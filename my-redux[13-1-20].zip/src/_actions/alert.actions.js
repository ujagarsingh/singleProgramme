import { alertConstants } from '../_constants';

export const alertActions = {
    success,
    error,
    clear
};

function success(message) {
	// debugger
    return { type: alertConstants.SUCCESS, message };
}

function error(message) {
	// debugger
    return { type: alertConstants.ERROR, message };
}

function clear() {
	// debugger
    return { type: alertConstants.CLEAR };
}