import { userConstants } from '../_constants';
import Axios from "axios";

//const USER_URL = "http://localhost:7777/users";

let user = '';
/*
Axios.get(USER_URL)
        .then((response)=>{
           //success
           user = response.data
         }).catch(()=>{
           //error
         })
*/
//let user = JSON.parse(localStorage.getItem('user'));

const initialState = user ? { loggedIn: true, user } : {};

export function authentication(state = initialState, action) {
  switch (action.type) {
    case userConstants.LOGIN_REQUEST:
	debugger
      return {
        loggingIn: true,
        user: action.user
      };
    case userConstants.LOGIN_SUCCESS:
	debugger
      return {
        loggedIn: true,
        user: action.user
      };
    case userConstants.LOGIN_FAILURE:
	debugger
      return {};
    case userConstants.LOGOUT:
	debugger
      return {};
    default:
	debugger
      return state
  }
}