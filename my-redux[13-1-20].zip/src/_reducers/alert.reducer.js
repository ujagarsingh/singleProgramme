import { alertConstants } from '../_constants';

export function alert(state = {}, action) {
  switch (action.type) {
    case alertConstants.SUCCESS:
	  // debugger
      return {
        type: 'alert-success',
        message: action.message
      };
    case alertConstants.ERROR:
	  // debugger
      return {
        type: 'alert-danger',
        message: action.message
      };
    case alertConstants.CLEAR:
	  // debugger
      return {};
    default:
	  // debugger
      return state
  }
}