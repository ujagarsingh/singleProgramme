// import config from 'config';
import { authHeader } from '../_helpers';
const USER_URL = "http://www.ujagarsingh.com/demo/login/api/";
export const userService = {
    login,
    logout,
    register,
    getAll,
    getById,
    update,
    delete: _delete
};

function login(username, password) {
   
    const url = USER_URL + 'login.php';
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    };
    return fetch(url, requestOptions)
        .then(handleResponse)
        .then(user => {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('user', JSON.stringify(user));

            return user;
        });
    
}

function logout() {
    // // debugger;
	// remove user from local storage to log user out
    localStorage.removeItem('user');
}

function getAll() {
    const url = USER_URL + 'read.php';
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
	// // debugger;
    return fetch(url, requestOptions)
    .then(handleResponse);
}

function getById(id) {
    
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
	// // debugger;
    return fetch(`/users/${id}`, requestOptions).then(handleResponse);
}


function PostData(type, userData) {
    
   }

function register(user) {
    const url = USER_URL + 'create_user.php';
    
    const requestOptions = {
        method: 'POST',
        mode: 'no-cors',
        // redirect: 'follow',
        headers: { 
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Max-Age": "3628800",
            "Access-Control-Allow-Headers": "X-Requested-With",
            "Access-Control-Allow-Methods": "POST, GET, PUT, DELETE, OPTIONS"
        },
        body: JSON.stringify(user)

    };

    return fetch(url, requestOptions).then(handleResponse);
 
}

function update(user) {
    const requestOptions = {
        method: 'PUT',
        headers: { ...authHeader(), 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    };
	// // debugger;
    return fetch(`/users/${user.id}`, requestOptions).then(handleResponse);;
}

// prefixed function name with underscore because delete is a reserved word in javascript
function _delete(id) {
    const requestOptions = {
        method: 'DELETE',
        headers: authHeader()
    };
	// // debugger;
    return fetch(`/users/${id}`, requestOptions).then(handleResponse);
}

function handleResponse(response) {
    console.log(response);
    // // debugger;
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logout();
                //location.reload(true);
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }
		// // debugger;
        return data;
    });
    
}