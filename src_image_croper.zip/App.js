//https://www.youtube.com/watch?v=pSzY5kh9MCs&list=PLB97yPrFwo5gpct1dOsirrotuPef1xBWS&index=3
import React from "react";
import "./App.css";
import { connect } from "react-redux";
import { anotherName } from "./actions/myactions";
import MyImage from "./my_image";

class App extends React.Component {

  state = {
    photos: "",
    crop: {
      unit: "%",
      width: 30,
      aspect: 16 / 9
    }
  };
  submitData = () => {
    //alert(1);
    console.log(this.state);
    this.resizeImage(this.state.photos);
  };

  myCallback = dataFromChild1 => {
    this.setState({
      photos: dataFromChild1
    });
  };

  resizeImage = data => {
    var canvas = document.createElement("canvas");
    var ctx = canvas.getContext("2d");

    canvas.width = 400; // target width
    canvas.height = 400; // target height

    var image = new Image();
    //document.getElementById("original").appendChild(image);
    var _img = "";
    var self = this;
    image.onload = function(e) {
      ctx.drawImage(
        image,
        0,
        0,
        image.width,
        image.height,
        0,
        0,
        canvas.width,
        canvas.height
      );
      // create a new base64 encoding
      var resampledImage = new Image();
      resampledImage.src = canvas.toDataURL();
      _img = resampledImage.src;
      //document.getElementById("resampled").appendChild(resampledImage);
      self.managePhotoSize(_img);
    };
    image.src = this.state.photos;
  };

  managePhotoSize = img => {
    this.setState({
      photos: img
    });
  };
  render() {
    const { photos, crop } = this.state;
    console.log(this.state);
    return (
      <div className="App">
        <p>
          This Is <strong>{this.props.myName}</strong>
        </p>
        <button
          onClick={() => {
            this.props.changeName("Suresh");
          }}
        >
          Change Name
        </button>
        <hr />
        <MyImage callbackFromParent={this.myCallback} crop={crop} />
        <hr />
        <img src={photos} alt="" />
        <hr />
        <button onClick={this.submitData}>Submit</button>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    myName: state.name,
    myWish: state.wish
  };
};
const mapDispatchToProps = dispatch => {
  return {
    changeName: name => {
      dispatch(anotherName("Suresh"));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
