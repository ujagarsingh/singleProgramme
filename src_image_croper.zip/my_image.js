import React, { PureComponent } from "react";
import ReactCrop from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";
import "./my_image.css";

class MyImage extends PureComponent {
  state = {
    src: null,
    /*crop: {
      unit: "%",
      width: 30,
      aspect: 1
    },*/
    crop: {},
    base64Image: "",
    isActive: false
  };

  constructor(props) {
    super(props);
    console.log(props);
  }
  componentDidMount() {
    console.log(this.props);
    const crop = this.props.crop;
    this.setState({ crop });
  }

  onSelectFile = e => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.addEventListener("load", () =>
        this.setState({ src: reader.result, isActive: true })
      );
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  // If you setState the crop in here you should return false.
  onImageLoaded = image => {
    this.imageRef = image;
  };

  onCropComplete = crop => {
    this.makeClientCrop(crop);
  };

  onCropChange = (crop, percentCrop) => {
    // You could also use percentCrop:
    // this.setState({ crop: percentCrop });
    this.setState({ crop });
  };

  async makeClientCrop(crop) {
    if (this.imageRef && crop.width && crop.height) {
      const croppedImageUrl = await this.getCroppedImg(
        this.imageRef,
        crop,
        "newFile.jpeg"
      );
      this.setState({ croppedImageUrl });
    }
  }

  getCroppedImg(image, crop, fileName) {
    const canvas = document.createElement("canvas");
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    /*canvas.width = 400;
    canvas.height = 400;*/
    const ctx = canvas.getContext("2d");

    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );

    // As Base64 string
    const base64Image = canvas.toDataURL("image/jpeg");

    return new Promise((resolve, reject) => {
      canvas.toBlob(blob => {
        if (!blob) {
          //reject(new Error('Canvas is empty'));
          console.error("Canvas is empty");
          return;
        }
        blob.name = fileName;
        window.URL.revokeObjectURL(this.fileUrl);
        this.fileUrl = window.URL.createObjectURL(blob);
        resolve(this.fileUrl);
        this.setState({ base64Image });
        this.imageHandlar(base64Image);
      }, "image/jpeg");
    });
  }
  resetImageHandlar = () => {
    this.setState({
      src: null,
      croppedImageUrl: "",
      isActive: false
    });
    document.querySelector("#inputGroupFile").value = "";
    console.log(this.state);
  };

  

  imageHandlar = base64Image => {
    this.props.callbackFromParent(base64Image);
  };

  render() {
    const { crop, croppedImageUrl, src, isActive } = this.state;
    console.log(this.state);
    return (
      <div
        className={isActive === true ? "image-cropper active" : "image-cropper"}
      >
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-8">
              {src &&
                <ReactCrop
                  src={src}
                  crop={crop}
                  ruleOfThirds
                  onImageLoaded={this.onImageLoaded}
                  onComplete={this.onCropComplete}
                  onChange={this.onCropChange}
                />}
            </div>
            <div className="col-sm-4">
              {croppedImageUrl &&
                <img
                  alt="Crop"
                  style={{ maxWidth: "100%" }}
                  src={croppedImageUrl}
                />}
            </div>
          </div>
        </div>
        <div className="form-group">
          <div className="input-group mb-3">
            <div className="custom-file">
              <input
                type="file"
                onChange={this.onSelectFile}
                className="custom-file-input"
                id="inputGroupFile"
              />
              <label className="custom-file-label" htmlFor="inputGroupFile">
                Choose file
              </label>
            </div>
            <div className="input-group-append">
              <span
                onClick={this.resetImageHandlar}
                className="input-group-text"
              >
                Done
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default MyImage;
