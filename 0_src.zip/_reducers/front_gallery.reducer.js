import { frontGalleryConstants } from '../_constants';

export function frontGallery(state = {}, action) {
  switch (action.type) {
    case frontGalleryConstants.GALLERY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case frontGalleryConstants.GALLERY_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case frontGalleryConstants.GALLERY_FAILURE:
      return {
        error: action.error
      };


    case frontGalleryConstants.CREATE_GALLERY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontGalleryConstants.CREATE_GALLERY_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case frontGalleryConstants.CREATE_GALLERY_FAILURE:
      return {
        error: action.error
      };



    case frontGalleryConstants.UPDATE_GALLERY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontGalleryConstants.UPDATE_GALLERY_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case frontGalleryConstants.UPDATE_GALLERY_FAILURE:
      return {
        error: action.error
      };


    case frontGalleryConstants.DELETE_GALLERY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontGalleryConstants.DELETE_GALLERY_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case frontGalleryConstants.DELETE_GALLERY_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}