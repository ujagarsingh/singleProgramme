import { authenticConstants } from '../_constants';

export function user(state = {}, action) {
  switch (action.type) {
    case authenticConstants.VALIDATE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case authenticConstants.VALIDATE_SUCCESS:
      return {
        valid: action.user
      };
    case authenticConstants.VALIDATE_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}