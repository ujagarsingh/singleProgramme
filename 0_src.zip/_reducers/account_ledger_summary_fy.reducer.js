import { accountLedgerSummaryFYConstants } from '../_constants';

export function accountLedgerSummaryFY(state = {}, action) {
  switch (action.type) {
    case accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_SUCCESS:
      // debugger
      // const new_obj = { ...state.item, ledger_fy_report : action.response.ledger_fy_report};
      // console.log(new_obj);
      return {
        item: action.response,
        loading: false,
      };
    case accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}