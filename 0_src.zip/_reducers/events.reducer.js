import { eventsConstants } from '../_constants';

export function events(state = {}, action) {
  switch (action.type) {
    case eventsConstants.EVENTS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case eventsConstants.EVENTS_SUCCESS:
      return {
        item: action.response
      };
    case eventsConstants.EVENTS_FAILURE:
      return {
        error: action.error
      };


    case eventsConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case eventsConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case eventsConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case eventsConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case eventsConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case eventsConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case eventsConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case eventsConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case eventsConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    default:
      return state
  }
}