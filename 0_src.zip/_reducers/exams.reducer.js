import { examsConstants } from '../_constants';

export function exams(state = {}, action) {
  switch (action.type) {
    case examsConstants.EXAMS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examsConstants.EXAMS_SUCCESS:
      return {
        item: action.response
      };
    case examsConstants.EXAMS_FAILURE:
      return {
        error: action.error
      };




    case examsConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true, 
      };
    case examsConstants.CREATE_SUCCESS:
      const new_arr = [...action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case examsConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    case examsConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examsConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case examsConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case examsConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examsConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case examsConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    default:
      return state
  }
}