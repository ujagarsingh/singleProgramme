import { accLedgerEntryConstants } from '../_constants';

export function accLedgerEntry(state = {}, action) {
  switch (action.type) {
    case accLedgerEntryConstants.ACC_LEDGER_ENTRY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accLedgerEntryConstants.ACC_LEDGER_ENTRY_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accLedgerEntryConstants.ACC_LEDGER_ENTRY_FAILURE:
      return {
        error: action.error
      };


   
    case accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_FAILURE:
      return {
        error: action.error
      };
   

    default:
      return state
  }
}

