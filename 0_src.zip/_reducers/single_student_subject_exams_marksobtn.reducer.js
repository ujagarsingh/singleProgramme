import { singleStudentSubjectExamsMarksobtnConstants } from '../_constants';

export function singleStudentSubjectExamsMarksobtn(state = {}, action) {
  switch (action.type) {
    case singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_SUCCESS:
      return {
        item: action.response
      };
    case singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}