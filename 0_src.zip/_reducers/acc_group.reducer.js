import { accGroupConstants } from '../_constants';

export function accGroup(state = {}, action) {
  switch (action.type) {
    case accGroupConstants.ACC_GROUP_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accGroupConstants.ACC_GROUP_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accGroupConstants.ACC_GROUP_FAILURE:
      return {
        error: action.error
      };


    case accGroupConstants.CREATE_ACC_GROUP_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accGroupConstants.CREATE_ACC_GROUP_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accGroupConstants.CREATE_ACC_GROUP_FAILURE:
      return {
        error: action.error
      };


    case accGroupConstants.UPDATE_ACC_GROUP_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accGroupConstants.UPDATE_ACC_GROUP_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accGroupConstants.UPDATE_ACC_GROUP_FAILURE:
      return {
        error: action.error
      };


    case accGroupConstants.DELETE_ACC_GROUP_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accGroupConstants.DELETE_ACC_GROUP_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accGroupConstants.DELETE_ACC_GROUP_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}