import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import ReportScoreSummary from './testpaper/reportScoreSummary';
import ReportLeaderboard from './testpaper/reportLeaderboard';
import ReportOverview from './testpaper/reportOverview';
import ReportUNTopper from './testpaper/reportYouNTopper';
import ReportDistribution from './testpaper/reportDistribution';
import ReportSummary from './testpaper/reportSummary';

class TestPaper extends Component {
	state = {
		selected_school_index: "",
		user: "ujagar",
		tst_repo_summary: { // accourding to user_id  [section 1, 2, 4, 5, 6, 7]
			user_id: "",
			tst_info_id: "",
			tst_title: "",
			subject: "",
			score: "",
			correct_ans: "",
			used_time: "",
			attempt_ans: "",
			accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
		},
		tst_repo_top:  // accourding to test_id top 10 (maximum scored) [section 3, 5]
			[
				{
					user_id: "", test_info_id: "", test_title: "", subject: "",
					score: "", correct_ans: "", used_time: "", attempt_ans: "",
					accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
				},
				{
					user_id: "", test_info_id: "", test_title: "", subject: "",
					score: "", correct_ans: "", used_time: "", attempt_ans: "",
					accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
				},
				{
					user_id: "", test_info_id: "", test_title: "", subject: "",
					score: "", correct_ans: "", used_time: "", attempt_ans: "",
					accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
				}
			]
	}
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	componentDidMount() {

	}

	showInstruction(event) {
		event.preventDefault();

	}
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}

	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (
			<div className="page-content">
				<Helmet>
					<title>Test Result</title>
				</Helmet>
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				{user &&
					<>
						<div className="page-bar d-flex">
							<div className="page-title">Test Result</div>
							<div className="form-inline ml-auto filter-panel">
								<span className="filter-closer">
									<button type="button" className="btn btn-danger filter-toggler-c">
										<i className="fa fa-times"></i>
									</button>
								</span>
								<div className="filter-con">
									<div className="filter-con">
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-warning btn-sm">Download Report <i className="fa fa-plus" /></NavLink>
										</div>
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-primary btn-sm">View Solutions <i className="fa fa-plus" /></NavLink>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="card card-box sfpage-cover">
							<div className="card-body sfpage-body">
								<div className="table-scrollable">
									<div className="container">
										<div className="d-flex">
											<h4 className="mr-auto">Title of This etest</h4>
										</div>
										<hr />
										<ReportScoreSummary />
										<hr />
										<div className="row">
											<div className="col">
												<div className="card">
													<ReportLeaderboard />
												</div>
											</div>
											<div className="col">
												<div className="card">
													<ReportOverview />
												</div>
											</div>
											<div className="col">
												<div className="card">
													<ReportUNTopper />
												</div>
											</div>
										</div>
										<hr />
										<div className="row">
											<div className="col">
												<div className="card">
													<ReportDistribution />
												</div>
											</div>
										</div>
										<hr />
										<div className="row">
											<ReportSummary />
										</div>
									</div>
									{/* <img className="thumbnail"
										alt="Test Result"
										src={`${process.env.PUBLIC_URL}/assets/images/dummy_rudult.png`} /> */}
								</div>
							</div>
						</div>
					</>
				}
			</div>
		)
	}
}
export default withRouter(TestPaper);