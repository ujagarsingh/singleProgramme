import React, { Component } from "react";

class ReportDistribution extends Component {
    constructor() {
        super();

    };


    componentDidMount() {
    }

    render() {
        return (
            <div class="card-body">
                <h4>Section wise distribution</h4>
                <h6>You attempted 2% question correct in [test name]. Keep praticing to increase your score!.</h6>
                <p>Your detailed section performance is shown below.</p>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Paper</th>
                            <th scope="col">Attempted</th>
                            <th scope="col">Correct</th>
                            <th scope="col">Accuracy</th>
                            <th scope="col">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">[Test Name]</th>
                            <td>2/100</td>
                            <td>2/100</td>
                            <td>100.00%</td>
                            <td>01:30:20</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
}

export default ReportDistribution;
