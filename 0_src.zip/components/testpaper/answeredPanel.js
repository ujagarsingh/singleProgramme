import React, { Component } from "react";

class AnsweredPanel extends Component {
  
  componentDidMount() {

  }
  activeThisQuestionHandler = (event, inx) => {
    event.preventDefault();
    this.props.activeThisQuestionHandler(inx);
  }

  setBtnClass = (inx) => {
    const cbtn = this.props.quiz[inx];
    const cid = this.props.current_id;
    let class_str = "btn ";
    if (cid === cbtn.id) {
      class_str += " btn-active";
    }

    if (cbtn.detail.markAS == "1") {
      class_str += " btn-answered";
    } else if (cbtn.detail.markAS == "2") {
      class_str += " btn-not-answered";
    } else if (cbtn.detail.markAS == "3") {
      class_str = " btn-review-later";
    } else if (cbtn.detail.markAS == "4") {
      class_str += " btn-ans-rev-leter";
    } else {
      class_str += " btn-not-visited";
    }

    return class_str;
  }

  render() {
    const { quiz } = this.props;
    return (
      <div className="answered-panel">
        <div className="title-test">Test Title Here...</div>
        <div className="list-queation">
          <button type="button" className="btn btn-answered">1</button>
          <button type="button" className="btn btn-active">2</button>
          <button type="button" className="btn btn-review-later">3</button>
          <button type="button" className="btn btn-ans-rev-leter">4</button>
          <button type="button" className="btn btn-not-answered ">5</button>
          {quiz.map((btn, inx) => {
            return (
              <button key={inx}
                onClick={(event) => { this.activeThisQuestionHandler(event, inx) }}
                className={() => this.setBtnClass(inx)}
                type="button" >{btn.id}
              </button>
            )
          })}

        </div>
      </div>

    );
  }
}

export default AnsweredPanel;
