import React, { Component } from "react";

class ReportScoreSummary extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <div className="row">
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Scrore</div>
													<div className="score-detail">3.00/100</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Accuracy</div>
													<div className="score-detail">100.00%</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Rank AIS</div>
													<div className="score-detail">32/54</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Percentage</div>
													<div className="score-detail">3.00%</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Percentile</div>
													<div className="score-detail">72.00%</div>
												</div>
											</div>
										</div>
																	   
    );
  }
}

export default ReportScoreSummary;
