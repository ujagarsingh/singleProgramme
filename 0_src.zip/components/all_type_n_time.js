import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { feeCategoryAction, schoolsAction, accLedgerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddTypeNTime from './add_type_n_time';
import EditTypeNTime from './edit_type_n_time';

import CommonFilters from '../utility/Filter/filter-schools';

class AllTypeNTime extends Component {
  state = {
    fee_category: [],
    months_params: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.feeCategory)) {
      this.props.getFeeCategory();
    }
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }

    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_feeCategory = this.props.feeCategory;
      if (_all_feeCategory && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _feeCategory = this.props.feeCategory;
    if (!isEmpty(_feeCategory)) {
      const _sch_feeCategory = _feeCategory.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
        return false
      })
      this.setState({
        display_feeCategory: _sch_feeCategory,
      })
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.feeCategory) {
      setTimeout(() => {
        this.filterBySchoolHandler()
      }, 100);
    }
  }

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteFeeCategory({ id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };


  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateFeeCategory(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.feeCategory.filter((item) => {
      if (item.id === id) {
        return item
      }
      return false
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }
  orderListofCollectTime = (months) => {
    if (!isEmpty(months)) {
      const month_arr = months.split(',');
      return (
        <ul className="orderedlist w-200">
          {month_arr.map((mnth, inx) => {
            let item = "";
            if (!isEmpty(mnth)) {
              item = <li key={inx}>{mnth}</li>
            }
            return (item)
          })
          }
        </ul>
      )
    }
  }
  render() {
    const { formIsHalfFilledOut, createItem, editItem, selected_item, display_feeCategory } = this.state;
    const { feeCategory, schools, user, accLedger } = this.props;
    //console.log(_state)
    return (
      <div className="page-content">
        <Helmet>
          <title>All Fee Category</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && feeCategory && accLedger &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">All Fee Category</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    // showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                  // filterByClsHandler={this.filterByClsHandler}
                  />

                  {/* <div className="form-group mt-1">
                <NavLink to="/add_type_n_time.jsp" className="btn btn-sm btn-primary ml-auto">
                  Add New</NavLink>
              </div> */}
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                {createItem ? <AddTypeNTime
                  accLedger={accLedger}
                  toggeleCreate={this.toggeleCreate}
                  updateView={this.updateView} />
                  : null}
                {editItem ?
                  <>
                    <EditTypeNTime
                      selected_item={selected_item}
                      accLedger={accLedger}
                      schools={schools}
                      user={user}
                      updateHandlar={this.updateHandlar}
                      openEdit={this.openEdit}
                      closeEdit={this.closeEdit}
                    />
                    <div className="backdrop edit-mode"></div>
                  </>
                  : null}
                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm">
                    <thead>
                      <tr>
                        <th />
                        <th> School </th>
                        <th> Fee Title </th>
                        <th> Fee Type </th>
                        <th> Ledger Name </th>
                        <th> Fee Different </th>
                        {/*_state.months_params.map((item, index) => {
                      return (
                        <th key={index}> {item} </th>
                        )
                      })*/}
                        <th>Collection Time</th>
                        <th> Action </th>
                      </tr>
                    </thead>
                    {display_feeCategory &&
                      <tbody>
                        {display_feeCategory.map((item, index) => {
                          return (
                            <tr key={index}>
                              <td>{index + 1 + ' .'}</td>
                              <td>{item.school_name}, {item.school_medium}</td>
                              <td>{item.cat_name}</td>
                              <td>{item.cat_type}</td>
                              <td>{item.ledger_name}</td>
                              <td>{item.cat_diff}</td>
                              <td>{this.orderListofCollectTime(item.collect_time)}</td>
                              <td className="d-flex">
                                {/* <NavLink to={`/edit_type_n_time.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit
                          </NavLink> */}
                                <button className="btn btn-primary btn-sm mr-1"
                                  value={item.id}
                                  type="button"
                                  onClick={event => this.openEdit(event, item.id)}>Edit</button>

                                <button className="btn btn-danger btn-sm"
                                  value={item.id}
                                  type="button"
                                  onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    }
                  </table>
                </div>
              </div>
              <div className="card-footer">
                {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-danger btn-sm ">
                    Cancel
            </button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-primary btn-sm">
                    Add New
            </button>
                }
              </div>
            </div>
          </>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: accLedger } = state.accLedger;
  const { item: feeCategory } = state.feeCategory;
  const { item: schools } = state.schools;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return { user, feeCategory, schools, filteredSchoolData, filteredClassesData, accLedger };
}

const actionCreators = {
  getFeeCategory: feeCategoryAction.getFeeCategory,
  getAccLedger: accLedgerActions.getAccLedger,
  updateFeeCategory: feeCategoryAction.update,
  deleteFeeCategory: feeCategoryAction.delete,
  getSchools: schoolsAction.getSchools,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllTypeNTime));