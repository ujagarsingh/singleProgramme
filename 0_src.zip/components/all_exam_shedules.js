import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import SingleShedule from './single_shedule';
import { connect } from 'react-redux';
import { schoolsAction, examSdulNotesAction, examsCategoryAction, examSdulAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const DELETE_SHEDULE = `http://schools.rajpsp.com/api/exam_sdul/delete.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
// const READ_SHEDULE = `http://schools.rajpsp.com/api/exam_sdul/read.php`;

class AllExamShedules extends Component {
   state = {
      schools: [],
      shedule_arr: [],
      exams: [],
      notes: [],
      final_shedule: {},
      group_id: '',
      school_id: '',
      user_category: '',
      session_year_id: '',
      formIsHalfFilledOut: false,
      showSheduleData: false,
   }
   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.examSdulNotes)) {
         this.props.getExamSdulNotes();
      }
      if (isEmptyObj(this.props.examsCategory)) {
         this.props.getExamsCategory();
      }
      if (isEmptyObj(this.props.examSdul)) {
         this.props.getExamSdul();
      }
   }

   componentWillReceiveProps(nextProps) {
      if (nextProps.examSdul) {
         this.setJsonToSheduleObject(nextProps.examSdul);
      }
   }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //                this.getExamShedules();
   //                this.getExamsCategories();
   //                this.getSheduleNotes();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getSheduleNotes() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //       exam_id: this.state.exam_name,
   //    }
   //    // console.log(JSON.stringify(obj));
   //    // debugger;
   //    axios.post(READ_SDUL_NOTE, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          let _notes = [];
   //          getRes.forEach((item) => {
   //             _notes.push({ "note": item.notes })
   //          })
   //          this.setState({
   //             notes: _notes,
   //             // updated_subjects: [...this.state.updated_subjects, getRes],
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }


   // getExamsCategories() {
   //    loadProgressBar();
   //    axios.get(READ_EXAM_CATE)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             exams: getRes,
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // getExamShedules() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id
   //    }
   //    console.log(JSON.stringify(obj));
   //    axios.post(READ_SHEDULE, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          if (!isEmpty(getRes.message)) {
   //             Alert.success(getRes.message, {
   //                position: 'bottom-right',
   //                effect: 'jelly',
   //                timeout: 5000, offset: 40
   //             });
   //          } else {
   //             this.setJsonToSheduleObject(getRes.db_data);
   //          }
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   setJsonToSheduleObject(data) {
      const final_arr = data.map((item) => {
         // let shedule_data = JSON.parse(item.shedule);
         let shedule_data = item.shedule;
         item['shedule'] = shedule_data;
         return item
      })
      this.setState({
         shedule_arr: final_arr
      })
   }
   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.props.deleteExamSdul({ id: id });
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   // deleteHandlar = (id) => {
   //    //event.preventDefault();
   //    const _id = id;
   //    axios.post(DELETE_SHEDULE + '?id=' + _id)
   //       .then(res => {
   //          const getRes = res.data;
   //          //console.log(getRes)
   //          Alert.success(getRes.message, {
   //             position: 'bottom-right',
   //             effect: 'jelly',
   //             timeout: 5000, offset: 40
   //          });
   //          const _shedule_arr = this.state.shedule_arr.filter((item, index) => {
   //             return item.id !== _id
   //          })
   //          this.setState({
   //             shedule_arr: _shedule_arr
   //          })
   //       }).catch((error) => {
   //          //this.setState({ errorMessages: error });
   //       })
   // }
   getExamCatNameHandler(exam_id) {
      const _exams = this.props.examsCategory;
      const _selected_obj = _exams.filter((item) => {
         if (item.id === exam_id) {
            return item;
         }
      })
      return _selected_obj[0].cat_name;
   }
   // getSchoolNameHandler(school_id) {
   //    const _schools = this.props.schools;
   //    debugger
   //    if (!isEmpty(_schools)) {
   //       const _selected_obj = _schools.filter((item) => {
   //          if (item.id === school_id) {
   //             return item
   //          }
   //       })
   //       // return _selected_obj[0].sch_name;
   //    } else {
   //       return false
   //    }
   // }
   viewSheduleHandler(ev, sdul_id) {
      ev.preventDefault();
      const _shedule_arr = this.props.examSdul;
      const selected_data = _shedule_arr.filter((item) => {
         if (item.id === sdul_id) {
            return item
         }
      })
      const _shedule = selected_data[0].shedule;
      console.log(typeof (_shedule));
      // console.log(_shedule);
      this.setState({
         final_shedule: _shedule,
         showSheduleData: true
      })
   }
   hideSheduleHandler(ev) {
      ev.preventDefault();
      this.setState({
         showSheduleData: false
      })
   }
   render() {
      const { notes, final_shedule, showSheduleData, formIsHalfFilledOut } = this.state;
      const { user, schools, examSdulNotes, examsCategory, examSdul } = this.props;
      console.log(this.props);
      return (
         <div className="page-content">
            <Helmet>
               <title>Exam Schedule</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

            {/* <div className="page-bar d-flex">
               <div className="page-title">Exam Schedule</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <div className="form-group ml-2">
                        <NavLink to="/create_exam_shedule.jsp" className="btn btn-primary btn-sm">Add New <i className="fa fa-plus" /></NavLink>
                     </div>
                  </div>
               </div>
            </div> */}
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  {user && schools && examSdulNotes && examsCategory && examSdul &&
                     <div className="table-scrollable">
                        <table className="table table-striped table-bordered table-hover table-sm">
                           <thead className="text-center">
                              <tr>
                                 <th />
                                 <th>School id</th>
                                 <th>Medium</th>
                                 <th>Session Year</th>
                                 <th>Exam id</th>
                                 <th>Action </th>
                              </tr>
                           </thead>
                           {examSdul.length > 0 && examsCategory.length > 0 ?
                              <tbody>
                                 {examSdul.map((item, index) => {
                                    return (
                                       <tr key={index} >
                                          <td>{index + 1}</td>
                                          <td className="left">
                                             {item.school_name}
                                             {/* {this.getSchoolNameHandler(item.school_id)} */}
                                          </td>
                                          <td className="left">
                                             {item.medium}
                                          </td>
                                          <td className="left">
                                             {item.ses_year}
                                          </td>
                                          <td className="left">
                                             {this.getExamCatNameHandler(item.exam_id)}
                                          </td>
                                          <td className="d-flex">
                                             <button className="btn btn-primary mr-2 btn-sm"
                                                value={item.id}
                                                onClick={event => this.viewSheduleHandler(event, item.id)}>
                                                View
                                             </button>
                                             <button className="btn btn-danger btn-sm"
                                                value={item.id}
                                                onClick={event => this.confirmBoxDelete(event, item.id)}>
                                                Del</button>
                                          </td>
                                       </tr>
                                    )
                                 })
                                 }
                              </tbody>
                              : null}
                        </table>
                        {showSheduleData ?
                           <React.Fragment>
                              <button className="btn btn-warning ml-auto mr-2 btn-sm"
                                 onClick={event => this.hideSheduleHandler(event)}>
                                 Hide Time Shedule</button>
                              <SingleShedule
                                 notes={notes}
                                 shedule_obj={final_shedule} />
                           </React.Fragment>
                           : null
                        }
                     </div>
                  }
               </div>
               <div className="card-footer">
                  <NavLink to="/create_exam_shedule.jsp"
                     className="btn btn-primary btn-sm">Add New
                  </NavLink>
               </div>
            </div>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: examSdulNotes } = state.examSdulNotes;
   const { item: examsCategory } = state.examsCategory;
   const { item: examSdul } = state.examSdul;
   return { user, schools, examSdulNotes, examsCategory, examSdul };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
   getExamsCategory: examsCategoryAction.getExamsCategory,
   getExamSdul: examSdulAction.getExamSdul,
   deleteExamSdul: examSdulAction.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllExamShedules));