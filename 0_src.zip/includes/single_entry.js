import React, { Component } from 'react';
import { withRouter } from 'react-router';

import { isEmpty } from '../utility/utilities';

class SingleEntry extends Component {

  ledgerListHandler = (event, eIndex, rIndex, list_type) => {
    // debugger
    const ldr_list = event.target.getAttribute('data-type');
    const ldr_val = event.target.value;
    event.target.select();
    // console.log(ldr_val);
    if (ldr_list === "CR") {
      const _inx = this.props.credit_ledgers.findIndex((item) => item.ledger_name === ldr_val);
      const obj = {
        filter_data: this.props.credit_ledgers,
        eindex: eIndex,
        rindex: rIndex,
        list_type: list_type,
        cursor: (_inx === -1) ? 0 : _inx,
      }
      // console.log(obj);

      this.props.ledgerListHandler(obj);
    } else if (ldr_list === "DR") {
      const _inx = this.props.debit_ledgers.findIndex((item) => item.ledger_name === ldr_val);
      const obj = {
        filter_data: this.props.debit_ledgers,
        eindex: eIndex,
        rindex: rIndex,
        list_type: list_type,
        cursor: (_inx === -1) ? 0 : _inx,
      }
      // console.log(obj);

      this.props.ledgerListHandler(obj);
    }
  };

  blurHandler = (event, fieldName, eIndex, rIndex) => {
    const _val = event.target.value;
    if (fieldName === 'ref_tr_type' || fieldName === 'ldr_type') {
      const V1 = _val.toUpperCase();
      if (V1 === "C" || V1 === "D") {
        const V2 = (V1 === "C") ? "CR" : "DR";
        this.props.valueTOchangeHandler(V2, eIndex, rIndex)
      }
    }
  };




  selectRefTypeHandler() {
    // debugger;
    const refs_items = this.props.refs_type;
    const cursor = this.props.cursor;
    if (refs_items.length > 0) {
      return (<div className="list-accunts">
        <div className="list-acc-head">Adjestment Type</div>
        <div className="list-acc-body" id="ldrList">
          <ul>
            {refs_items.map((item, index) => {
              return (
                <li
                  className={cursor === index ? 'active' : null}
                  onClick={event => this.props.activeThisHandler(index)}
                  key={index}>
                  {item.item}
                </li>
              )
            })}
          </ul>
        </div>
      </div>
      )
    }
  }
  selectLedgerwiseExistingRefsHandler = () => {
    // alert("Line No. 89  " + id)
    // debugger;
    const { cursor, adj_list } = this.props;
    // console.log(adj_list);
    return (
      <div className="list-accunts">
        <div className="list-acc-head">Pending Adjestment(s)</div>
        <div className="list-acc-body" id="ldrList">
          <table className="table table-bordered table-sm m-0">
            <tbody>
              {adj_list.map((elem, index) => {
                return (
                  <tr
                    className={cursor === index ? 'active' : null}
                    onClick={event => this.props.activeThisHandler(index)}
                    key={index}>
                    <td>{elem.ldr_ref_id}</td>
                    <td>{elem.id}</td>
                    <td>{elem.tr_date}</td>
                    <td>{elem.tr_amount}</td>
                    <td>{elem.tr_type}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    )

    // id: "87"
    // ldr_ref_id: "13_STF_4"
    // ref_type: "1"
    // school_id: "4"
    // self_ref_id: "0"
    // server_date_time: "2021-01-26 18:29:29"
    // session_year_id: "1"
    // tr_amount: "13555"
    // tr_date: "2021-01-27"
    // tr_type: "CR"
    // vchr_ref_id: "3352"
    // return adj_list; 
  }

  setCredentialsHandler = (event, eIndex, rIndex, list_type) => {
    event.preventDefault();
    this.props.setCredentialsHandler(event, eIndex, rIndex, list_type);
  }

  render() {
    const { eIndex, eItem, list_type, eindex, rindex } = this.props;
    // console.log(this.props.cursor)
    return (
      <div className="av-detail-head">
        <div className="main-head" >
          <div className="head-name d-flex">
            <span className="txt-normal mr-2">
              <input type="text"
                value={eItem.tr_type}
                disabled={(eIndex === 0) ? true : false}
                data-eindex={eIndex}
                data-ename={'ldr_type'}
                maxLength="2"
                className="form-control trans-input tr-type form-control-sm"
                onChange={event => this.props.changeHandler(event, `ldr_type`, null, eIndex)}
                onBlur={event => this.blurHandler(event, `ldr_type`, eIndex, null)}
                onFocus={event => this.setCredentialsHandler(event, eIndex, null, null)}
              />
            </span>
            <input type="text"
              value={eItem.ledger_name}
              data-type={eItem.tr_type}
              data-eindex={eIndex}
              data-ename={'ldr_name'}
              className="form-control trans-input tr-name form-control-sm"
              onChange={event => this.props.changeHandler(event, `ldr_name`, null, eIndex)}
              onFocus={event => this.ledgerListHandler(event, eIndex, null, "ledger")}
            // onClick={event => this.ledgerListHandler(event, eIndex, null, "ledger")}
            //onBlur={event => this.blurHandler(event, `ldr_name`, null, eIndex)}
            />
          </div>
          <div className="head-amount">
            <div className="dr-total">
              {(eItem.tr_type === "DR") ?
                <input type="number"
                  value={eItem.tr_amount}
                  data-method={eItem.adjustment}
                  data-ccenter={eItem.cost_center}
                  data-eindex={eIndex}
                  data-ename={'ldr_amo'}
                  className="form-control trans-input tr-amount form-control-sm"
                  onChange={event => this.props.changeHandler(event, `ldr_amo`, null, eIndex, `DR`)}
                  onFocus={event => this.setCredentialsHandler(event, eIndex, null, null)}
                />
                : null}
            </div>
            <div className="cr-total">
              {(eItem.tr_type === "CR") ?
                <input type="number"
                  value={eItem.tr_amount}
                  data-eindex={eIndex}
                  data-ename={'ldr_amo'}
                  className="form-control trans-input tr-amount form-control-sm"
                  onChange={event => this.props.changeHandler(event, `ldr_amo`, null, eIndex, `CR`)}
                  onFocus={event => this.setCredentialsHandler(event, eIndex, null, null)}
                />
                : null}
            </div>
          </div>
        </div>
        {eItem.ledger_name &&
          <div className="crnt-balance-head">
            <div className="bal-head">
              <span className="txt-normal">Cur Bal :</span> {eItem.ldr_crnt_balance}
              <span className="txt-normal ml-1">{eItem.ldr_crnt_balance_type}</span>
              <span className="txt-normal ml-4">ID :</span> {eItem.ldr_ref_id}
            </div>
          </div>
        }
        {eItem.adjustment && eItem.tr_amount &&
          <div className="adjestment-head">
            {eItem.ref_child.map((rItemm, rIndex) => {
              return (
                <div className="adjt-head" key={rIndex}>
                  <div className="ref-type">
                    <input
                      // onFocus={event => this.ledgerListHandler(event, eIndex)}
                      readOnly={true}
                      defaultValue={rItemm.ref_type}
                      placeholder={"Refs Type"}
                      data-eindex={eIndex}
                      data-rindex={rIndex}
                      data-erefid={eItem.ldr_ref_id}
                      data-ename={'ref_type'}
                      onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, 'adjustment')}
                      // onChange={event => this.props.changeHandler(event, `ref_type`, null, eIndex, null, rIndex)}
                      type="text"
                      className="form-control trans-input tr-amount form-control-sm" />
                    {(list_type === "adjustment") && (eIndex === eindex) && (rIndex === rindex) &&
                      <div className="">
                        {this.selectRefTypeHandler()}
                      </div>
                    }
                  </div>
                  {/* {rItemm.ref_name &&
                    <> */}
                  {(rItemm.ref_type === 'Advance') || (rItemm.ref_type === 'On Account') ?
                    <div className="ref-name">
                      <input type="text"
                        placeholder={rItemm.ref_type}
                        data-eindex={eIndex}
                        data-rindex={rIndex}
                        data-ename={'ref_name'}
                        defaultValue={rItemm.ref_name + "_" + rIndex}
                        onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, null)}
                        onChange={event => this.props.changeHandler(event, `ref_name`, null, eIndex, null, rIndex)}
                        className="form-control trans-input tr-amount form-control-sm" />
                    </div>
                    : null}
                  {(rItemm.ref_type === 'Agst Ref') ?
                    <div className="ref-name">
                      <input type="text"
                        readOnly={true}
                        placeholder={"Refs Name"}
                        data-eindex={eIndex}
                        data-rindex={rIndex}
                        data-ename={'ref_name'}
                        defaultValue={rItemm.ref_name}
                        onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, 'old_refs')}
                        className="form-control trans-input tr-amount form-control-sm" />
                      {(list_type === "old_refs") && (eIndex === eindex) && (rIndex === rindex) &&
                        <div className="">
                          {this.selectLedgerwiseExistingRefsHandler()}
                        </div>
                      }
                    </div>
                    : null}
                  {(rItemm.ref_type === 'New Ref') ?
                    <div className="ref-name">
                      <input type="text"
                        placeholder={"Refs Name"}
                        data-eindex={eIndex}
                        data-rindex={rIndex}
                        data-ename={'ref_name'}
                        defaultValue={rItemm.ref_name + "_" + rIndex}
                        onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, null)}
                        onChange={event => this.props.changeHandler(event, `ref_name`, null, eIndex, null, rIndex)}
                        className="form-control trans-input tr-amount form-control-sm" />
                    </div>
                    : null
                  }
                  {rItemm.ref_type &&
                    <>
                      <div className="tr-amount">
                        <input type="number"
                          placeholder={"Amount"}
                          data-eindex={eIndex}
                          data-rindex={rIndex}
                          data-ename={'ref_tr_amount'}
                          value={rItemm.ref_tr_amount}
                          onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, null)}
                          onChange={event => this.props.changeHandler(event, `ref_tr_amount`, null, eIndex, eItem.tr_type, rIndex)}
                          // onBlur={event => this.props.blurHandler(event, `ref_tr_amount`, eIndex, rIndex)}
                          className="form-control true trans-input tr-amount form-control-sm" />
                      </div>
                      <div className="tr-type">
                        <input type="text"
                          //placeholder={"Cr/Dr"}
                          data-eindex={eIndex}
                          data-rindex={rIndex}
                          data-ename={'ref_tr_type'}
                          maxLength="2"
                          value={rItemm.ref_tr_type}
                          className="form-control trans-input tr-type form-control-sm"
                          onFocus={event => this.setCredentialsHandler(event, eIndex, rIndex, null)}
                          onChange={event => this.props.changeHandler(event, `ref_tr_type`, null, eIndex, null, rIndex)}
                          onBlur={event => this.blurHandler(event, `ref_tr_type`, eIndex, rIndex)}
                        />
                      </div>
                    </>
                  }
                </div>
              )
            })}
          </div>
        }
        {/* {eItem.cost_center &&
          <div className="adjestment-head">
            <div className="adjt-head">
              <span className="ref-type">Cost Center</span>
              <span className="ref-name">10</span>
              <span className="tr-amount">10,000</span>
              <span className="tr-type">Cr</span>
            </div>
          </div>
        } */}
      </div>

    )
  }
}
export default withRouter(SingleEntry);
