import { studentsConstants } from '../_constants';
import { studentsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const studentsAction = {
    getStudents,
    create
};

function getStudents() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        studentsService.getStudents()
            .then(
                response => {
                    dispatch(success(response.data.student_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: studentsConstants.STUDENTS_REQUEST } }
    function success(response) { return { type: studentsConstants.STUDENTS_SUCCESS, response } }
    function failure(error) { return { type: studentsConstants.STUDENTS_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        studentsService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.student_arr),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: studentsConstants.CREATE_STUDENTS_REQUEST } }
    function success(response) { return { type: studentsConstants.CREATE_STUDENTS_SUCCESS, response } }
    function failure(error) { return { type: studentsConstants.CREATE_STUDENTS_FAILURE, error } }
}
