import { schoolsConstants } from '../_constants';
import { schoolsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const schoolsAction = {
    getSchools,
    create,
    update,
    delete : _delete
};

function getSchools() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        schoolsService.getSchools()
            .then(
                response => {
                    dispatch(success(response.data.school_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: schoolsConstants.SCHOOLS_REQUEST } }
    function success(response) { return { type: schoolsConstants.SCHOOLS_SUCCESS, response } }
    function failure(error) { return { type: schoolsConstants.SCHOOLS_FAILURE, error } }
}
 
function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        schoolsService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: schoolsConstants.CREATE_SCHOOL_REQUEST } }
    function success(response) { return { type: schoolsConstants.CREATE_SCHOOL_SUCCESS, response } }
    function failure(error) { return { type: schoolsConstants.CREATE_SCHOOL_FAILURE, error } }
}
 
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        schoolsService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: schoolsConstants.UPDATE_SCHOOL_REQUEST } }
    function success(response) { return { type: schoolsConstants.UPDATE_SCHOOL_SUCCESS, response } }
    function failure(error) { return { type: schoolsConstants.UPDATE_SCHOOL_FAILURE, error } }
}
 

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        schoolsService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: schoolsConstants.DELETE_SCHOOL_REQUEST } }
    function success(response) { return { type: schoolsConstants.DELETE_SCHOOL_SUCCESS, response } }
    function failure(error) { return { type: schoolsConstants.DELETE_SCHOOL_FAILURE, error } }
}
 