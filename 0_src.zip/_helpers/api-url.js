// const api_url = "http://localhost/schooloffice/api/";
// const api_url = "http://www.rajpsp.com/api_redux/";
const api_url = "http://schools.rajpsp.com/api/";

export default api_url;