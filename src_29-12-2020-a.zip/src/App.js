import React, { Component } from 'react';
import { Router, Route, Redirect, Switch, withRouter } from 'react-router-dom';
import 'react-picky/dist/picky.css';
import Alert from 'react-s-alert';
// import { connect } from 'react-redux';
import { history } from './_helpers';

// Layouts
import FrontLayoutRoute from "./layouts/FrontLayoutRoute";
import FrontLayoutInnerRoute from "./layouts/FrontLayoutInnerRoute";
import UserLayoutRoute from "./layouts/UserLayoutRoute";
import DashboardLayoutRoute from "./layouts/DashboardLayoutRoute";
// Components

import FrontIndexPage from "./components/front_index_page";
import Mission from "./components/front_mission_page";
import Login from "./components/login";
import Dashboard from "./components/dashboard";
import HolidayCalendar from "./components/holiday_calendar";
/*import PortalStudents from "./components/portal_students";*/
import AllStudents from "./components/all_students";
import AddStudent from "./components/add_student";
import EditStudent from "./components/edit_student";
import StudentProfile from "./components/student_profile";
import AllProfessionals from "./components/all_professionals";
import AssignSubjects from "./components/assign_subjects";
import AddProfessional from "./components/add_professional";
import EditProfessional from "./components/edit_professional";
import ProfessionalProfile from "./components/professional_profile";
import FeesCollection from "./components/fees_collection";
import GetFees from "./components/get_fees";
import AllExamShedules from "./components/all_exam_shedules";
import CreateExamShedule from "./components/create_exam_shedule";
import PrintShedule from "./components/print_shedule";
import SheduleInnings from "./components/shedule_innings";
import SheduleNotes from "./components/shedule_notes";
import AddSheduleNotes from "./components/add_shedule_notes";
import EditSheduleNotes from "./components/edit_shedule_notes";
/*import GetEstimate from "./components/get_estimate";
import NewGetEstimate from "./components/new_get_estimate";*/
import FeesReceipt from "./components/fees_receipt";
import PaymentList from "./components/payment_list";
import AllAccLedger from "./components/all_acc_ledger";
import AllAccGroup from "./components/all_acc_group";
import NewPayment from "./components/new_payment";
import EditPayment from "./components/edit_payment";
import IncomeList from "./components/income_list";
import NewIncome from "./components/new_income";
import EditIncome from "./components/edit_income";
import AllMarks from "./components/all_marks";
import AddMarks from "./components/add_marks";
import ExcelToUpdate from "./components/excel_to_update";
//import UpdateMarks from "./components/update_marks";
import AllExam from "./components/all_exam";
import AddExam from "./components/add_exam";
import EditExam from "./components/edit_exam";
import SubjectMaxMarks from "./components/subject_max_marks";
import ViewMarksStudent from "./components/view_marks_student";
import AddMarksStudent from "./components/add_marks_student";
import GetMarksSheet from "./components/get_marks_sheet";
import VisitSite from "./components/visit_site";
import SelectTemplate from "./components/select_template";
import GroupInfo from "./components/group_info";
import SchoolInfo from "./components/school_info";
import EditGroupInfo from "./components/edit_group_info";
import AllSlider from "./components/all_slider";
import AddSlider from "./components/add_slider";
import EditSlider from "./components/edit_slider";
import AllArticle from "./components/all_article";
import UpdateArticle from "./components/update_article";
import AllEvents from "./components/all_events";
import AddEvent from "./components/add_event";
import EditEvent from "./components/edit_event";
import AllGalleries from "./components/all_galleries";
import AddGallery from "./components/add_gallery";
import EditGallery from "./components/edit_gallery";
import ViewGallery from "./components/view_gallery";
import AllImages from "./components/all_images";
import AddImage from "./components/add_image";
import EditImage from "./components/edit_image";
import AllReview from "./components/all_review";
import AddReview from "./components/add_review";
import AhowReview from "./components/show_review";
import Backup from "./components/backup";
import BalanceSheet from "./components/balance_sheet";
import ProfitAndLoss from "./components/profit_n_loss";
import AccountingVouchers from "./components/accounting_vouchers";
import LedgerMonthlySummary from "./components/ledger_monthly_summary";
import LedgerVouchers from "./components/ledger_vouchers";
import GroupSummary from "./components/group_summary";
import CreateMonthlyDues from "./components/create_monthly_dues";
import AllDuesStatus from "./components/all_dues_status";
import AllGroupStatus from "./components/all_group_status";
import AllLedgerStatus from "./components/all_ledger_status";
import AllCostCenterStatus from "./components/all_cost_center_status";
import AllTypeNTime from "./components/all_type_n_time";
import AddTypeNTime from "./components/add_type_n_time";
import EditTypeNTime from "./components/edit_type_n_time";
import AllFeeStructure from "./components/all_fee_structure";
import AddFeeDetails from "./components/add_fee_structure";
import EditFeeDetails from "./components/edit_fee_structure";
import AllTranspoartRoot from "./components/all_transpoart_root";
import AddTranspoartRoot from "./components/add_transpoart_root";
import EditTranspoartRoot from "./components/edit_transpoart_root";
import AllLesson from "./components/all_lesson";
import AddLesson from "./components/add_lesson";
import EditLesson from "./components/edit_lesson";
import ViewLesson from "./components/view_lesson";
import StudentLesson from "./components/student_lesson";
import LessonFAQs from "./components/lesson_faqs";
import LessonFAQsReply from "./components/lesson_faqs_reply";
import AllETest from "./components/all_e_test";
import AllNewTest from "./components/add_new_test";
import TestAttempt from "./components/test_attempt";
import TestResult from "./components/test_result";
import AllClass from "./components/all_class";
import AddClass from "./components/add_class";
import EditClass from "./components/edit_class";
import AllSubject from "./components/all_subject";
import AddSubject from "./components/add_subject";
import EditSubject from "./components/edit_subject";
import AllUsers from "./components/all_users";
import AddUser from "./components/add_user";
import EditUser from "./components/edit_user";
/*import AllSubjectPart from "./components/all_subject_part";
import AddSubjectPart from "./components/add_subject_part";
import EditSubjectPart from "./components/edit_subject_part";
import AllSubjectPartPart from "./components/all_subject_part_part";
import AddSubjectPartPart from "./components/add_subject_part_part";
import EditSubjectPartPart from "./components/edit_subject_part_part";*/
import UserRoll from "./components/user_roll";
import AddUserRoll from "./components/add_user_roll";
import EditUserRoll from "./components/edit_user_roll";
import UploadStudents from "./components/upload_students";
import UploadStaff from "./components/upload_staff";
import AllSchools from "./components/all_schools";
import AddSchool from "./components/add_school";
import EditSchool from "./components/edit_school";
import CreateSalary from "./components/create_salary";

import NotFound from "./components/not_found";

class App extends Component {

  constructor(props) {
    super(props);
    history.listen((location, action) => {
      // clear alert on location change
      // this.props.clearAlerts();
      // console.log(history);
    //  console.log("inside history listen");
    });
  }
  render() {
    // console.log(this.props);
    return (
      <Router history={history} >
        <Switch>
          <Route exact path={"/"}>
            <Redirect exact to="/Home.jsp" />
          </Route>
          <FrontLayoutRoute exact path="/Home.jsp" component={FrontIndexPage} />
          <FrontLayoutInnerRoute path="/Mission.jsp" component={Mission} />
          <UserLayoutRoute path="/Login.jsp" component={Login} />
          <DashboardLayoutRoute path="/Dashboard.jsp" component={Dashboard} />
          <DashboardLayoutRoute path="/holiday_calendar.jsp" component={HolidayCalendar} />
          {/* <DashboardLayoutRoute path="/portal_students.jsp" component={PortalStudents} /> */}
          <DashboardLayoutRoute path="/all_students.jsp" component={AllStudents} />
          <DashboardLayoutRoute path="/add_student.jsp" component={AddStudent} />
          <DashboardLayoutRoute path="/edit_student.jsp/:id" component={EditStudent} />
          <DashboardLayoutRoute path="/student_profile.jsp/:id" component={StudentProfile} />
          <DashboardLayoutRoute path="/all_professionals.jsp" component={AllProfessionals} />
          <DashboardLayoutRoute path="/assign_subjects.jsp/:id" component={AssignSubjects} />
          <DashboardLayoutRoute path="/add_professional.jsp" component={AddProfessional} />
          <DashboardLayoutRoute path="/edit_professional.jsp/:id" component={EditProfessional} />
          <DashboardLayoutRoute path="/professional_profile.jsp/:id" component={ProfessionalProfile} />
          <DashboardLayoutRoute path="/fees_collection.jsp" component={FeesCollection} />
          <DashboardLayoutRoute path="/get_fees.jsp" component={GetFees} />
          <DashboardLayoutRoute path="/all_exam_shedules.jsp" component={AllExamShedules} />
          <DashboardLayoutRoute path="/create_exam_shedule.jsp" component={CreateExamShedule} />
          <DashboardLayoutRoute path="/print_shedule.jsp" component={PrintShedule} />
          <DashboardLayoutRoute path="/shedule_innings.jsp" component={SheduleInnings} />
          <DashboardLayoutRoute path="/shedule_notes.jsp" component={SheduleNotes} />
          <DashboardLayoutRoute path="/add_shedule_notes.jsp" component={AddSheduleNotes} />
          <DashboardLayoutRoute path="/edit_shedule_notes.jsp/:id" component={EditSheduleNotes} />
          {/*<DashboardLayoutRoute path="/get_estimate.jsp" component={GetEstimate} />
          <DashboardLayoutRoute path="/new_get_estimate.jsp" component={NewGetEstimate} />*/}
          <DashboardLayoutRoute path="/fees_receipt.jsp" component={FeesReceipt} />
          <DashboardLayoutRoute path="/payment_list.jsp" component={PaymentList} />
          <DashboardLayoutRoute path="/all_acc_ledger.jsp" component={AllAccLedger} />
          <DashboardLayoutRoute path="/all_acc_group.jsp" component={AllAccGroup} />
          <DashboardLayoutRoute path="/new_payment.jsp" component={NewPayment} />
          <DashboardLayoutRoute path="/edit_payment.jsp/:id" component={EditPayment} />
          <DashboardLayoutRoute path="/income_list.jsp" component={IncomeList} />
          <DashboardLayoutRoute path="/new_income.jsp" component={NewIncome} />
          <DashboardLayoutRoute path="/edit_income.jsp/:id" component={EditIncome} />
          <DashboardLayoutRoute path="/all_marks.jsp" component={AllMarks} />
          <DashboardLayoutRoute path="/add_marks.jsp" component={AddMarks} />
          <DashboardLayoutRoute path="/excel_to_update.jsp" component={ExcelToUpdate} />
          {/*<DashboardLayoutRoute path="/update_marks.jsp/:id" component={UpdateMarks} />*/}
          <DashboardLayoutRoute path="/all_exam.jsp" component={AllExam} />
          <DashboardLayoutRoute path="/add_exam.jsp" component={AddExam} />
          <DashboardLayoutRoute path="/edit_exam.jsp/:id" component={EditExam} />
          <DashboardLayoutRoute path="/subject_max_marks.jsp" component={SubjectMaxMarks} />
          <DashboardLayoutRoute path="/view_marks_student.jsp/:id/:class_id/" component={ViewMarksStudent} />
          <DashboardLayoutRoute path="/add_marks_student.jsp/:id/:school_id/" component={AddMarksStudent} />
          <DashboardLayoutRoute path="/get_marks_sheet.jsp" component={GetMarksSheet} />
          <DashboardLayoutRoute path="/visit_site.jsp" component={VisitSite} />
          <DashboardLayoutRoute path="/select_template.jsp" component={SelectTemplate} />
          <DashboardLayoutRoute path="/group_info.jsp" component={GroupInfo} />
          <DashboardLayoutRoute path="/school_info.jsp" component={SchoolInfo} />
          <DashboardLayoutRoute path="/edit_group_info.jsp" component={EditGroupInfo} />
          <DashboardLayoutRoute path="/all_slider.jsp" component={AllSlider} />
          <DashboardLayoutRoute path="/add_slider.jsp" component={AddSlider} />
          <DashboardLayoutRoute path="/edit_slider.jsp/:id" component={EditSlider} />
          <DashboardLayoutRoute path="/all_article.jsp" component={AllArticle} />
          <DashboardLayoutRoute path="/update_article.jsp/:id" component={UpdateArticle} />
          <DashboardLayoutRoute path="/all_events.jsp" component={AllEvents} />
          <DashboardLayoutRoute path="/add_event.jsp" component={AddEvent} />
          <DashboardLayoutRoute path="/edit_event.jsp/:id" component={EditEvent} />
          <DashboardLayoutRoute path="/all_galleries.jsp" component={AllGalleries} />
          <DashboardLayoutRoute path="/add_gallery.jsp" component={AddGallery} />
          <DashboardLayoutRoute path="/edit_gallery.jsp/:id" component={EditGallery} />
          <DashboardLayoutRoute path="/view_gallery.jsp/:id" component={ViewGallery} />
          <DashboardLayoutRoute path="/all_images.jsp" component={AllImages} />
          <DashboardLayoutRoute path="/add_image.jsp" component={AddImage} />
          <DashboardLayoutRoute path="/edit_image.jsp/:id" component={EditImage} />
          <DashboardLayoutRoute path="/all_review.jsp" component={AllReview} />
          <DashboardLayoutRoute path="/add_review.jsp" component={AddReview} />
          <DashboardLayoutRoute path="/show_review.jsp" component={AhowReview} />
          <DashboardLayoutRoute path="/backup.jsp" component={Backup} />
          <DashboardLayoutRoute path="/balance_sheet.jsp" component={BalanceSheet} />
          <DashboardLayoutRoute path="/profit_n_loss.jsp" component={ProfitAndLoss} />
          <DashboardLayoutRoute path="/accounting_vouchers.jsp/:id" component={AccountingVouchers} />
          <DashboardLayoutRoute path="/ledger_monthly_summary.jsp/:id" component={LedgerMonthlySummary} />
          <DashboardLayoutRoute path="/ledger_vouchers.jsp/:l_id/:m_id" component={LedgerVouchers} />
          <DashboardLayoutRoute path="/group_summary.jsp/:type/:id/:grp_id?" component={GroupSummary} />
          <DashboardLayoutRoute path="/create_monthly_dues.jsp" component={CreateMonthlyDues} />
          <DashboardLayoutRoute path="/all_dues_status.jsp" component={AllDuesStatus} />
          <DashboardLayoutRoute path="/all_group_status.jsp" component={AllGroupStatus} />
          <DashboardLayoutRoute path="/all_ledger_status.jsp" component={AllLedgerStatus} />
          <DashboardLayoutRoute path="/all_cost_center_status.jsp" component={AllCostCenterStatus} />
          <DashboardLayoutRoute path="/all_type_n_time.jsp" component={AllTypeNTime} />
          <DashboardLayoutRoute path="/add_type_n_time.jsp" component={AddTypeNTime} />
          <DashboardLayoutRoute path="/edit_type_n_time.jsp/:id" component={EditTypeNTime} />
          <DashboardLayoutRoute path="/all_fee_structure.jsp" component={AllFeeStructure} />
          <DashboardLayoutRoute path="/add_fee_structure.jsp" component={AddFeeDetails} />
          <DashboardLayoutRoute path="/edit_fee_structure.jsp/:id" component={EditFeeDetails} />
          <DashboardLayoutRoute path="/all_transpoart_root.jsp" component={AllTranspoartRoot} />
          <DashboardLayoutRoute path="/add_transpoart_root.jsp" component={AddTranspoartRoot} />
          <DashboardLayoutRoute path="/edit_transpoart_root.jsp/:id" component={EditTranspoartRoot} />
          <DashboardLayoutRoute path="/all_lesson.jsp" component={AllLesson} />
          <DashboardLayoutRoute path="/add_lesson.jsp" component={AddLesson} />
          <DashboardLayoutRoute path="/edit_lesson.jsp/:id" component={EditLesson} />
          <DashboardLayoutRoute path="/view_lesson.jsp/:id" component={ViewLesson} />
          <DashboardLayoutRoute path="/student_lesson.jsp/:id" component={StudentLesson} />
          <DashboardLayoutRoute path="/lesson_faqs.jsp/:id" component={LessonFAQs} />
          <DashboardLayoutRoute path="/lesson_faqs_reply.jsp/:id" component={LessonFAQsReply} />
          <DashboardLayoutRoute path="/all_e_test.jsp" component={AllETest} />
          <DashboardLayoutRoute path="/add_new_test.jsp" component={AllNewTest} />
          <DashboardLayoutRoute path="/test_attempt.jsp" component={TestAttempt} />
          <DashboardLayoutRoute path="/test_result.jsp" component={TestResult} />
          <DashboardLayoutRoute path="/all_class.jsp" component={AllClass} />
          <DashboardLayoutRoute path="/add_class.jsp" component={AddClass} />
          <DashboardLayoutRoute path="/edit_class.jsp/:id" component={EditClass} />
          <DashboardLayoutRoute path="/all_subject.jsp" component={AllSubject} />
          <DashboardLayoutRoute path="/add_subject.jsp" component={AddSubject} />
          <DashboardLayoutRoute path="/edit_subject.jsp/:id" component={EditSubject} />
          <DashboardLayoutRoute path="/all_users.jsp" component={AllUsers} />
          <DashboardLayoutRoute path="/add_user.jsp" component={AddUser} />
          <DashboardLayoutRoute path="/edit_user.jsp/:id" component={EditUser} />
          {/*<DashboardLayoutRoute path="/all_subject_part.jsp" component={AllSubjectPart} />
          <DashboardLayoutRoute path="/add_subject_part.jsp" component={AddSubjectPart} />
          <DashboardLayoutRoute path="/edit_subject_part.jsp/:id" component={EditSubjectPart} />
          <DashboardLayoutRoute path="/all_subject_part_part.jsp" component={AllSubjectPartPart} />
          <DashboardLayoutRoute path="/add_subject_part_part.jsp" component={AddSubjectPartPart} />
          <DashboardLayoutRoute path="/edit_subject_part_part.jsp/:id" component={EOditSubjectPartPart} />*/}
          <DashboardLayoutRoute path="/user_roll.jsp" component={UserRoll} />
          <DashboardLayoutRoute path="/add_user_rollv" component={AddUserRoll} />
          <DashboardLayoutRoute path="/edit_user_roll.jsp/:id" component={EditUserRoll} />
          <DashboardLayoutRoute path="/upload_students.jsp" component={UploadStudents} />
          <DashboardLayoutRoute path="/upload_staff.jsp" component={UploadStaff} />
          <DashboardLayoutRoute path="/all_schools.jsp" component={AllSchools} />
          <DashboardLayoutRoute path="/add_school.jsp" component={AddSchool} />
          <DashboardLayoutRoute path="/edit_school.jsp/:id" component={EditSchool} />
          <DashboardLayoutRoute path="/create_salary.jsp" component={CreateSalary} />

          <DashboardLayoutRoute component={NotFound} />
        </Switch>
        <Alert stack={{ limit: 3 }} html={true} />
      </Router>
    );
  }
}

// function mapState(state) {
//   //   const { alert } = state;
//   //  return { alert };
// }

// const actionCreators = {
// 	// clearAlerts: alertActions.clear
// };

// export default withRouter(connect(mapState, actionCreators)(App));
export default withRouter(App);
 
