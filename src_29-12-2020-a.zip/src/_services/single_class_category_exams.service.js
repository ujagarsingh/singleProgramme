// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const singleClassCategoryExamsService = {
    getSingleCCE
};

function getSingleCCE(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam/one_class_category_exams.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

 