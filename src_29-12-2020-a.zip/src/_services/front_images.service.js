// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const frontImagesService = {
    getFrontImages,
    createFrontImages,
    update,
    delete : _delete
};

function getFrontImages() {
    loadProgressBar();
    const url = USER_URL + 'galleries/images/read.php';
    return Axios.post(url, authHeader()).then()
}

function createFrontImages(obj) {
    loadProgressBar();
    const url = USER_URL + 'galleries/images/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'galleries/images/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'galleries/images/delete.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
