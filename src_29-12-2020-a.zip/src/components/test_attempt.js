import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import TestInstructionInfo from './test_instruction_info';
import TestPaper from './test_paper';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class TestAttempt extends Component {
	state = {
		step_first: true,
		step_second: false,
		step_third: false,
		formIsHalfFilledOut: false,
	};
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	changeHandler = (event, fieldName, qIndex, isCheckbox) => {
		if (fieldName === 'question') {
			const _str = event.target.value;
			const _index = qIndex;
			const _questions = this.state.qes_paper;
			const finel_question = _questions.map((item, idx) => {
				if (idx === _index) {
					item.question = _str;
				}
				return item;
			})

			this.setState({
				qes_paper: finel_question,
				formIsHalfFilledOut: true
			});
		} else {
			this.setState({
				[fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
				formIsHalfFilledOut: true
			});
		}
	}

	componentDidMount() {
		const token = sessionStorage.getItem('jwt');
		const obj = { "jwt": token };
		this.checkAuthentication(obj);
	}

	checkAuthentication(obj) {
		loadProgressBar();
		axios.post(VALIDATE_URL, obj)
			.then(res => {
				const getRes = res.data;
				// sessionStorage.setItem("user", getRes.data);
				console.log(getRes);
				if (getRes.data) {
					this.setState({
						user: getRes.data,
						group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
						school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
						user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
						session_year: (getRes.data.session_year) ? getRes.data.session_year : "",
					}, () => {
						// this.getSchoolHandler();
						// this.getExamsCategories();
						// this.getSheduleNotes();
					})
				}
			}).catch((error) => {
				this.props.history.push('/login.jsp');
			})
	}

	getSchoolHandler() {
		loadProgressBar();
		const obj = {
			group_id: this.state.group_id
		}
		axios.post(READ_SCHOOLS, obj)
			.then(res => {
				const getRes = res.data;
				this.setState({
					schools_arr: getRes,
					errorMessages: getRes.message
				});
				// console.log(this.state);
			}).catch((error) => {
				// error
			})
	}

	nextStep = (obj) => {
		this.setState({
			step_first: obj.step_first,
			step_second: obj.step_second,
			step_third: obj.step_third
		})
	}
	prevStep = (obj) => {
		this.setState({
			step_first: obj.step_first,
			step_second: obj.step_second,
			step_third: obj.step_third
		})
	}
	startTest = (obj) => {
		this.setState({
			step_first: obj.step_first,
			step_second: obj.step_second,
			step_third: obj.step_third
		})
	}
	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (
			<div className="page-content">
				<Helmet>
					<title>Test Instructions</title>
				</Helmet>
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				{user &&
					<>
						<div className="page-bar d-flex">
							<div className="page-title">Test Instructions</div>
							<div className="form-inline ml-auto filter-panel">
								<span className="filter-closer">
									<button type="button" className="btn btn-danger filter-toggler-c">
										<i className="fa fa-times"></i>
									</button>
								</span>
							</div>
						</div>

						<div className="card card-box sfpage-cover">
							<div className="card-body sfpage-body">
								<div className="table-scrollable">
									{!step_third ?
										<TestInstructionInfo
											step_first={step_first}
											step_second={step_second}
											nextStep={this.nextStep}
											prevStep={this.prevStep}
											startTest={this.startTest}
										/>
										:
										<TestPaper
											step_first={step_first}
											step_second={step_second}
											nextStep={this.nextStep}
											prevStep={this.prevStep}
											startTest={this.startTest}
										/>
									}
								</div>

							</div>

						</div>
					</>
				}
			</div>
		)
	}
}
export default withRouter(TestAttempt);