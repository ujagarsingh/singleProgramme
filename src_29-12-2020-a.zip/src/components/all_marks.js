import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink, Link } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
  schoolsAction, classesAction, classExamSubjectAction, 
  marksOfaClassAction,
  classStudentExamMobtnAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
// const GET_DETAILD_EXAM = `http://schools.rajpsp.com/api/exam/class_exam_subject.php`;
// const READ_STUDENT_MARKS_DETAIL_URL = `http://schools.rajpsp.com/api/exam/class_exam_subject_student.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;   

class AllMarks extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    classes: [],
    selected_classes: [],
    display_student: '', // student marks obtain detail
    exam_detail: [],
    slct_exam_detail: '',
    class_id: '',
    selected_class: '',
    medium: '',
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: '',
    //   }, () => { this.filterClassesOnSchool(_sch_id, this.props.user.group_id); })
    // } else if (fieldName === 'selected_class') {
    //   const _class_inx = event.target.value;
    //   const _class_name = this.state.selected_classes[_class_inx].stu_class;
    //   const _class_id = this.state.selected_classes[_class_inx].id;
    //   sessionStorage.setItem("stu_class", _class_name);
    //   this.setState({
    //     class_id: _class_id
    //   }, () => {
    //     this.classHandler(_class_inx);
    //     this.getDetaildExamHandler(_class_id);
    //   })
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   sessionStorage.setItem("medium", _medium);
    // } else {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      // formIsHalfFilledOut: true
    });
    // }
  };

  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item, inx) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      selected_class_inx: 'All',
    })
  };
  classHandler(_class_inx) {
    if (_class_inx !== '') {
      const _class_idx = parseInt(_class_inx);
      const _class_id = this.state.selected_classes[_class_idx].id;
      // const _class_name = this.state.selected_classes[_class_idx].stu_class;
      this.setState({
        class_id: _class_id,
        selected_class_inx: _class_inx,
        display_student: ''
      }, () => {
        this.getStudentofClass(_class_id);
      })
    } else {
      this.setState({
        display_student: ''
      })
    }
  }
  getStudentofClass(class_id) {
    const group_id = this.props.user.group_id;

    const _students = this.props.classStudentExamMobtn.filter((item) => {
      if (item.id === class_id) {
        return item
      }
    })

    const _exam_detail = this.state.exam_detail.filter((item) => {
      if (item.id === class_id && item.group_id === group_id) {
        return item
      }
    })
    console.log(_students);
    this.setState({
      // slct_exam_detail: _exam_detail,
      display_student: _students,
      class_id: class_id,
      selected_class: _students[0].stu_class,
    });
  }


  // getStudentofClass(class_id) {
  //   loadProgressBar();
  //   const obj = {
  //     class_id: class_id,
  //     group_id: this.props.user.group_id,
  //     school_id: this.state.school_id,
  //     medium: this.state.medium,
  //   };
  //   console.log(JSON.stringify(obj))
  //   axios.post(READ_STUDENT_MARKS_DETAIL_URL, obj)
  //     .then(res => {
  //       const students = res.data;
  //       // debugger;
  //       this.setState({
  //         display_student: students,
  //         selected_class: students[0].stu_class,
  //         errorMessages: res.data.message
  //       }, () => {
  //         const _exam_detail = this.state.exam_detail.filter((item, index) => {
  //           if (class_id === item.id && this.props.user.group_id === item.group_id) {
  //             return item
  //           }
  //         })
  //         this.setState({
  //           slct_exam_detail: _exam_detail
  //         })
  //       });
  //       //console.log(this.state.display_student);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // }

  getDetaildExamHandler(class_id) {
    const examDetail = this.props.classExamSubject.filter((item) => {
      if (item.id === class_id) {
        return item
      }
    })
    this.setState({
      exam_detail: examDetail,
      slct_exam_detail: examDetail,
    });
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.classExamSubject)) {
      this.props.getClassExamSubject();
    }
    if (isEmptyObj(this.props.classStudentExamMobtn)) {
      this.props.getClassStudentExamMobtn();
    }
    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.classStudentExamMobtn;
      if (_all_student && _filter) {
        this.filterBySchoolHandler();
        this.filterByClsHandler()
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    // because every class has diffrent Exams. (in my case table Header.)
    // const _filter = this.props.filteredSchoolData;
    // const _all_student = this.props.classStudentExamMobtn;
    // if (!isEmpty(_all_student)) {
    //   const _school_student = _all_student.filter((item) => {
    //     if (_filter.slct_school_id) {
    //       if (item.school_id === _filter.slct_school_id) {
    //         return item
    //       }
    //     } else {
    //       return item
    //     }
    //   })
    //   this.setState({
    //     display_student: _school_student,
    //   }, () => this.filterByClsHandler())
    // }
    this.filterByClsHandler()
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.classStudentExamMobtn;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      this.setState({
        display_student: _school_student
      }, () => {
         this.getDetaildExamHandler(_fltr_class.slct_cls_id)
        // this.props.getMarksOfaClass({ class_id: _fltr_class.slct_cls_id });
      })
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           // this.getSubjectsHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.props.user.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getClassesHandler() {
  //   loadProgressBar();
  //   // read all existing class
  //   const obj = {
  //     group_id: this.props.user.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       const _classes = classes.filter((item, index) => {
  //         if (item.is_section !== 'Yes') {
  //           return item;
  //         }
  //       })
  //       if (this.state.user_category === "1") {
  //         this.setState({
  //           classes: _classes,
  //           errorMessages: res.data.message
  //         });
  //       } else {
  //         this.setState({
  //           classes: _classes,
  //           selected_class: _classes,
  //           errorMessages: res.data.message
  //         });
  //       }
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };

  render() {
    const { medium, selected_classes, slct_exam_detail, display_student, selected_class_inx,
      selected_school_index, medium_arr } = this.state;
    const { user, schools, classes, classExamSubject, classStudentExamMobtn } = this.props;
    console.log(this.props)
    return (
      <div className="page-content">
        <Helmet>
          <title>All Marks</title>
        </Helmet>
        {user && schools && classes && classExamSubject && classStudentExamMobtn && 
          <>
            <div className="page-bar d-flex">
              <div className="page-title">All Marks</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>

                <div className="filter-con">
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                    filterByClsHandler={this.filterByClsHandler}
                  />
                  {/* <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mt-1"> 
                    <label className="mr-2">Class:</label>
                    <select
                      value={selected_class_inx}
                      // disabled={medium === '' ? true : false}
                      className="form-control form-control-sm" name="selected_class"
                      onChange={event => this.changeHandler(event, 'selected_class')} >
                      <option value="All">Select...</option>
                      {selected_classes.map((option, index) => {
                        return (<option key={index} value={index}>{option.class_name}</option>)
                      })}
                    </select>
                  </div>
                  */}
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                <div className="table-scrollable">
                  <table className="table table-sm table-striped table-bordered marks-table">
                    <thead>
                      <tr>
                        <th />
                        <th> Roll No </th>
                        <th> Admi. No </th>
                        <th> Student's and Father's Name  </th>
                        {(slct_exam_detail.length > 0) ? slct_exam_detail[0].exams.map((item, index) => {
                          return (
                            <th width="200" className="text-center" key={index}>
                              <strong>{item.exam_name}</strong>
                              <table className="table m-0 tbl_head_1">
                                <tbody>
                                  <tr >
                                    {(item.subject.length > 0) ? item.subject.map((item_s, idx) => {
                                      return (
                                        <td key={idx} className="p-1">
                                          {(item_s.sub_lavel === '1') ?
                                            /*<NavLink
                                              to={`update_marks.jsp/${slct_exam_detail[0].id}-${item.id}-${item_s.id}`}
                                            className="btn p-1 btn-link">{item_s.sub_name}</NavLink>*/
                                            <span>{item_s.sub_name}</span>
                                            : <span>{item_s.sub_name}</span>
                                          }
                                          {(item_s.subject_sec.length > 0) ?
                                            <table className="table m-0 tbl_head_2">
                                              <tbody>
                                                <tr>
                                                  {item_s.subject_sec.map((item_x, ids) => {
                                                    return (
                                                      <td key={ids} className="p-0">
                                                        {/*<NavLink
                                                      className="btn p-1 btn-link ids_class_exam_sub"
                                                      to={`update_marks.jsp/${slct_exam_detail[0].id}-${item.id}-${item_x.id}`}>
                                                      {item_x.sub_name}
                                                    </NavLink>
                                                    */}
                                                        {item_x.sub_name}
                                                      </td>
                                                    )
                                                  })}
                                                </tr>
                                              </tbody>
                                            </table> : null}
                                        </td>
                                      )
                                    })
                                      : null}
                                  </tr>
                                </tbody>
                              </table>
                            </th>
                          )
                        })
                          : null}
                        <th> Action </th>
                      </tr>
                    </thead>
                    <tbody>
                      {(display_student.length > 0) ? display_student[0].student.map((item, index) => {
                        return (
                          <tr key={index} >
                            <td className="profile-pic">
                              {item.student_image !== '' ?
                                < img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
                                : (item.gender === 'Boy' ?
                                  <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                  :
                                  <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                              }
                            </td>
                            <td>{item.roll_number}</td>
                            <td>{item.admission_number}</td>
                            <td className="left">
                             <Link to={`view_marks_student.jsp/${item.id}/${item.class_id}`}>
                                <strong>{item.student_name} </strong> </Link>
                                S/o <br />
                              {item.father_name}
                            </td>

                            {(item.exams.length > 0) ? item.exams.map((item_s, idx) => {
                              return (
                                <td key={idx} className="p-0 text-center" data-sec={item_s.exam_name}>
                                  <table className="table  m-0 tbl_lavel_1">
                                    <tbody>
                                      <tr>
                                        {(item_s.subject.length > 0) ? item_s.subject.map((item_sub, inx) => {
                                          return (
                                            <td width={(item_sub.sub_lavel === '1' ? 60 : 120)} className="p-0" key={inx}>
                                              <table className="table  m-0 tbl_lavel_2 text-nowrap">
                                                <tbody>
                                                  <tr data-sec={item_sub.sub_name}>
                                                    {(item_sub.sub_lavel === '1' ?
                                                      <td height="30" width="60" className={item_sub.marks_obtain === '' ? 'table-warning' : ''}>
                                                        <b>{item_sub.marks_obtain}</b>
                                                      /
                                                      {item_sub.max_marks}
                                                      </td>
                                                      :
                                                      <td width="120" className="p-0">
                                                        <table className="table  m-0 tbl_lavel_3">
                                                          <tbody>
                                                            <tr>
                                                              {(item_sub.subject_sec.length > 0) ?
                                                                item_sub.subject_sec.map((item_sec, iex) => {
                                                                  return (
                                                                    <td width="60" height="30" key={iex} className="" data-sec={item_sec.sub_name}>
                                                                      <b>{item_sec.marks_obtain}</b>
                                                                   /
                                                                      {item_sec.max_marks}
                                                                    </td>
                                                                  )
                                                                })
                                                                :
                                                                <td ></td>
                                                              }
                                                            </tr>
                                                          </tbody>
                                                        </table>
                                                      </td>
                                                    )}
                                                  </tr>
                                                </tbody>
                                              </table>
                                            </td>
                                          )
                                        })
                                          : <td ></td>}
                                      </tr>
                                    </tbody>
                                  </table>
                                </td>
                              )
                            })
                              : <td ></td>
                            }
                            <td>
                              <NavLink to={`add_marks_student.jsp/${item.id}/${item.school_id}`} className="btn btn-primary btn-sm">
                                Add/Edit
                              </NavLink>
                            </td>
                          </tr>
                        )
                      })
                        : null}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: classExamSubject } = state.classExamSubject;
  const { item: classStudentExamMobtn } = state.classStudentExamMobtn;
  const { item: marksOfaClass } = state.marksOfaClass;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, classes, classExamSubject, classStudentExamMobtn, marksOfaClass,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getClassExamSubject: classExamSubjectAction.getClassExamSubject,
  getClassStudentExamMobtn: classStudentExamMobtnAction.getClassStudentExamMobtn,
  // getMarksOfaClass: marksOfaClassAction.getMarksOfaClass
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllMarks));