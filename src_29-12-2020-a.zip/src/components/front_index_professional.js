import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultProfessionalActions } from '../_actions';


class FrontIndexProfessional extends Component {
   state = {
      formIsHalfFilledOut: false,
   }
   componentDidMount() {
      if (isEmptyObj(this.props.defaultProfessional)) {
         this.props.getDefaultProfessional();
      }
   };

   render() {
      const { defaultProfessional } = this.props;
      return (
         <section className="prof_area sec_panel bg-yellow">
            <div className="sec_inner">
               <div className="container">
                  <div className="section_header prof_header">
                     <h2>Our Pofessional</h2>
                  </div>
                  {defaultProfessional &&
                     <div className="row">
                        { defaultProfessional.map((item, index) => {
                           return (
                              <div key={index} className="col-sm-6 col-md-3">
                                 <div className="box_body mb-3">
                                    {item.profile_image !== '' ?
                                       < img src={`${process.env.PUBLIC_URL}` + item.profile_image} className="img-responsive" alt={item.emp_name} />
                                       : (item.gender === 'Male' ?
                                          <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="img-responsive" />
                                          :
                                          <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_female.jpg`} className="img-responsive" />)
                                    }
                                    <div className="prof_info">
                                       <h4>{item.emp_name}</h4>
                                       <span>{item.emp_crnt_designation}</span>
                                    </div>
                                 </div>
                              </div>

                           )
                        })}
                     </div>
                  }
               </div>
            </div>
         </section>
      )
   }
}

function mapStateToProps(state) {
   const { item: defaultProfessional } = state.defaultProfessional;
   return { defaultProfessional };
}

const actionCreators = {
   getDefaultProfessional: defaultProfessionalActions.getDefaultProfessional,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexProfessional));
