import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { paymentReceiverAction, accGroupActions, schoolsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import NewPayment from './new_payment';
import EditPayment from './edit_payment';

class PaymentList extends Component {
  state = {
    receivers: [],
    id: "",
    party_name: "",
    dr_amo: "",
    transaction_date: "",
    receiver_id: "",
    description: "",
    createItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {

    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

    if (isEmptyObj(this.props.paymentReceiver)) {
      this.props.getPaymentReceiver();
    }

    if (isEmptyObj(this.props.incomeExpenditure)) {
      this.props.getIncomeExpenditure();
    }
  }


  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _s_item = this.props.incomeExpenditure.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      editItem: true,
      createItem: false,
      selected_item: { ..._s_item[0], 'transaction_date': new Date(_s_item[0].transaction_date) }
    })
  }

  closeEdit = (event) => {
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  deleteHandlar = (id) => {
    const obj = { id: id };
    this.props.deleteIncomeExpenditure(obj);
  }

  updateHandlar = (obj) => {
    // console.log(JSON.stringify(obj));
    this.props.updateIncomeExpenditure(obj);
  }


  render() {
    const { formIsHalfFilledOut, createItem, editItem, selected_item } = this.state;
    const { user, paymentReceiver, incomeExpenditure, schools } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Payment List</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">

            {createItem ? <NewPayment
              toggeleCreate={this.toggeleCreate} />
              : null}
            {editItem ? <EditPayment
              selected_item={selected_item}
              schools={schools}
              user={user}
              updateHandlar={this.updateHandlar}
              openEdit={this.openEdit}
              closeEdit={this.closeEdit}
            />
              : null}
            {incomeExpenditure &&
              <div className="table-scrollable">
                <table className="table table-striped table-bordered table-hover table-sm">
                  <thead>
                    <tr>
                      <th className="center"> </th>
                      <th className=" "> Name </th>
                      <th className="text-right"> Amount </th>
                      <th className="text-right"> Balance </th>
                      <th className="center"> Date (YYYY-MM-DD)</th>
                      <th className="center"> Discription </th>
                      <th className="center"> Action </th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                      incomeExpenditure.map((item, index) => {

                        return (
                          <>
                            {(item.dr_amo > 0) ?
                              <tr key={index}>
                                <td className="center">{index + 1}</td>
                                <td className=" ">{item.party_name}</td>
                                <td className="text-right">{item.dr_amo}</td>
                                <td className="text-right">{item.balance}</td>
                                <td className="center">{item.transaction_date}</td>
                                <td className="">{item.description}</td>
                                <td className="d-flex">
                                  <button className="btn btn-primary btn-sm mr-1"
                                    item={item.id}
                                    type="button"
                                    onClick={event => this.openEdit(event, item.id)}>Edit</button>
                                  <button className="btn btn-danger btn-sm"
                                    onClick={event => this.confirmBoxDelete(event, item.id)}>
                                    Del</button>
                                </td>
                              </tr>
                              : null}
                          </>
                        )

                      })
                    }
                  </tbody>
                </table>
              </div>
            }
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">Cancel</button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">Add New</button>
            }
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: paymentReceiver } = state.paymentReceiver;
  const { item: incomeExpenditure } = state.incomeExpenditure;
  const { item: schools } = state.schools;
  return { user, paymentReceiver, incomeExpenditure, schools };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getPaymentReceiver: paymentReceiverAction.getPaymentReceiver,
  getAccGroup: accGroupActions.getAccGroup,

}

export default connect(mapStateToProps, actionCreators)(withRouter(PaymentList));
