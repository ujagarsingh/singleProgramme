import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import axios from 'axios';
import Alert from 'react-s-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { classesAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`; 
const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`; 
const READ_URL = `http://schools.rajpsp.com/api/subject/read_class_subjects.php`;
const CREATE_SUBJECT = `http://schools.rajpsp.com/api/subject/create.php`; 
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_class_subjects.php`;

class EditSubject extends Component {
  state = {
    classes: [],
    class_id: 0,
    selected_class: '',
    existsubject: [{ sub_name: "" }],
    subjectnames: [{ sub_name: "" }],
    formIsHalfFilledOut: false,
  }
  handleSubjecrTitleChange = index => evt => {
    const newClsname = this.state.subjectnames.map((item, sidx) => {
      if (index !== sidx) return item;
      return { ...item, sub_name: evt.target.value };
    });

    this.setState({ subjectnames: newClsname });
  };
  handleEditSubject = () => {
    this.setState({
      subjectnames: this.state.subjectnames.concat([{ sub_name: "" }])
    });
  };
  handleRemoveSubject = index => () => {
    if (this.state.subjectnames.length > 1) {
      this.setState({
        subjectnames: this.state.subjectnames.filter((s, sidx) => index !== sidx)
      })
    }
  };
  getSectedClassHandler = (event) => {
    const _class_id = event.target.value;
    this.subjectsClasswise(_class_id);
  }
  // get subjects according to class
  subjectsClasswise = (_class_id) => {
    this.setState({
      class_id: _class_id,
      existsubject: '',
    }, () => {
      loadProgressBar();
      axios.get(READ_SUBJECTS + `?id=` + _class_id)
        .then(res => {
          const getRes = res.data;
          (getRes.message === undefined) ?
            this.setState({
              existsubject: getRes,
              subjectnames: getRes,
            }) :
            this.setState({
              errorMessages: getRes.message,
              subjectnames: [{ sub_name: "" }]
            })
          ////console.log(this.state.classes);
        }).catch((error) => {
          // error
        })
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getAllClassesHandler();
            this.getExistingSubjectHandler();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }

  getAllClassesHandler() {
    // read all existing classes
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
    }
    axios.post(GET_CLASSES, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          classes: getRes,
          errorMessages: getRes.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  };

  getExistingSubjectHandler() {
    // read all selected class subject(s)
    // we are giver there class id not subject id
    loadProgressBar();
    const { match } = this.props;
    axios.get(READ_URL + '?id=' + match.params.id)
      .then(res => {
        const subjects = res.data;
        this.setState({
          existsubject: subjects,
          selected_class: match.params.id,
          errorMessages: subjects.message
        }, () => {
          this.subjectsClasswise(match.params.id);
        });
        //console.log(this.state.existsubject);
      }).catch((error) => {
        // error
      })
  }
  submitHandler = e => {
    loadProgressBar();
    const _state = this.state;
    e.preventDefault();
    const _subject = _state.subjectnames.filter((item, index) => {
      return item.sub_name.length > 0
    })
    const obj = {
      class_id: _state.class_id,
      sub_name: _subject
    };
    //console.log(JSON.stringify(obj));
    axios.post(CREATE_SUBJECT, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          class_id: 0,
          subjectnames: [{ sub_name: "" }]
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  };
  render() {
    const { formIsHalfFilledOut, selected_class, classes, subjectnames } = this.state;
    //console.log(_state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Student</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Add Subject</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body">
            <div className="table-scrollable">
              <div className="col-md-12 col-sm-12">
                <div className="card card-box sfpage-cover">
                  <div className="card-body sfpage-body">
                    <form className="form-horizontal" onSubmit={this.submitHandler}>
                      <div className="form-body">
                        <div className="form-group row">
                          <label className="control-label col-md-3">Class
                        <span className="required"> * </span>
                          </label>
                          <div className="col-md-5">
                            <select className="form-control form-control-sm" name="select"
                              value={selected_class}
                              onChange={this.getSectedClassHandler}>
                              <option value="">Select...</option>
                              {classes.map((option, index) => {
                                return (
                                  <option key={index}
                                    value={option.id}>
                                    {option.class_name} [{option.class_name_portal}]
                                  </option>
                                )
                              })}
                            </select>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-3">Subject Name
                        <span className="required"> * </span>
                          </label>
                          <div className="col-md-5">
                            {(subjectnames.length > 0) ? subjectnames.map((item, index) => (
                              <div className="form-group" key={index}>
                                <div className="form-group mt-1">
                                  <div className="input-group mb-3">
                                    <div className="input-group-prepend">
                                      <button
                                        type="button"
                                        className="btn btn-danger"
                                        onClick={this.handleRemoveSubject(index)} >
                                        <i className="fa fa-minus"></i>
                                      </button>
                                    </div>
                                    <input
                                      type="text"
                                      className="form-control form-control-sm"
                                      placeholder={`#${index + 1} Subject Name`}
                                      value={item.sub_name}
                                      onChange={this.handleSubjecrTitleChange(index)}
                                    />
                                    <div className="input-group-append">
                                      <button
                                        type="button"
                                        className="btn btn-info"
                                        onClick={this.handleEditSubject}
                                      >
                                        <i className="fa fa-plus"></i>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )) : null}
                          </div>
                        </div>
                        <div className="form-actions  text-right">
                          <div className="row">
                            <div className="offset-md-3 col-md-9">
                              <button type="submit" className="btn btn-primary mr-2">Submit</button>
                              <NavLink to="/all_subject.jsp" className="btn btn-danger">Cancel</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: classes } = state.classes;
  return { user, classes };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
  
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditSubject));