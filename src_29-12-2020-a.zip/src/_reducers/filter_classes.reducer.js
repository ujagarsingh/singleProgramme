import { filterConstants } from '../_constants';

const initialState = {
  slct_cls_index: '',
  slct_cls_id: '',
  slct_cls: '',
  slct_cls_name: ''
}

export function filteredClassesData(state = initialState, action) {
  switch (action.type) {

    case filterConstants.FILTER_CLASSES_REQUEST:
      let _obj = action.obj;
      if (_obj.index === "") {
        return initialState;
      } else {
        const _slct_class = _obj.classes.filter((item, index) => {
          if (index == _obj.index) {
            return item;
          }
        })
        // console.log(_slct_class);
        return {
          ...state,
          slct_cls_index: _obj.index,
          slct_cls_id: _slct_class[0]['id'],
          slct_cls: _slct_class[0],
          slct_cls_name: _slct_class[0]['class_name_portal'],
        };
      }
    default:
      return state
  }
}