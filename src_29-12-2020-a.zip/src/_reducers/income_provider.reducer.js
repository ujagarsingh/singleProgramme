import { incomeProviderConstants } from '../_constants';

export function incomeProvider(state = {}, action) {
  switch (action.type) {
    case incomeProviderConstants.INCOME_PROVIDER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case incomeProviderConstants.INCOME_PROVIDER_SUCCESS:
      return {
        item: action.response
      };
    case incomeProviderConstants.INCOME_PROVIDER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}