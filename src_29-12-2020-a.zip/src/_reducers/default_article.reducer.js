import { defaultArticleConstants } from '../_constants';

export function defaultArticle(state = {}, action) {
  switch (action.type) {
    case defaultArticleConstants.ARTICLE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultArticleConstants.ARTICLE_SUCCESS:
      return {
        item: action.response
      };
    case defaultArticleConstants.ARTICLE_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}