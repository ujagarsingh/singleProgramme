import { defaultSchoolConstants } from '../_constants';

export function defaultSchool(state = {}, action) {
  switch (action.type) {
    case defaultSchoolConstants.SCHOOLS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultSchoolConstants.SCHOOLS_SUCCESS:
      return {
        item: action.response
      };
    case defaultSchoolConstants.SCHOOLS_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}