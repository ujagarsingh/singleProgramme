import React, { Component } from "react";
import ReactDOM from "react-dom";
import VirtualScroller from "./VirtualScroller";
import "./style.css";

const SETTINGS = {
  itemHeight: 20,
  amount: 20,
  tolerance: 5,
  minIndex: 0,
  maxIndex: 999,
  startIndex: 1
};
const scrollEffect = ()=>{
  var isSyncingLeftScroll = false;
  var isSyncingRightScroll = false;
  var leftDiv = document.getElementById('gridHeader');
  var rightDiv = document.getElementById('gridBody');
// debugger
  leftDiv.onscroll = function() {
    if (!isSyncingLeftScroll) {
      isSyncingRightScroll = true;
      rightDiv.scrollLeft = this.scrollLeft;
    }
    isSyncingLeftScroll = false;
  }

  rightDiv.onscroll = function() {
    if (!isSyncingRightScroll) {
      isSyncingLeftScroll = true;
      leftDiv.scrollLeft = this.scrollLeft;
    }
    isSyncingRightScroll = false;
  }
}
setTimeout(()=>{
  scrollEffect();
},1000)

const getData = (offset, limit, rows, heading) => {
  const data = [];
  const start = Math.max(SETTINGS.minIndex, offset);
  const end = Math.min(offset + limit - 1, SETTINGS.maxIndex);
  // console.log(
  //   `request [${offset}..${offset + limit - 1}] -> [${start}..${end}] items`
  // );
  
  // console.log(rows);
  if (start <= end) {
    for (let i = start; i <= end; i++) {
      const _rows = rows.filter((item, index)=>{
        if(index === i){
          return item
        }
      })
      // data.push({ index: i, text: `item ${i}` });
      // data.push({index: i, text: `item ${i}`, row_data : _rows[0], config : heading});
      data.push({index: i, row_data : _rows[0], config : heading});
    }
  }
  
  //console.log(data)
  return data;
  
  // const _rows = rows.filter((item, index)=>{
  //   if(index >= start && index <= end ){
  //     return item
  //   }
  // })
  // return _rows;
};
const manageCellTemplate = (item, index, data, last_left) =>{
  // console.log(data.row_data); // Row Data
   // console.log(item); // heading Data
   let _elem = null;

   if(item.hasOwnProperty("frozen")){
    const row_style = {left:last_left+'px', width:item.width+'px', borderColor:"periwinkle"  }
    _elem = <div key={index} 
                style={row_style}>
                {data.row_data[item.key]}
            </div>;
  } else  {
    const row_style =  {left:last_left+'px', width:item.width+'px', borderColor:"beige" }
    _elem = <div key={index} 
                style={row_style}>
                {data.row_data[item.key]}
            </div>;
  }
  return _elem
}
const manageRowTemplate = (data) => {
  // data.config      // heading
  // data.row_data    // details
  


  let final_row = [];
  let last_left_fr = 0;
  let last_left_nl = 0;
  
  data.config.forEach((item)=>{
    if(item.hasOwnProperty("frozen")){
      last_left_nl += item.width;
    }
  })
  
  data.config.map((item, index)=>{
    if(item.hasOwnProperty("frozen")){
      final_row.push(manageCellTemplate(item, index, data, last_left_fr ));
      last_left_fr += item.width;
    } else {
      final_row.push(manageCellTemplate(item, index, data, last_left_nl ));
      last_left_nl += item.width;
    }
  })
  
  return final_row;
}
const rowTemplate = item => (
  <div className="item" key={item.index}>
    { manageRowTemplate(item) }
  </div>
);

const AppComponent = (props) => (
  <VirtualScroller
    rows={props.rows}
    columns={props.columns}
    className="viewport"
    get={getData}
    settings={SETTINGS}
    row={rowTemplate}
  />
);

export default AppComponent;
// ReactDOM.render(<AppComponent />, document.querySelector("#root"));
