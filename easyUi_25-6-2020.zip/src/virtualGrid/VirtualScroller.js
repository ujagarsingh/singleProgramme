import React, { Component } from "react";

const setInitialState = settings => {
  const {
    itemHeight,
    amount,
    tolerance,
    minIndex,
    maxIndex,
    startIndex
  } = settings;

  const viewportHeight = amount * itemHeight;
  const totalHeight = (maxIndex - minIndex + 1) * itemHeight;
  const toleranceHeight = tolerance * itemHeight;
  const bufferHeight = viewportHeight + 2 * toleranceHeight;
  const bufferedItems = amount + 2 * tolerance;
  const itemsAbove = startIndex - tolerance - minIndex;
  const topPaddingHeight = itemsAbove * itemHeight;
  const bottomPaddingHeight = totalHeight - topPaddingHeight;
  const initialPosition = topPaddingHeight + toleranceHeight;

  return {
    settings,
    viewportHeight,
    totalHeight,
    toleranceHeight,
    bufferHeight,
    bufferedItems,
    topPaddingHeight,
    bottomPaddingHeight,
    initialPosition,
    data: []
  };
};

class Scroller extends Component {
  constructor(props) {
    super(props);
    this.state = setInitialState(props.settings);
    this.viewportElement = React.createRef();
    // console.log(this.state);
  }

  componentDidMount() {
    this.viewportElement.current.scrollTop = this.state.initialPosition;
    if (!this.state.initialPosition) {
      this.runScroller({ target: { scrollTop: 0 } });
    }
  }

  runScroller = ({ target: { scrollTop } }) => {
    const {
      totalHeight,
      toleranceHeight,
      bufferedItems,
      settings: { itemHeight, minIndex }
    } = this.state;

    const index = minIndex + Math.floor((scrollTop - toleranceHeight) / itemHeight);
    const data = this.props.get(index, bufferedItems, this.props.rows, this.props.columns );
    const topPaddingHeight = Math.max((index - minIndex) * itemHeight, 0);
    const bottomPaddingHeight = Math.max(
      totalHeight - topPaddingHeight - data.length * itemHeight,
      0
    );

    this.setState({
      topPaddingHeight,
      bottomPaddingHeight,
      data
    });
  };

  render() {
    const {
      viewportHeight,
      topPaddingHeight,
      bottomPaddingHeight,
      data
    } = this.state;
    // const {
    //   rows,
    //   column
    // } = this.props;
    // console.log(this.props)
    return (
      <div id="gridCover">
    
       <div
       id="gridBody" 
         className="viewport"
         ref={this.viewportElement}
         onScroll={this.runScroller}
         style={{ height: viewportHeight }}>
         <div style={{ height: topPaddingHeight }} />
           {data.map(this.props.row)}
           {/* {data.map(rows)} */}
         <div style={{ height: bottomPaddingHeight }} />
       </div>
       </div>
    );
  }
}

export default Scroller;
