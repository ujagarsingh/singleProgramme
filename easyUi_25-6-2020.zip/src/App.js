import React from 'react';
import './App.css';
import AppGrid from "./myDataGrid";
import AssignSubjects from "./assign_sub"

function App() {
  return (
    <div className="App">
	  <AppGrid />
	  {/* <hr/>
	  <AssignSubjects/> */}
    </div>
  );
}

export default App;
