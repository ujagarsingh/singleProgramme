import React, { Component } from "react";
import axios from 'axios';
import  AlphaDataGrid  from "./alphaDataGrid";
import './alphaTable.css';
class AppGrid extends Component {
  constructor(props) {
    super(props);
    this.state = { };
  }

  componentDidMount(){
    axios.get(`https://jsonplaceholder.typicode.com/users`)
    .then(res => {
      const persons = res.data;
      const _persons = persons.map((item)=>{
        item = {...item, address:"", company : ""};
        return item;
      })
      // const colKeys = this.getKeys(persons[0]);
      const colKeys = [
          {
            key: "id",
            name: "ID",
            width : 50,
            frozen: true,
          },
          {
            key: "name",
            name: "Name",
            width : 180,
            resizable: true,
            frozen: true,
          },
          {
            key: "username",
            name: "User Name",
            width : 520,
          },
          {
            key: "email",
            name: "Email",
            width : 550,
          },
          {
            key: "address",
            name: "Client Address",
            width : 500
          },
          {
            key: "phone",
            name: "Telephone",
            width : 550
          },
          {
            key: "website",
            name: "Website",
            width : 250
          },
          {
            key: "company",
            name: "Company",
            width : 200
          } 
      ];
      const rows = [
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
        ..._persons, ..._persons, ..._persons, ..._persons, ..._persons,
      ];
      
      const finalrow = rows.map((item, inx)=>{
        return item = {...item, id : inx+1, rowinx : inx}
      })

      this.setState({ 
        columns : colKeys,
        rows : finalrow
      });
    })
  }

  getKeys(data){
    let header = [];
    const all_keys = Object.keys(data);
    all_keys.map((item)=>{
      header.push({"name" : item.toUpperCase()})
    })
    return header;
  }

  render() {
    const {rows, columns} = this.state;
    return (
      <div className="myGrid">
        <AlphaDataGrid
          columns={columns}
          rows={rows}
        />
      </div>
    );
  }
}
export default AppGrid;