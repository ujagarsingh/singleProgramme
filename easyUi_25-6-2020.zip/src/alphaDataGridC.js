import React, { Component } from "react";
import AlphaDataHeader  from "./alphaDataHeader";
import AlphaDataFooter  from "./alphaDataFooter";
import AlphaDataBody  from "./alphaDataBody";
import './alphaTable.css';
let _rowCounter = 0;
let _lastScroll = 0;
class AlphaDataGrid extends Component {
  state = {
    displayRow : [],
    lastScrollTop:0,
    transform : '',
    transform_left : 0,
    myRequestedRefs : [],
    scrollCounterTop : 0,
  }
componentDidMount() {
    window.addEventListener('scroll', this.handleScrollTop);
    window.addEventListener('scroll', this.handleScrollLeft);

    window.addEventListener('scroll', e => this.handleNavigation(e));
    this.setState({
      prev : window.scrollY
    })
    setTimeout(() => {
      this.displayFilteredRows(0, 15);
    }, 1000);
    
};

componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScrollTop);
    window.removeEventListener('scroll', this.handleScrollLeft);
};

displayFilteredRows(startRow, endRow, counter){
  const realrows = this.props.rows;    
  const _filteredRow = realrows.filter((item, index)=>{
    if(index >= startRow && index <= endRow){
      return item;
    }
  })
  this.setState({
    displayRow : _filteredRow
  })
}
 


handleScrollTop = (event) => {
  event.preventDefault();

    // let scrollTop = event.srcElement.body.scrollTop;
    let scrollTop = event.currentTarget.scrollTop;
    // console.log(scrollTop);
    
    /* common start */
    let default_rows = 10;
    let row_height = 50;
    let afterChange = 4; // Rows Scroll after Change
    if(scrollTop > _lastScroll){
      this.newGridData(scrollTop, default_rows, row_height, afterChange, "DOWN")
    } else {
      this.newGridData(scrollTop, default_rows, row_height, afterChange, "UP")
    }
    _lastScroll = scrollTop;
  };

newGridData = (scrollTop, default_rows, row_height, afterChange, key) => {
  const _startPoint = scrollTop;
  const _endPoint  = scrollTop + (default_rows * row_height);
  const _topRow = Math.round(_startPoint/row_height);
  const _bottomRow = Math.round(_endPoint/row_height);

  if(key === "DOWN" && ( scrollTop >= _rowCounter + (row_height * afterChange))){
      // console.log(Math.round(_startPoint/row_height));
      // console.log(Math.round(_endPoint/row_height));
      this.displayFilteredRows(_topRow, _bottomRow, afterChange);
      _rowCounter += (row_height * afterChange);
  } else if(key === "UP" && (scrollTop <= (_rowCounter - (row_height * afterChange))) ) {
      // console.log(Math.round(_startPoint/row_height));
      // console.log(Math.round(_endPoint/row_height));
      this.displayFilteredRows(_topRow, _bottomRow, afterChange);
      _rowCounter -= (row_height * afterChange);
  } 
}


displayGridObj(startIndex, stopIndex){
  const _columms = this.state.columns;
  const _final_obj = _columms.filter((item)=>{
    if(item.rowInx <= startIndex && item.rowInx >= startIndex){
      return item
    }
  })
  console.log(_final_obj)
}

handleScrollLeft=(event)=>{
    event.preventDefault();
    let scrollLeftAmo = event.currentTarget.scrollLeft;
    // let itemTranslate = Math.min(0, scrollLeft/3 - 60);
    this.state.myRequestedRefs[0].scrollLeft = scrollLeftAmo;
    this.state.myRequestedRefs[1].scrollLeft = scrollLeftAmo;
    // this.state.myRequestedRefs.scrollLeft = scrollLeftAmo
    
};


  getRefsFromChild = (childRefs) => {
    // console.log(childRefs);
    // debugger
    setTimeout(() => {
      let oldRefs = this.state.myRequestedRefs;
      this.setState({
        myRequestedRefs : [...oldRefs, childRefs]
      });
    }, 100);

  } 

  render() {
    const {rows, columns} = this.props;
    const {displayRow} = this.state;
     // console.log(this.state)
    return (
      <div>
        { rows && columns &&
          <div className="tbl_alpha">
            <AlphaDataHeader 
            passRefHeader={this.getRefsFromChild}
            columns={columns}/>
            <AlphaDataBody 
              passRefUpward={this.getRefsFromChild}
              rows={displayRow}
              totalRows={rows}
              columns={columns}
              transform_left={this.state.transform_left}
              handleScrollTop={this.handleScrollTop}
            />
            <AlphaDataFooter 
              columns={columns}
              handleScrollLeft={this.handleScrollLeft}
            />
          </div>
        }
      </div>
    );
  }

}
export default AlphaDataGrid;