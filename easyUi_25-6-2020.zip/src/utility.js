const fullWidth = function(columns){
    let final_width = 0;
    columns.map((item)=>{
      final_width += item.width;
    })
    return final_width;
  }

 const fullHeight = function(rows){
    let _finalHeidht = 0;
    _finalHeidht = rows.length * 50;
    return _finalHeidht;
  }

export {fullHeight, fullWidth};