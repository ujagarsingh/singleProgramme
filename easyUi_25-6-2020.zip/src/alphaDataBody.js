import React, { Component } from "react";
import ReactDOM from 'react-dom'
import {fullWidth, fullHeight } from './utility'

const RenderRow = (props) =>{
  return props.keys.map((key, index)=>{
    // console.log(props.data);
    let current_row = props.headerData.filter((item, inx)=>{
      if(item.key === key){
        return item;
      }
    })
    // console.log(current_row);
    const _width = current_row[0].width;
    // const _width = 180;

    if((typeof props.data[key] ) === 'object'){
      return (
      <div
        className="tbl_cell" 
        style={{"width": _width}}
        key={index}>
        </div>
      )
    } else {
      return (
        <div className="tbl_cell" 
         style={{"width": _width}}
          key={index}>
          {props.data[key]}
        </div>
      )
    }
  })
}

 
class AlphaDataGridBody extends Component {
  
  constructor(props) {
    super(props);
    this.gridBody = React.createRef();
}
  getKeys(){
    return Object.keys(this.props.rows[0]);
  }
  styleOfRow(row){
    const row_style =  {transform: "translateY("+ (row.rowinx)*50 +"px)"}
    return row_style;
  }
  getRowsData(){
    var items = this.props.rows;
    var headerData = this.props.columns;
    // var keys = this.getKeys();
    var keys = [];
    headerData.map((item, inx)=>{
      keys.push(item.key)
    })
    // console.log(keys);
    return items.map((row, index)=>{
      return (
        <div 
        style={this.styleOfRow(row, index)}
        className="tbl_row" 
        key={index}>
          <RenderRow 
            headerData={headerData}
            key={index} 
            data={row} 
            keys={keys}/>
        </div>
      )
    })
  }
  
  scrollFun=(e)=>{
    e.preventDefault();
    // console.log("Hellow")
    this.props.handleScrollTop(e);
  }

  componentDidMount() {
    // pass the requested ref here
    this.props.passRefUpward(this.gridBody.current);
  }    
 
  render() {
    const {rows, totalRows, columns} = this.props;
    // console.log(rows);
    return (
      <div className="tbl_body">
        <div className="tbl_body_cover"
        ref={this.gridBody}
        onScroll={(e) => this.scrollFun(e)}>
          { rows &&
            <div className="tbl_body_inner"
            style={{"width" : fullWidth(columns), "height" : fullHeight(totalRows)}}
            >
              { this.getRowsData()}
            </div>
          }
        </div>
      </div>
    );
  }
}
export default AlphaDataGridBody;