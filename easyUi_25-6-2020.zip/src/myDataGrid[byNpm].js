import React, { Component } from "react";
import axios from 'axios';
// import  AlphaDataGrid  from "./alphaDataGrid";
// import DataGrid from "../src/react-data-grid";
import './alphaTable.css';
import ReactDOM from "react-dom";
import ReactDataGrid from "react-data-grid";
import ImagesmFormatter from "./ImageFormatter";
import 'react-data-grid/dist/react-data-grid.css';

class AppGrid extends Component {
  constructor(props) {
    super(props);
    this.state = { };
  }

  componentDidMount(){
    axios.get(`https://jsonplaceholder.typicode.com/users`)
    .then(res => {
      const persons = res.data;
      const _persons = persons.map((item)=>{
        item = {...item, address:`https://i.picsum.photos/id/${item['id']}/200/200.jpg`, company : ""};
        return item;
      })
      console.log(_persons);
      // const colKeys = this.getKeys(persons[0]);
      const colKeys = [
          {
            key: "id",
            name: "ID",
            width : 50,
            frozen: true,
          },
          {
            key: "name",
            name: "Name",
            width : 80,
            resizable: true,
            frozen: true,
          },
          {
            key: "username",
            name: "User Name",
            width : 120,
          },
          {
            key: "email",
            name: "Email",
            width : 250,
          },
          {
            key: "address",
            name: "Client Address",
            width : 200,
            formatter:ImagesmFormatter
          },
          {
            key: "phone",
            name: "Telephone",
            width : 150
          },
          {
            key: "website",
            name: "Website",
            width : 150
          },
          {
            key: "company",
            name: "Company",
            width : 100
          } 
      ];
      this.setState({ 
        columns : colKeys,
        rows : [..._persons, ..._persons, ..._persons, ..._persons, ..._persons]
      });
    })
  }

  getKeys(data){
    let header = [];
    const all_keys = Object.keys(data);
    all_keys.map((item)=>{
      header.push({"name" : item.toUpperCase()})
    })
    return header;
  }

  render() {
    const {rows, columns} = this.state;
    return (
      <div className="myGrid">
      {/* <AlphaDataGrid
        columns={columns}
        rows={rows}
        /> */}

      { rows && columns &&
          <ReactDataGrid
            columns={columns}
            rows={rows}
          />
      }
        </div>
    );
  }
}
export default AppGrid;