import React, { Component } from "react";
import {fullWidth } from './utility'

class AlphaDataHeader extends Component {
  constructor(props) {
    super(props);
    this.gridHead = React.createRef();
}

createHeader(columns) {
    const new_columns = columns.map((cell, inx)=>{
        return ( 
            <div key={inx} 
            style={{"width": cell.width}}
            className="tbl_cell">
                {cell.name}
            </div> 
        );
    })
    return <div className="tbl_row">{new_columns}</div>;
    }
    componentDidMount() {
      // pass the requested ref here
      this.props.passRefHeader(this.gridHead.current);
    }  
   
  render() {
    const {columns} = this.props;
    return (
      <div className="tbl_head">
        <div  id="gridHeader"
        ref={this.gridHead}
        className="tbl_head_cover">
          { columns &&
            <div 
            style={{"width" : fullWidth(columns)}}
            className="tbl_head_inner">
              {this.createHeader(columns)}
            </div>
          }
        </div>
      </div>
    );
  }
}
export default AlphaDataHeader;