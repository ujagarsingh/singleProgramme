import React, { Component } from "react";

class ImagesmFormatter extends Component {
  render() {
    console.log(this.props.value);
    return (
      <div>
        <img src={this.props.value}/> //this.props.value should contain the path
      </div>
    )
  }
}
export default ImagesmFormatter;