import React, { Component } from "react";

class SidebarBottom extends Component {
totalWidth(columns){
    let width_val = 0;
    columns.map((item)=>{
        width_val += item.width;
    })
    return width_val;
}
scrollLeftHandler=(e)=>{
  e.preventDefault();
  this.props.handleScrollLeft(e);
}
render() {
  const {columns} = this.props;
    return (
      <div className="tbl_footer_Scroll"
      onScroll={(e) => this.scrollLeftHandler(e)}
      >
        { columns &&
          <div className="tbl_fScrollInner"
          style={{"width" : this.totalWidth(columns)}}
          >
          </div>
        }
      </div>
    );
  }
}
export default SidebarBottom;