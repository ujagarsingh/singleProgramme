import React, { Component } from 'react';
import data_obj from './assign_obj';

class AssignSubjects extends Component {
   /*state = {
      schools_arr: [],
      school_id: '',
      selected_school_index: '',
      medium_arr: [],
      subjects: [],
      selected_subjects: [],
      sft_classes: [],
      selected_class: '',
      selected_class_inx: '',
      selected_classes: [],
      medium: '',
      errorMessages: '',
      successMessages: '',
   }*/
   state = data_obj;
   isEmpty(val) {
      return (val === undefined || val == null || val.length <= 0) ? true : false;
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      if (fieldName === 'school') {
         const _inx = event.target.value;
         const _sch_id = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].id : '';
         const _medium = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_medium : [];
         sessionStorage.setItem("school_id", _sch_id);
         this.filterClassesOnSchool(_sch_id, this.state.group_id);
         this.setState({
            school_id: _sch_id,
            medium_arr: _medium,
            medium: (_medium.length === 1 ? _medium[0] : ''),
            selected_school_index: _inx,
            selected_class_inx: '',
            selected_subjects: []
         })
      } else if (fieldName === 'medium') {
         const _medium = event.target.value;
         sessionStorage.setItem("medium", _medium);
      } else if (fieldName === 'selected_class') {
         const _class_inx = event.target.value;
         const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
         //console.log(this.state.selected_classes[_class_inx]);
         sessionStorage.setItem("class_name_portal", _class_name);
         this.classHandler(_class_inx);
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            selected_class_inx: _class_inx
         })
      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value
         })
      }
   };
   filterClassesOnSchool(sch_id, group_id) {
      const _classes = this.state.sft_classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         selected_classes: _classes,
      }, ()=>{this.schoolWiseClassAndSubjectHandler()})
   }
   
   schoolWiseClassAndSubjectHandler(){
     const class_arr = this.state.selected_classes;
     const new_cl = class_arr.map((item)=>{
      const cl_sub =  this.getClassSubjectHandler(item.id) ;
      item = {...item, class_sub : cl_sub};
      return item;
     })
     // console.log(JSON.stringify(new_cl))
     console.log(new_cl)
     this.setState({
        
     })
   }





























   getClassSubjectHandler(_class_id) {
      const { subjects, medium} = this.state
         const _subject = subjects.filter((item) => {
            if (item.medium === medium && item.class_id === _class_id && item.sub_parent_id === "0") {
               return item
            }
         })
      return _subject;
   }
   classHandler(_classIdx) {
      const { subjects, medium, selected_classes } = this.state
      if (_classIdx !== 'All') {
         const _class_name = selected_classes[_classIdx].class_name;
         const _class_id = selected_classes[_classIdx].id;
         const _subject = subjects.filter((item, inx) => {
            if (item.medium === medium && item.class_id === _class_id) {
               return item
            }
         })
         this.setState({
            selected_subjects: _subject
         })
      } else {
         const _subject = subjects.filter((item, inx) => {
            if (item.medium === medium) {
               return item
            }
         })
         this.setState({
            selected_subjects: _subject
         })
      }
   }
   basicInfoHandler = (event) => {
      event.preventDefault();
      this.setState({
         basicInfo: !this.state.basicInfo
      })
   }
   
   
    
   finalSubArray = () => {
      const _subjects_arr = this.state.subjects;
      if (!this.isEmpty(_subjects_arr)) {
         const _subjects = _subjects_arr.map((item, index) => {
            let _class_name = '';
            this.state.sft_classes.filter((item_c, index) => {
               if (item.class_id === item_c.id) {
                  _class_name = item_c.class_name
               }
            })
            return item = { ...item, class_name: _class_name }
         })
         this.setState({
            subjects: _subjects
         })
      }
   }
    componentDidMount(){
      this.schoolWiseClassAndSubjectHandler();
    }
   render() {
      const { selected_school_index, schools_arr, selected_classes, medium_arr, selected_subjects,
         medium, selected_class_inx, user } = this.state;
      console.log(this.state)
      return (
         <div className="page-content">
               <title>All Subject</title>
            {user &&
               <>
                  <div className="page-bar d-none">
                     <div className="page-title">Subjects List</div>
                     <div className="form-inline ml-auto filter-panel">
                        <span className="filter-closer">
                           <button type="button" className="btn btn-danger filter-toggler-c">
                              <i className="fa fa-times"></i>
                           </button>
                        </span>
                        <div className="filter-con">
                           {user.user_category === "1" ?
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    value={selected_school_index}
                                    onChange={event => this.changeHandler(event, 'school')}>
                                    <option value="">Select ...</option>
                                    {schools_arr.map((item, index) => {
                                       return (
                                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                              : null}
                           <div className="form-group mr-2 mt-1">
                              <label className="control-label mr-2">Medium :</label>
                              <select className="form-control form-control-sm"
                                 required
                                 disabled={medium_arr.length > 1 ? false : true}
                                 value={medium}
                                 onChange={event => this.changeHandler(event, 'medium')}>
                                 <option value="">Select ...</option>
                                 {medium_arr.map((item, index) => {
                                    return (
                                       <option key={index} value={item}>{item}</option>
                                    )
                                 })}
                              </select>
                           </div>
                           <div className="form-group mr-2 mt-1">
                              <label className="control-label mr-2">Class : </label>
                              <select
                                 // disabled={medium === '' ? true : false}
                                 value={selected_class_inx}
                                 className="form-control form-control-sm " name="selected_class"
                                 onChange={event => this.changeHandler(event, 'selected_class')}>
                                 <option value="All">Select...</option>
                                 {selected_classes.map((option, index) => {
                                    return (<option key={index} value={index}>{option.class_name}</option>)
                                 })}
                              </select>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="card card-box sfpage-cover  d-none">
                     <div className="card-body sfpage-body">
                        <div className="table-scrollable">
                           <table className="table table-striped table-sm table-bordered table-hover table-sm">
                              <thead>
                                 <tr>
                                    <th>Id</th>
                                    <th>Class Name</th>
                                    <th>Subject Name</th>
                                    <th>Action</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr>
                                    <td>Id</td>
                                    <td>Class Name</td>
                                    <td>Subject Name</td>
                                    <td>Action</td>
                                 </tr>
                              </tbody>
                              
                           </table>
                        </div>
                     </div>
                  </div>
               </>
            }
         </div>
      )
   }
}
export default AssignSubjects;