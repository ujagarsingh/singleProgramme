import React, { Component } from "react";
import SidebarBottom  from "./alphaSidebarBottom";

class AlphaDataFooter extends Component {
// createHeader(columns) {
//     const new_columns = columns.map((cell, inx)=>{
//         return ( 
//             <div key={inx} 
//             style={{"width": cell.width}}
//             className="cell_head">
//                 {cell.name}
//             </div> 
//         );
//     })
//     return <div className="tbl_row">{new_columns}</div>;
//     }
 


  render() {
    const {columns} = this.props;
    // console.log(this.props)
    return (
      <div className="tbl_footer">
        <div className="tbl_footer_cover">
            <SidebarBottom
              columns={columns}
              handleScrollLeft={(e) => this.props.handleScrollLeft(e)}
            />
        </div>
      </div>
    );
  }
}
export default AlphaDataFooter;
