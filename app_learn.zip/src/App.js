import React, { Component } from 'react';
import { Router, Route, Switch, withRouter } from 'react-router-dom';
import { history } from './_helpers';

import Home from "./components/Home";
import AllSlider from "./components/all_slider";
import AddSlider from "./components/add_slider";

class App extends Component {

  constructor(props) {
    super(props);
    history.listen((location, action) => {
    });
  }
  render() {
    // console.log(this.props);
    return (
      <Router history={history} >
        <Switch>
          <Route path="/Home.jsp" component={Home} />
          <Route path="/all_slider.jsp" component={AllSlider} />
          <Route path="/add_slider.jsp" component={AddSlider} />
        </Switch>
      </Router>
    );
  }
}
export default withRouter(App);
 
