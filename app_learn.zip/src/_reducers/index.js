import { combineReducers } from 'redux';
import { frontSlider } from './front_slider.reducer';

const rootReducer = combineReducers({
  frontSlider,
});

export default rootReducer;
 