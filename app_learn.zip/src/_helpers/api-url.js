const api_url = "http://www.rajpsp.com/api_redux/";
// const api_url = "http://localhost/schooloffice/api/";

export default api_url;