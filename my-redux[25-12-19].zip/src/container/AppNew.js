import React, { Component } from 'react';  
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';  
  
/** Layouts **/  
import HomeLayoutRoute from "../layouts/HomeLayout";  
import UserLayoutRoute from "../layouts/UserLayout";  
  
/** Components **/  
import HomePage from '../layouts/HomePage';  
import UserPage from '../layouts/UserPage'  
  
/* 
   App 
 */  
class App extends Component {  
  render() {  
    return (  
      <Router>  
        <Switch>  
          <Route exact path="/">  
            <Redirect to="/Home" />  
          </Route>  
          <HomeLayoutRoute path="/Home" component={HomePage} />  
          <UserLayoutRoute path="/Register" component={UserPage} />  
        </Switch>  
      </Router>  
    );  
  }  
}  
  
export default App;