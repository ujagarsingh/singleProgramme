import React from "react";
import { connect } from "react-redux";
import { NavLink } from "react-router-dom"

import { addTodo } from "../actionCreator/todo-action-creator";
class AddTodo extends React.Component {
  addItemToState = (ev) => {
    ev.preventDefault();
    this.props.addTodo({
      text: this.refs.text.value,
      desc: this.refs.desc.value
    })
    this.refs.text.value = "";
    this.refs.desc.value = "";
  }
  render() {
    return (
      <section>
        <NavLink className="btn btn-link" to="/">Back to Index</NavLink>
        <hr/>
        <form className="form-group p-3 bg-light" onSubmit={this.addItemToState}>
          <div className="input-group">
            <input className="form-control" type="text" ref="text" placeholder="Title" />
            <input className="form-control" type="text" ref="desc" placeholder="Description" />
            <div className="input-group-append">
              <button className="btn btn-default" type="submit">Add Todo</button>
            </div>
          </div>
        </form>
      </section>
    )
  }
}

export default connect(null, { addTodo })(AddTodo);