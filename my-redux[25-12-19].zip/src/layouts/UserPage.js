import React, { Component } from 'react';
import { NavLink } from "react-router-dom";
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import RegistrationPage from '../components/RegistrationPage'
class UserPage extends Component {
  render() {
    return (
      <section>
        <Navbar />
        <RegistrationPage />
        <Footer />
      </section>
    );
  };
};

export default UserPage  