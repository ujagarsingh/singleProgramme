import React from "react";
class AddTodo extends React.Component{
    addItemToState = (ev) =>{
    ev.preventDefault();
    this.props.addTodo({
        text : this.refs.addtodo.value
    })
    this.refs.addtodo.value = ""
    }
    render(){
        return(
          <form className="d-flex p-3 bg-light" onSubmit={ this.addItemToState }>
            <input className="form-control" type="text" ref="addtodo" />
            <button className="btn btn-default"  type="submit">Add Todo</button>
          </form>
        )
    }
}
export default AddTodo;