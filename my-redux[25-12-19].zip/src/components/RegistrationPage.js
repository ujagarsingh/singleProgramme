import React from "react";
import { NavLink } from "react-router-dom";

class RegistrationPage extends React.Component {
  render() {
    return (
      <>
        <div className="ui-hero hero-sm bg-dark-gray hero-svg-layer-4">
          <div className="container">
            <h1 className="heading">Registration</h1>
            <p className="paragraph">Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor.</p>
          </div>
        </div>
        <div className="main" role="main">
          <div className="section contact-section">
            <div className="container">
              <div className="row">
                <div className="col-md-7">
                  <div className="section-heading mb-2">
                    <h3 className="heading text-indigo">Please Fill Below Details</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                  </div>
                  <form autoComplete="on" id="contact-form" name="contact-form">
                    <div className="form-group">
                      <div className="row">
                        <div className="col-sm-6">
                          <input className="input form-control" placeholder="User Name *" />
                        </div>
                        <div className="col-sm-6">
                          <input className="input form-control" placeholder="Mobile Number *" />
                        </div>
                      </div>
                    </div>
                    <div className="form-group">
                      <div className="form-group">
                        <input className="input form-control" placeholder="School Name *" />
                      </div>
                    </div>
                    <div className="form-group">
                      <div className="form-group">
                        <input className="input form-control" placeholder="School Address *" />
                      </div>
                    </div>
                    <div className="form-group">
                      <div className="row">
                        <div className="col-sm-6">
                          <input className="input form-control" placeholder="Recognition Number *" />
                        </div>
                        <div className="col-sm-6">
                          <select className="input form-control">
                            <option>Free</option>
                            <option>Single School</option>
                            <option>ERP Solution</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="form-group">
                      <textarea className="input form-control" placeholder="Your Message" rows={3} defaultValue={""} />
                    </div>
                    <button type="submit" className="btn btn-block ui-gradient-green shadow-md">Submit</button>
                  </form>
                </div>
                <div className="col-md-5">
                  <div className="ui-card form-card shadow-xl bg-indigo">
                    <div className="card-header pb-0">
                      <h3 className="heading">Telephone Support</h3></div>
                    <div className="card-body">
                      <ul className="ui-icon-blocks ui-blocks-v">
                        <li className="ui-icon-block"><span className="icon lar la-clock" />
                          <p>Mon - Sat 09:00 - 19:00</p>
                        </li>
                        <li className="ui-icon-block"><span className="icon las la-phone" />
                          <p>+91 97 1117 1961</p>
                        </li>
                        <li className="ui-icon-block"><span className="icon lar la-envelope" />
                          <p>info.smartpsp@gmail.com</p>
                        </li>
                        <li className="ui-icon-block"><span className="icon la la-shopping-cart" />
                          <p>sales.smartpsp@gmail.com</p>
                        </li>
                        <li className="ui-icon-block"><span className="icon la la-map-pin" />
                          <h6 className="text-white">Head Office :</h6>
                          <p>101 Street Address,
                          <br />Jind, Haryana</p>
                          <h6 className="text-white mt-4">Branch Office :</h6>
                          <p>45, Khawaraniji, Jamwaramgarh,
                          <br />Jaipur, Rajasthan</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="section ui-gradient-blue ui-action-section z-index-3">
            <div className="container">
              <div className="row">
                <div className="col-lg-6 col-md-7 text-block" data-vertical_center="true">
                  <div className="section-heading">
                    <h2 className="heading">Display on iOS and Android</h2>
                    <p className="paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis</p>
                    <div className="actions"><NavLink to="/Home" className="btn ui-gradient-green btn-app-store btn-download shadow-lg"><span>Available on the</span> <span>App Store</span></NavLink> <NavLink to="/Home" className="btn ui-gradient-blue btn-google-play btn-download shadow-lg"><span>Available on</span> <span>Google Play</span></NavLink></div>
                  </div>
                </div>
                <div className="col-lg-6 col-md-5 img-block animate" data-show="fade-in-left"><img src="assets/img/mockups/shala-darpan-mockup-2-lg.png" alt="ShalaDarpan - Online School Managment" data-uhd className="responsive-on-sm" data-max_width={547} /></div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default RegistrationPage;