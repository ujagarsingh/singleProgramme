import React from "react";
import { NavLink } from "react-router-dom";

class IndexPage extends React.Component {
	nextSlide = () => {
        // alert(1);
    }
    render() {
        return (
            <>
                <div className="main" role="main">
                    <div className="ui-hero hero-lg hero-center hero-bg ui-curve hero-svg-layer-4 bg-dark-gray">
                        <div className="container">
                            <div className="row pt-2 pb-6">
                                <div className="col-sm-12" data-vertical_center={true} data-vertical_offset={16}>
                                    <h1 className="heading animate" data-show="fade-in-up-big" data-delay={100}>
                                        The <span className="text-red">easiest</span> &amp; most <span className="text-red">secure</span> online school managment system
		</h1>
                                    <form autoComplete="on" className="pt-2">
                                        <div className="form-group">
                                            <div className="input-group">
                                                <input autoComplete="email" className="input form-control" data-validation="required" data-validation-error-msg="Invalid email" name="email" placeholder="Enter your email" />
                                                <div className="input-group-append">
                                                    <button className="btn ui-gradient-peach">Lets go! <span className="la la-rocket" /></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <NavLink to="/" className="ui-video-toggle mt-4" data-video="1C75bKax4Eg">
                                        <i className="" />
                                        <span className="icon la la-play bg-red" /> <span>How ShalaDarpan Works</span>
                                    </NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="section intro-image pt-0">
                        <img src="assets/demo/img/mockups/shala-darpan-browser-mockup.png" data-uhd data-max_width={1000} className="shadow-xxl responsive-on-lg" alt="ShalaDarpan - Online School Managment" />
                    </div>
                    <div id="modules-of-online-school-managment" className="section pt-0">
                        <div className="container ui-icon-blocks ui-blocks-h icons-lg">
                            <div className="section-heading cente">
                                <h2 className="heading text-dark-gray">
                                    Modules of ShalaDarpan ERP
	  </h2>
                                <p className="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.
	  </p>
                            </div>
                            <div className="row">
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-graduation-cap icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Student Admission Management</h4>
                                    <p>
                                        The organization can handle all complicated process of admission with ease. This includes prospectus sale, student registration, verification &amp; finalization, etc.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-wallet icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Online Fees Collection</h4>
                                    <p>
                                        With this advance cloud-based fee collection module, parents can pay their child's fee &amp; track fee records. A comfortable platform for parents and organization.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-user-check icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Student Attendance Management</h4>
                                    <p>
                                        This module provides a convenient platform for taking student's attendance online via smart phone. Parents will receive SMS about their ward's presence in the campus.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="la la-rocket icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Student Administration Management</h4>
                                    <p>
                                        Student administration module provides the facility to manage all the administration related tasks on a single platform. This module generates various MIS reports useful for the institution.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-id-card icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">ID Card Generation &amp; Printing</h4>
                                    <p>
                                        Through this School Edu ERP module, school authorities can design and print student identity card as per their standard format.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-door-open icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Parents/Students Login</h4>
                                    <p>
                                        Parents/ Students will receive a secured login to perform various activities. Parents can also check their ward's attendance, results, fee dues, etc.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-certificate icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Staff Login</h4>
                                    <p>
                                        Each authorized staff member will receive secured login to perform various tasks efficiently depending on the liberty assigned to them.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-bullseye icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Examination Management</h4>
                                    <p>
                                        Using this module, schools can define class wise examination scheme, subject offered grades, passing criteria. Any type grace and exam rules can be defined by users.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="lar la-address-book icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Result Processing</h4>
                                    <p>
                                        This module helps to process examination results from Std. I to XII on the basis of various systems like marks based, grade based and combination of both.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-rupee-sign icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Finance</h4>
                                    <p>
                                        This module helps to keep track of the expenses and the available funds of the financial and accounting department. Any number of account can be maintained for end number of years.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-globe icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">Web Portal</h4>
                                    <p>
                                        Give your institute a global gateway and recognition through an elegant web presence. An economical, social and communicative standing of a school/ institute validates excellence.
		</p>
                                </div>
                                <div className="col-sm-4 ui-icon-block">
                                    <div className="las la-sms icon icon-lg icon-circle text-red" />
                                    <h4 className="text-dark-gray">SMS Integration</h4>
                                    <p>
                                        With SMS integration, school authorities can send push notification about fee dues, examination schedules, school notices, incoming parent meeting, etc.
		</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="features" className="section bg-light">
                        <div className="container">
                            <div className="section-heading center">
                                <h2 className="heading text-dark-gray">
                                    Awesome Features
	  </h2>
                                <p className="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
	  </p>
                            </div>
                            <div className="ui-showcase-blocks ui-steps">
                                <div className="step-wrapper">
                                    <span className="step-number ui-gradient-blue">1</span>
                                    <div className="row">
                                        <div className="col-md-6" data-vertical_center={true}>
                                            <h4 className="heading text-dark-gray">
                                                All Device Supported
			</h4>
                                            <p className="paragraph">
                                                This Application can be use use in all devices. It is smoothly used and responsible for Mobile, Laptop, and Desktop.
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">Explore</NavLink>
                                        </div>
                                        <div className="col-md-6">
                                            <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-7.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width={464} />
                                        </div>
                                    </div>
                                </div>
                                <div className="step-wrapper">
                                    <span className="step-number ui-gradient-blue">2</span>
                                    <div className="row">
                                        <div className="col-md-6" data-vertical_center={true}>
                                            <h4 className="heading text-dark-gray">
                                                Easy to Use
			</h4>
                                            <p className="paragraph">
                                                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">Explore</NavLink>
                                        </div>
                                        <div className="col-md-6">
                                            <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-8.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width={445} />
                                        </div>
                                    </div>
                                </div>
                                <div className="step-wrapper">
                                    <span className="step-number ui-gradient-blue">3</span>
                                    <div className="row">
                                        <div className="col-md-6" data-vertical_center={true}>
                                            <h4 className="heading text-dark-gray">
                                                Secure Login and Backpup
			</h4>
                                            <p className="paragraph">
                                                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">Explore</NavLink>
                                        </div>
                                        <div className="col-sm-6">
                                            <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-10.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width={451} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="used-technology" className="section ui-gradient-blue d-none">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-5 col-xl-6" data-vertical_center={true}>
                                    <div className="section-heading mb-2">
                                        <h2 className="heading">
                                            Student Administration Management
		  </h2>
                                        <p className="paragraph">
                                            Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Ali
		  </p>
                                    </div>
                                    <ul className="ui-icon-blocks ui-blocks-v icons-sm">
                                        <li className="ui-icon-block">
                                            <span className="la la-gem icon" />
                                            <p className="">
                                                Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">
                                                Learn More
			</NavLink>
                                        </li>
                                        <li className="ui-icon-block">
                                            <span className="la la-chart-pie icon" />
                                            <p className="">
                                                Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">
                                                Learn More
			</NavLink>
                                        </li>
                                        <li className="ui-icon-block">
                                            <span className="la la-layer-group icon" />
                                            <p className="">
                                                Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod
			</p>
                                            <NavLink to="/" className="btn-link btn-arrow">
                                                Learn More
			</NavLink>
                                        </li>
                                    </ul>
                                </div>
                                <div className="col-lg-7 col-xl-6">
                                    <div className="ui-logos-cloud">
                                        <div data-size={4} className="mt-0 animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/quickbooks.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={10} className="mt-0 animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/salesforce.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={7} className="mt-0 animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/git.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <span className="flex-break" />
                                        <div data-size={4} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/webflow.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={10} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/shopify.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={4} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/mailchimp.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={6} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/magento.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={3} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/bigcommerce.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <span className="flex-break" />
                                        <div data-size={8} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/squarespace.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={3} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/sharepoint.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={10} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/slack.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={5} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/paypal.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <span className="flex-break" />
                                        <div data-size={3} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/fresh-desk.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={10} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/stripe.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <div data-size={7} className="animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/woocommerce.svg" alt="Applif App Landing Page" />
                                        </div>
                                        <span className="flex-break" />
                                        <div data-size={4} className="mb-0 animate" data-show="fade-in">
                                            <img src="assets/img/3rd-party-logos/xero.svg" alt="Applif App Landing Page" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="section laptop-showcase">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-5 col-lg-4" data-vertical_center={true}>
                                    <div>
                                        <h2 className="heading text-dark-gray">
                                            Designed For All Apps
		  </h2>
                                        <p>
                                            Lorem ipsum dolor  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
		  </p>
                                        <ul className="ui-checklist mt-2">
                                            <li>
                                                <h6 className="heading text-dark-gray">Consectetur adipisicing</h6>
                                            </li>
                                            <li>
                                                <h6 className="heading text-dark-gray">Eiusmod tempor incididunt</h6>
                                            </li>
                                            <li>
                                                <h6 className="heading text-dark-gray">Ut enim ad minim</h6>
                                            </li>
                                        </ul>
                                        <NavLink to="/" className="btn ui-gradient-peach">Download</NavLink>
                                    </div>
                                </div>
                                <div className="col-md-7 col-lg-8">
                                    <img className="responsive-on-sm laptop" src="assets/demo/img/mockups/shala-darpan-mockup-11.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width={1000} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="section bg-light pb-6" style={{ margin: '250px 0' }}>
                        <div className="container ">
                            <div className="multi-slider-con">
                                <div className="multi-slider">
                                    <div className="slidercontainer mobile-view">
                                        <div className="showSlide animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-m-1.jpg" />
                                            <div className="content">Slide1 heading</div>
                                        </div>
                                        <div className="showSlide animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-m-0.jpg" />
                                            <div className="content">Slide2 heading</div>
                                        </div>
                                        <div className="showSlide animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-m-1.jpg" />
                                            <div className="content">Slide3 heading</div>
                                        </div>
                                        <div className="showSlide animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-m-0.jpg" />
                                            <div className="content">Slide4 heading</div>
                                        </div>
                                        <NavLink to="/" className="left" onClick={this.nextSlide(-1)}>❮</NavLink>
                                        <NavLink to="/" className="right" onClick={this.nextSlide(1)}>❯</NavLink>
                                    </div>
                                    <div className="slidercontainer tab-vlew">
                                        <div className="showSlide0 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-t-1.jpg" />
                                            <div className="content">Slide1 heading</div>
                                        </div>
                                        <div className="showSlide0 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-t-0.jpg" />
                                            <div className="content">Slide2 heading</div>
                                        </div>
                                        <div className="showSlide0 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-t-1.jpg" />
                                            <div className="content">Slide3 heading</div>
                                        </div>
                                        <div className="showSlide0 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-t-0.jpg" />
                                            <div className="content">Slide4 heading</div>
                                        </div>
                                        <NavLink to="/" className="left" onClick={this.nextSlide(-1)}>❮</NavLink>
                                        <NavLink to="/" className="right" onClick={this.nextSlide(1)}>❯</NavLink>
                                    </div>
                                    <div className="slidercontainer laptop-view">
                                        <div className="showSlide1 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-l-1.jpg" />
                                            <div className="content">Slide1 heading</div>
                                        </div>
                                        <div className="showSlide1 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-l-0.jpg" />
                                            <div className="content">Slide2 heading</div>
                                        </div>
                                        <div className="showSlide1 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-l-1.jpg" />
                                            <div className="content">Slide3 heading</div>
                                        </div>
                                        <div className="showSlide1 animate animated fade-in-bottom">
                                            <img src="assets/img/slider/fullimage-l-0.jpg" />
                                            <div className="content">Slide4 heading</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="controls">
                                    <NavLink to="/" className="left" onClick={this.nextSlide(-1)}>❮</NavLink>
                                    <NavLink to="/" className="right" onClick={this.nextSlide(1)}>❯</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="support" className="section bg-dark-gray">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-6 col-md-5" data-vertical_center={true}>
                                    <div className="section-heading mb-0 center-on-md">
                                        <h2 className="heading">
                                            Award-Winning Support
		  </h2>
                                        <p className="paragraph">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
		  </p>
                                        <div className="row ui-icon-blocks ui-blocks-h icons-md mt-2">
                                            <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                                <div className="la la-phone icon" />
                                                <h4 className="heading mb-1">200k</h4>
                                                <p>
                                                    Calls a day
			  </p>
                                            </div>
                                            <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                                <div className="las la-trophy icon" />
                                                <h4 className="heading mb-1">4.5</h4>
                                                <p>
                                                    Star Rating
			  </p>
                                            </div>
                                            <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                                <div className="la la-support icon" />
                                                <h4 className="heading mb-1">500k</h4>
                                                <p>
                                                    Experts working 24/7
			  </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-7 img-block animate" data-show="fade-in-left" data-vertical_center={true}>
                                    <img src="assets/img/support/shala-darpan-support.png" alt="ShalaDarpan - Online School Managment" data-uhd className="img-fluid" data-max_width={460} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="pricing" className="section bg-light">
                        <div className="container">
                            <div className="section-heading center">
                                <h2 className="heading text-dark-gray">
                                    Pricing Cards
	  </h2>
                                <p className="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
	  </p>
                            </div>
                            <div className="ui-pricing-cards owl-carousel owl-theme">
                                <div className="ui-pricing-card animate" data-show="fade-in-left">
                                    <div className="ui-card ui-curve shadow-lg">
                                        <div className="card-header bg-dark-gray">
                                            <h4 className="heading">Start-up</h4>
                                            <div className="price text-red">
                                                <span className="curency">£</span>
                                                <span className="price">Free</span>
                                                <span className="period">/year</span>
                                            </div>
                                            <h6 className="sub-heading">24/7 Support</h6>
                                        </div>
                                        <div className="card-body">
                                            <ul>
                                                <li>
                                                    10 GB SSD Disk Space
			  </li>
                                                <li>
                                                    10 SDD Databases
			  </li>
                                                <li>
                                                    2 Subdomains
			  </li>
                                                <li>
                                                    25 Email Accounts
			  </li>
                                            </ul>
                                            <NavLink to="page-pricing.html" className="btn shadow-md ui-gradient-peach">Get Started</NavLink>
                                        </div>
                                    </div>
                                </div>
                                <div className="ui-pricing-card active animate" data-show="fade-in">
                                    <div className="ui-card ui-curve color-card shadow-xl">
                                        <div className="card-header ui-gradient-peach">
                                            <h4 className="heading">Established</h4>
                                            <div className="price">
                                                <span className="curency">£</span>
                                                <span className="price">57</span>
                                                <span className="period">/mo</span>
                                            </div>
                                            <h6 className="sub-heading">24/7 Support</h6>
                                        </div>
                                        <div className="card-body">
                                            <ul>
                                                <li>
                                                    20 GB SSD Disk Space
			  </li>
                                                <li>
                                                    20 SDD Databases
			  </li>
                                                <li>
                                                    4 Subdomains
			  </li>
                                                <li>
                                                    50 Email Accounts
			  </li>
                                            </ul>
                                            <NavLink to="page-pricing.html" className="btn bg-dark-gray shadow-md">Get Started</NavLink>
                                        </div>
                                    </div>
                                </div>
                                <div className="ui-pricing-card animate" data-show="fade-in-right">
                                    <div className="ui-card ui-curve shadow-lg">
                                        <div className="card-header bg-dark-gray">
                                            <h4 className="heading">Mastery</h4>
                                            <div className="price text-red">
                                                <span className="curency">£</span>
                                                <span className="price">89</span>
                                                <span className="period">/mo</span>
                                            </div>
                                            <h6 className="sub-heading">24/7 Support</h6>
                                        </div>
                                        <div className="card-body">
                                            <ul>
                                                <li>
                                                    60 GB SSD Disk Space
			  </li>
                                                <li>
                                                    30 SDD Databases
			  </li>
                                                <li>
                                                    12 Subdomains
			  </li>
                                                <li>
                                                    200 Email Accounts
			  </li>
                                            </ul>
                                            <NavLink to="page-pricing.html" className="btn ui-gradient-peach shadow-md">Get Started</NavLink>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="ui-pricing-footer">
                                <p className="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
	  </p>
                                <div className="actions">
                                    <NavLink to="/" className="btn">Learn More</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="section">
                        <div className="container">
                            <div className="section-heading center">
                                <h2 className="heading text-dark-gray">
                                    What People Say
	  </h2>
                                <p className="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
	  </p>
                            </div>
                            <div className="ui-testimonials slider owl-carousel owl-theme">
                                <div className="item">
                                    <div className="ui-card shadow-md">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                                    </div>
                                    <div className="user">
                                        <div className="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar1-sm.png" /></div>
                                        <div className="info">
                                            <h6 className="heading text-dark-gray">Vicky Stout</h6>
                                            <p className="sub-heading">Founder at Smith &amp; Co</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="item">
                                    <div className="ui-card shadow-md">
                                        <p> Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
                                    </div>
                                    <div className="user">
                                        <div className="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar2-sm.png" /></div>
                                        <div className="info">
                                            <h6 className="heading text-dark-gray">Jack Smith</h6>
                                            <p className="sub-heading">Founder at Smith &amp; Co</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="item">
                                    <div className="ui-card shadow-md">
                                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariaturin.</p>
                                    </div>
                                    <div className="user">
                                        <div className="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar3-sm.png" /></div>
                                        <div className="info">
                                            <h6 className="heading text-dark-gray">Chérel Doe</h6>
                                            <p className="sub-heading">Founder at Smith &amp; Co</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="item">
                                    <div className="ui-card shadow-md">
                                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur ac nisi.</p>
                                    </div>
                                    <div className="user">
                                        <div className="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar4-sm.png" /></div>
                                        <div className="info">
                                            <h6 className="heading text-dark-gray">Derick Watts</h6>
                                            <p className="sub-heading">Founder at Smith &amp; Co</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="item">
                                    <div className="ui-card shadow-md">
                                        <p>Donec elementum ligula eu sapien consequat eleifend. Donec nec dolor erat, condimentum sagittis.</p>
                                    </div>
                                    <div className="user">
                                        <div className="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar5-sm.png" /></div>
                                        <div className="info">
                                            <h6 className="heading text-dark-gray">Jane Austin</h6>
                                            <p className="sub-heading">Founder at Smith &amp; Co</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default IndexPage;