import { feeWithCategoryConstants } from '../_constants';

export function feeWithCategory(state = {}, action) {
  switch (action.type) {
    case feeWithCategoryConstants.FEE_WITH_CATEGORY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeWithCategoryConstants.FEE_WITH_CATEGORY_SUCCESS:
      return {
        item: action.response
      };
    case feeWithCategoryConstants.FEE_WITH_CATEGORY_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}