import { accManagerConstants } from '../_constants';
const initialState = {
                         ledger_fy_report : [],
                         ledger_summary_of_month : [],
                         group_balance : [],
                         ledger_data : [],
                     }

export function accManager(state = initialState, action) {
  switch (action.type) {
    case accManagerConstants.ACC_MANAGER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_MANAGER_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accManagerConstants.ACC_MANAGER_FAILURE:
      return {
        error: action.error
      };
    

    case accManagerConstants.ACC_LDR_YEAR_REPORT_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_LDR_YEAR_REPORT_SUCCESS:
      const new_obj = {...state.item, ledger_fy_report: action.response};
      return {
        item: new_obj,
        loading: false,
      };
    case accManagerConstants.ACC_LDR_YEAR_REPORT_FAILURE:
      return {
        error: action.error
      };
    
    
    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_SUCCESS:
      const new_month_obj = {...state.item, ledger_summary_of_month: action.response};
      return {
        item: new_month_obj,
        loading: false,
      };
    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_FAILURE:
      return {
        error: action.error
      };
    
    
    default:
      return state
  }
}