import { authenticConstants } from '../_constants';

let jwt = '';

const initialState = jwt ? { loggedIn: true, jwt } : {};

export function authentication(state = initialState, action) {
  switch (action.type) {
    case authenticConstants.LOGIN_REQUEST:
      return {
        loggingIn: true,
        // item: action.obj
      };
    case authenticConstants.LOGIN_SUCCESS:
      return {
        loggedIn: false,
        item: action.user
      };
    case authenticConstants.LOGIN_FAILURE:
      return {};

    case authenticConstants.LOGOUT:
      return {};
    default:
      return state
  }
}