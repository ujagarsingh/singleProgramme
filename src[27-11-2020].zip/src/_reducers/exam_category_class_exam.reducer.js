import { examCategoryClassExamConstants } from '../_constants';

export function examCategoryClassExam(state = {}, action) {
  switch (action.type) {
    case examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_SUCCESS:
      return {
        item: action.response
      };
    case examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}