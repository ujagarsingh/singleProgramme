import { filterConstants } from '../_constants';

const initialState = {
  slct_school_index: '',
  slct_school_id: '',
  slct_school: '',
  school_classes: [],
  school_mediums: [],

  slct_medium_index: '',
  slct_medium_id: '',
  slct_medium: '',
}

export function filteredSchoolData(state = initialState, action) {
  switch (action.type) {
    case filterConstants.FILTER_SCHOOLS_REQUEST:
      let _obj = action.obj;
      if (_obj.index === "") {
        return initialState;
      } else {
        const _slct_school = _obj.schools.filter((item, index) => {
          if (index == _obj.index) {
            return item;
          }
        })
        const _slct_classes = _obj.classes.filter((item, index) => {
          if (item.school_id === _slct_school[0].id) {
            return item;
          }
        })
        return {
          ...state,
          slct_school_index: _obj.index,
          slct_school_id: _slct_school[0]['id'],
          slct_school: _slct_school[0],
          school_classes: _slct_classes,
          school_mediums: _slct_school[0]['sch_medium'],
          slct_medium: (_slct_school[0]['sch_medium'].length === 1) ? _slct_school[0]['sch_medium'][0] : ''
        };
      }

    default:
      return state
  }
}