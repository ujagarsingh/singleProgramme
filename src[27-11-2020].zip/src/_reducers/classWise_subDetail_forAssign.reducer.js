import { classWiseSubDetailsForAssignConstants } from '../_constants';

export function classWiseSubDetailsForAssign(state = {}, action) {
  switch (action.type) {
    case classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_SUCCESS:
      return {
        item: action.response
      };
    case classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}