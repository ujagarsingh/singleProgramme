import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
//import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

const GET_SLIDERS = `http://schools.rajpsp.com/api/front_slider/read.php`;
class FrontIndexSlider extends Component {
  state = {
    slider_arr: [],
    successMessages: ''
  }
  componentDidMount() {
    loadProgressBar();
    axios.get(GET_SLIDERS)
      .then(res => {
        const getRes = res.data;
        this.setState({
          slider_arr: getRes,
          errorMessages: getRes.message
        });
        //console.log(this.state.slider_ar);
      }).catch((error) => {
        // error
      })
  };
  render() {
    const _state = this.state;
    return (
      <div className="rev_slider_wrapper" >
        <div id="rev_slider_1" className="rev_slider" style={{ display: 'none' }}>
          {/* BEGIN SLIDES LIST */}
          <ul>
            {_state.slider_arr.map((value, index) => {
              return (
                <li key={index} data-transition="boxfade" data-title="Slide Title"
                  data-param1="Additional Text" data-thumb={`images/index/slider-0` + (index + 1) + `.jpg`}>
                  <div className="slider-overlay" />
                  {/* SLIDE'S MAIN BACKGROUND IMAGE */}
                  <img alt="SmartPSP" src={`/assets/images/slider-0` + (index + 1) + `.jpg`}   className="rev-slidebg" />
                  {/* BEGIN BASIC TEXT LAYER */}
                  {/* LAYER NR. 1 */}
                  <div className="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 header-1 title-line-1"
                    data-x="left" data-hoffset={0} data-y="center" data-voffset={-140}
                    data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:3000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, fontSize: '60px', color: '#fff', fontFamily: '"Montserrat", sans-serif', whiteSpace: 'nowrap', fontWeight: 700 }}>
                    {value.title_1a}
                  </div>
                  {/* LAYER NR. 2 */}
                  <div className="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 header-1 title-line-2"
                    data-x="left" data-hoffset={0} data-y="center" data-voffset={-80}
                    data-frames="[{&quot;delay&quot;:1000,&quot;speed&quot;:3000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, fontSize: '60px', color: '#fff', fontFamily: '"Montserrat", sans-serif', whiteSpace: 'nowrap', fontWeight: 700 }}>
                    {value.title_1b}
                  </div>
                  {/* LAYER NR. 3 */}
                  <div className="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 header-p"
                    data-x="left" data-hoffset={0} data-y="center" data-voffset={-10}
                    data-frames="[{&quot;delay&quot;:1000,&quot;speed&quot;:3000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, lineHeight: '25px', fontSize: '15px', color: '#fff', fontFamily: '"Open Sans", sans-serif', whiteSpace: 'nowrap' }}>
                    {value.sub_title}
                  </div>
                  {/* LAYER NR. 4 
                  <div className="tp-caption lfb tp-resizeme header-btn" data-x="left" data-hoffset={0} data-y="center" data-voffset={90} data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:2000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:bottom;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 8 }}>
                    <a href="#." className="el-btn-regular slider-btn-left">Get Started Now</a>
                    <a href="#." className="el-btn-regular">View Courses</a>
                  </div>
                  */}
                </li>
              )
            })}
          </ul>{/* END SLIDES LIST */}
        </div>{/* END SLIDER CONTAINER */}
      </div >
    )
  }
}
export default FrontIndexSlider;
{/*
<li data-transition="random" data-title="Slide Title" data-param1="Additional Text" data-thumb="images/index/slider-02.jpg">
<div className="slider-overlay" />
<img alt="SmartPSP" src="/assets/images/slider-02.jpg"  className="rev-slidebg" />
<div className="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 header-1 title-line-1" data-x="left" data-hoffset={0} data-y="center" data-voffset={-140} data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:3000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, fontSize: '60px', color: '#fff', fontFamily: '"Montserrat", sans-serif', whiteSpace: 'nowrap', fontWeight: 700 }}>Better education for
     </div>
<div className="tp-caption sfr font-extra-bold tp-resizeme letter-space-4  header-1 title-line-2" data-x="left" data-hoffset={0} data-y="center" data-voffset={-80} data-frames="[{&quot;delay&quot;:1000,&quot;speed&quot;:3000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, fontSize: '60px', color: '#fff', fontFamily: '"Montserrat", sans-serif', whiteSpace: 'nowrap', fontWeight: 700 }}>A batter world
     </div>
<div className="tp-caption font-lora sfb tp-resizeme letter-space-5 header-p" data-x="left" data-hoffset={0} data-y="center" data-voffset={-10} data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:2000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:top;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 6, lineHeight: '25px', fontSize: '15px', color: '#fff', fontFamily: '"Open Sans", sans-serif', whiteSpace: 'nowrap' }}>Lorem ipsum dolor sit amet, consectetuer adipiscingl elit sed diam nonumm nibhy euismod<br /> tincidunt ut laoreet dolore magna aliquam erat volutpat.
     </div>
<div className="tp-caption lfb tp-resizeme header-btn" data-x="left" data-hoffset={0} data-y="center" data-voffset={90} data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:2000,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:bottom;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;auto:auto;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" style={{ zIndex: 8 }}><a href="#." className="el-btn-regular slider-btn-left">Get Started Now</a> <a href="#." className="el-btn-regular">View Courses</a>
</div>
</li>*/}