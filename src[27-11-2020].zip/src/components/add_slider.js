import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
//import ReactCrop from 'react-image-crop';
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { frontSliderActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const CREATE_SLIDER = `http://schools.rajpsp.com/api/front_slider/create.php`;

class AddSlider extends Component {
  state = {
    //main_image: "", // base64 data
    //main_image_name: "", //image Name
    title_1a: "",
    title_1b: "",
    sub_title: "",
    formIsHalfFilledOut: false,
    imageData: "",
    crop: {
      unit: "%",
      width: 30,
      aspect: 16 / 8
    },
    final_size: {
      width: 1680,
      height: 815
    }
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      imageData: data
    })
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Add this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler() {
    loadProgressBar();
    //e.preventDefault();
    const obj = {
      main_image: this.state.imageData,
      title_1a: this.state.title_1a,
      title_1b: this.state.title_1b,
      sub_title: this.state.sub_title
    }
    console.log(JSON.stringify(obj));
    this.props.createFrontSlider(obj);
    // axios.post(CREATE_SLIDER, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       imageData: "",
    //       title_1a: "",
    //       title_1b: "",
    //       sub_title: ""
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  /*
  handleFiles = (files) => {
    this.setState({
      main_image: files.base64,
      main_image_name: files.fileList[0].name
    })
  }*/
  // toggeleCreate = (event) => {
  //   event.preventDefault();
  //   this.props.toggeleCreate(event);
  // }
  render() {
    const { crop, imageData, final_size, title_1a, title_1b, sub_title, formIsHalfFilledOut } = this.state;
    const { user, frontSlider} = this.props;
    // console.log(this.state)
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Slider</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Slider
          </div>
          <div className="card-body">
            <div className="row">
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="control-label">Slidter Image
                      </label>
                  <div className="form-input">
                    <MyImage
                      //callbackFromParent={this.myCallback}
                      cropComplete={this.onComplete}
                      crop={crop}
                      final_size={final_size}
                    />
                    {imageData !== '' ?
                      <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + imageData} />
                      : null}
                  </div>
                </div>
              </div>
              <div className="col-sm-5">
                <div className="form-group">
                  <label className="control-label">First Line of Title
                        <span className="required"> * </span>
                  </label>
                  <div className="form-input">
                    <input type="text" name="title_1a"
                      placeholder="First Line of Title"
                      className="form-control form-control-sm"
                      value={title_1a}
                      onChange={event => this.changeHandler(event, 'title_1a')} />
                  </div>
                </div>

                <div className="form-group">
                  <label className="control-label">Second Line of Title
                        <span className="required"> * </span>
                  </label>
                  <div className="form-input">
                    <input type="text" name="title_1b"
                      placeholder="Second Line of Title"
                      className="form-control form-control-sm"
                      value={title_1b}
                      onChange={event => this.changeHandler(event, 'title_1b')} />
                  </div>
                </div>
              </div>
              <div className="col-sm-4">
                <div className="form-group">
                  <label className="control-label">Sub Title
                            <span className="required"> * </span>
                  </label>
                  <div className="form-input">
                    <textarea name="sub_title" placeholder="Sub Title"
                      className="form-control-textarea form-control" rows={4}
                      value={sub_title}
                      onChange={event => this.changeHandler(event, 'sub_title')} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-secondary mr-4">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontSlider } = state.frontSlider;
  return { user, frontSlider };
}

const actionCreators = {
  createFrontSlider: frontSliderActions.createFrontSlider,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddSlider));