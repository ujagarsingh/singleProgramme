import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { Nalvink } from 'react-router-dom';
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class AccountingVoucher extends Component {
	state = {
		formIsHalfFilledOut: false,
	}

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
			this.props.getAccLedgerEntry();
		}

		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}

		if (isEmptyObj(this.props.accGroup)) {
			this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		// this.checkFlag();
	}

	render() {
		return (
			<div className="page-content">
				<Helmet>
					<title>Accounting Voucher</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Accounting Voucher</div>
				</div>
				<div className="card card-box sfpage-cover">
					<div className="card-body p-1 sfpage-body">
						<div className="acc-page page-accounting-vouchers">
							<div className="acc-page-head container-fluid">
								<div className="sec-title">
									<div className="title-zone">Particulars</div>
									<div className="info-zone">
										<div className="info-zone">
											<table className="table table-bordered table-sm">
												<tbody>
													<tr>
														<td>
															<div className="dr-title">Debit</div>
														</td>
														<td>
															<div className="cr-title">Credit</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div className="acc-page-body container-fluid">
								<div className="av-detail-zone">
									<div className="av-detail-head">
										<div className="main-head">
											<div className="head-name"><span className="txt-normal">Cr</span> Alok 10nth</div>
											<div className="head-amount">
												<div className="dr-total">1,200.00</div>
												<div className="cr-total"></div>
											</div>
										</div>
										<div className="crnt-balance-head">
											<div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Cr</div>
										</div>
									</div>
									<div className="av-detail-head">
										<div className="main-head">
											<div className="head-name"><span className="txt-normal">Dr</span> Cash</div>
											<div className="head-amount">
												<div className="dr-total"></div>
												<div className="cr-total">600.00</div>
											</div>
										</div>
										<div className="crnt-balance-head">
											<div className="bal-head"><span className="txt-normal">Cur Bal :</span> 6,500 Dr</div>
										</div>
									</div>
									<div className="av-detail-head">
										<div className="main-head">
											<div className="head-name"><span className="txt-normal">Dr</span> State Bank of India</div>
											<div className="head-amount">
												<div className="dr-total"></div>
												<div className="cr-total">600.00</div>
											</div>
										</div>
										<div className="crnt-balance-head">
											<div className="bal-head"><span className="txt-normal">Cur Bal :</span> 5,000 Dr</div>
										</div>
									</div>
								</div>
							</div>
							<div className="acc-page-footer av-page-footer container-fluid">
								<div className="sec-foot">
									<div className="narration-zone">
										<div className="title">Narration:</div>
										<textarea className="form-control"></textarea>
									</div>
									<div className="amount-zone">
										<div className="dr-total">7,200.00</div>
										<div className="cr-total">7,200.00</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	return {
		user, students, accLedger, accGroup, accLedgerEntry,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,

}

export default connect(mapStateToProps, actionCreators)(withRouter(AccountingVoucher));