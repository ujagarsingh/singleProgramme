import React, { Component } from 'react';
import { withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class Backup extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Backup</title>
        </Helmet>

        <div className="page-bar d-flex">
              <div className="page-title">Backup</div>
            </div>
        <div className="card card-box sfpage-cover">
          <div className="card-head">
            <header>Backup</header>
          </div>
          <div className="card-body sfpage-body">
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(Backup);