
import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, examSdulNotesAction, examsCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class AddNewTest extends Component {
    state = {
        schools: [],
        school_id: "",
        medium_arr: [],
        medium: "",
        q_no: "",
        t_matks: "",
        sft_classes: [],
        filtered_classes: [],
        selected_class: '',
        class_subject_arr: [],
        filtered_class_sub: [],
        selected_subject: "",
        test_title: "",
        total_question: "",
        total_marks: "",
        test_start: "",
        test_end: "",
        qes_paper: [
            {
                "question": "",
                "answer": [
                    { "option": "", "is_right": false, },
                    { "option": "", "is_right": false, },
                    { "option": "", "is_right": false, },
                    { "option": "", "is_right": false, }
                ],
                "max_marks": "", "nagetive_marks": "",
            }
        ],
        formIsHalfFilledOut: false,
    };
    isEmpty(val) {
        return (val === undefined || val == null || val.length <= 0) ? true : false;
    }
    changeHandler = (event, fieldName, qIndex, isCheckbox) => {
        if (fieldName === 'question') {
            const _str = event.target.value;
            const _index = qIndex;
            const _questions = this.state.qes_paper;
            const finel_question = _questions.map((item, idx) => {
                if (idx === _index) {
                    item.question = _str;
                }
                return item;
            })

            this.setState({
                qes_paper: finel_question,
                formIsHalfFilledOut: true
            });
        } else if (fieldName === 'answer') {
            const _str = event.target.value;
            const inx_arr = qIndex.split('_');
            const _qes_inx = parseInt(inx_arr[0]);
            const _opt_inx = parseInt(inx_arr[1]);
            const _questions = this.state.qes_paper;
            const finel_question = _questions.map((item, inx) => {
                if (_qes_inx === inx) {
                    const _item_answer = item.answer.filter((ans_item, ans_idx) => {
                        if (ans_idx === _opt_inx) {
                            ans_item.option = _str;
                        }
                        return ans_item
                    })
                    item = { ...item, 'answer': _item_answer }
                }
                return item;
            })
            this.setState({
                qes_paper: finel_question,
                formIsHalfFilledOut: true
            });
        } else if (fieldName === 'max_marks') {
            const _str = event.target.value;
            const _index = qIndex;
            const _questions = this.state.qes_paper;
            const finel_question = _questions.map((item, idx) => {
                if (idx === _index) {
                    item.max_marks = _str;
                }
                return item;
            })

            this.setState({
                qes_paper: finel_question,
                formIsHalfFilledOut: true
            });
        } else if (fieldName === 'nagetive_marks') {
            const _str = event.target.value;
            const _index = qIndex;
            const _questions = this.state.qes_paper;
            const finel_question = _questions.map((item, idx) => {
                if (idx === _index) {
                    item.nagetive_marks = _str;
                }
                return item;
            })

            this.setState({
                qes_paper: finel_question,
                formIsHalfFilledOut: true
            });
        } else {
            this.setState({
                [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
                formIsHalfFilledOut: true
            });
        }
    }

    componentDidMount() {
        if (isEmptyObj(this.props.schools)) {
            this.props.getSchools();
        }
        if (isEmptyObj(this.props.examSdulNotes)) {
            this.props.getExamSdulNotes();
        }
        if (isEmptyObj(this.props.examsCategory)) {
            this.props.getExamsCategory();
        }
    }


    questionAdd(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        let finel_question = [];
        const _qes_pre = _questions.slice(0, index + 1);
        const _qes_next = _questions.slice(index + 1, _questions.length);
        const _qes_crnt = [{
            "question": "",
            "answer": [
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, }
            ],
            "max_marks": "", "nagetive_marks": "",
        }];
        finel_question = [..._qes_pre, ..._qes_crnt, ..._qes_next];
        this.setState({
            qes_paper: finel_question
        })
    }
    questionRemove(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const finel_question = _questions.filter((item, inx) => {
            if (index !== inx) {
                return item
            }
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    optioonAdd(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const inx_arr = index.split('_');
        const _qes_inx = parseInt(inx_arr[0]);
        const _opt_inx = parseInt(inx_arr[1]);
        const finel_question = _questions.map((item, inx) => {
            if (inx === _qes_inx) {
                let _ans_option = [];
                const _answer = item.answer;
                const _ans_pre = _answer.slice(0, _opt_inx + 1);
                const _ans_next = _answer.slice(_opt_inx + 1, _answer.length);
                const _ans_crnt = [{ "option": "", "is_right": false, }];
                _ans_option = [..._ans_pre, ..._ans_crnt, ..._ans_next];
                item = { ...item, "answer": _ans_option }
            }
            return item
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    optioonRemove(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const inx_arr = index.split('_');
        const _qes_inx = parseInt(inx_arr[0]);
        const _opt_inx = parseInt(inx_arr[1]);
        const finel_question = _questions.map((item, inx) => {
            if (_qes_inx === inx) {
                const _item_answer = item.answer.filter((ans_item, ans_idx) => {
                    if (ans_idx !== _opt_inx) {
                        return ans_item
                    }
                })
                item = { ...item, "answer": _item_answer }
                return item;
            }
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    textStartDate = (feeDate) => {
        this.setState({ test_start: feeDate });
    };
    textEndDate = (feeDate) => {
        this.setState({ test_end: feeDate });
    };
    render() {
        const { selected_school_index, medium_arr, medium,
            qes_paper, test_start, test_end, formIsHalfFilledOut } = this.state;
        const { user, schools, examSdulNotes, examsCategory } = this.props;
        console.log(this.state);
        return (
            <div className="page-content">
                <Helmet>
                    <title>Add New Test</title>
                </Helmet>
                <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
                {user && schools && examSdulNotes && examsCategory &&
                    <>
                        <div className="page-bar d-flex">
                            <div className="page-title">Add New Test</div>
                            <div className="form-inline ml-auto filter-panel">
                                <span className="filter-closer">
                                    <button type="button" className="btn btn-danger filter-toggler-c">
                                        <i className="fa fa-times"></i>
                                    </button>
                                </span>
                                <div className="filter-con">
                                    {(user.user_category === "1") ?
                                        <div className="form-group mr-2 mt-1">
                                            <label className="control-label mr-2">Schools :</label>
                                            <select className="form-control form-control-sm form-control form-control-sm-sm"
                                                required
                                                ref='school'
                                                value={selected_school_index}
                                                onChange={event => this.changeHandler(event, 'school')}>
                                                <option value="">Select ...</option>
                                                {schools.map((item, index) => {
                                                    return (
                                                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                                    )
                                                })}
                                            </select>
                                        </div>
                                        : null}
                                    <div className="form-group mr-2 mt-1">
                                        <label className="control-label mr-2">Medium :</label>
                                        <select className="form-control form-control-sm form-control form-control-sm-sm"
                                            required
                                            ref='medium'
                                            disabled={medium_arr.length > 1 ? false : true}
                                            value={medium}
                                            onChange={event => this.changeHandler(event, 'medium')}>
                                            <option value="">Select ...</option>
                                            {medium_arr.map((item, index) => {
                                                return (
                                                    <option key={index} value={item}>{item}</option>
                                                )
                                            })}
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card card-box sfpage-cover">
                            <div className="card-body sfpage-body">
                                <div className="table-scrollable">
                                    <div className="form-vertical col pt-1">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <div className="form-group d-flex">
                                                    <label className="mr-2 text-nowrap">Test Title</label>
                                                    <input type="text" className="form-control form-control-sm"
                                                        onChange={event => this.changeHandler(event, 'test_title')}
                                                        placeholder="Write Test Title" />
                                                </div>
                                            </div>
                                            <div className="col-sm-6">
                                                <div className="row">
                                                    <div className="form-group d-flex col">
                                                        <label className="mr-2 text-nowrap">No. of Question</label>
                                                        <input type="number" className="form-control form-control-sm"
                                                            onChange={event => this.changeHandler(event, 'total_question')}
                                                            placeholder="Total Questions" />
                                                    </div>
                                                    <div className="form-group d-flex col">
                                                        <label className="mr-2 text-nowrap">Total Marks</label>
                                                        <input type="number" className="form-control form-control-sm"
                                                            onChange={event => this.changeHandler(event, 'total_marks')}
                                                            placeholder="Totla Marks" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Class</label>
                                                <select className="form-control form-control-sm">
                                                    <option>Select..</option>
                                                    <option>First</option>
                                                </select>
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Subject</label>
                                                <select className="form-control form-control-sm">
                                                    <option>Select..</option>
                                                    <option>Hindi</option>
                                                </select>
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Show Date</label>
                                                <DatePicker
                                                    onChange={this.textStartDate}
                                                    value={test_start}
                                                    showLeadingZeroes={true}
                                                //minDate={new Date()}
                                                />
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Hide Date</label>
                                                <DatePicker
                                                    onChange={this.textEndDate}
                                                    value={test_end}
                                                    showLeadingZeroes={true}
                                                //minDate={new Date()}
                                                />
                                            </div>
                                        </div>
                                        {qes_paper.map((q_item, q_inx) => {
                                            return (
                                                <div key={q_inx} className="well bg-light border p-3 mb-2">
                                                    <div className="form-group">
                                                        <h6>{q_inx + 1}. Question </h6>
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <input type="test"
                                                                    className="form-control form-control-sm"
                                                                    placeholder="Write Question here..."
                                                                    value={q_item.question}
                                                                    onChange={event => this.changeHandler(event, 'question', q_inx)}
                                                                />
                                                            </div>
                                                            <div className="col-sm-6">
                                                                <h6>{q_item.question}</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="answer-options">
                                                        <h6>Answer</h6>
                                                        {q_item.answer.map((o_item, o_idx) => {
                                                            return (
                                                                <div key={o_idx} className="form-group">
                                                                    <div className="row">
                                                                        <div className="col-sm-6">
                                                                            <div className="input-group">
                                                                                <div className="input-group-prepend">
                                                                                    <span className="input-group-text p-1">{o_idx + 1}.</span>
                                                                                </div>
                                                                                <input type="test"
                                                                                    className="form-control form-control-sm"
                                                                                    placeholder={`Write option here...`}
                                                                                    value={o_item.option}
                                                                                    onChange={event => this.changeHandler(event, 'answer', q_inx + '_' + o_idx)}
                                                                                />
                                                                                <div className="input-group-append">
                                                                                    <button
                                                                                        type="button"
                                                                                        className="btn btn-danger btn-sm"
                                                                                        onClick={event => this.optioonRemove(event, q_inx + "_" + o_idx)}>
                                                                                        <i className="fa fa-minus"></i></button>
                                                                                    <button
                                                                                        type="button"
                                                                                        className="btn btn-warning btn-sm"
                                                                                        onClick={event => this.optioonAdd(event, q_inx + "_" + o_idx)}>
                                                                                        <i className="fa fa-plus"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div className="col-sm-6">
                                                                            <div className="custom-control custom-checkbox">
                                                                                <input type="checkbox" id="anscheckbox1" name="anscheckbox" className="custom-control-input" />
                                                                                <label className="custom-control-label" htmlFor="anscheckbox1">
                                                                                    {o_item.option}
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            )
                                                        })}
                                                        <div className="row">
                                                            <div className="col-sm-6 ml-auto">
                                                                <button type="button"
                                                                    className="btn btn-primary btn-sm mr-3"
                                                                    onClick={event => this.questionAdd(event, q_inx)}>
                                                                    Add More</button>
                                                                <button type="button"
                                                                    className="btn btn-outline-danger btn-sm"
                                                                    onClick={event => this.questionRemove(event, q_inx)}>
                                                                    Remove</button>
                                                            </div>
                                                            <div className="col-sm-3">
                                                                <div className="form-group m-0 d-flex">
                                                                    <label className="mr-2 text-nowrap">Max Marks</label>
                                                                    <input type="number" className="form-control form-control-sm"
                                                                        placeholder="Max Marks"
                                                                        onChange={event => this.changeHandler(event, 'max_marks', q_inx)} />
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-3">
                                                                <div className="form-group m-0 d-flex">
                                                                    <label className="mr-2 text-nowrap">Nagetive Marks</label>
                                                                    <input type="number" className="form-control form-control-sm"
                                                                        placeholder="Nagetive Marks"
                                                                        onChange={event => this.changeHandler(event, 'nagetive_marks', q_inx)} />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )
                                        })}
                                    </div>
                                </div>
                            </div>
                            <div className="card-footer d-flex p-2">
                                <button type="button" className="btn btn-primary ml-auto"
                                    onClick={event => this.saveInDatabase(event)}>
                                    Create</button>
                            </div>
                        </div>
                    </>
                }
            </div>
        )
    }
}
function mapStateToProps(state) {
    const { item: user } = state.authentication;
    const { item: schools } = state.schools;
    const { item: examSdulNotes } = state.examSdulNotes;
    const { item: examsCategory } = state.examsCategory;
    return { user, schools, examSdulNotes, examsCategory };
}

const actionCreators = {
    getSchools: schoolsAction.getSchools,
    getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
    getExamsCategory: examsCategoryAction.getExamsCategory,

}

export default connect(mapStateToProps, actionCreators)(withRouter(AddNewTest));
/*

import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { Helmet } from "react-helmet";

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class AddNewTest extends Component {
    state = {
        schools: [],
        school_id: "",
        medium_arr: [],
        medium: "",
        q_no: "",
        t_matks: "",
        sft_classes: [],
        filtered_classes: [],
        selected_class: '',
        class_subject_arr: [],
        filtered_class_sub: [],
        selected_subject: "",
        qes_paper: {
            children: [
                {
                    "question": "",
                    "answer": [
                        { "option": "", "is_right": false, },
                        { "option": "", "is_right": false, },
                        { "option": "", "is_right": false, },
                        { "option": "", "is_right": false, }
                    ],
                    "max_marks": "", "nagetive_marks": "",
                }
            ]
        },
        formIsHalfFilledOut: false,
    };
    isEmpty(val) {
        return (val === undefined || val == null || val.length <= 0) ? true : false;
    }
    changeHandler = (event, fieldName, isCheckbox) => {
        if (fieldName === 'select_subject') {
            const _subjectIdx = event.target.value;
        } else {
            this.setState({
                [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
                formIsHalfFilledOut: true
            });
        }
    }

    componentDidMount() {
        if (isEmptyObj(this.props.schools)) {
            this.props.getSchools();
        }
        if (isEmptyObj(this.props.examSdulNotes)) {
            this.props.getExamSdulNotes();
        }
        if (isEmptyObj(this.props.examsCategory)) {
            this.props.getExamsCategory();
        }
    }

    // checkAuthentication(obj) {
    //     loadProgressBar();
    //     axios.post(VALIDATE_URL, obj)
    //         .then(res => {
    //             const getRes = res.data;
    //             // sessionStorage.setItem("user", getRes.data);
    //             console.log(getRes);
    //             if (getRes.data) {
    //                 this.setState({
    //                     user: getRes.data,
    //                     group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //                     school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //                     user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //                     session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //                 }, () => {
    //                     this.getSchoolHandler();
    //                     this.getExamsCategories();
    //                     this.getSheduleNotes();
    //                 })
    //             }
    //         }).catch((error) => {
    //             this.props.history.push('/login.jsp');
    //         })
    // }

    // getSchoolHandler() {
    //     loadProgressBar();
    //     const obj = {
    //         group_id: this.state.group_id
    //     }
    //     axios.post(READ_SCHOOLS, obj)
    //         .then(res => {
    //             const getRes = res.data;
    //             this.setState({
    //                 schools: getRes,
    //                 errorMessages: getRes.message
    //             });
    //             // console.log(this.state);
    //         }).catch((error) => {
    //             // error
    //         })
    // }
    questionAdd(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        let finel_question = [];
        const _qes_pre = _questions.slice(0, index + 1);
        const _qes_next = _questions.slice(index + 1, _questions.length);
        const _qes_crnt = [{
            "question": "",
            "answer": [
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, },
                { "option": "", "is_right": false, }
            ],
            "max_marks": "", "nagetive_marks": "",
        }];
        finel_question = [..._qes_pre, ..._qes_crnt, ..._qes_next];
        this.setState({
            qes_paper: finel_question
        })
    }
    questionRemove(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const finel_question = _questions.filter((item, inx) => {
            if (index !== inx) {
                return item
            }
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    optioonAdd(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const inx_arr = index.split('_');
        const _qes_inx = parseInt(inx_arr[0]);
        const _opt_inx = parseInt(inx_arr[1]);
        const finel_question = _questions.map((item, inx) => {
            if (inx === _qes_inx) {
                let _ans_option = [];
                const _answer = item.answer;
                const _ans_pre = _answer.slice(0, _opt_inx + 1);
                const _ans_next = _answer.slice(_opt_inx + 1, _answer.length);
                const _ans_crnt = [{ "option": "", "is_right": false, }];
                _ans_option = [..._ans_pre, ..._ans_crnt, ..._ans_next];
                item = { ...item, "answer": _ans_option }
            }
            return item
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    optioonRemove(event, index) {
        event.preventDefault();
        const _questions = this.state.qes_paper;
        const inx_arr = index.split('_');
        const _qes_inx = parseInt(inx_arr[0]);
        const _opt_inx = parseInt(inx_arr[1]);
        const finel_question = _questions.map((item, inx) => {
            if (_qes_inx === inx) {
                const _item_answer = item.answer.filter((ans_item, ans_idx) => {
                    if (ans_idx !== _opt_inx) {
                        return ans_item
                    }
                })
                item = { ...item, "answer": _item_answer }
                return item;
            }
        })
        this.setState({
            qes_paper: finel_question
        })
    }
    textStartDate = (feeDate) => {
        this.setState({ test_start: feeDate });
    };
    textEndDate = (feeDate) => {
        this.setState({ test_end: feeDate });
    };
    render() {
        const { selected_school_index, medium_arr, medium,
            qes_paper, test_start, test_end, formIsHalfFilledOut } = this.state;
        const { user, schools, examSdulNotes, examsCategory } = this.props;
        console.log(this.state);
        return (
            <div className="page-content">
                <Helmet>
                    <title>Add New Test</title>
                </Helmet>
                <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
                {user && schools && examSdulNotes && examsCategory &&
                    <>
                        <div className="page-bar d-flex">
                            <div className="page-title">Add New Test</div>
                            <div className="form-inline ml-auto filter-panel">
                                <span className="filter-closer">
                                    <button type="button" className="btn btn-danger filter-toggler-c">
                                        <i className="fa fa-times"></i>
                                    </button>
                                </span>
                                <div className="filter-con">
                                    {(user.user_category === "1") ?
                                        <div className="form-group mr-2 mt-1">
                                            <label className="control-label mr-2">Schools :</label>
                                            <select className="form-control form-control-sm form-control form-control-sm-sm"
                                                required
                                                ref='school'
                                                value={selected_school_index}
                                                onChange={event => this.changeHandler(event, 'school')}>
                                                <option value="">Select ...</option>
                                                {schools.map((item, index) => {
                                                    return (
                                                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                                    )
                                                })}
                                            </select>
                                        </div>
                                        : null}
                                    <div className="form-group mr-2 mt-1">
                                        <label className="control-label mr-2">Medium :</label>
                                        <select className="form-control form-control-sm form-control form-control-sm-sm"
                                            required
                                            ref='medium'
                                            disabled={medium_arr.length > 1 ? false : true}
                                            value={medium}
                                            onChange={event => this.changeHandler(event, 'medium')}>
                                            <option value="">Select ...</option>
                                            {medium_arr.map((item, index) => {
                                                return (
                                                    <option key={index} value={item}>{item}</option>
                                                )
                                            })}
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card card-box sfpage-cover">
                            <div className="card-body sfpage-body">
                                <div className="table-scrollable">
                                    <div className="form-vertical col pt-1">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <div className="form-group d-flex">
                                                    <label className="mr-2 text-nowrap">Test Title</label>
                                                    <input type="text" className="form-control form-control-sm"
                                                        onChange={event => this.changeHandler(event, 'test_title')}
                                                        placeholder="Write Test Title" />
                                                </div>
                                            </div>
                                            <div className="col-sm-6">
                                                <div className="row">
                                                    <div className="form-group d-flex col">
                                                        <label className="mr-2 text-nowrap">No. of Question</label>
                                                        <input type="number" className="form-control form-control-sm"
                                                            onChange={event => this.changeHandler(event, 'total_question')}
                                                            placeholder="Total Questions" />
                                                    </div>
                                                    <div className="form-group d-flex col">
                                                        <label className="mr-2 text-nowrap">Total Marks</label>
                                                        <input type="number" className="form-control form-control-sm"
                                                            onChange={event => this.changeHandler(event, 'total_marks')}
                                                            placeholder="Totla Marks" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Class</label>
                                                <select className="form-control form-control-sm">
                                                    <option>Select..</option>
                                                    <option>First</option>
                                                </select>
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Subject</label>
                                                <select className="form-control form-control-sm">
                                                    <option>Select..</option>
                                                    <option>Hindi</option>
                                                </select>
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Show Date</label>
                                                <DatePicker
                                                    onChange={this.textStartDate}
                                                    value={test_start}
                                                    showLeadingZeroes={true}
                                                //minDate={new Date()}
                                                />
                                            </div>
                                            <div className="form-group d-flex col">
                                                <label className="mr-2 text-nowrap">Hide Date</label>
                                                <DatePicker
                                                    onChange={this.textEndDate}
                                                    value={test_end}
                                                    showLeadingZeroes={true}
                                                //minDate={new Date()}
                                                />
                                            </div>
                                        </div>
                                        {qes_paper.children.map((q_item, q_inx) => {
                                            return (
                                                <div key={q_inx} className="well bg-light border p-3 mb-2">
                                                    <div className="form-group">
                                                        <h6>{q_inx + 1}. Question </h6>
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <input type="test"
                                                                    className="form-control form-control-sm"
                                                                    placeholder="Write Question here..."
                                                                    value={q_item.question}
                                                                    onChange={event => this.changeHandler(event, 'question', q_inx)}
                                                                />
                                                            </div>
                                                            <div className="col-sm-6">
                                                                <h6>{q_item.question}</h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="answer-options">
                                                        <h6>Answer</h6>
                                                        {q_item.answer.map((o_item, o_idx) => {
                                                            return (
                                                                <div key={o_idx} className="form-group">
                                                                    <div className="row">
                                                                        <div className="col-sm-6">
                                                                            <div className="input-group">
                                                                                <div className="input-group-prepend">
                                                                                    <span className="input-group-text p-1">{o_idx + 1}.</span>
                                                                                </div>
                                                                                <input type="test"
                                                                                    className="form-control form-control-sm"
                                                                                    placeholder={`Write option here...`}
                                                                                    value={o_item.option}
                                                                                    onChange={event => this.changeHandler(event, 'answer', q_inx + '_' + o_idx)}
                                                                                />
                                                                                <div className="input-group-append">
                                                                                    <button
                                                                                        type="button"
                                                                                        className="btn btn-danger btn-sm"
                                                                                        onClick={event => this.optioonRemove(event, q_inx + "_" + o_idx)}>
                                                                                        <i className="fa fa-minus"></i></button>
                                                                                    <button
                                                                                        type="button"
                                                                                        className="btn btn-warning btn-sm"
                                                                                        onClick={event => this.optioonAdd(event, q_inx + "_" + o_idx)}>
                                                                                        <i className="fa fa-plus"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div className="col-sm-6">
                                                                            <div className="custom-control custom-checkbox">
                                                                                <input type="checkbox" id="anscheckbox1" name="anscheckbox" className="custom-control-input" />
                                                                                <label className="custom-control-label" htmlFor="anscheckbox1">
                                                                                    {o_item.option}
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            )
                                                        })}
                                                        <div className="row">
                                                            <div className="col-sm-6 ml-auto">
                                                                <button type="button"
                                                                    className="btn btn-primary btn-sm mr-3"
                                                                    onClick={event => this.questionAdd(event, q_inx)}>
                                                                    Add More</button>
                                                                <button type="button"
                                                                    className="btn btn-outline-danger btn-sm"
                                                                    onClick={event => this.questionRemove(event, q_inx)}>
                                                                    Remove</button>
                                                            </div>
                                                            <div className="col-sm-3">
                                                                <div className="form-group m-0 d-flex">
                                                                    <label className="mr-2 text-nowrap">Max Marks</label>
                                                                    <input type="number" className="form-control form-control-sm"
                                                                        placeholder="Max Marks"
                                                                        onChange={event => this.changeHandler(event, 'max_marks', q_inx)} />
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-3">
                                                                <div className="form-group m-0 d-flex">
                                                                    <label className="mr-2 text-nowrap">Nagetive Marks</label>
                                                                    <input type="number" className="form-control form-control-sm"
                                                                        placeholder="Nagetive Marks"
                                                                        onChange={event => this.changeHandler(event, 'nagetive_marks', q_inx)} />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )
                                        })}
                                    </div>
                                </div>
                            </div>
                            <div className="card-footer d-flex p-2">
                                <button type="button" className="btn btn-primary ml-auto"
                                    onClick={event => this.saveInDatabase(event)}>
                                    Create</button>
                            </div>
                        </div>
                    </>
                }
            </div>
        )
    }
}
*/