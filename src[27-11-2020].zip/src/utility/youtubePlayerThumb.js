import React, { Component } from 'react';
import YouTube from 'react-youtube';

class ReactYoutubePlayerThumb extends Component {
    // constructor(props) {
    //     super(props);
    // }

    videoOnReady(event) {
        // access to player in all event handlers via event.target
        event.target.pauseVideo();
        // event.target.playVideo();
        // console.log(event.target);
    }
    render() {
        const { videoId, videoClass } = this.props;
        const opts = {
            height: '390',
            width: '640',

            playerVars: {
                // https://developers.google.com/youtube/player_parameters
                autoplay: 0,
                rel: 0,
                // controls: 1
            },
        };

        return <YouTube
            videoId={videoId}                 // defaults -> null
            // id={string}                       // defaults -> null
            className={videoClass}                // defaults -> null
            // containerClassName={string}       // defaults -> ''
            opts={opts}                       // defaults -> {}
            onReady={this.videoOnReady}                   // defaults -> noop
        // onPlay={func}                     // defaults -> noop
        // onPause={func}                    // defaults -> noop
        // onEnd={func}                      // defaults -> noop
        // onError={func}                    // defaults -> noop
        // onStateChange={func}              // defaults -> noop
        // onPlaybackRateChange={func}       // defaults -> noop
        // onPlaybackQualityChange={func}    // defaults -> noop
        />;

    }

}

export default ReactYoutubePlayerThumb;