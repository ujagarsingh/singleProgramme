import { authenticConstants } from '../_constants';
import { authenticService } from '../_services';
import { toastr } from 'react-redux-toastr'; 
import { history } from '../_helpers';

export const authenticActions = {
    login,
    logout,
    validate
};

function login(user) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request( user ));

        authenticService.login(user)
            .then(
                response => {
                    sessionStorage.setItem('jwt', response.data.jwt);
                    history.push('/Dashboard.jsp');
                    dispatch(success(response.data.user_data));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request(user) { return { type: authenticConstants.LOGIN_REQUEST, user } }
    function success(user) { return { type: authenticConstants.LOGIN_SUCCESS, user } }
    function failure(error) { return { type: authenticConstants.LOGIN_FAILURE, error } }
}
 
function validate() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request( ));

        authenticService.validate()
            .then(
                response => {
                    dispatch(success(response));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: authenticConstants.VALIDATE_REQUEST } }
    function success(response) { return { type: authenticConstants.VALIDATE_SUCCESS, response } }
    function failure(error) { return { type: authenticConstants.VALIDATE_FAILURE, error } }
}
 

function logout() {
    authenticService.logout();
    return { type: authenticConstants.LOGOUT };
}
