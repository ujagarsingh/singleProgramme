import { groupConstants } from '../_constants';
import { groupService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const groupActions = {
    getGroup 
};

function getGroup() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        groupService.getGroup()
            .then(
                response => {
                    dispatch(success(response.data.group_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request(obj) { return { type: groupConstants.GROUP_REQUEST, obj } }
    function success(response) { return { type: groupConstants.GROUP_SUCCESS, response } }
    function failure(error) { return { type: groupConstants.GROUP_FAILURE, error } }
}
 