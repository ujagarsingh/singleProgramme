import { classStudentsExamDetailConstants } from '../_constants';
import { classStudentExamDetailService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classStudentExamDetailAction = {
    getClassStudentExamDetail
};

function getClassStudentExamDetail(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classStudentExamDetailService.getClassStudentExamDetail(obj)
            .then(
                response => {
                    dispatch(success(response.data.Class_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_REQUEST } }
    function success(response) { return { type: classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_SUCCESS, response } }
    function failure(error) { return { type: classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_FAILURE, error } }
}
 