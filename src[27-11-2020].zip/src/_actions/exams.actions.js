import { examsConstants } from '../_constants';
import { examsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examsAction = {
    getExams,
    create,
    update,
    delete: _delete
};

function getExams() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsService.getExams()
            .then(
                response => {
                    dispatch(success(response.data.exam_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsConstants.EXAMS_REQUEST } }
    function success(response) { return { type: examsConstants.EXAMS_SUCCESS, response } }
    function failure(error) { return { type: examsConstants.EXAMS_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item), toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsConstants.CREATE_REQUEST } }
    function success(response) { return { type: examsConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: examsConstants.CREATE_FAILURE, error } }
}


function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item), toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsConstants.UPDATE_REQUEST } }
    function success(response) { return { type: examsConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: examsConstants.UPDATE_FAILURE, error } }
}

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsConstants.DELETE_REQUEST } }
    function success(response) { return { type: examsConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: examsConstants.DELETE_FAILURE, error } }
}

