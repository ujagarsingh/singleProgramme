import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class User extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>User </title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title">User  List</div>

        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-head d-flex">
            <header>All User </header>
            <div className="ml-auto">
              <NavLink to="add_user_" className="btn btn-info">
                Add New <i className="fa fa-plus" />
              </NavLink>
            </div>
          </div>
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Category </th>
                    <th> Main Website </th>
                    <th> Student </th>
                    <th> Class </th>
                    <th> Teacher </th>
                    <th> Staff </th>
                    <th> Event Managment </th>
                    <th> Holiday </th>
                    <th> Fees </th>
                    <th> Marks </th>
                    <th> Backup </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                  <tr >
                    <td className="profile-pic">
                      <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} />
                    </td>
                    <td>Office Admin</td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td>
                      <NavLink to="edit_user_" className="btn btn-primary btn-sm">
                        Edit
                      </NavLink>
                      <button className="btn btn-danger btn-sm">
                        Del
                      </button>
                    </td>
                  </tr>
                  <tr >
                    <td className="profile-pic">
                      <img alt="SmartPSP"  src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                    </td>
                    <td>Office Staff</td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left" />
                    <td className="left" />
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left" />
                    <td className="left" />
                    <td>
                      <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                        Edit
                      </NavLink>
                      <button className="btn btn-danger btn-sm">
                        Del
                      </button>
                    </td>
                  </tr>
                  <tr >
                    <td className="profile-pic">
                      <img alt="SmartPSP"  src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                    </td>
                    <td>Teacher</td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"> </td>
                    <td>
                      <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                        Edit
                      </NavLink>
                      <button className="btn btn-danger btn-sm">
                        Del
                      </button>
                    </td>
                  </tr>
                  <tr >
                    <td className="profile-pic">
                      <img alt="SmartPSP"  src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                    </td>
                    <td>Student</td>
                    <td className="left"> </td>
                    <td className="left"><span className="label label-sm label-success">Yes</span></td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td className="left"> </td>
                    <td>
                      <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                        Edit
                      </NavLink>
                      <button className="btn btn-danger btn-sm">
                        Del
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(User);