import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
//import { Picky } from 'react-picky';
// import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
//import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { schoolsAction, sessionYearsAction } from '../_actions';
import { isEmptyObj } from '../utility/utilities';

import EditSchool from './edit_school';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/school/read_one.php`;

class SchoolInfo extends Component {
  state = {
    school_info: "",
    editItem: false,
  }
  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.sessionYears)) {
      this.props.getSessionYears();
    }
    this.getSchoolInfoHandler()
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.schools) {
      this.getSchoolInfoHandler();
    }
  }
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolInfoHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }


  getSchoolInfoHandler() {
    // debugger;
    const _schools = this.props.schools;
    const _user = this.props.user;
    const _selected_school = _schools.filter((item) => {
      if (item.id === _user.school_id) {
        return item
      }
    })
    this.setState({
      school_info: _selected_school[0]
    })

    // axios.post(READ_URL + `?id=` + school_id)
    //   .then(res => {
    //     const getRes = res.data.responceData;
    //     if (getRes) {
    //       this.setState({
    //         school_info: getRes
    //       });
    //     } else {
    //       Alert.error(res.data.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //     });
    //     }
    //   }).catch((error) => {
    //     // error
    //   })
  }

  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateSchoolHandler(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.schools.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  render() {
    const { school_info, editItem, selected_item } = this.state;
    const { user, schools, sessionYears } = this.props;
    console.log(this.state)
    return (
      <div className="page-content">
        <Helmet>
          <title>School Info</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title">School Info</div>
        </div>
        {school_info &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">
              {editItem ?
                <>
                  <EditSchool
                    selected_item={selected_item}
                    schools={schools}
                    sessionYears={sessionYears}
                    user={user}
                    updateHandlar={this.updateHandlar}
                    openEdit={this.openEdit}
                    closeEdit={this.closeEdit}
                  />
                  <div className="backdrop edit-mode"></div>
                </>
                :
                <div className="table-scrollable">
                  <div className="form-horizontal">
                    <div className="col-sm-12">
                      <div className="form-body">
                        <div className="row">
                          <div className="col-sm-6">
                            <div className="form-group row">
                              <label className="control-label col-md-4">School Name
                          </label>
                              <div className="col-md-8">
                                <h5 className="p-1">{school_info.sch_name}</h5>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Registration Number
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_reg_no}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Recognization Number
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_recog_no}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Contact No.
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_contact_num}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Mobile
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_mobile_num}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Email
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_email}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Head Office Address
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_address}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">Current Session Year
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.session_year_id}</h6>
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-4">School Medium
                          </label>
                              <div className="col-md-8">
                                <h6 className="p-1">{school_info.sch_medium}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-sm-4 ml-auto">
                            <div className="form-group row">
                              <label className="control-label col-md-6">School Logo</label>
                              <div className="col-md-6">
                                {school_info.sch_logo !== '' ?
                                  <img alt="OSM" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + school_info.sch_logo} />
                                  : null}
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-6">Admin Image</label>
                              <div className="col-md-6">
                                {school_info.admin_img !== '' ?
                                  <img alt="OSM" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + school_info.admin_img} />
                                  : null}
                              </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-6">Admin Sign</label>
                              <div className="col-md-6">
                                {school_info.admin_sign !== '' ?
                                  <img alt="OSM" className="img-thumbnail"
                                    src={`${process.env.PUBLIC_URL}` + school_info.admin_sign} />
                                  : null}
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              }
            </div>
            <div className="card-footer  text-right">
              {/* <NavLink to={`edit_school.jsp/${school_info.id}`} className="btn btn-primary mr-2">Edit</NavLink> */}
              <button className="btn btn-primary btn-sm mr-1"
                type="button"
                onClick={event => this.openEdit(event, school_info.id)}>Edit</button>
              <NavLink to="dashboard.jsp" className="btn  btn-sm btn-danger">Back</NavLink>
            </div>
          </div>
        }
      </div>
    )
  }
}


function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: sessionYears } = state.sessionYears;
  return { user, schools, sessionYears };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  updateSchoolHandler: schoolsAction.update,
  getSessionYears: sessionYearsAction.getSessionYears,
}

export default connect(mapStateToProps, actionCreators)(withRouter(SchoolInfo));