import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { classesAction, schoolsAction, feeCategoryAction, feeStructureAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_FEE_CWA = `http://schools.rajpsp.com/api/fee_category/read_one_by_cwa.php`;
// const CREATE_FEE_STRUCTURE = `http://schools.rajpsp.com/api/fee_amount/create.php`;
// const CLASSES_BY_MEDIUM = `http://schools.rajpsp.com/api/classes/read.php`;

class AddFeeDetails extends Component {
  state = {
    medium: '',
    fee_category: [],
    medium_arr: [],
    selected_classes: [],
    class_id: '',
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      // this.filterFeeStructureOnSchool(_sch_id);
      this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      const _fee_detail = this.state.fee_detail.filter((item) => {
        if (item.medium === _medium) {
          return item
        }
      });
      this.setState({
        display_fee_detail: _fee_detail,
        formIsHalfFilledOut: true
      })
    } else if (fieldName === 'class_id') {
      const _class_id = event.target.value;
      this.setState({
        class_id: _class_id
      }, () => {
        //  this.getFeeDetails()
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  }

  changeDyHandler = (event, fieldName, isCheckbox) => {
    //this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value })
    const _field = fieldName;
    const _value = event.target.value;
    const _fee_category = this.props.feeCategory.map((item) => {
      if (item.cat_name === _field) {
        item.fee_amount = _value;
      }
      return item
    })
    this.setState({
      fee_category: _fee_category
    })
  }
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      //selected_subjects: ''
    })
  }
  componentDidMount() {
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.feeCategory)) {
      this.props.getFeeCategory();
    }
  }
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           //this.getOneByOneFeeRecord();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getFeeDetails() {
  //   const obj = {
  //     class_id: this.state.class_id,
  //     medium: this.state.medium
  //   }
  //   this.props.feeCategory.map((item) => {

  //   })
  //   // axios.post(READ_FEE_CWA, obj)
  //   //   .then(res => {
  //   //     const resData = res.data;
  //   //     if (resData.message) {
  //   //       Alert.success(resData.message, {
  //   //         position: 'bottom-right',
  //   //         effect: 'jelly',
  //   //         timeout: 5000, offset: 40
  //   //       });
  //   //     } else {
  //   //       this.setState({
  //   //         fee_category: resData,
  //   //         temp_fee_category: resData,
  //   //       });
  //   //     }
  //   //     //console.log(this.state.fee_category);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })

  // };

  // getClassesByMedium() {
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   axios.post(CLASSES_BY_MEDIUM, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       if (getRes.message) {
  //         Alert.success(getRes.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //       } else {
  //         this.setState({
  //           classes: getRes
  //         })
  //       }
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Create this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler = e => {
    // loadProgressBar();
    e.preventDefault();
    let fee_amount_array = [];
    this.state.fee_category.map((item) => {
      if (!isEmpty(item.fee_amount)) {
        fee_amount_array.push({
          'fee_title': item.cat_name,
          'fee_amount': item.fee_amount,
          'fee_category_id': item.id
        });
      }
    })
    const obj = {
      school_id: this.state.school_id,
      medium: this.state.medium,
      class_id: this.state.class_id,
      fee_amount_array: fee_amount_array
    };

    // console.log(JSON.stringify(obj));
    this.props.create(obj);
    
    // axios.post(CREATE_FEE_STRUCTURE, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.feeStructure) {
  //     this.props.resetFeeStructure(this.state.school_id);
  //   }
  // }

  render() {
    const { medium, class_id, selected_classes, medium_arr, selected_school_index, formIsHalfFilledOut } = this.state;
    const { user, classes, schools, feeCategory } = this.props;
    console.log(this.state)
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Fee Details</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Fee Details
          </div>
          {user && classes && schools && feeCategory &&
            <div className="card-body">
              <div className="row">
                <div className="col-sm-4">
                    <div className="form-group d-flex">
                      <label className="control-label mr-2 mt-1 text-nowrap">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                    
                </div>
                <div className="col-sm-2">
                  <div className="form-group d-flex">
                    <label className="control-label mr-2 mt-1 text-nowrap">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                </div>
                <div className="col-sm-3">
                  {selected_classes.length > 0 ?
                    <div className="form-group d-flex">
                      <label className="control-label mr-2 mt-1 text-nowrap">Class Name
                        <span className="required"> * </span>
                      </label>
                      <select className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'class_id')}
                      >
                        <option value>Select...</option>
                        {selected_classes.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.class_name}</option>
                          )
                        })}
                      </select>
                    </div>
                    : null}
                </div>
              </div>

              {(class_id !== "") && medium !== '' ?
                <div className="row">
                  {feeCategory.map((item, index) => {
                    return (
                      <div key={index} className="col-sm-2">
                        <div className="form-group">
                          <label className="control-label">
                            {item.cat_name}
                            <span className="required"> * </span>
                          </label>
                          <div className="form-input">
                            <input type="number"
                              disabled={(item.cat_diff === "Different") ? true : false}
                              // placeholder="Rs"
                              // defaultValue={item.fee_amount}
                              defaultValue={""}
                              className="form-control form-control-sm"
                              onChange={event => this.changeDyHandler(event, `${item.cat_name}`)}
                            />
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
                : null}
            </div>
          }
          <div className="card-footer d-flex">
            <div className="alert p-2 mb-0 alert-danger mr-auto">
              <strong>Note :</strong> Add only one time Fee not Annually.
                    (Like : <b>One Month Fee</b> of Tution, <b>One Time Fee</b> of Exam Fee.) </div>
            <button type="submit" className="btn btn-secondary mr-2">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: classes } = state.classes;
  const { item: schools } = state.schools;
  const { item: feeCategory } = state.feeCategory;
  return { user, classes, schools, feeCategory };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
  getSchools: schoolsAction.getSchools,
  getFeeCategory: feeCategoryAction.getFeeCategory,
  create: feeStructureAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddFeeDetails));