import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, classExamSubjectAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddSubject from './add_subject';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_DETAILD_EXAM = `http://schools.rajpsp.com/api/exam/class_exam_subject.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
const CREATE_MAX_MARKS = `http://schools.rajpsp.com/api/exam/create_max_marks.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;


class SubjecteMaxMarks extends Component {
   state = {
      schools: [],
      school_id: '',
      selected_school_index: '',
      medium_arr: [],
      medium: '',
      classes: [],
      selected_classes: [],
      exams: [],
      detailed_exams: [],
      subjects: [],
      classwise_subject: [],
      selected_student: [],
      display_student_with_checked: [],
      selected_class_inx: '',
      selected_exam: '',
      display_max_marks: [],
      update_max_marks: [],
      selected_subject: '',
      selectAllStudentCheck: false,
      createItem: false,
      formIsHalfFilledOut: false,
   }

   changeHandler = (event, fieldName, isCheckbox) => {

      // if (fieldName === 'school') {
      //    const _inx = event.target.value;
      //    const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      //    const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      //    sessionStorage.setItem("school_id", _sch_id);
      //    this.filterExamsOnSchool(_sch_id, this.props.user.group_id);
      //    this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      //    this.setState({
      //       school_id: _sch_id,
      //       medium_arr: _medium,
      //       medium: (_medium.length === 1 ? _medium[0] : ''),
      //       selected_school_index: _inx,
      //       selected_class_inx: ''
      //    })
      // } else if (fieldName === 'medium') {
      //    const _medium = event.target.value;
      //    sessionStorage.setItem("medium", _medium);
      //    this.mediumHandler(_medium);
      // } else if (fieldName === 'selected_class') {
      //    //const _class_name = this.state.selected_classes[event.target.value].class_name;
      //    //this.filterDetaildExamClasswise(_class_name);
      //    const _class_inx = event.target.value;
      //    const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
      //    const _class_id = this.state.selected_classes[_class_inx].id;
      //    sessionStorage.setItem("class_name_portal", _class_name);
      //    this.setState({
      //       class_id: _class_id
      //    }, () => {
      //       this.filterDetaildExamClasswise(_class_inx);
      //       this.getDetaildExamHandler();
      //    })

      // } else
      
      if (fieldName === 'all_checks') {
         this.selectAllStudentHandler();
      } else if (fieldName === 'max_marks') {
         const _marks = event.target.value;
         if (_marks >= 0 && _marks <= 100) {
            const _class_id = event.target.getAttribute('data-cls-id');
            const _exam_id = event.target.getAttribute('data-exm-id');
            const _sub_id = event.target.getAttribute('data-sub-id');
            const _detailed_exams = this.state.detailed_exams.map((item) => {
               if (item.id === _class_id) {
                  item.exams.map((item_e) => {
                     if (item_e.id === _exam_id) {
                        item_e.subject.map((item_s) => {
                           if (item_s.id === _sub_id) {
                              item_s['max_marks'] = _marks
                           }
                        })
                     }
                  })
               }
               return item
            })
            // //console.log(JSON.stringify(_detailed_exams));
            this.setState({
               detailed_exams: _detailed_exams,
               formIsHalfFilledOut: true
            })
         }
      } else if (fieldName === 'max_marks_s') {
         // max marks of section
         const _marks = event.target.value;
         if (_marks >= 0 && _marks <= 100) {
            const _class_id = event.target.getAttribute('data-cls-id');
            const _exam_id = event.target.getAttribute('data-exm-id');
            const _sub_id = event.target.getAttribute('data-sub-id');
            const _sec_id = event.target.getAttribute('data-sec-id');
            const _detailed_exams = this.state.detailed_exams.map((item) => {
               if (item.id === _class_id) {
                  item.exams.map((item_e) => {
                     if (item_e.id === _exam_id) {
                        item_e.subject.map((item_s) => {
                           if (item_s.id === _sub_id) {
                              item_s.subject_sec.map((item_ss) => {
                                 if (item_ss.id === _sec_id) {
                                    item_ss['max_marks'] = _marks
                                 }
                              })
                           }
                        })
                     }
                  })
               }
               return item
            })
            // //console.log(JSON.stringify(_detailed_exams));
            this.setState({
               detailed_exams: _detailed_exams,
               formIsHalfFilledOut: true
            })
         }
      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            // formIsHalfFilledOut: true
         });
      }
   };
   filterExamsOnSchool(sch_id, group_id) {
      const _exams = this.props.classExamSubject.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         detailed_exams: _exams
      })
   }
   mediumHandler(_medium) {
      if (_medium !== '') {
         const _classes_medium = this.props.classes.filter((item, inx) => {
            if (item.medium === _medium) {
               return item
            }
         })
         this.setState({
            medium: _medium,
            selected_classes: _classes_medium,
            selected_class_inx: ''
         }, () => {
            // this.getDetaildExamHandler()
         })
      } else {
         this.setState({
            detailed_exams: ''
         })
      }
   }
   checkHandler = (event, fieldName, value) => {
      //debugger
      var _detailed_exams = '';
      let _current_select = value;
      if (fieldName === 'select_this') {
         _detailed_exams = this.state.detailed_exams.filter((item) => {
            if (_current_select === item.id) {
               item['checked'] = !item.checked;
               return item;
            }
            return item;
         })
      } else if (fieldName === 'select_all') {
         _detailed_exams = this.state.detailed_exams.map((item) => {
            item['checked'] = (event.target.checked) ? true : false;
            return item;
         })
      }
      //console.log(_detailed_exams);
      //console.log(this.state.update_max_marks)
      this.setState({
         update_max_marks: _detailed_exams
      }, () => {
         //console.log(this.state.update_max_marks)
      })

   };
   // filter exam list according to class
   filterDetaildExamClasswise(_class_inx) {
      const school_id = this.state.school_id;
      const group_id = this.props.user.group_id;
      const _class_idx = parseInt(_class_inx);
      const _class_name = this.state.selected_classes[_class_idx].class_name_portal;
      const _exams = this.state.exams.filter((item, index) => {
         if (item.class_name_portal === _class_name && item.group_id === group_id && item.school_id === school_id) {
            return item
         }
      })
      //console.log(JSON.stringify(_subects))
      this.setState({
         detailed_exams: _exams,
         selected_class_inx: _class_idx
      })
   }
   filterClassesOnSchool(sch_id, group_id) {
      const _classes = this.props.classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         selected_classes: _classes
      })
   }
   selectAllStudentHandler() {
      this.setState({
         selectAllStudentCheck: !this.state.selectAllStudentCheck
      })
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.classExamSubject)) {
         this.props.getClassExamSubject();
      }
      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         const _all_classExamSubject = this.props.classExamSubject;
         if (_all_classExamSubject && _filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   filterBySchoolHandler = () => {
      const _filter = this.props.filteredSchoolData;
      const _all_classExamSubject = this.props.classExamSubject;
      if (!isEmpty(_all_classExamSubject)) {
         const _school_classExamSubject = _all_classExamSubject.filter((item) => {
            if (_filter.slct_school_id) {
               if (item.school_id === _filter.slct_school_id) {
                  return item
               }
            } else {
               return item
            }
         })
         this.setState({
            detailed_exams: _school_classExamSubject,
         }, () => this.filterByClsHandler())
      }
   }

   filterByClsHandler = () => {
      const _fltr_school = this.props.filteredSchoolData;
      const _fltr_class = this.props.filteredClassesData;
      const _all_classExamSubject = this.props.classExamSubject;
      if (_all_classExamSubject) {
         const _school_classExamSubject = _all_classExamSubject.filter((item) => {
            if (!isEmpty(_fltr_class.slct_cls_name)) {
               if (item.school_id === _fltr_school.slct_school_id &&
                  item.stu_class === _fltr_class.slct_cls_name) {
                  return item
               }
            } else {
               if (item.school_id === _fltr_school.slct_school_id) {
                  return item
               }
            }
         })
         this.setState({
            detailed_exams: _school_classExamSubject
         })
      }
      // this.filterDetaildExamClasswise(_class_inx);
      this.getDetaildExamHandler();
   }


   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //                this.getClassesHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.props.user.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          ////console.log(this.props.classes);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // getClassesHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.props.user.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //    }
   //    console.log(JSON.stringify(obj));
   //    axios.post(READ_CLASS_URL, obj)
   //       .then(res => {
   //          const classes = res.data;
   //          this.setState({
   //             classes: classes,
   //             selected_classes: classes,
   //             errorMessages: res.data.message
   //          });
   //          //console.log(this.props.classes);
   //       }).catch((error) => {
   //          // error
   //       })
   // };

   getDetaildExamHandler() {
      const _fltr_school = this.props.filteredSchoolData;
      const _fltr_class = this.props.filteredClassesData;

      const _classExamsSubject = this.props.classExamSubject.filter((item) => {
         if (item.class_name_portal === _fltr_class.slct_cls_name && item.school_id === _fltr_school.slct_school_id) {
            return item
         }
      })
      this.setState({
         detailed_exams: _classExamsSubject,
      });

      // loadProgressBar();
      // const obj = {
      //    group_id: this.props.user.group_id,
      //    school_id: this.state.school_id,
      //    class_id: this.state.class_id
      // }
      // console.log(JSON.stringify(obj));
      // axios.post(GET_DETAILD_EXAM, obj)
      //    .then(res => {
      //       const resData = res.data;
      //       this.setState({
      //          exams: resData,
      //          detailed_exams: resData,
      //          errorMessages: resData.message
      //       });
      //       // console.log(resData);
      //    })
      //    .catch((error) => {
      //       // error
      //    });
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Submit this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler = () => { //id = class_id
      //e.preventDefault();
      var classdata = [];
      let obj = this.state.detailed_exams.filter((item) => {
         //if (item['id'] === id) {
         var counter = 0;
         //const _detailed_data = item.map((item) => {
         const _class = {
            class_id: item.id, class_name: item.class_name, class_name_portal: item.lass_name_portal,
            group_id: item.group_id, school_id: item.school_id
         }
         const _exam_id = item.exams.map((item) => {
            const _exams = { exam_id: item.id, exam_name: item.exam_name, exam_priority: item.exam_priority }
            const _sub_id = item.subject.map((item) => {
               const _mk_mm = Number(item.max_marks);
               const _subject = { sub_id: item.id, sub_name: item.sub_name, max_marks: _mk_mm }
               if (item.sub_lavel === '1' && _mk_mm > 0) {
                  classdata[counter] = { ..._exams, ..._class, sub_id: item.id, sub_name: item.sub_name, max_marks: _mk_mm }
                  counter++;
               } else {
                  const _sec_id = item.subject_sec.map((item) => {
                     const _mks_mm = Number(item.max_marks);
                     if (_mks_mm > 0) {
                        classdata[counter] = { ..._exams, ..._class, sub_id: item.id, sub_name: item.sub_name, max_marks: _mks_mm }
                        counter++;
                     }
                  })
               }
            })
         })
         //})
         //}
         //return classdata
      })
      const singleObj = { myObj: classdata };
      console.log(JSON.stringify(singleObj));

      loadProgressBar();
      axios.post(CREATE_MAX_MARKS, singleObj)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes);
            Alert.success(getRes.message, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })
   }
   // allSubmitHandler = (e) => {
   //    const obj = { myObj: this.state.detailed_exams };
   //    ////console.log(JSON.stringify(obj));
   //    e.preventDefault();
   //    loadProgressBar();
   //    axios.post(CREATE_MAX_MARKS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          //console.log(getRes);
   //          Alert.success(getRes.message, {
   //             position: 'bottom-right',
   //             effect: 'jelly',
   //             timeout: 5000, offset: 40
   //          });
   //       }).catch((error) => {
   //          //this.setState({ errorMessages: error });
   //       })
   // }
   toggeleCreate = (event) => {
      event.preventDefault();
      this.setState({
         createItem: !this.state.createItem
      })
   }
   render() {
      const { medium, selected_classes, selected_school_index, medium_arr,
         detailed_exams, selected_class_inx, formIsHalfFilledOut, createItem } = this.state;
      const { user, schools, classes, classExamSubject } = this.props;
      console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Subject Max Marks</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            {user && schools && classes && classExamSubject &&
               <>
                  <div className="page-bar d-flex">
                     <div className="page-title">Subject Max Marks</div>
                     <div className="form-inline  ml-auto">
                        {/* <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Schools :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='school'
                              value={selected_school_index}
                              onChange={event => this.changeHandler(event, 'school')}>
                              <option value="">Select ...</option>
                              {schools.map((item, index) => {
                                 return (
                                    <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                 )
                              })}
                           </select>
                        </div>
                        <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Medium :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='medium'
                              disabled={medium_arr.length > 1 ? false : true}
                              value={medium}
                              onChange={event => this.changeHandler(event, 'medium')}>
                              <option value="">Select ...</option>
                              {medium_arr.map((item, index) => {
                                 return (
                                    <option key={index} value={item}>{item}</option>
                                 )
                              })}
                           </select>
                        </div>
                        <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Class:</label>
                           <select
                              // disabled={medium === '' ? true : false}
                              value={selected_class_inx}
                              className="form-control form-control-sm" name="selected_class"
                              onChange={event => this.changeHandler(event, 'selected_class')} >
                              <option value="">Select...</option>
                              {selected_classes.map((option, index) => {
                                 return (<option key={index} value={index}>{option.class_name}</option>)
                              })}
                           </select>
                        </div> */}
                        <CommonFilters
                           showSchoolFilter={true}
                           showMediumFilter={false}
                           showClassFilter={true}
                           filterBySchoolHandler={this.filterBySchoolHandler}
                           filterByClsHandler={this.filterByClsHandler}
                        />

                     </div>
                  </div>
                  <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
                     {createItem ? <AddSubject
                        toggeleCreate={this.toggeleCreate} />
                        : null}
                     <div className="card-body sfpage-body">
                        <div className="table-scrollable">
                           <table className="table table-bordered table-sm">
                              <thead>
                                 <tr>
                                    {/* <th width="60">
                                 <div className="custom-control custom-checkbox">
                                    <input type="checkbox"
                                       id="select_all" className="custom-control-input"
                                       onChange={event => this.checkHandler(event, 'select_all', true)} />
                                    <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                                 </div>
                              </th> */}
                                    <th width="50">Sr.</th>
                                    <th width="150">Class Name</th>
                                    <th width="150">Exam Name</th>
                                    <th width="100">Subject</th>
                                    <th >Sub. Max Marks</th>
                                    {/* <th width="100">Action</th> */}
                                 </tr>
                              </thead>
                              <tbody>
                                 {(detailed_exams.length > 0) ? detailed_exams.map((item, index) => {
                                    return (
                                       <tr className={'odd gradeX'} key={index}>
                                          <td colSpan="7" className="p-0">
                                             <table className="table m-0 table-striped">
                                                <tbody>
                                                   <tr>
                                                      {/* <td width="60">
                                                   <div className="custom-control custom-control-inline custom-checkbox">
                                                      <input type="checkbox"
                                                         checked={item.checked}
                                                         id={`check_` + index} name="customRadio" className="custom-control-input"
                                                         onChange={event => this.checkHandler(event, `select_this`, item.id)} />
                                                      <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                                                   </div>
                                                </td> */}
                                                      <td width="50">{index + 1}</td>
                                                      <td wisth="100">{item.class_name} [{item.class_name_portal} ] </td>
                                                      <td colSpan="3"></td>
                                                      {/* <td width="100">
                                                   <div className="btn-group btn-group-toggle" data-toggle="buttons">
                                                      <button type="button" className="btn btn-secondary btn-sm"

                                                         onClick={event => this.singleSubmitHandler(event, item.id)}>
                                                         Update
                                                      </button>
                                                   </div>
                                                </td> */}
                                                   </tr>
                                                   <tr>
                                                      {/* <td width="50"></td> */}
                                                      <td width="50"></td>
                                                      <td width="150"></td>
                                                      <td className="p-0" colSpan="3">
                                                         {(item.exams.length > 0) ? item.exams.map((item_e, index_e) => {
                                                            return (
                                                               <table className="table table-striped m-0" key={index_e}>
                                                                  <tbody>
                                                                     <tr>
                                                                        <td width="150">{item_e.exam_name} </td>
                                                                        <td colSpan="2"></td>
                                                                     </tr>
                                                                     <tr>
                                                                        <td width="150"></td>
                                                                        <td rowSpan="2" className="p-0">
                                                                           {(item_e.subject.length > 0) ?
                                                                              item_e.subject.map((item_s, index) => {
                                                                                 return (
                                                                                    <table className="table m-0" key={index}>
                                                                                       <tbody>
                                                                                          <tr>
                                                                                             <td width="100">{item_s.sub_name} </td>
                                                                                             <td width="200" className={(item_s.sub_lavel === '1') ?
                                                                                                (item_s.max_marks != '0' || item_s.max_marks != '' ? 'table-success' : 'table-danger') : null}>
                                                                                                {(item_s.sub_lavel === '1') ?
                                                                                                   <input type="number"
                                                                                                      data-cls-id={item.id}
                                                                                                      data-exm-id={item_e.id}
                                                                                                      data-sub-id={item_s.id}
                                                                                                      className="form-control form-control-sm"
                                                                                                      value={item_s.max_marks}
                                                                                                      onChange={event =>
                                                                                                         this.changeHandler(event, 'max_marks')} />
                                                                                                   : null}

                                                                                                {(item_s.subject_sec.length > 0) ?
                                                                                                   item_s.subject_sec.map((item_s_s, index_ss) => {
                                                                                                      return (
                                                                                                         <table className="table m-0" key={index_ss}>
                                                                                                            <tbody>
                                                                                                               <tr>
                                                                                                                  <td width="100">{item_s_s.sub_name} </td>
                                                                                                                  <td width="100" className={(item_s_s.max_marks != '0' ||
                                                                                                                     item_s_s.max_marks != '' ? 'table-success' : 'table-danger')}>
                                                                                                                     <input type="number"
                                                                                                                        data-cls-id={item.id}
                                                                                                                        data-exm-id={item_e.id}
                                                                                                                        data-sub-id={item_s.id}
                                                                                                                        data-sec-id={item_s_s.id}
                                                                                                                        className="form-control form-control-sm"
                                                                                                                        value={item_s_s.max_marks}
                                                                                                                        onChange={event =>
                                                                                                                           this.changeHandler(event, 'max_marks_s')} />
                                                                                                                  </td>
                                                                                                               </tr>
                                                                                                            </tbody>
                                                                                                         </table>
                                                                                                      )
                                                                                                   }) : null}
                                                                                             </td>
                                                                                          </tr>
                                                                                       </tbody>
                                                                                    </table>
                                                                                 )
                                                                              }) : 'Subject not found !!'}
                                                                        </td>
                                                                     </tr>
                                                                  </tbody>
                                                               </table>
                                                            )
                                                         }) : null}
                                                      </td>
                                                      {/* <td></td> */}
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </td>
                                       </tr>
                                    )
                                 }) : null}
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div className="card-footer d-flex">
                        {createItem ?
                           <button onClick={event => this.toggeleCreate(event)}
                              className="btn btn-danger btn-sm ">
                              Cancel</button>
                           :
                           <button onClick={event => this.toggeleCreate(event)}
                              className="btn btn-primary btn-sm">
                              Add New Subjct </button>
                        }
                        {/* <NavLink to="/add_subject.jsp" className="btn btn-success btn-sm">
                           Add Subject
                  </NavLink> */}
                        <span className="p-2">1. If Subject Have Marks Insert otherwise stay with blank.</span>
                        <button type="submit"
                           disabled={!formIsHalfFilledOut}
                           className="btn btn-primary ml-auto mr-1">Update</button>
                        <NavLink to="#" className="btn btn-secondary">Reset</NavLink>
                     </div>
                  </form>
               </>
            }
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: classExamSubject } = state.classExamSubject;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, classes, classExamSubject,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getClassExamSubject: classExamSubjectAction.getClassExamSubject,
}

export default connect(mapStateToProps, actionCreators)(withRouter(SubjecteMaxMarks));