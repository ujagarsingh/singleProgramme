import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultEventsActions } from '../_actions';

class FrontIndexEvents extends Component {
   state = {
      event_arr: [],
      formIsHalfFilledOut: false,
   }
   componentDidMount() {
      if (isEmptyObj(this.props.defaultEvents)) {
         this.props.getDefaultEvents();
      }
   };

   render() {
      const { defaultEvents } = this.props;
      //console.log(_state);
      return (
         <section className="events_sec sec_panel bg-lightGray">
            <div className="sec_inner">
               <div className="container">
                  <div className="section_header event_header">
                     <h2>Upcoming Events</h2>
                  </div>
                  {defaultEvents && 
                  <div className="row">
                     {defaultEvents.map((item, index) => {
                        if (item.type === 'Event') {
                           return (
                              <div key={index} className="mb-4 col-sm-6">
                                 <div className="event_single ">
                                    <div className="row">
                                       <div className="col-lg-5">
                                          <div className="event_img">
                                             {item.event_img !== '' ?
                                                < img src={`${process.env.PUBLIC_URL}`+item.event_img} alt={item.title} className="img-responsive" />
                                                : <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/event.jpg`} alt={item.title} className="img-responsive" />
                                             }
                                          </div>
                                       </div>
                                       <div className="col-lg-7">
                                          <div className="event-info">
                                             <h5>{item.title}</h5>
                                             <p className="event_time">
                                                <span>
                                                   <i className="fa fa-calendar" />
                                                   {item.date_start}
                                                </span>
                                             </p>
                                          </div>
                                       </div>
                                       <div className="col">
                                          <div className="card-body p-2 m-2">
                                             <p className="pb-1">{item.description}</p>
                                             <NavLink className="event-btn d-none" to="/">Read More<i className="fa fa-long-arrow-right" /></NavLink>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           )
                        }
                        else {
                           return null
                        }
                     })}
                  </div>
               }
               </div>
            </div>
         </section>
      )
   }
}

function mapStateToProps(state) {
   const { item: defaultEvents } = state.defaultEvents;
   return { defaultEvents };
}

const actionCreators = {
   getDefaultEvents: defaultEventsActions.getDefaultEvents,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexEvents));
