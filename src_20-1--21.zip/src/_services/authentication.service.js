// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const authenticService = {
    login,
    logout,
    validate
};

function login(obj) {
    loadProgressBar();
    const url = USER_URL + 'login/login.php';
    return Axios.post(url, obj).then()
}

function validate() {
    loadProgressBar();
    const url = USER_URL + 'login/validate_token.php';
    return Axios.post(url, authHeader()).then();
}

function logout() {
    loadProgressBar();
    // remove user from local storage to log user out
    sessionStorage.removeItem('jwt');
    sessionStorage.clear();
    localStorage.clear();
}



Axios.interceptors.request.use(request => {
    request.headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
    // request.headers["Access-Control-Allow-Origin"] = "*";
    // console.log(request);
    return request;
}, error => {
    // console.log(error);
    return Promise.reject(error)
})
Axios.interceptors.response.use(response => {
    // console.log(response);
    return response;
}, error => {
    // console.log(error);
    return Promise.reject(error)
})
