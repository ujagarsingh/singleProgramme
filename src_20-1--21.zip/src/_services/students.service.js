// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const studentsService = {
    getStudents,
    create
};

function getStudents() {
    loadProgressBar();
    const url = USER_URL + 'students/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'students/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}
