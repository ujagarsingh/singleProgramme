import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { store } from "./_helpers/index";
import * as serviceWorker from './serviceWorker';

import App from './App';

// mandatory
import 'react-s-alert/dist/s-alert-default.css';

// optional - you can choose the effect you want
import 'react-s-alert/dist/s-alert-css-effects/slide.css';
import 'react-s-alert/dist/s-alert-css-effects/scale.css';
import 'react-s-alert/dist/s-alert-css-effects/bouncyflip.css';
import 'react-s-alert/dist/s-alert-css-effects/flip.css';
import 'react-s-alert/dist/s-alert-css-effects/genie.css';
import 'react-s-alert/dist/s-alert-css-effects/jelly.css';
import 'react-s-alert/dist/s-alert-css-effects/stackslide.css';

// toastr using redux
import 'react-redux-toastr/lib/css/react-redux-toastr.min.css';
import ReduxToastr from 'react-redux-toastr'

// fancy image Crop design
import 'react-image-crop/dist/ReactCrop.css';

// fancy alert box design
import 'react-confirm-alert/src/react-confirm-alert.css';

// axios progressbar
import 'axios-progress-bar/dist/nprogress.css';



ReactDOM.render(
      <Provider store={store}>
            <BrowserRouter>
                  <App />
                  <ReduxToastr
                        timeOut={4000}
                        newestOnTop={false}
                        preventDuplicates
                        position="bottom-left"
                        getState={(state) => state.toastr} // This is the default
                        transitionIn="bounceIn"
                        transitionOut="bounceOut"
                        progressBar={true}
                        closeOnToastrClick />
            </BrowserRouter>
      </Provider>
      , document.getElementById('root'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
