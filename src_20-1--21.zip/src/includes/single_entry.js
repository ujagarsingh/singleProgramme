import React, { Component } from 'react';
import { withRouter } from 'react-router';

import { isEmpty } from '../utility/utilities';

class SingleEntry extends Component {

  ledgerListHandler = (event, indexNo) => {
    // debugger
    const ldr_list = event.target.getAttribute('data-type');
    const ldr_val = event.target.value;
    if (ldr_list === "CR") {
      const _inx = this.props.credit_ledgers.findIndex((item) => item.ledger_name === ldr_val);
      const obj = {
        filter_data: this.props.credit_ledgers,
        current_inx: indexNo,
        cursor: _inx,
      }
      this.props.ledgerListHandler(obj);
    } else if (ldr_list === "DR") {
      const _inx = this.props.debit_ledgers.findIndex((item) => item.ledger_name === ldr_val);
      const obj = {
        filter_data: this.props.debit_ledgers,
        current_inx: indexNo,
        cursor: _inx,
      }
      this.props.ledgerListHandler(obj);
    }
  }
  blurHandler = (event, fieldName, isCheckbox, indexNo, inputType) => {
    const _val = event.target.value;
    if (fieldName === 'ldr_type') {
      if (_val === "Cr" || _val === "CR" || _val === "Dr" || _val === "DR") {

      } else {
        //  event.target.focus();
      }
    } else if (fieldName === 'ldr_name') {
      if (isEmpty(_val)) {
        // event.target.focus();
      } else {
        const data = [];
        this.props.setFilteredDataHandler(data);
      }
    } else if (fieldName === 'ldr_amo') {
      if (isEmpty(_val)) {
        // event.target.focus();
      } else {
        // this.calculateANDautofillAmountHandler(event, fieldName, isCheckbox, indexNo, inputType);
      }
    }
  };
  render() {
    const { eIndex, eItem } = this.props;
    console.log(this.props)
    return (
      <div className="av-detail-head">
        <div className="main-head" >
          <div className="head-name d-flex">
            <span className="txt-normal mr-2">
              <input type="text"
                value={eItem.tr_type}
                disabled={(eIndex === 0) ? true : false}
                data-index={eIndex}
                maxLength="2"
                className="form-control trans-input tr-type form-control-sm"
                onChange={event => this.props.changeHandler(event, `ldr_type`, null, eIndex)}
                onBlur={event => this.blurHandler(event, `ldr_type`, null, eIndex)}
              />
            </span>
            <input type="text"
              value={eItem.ledger_name}
              data-type={eItem.tr_type}
              className="form-control trans-input tr-name form-control-sm"
              onChange={event => this.props.changeHandler(event, `ldr_name`, null, eIndex)}
              onFocus={event => this.ledgerListHandler(event, eIndex)}
              onBlur={event => this.blurHandler(event, `ldr_name`, null, eIndex)}
            />
          </div>
          <div className="head-amount">
            <div className="dr-total">
              {(eItem.tr_type == "CR") ?
                <input type="number"
                  value={eItem.tr_amount}
                  className="form-control trans-input tr-amount form-control-sm"
                  onChange={event => this.props.changeHandler(event, `ldr_amo`, null, eIndex, `CR`)}
                  onBlur={event => this.blurHandler(event, `ldr_amo`, null, eIndex, `CR`)}
                />
                : null}
            </div>
            <div className="cr-total">
              {(eItem.tr_type == "DR") ?
                <input type="number"
                  value={eItem.tr_amount}
                  className="form-control trans-input tr-amount form-control-sm"
                  onChange={event => this.props.changeHandler(event, `ldr_amo`, null, eIndex, `DR`)}
                  onBlur={event => this.blurHandler(event, `ldr_amo`, null, eIndex, `DR`)}
                />
                : null}
            </div>
          </div>
        </div>
        <div className="crnt-balance-head">
          <div className="bal-head"><span className="txt-normal">Cur Bal :</span> {eItem.ldr_ref_id}</div>
        </div>
        {eItem.adjustment &&
          <div className="adjestment-head">
            <div className="adjt-head">
              <span className="ref-type">New Ref</span>
              <span className="ref-no">10</span>
              <span className="tr-amount">10,000</span>
              <span className="tr-type">Cr</span>
            </div>
          </div>
        }
        {eItem.cost_center &&
          <div className="adjestment-head">
            <div className="adjt-head">
              <span className="ref-type">Cost Center</span>
              <span className="ref-no">10</span>
              <span className="tr-amount">10,000</span>
              <span className="tr-type">Cr</span>
            </div>
          </div>
        }
      </div>

    )
  }
}
export default withRouter(SingleEntry);

