import { subjectsConstants } from '../_constants';
import { subjectsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const subjectsAction = {
    getSubjects, 
    create,
    delete : _delete
};

function getSubjects() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        subjectsService.getSubjects()
            .then(
                response => {
                    dispatch(success(response.data.sub_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: subjectsConstants.SUBJECTS_REQUEST } }
    function success(response) { return { type: subjectsConstants.SUBJECTS_SUCCESS, response } }
    function failure(error) { return { type: subjectsConstants.SUBJECTS_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        subjectsService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: subjectsConstants.CREATE_REQUEST } }
    function success(response) { return { type: subjectsConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: subjectsConstants.CREATE_FAILURE, error } }
}

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        subjectsService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: subjectsConstants.DELETE_REQUEST } }
    function success(response) { return { type: subjectsConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: subjectsConstants.DELETE_FAILURE, error } }
}
