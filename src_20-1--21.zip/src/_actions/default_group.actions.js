import { defaultGroupConstants } from '../_constants';
import { defaultGroupService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultGroupActions = {
    getDefaultGroup 
};

function getDefaultGroup() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultGroupService.getDefaultGroup()
            .then(
                response => {
                    dispatch(success(response.data.group_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultGroupConstants.GROUP_REQUEST } }
    function success(response) { return { type: defaultGroupConstants.GROUP_SUCCESS, response } }
    function failure(error) { return { type: defaultGroupConstants.GROUP_FAILURE, error } }
}
 