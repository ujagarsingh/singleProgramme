import { marksObtainConstants } from '../_constants';
import { marksObtainService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const marksObtainAction = {
    getMarksObtain,
    createMultiple
};

function getMarksObtain() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        marksObtainService.getMarksObtain()
            .then(
                response => {
                    dispatch(success(response.data.mark_obtain));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: marksObtainConstants.MARKS_OBTAIN_REQUEST } }
    function success(response) { return { type: marksObtainConstants.MARKS_OBTAIN_SUCCESS, response } }
    function failure(error) { return { type: marksObtainConstants.MARKS_OBTAIN_FAILURE, error } }
}


function createMultiple(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        marksObtainService.createMultiple(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.mark_obtain),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_REQUEST } }
    function success(response) { return { type: marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_SUCCESS, response } }
    function failure(error) { return { type: marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_FAILURE, error } }
}
