import { feeCategoryStructureConstants } from '../_constants';
import { feeCategoryStructureService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeCategoryStructureAction = {
    getFeeCategoryStructure
};

function getFeeCategoryStructure(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeCategoryStructureService.getFeeCategoryStructure(obj)
            .then(
                response => {
                    dispatch(success(response.data.fee_cat_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_REQUEST } }
    function success(response) { return { type: feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_SUCCESS, response } }
    function failure(error) { return { type: feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_FAILURE, error } }
}
