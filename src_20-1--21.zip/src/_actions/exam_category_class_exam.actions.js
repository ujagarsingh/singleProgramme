import { examCategoryClassExamConstants } from '../_constants';
import { examCategoryClassExamService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examCategoryClassExamAction = {
    getExamCategoryClassExam
};

function getExamCategoryClassExam() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examCategoryClassExamService.getExamCategoryClassExam()
            .then(
                response => {
                    dispatch(success(response.data.exam_cate_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_REQUEST } }
    function success(response) { return { type: examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_SUCCESS, response } }
    function failure(error) { return { type: examCategoryClassExamConstants.EXAM_CATEGORY_CLASS_EXAM_FAILURE, error } }
}
