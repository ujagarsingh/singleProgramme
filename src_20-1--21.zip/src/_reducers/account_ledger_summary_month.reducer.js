import { accountLedgerSummaryMonthConstants } from '../_constants';

export function accountLedgerSummaryMonth(state = {}, action) {
  switch (action.type) {
    
    case accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_SUCCESS:
      // const new_month_obj = { ...state.item, ledger_summary_of_month: action.response, single_voucer: "" };
      return {
        item: action.response,
        loading: false,
      };
    case accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}