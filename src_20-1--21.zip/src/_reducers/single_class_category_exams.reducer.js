import { singleClassCategoryExamsConstants } from '../_constants';

export function singleClassCategoryExams(state = {}, action) {
  switch (action.type) {
    case singleClassCategoryExamsConstants.SINGLE_CCE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case singleClassCategoryExamsConstants.SINGLE_CCE_SUCCESS:
      return {
        item: action.response
      };
    case singleClassCategoryExamsConstants.SINGLE_CCE_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}