import React, { Component } from 'react';
import { withRouter } from 'react-router';

class FilteredDataList extends Component {
  
  componentDidMount() {
    
  }
  render() {
    const { cursor, filter_data } = this.props;
    // console.log(this.props)
    return (
      <div className="list-accunts">
        <div className="list-acc-head">List of Ledger Accunts</div>
        <div className="list-acc-body" id="ldrList">
          <ul>
            {filter_data.map((item, index) => {
              return (
                <li
                  className={cursor === index ? 'active' : null}
                  key={index}>
                  {item.ledger_name}
                </li>
              )
            })}
          </ul>
        </div>
        <div className="list-acc-footer">more...</div>
      </div>
    )
  }
}
export default withRouter(FilteredDataList);

