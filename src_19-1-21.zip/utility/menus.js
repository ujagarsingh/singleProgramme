const Menus =
{
  "type": [
    {
      "image": "/assets/images/dp.jpg",
      "name": "Supper Admin",
      "param": false,
      "children": [
        {
          "icon": "fas fa-suitcase",
          "name": "Dashboard",
          "param": false,
          "link": "/dashboard.jsp",
          "children": []
        },
        {
          "icon": "fas fa-umbrella-beach",
          "name": "Holiday Calendar",
          "param": false,
          "link": "/holiday_calendar.jsp",
          "children": []
        },
        {
          "icon": "fas fa-umbrella-beach",
          "name": "Accounts",
          "param": true,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Balance Sheet",
              "param": false,
              "link": "/balance_sheet.jsp",
              "children": [],
            },
            // {
            //   "icon": "",
            //   "name": "Payment List ",
            //   "param": false,
            //   "link": "/payment_list.jsp",
            //   "children": [],
            // },
            // {
            //   "icon": "",
            //   "name": "Income List ",
            //   "param": false,
            //   "link": "/income_list.jsp",
            //   "children": [],
            // }
          ]
        },
        {
          "icon": "fas fa-user-graduate",
          "name": "Students",
          "param": false,
          "link": "",
          "children": [
            /*{
              "icon": "",
              "name": "Portal Data",
              "param":false,
              "link": "/portal_students.jsp",
              "children": [],
            },*/
            {
              "icon": "",
              "name": "All Recods",
              "param": false,
              "link": "/all_students.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Add New Student",
              "param": false,
              "link": "/add_student.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fas fa-user-tie",
          "name": "Professional",
          "param": false,
          "link": "/all_professionals.jsp",
          "children": []
        },
        {
          "icon": "fas fa-receipt",
          "name": "Fees/ Transpoart",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Fees Collection",
              "param": false,
              "link": "/fees_collection.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Get Fees",
              "param": false,
              "link": "/get_fees.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Fee Receipt",
              "param": false,
              "link": "/fees_receipt.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fa fa-address-card",
          "name": "Report Card",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Marks Class wise",
              "param": false,
              "link": "/all_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Add Marks Subject wise",
              "param": false,
              "link": "/add_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Excel to Update",
              "param": false,
              "link": "/excel_to_update.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Report Card",
              "param": false,
              "link": "/get_marks_sheet.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fa fa-calendar",
          "name": "Print Shedule",
          "param": false,
          "link": "/print_shedule.jsp",
          "children": []
        },
        {
          "icon": "fa fa-cog",
          "name": "Settings",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "fa fa-desktop",
              "name": "Main Website",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "Main Slider",
                  "param": false,
                  "link": "/all_slider.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Main Ariticle",
                  "param": false,
                  "link": "/all_article.jsp",
                  "children": [],
                }
              ],
            },
            {
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Galleries",
                  "param": false,
                  "link": "/all_galleries.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Images",
                  "param": false,
                  "link": "/all_images.jsp",
                  "children": [],
                }
              ],
              "icon": "fa fa-images",
              "name": "Image Gallery",
              "param": false,
              "link": ""
            },
            {
              "icon": "fas fa-file-excel",
              "name": "Upload Excel",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "Upload Students",
                  "param": false,
                  "link": "/upload_students.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Upload Staff",
                  "param": false,
                  "link": "/upload_staff.jsp",
                  "children": [],
                }
              ],
            },
            {
              "icon": "las la-rupee-sign",
              "name": "Accounts",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Groups",
                  "param": false,
                  "link": "/all_acc_group.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Ledger",
                  "param": false,
                  "link": "/all_acc_ledger.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "fab fa-gripfire",
              "name": "Fee Manager",
              "param": false,
              "link": "",
              "children": [
                {
                  "children": [
                    {
                      "icon": "fa fa-caret-right",
                      "name": "Category",
                      "param": false,
                      "link": "/all_type_n_time.jsp",
                      "children": [],
                    },
                    {
                      "icon": "fa fa-caret-right",
                      "name": "Structrue",
                      "param": false,
                      "link": "/all_fee_structure.jsp",
                      "children": [],
                    }
                  ],
                  "icon": "fas fa-rupee-sign",
                  "name": "Fee",
                  "param": false,
                  "link": ""
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Transpoart",
                  "param": false,
                  "link": "/all_transpoart_root.jsp",
                  "children": [],
                }
              ],
            },
            {
              "icon": "fas fa-school",
              "name": "Affiliated Schools",
              "param": false,
              "link": "/all_schools.jsp",
              "children": [],
            },
            {
              "icon": "fas fa-chalkboard-teacher",
              "name": "Lesson",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Lesson",
                  "param": false,
                  "link": "/all_lesson.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Add Lesson",
                  "param": false,
                  "link": "/add_lesson.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "fas fa-chalkboard-teacher",
              "name": "Class",
              "param": false,
              "link": "/all_class.jsp",
              "children": [],
            },
            {
              "icon": "fa fa-file-alt",
              "name": "All E-Test",
              "param": false,
              "link": "/all_e_test.jsp",
              "children": [],
            },
            {
              "icon": "fab fa-buffer",
              "name": "Exams / Subject",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Exams",
                  "param": false,
                  "link": "/all_exam.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Subject",
                  "param": false,
                  "link": "/all_subject.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Add/Update Max Marks",
                  "param": false,
                  "link": "/subject_max_marks.jsp",
                  "children": [],
                }
              ],
            },
            {
              "icon": "fa fa-calendar",
              "name": "Exam Shedule",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "",
                  "name": "All Shedules",
                  "param": false,
                  "link": "/all_exam_shedules.jsp",
                  "children": [
                  ],
                },
                // {
                //   "icon": "",
                //   "name": "All Innings",
                //   "param": false,
                //   "link": "/shedule_innings.jsp",
                //   "children": [],
                // },
                {
                  "icon": "",
                  "name": "All Notes",
                  "param": false,
                  "link": "/shedule_notes.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "far fa-calendar-alt",
              "name": "Events / Holiday",
              "param": false,
              "link": "/all_events.jsp",
              "children": [],
            },
            {
              "icon": "fab fa-buffer",
              "name": "Users",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fas fa-user-shield",
                  "name": "Admin",
                  "param": false,
                  "link": "/group_info.jsp",
                  "children": [],
                },
                // {
                //   "icon": "fa fa-user",
                //   "name": "Users",
                //   "param": false,
                //   "link": "/all_users.jsp",
                //   "children": [],
                // },
              ],
            }
          ],
        }
      ]
    },
    {
      "image": "/assets/images/dp.jpg",
      "name": "Admin",
      "param": false,
      "children": [
        {
          "icon": "fas fa-suitcase",
          "name": "Dashboard",
          "param": false,
          "link": "/dashboard.jsp",
          "children": []
        },
        {
          "icon": "fas fa-umbrella-beach",
          "name": "Holiday Calendar",
          "param": false,
          "link": "/holiday_calendar.jsp",
          "children": []
        },
        {
          "icon": "fas fa-umbrella-beach",
          "name": "Gateway of Accounting",
          "param": true,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Balance Sheet",
              "param": false,
              "link": "/balance_sheet.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Profit & Loss",
              "param": false,
              "link": "/profit_n_loss.jsp",
              "children": [],
            },
            {
              "icon": "fas fa-receipt",
              "name": "Reports",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "",
                  "name": "Group Status",
                  "param": false,
                  "link": "/all_group_status.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Ledger Status",
                  "param": false,
                  "link": "/all_ledger_status.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Cost Center's Status",
                  "param": false,
                  "link": "/all_cost_center_status.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Due's Status",
                  "param": false,
                  "link": "/all_dues_status.jsp",
                  "children": [],
                }
              ]
            },
            {
              "icon": "fas fa-receipt",
              "name": "Accounting",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "",
                  "name": "Create Due Fee",
                  "param": false,
                  "link": "/create_monthly_dues.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Edit/ Remove Due Fee",
                  "param": false,
                  "link": "/create_monthly_dues.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Create Salary",
                  "param": false,
                  "link": "/create_salary.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Edit/ Remove Salary",
                  "param": false,
                  "link": "/create_salary.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Receipt Journal",
                  "param": false,
                  "link": "/fees_receipt.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Receipt Fee",
                  "param": false,
                  "link": "/receipt_voucher.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Payment",
                  "param": false,
                  "link": "/payment_voucher.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "Paymemt Journal",
                  "param": false,
                  "link": "/fees_receipt.jsp",
                  "children": [],
                }
              ]
            },
            
            // {
            //   "icon": "",
            //   "name": "Accounting Vouchers",
            //   "param": false,
            //   "link": "/journal_voucher.jsp",
            //   "children": [],
            // },
            // {
            //   "icon": "",
            //   "name": "ledger_monthly_summary",
            //   "param": false,
            //   "link": "/ledger_monthly_summary.jsp",
            //   "children": [],
            // },
            // {
            //   "icon": "",
            //   "name": "ledger_vouchers",
            //   "param": false,
            //   "link": "/ledger_vouchers.jsp",
            //   "children": [],
            // },
            // {
            //   "icon": "",
            //   "name": "group_summary",
            //   "param": false,
            //   "link": "/group_summary.jsp",
            //   "children": [],
            // },
            {
              "icon": "fas fa-receipt",
              "name": "Old",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "",
                  "name": "fees_collection",
                  "param": false,
                  "link": "/fees_collection.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "get_fees",
                  "param": false,
                  "link": "/get_fees.jsp",
                  "children": [],
                },
                {
                  "icon": "",
                  "name": "fees_receipt",
                  "param": false,
                  "link": "/fees_receipt.jsp",
                  "children": [],
                },
                
              ]
            },
            // {
            //   "icon": "",
            //   "name": "Payment List ",
            //   "param": false,
            //   "link": "/payment_list.jsp",
            //   "children": [],
            // },
            // {
            //   "icon": "",
            //   "name": "Income List ",
            //   "param": false,
            //   "link": "/income_list.jsp",
            //   "children": [],
            // }
          ]
        },
        {
          "icon": "fas fa-user-graduate",
          "name": "Students",
          "param": false,
          "link": "",
          "children": [
            /*{
              "icon": "",
              "name": "Portal Data",
              "param":false,
              "link": "/portal_students.jsp",
              "children": [],
            },*/
            {
              "icon": "",
              "name": "All Recods",
              "param": false,
              "link": "/all_students.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Add New Student",
              "param": false,
              "link": "/add_student.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fas fa-user-tie",
          "name": "Professional",
          "param": false,
          "link": "/all_professionals.jsp",
          "children": []
        },
        {
          "icon": "fas fa-receipt",
          "name": "Fees/ Transpoart",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Fees Collection",
              "param": false,
              "link": "/fees_collection.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Get Fees",
              "param": false,
              "link": "/get_fees.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Fee Receipt",
              "param": false,
              "link": "/fees_receipt.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fa fa-address-card",
          "name": "Report Card",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "",
              "name": "Marks Class wise",
              "param": false,
              "link": "/all_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Add Marks Subject wise",
              "param": false,
              "link": "/add_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Excel to Update",
              "param": false,
              "link": "/excel_to_update.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Report Card",
              "param": false,
              "link": "/get_marks_sheet.jsp",
              "children": [],
            }
          ]
        },
        {
          "icon": "fa fa-calendar",
          "name": "Print Shedule",
          "param": false,
          "link": "/print_shedule.jsp",
          "children": []
        },
        {
          "icon": "fa fa-cog",
          "name": "Settings",
          "param": false,
          "link": "",
          "children": [
            // {
            //   "icon": "fa fa-desktop",
            //   "name": "Main Website",
            //   "param": false,
            //   "link": "",
            //   "children": [
            //     {
            //       "icon": "fa fa-caret-right",
            //       "name": "Main Slider",
            //       "param": false,
            //       "link": "/all_slider.jsp",
            //       "children": [],
            //     },
            //     {
            //       "icon": "fa fa-caret-right",
            //       "name": "Main Ariticle",
            //       "param": false,
            //       "link": "/all_article.jsp",
            //       "children": [],
            //     }
            //   ],
            // },
            {
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Galleries",
                  "param": false,
                  "link": "/all_galleries.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Images",
                  "param": false,
                  "link": "/all_images.jsp",
                  "children": [],
                }
              ],
              "icon": "fa fa-images",
              "name": "Image Gallery",
              "param": false,
              "link": ""
            },
            {
              "icon": "fas fa-file-excel",
              "name": "Upload Excel",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "Upload Students",
                  "param": false,
                  "link": "/upload_students.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Upload Staff",
                  "param": false,
                  "link": "/upload_staff.jsp",
                  "children": [],
                }
              ],
            },
            {
              "icon": "las la-rupee-sign",
              "name": "Accounts Info",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Groups",
                  "param": false,
                  "link": "/all_acc_group.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Ledger",
                  "param": false,
                  "link": "/all_acc_ledger.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "fab fa-gripfire",
              "name": "Fee Manager",
              "param": false,
              "link": "",
              "children": [
                {
                  "children": [
                    {
                      "icon": "fa fa-caret-right",
                      "name": "Category",
                      "param": false,
                      "link": "/all_type_n_time.jsp",
                      "children": [],
                    },
                    {
                      "icon": "fa fa-caret-right",
                      "name": "Structrue",
                      "param": false,
                      "link": "/all_fee_structure.jsp",
                      "children": [],
                    }
                  ],
                  "icon": "fas fa-rupee-sign",
                  "name": "Fee",
                  "param": false,
                  "link": ""
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Transpoart",
                  "param": false,
                  "link": "/all_transpoart_root.jsp",
                  "children": [],
                }
              ],
            },
            // {
            //   "icon": "fas fa-school",
            //   "name": "Affiliated Schools",
            //   "param": false,
            //   "link": "/all_schools.jsp",
            //   "children": [],
            // },
            {
              "icon": "fas fa-chalkboard-teacher",
              "name": "Lesson",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Lesson",
                  "param": false,
                  "link": "/all_lesson.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Add Lesson",
                  "param": false,
                  "link": "/add_lesson.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "fas fa-chalkboard-teacher",
              "name": "Class",
              "param": false,
              "link": "/all_class.jsp",
              "children": [],
            },
            {
              "icon": "fa fa-file-alt",
              "name": "All E-Test",
              "param": false,
              "link": "/all_e_test.jsp",
              "children": [],
            },
            {
              "icon": "fab fa-buffer",
              "name": "Exams / Subject",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fa fa-caret-right",
                  "name": "All Exams",
                  "param": false,
                  "link": "/all_exam.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Subject",
                  "param": false,
                  "link": "/all_subject.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-caret-right",
                  "name": "Add/Update Max Marks",
                  "param": false,
                  "link": "/subject_max_marks.jsp",
                  "children": [],
                }
              ],
            },
            {
              "icon": "fa fa-calendar",
              "name": "Exam Shedule",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "",
                  "name": "All Shedules",
                  "param": false,
                  "link": "/all_exam_shedules.jsp",
                  "children": [
                  ],
                },
                // {
                //   "icon": "",
                //   "name": "All Innings",
                //   "param": false,
                //   "link": "/shedule_innings.jsp",
                //   "children": [],
                // },
                {
                  "icon": "",
                  "name": "All Notes",
                  "param": false,
                  "link": "/shedule_notes.jsp",
                  "children": [],
                },
              ],
            },
            {
              "icon": "far fa-calendar-alt",
              "name": "Events / Holiday",
              "param": false,
              "link": "/all_events.jsp",
              "children": [],
            },
            {
              "icon": "fab fa-buffer",
              "name": "Users",
              "param": false,
              "link": "",
              "children": [
                {
                  "icon": "fas fa-user-shield",
                  "name": "Admin",
                  "param": false,
                  "link": "/school_info.jsp",
                  "children": [],
                },
                {
                  "icon": "fa fa-user",
                  "name": "Users",
                  "param": false,
                  "link": "/all_users.jsp",
                  "children": [],
                },
              ],
            }
          ],
        }
      ]
    },
    {
      "image": "/assets/images/dp.jpg",
      "name": "Professional",
      "param": false,
      "children": [
        {
          "icon": "fas fa-suitcase",
          "name": "Dashboard",
          "param": false,
          "link": "/dashboard.jsp",
          "children": []
        },
        {
          "children": [
            /*{
              "icon": "",
              "name": "Portal Data",
              "param":false,
              "link": "/portal_students.jsp",
              "children": [],
            },*/
            {
              "icon": "",
              "name": "All Recods",
              "param": false,
              "link": "/all_students.jsp",
              "children": [],
            }
          ],
          "icon": "fas fa-user-graduate",
          "name": "Students",
          "param": false,
          "link": ""
        },
        {
          "icon": "fas fa-suitcase",
          "name": "Profile",
          "param": true,
          "link": "/professional_profile.jsp",
          "children": []
        },
        {
          "children": [
            {
              "icon": "",
              "name": "Fees Collection",
              "param": false,
              "link": "/fees_collection.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Get Fees",
              "param": false,
              "link": "/get_fees.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Fee Receipt",
              "param": false,
              "link": "/fees_receipt.jsp",
              "children": [],
            }
          ],
          "icon": "fas fa-receipt",
          "name": "Fees/ Transpoart",
          "param": false,
          "link": ""
        },
        {
          "children": [
            {
              "icon": "",
              "name": "Marks Class wise",
              "param": false,
              "link": "/all_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Add Marks Subject wise",
              "param": false,
              "link": "/add_marks.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Excel to Update",
              "param": false,
              "link": "/excel_to_update.jsp",
              "children": [],
            },
            {
              "icon": "",
              "name": "Report Card",
              "param": false,
              "link": "/get_marks_sheet.jsp",
              "children": [],
            }
          ],
          "icon": "fab fa-buffer",
          "name": "Report Card",
          "param": false,
          "link": ""
        },
        {
          "icon": "fa fa-question-circle",
          "name": "Lesson FAQs",
          "param": true,
          "link": "/lesson_faqs.jsp",
          "children": []
        },
        {
          "icon": "fas fa-chalkboard-teacher",
          "name": "Lesson",
          "param": false,
          "link": "",
          "children": [
            {
              "icon": "fa fa-caret-right",
              "name": "All Lesson",
              "param": false,
              "link": "/all_lesson.jsp",
              "children": [],
            },
            {
              "icon": "fa fa-caret-right",
              "name": "Add Lesson",
              "param": false,
              "link": "/add_lesson.jsp",
              "children": [],
            },
          ]
        },
        {
          "icon": "fa fa-file-alt",
          "name": "All E-Test",
          "param": false,
          "link": "/all_e_test.jsp",
          "children": [],
        }
      ]
    },
    {
      "image": "/assets/images/dp.jpg",
      "name": "Student",
      "param": false,
      "children": [
        {
          "icon": "fas fa-suitcase",
          "name": "Dashboard",
          "param": false,
          "link": "/dashboard.jsp",
          "children": []
        },
        {
          "icon": "fas fa-umbrella-beach",
          "name": "Holiday Calendar",
          "param": false,
          "link": "/holiday_calendar.jsp",
          "children": []
        },
        {
          "icon": "fas fa-user-graduate",
          "name": "Profile",
          "param": true,
          "link": "/student_profile.jsp",
          "children": []
        },
        {
          "icon": "fas fa-user-graduate",
          "name": "Lessons",
          "param": true,
          "link": "/student_lesson.jsp",
          "children": [],
        },
        {
          "icon": "fa fa-file-alt",
          "name": "All E-Test",
          "param": false,
          "link": "/all_e_test.jsp",
          "children": [],
        },
      ]
    },
    {
      "image": "/assets/images/dp.jpg",
      "name": "RAJPSP",
      "param": false,
      "children": []
    }
  ]
}
export default Menus;