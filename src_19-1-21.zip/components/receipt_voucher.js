import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { confirmAlert } from 'react-confirm-alert';
import { connect } from 'react-redux';
import DatePicker from 'react-date-picker';
import {
  accLedgerActions, professionalAction,
  accGroupActions, accLedgerEntryActions, studentsAction
} from '../_actions';
import { isEmptyObj, isEmpty, checkEntryType, getAllInputs } from '../utility/utilities';
// import { events } from '../_reducers/events.reducer';

// import CommonFilters from '../utility/Filter/filter-schools';

class ReceiptVoucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    filter_data: [],
    effected_left_ldr: [],
    effected_right_ldr: [],
    current_ldr: '',
    vchr_type: "Journal",
    voucher: {
      "vch_no": "3163", "child": [
        { "ldr_ref_id": "5_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Fee Discount" },
        { "ldr_ref_id": "1_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Profit & Loss A/c" },
        { "ldr_ref_id": "6_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Teaching Staff Salary" },
        { "ldr_ref_id": "9_LDR_4", "tr_amount": "545", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Exam Fee" },
        { "ldr_ref_id": "14_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Registration Fee" },
        { "ldr_ref_id": "49_STU_4", "tr_amount": "743", "tr_type": "DR", "under_grp_id": "10", "under_grp_type": "P", "ledger_name": "AASHISH MEENA S/o RAMBABU MEENA [141/Fourth]" }],
      "cr_total_amo": 743, "dr_total_amo": 743, "narration": "AASHISH MEENA S/o RAMBABU MEENA Total Due is Rs. 743.", "vchr_type": "Journal"
    },
    vchr_date: new Date(),
  }

  setArraowKeysHandler() {
    document.addEventListener('keydown', (e) => {
      switch (e.keyCode) {
        case 37:
          // console.log('left');
          this.handleKeyDown("left");
          break;
        case 38:
          // console.log('up');
          this.handleKeyDown("up");
          break;
        case 39:
          // console.log('right');
          this.handleKeyDown("right");
          break;
        case 40:
          // console.log('down');
          this.handleKeyDown("down");
          break;
        case 13:
          // console.log('Enter');
          this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        case 9:
          // console.log('Tab');
          this.tabAndEnterHandler(e);
          break;
        default:
        // console.log('something wrong');
      }
    });
    this.focusFirstHandler()
  }
  focusFirstHandler() {
    const allinput = Array.prototype.slice.call(document.querySelector('.sfpage-body').querySelectorAll("textarea, input"));
    if (allinput.length > 0) {
      (allinput[1]).focus();
    }
  }
  examStartDate = (feeDate) => {
    this.setState({ vchr_date: feeDate });
    // this.to.openCalendar();
  };
  chooseLedgerHandler() {
    // debugger

    const { filter_data, cursor, current_inx } = this.state;
    const current_ldr = filter_data[cursor];
    // console.log(current_ldr);
    if (!isEmptyObj(current_ldr)) {
      let sv = this.state.voucher;
      sv.child[current_inx]['ldr_ref_id'] = current_ldr['ldr_ref_id'];
      // sv.child[current_inx]['under_grp_id'] = current_ldr['under_grp_id'];
      // sv.child[current_inx]['under_grp_type'] = current_ldr['under_grp_type'];
      sv.child[current_inx]['ledger_name'] = current_ldr['ledger_name'];
      this.setState({
        voucher: sv
      })
    }
  }

  handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }), () => { this.srollListItemHandler(key) })
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }), () => { this.srollListItemHandler(key) })
    }
  }



  srollListItemHandler(key) {
    // debugger;
    const _div = document.querySelector('#ldrList');
    const _elem = _div.querySelector('.active');
    const _elh = _elem.clientHeight;
    const _dlh = _div.clientHeight + 80;

    let rect = _elem.getBoundingClientRect();
    let elementTop; //x and y
    var scrollTop = document.documentElement.scrollTop ?
      document.documentElement.scrollTop : document.body.scrollTop;
    elementTop = rect.top + scrollTop;
    // console.log(elementTop)

    if ((key === "up" || key === "left") && elementTop < 110) {
      _div.scrollBy(0, -_elh);
    } else if ((key === "down" || key === "right") && elementTop > _dlh) {
      _div.scrollBy(0, _elh);
    }
  }

  changeHandler = (event, fieldName, isCheckbox, indexNo, trType) => {
    // debugger
    if (fieldName === 'ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher));
      sv.child[indexNo].tr_type = _val;
      this.setState({ voucher: sv })
    } else if (fieldName === 'ldr_name') {
      this.filterDataHandler(event, fieldName, indexNo);
    } else if (fieldName === 'ldr_amo') {
      this.updateTransetionAmountHandler(event, indexNo, trType);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  updateTransetionAmountHandler(e, indexNo, trType) {
    // let sv = JSON.parse(JSON.stringify(this.state.voucher));
    let sv = this.state.voucher;
    const _val = e.target.value;
    sv.child[indexNo].tr_amount = _val;
    this.setState({
      voucher: sv,
      tr_type: trType
    })
  }

  filterDataHandler = (e, fieldName, indexNo) => {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    const _val = e.target.value;
    sv.child[indexNo].ledger_name = _val;

    const ldr_list = (e.target.getAttribute('data-type') === "CR") ? "effected_left_ldr" : "effected_right_ldr";

    const _ldr_list = JSON.parse(JSON.stringify(this.state[ldr_list]));
    const val = _val.toUpperCase();
    const filtered_data = _ldr_list.filter((elem) => {
      const _elem = elem.ledger_name.toUpperCase();
      if (!_elem.includes(val)) {
        return false
      }
      return elem
    })
    // console.log(filtered_data);
    this.setState({
      filter_data: filtered_data,
      voucher: sv,
      // current_grp: fieldName,
      // current_inx: indexNo,
    }, () => {
      // this.handleKeyDown(e)
    })
  }

  blurHandler = (event, fieldName, isCheckbox, indexNo, inputType) => {
    const _val = event.target.value;
    if (fieldName === 'ldr_type') {
      if (_val === "Cr" || _val === "CR" || _val === "Dr" || _val === "DR") {

      } else {
        event.target.focus();
      }
    } else if (fieldName === 'ldr_name') {
      if (isEmpty(_val)) {
        event.target.focus();
      } else {
        this.setState({
          filter_data: []
        })
      }
    } else if (fieldName === 'ldr_amo') {
      if (isEmpty(_val)) {
        event.target.focus();
      } else {
        // this.calculateANDautofillAmountHandler(event, fieldName, isCheckbox, indexNo, inputType);
      }
    }
  };

  // calculateANDautofillAmountHandler(event, fieldName, isCheckbox, indexNo, inputType){

  // }

  ledgerListHandler = (event, fieldName, isCheckbox, indexNo) => {
    // debugger
    const ldr_list = event.target.getAttribute('data-type');
    const ldr_val = event.target.value;
    if (ldr_list === "CR") {
      const _inx = this.state.effected_left_ldr.findIndex((item) => item.ledger_name === ldr_val);
      this.setState({
        filter_data: this.state.effected_left_ldr,
        current_inx: indexNo,
        cursor: _inx,
      })
    } else if (ldr_list === "DR") {
      const _inx = this.state.effected_right_ldr.findIndex((item) => item.ledger_name === ldr_val);
      this.setState({
        filter_data: this.state.effected_right_ldr,
        current_inx: indexNo,
        cursor: _inx,
      })
    }
  }

  effectedLedgerHandler() {
    // debugger
    let ldr_debit = [];
    let ldr_credit = [];
    const vchr_type = this.state.vchr_type;

    switch (vchr_type) {
      case "Payment":
        // code
        ldr_debit = [10];
        ldr_credit = [11];

        break;
      case "Receipt":
        // code
        break;
      default:
        // code
        ldr_credit = [1, 2];
        ldr_debit = [10];
    }
    const { all_ledgers } = this.props.accountManager;
    let efctd_cr_ldr = [];
    let efctd_dr_ldr = [];

    ldr_credit.forEach(el => {
      efctd_cr_ldr = [...efctd_cr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
    })

    ldr_debit.forEach(el => {
      efctd_dr_ldr = [...efctd_dr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
    });


    this.setState({
      effected_left_ldr: efctd_cr_ldr,
      effected_right_ldr: efctd_dr_ldr,
      all_ledgers: all_ledgers
    })
  }

  tabAndEnterHandler(ev) {
    ev.preventDefault();
    // const allinput = (!isEmpty(this.state.allinput) || this.state.allinput === 'undefined') ? getAllInputs() : this.state.allinput;
    const allinput = getAllInputs();
    const _ti = ev.target;
    let _ci = '';
    allinput.map((item, inx) => { if (item === _ti) { _ci = inx; } });

    let nextTi = '';
    if ((ev.shiftKey && ev.key === 'Tab') || (ev.shiftKey && ev.key === 'Enter')) {
      // nextTi = (_ci === 0) ? allinput.length - 1 : _ci - 1;
      nextTi = (_ci === 0 || _ci === 1) ? 1 : _ci - 1;
    } else {
      // nextTi = (_ci === allinput.length) ? 0 : (_ci === (allinput.length - 1)) ? 0 : _ci + 1;
      nextTi = (_ci === allinput.length) ? allinput.length : _ci + 1;
    }
    if (nextTi === (allinput.length - 1)) {
      const gTotal = this.getSumOfBalanceHandler();
      // console.log("last transaction");
      if (gTotal.total_cr !== gTotal.total_dr) {
        this.checkEntriesHandler(ev, gTotal);
      } else {
        (allinput[nextTi]).focus();
      }
    } else if (nextTi === 1) {
      // console.log("first")
      (allinput[nextTi]).focus();
    } else if (nextTi === allinput.length) {
      // console.log("last")
      this.confirmBoxSubmit(ev)
    } else {
      (allinput[nextTi]).focus();
    }
  }
  getSumOfBalanceHandler() {
    //debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    let total_cr = 0;
    let total_dr = 0;
    sv.child.forEach(elem => {
      if ((elem.tr_type).toUpperCase() === "CR") {
        total_cr += Number(elem.tr_amount);
      } else {
        total_dr += Number(elem.tr_amount);
      }
    });
    return { total_cr: total_cr, total_dr: total_dr };
  }
  checkEntriesHandler(ev, gTotal) {
    const gt = gTotal;
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    sv['cr_total_amo'] = gt.total_cr;
    sv['dr_total_amo'] = gt.total_dr;
    sv.child.push({ ldr_ref_id: "", tr_amount: Math.abs(gt.total_cr - gt.total_dr), tr_type: (gt.total_cr < gt.total_dr) ? "CR" : "DR", ledger_name: "" })
    this.setState({
      voucher: sv
    }, () => this.tabAndEnterHandler(ev))
  };

  componentDidMount() {
    this.effectedLedgerHandler();
    this.setArraowKeysHandler();
  }


  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.createHandler();
          }
        },
        {
          label: 'No',
          onClick: () => {
            this.focusFirstHandler();
          }
        }
      ]
    });
  };
  createHandler = () => {
    alert(JSON.stringify(this.state.voucher));
  }

  selectVoucherTypeHandler(ev, val) {
    ev.preventDefault();
    switch (val) {
      case "Receipt":
        // Receipt Voucher
        this.addNewVoucher("CR");
        break;
      case "Payment":
        // Receipt Voucher
        this.addNewVoucher("DR");
        break;
      case "Contra":
        // Receipt Voucher
        this.addNewVoucher("CR");

        break;
      default:
        // Journal
        this.addNewVoucher("CR");

    }
  }

  addNewVoucher(type) {
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    sv.child.push({ ldr_ref_id: "", tr_amount: '', tr_type: type, ledger_name: "" })
    this.setState({
      voucher: sv
    })
  }

  render() {
    const { user, accountManager } = this.props;
    const { voucher, filter_data, cursor, vchr_date } = this.state;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Accounting Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> Receipt Voucher</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con inline-box">
              <div className="form-group mr-2 mt-2">
                <ul className="nav d-flex mr-4">
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Receipt")}
                      className="btn btn-outline-secondary btn-sm">Receipt</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Payment")}
                      className="btn btn-outline-secondary btn-sm">Payment</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Journal")}
                      className="btn btn-outline-secondary btn-sm">Journal</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Contra")}
                      className="btn btn-outline-secondary btn-sm">Contra</button>
                  </li>
                </ul>
              </div>
              <div className="form-group mt-1">
                <DatePicker
                  onChange={this.examStartDate}
                  value={vchr_date}
                  showLeadingZeroes={true}
                //minDate={new Date()}
                />
              </div>
            </div>
          </div>
        </div>
        {user && voucher && accountManager &&
          <div className="card card-box sfpage-cover light-trans">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page page-receipt-voucher">
                {(filter_data.length > 0) &&
                  <div className="list-accunts">
                    <div className="list-acc-head">List of Ledger Accunts</div>
                    <div className="list-acc-body" id="ldrList">
                      <ul>
                        {filter_data.map((item, index) => {
                          return (
                            <li
                              className={cursor === index ? 'active' : null}
                              key={index}>
                              {item.ledger_name}
                            </li>
                          )
                        })}
                      </ul>
                    </div>
                    <div className="list-acc-footer">more...</div>
                  </div>
                }
                <div className="acc-page-head container-fluid">
                  <div className="sec-title">
                    <div className="title-zone">Particulars</div>
                    <div className="info-zone">
                      <div className="info-zone">
                        <table className="table table-bordered table-sm">
                          <tbody>
                            <tr>
                              <td>
                                <div className="dr-title">Debit</div>
                              </td>
                              <td>
                                <div className="cr-title">Credit</div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="acc-page-body container-fluid">
                  <div className="av-detail-zone">
                    {voucher.child.map((item, index) => {
                      return (
                        <div className="av-detail-head" key={index}>
                          <div className="main-head" >
                            <div className="head-name d-flex">
                              <span className="txt-normal mr-2">
                                <input type="text"
                                  value={item.tr_type}
                                  disabled={(index === 0) ? true : false}
                                  maxLength="2"
                                  className="form-control trans-input tr-type form-control-sm"
                                  onChange={event => this.changeHandler(event, `ldr_type`, null, index)}
                                  onBlur={event => this.blurHandler(event, `ldr_type`, null, index)}
                                />
                              </span>
                              <input type="text"
                                value={item.ledger_name}
                                data-type={item.tr_type}
                                className="form-control trans-input tr-name form-control-sm"
                                onChange={event => this.changeHandler(event, `ldr_name`, null, index)}
                                onFocus={event => this.ledgerListHandler(event, `ldr_name`, null, index)}
                                onBlur={event => this.blurHandler(event, `ldr_name`, null, index)}
                              />
                            </div>
                            <div className="head-amount">
                              <div className="dr-total">
                                {(item.tr_type == "CR") ?
                                  <input type="number"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `ldr_amo`, null, index, `CR`)}
                                    onBlur={event => this.blurHandler(event, `ldr_amo`, null, index, `CR`)}
                                  />
                                  : null}
                              </div>
                              <div className="cr-total">
                                {(item.tr_type == "DR") ?
                                  <input type="number"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `ldr_amo`, null, index, `DR`)}
                                    onBlur={event => this.blurHandler(event, `ldr_amo`, null, index, `DR`)}
                                  />
                                  : null}
                              </div>
                            </div>
                          </div>
                          <div className="crnt-balance-head">
                            <div className="bal-head"><span className="txt-normal">Cur Bal :</span> {item.ldr_ref_id}</div>
                          </div>
                        </div>
                      )
                    })}
                  </div>

                </div>
                <div className="acc-page-footer av-page-footer container-fluid">
                  <div className="sec-foot">
                    <div className="narration-zone">
                      <div className="title">Narration:</div>
                      <textarea
                        value={voucher.narration}
                        onChange={event => this.changeHandler(event, `narration`)}
                        className="form-control" >

                      </textarea>
                    </div>
                    <div className="amount-zone">
                      <div className="dr-total">{voucher.dr_total_amo}</div>
                      <div className="cr-total">{voucher.cr_total_amo}</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accountManager } = state.accountManager;
  return {
    user, accountManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
}

export default connect(mapStateToProps, actionCreators)(withRouter(ReceiptVoucher));