import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { isEmptyObj, checkEntryType, getAllInputs, isEmpty } from '../utility/utilities';
import * as accMethod from '../utility/accounts';
import SingleEntry from '../includes/single_entry';
import FilteredDataList from '../includes/filtered_data_list';

class VoucherBody extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    lockInputs: false,
    voucher_obj: '',
    filter_data: [],
    credit_ledgers: [],
    debit_ledgers: [],
    current_ldr: '',
    vchr_type: "",
    first_vchr_type: "",
    vchr_date: new Date(),
  }

  setArraowKeysHandler() {
    document.addEventListener('keydown', (e) => {
      switch (e.keyCode) {
        case 37:          // console.log('left');
          this.handleKeyDown("left");
          break;
        case 38:          // console.log('up');
          this.handleKeyDown("up");
          break;
        case 39:          // console.log('right');
          this.handleKeyDown("right");
          break;
        case 40:          // console.log('down');
          this.handleKeyDown("down");
          break;
        case 13:          // console.log('Enter');
          // this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        case 9:          // console.log('Tab');
          // this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        default:        // console.log('something wrong');
      }
    });
    accMethod.focusFirstHandler();
  }

  examStartDate = (feeDate) => {
    this.setState({ vchr_date: feeDate });
    // this.to.openCalendar();
  };
  chooseLedgerHandler() {
    //  debugger

    const { filter_data, cursor, current_inx } = this.state;
    const current_ldr = filter_data[cursor];
    // console.log(current_ldr);
    if (!isEmptyObj(current_ldr)) {
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv.child[current_inx]['ldr_ref_id'] = current_ldr['ldr_ref_id'];
      sv.child[current_inx]['ledger_name'] = current_ldr['ledger_name'];
      this.setState({
        voucher_obj: sv,
        filter_data: []
      })
    }
  }


  handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }), () => { accMethod.srollListItemHandler(key) })
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }), () => { accMethod.srollListItemHandler(key) })
    }
  }

  valueTOchangeHandler = (val, indexNo) => {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    sv.child[indexNo].tr_type = val;
    this.setState({ voucher_obj: sv })
  };

  changeHandler = (event, fieldName, isCheckbox, indexNo, trType) => {
    // debugger
    if (fieldName === 'ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv.child[indexNo].tr_type = _val.toUpperCase();
      this.setState({ voucher_obj: sv })
    } else if (fieldName === 'narration') {
      // debugger;
      const _val = event.target.value;
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv['narration'] = _val;
      this.setState({ voucher_obj: sv })
    } else if (fieldName === 'ldr_name') {
      // debugger;
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      const _val = event.target.value;

      const ldr_list = (event.target.getAttribute('data-type') === "CR") ? "credit_ledgers" : "debit_ledgers";

      const ledger_list = JSON.parse(JSON.stringify(this.state[ldr_list]));
      const resData = accMethod.filterDataHandler(ledger_list, _val);

      sv.child[indexNo].ledger_name = resData['val_txt'];

      this.setState({
        filter_data: resData['filter_data'],
        voucher_obj: sv
      })

    } else if (fieldName === 'ldr_amo') {

      this.updateTransetionAmountHandler(event, indexNo, trType);

    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  updateTransetionAmountHandler(e, indexNo, trType) {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    const _val = e.target.value;
    sv.child[indexNo].tr_amount = _val;
    this.setState({
      voucher_obj: sv,
      tr_type: trType
    })
  }

  // setFilteredDataHandler = () => {
  //   this.setState({
  //     filter_data: []
  //   })
  // }

  ledgerListHandler = (obj) => {
    this.setState({
      filter_data: obj['filter_data'],
      current_inx: obj['current_inx'],
      cursor: obj['cursor']
    })
  }


  tabAndEnterHandler(ev) {
    ev.preventDefault();
    const allinput = getAllInputs();
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    const _ti = ev.target;
    let _ci = '';
    allinput.map((item, inx) => { if (item === _ti) { _ci = inx; } });

    let nextTi = '';
    if ((ev.shiftKey && ev.key === 'Tab') || (ev.shiftKey && ev.key === 'Enter')) {
      nextTi = (_ci === 0 || _ci === 1) ? 1 : _ci - 1;
    } else {
      nextTi = (_ci === allinput.length) ? allinput.length : _ci + 1;
    }

    if (nextTi !== -1) {
      if (nextTi === (allinput.length - 1)) {
        const gTotal = accMethod.getSumOfBalanceHandler(sv);
        // console.log("last transaction");
        if (gTotal.total_cr !== gTotal.total_dr) {
          this.checkEntriesHandler(ev, gTotal);
        } else {
          (allinput[nextTi]).focus();
          (allinput[nextTi]).select();
        }
      } else if (nextTi === 1) {
        // console.log("first")
        (allinput[nextTi]).focus();
        (allinput[nextTi]).select();
      } else if (nextTi === allinput.length) {
        // console.log("last")
        debugger;
        if (!isEmpty(sv.cr_total_amo) || !isEmpty(sv.dr_total_amo)) {
          this.setState({
            lockInputs: true
          })
          this.confirmBoxSubmit(ev)
        } else {
          alert('Something is Wrong!')
        }
      } else {
        (allinput[nextTi]).focus();
        (allinput[nextTi]).select();
      }
    }
    if (ev.target.dataset.name === 'ldr_name') {
      this.chooseLedgerHandler();
    }
  }

  checkEntriesHandler(ev, gTotal) {
    const gt = gTotal;
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    sv['cr_total_amo'] = (gt.total_cr > gt.total_dr) ? gt.total_cr : gt.total_dr;
    sv['dr_total_amo'] = (gt.total_cr > gt.total_dr) ? gt.total_cr : gt.total_dr;
    sv.child.push({
      ldr_ref_id: "", tr_amount: Math.abs(gt.total_cr - gt.total_dr),
      tr_type: (gt.total_cr < gt.total_dr) ? "CR" : "DR", ledger_name: ""
    })
    this.setState({
      voucher_obj: sv
    }, () => this.tabAndEnterHandler(ev))
  };

  componentDidMount() {
    // debugger
    const { voucher_obj, all_ledgers, voucher_type, first_vchr_type } = this.props;
    const resData = accMethod.effectedLedgerHandler(voucher_type, all_ledgers);
    this.setState({
      voucher_obj: voucher_obj,
      first_vchr_type: first_vchr_type,
      voucher_type: voucher_type,
      credit_ledgers: resData['credit_ledgers'],
      debit_ledgers: resData['debit_ledgers'],
    }, () => { this.setArraowKeysHandler(); })
  }

  componentWillUnmount() {
    // alert('unmounting 243')
    // document.removeEventListener('keydown', this, false)
    window.document.removeEventListener('keydown', (e) => { })
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          type: 'submit',
          onClick: () => {
            this.createHandler();
          }
        },
        {
          label: 'No',
          onClick: () => {
            this.cancleHandler()
          }
        }
      ]
    });
  };
  cancleHandler = () => {
    this.setState({
      lockInputs: true,
    }, () => {
      accMethod.focusFirstHandler();
    })
  }
  createHandler = () => {
    const finalVoucher = JSON.parse(JSON.stringify(this.state.voucher_obj));
    const tr_type = this.props.first_vchr_type;
    this.setState({
      voucher_obj: {
        "child": [{ "ldr_ref_id": "", "tr_amount": "", "tr_type": tr_type, "ledger_name": "" }],
        narration: ''
      },
      lockInputs: false,
    }, () => {
      // console.log(finalVoucher);
      // accMethod.focusFirstHandler();
      this.props.submitDataHandler(finalVoucher);
    })
  }

  staticHeader() {
    return <div className="acc-page-head container-fluid">
      <div className="sec-title">
        <div className="title-zone">Particulars</div>
        <div className="info-zone">
          <div className="info-zone">
            <table className="table table-bordered table-sm">
              <tbody>
                <tr>
                  <td>
                    <div className="dr-title">Debit</div>
                  </td>
                  <td>
                    <div className="cr-title">Credit</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  }
  render() {
    const { voucher_obj, filter_data, cursor, credit_ledgers, debit_ledgers, lockInputs } = this.state;
    // console.log(this.state);
    return (
      <>
        {voucher_obj &&
          <div className="acc-page page-receipt-voucher">
            {(filter_data.length > 0) &&
              <FilteredDataList
                cursor={cursor}
                filter_data={filter_data}
              />
            }
            {this.staticHeader()}
            <div className="acc-page-body container-fluid">
              <div className="av-detail-zone">
                {voucher_obj.child.map((item, index) => {
                  return (
                    <div key={index}>
                      <SingleEntry
                        eIndex={index}
                        lockInputs={lockInputs}
                        eItem={item}
                        credit_ledgers={credit_ledgers}
                        debit_ledgers={debit_ledgers}
                        ledgerListHandler={this.ledgerListHandler}
                        setFilteredDataHandler={this.setFilteredDataHandler}
                        changeHandler={this.changeHandler}
                        valueTOchangeHandler={this.valueTOchangeHandler}
                      />
                    </div>
                  )
                })}
              </div>

            </div>
            <div className="acc-page-footer av-page-footer container-fluid">
              <div className="sec-foot">
                <div className="narration-zone">
                  <div className="title">Narration:</div>
                  <textarea
                    value={voucher_obj.narration}
                    disabled={(lockInputs) ? true : false}
                    onChange={event => this.changeHandler(event, `narration`)}
                    className="form-control" >
                  </textarea>
                </div>
                <div className="amount-zone">
                  <div className="dr-total">{voucher_obj.dr_total_amo}</div>
                  <div className="cr-total">{voucher_obj.cr_total_amo}</div>
                </div>
              </div>
            </div>

          </div>
        }
      </>
    )
  }
}

export default withRouter(VoucherBody);