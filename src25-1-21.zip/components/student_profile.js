import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { feeDepositedCurrentStudentAction, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/students/read_one.php`;
// const READ_ALL_STU_IDS = `http://schools.rajpsp.com/api/students/read_all_student_ids.php`;
// const GET_PRE_DEPOSIT_RECORD = `http://schools.rajpsp.com/api/fee_deposit/read_pre_deposit_months.php`;

class StudentProfile extends Component {
  state = {
    current_id: "",
    student_info: "",
    prev_id: '',
    next_id: '',
    is_prev: false,
    is_next: false,
    group_id: '',
    session_year_id: '',
    user_category: '',
    school_id: '',
    all_students_ids: [],
    monthly_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    convence_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    monthly: '',
    convence: '',
    reg_fee: false,
    sports_fee: false,
    exam_fee: false,
    pre_fee_deposit_arr: '',
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    // if (isEmptyObj(this.props.classes)) {
    //   this.props.getClasses();
    // }
    // if (isEmptyObj(this.props.conveyance)) {
    //   this.props.getConveyance();
    // }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }

    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _all_stu = this.props.students;
      if (_all_stu) {
        this.checkAuthentication();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  componentWillReceiveProps(nextProps) {
    //  debugger;
    if (nextProps.feeDepositedCurrentStudent) {
      const resData = nextProps.feeDepositedCurrentStudent;
      this.setState({
        pre_fee_deposit_arr: resData,
        monthly: resData.monthly,
        convence: resData.convence,
        reg_fee: resData.reg_fee,
        sports_fee: resData.sports_fee,
        exam_fee: resData.sports_fee,
      })
    }
  }

  checkAuthentication() {
    // loadProgressBar();
    const { match } = this.props;
    const current_id = match.params.id;

    this.setState({
      current_id: current_id,
    }, () => {
      this.getStudentDetailHandler();
      this.getAllStudentIdsHandler();
    })

    // axios.post(VALIDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     // sessionStorage.setItem("user", getRes.data);
    //     console.log(getRes);
    //     if (getRes.data) {
    //       this.setState({
    //         user: getRes.data,
    //         group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //         school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //         user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //         session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //         current_id: current_id,
    //       }, () => {
    //         this.getStudentDetailHandler();
    //         this.getAllStudentIdsHandler();
    //       })
    //     }
    //   }).catch((error) => {
    //     this.props.history.push('/login.jsp');
    //   })
  }

  getPrevStudentRecord(e, _id) {
    e.preventDefault();
    this.setState({
      current_id: _id
    }, () => {
      this.getStudentDetailHandler();
      this.setStudentsItsHandler();
      this.changeUrlHandler();
    })
  }
  changeUrlHandler() {
    this.props.history.push(`/student_profile.jsp/${this.state.current_id}`);
  }
  setStudentsItsHandler() {
    const _current_id = this.state.current_id;
    const _student_ids = this.state.all_students_ids;
    // debugger
    let _prev_id = '';
    let _next_id = '';
    let _is_prev = false;
    let _is_next = false;
    let _chnage_state = false;
    for (let i = 0; i < _student_ids.length; i++) {
      if (_current_id === _student_ids[i].s_id && (i >= 0 && i < _student_ids.length)) {

        if (i === 0) {
          _prev_id = _student_ids[_student_ids.length - 1].s_id;
        } else {
          _prev_id = _student_ids[i - 1].s_id;
        }

        if (i === _student_ids.length - 1) {
          _next_id = _student_ids[0].s_id;
        } else {
          _next_id = _student_ids[i + 1].s_id;
        }

        _chnage_state = true;
        if (i == 0) {
          _is_prev = true;
        } else if (i == _student_ids.length - 1) {
          _is_next = true;
        }
        break;
      }
    }

    if (_chnage_state) {
      this.setState({
        prev_id: _prev_id,
        next_id: _next_id,
        is_prev: _is_prev,
        is_next: _is_next
      })
    }
  }
  getAllStudentIdsHandler() {
    // debugger
    const selected_students = this.props.students;
    const school_id = this.props.user.school_id;
    const slct_class = this.props.filteredClassesData.slct_cls_name;

    let all_Ids = [];
    selected_students.map((item) => {
      if (!isEmpty(slct_class)) {
        if (item.school_id === school_id && item.stu_class === slct_class) {
          all_Ids = [...all_Ids, { s_id: item.se_id, student_name: item.student_name }];
        }
      } else {
        if(item.school_id === school_id) {
          all_Ids = [...all_Ids, { s_id: item.se_id, student_name: item.student_name }];
        }
      }
    })

    this.setState({
      all_students_ids: all_Ids
    }, () => {
      this.setStudentsItsHandler();
    })
    // console.log(JSON.stringify(obj));
    // debugger
    // axios.post(READ_ALL_STU_IDS, obj)
    //   .then(res => {
    //     const resData = res.data;
    //     // console.log(resData);
    //     this.setState({
    //       all_students_ids: resData,
    //       errorMessages: resData.message
    //     }, () => {
    //       this.setStudentsItsHandler()
    //     });
    //   }).catch((error) => {
    //     // error
    //   });
  }

  getStudentDetailHandler() {
    const _students = this.props.students;
    const _c_id = this.state.current_id;
    // debugger
    const _current_student = _students.filter((item) => {
      if (item.se_id === _c_id) {
        return item
      }
    })
    this.setState({
      student_info: _current_student[0]
    }, () => {
      const obj = { student_id: _c_id }
      // console.log(obj);
      this.props.getFeeDepositedCurrentStudent(obj);
    })

    // axios.get(READ_URL + '?id=' + this.state.current_id)
    //   .then(res => {
    //     const student = res.data;
    //     //console.log(student);
    //     this.setState({
    //       student_info: student,
    //       errorMessages: student.message
    //     }, () => {
    //       this.getPreDepositRecords()
    //     })
    //   }).catch((error) => {
    //     // error
    //   });
  };


  getPreDepositRecords() {


    // axios.get(GET_PRE_DEPOSIT_RECORD + '?student_id=' + this.state.admission_number)
    //   .then(res => {
    //     const deposited_arr = res.data;
    //     this.setState({
    //       pre_fee_deposit_arr: deposited_arr,
    //       monthly: deposited_arr.monthly,
    //       convence: deposited_arr.convence,
    //       reg_fee: deposited_arr.reg_fee,
    //       sports_fee: deposited_arr.sports_fee,
    //       exam_fee: deposited_arr.sports_fee,
    //       errorMessages: deposited_arr.message
    //     });
    //     //console.log(this.state.pre_fee_deposit_arr);
    //   }).catch((error) => {
    //     // error
    //   })
  }
  filterInArray = (stateArray, month) => {
    const _this = this.state.convence_will_deposit_months.map((arrayMonth) => {
      if (arrayMonth === month) {
        return true
      } else {
        return false
      }
    })
    return _this;
  }

  render() {
    const { prev_id, next_id, is_prev, is_next, student_info, formIsHalfFilledOut } = this.state;
    const { user, students } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Student Profile</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Student Profile</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {user && students && student_info &&
              <div className="table-scrollable">
                <div className="col-sm-12">
                  {/* BEGIN PROFILE SIDEBAR */}
                  <div className="profile-sidebar">
                    <div className="card mb-4 card-topline-aqua">
                      <div className="card-body p-0">
                        <div className="row">
                          <div className="profile-userpic">
                            {student_info.student_image !== '' ?
                              < img src={`${process.env.PUBLIC_URL}` + student_info.student_image} className="img-responsive" alt={student_info.student_name} />
                              : (student_info.gender === 'Boy' ?
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} className="img-responsive" />
                                :
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} className="img-responsive" />)
                            }
                          </div>
                        </div>
                        <div className="profile-usertitle">
                          <div className="profile-usertitle-name">{student_info.student_name}</div>
                        </div>
                        <ul className="list-group list-group-unbordered">
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Addmission No. </b>
                            <div className=" pull-right">{student_info.admission_number}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Class</b>
                            <div className=" pull-right">{student_info.stu_class}</div>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="card mb-4">
                      <div className="card-body p-0">
                        <ul className="list-group list-group-unbordered">

                          <li className="list-group-item d-flex justify-content-between">
                            <b>Gender </b>
                            <div className=" pull-right">{student_info.gender}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Father's Name</b><span className="pull-right">{student_info.father_name}</span>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Mother's Name</b> <span className="pull-right">{student_info.mother_name}</span>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Email </b>
                            <div className=" pull-right">{student_info.email_address}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Mobile</b>
                            <div className=" pull-right">{student_info.mobile_number}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b>Mobile(Msz.)</b>
                            <div className=" pull-right">{student_info.message_mob}</div>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="card mb-4">
                      <div className="card-head card-topline-aqua">
                        <header className="p-2">Address</header>
                      </div>
                      <div className="card-body p-0">
                        <div className="row text-center m-t-10">
                          <div className="col-md-12">
                            <p>{student_info.habitation_or_locality}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* BEGIN PROFILE CONTENT */}
                  <div className="profile-content">
                    <div className="row">
                      <div className="card">
                        <div className="card-topline-aqua">
                          <header />
                        </div>
                        <div className="card-body">
                          <div className="tab-content">
                            <div id="biography">
                              <h5 className="font-bold">Fee Statement</h5>
                              <table className="table table-striped table-bordered table-responsive">
                                <thead>
                                  <tr>
                                    <th></th>
                                    <th>Fee Title</th>
                                    <th>Jul</th>
                                    <th>Aug</th>
                                    <th>Sep</th>
                                    <th>Oct</th>
                                    <th>Nov</th>
                                    <th>Dec</th>
                                    <th>Jan</th>
                                    <th>Feb</th>
                                    <th>Mar</th>
                                    <th>Apr</th>
                                    <th>May</th>
                                    <th>Jun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>1</td>
                                    <td>Monthly</td>
                                    <td> {(this.filterInArray('monthly', 'July')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'August')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'September')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'October')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'November')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'December')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'January')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'February')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'March')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'April')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'May')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('monthly', 'June')) ? <i className="fa fa-check"></i> : null}</td>
                                  </tr>
                                  <tr>
                                    <td>1</td>
                                    <td>Convence</td>
                                    <td> {(this.filterInArray('convence', 'July')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'August')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'September')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'October')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'November')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'December')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'January')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'February')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'March')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'April')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'May')) ? <i className="fa fa-check"></i> : null}</td>
                                    <td> {(this.filterInArray('convence', 'June')) ? <i className="fa fa-check"></i> : null}</td>
                                  </tr>
                                </tbody>
                              </table>
                              <ul className="list-group">
                                <li className="list-group-item d-flex justify-content-between d-flex justify-content-between align-items-center">
                                  Registration Fee
    <span className="badge badge-primary badge-pill">
                                    {(this.reg_fee === 'oneTime') ? <i className="fa fa-check"></i> : null}
                                  </span>
                                </li>
                                <li className="list-group-item d-flex justify-content-between d-flex justify-content-between align-items-center">
                                  Sports Fee
    <span className="badge badge-primary badge-pill">
                                    {(this.sports_fee === 'onetTime') ? <i className="fa fa-check"></i> : null}
                                  </span>
                                </li>
                                <li className="list-group-item d-flex justify-content-between d-flex justify-content-between align-items-center">
                                  Exam Fee
    <span className="badge badge-primary badge-pill">
                                    {(this.exam_fee === 'oneTime') ? null : <i className="fa fa-check"></i>}
                                  </span>
                                </li>
                              </ul>
                              <br />
                              <h5 className="font-bold">Marks</h5>
                              <hr />
                              <table className="table table-striped table-bordered table-responsive">
                                <thead>
                                  <tr>
                                    <th></th>
                                    <th>Subject</th>
                                    <th>1st</th>
                                    <th>2nd</th>
                                    <th>Half Year</th>
                                    <th>3rd</th>
                                    <th>Annual</th>
                                    <th>Total</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>1</td>
                                    <td>Hindi</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                  <tr>
                                    <td>2</td>
                                    <td>English</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                  <tr>
                                    <td>3</td>
                                    <td>Math</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                  <tr>
                                    <td>4</td>
                                    <td>S. Science</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                  <tr>
                                    <td>5</td>
                                    <td>Science</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                  <tr>
                                    <td>6</td>
                                    <td>Sanskrit</td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                    <td> </td>
                                  </tr>
                                </tbody>
                              </table>
                              <ul className="list-group">
                                <li className="list-group-item d-flex justify-content-between d-flex justify-content-between align-items-center">
                                  Grade in Class
    <span className="badge badge-primary badge-pill">
                                    A+
                            </span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* END PROFILE CONTENT */}
                </div>
              </div>
            }
          </div>
          {user &&
            <div className="card-footer d-flex p-2">
              {(user.user_category !== "4") ?
                <>
                  <button type="button"
                    onClick={event => this.getPrevStudentRecord(event, prev_id)}
                    disabled={is_prev}
                    className="btn btn-primary text-white">
                    <i className="fa fa-angle-left"></i>
                  </button>
                  <button type="button"
                    onClick={event => this.getPrevStudentRecord(event, next_id)}
                    disabled={is_next}
                    className="btn btn-primary ml-3 text-white">
                    <i className="fa fa-angle-right"></i>
                  </button>
                  <NavLink className="btn btn-primary mr-2 ml-auto" to={`/edit_student.jsp/${student_info.s_id}`}>
                    Edit</NavLink>
                </>
                : null}
              <NavLink to="/all_students.jsp" className="btn btn-danger">Back</NavLink>
            </div>
          }
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  // const { item: schools } = state.schools;
  // const { item: conveyance } = state.conveyance;
  const { item: students } = state.students;
  const filteredClassesData = state.filteredClassesData;
  return { user, students, filteredClassesData };
}

const actionCreators = {
  // getConveyance: conveyanceAction.getConveyance,
  getStudents: studentsAction.getStudents,
  getFeeDepositedCurrentStudent: feeDepositedCurrentStudentAction.getFeeDepositedCurrentStudent,
}

export default connect(mapStateToProps, actionCreators)(withRouter(StudentProfile));