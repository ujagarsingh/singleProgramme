import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
  schoolsAction, classesAction, subjectsAction, examsAction, studentsAction,
  maxMarksAction, marksObtainAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_EXAMS = `http://schools.rajpsp.com/api/exam/read_exams_by_class.php`;
// const READ_SUB_MARKS = `http://schools.rajpsp.com/api/exam/read_max_marks_subject.php`;
// const READ_SUBJECT = `http://schools.rajpsp.com/api/subject/read.php`;
// const GET_STUDENTS_BY_CLASS = `http://schools.rajpsp.com/api/students/read_students_by_class.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
const CREATE_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/create_multiple.php`;
// const READ_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/read_specific.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;  

class AddMarks extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    students: [],
    all_classes: [],
    selected_classes: [],
    selected_exams: [],
    subjects: [],
    classwise_subject: [],
    selected_student: [],
    display_student: [], // for add ischeck and max_marks
    update_student: [], // for only check student when submit
    selected_subject: '',
    selected_subject_inx: '',
    selected_class: '',
    selected_class_inx: '',
    selected_exam: '',
    selected_exam_inx: '',
    select_all: false,
    class_id: '',
    exam_id: '',
    subject_id: '',
    max_marks: '',
    medium: '',
    selectAllStudentCheck: false,
    formIsHalfFilledOut: false,
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      // const _inx = event.target.value;
      // const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      // const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      // sessionStorage.setItem("school_id", _sch_id);
      // this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      // this.setState({
      //   school_id: _sch_id,
      //   medium_arr: _medium,
      //   medium: (_medium.length === 1 ? _medium[0] : ''),
      //   selected_school_index: _inx,
      //   selected_class_inx: ''
      // })
    } else if (fieldName === 'selected_class') {
      // const _class_inx = event.target.value;
      // // const _class_name = this.state.selected_classes[_class_inx].stu_class;
      // // sessionStorage.setItem("class_name_portal", _class_name);
      // this.classHandler(_class_inx);
    } else if (fieldName === 'all_checks') {
      this.selectAllStudentHandler();
    } else if (fieldName === 'selected_exam') {
      const _examIdx = event.target.value;
      if (_examIdx !== '') {
        const _exam_name = this.state.selected_exams[_examIdx].exam_name;
        const _exam_id = this.state.selected_exams[_examIdx].id;
        const _exam_cat_id = this.state.selected_exams[_examIdx].exam_cat_id;
        this.setState({
          selected_exam: _exam_name,
          selected_exam_inx: _examIdx,
          selected_exam_cat_id: _exam_cat_id,
          exam_id: _exam_id,
          selected_subject: '',
          selected_subject_inx: '',
          subject_id: '',
          max_marks: ''
        })
        this.resetMarksObtain();
        this.classWiseSubjectHandler(_exam_cat_id);
      } else {
        this.setState({
          selected_exam: '',
          selected_exam_inx: '',
          selected_exam_cat_id: '',
          exam_id: '',
          selected_subject: '',
          selected_subject_inx: '',
          subject_id: '',
          max_marks: ''
        })
      }
    } else if (fieldName === 'selected_subject') {
      const _subIdx = event.target.value;
      if (_subIdx !== '') {
        const _class_id = this.state.class_id;
        const _exam_id = this.state.exam_id;
        const _subject_id = this.state.classwise_subject[_subIdx].id;
        const _subject_name = this.state.classwise_subject[_subIdx].sub_name;
        this.getSubMarksAccordingExam(_class_id, _exam_id, _subject_id);
        this.setState({
          subject_id: _subject_id,
          selected_subject: _subject_name,
          selected_subject_inx: _subIdx,
        })
      }
    } else if (fieldName === 'subject_marks') {
      const _max_marks = parseInt(this.state.max_marks);
      const _marks_val = (event.target.value !== '') ? event.target.value : 0;
      const _stu_idx = parseInt(event.target.getAttribute('data-stu-idx'));
      var _updated_student = this.state.display_student.map((item, index) => {
        if (_stu_idx === index && parseInt(_marks_val) <= _max_marks) {
          return item = { ...item, 'marks_obtain': _marks_val }
        } else {
          return item
        }
      })
      //console.log(_updated_student);
      this.setState({
        display_student: _updated_student
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      // this.filterClassesOnSchool(_medium);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      });
    }
  };

  // filterClassesOnSchool(sch_id, group_id) {
  //   const _classes = this.props.classes.filter((item, inx) => {
  //     if (item.group_id === group_id && item.school_id === sch_id && item.is_section !== 'Yes') {
  //       return item
  //     }
  //     return false
  //   })
  //   this.setState({
  //     selected_classes: _classes,
  //     selected_class: '',
  //     display_student: [],
  //     selected_exam: '',
  //     selected_subject: '',
  //     subject_id: '',
  //     max_marks: ''
  //   })
  // }

  classHandler(_class_inx) {
    if (_class_inx !== '') {
      const _fltr_class = this.props.filteredClassesData;
      const _class_idx = parseInt(_class_inx);
      const _class_id = _fltr_class.slct_cls_id;
      const _class_name = _fltr_class.slct_cls_name;
      this.getExamAccordingClass(_class_id);
      this.setState({
        class_id: _class_id,
        selected_class: _class_name,
        selected_class_inx: _class_idx,
        selected_exam_inx: '',
        selected_subject: '',
        selected_exam: '',
        subject_id: '',
        exam_id: '',
        max_marks: ''
      });
    } else {
      this.setState({
        class_id: '',
        selected_class: '',
        selected_class_inx: '',
        selected_exam_inx: '',
        selected_subject: '',
        selected_exam: '',
        subject_id: '',
        exam_id: '',
        max_marks: ''
      })
    }
  }
  resetMarksObtain = () => {
    const _display_student = this.state.display_student.map((chkitem) => {
      const item = { ...chkitem, marks_obtain: '' };
      return item;
    })
    this.setState({
      display_student: _display_student
    })
  };
  checkHandler = (event, fieldName, value) => {
    let _students = null;
    let _current_select = JSON.parse(value).admission_number;
    if (fieldName === 'select_this') {
      _students = this.state.display_student.map((chkitem) => {
        if (_current_select === chkitem.admission_number) {
          chkitem['checked'] = !chkitem.checked;
          return chkitem;
        }
        return chkitem;
      })
      this.setState({
        update_student: _students
      })
    } else if (fieldName === 'select_all') {
      _students = this.state.display_student.filter((chkitem) => {
        chkitem['checked'] = (event.target.checked) ? true : false;
        return chkitem;
      })
      this.setState({
        update_student: _students,
        select_all: !this.state.select_all,
      })
    }
    this.setState({
      display_student: _students,
    })
  };

  // get all subject name accoding to class
  classWiseSubjectHandler(exam_cat_id) {
    const _class_id = this.state.class_id;
    const _exam_cat_id = exam_cat_id;
    //classwise_subject
    const _subejcts = this.props.subjects.filter((item) => {
      if (item.class_id === _class_id && item.exam_cat_id === _exam_cat_id) {
        return item
      } else {
        return false
      }
    })

    const merge_sub_name = _subejcts.map((item) => {
      if (item.sub_parent_id > 0) {
        let _parent_name = '';
        _subejcts.forEach((sub) => {
          if (item.sub_parent_id === sub.id) {
            _parent_name = sub.sub_name;
          }
        })
        return { ...item, sub_name: _parent_name + '_' + item.sub_name };
      }
      return item;
    })
    //console.log(JSON.stringify(merge_sub_name))
    const filtered_sub = merge_sub_name.filter((item) => {
      if (item.sub_lavel !== '2') {
        return item
      }
    })
    //console.log(JSON.stringify(filtered_sub))

    this.setState({
      classwise_subject: filtered_sub
    })
  }

  selectAllStudentHandler() {
    this.setState({
      selectAllStudentCheck: !this.state.selectAllStudentCheck
    })
  }
  getExamAccordingClass = (class_id) => {
    // const _medium = this.state.medium;
    const _selected_exams = this.props.exams.filter((item) => {
      if (item.class_id === class_id) {
        return item
      }
    })
    this.setState({
      selected_exams: _selected_exams,
    });

    // console.log(_selected_exams);
    // // read all exas list
    // loadProgressBar();
    // let obj = {
    //   class_id: class_id,
    //   group_id: this.state.group_id,
    //   school_id: this.state.school_id,
    // };
    // // console.log(JSON.stringify(obj))
    // axios.post(GET_EXAMS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     if (getRes.message !== undefined) {
    //       Alert.error(getRes.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //     } else {
    //       // debugger
    //       const _exams = getRes.filter((item, inx) => {
    //         if (item.medium === this.state.medium) {
    //           return item
    //         } else {
    //           return false
    //         }
    //       })
    //       this.setState({
    //         exams: _exams,
    //         errorMessages: getRes.message
    //       });
    //     }
    //     ////console.log(this.state.classes);
    //   }).catch((error) => {
    //     // error
    //   })
  }

  getSubMarksAccordingExam = (class_id, exam_id, sub_id) => {
    const _max_marks = this.props.maxMarks.filter((item) => {
      if (item.class_id === class_id && item.exam_id === exam_id && item.sub_id === sub_id) {
        return item
      }
    })
    if (_max_marks.length > 0) {
      const sub_max_marks = _max_marks[0].max_marks;
      this.setState({
        max_marks: sub_max_marks
      })
    } else {
      Alert.error("This Subject Max-Marks Not Found", {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }

    const _students = this.state.selected_student.map((item) => {
      const _admission_number = item.admission_number;
      if (this.props.marksObtain.length > 0) {
        this.props.marksObtain.map((item_1) => {
          if (_admission_number === item_1.admission_number &&
            this.state.exam_id === item_1.exam_id &&
            this.state.subject_id === item_1.sub_id) {
            item['marks_obtain'] = item_1.marks_obtain;
            item['marks_obtain_id'] = item_1.id;
          }
        })
        return item;
      } else {
        item['marks_obtain'] = ''
        return item;
      }

    })
    this.setState({
      display_student: _students
    })

    // loadProgressBar();
    // // console.log(JSON.stringify(obj));
    // axios.post(READ_SUB_MARKS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     this.setState({
    //       max_marks: getRes.max_marks
    //     })
    //     if (getRes.message !== undefined) {
    //       Alert.error(getRes.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //     }
    //   }).catch((error) => {
    //     // error
    //   });


    // if (this.props.marksObtain.length > 0) {
    //   const _students = this.props.students.map((item) => {
    //     const _admission_number = item.admission_number;
    //     if (this.props.marksObtain.length > 0) {
    //       this.props.marksObtain.map((item_1) => {
    //         if (_admission_number === item_1.admission_number &&
    //           this.state.exam_id === item_1.exam_id &&
    //           this.state.subject_id === item_1.sub_id) {
    //           item['marks_obtain'] = item_1.marks_obtain;
    //           item['marks_obtain_id'] = item_1.id;
    //         }
    //       })
    //       return item;
    //     } else {
    //       item['marks_obtain'] = ''
    //       return item;
    //     }

    //   })
    //   this.setState({
    //     display_student: _students
    //   })
    // } else {
    //   alert("Marks Obtain Not Found")
    // }

    // axios.post(READ_MAX_MARKS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes);
    //     const _students = this.state.students.map((item, index) => {
    //       const _admission_number = item.admission_number;
    //       if (getRes.length > 0) {
    //         getRes.map((item_1) => {
    //           if (_admission_number === item_1.admission_number &&
    //             this.state.exam_id === item_1.exam_id &&
    //             this.state.subject_id === item_1.sub_id) {
    //             item['marks_obtain'] = item_1.marks_obtain;
    //             item['marks_obtain_id'] = item_1.id;
    //           }
    //         })
    //         return item;
    //       } else {
    //         item['marks_obtain'] = ''
    //         return item;
    //       }

    //     })
    //     this.setState({
    //       display_student: _students
    //     })

    //   }).catch((error) => {
    //     // error
    //   });
  }
  // getStudentRecords = (class_id) => {
  //   // const _school_id = this.state.school_id;
  //   // const _students_of_class = this.props.students.filter((item) => {
  //   //   if (item.stu_class === class_id && item.school_id === _school_id) {
  //   //     return item;
  //   //   }
  //   // })
  //   // if (_students_of_class.length > 0) {
  //   //   const _students = _students_of_class.map((student) => {
  //   //     const xyz = { ...student };
  //   //     xyz['checked'] = false;
  //   //     xyz['marks_obtain'] = '';
  //   //     return xyz;
  //   //   })
  //   //   this.setState({
  //   //     selected_student: _students,
  //   //     display_student: _students
  //   //   })
  //   // } else {
  //   //   Alert.error("Student Not Found", {
  //   //     position: 'bottom-right',
  //   //     effect: 'jelly',
  //   //     timeout: 5000, offset: 40
  //   //   });
  //   // }



  //   // const obj = {
  //   //   class_id: this.state.class_id,
  //   //   group_id: this.state.group_id,
  //   //   school_id: this.state.school_id,
  //   //   session_year_id: this.state.session_year_id
  //   // }
  //   // // console.log(JSON.stringify(obj));
  //   // axios.post(GET_STUDENTS_BY_CLASS, obj)
  //   //   .then(res => {
  //   //     const students = res.data.records;
  //   //     if (students.length > 0) {
  //   //       const _students = students.map((student) => {
  //   //         const xyz = { ...student };
  //   //         xyz['checked'] = false;
  //   //         xyz['marks_obtain'] = '';
  //   //         return xyz;
  //   //       })
  //   //       this.setState({
  //   //         students: _students,
  //   //         display_student: _students
  //   //       })
  //   //     } else {
  //   //       Alert.error(res.data.message, {
  //   //         position: 'bottom-right',
  //   //         effect: 'jelly',
  //   //         timeout: 5000, offset: 40
  //   //       });
  //   //     }
  //   //     ////console.log('DATABASE STUDENT :', this.state.students);
  //   //     ////console.log('DISPLAY STUDENT :', this.state.display_student);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   });
  // }


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.subjects)) {
      this.props.getSubjects();
    }
    if (isEmptyObj(this.props.exams)) {
      this.props.getExams();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    if (isEmptyObj(this.props.maxMarks)) {
      this.props.getMaxMarks();
    }
    if (isEmptyObj(this.props.marksObtain)) {
      this.props.getMarksObtain();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      const _all_exams = this.props.exams;
      if (_all_student && _filter && _all_exams) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      this.setState({
        display_student: [..._school_student],
        selected_student: [..._school_student],
      }, () => { this.classHandler(_fltr_class.slct_cls_index) })
    }
  }


  // filteredClasses() {
  //   const _classes = this.props.classes.filter((item, index) => {
  //     if (item.is_section !== 'Yes') {
  //       return item;
  //     }
  //   })
  //   this.setState({
  //     all_classes: _classes
  //   });
  // }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getSubjectsHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getClassesHandler() {
  //   loadProgressBar();
  //   // read all existing class
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       const _classes = classes.filter((item, index) => {
  //         if (item.is_section !== 'Yes') {
  //           return item;
  //         }
  //       })
  //       this.setState({
  //         classes: _classes,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });


  // };
  // getSubjectsHandler() {
  //   // read all subjes according class
  //   loadProgressBar();
  //   axios.get(READ_SUBJECT)
  //     .then(res => {
  //       const subjects = res.data;
  //       this.setState({
  //         subjects: subjects,
  //         errorMessages: subjects.message
  //       });
  //       //console.log(this.state.subjects);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update All.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.updateHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  confirmBoxSubmitSingle = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.singleUpdateHandler(event, id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  singleUpdateHandler = (e, admission_number) => {
    // e.preventDefault();
    const obj = [];
    this.state.display_student.filter((item) => {
      if (item['admission_number'] === admission_number && item.marks_obtain !== '') {
        obj[0] = {
          // max_marks: this.state.max_marks,
          class_id: this.state.class_id,
          exam_id: this.state.exam_id,
          sub_id: this.state.subject_id,
          admission_number: item.admission_number,
          marks_obtain: item.marks_obtain,
          id: item.marks_obtain_id
        }
      }
    })
    const singleObj = { myObj: obj };
    // console.log(JSON.stringify(singleObj));
    loadProgressBar();
    axios.post(CREATE_MAX_MARKS, singleObj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          //display_student: this.state.student,
          selected_subject: '',
          selected_exam: '',
          subject_id: '',
          exam_id: '',
          max_marks: ''
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
    // document.location.reload();
  }
  updateHandler = (e) => {
    //e.preventDefault();
    loadProgressBar();
    let _update_students = this.state.display_student.filter((item) => {
      if (item.marks_obtain !== '') {
        return item
      }
    })
    const _obj = [];
    let counter = 0;
    _update_students.map((item) => {
      _obj[counter] = {
        // max_marks: this.state.max_marks,
        class_id: this.state.class_id,
        exam_id: this.state.exam_id,
        sub_id: this.state.subject_id,
        admission_number: item.admission_number,
        marks_obtain: item.marks_obtain,
        id: item.marks_obtain_id
      }
      counter++;
    })

    const obj = { myObj: _obj };
    //console.log(JSON.stringify(obj));
    axios.post(CREATE_MAX_MARKS, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          //display_student: this.state.student,
          selected_subject: '',
          selected_exam: '',
          subject_id: '',
          exam_id: '',
          max_marks: '',
          select_all: false
        })
        const _display_student = this.state.display_student.map((chkitem) => {
          chkitem['checked'] = false;
          return chkitem;
        })
        this.setState({
          update_student: _display_student
        })
        //document.location.reload();
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  render() {
    const { select_all, all_classes, selected_class_inx, selected_classes, display_student, selected_school_index,
      selected_subject_inx, classwise_subject, selected_class, formIsHalfFilledOut, medium_arr,
      selected_exam_inx, selected_exam, selected_subject, max_marks, medium, selected_exams } = this.state;
    const { user, schools, classes, subjects, exams, students, maxMarks, marksObtain } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Add Marks</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Add Subject Wise Marks</div>
          {user && schools && classes && subjects && exams && students && maxMarks && marksObtain &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="mr-2">Class:</label>
                  <select
                    value={selected_class_inx}
                    disabled={medium === '' ? true : false}
                    className="form-control form-control-sm" name="selected_class"
                    onChange={event => this.changeHandler(event, 'selected_class')} >
                    <option value="">Select...</option>
                    {selected_classes.map((option, index) => {
                      return (<option key={index} value={index}>{option.class_name}</option>)
                    })}
                  </select>
                </div> */}
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />

                <div className="form-group mr-2 mt-1">
                  <label className="mr-2">Exam:</label>
                  <select
                    value={selected_exam_inx}
                    disabled={selected_class === '' ? true : false}
                    className="form-control form-control-sm" name="selected_exam"
                    onChange={event => this.changeHandler(event, 'selected_exam')} >
                    <option value="">Select...</option>
                    {selected_exams.map((option, index) => {
                      return (<option key={index} value={index}>{option.exam_name}</option>)
                    })}
                  </select>
                </div>
                <div className="form-group mt-1">
                  <label className="mr-2">Subject:</label>
                  <select
                    value={selected_subject_inx}
                    disabled={selected_exam === '' ? true : false}
                    className="form-control form-control-sm" name="selected_subject"
                    onChange={event => this.changeHandler(event, 'selected_subject')} >
                    <option value="">Select...</option>
                    {classwise_subject.map((option, index) => {
                      return (<option key={index} value={index}>{option.sub_name}</option>)
                    })}
                  </select>
                </div>
              </div>
            </div>
          }
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th>
                      <div className="custom-control custom-checkbox">
                        <input type="checkbox"
                          id="select_all" className="custom-control-input"
                          checked={select_all}
                          onChange={event => this.checkHandler(event, 'select_all', true)} />
                        <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                      </div>
                    </th>
                    <th />
                    <th>Sr. No.</th>
                    <th>Student & Father's Name</th>
                    <th>Class</th>
                    <th>Roll No.</th>
                    <th>Marks</th>
                    <th>Marks Obtain {}</th>
                    <th>Action</th>
                  </tr>
                </thead>
                {display_student.length > 0 ?
                  <tbody>
                    {display_student.map((item, index) => {
                      return (
                        <tr className={(item.free_seat === '0') ? 'odd gradeX' : 'odd gradeX table-warning'} key={index}>
                          <td>
                            <div className="custom-control custom-control-inline custom-checkbox">
                              <input type="checkbox"
                                checked={item.checked}
                                id={`check_` + index} name="customRadio" className="custom-control-input"
                                onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
                              <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                            </div>
                          </td>
                          <td className="profile-pic">
                            <NavLink className="" to={`student_profile.jsp/${item.admission_number}`}>
                              {item.student_image !== '' ?
                                < img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
                                : (item.gender === 'Boy' ?
                                  <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                  :
                                  <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                              }
                            </NavLink>
                          </td>
                          <td>{item.admission_number}</td>
                          <td><NavLink className="" to={`student_profile.jsp/${item.admission_number}`}>
                            {item.student_name}
                          </NavLink>
                            <br /> S/o  {item.father_name}</td>
                          <td>{item.stu_class}</td>
                          <td>{item.roll_number}</td>
                          <td>{max_marks}</td>
                          <td>
                            {(selected_subject !== '' && max_marks) ?
                              <input type="number"
                                value={item.marks_obtain}
                                data-stu-idx={index}
                                className="form-control form-control-sm"
                                onChange={event => this.changeHandler(event, 'subject_marks')} />
                              : null}
                          </td>

                          <td className="">
                            <div className="btn-group btn-group-toggle" data-toggle="buttons">
                              {/*<NavLink to={`student_profile.jsp/${item.admission_number}`} className="btn btn-danger btn-sm">
                                Show
                              </NavLink>
                              <NavLink to={`/edit_student/${item.admission_number}`} className="btn btn-primary btn-sm">
                                Edit
                      </NavLink>*/}
                              <button type="button" className="btn btn-secondary btn-sm"
                                disabled={(item.marks_obtain !== '') ? false : true}
                                onClick={event => this.confirmBoxSubmitSingle(event, item.admission_number)}>
                                <i className="fa fa-check"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}

                  </tbody>
                  : null}
              </table>
            </div>
          </div>
          <div className="card-footer text-right p-1">
            <button type="button"
              disabled={(this.state.update_student.length > 0) ? false : true}
              onClick={event => this.confirmBoxSubmit(event)}
              className="btn btn-primary mr-2">Update</button>
            <NavLink to="#" className="btn btn-danger">Reset</NavLink>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: subjects } = state.subjects;
  const { item: exams } = state.exams;
  const { item: students } = state.students;
  const { item: maxMarks } = state.maxMarks;
  const { item: marksObtain } = state.marksObtain;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return { user, schools, classes, subjects, exams, students, maxMarks, marksObtain, filteredSchoolData, filteredClassesData };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getSubjects: subjectsAction.getSubjects,
  getExams: examsAction.getExams,
  getStudents: studentsAction.getStudents,
  getMaxMarks: maxMarksAction.getMaxMarks,
  getMarksObtain: marksObtainAction.getMarksObtain,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddMarks));