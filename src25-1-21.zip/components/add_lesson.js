import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import DatePicker from 'react-date-picker';
import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import ReactYoutubePlayer from "../utility/youtubePlayer";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, subjectsAction, sessionYearsAction, monthlyLessonAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const CREATE_LESSON = `http://schools.rajpsp.com/api/lessons/create.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
// const READ_SESSION_YEAR = `http://schools.rajpsp.com/api/session_year_id/read.php`;

class AddLesson extends Component {
  state = {
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    session_year_inx: 1,
    classes: [],
    selected_classes: [],
    subjects_obj: [],
    subjects_of_class: [],
    lesson_type_arr: [{ 'id': "1", "les_type": "Video" }],
    class_id: '',
    medium: '',
    lesson_date: new Date(),
    // exam_cat_arr: [],
    existingLesson: [{
      les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
    }],
    lesson_obj: [{
      les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
    }],
    formIsHalfFilledOut: false,
  }

  lessonDateHandlar = (_date) => {
    this.setState({ lesson_date: _date });
  };
  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: ''
    //   })
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   const _classes = this.props.classes.filter((item, inx) => {
    //     if (item.medium === _medium) {
    //       return item
    //     }
    //   })
    //   this.setState({
    //     selected_classes: _classes
    //   })
    // } else if (fieldName === 'stu_class') {
    //   const _inx = event.target.value;
    //   this.getSubjectsOfClass(_inx);

    // } else {

    // }
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      //selected_subjects: ''
    })
  }
  getSubjectsOfClass() {
    // const _class_id = this.state.selected_classes[idx].id;
    const _fltr_class = this.props.filteredClassesData;
    const _subejcts = this.props.subjects.filter((item) => {
      if (item.class_id === _fltr_class.slct_cls_id && item.sub_parent_id === "0") {
        return item
      }
    })
    // const filtered_sub = _subejcts.filter((item) => {
    //   if (item.sub_parent_id === "0") {
    //     return item
    //   }
    // })
    this.setState({
      subjects_of_class: _subejcts,
    })
  }
  lessonDataHandler = (event, index) => {
    let _str = event.target.value;
    let fild_name = event.target.name;
    let _newItem = "";
    _newItem = this.state.lesson_obj.map((item, sidx) => {
      if (index !== sidx) return item;
      return { ...item, [fild_name]: _str };
    });
    this.setState({ lesson_obj: _newItem });

  };

  handleAddSubject = (event, index) => {
    this.setState({
      lesson_obj: this.state.lesson_obj.concat([{
        les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
      }])
    });
  };
  confirmBoxDelete = (event, index) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.handleRemoveSubject(event, index);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };


  handleRemoveSubject = (event, index) => {
    if (this.state.lesson_obj.length > 1) {
      this.setState({
        lesson_obj: this.state.lesson_obj.filter((s, sidx) => index !== sidx)
      })
    }
  };



  // getSessionYearHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  // //   axios.post(READ_SESSION_YEAR, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         sessionYear: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  getSelectedClassHandler = (event) => {
    const _class_id = event.target.value;
    this.setState({ class_id: _class_id });
  }
  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.subjects)) {
      this.props.getSubjects();
    }
    if (isEmptyObj(this.props.sessionYears)) {
      this.props.getSessionYears();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_subjects = this.props.subjects;
      if (_all_subjects && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _all_classes = this.props.classes;
    //const _fltr_class = this.props.filteredClassesData;
    if (!isEmptyObj(_all_classes)) {
      const _school_classes = _all_classes.filter((item) => {
        if (item.school_id === _fltr_school.slct_school_id) {
          return item
        }
      })
      this.setState({
        selected_classes: _school_classes
      })
    }

    this.filterByClsHandler()
  }

  filterByClsHandler = () => {
    // this.getCurrentLessonHandler();
    this.getSubjectsOfClass();
  }


  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getSchoolHandler();
  //           // this.getSubjectsHandler();
  //           // this.getClassesHandler();
  //           this.getSessionYearHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getExamTypeHandler() {
  //   loadProgressBar();
  //   axios.get(READ_EXAM_CATE)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         exam_cat_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getSubjectsHandler() {
  //   loadProgressBar();
  //   axios.get(READ_SUBJECTS)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.message !== undefined) {
  //         Alert.error(resData.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000,
  //         });
  //       } else {
  //         this.setState({
  //           subjects: resData
  //         });
  //         //console.log(this.state.subjects);
  //       }
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       if (this.state.user_category === "1") {
  //         this.setState({
  //           classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       } else {
  //         this.setState({
  //           classes: classes,
  //           selected_classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       }
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  // getConvertedDay(str) {
  //   var currnt_date = new Date(str);
  //   // let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  //   var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  //   return months[currnt_date.getMonth()];
  //   // return days[currnt_date.getDay()].toUpperCase();
  // }

  submitHandler = () => {
    loadProgressBar();

    const { medium, lesson_date, session_year_inx, lesson_obj } = this.state;
    const _lesson = lesson_obj.filter((item) => {
      return item.les_link.length > 0
    })
    const real_date = lesson_date.getFullYear() + "-" + (lesson_date.getMonth() + 1) + "-" + lesson_date.getDate();
    const obj = {
      school_id: this.props.filteredSchoolData.slct_school_id,
      session_year_id: session_year_inx,
      class_id: this.props.filteredClassesData.slct_cls_id,
      lesson_arr: _lesson,
      les_date: real_date,
      les_month: (lesson_date).getMonth() + 1,
      medium: medium,
    };

    console.log(JSON.stringify(obj));
    this.props.create(obj)

    // // debugger
    // axios.post(CREATE_LESSON, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  };
  render() {
    const { lesson_obj, medium, selected_school_index, medium_arr, selected_classes,
      lesson_date, class_id, lesson_type_arr, school_id, subjects_of_class,
      session_year_inx, formIsHalfFilledOut } = this.state;
    const { user, schools, classes, sessionYears, subjects,      filteredSchoolData, filteredClassesData} = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Add Lesson</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && classes && sessionYears && subjects &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">Add Lesson</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  {/* <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Class :</label>
                    <select className="form-control form-control-sm" name="stu_class"
                      value={class_id}
                      onChange={event => this.changeHandler(event, 'stu_class')}>
                      <option value="">Select...</option>
                      {selected_classes.map((option, index) => {
                        return (
                          <option key={index}
                            value={option.id}>
                            {option.class_name} [{option.class_name_portal}]
                          </option>
                        )
                      })}
                    </select>
                  </div> */}
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                    filterByClsHandler={this.filterByClsHandler}
                  />
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Session Year : </label>
                    <select className="form-control form-control-sm"
                      required
                      ref='session_year_id'
                      value={session_year_inx}
                      onChange={event => this.changeHandler(event, 'session_year_id')}>
                      <option value="">Select ...</option>
                      {sessionYears.map((item, index) => {
                        return (
                          <option key={index} value={item.id}>{item.ses_year}</option>
                        )
                      })}
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
              <div className="d-flex  p-3 pb-1">
                {/* <div className="form-group">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">Grid</button>
                <button type="button" className="btn btn-sm btn-secondary">Card</button>
              </div>
            </div> */}
                <div className="form-group form-inline ml-auto">
                  <label className="control-label mr-2">Date<span className="required"> * </span>
                  </label>
                  <div className="datePicker">
                    <DatePicker
                      onChange={this.lessonDateHandlar}
                      value={lesson_date}
                      showLeadingZeroes={true}
                    />
                  </div>
                </div>
              </div>
              <div className="card-body pt-0 sfpage-body">
                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm">
                    <thead>
                      <tr>
                        <th />
                        <th> Video Id / Image Link / Star - End Point </th>
                        <th> View Uploaded Data</th>
                        <th> Subject /  Lesson Title(Topic) / Remark</th>
                        <th> Action </th>
                      </tr>
                    </thead>
                    <thead>
                      {(lesson_obj.length > 0 && filteredSchoolData.slct_school_id !== '') ? lesson_obj.map((item, index) => (
                        <tr key={index}>
                          <td>
                            {index + 1}
                          </td>
                          <td>
                            <div className="form-group">
                              <select className="form-control form-control-sm"
                                required
                                disabled={(filteredClassesData.slct_cls_id) ? false : true}
                                name='les_type'
                                onChange={event => this.lessonDataHandler(event, index)}>
                                <option value="">Select Type...</option>
                                {lesson_type_arr.map((item, index) => {
                                  return (
                                    <option key={index} value={item.id}>{item.les_type}</option>
                                  )
                                })}
                              </select>
                            </div>
                            <div className="form-group">
                              <input
                                type="text"
                                required
                                disabled={(filteredClassesData.slct_cls_id) ? false : true}
                                placeholder="Video ID"
                                className="form-control form-control-sm"
                                autoComplete="off"
                                name="les_link"
                                value={item.les_link}
                                onChange={event => this.lessonDataHandler(event, index)} />
                            </div>
                            <div className="form-group row">
                              <div className="col-6">
                                <input
                                  type="text"
                                  placeholder="Start Point"
                                  className="form-control form-control-sm"
                                  autoComplete="off"
                                  disabled={true}
                                  name="les_sP"
                                  value={item.les_sP}
                                  onChange={event => this.lessonDataHandler(event, index)} />
                              </div>
                              <div className="col-6">
                                <input
                                  type="text"
                                  placeholder="End Point"
                                  className="form-control form-control-sm"
                                  autoComplete="off"
                                  disabled={true}
                                  name="les_eP"
                                  value={item.les_eP}
                                  onChange={event => this.lessonDataHandler(event, index)} />
                              </div>
                            </div>
                          </td>
                          <td className="les_video_data">
                            <ReactYoutubePlayer videoId={item.les_link} videoClass={"vp-MiddleThumb"} />
                          </td>

                          <td>
                            <div className="form-group">
                              <select className="form-control form-control-sm"
                                required
                                disabled={(filteredClassesData.slct_cls_id) ? false : true}
                                name="les_sub"
                                value={item.les_sub}
                                onChange={event => this.lessonDataHandler(event, index)}>
                                <option value="">Select Subject ...</option>
                                {subjects_of_class.map((item, index) => {
                                  return (
                                    <option key={index} value={item.id}>{item.sub_name}</option>
                                  )
                                })}
                              </select>
                            </div>
                            <div className="form-group">
                              <input
                                type="text"
                                required
                                disabled={(filteredClassesData.slct_cls_id) ? false : true}
                                placeholder="Lesson Title"
                                className="form-control form-control-sm"
                                autoComplete="off"
                                name="les_title"
                                value={item.les_title}
                                onChange={event => this.lessonDataHandler(event, index)} />
                            </div>
                            <div className="form-group">
                              <input
                                type="text"
                                disabled={(filteredClassesData.slct_cls_id) ? false : true}
                                placeholder="Remark"
                                className="form-control form-control-sm"
                                autoComplete="off"
                                name="les_remark"
                                value={item.les_remark}
                                onChange={event => this.lessonDataHandler(event, index)}
                              />
                            </div>
                          </td>

                          <td>
                            <div className="form-group pb-2">
                              <button
                                type="button"
                                className="btn btn-danger btn-sm w-100"
                                onClick={event => this.confirmBoxDelete(event, index)} >
                                Delete</button>
                            </div>
                            <div className="form-group mt-4">
                              <button
                                type="button"
                                onClick={event => this.handleAddSubject(event)}
                                className="btn btn-info  w-100">
                                Add More</button>
                            </div>
                          </td>
                        </tr>
                      )) : null}
                    </thead>
                  </table>

                </div>
              </div>

              <div className="card-footer d-flex">
                <span className="p-2">1. please add all lesson.</span>
                <button type="submit" className="btn btn-primary btn-sm ml-auto mr-2 ">Submit</button>
                <NavLink to="/all_lesson.jsp" className="btn btn-danger btn-sm">All Lesson</NavLink>
              </div>
            </form >
          </>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: sessionYears } = state.sessionYears;
  const { item: subjects } = state.subjects;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, classes, sessionYears, subjects,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getSubjects: subjectsAction.getSubjects,
  getSessionYears: sessionYearsAction.getSessionYears,
  create: monthlyLessonAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddLesson));
