import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import DatePicker from 'react-date-picker';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import MyImage from '../utility/my_image';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const READ_ONE = `http://schools.rajpsp.com/api/events/read_one.php`;
// const UPDATE_EVENT = `http://schools.rajpsp.com/api/events/update.php`;

class EditEvent extends Component {
  state = ({
    id: "",
    title: "",
    medium_arr: [],
    medium: "",
    type: "",
    description: "",
    date_start: new Date(),
    date_end: new Date(),
    formIsHalfFilledOut: false,
    event_img: "",
    crop: {
      unit: "%",
      width: 50,
      aspect: 16 / 9
    },
    final_size: {
      width: 640,
      height: 360
    }
  })
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
      })
    } else if (fieldName === 'type') {
      this.setState({
        type: event.target.value
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  startDateHandler = (getDate) => {
    this.setState({ date_start: getDate });
    //this.to.endDateHandler();
  };
  endDateHandler = (getDate) => {
    this.setState({ date_end: getDate });
    //this.to.openCalendar();
  };
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      event_img: data
    })
  }
  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.selected_item;
    console.log(obj);
    debugger;

    this.setState({
      id: obj.id,
      title: obj.title,
      type: obj.type,
      medium: obj.medium,
      description: obj.description,
      date_start: this.getDateObjectHandler(obj.date_start),
      date_end: this.getDateObjectHandler(obj.date_end),
      event_img: obj.event_img,
      school_id: obj.school_id
    })
    this.setIndexSelectedItem(obj.school_id)
  }
  getDateObjectHandler(d_obj) {
    const date_obj = new Date(d_obj);
    return date_obj;
  }
  setIndexSelectedItem(sch_id) {
    let _index = '';
    this.props.schools.filter((item, index) => {
      if (item.id === sch_id) {
        _index = index
      }
    })
    this.setState({
      selected_school_index: _index
    })
  }


  // const { match } = this.props;
  // axios.get(READ_ONE + `?id=` + match.params.id)
  //   .then(res => {
  //     const getRes = res.data;
  //     this.setState({
  //       id: getRes.id,
  //       title: getRes.title,
  //       type: getRes.type,
  //       medium: getRes.medium,
  //       description: getRes.description,
  //       date_start: getRes.date_start,
  //       date_end: getRes.date_end,
  //       event_img: 'img.jpg',
  //       //event_img: getRes.event_img,
  //       errorMessages: getRes.message,
  //     });
  //     ////console.log(this.state.classes);
  //   }).catch((error) => {
  //     // error
  //   })

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    const _state = this.state;
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      // default_obj = { school_id: this.refs.school.value }
    }

    const form_obj = {
      id: this.state.id,
      event_img: this.state.event_img,
      title: this.state.title,
      medium: this.state.medium,
      school_id: this.state.school_id,
      type: this.state.type,
      description: this.state.description,
      date_start: this.state.date_start,
      date_end: this.state.date_end
    }
    
    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);
    

    // axios.post(UPDATE_EVENT, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });

    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  render() {
    const { crop, event_img, final_size, date_end, date_start, title, description,
      medium_arr, type, medium, formIsHalfFilledOut, selected_school_index } = this.state;
    const { user, schools, selected_item } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Event</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && selected_item &&
          <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">Edit Event</div>
            <div className="card-body">
              <div className="row">
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="control-label">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="control-label">Event Title
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="title" placeholder="Event Title"
                        className="form-control form-control-sm"
                        value={title}
                        onChange={event => this.changeHandler(event, 'title')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Select Type
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        value={type}
                        onChange={event => this.changeHandler(event, 'type')}>
                        <option >Select type ...</option>
                        <option >Event</option>
                        <option >Holiday</option>
                        <option >Event and Holiday</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label">Start Date Of Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <DatePicker
                        onChange={this.startDateHandler}
                        value={date_start}
                        showLeadingZeroes={true}
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label">End Date Of Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <DatePicker
                        onChange={this.endDateHandler}
                        value={date_end}
                        showLeadingZeroes={true}
                      //minDate={date_start}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label className="control-label">About Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <textarea name="description" placeholder="About Event"
                        className="form-control-textarea form-control" rows={6}
                        value={description}
                        onChange={event => this.changeHandler(event, 'description')} />
                    </div>
                  </div>

                </div>
                <div className="col-sm-2" >
                  <div className="form-group">
                    <label className="control-label">Event Image
                      </label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onComplete}
                        crop={crop}
                        final_size={final_size}
                      />
                      {event_img !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + event_img} />
                        : null}
                    </div>
                  </div>
                </div >
              </div>
            </div>
            <div className="card-footer text-right">
              <div className="form-actions  text-right">
                <button type="submit" className="btn btn-primary mr-2">Update</button>
                {/* <NavLink to="/all_events.jsp" className="btn btn-danger">Cancel</NavLink> */}
                <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                  Exit </button>
              </div>
            </div>
          </form >
        }
      </div>
    )
  }
}
export default withRouter(EditEvent);