import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import DatePicker from 'react-date-picker';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import ReactYoutubePlayer from "../utility/youtubePlayer";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, subjectsAction, sessionYearsAction, monthlyLessonAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const UPDATE_LESSON = `http://schools.rajpsp.com/api/lessons/update.php`;
// const READ_LESSON = `http://schools.rajpsp.com/api/lessons/read_one.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`; 
// const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read.phpxxx   `;
// const READ_SUBJECTS1 = `http://schools.rajpsp.com/api/subject/read_class_sub.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;  
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_type/read.php`; 
// const READ_SESSION_YEAR = `http://schools.rajpsp.com/api/session_year_id/read.php`;
//const GET_SUBJECT_LAVEL = `http://schools.rajpsp.com/api/subject/create.php`;

class AddLesson extends Component {
  state = {
    schools_arr: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    session_year_arr: [],
    session_year_inx: '',
    sft_classes: [],
    selected_classes: [],
    subjects_obj: [],
    subjects_of_class: [],
    lesson_type_arr: [{ 'id': "1", "les_type": "Video" }],
    class_id: '',
    medium: '',
    lesson_data: "",
    // existingLesson: [{
    //   les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
    // }],
    // lesson_obj: [{
    //   les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
    // }],
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  lessonDateHandlar = (_date) => {
    const lessonData = this.state.lesson_data;
    const real_date = _date.getFullYear() + "-" + (_date.getMonth() + 1) + "-" + _date.getDate();
    this.setState({ lesson_data: { ...lessonData, les_date: real_date } });
  };
  changeHandler = (event, fieldName, isCheckbox) => {
    let get_value = isCheckbox ? event.target.checked : event.target.value;

    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].id : '';
    //   const _medium = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterClassesOnSchool(_sch_id, this.state.group_id);
    //   this.setState({
    //     lesson_data: { ...this.state.lesson_data, sch_id: _sch_id, medium: (_medium.length === 1 ? _medium[0] : '') },
    //     medium_arr: _medium,
    //     selected_school_index: _inx,
    //     selected_class_inx: ''
    //   })
    // } else 
    if (fieldName === 'medium') {
      const _medium = event.target.value;
      const _classes = this.state.sft_classes.filter((item, inx) => {
        if (item.medium === _medium) {
          return item
        }
      })
      this.setState({
        selected_classes: _classes
      })

    } else if (fieldName === 'is_active') {
      const active_val = (get_value) ? "1" : "0";
      this.setState({
        lesson_data: { ...this.state.lesson_data, [fieldName]: active_val },
      })
    } else if (fieldName === 'stu_class') {
      const _inx = event.target.value;
      this.getSubjectsOfClass(_inx);

    } else {
      this.setState({
        lesson_data: { ...this.state.lesson_data, [fieldName]: get_value },
        formIsHalfFilledOut: true
      })

    }
  };
  // filterSchoolById() {
  //   const _sch_id = this.state.lesson_data["sch_id"];
  //   let _inx = null;
  //   this.state.schools_arr.filter((item, index) => {
  //     if (item.id === _sch_id) {
  //       _inx = index;
  //       return item
  //     }
  //   })
  //   const _medium = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_medium : [];
  //   sessionStorage.setItem("school_id", _sch_id);
  //   // this.filterClassesOnSchool(_sch_id, this.state.lesson_data.group_id);
  //   this.setState({
  //     lesson_data: { ...this.state.lesson_data, sch_id: _sch_id, medium: (_medium.length === 1 ? _medium[0] : '') },
  //     medium_arr: _medium,
  //     selected_school_index: _inx,
  //     selected_class_inx: ''
  //   })
  // }
  // filterClassesOnSchool(sch_id, group_id) {
  //   const _classes = this.state.sft_classes.filter((item) => {
  //     if (item.group_id === group_id && item.school_id === sch_id) {
  //       return item
  //     }
  //   })
  //   this.setState({
  //     selected_classes: _classes,
  //     selected_subjects: ''
  //   })
  // }
  getSubjectsOfClass(idx) {
    // const _class_id = this.state.selected_classes[idx].id;
    const _subejcts = this.props.subjects.filter((item) => {
      if (item.class_id === idx && item.sub_parent_id === "0") {
        return item
      }
    })
    this.setState({
      subjects_of_class: _subejcts,
      lesson_data: { ...this.state.lesson_data, ["class_id"]: idx },
    })
  }
  // changeHandler = (event, index) => {
  //   let _str = event.target.value;
  //   let fild_name = event.target.name;
  //   let _newItem = "";
  //   _newItem = this.state.lesson_obj.map((item, sidx) => {
  //     if (index !== sidx) return item;
  //     return { ...item, [fild_name]: _str };
  //   });
  //   this.setState({ lesson_obj: _newItem });

  // };

  // handleAddSubject = (event) => {
  //   this.setState({
  //     lesson_obj: this.state.lesson_obj.concat([{
  //       les_type: "", les_link: "", les_sP: "", les_eP: "", les_title: "", les_sub: "", les_remark: ""
  //     }])
  //   });
  // };
  // confirmBoxDelete = (event) => {
  //   event.preventDefault();
  //   confirmAlert({
  //     title: 'stay one moment!',
  //     message: 'Are you sure do you want to delete this.',
  //     buttons: [
  //       {
  //         label: 'Yes',
  //         onClick: () => {
  //           this.handleRemoveSubject(event);
  //         }
  //       },
  //       {
  //         label: 'No',
  //       }
  //     ]
  //   });
  // };


  // handleRemoveSubject = (event) => {
  //   if (this.state.lesson_obj.length > 1) {
  //     this.setState({
  //       lesson_obj: this.state.lesson_obj.filter((s, sidx) => index !== sidx)
  //     })
  //   }
  // };
  // getClassesHandler() {
  //   loadProgressBar();
  //   const school_id = this.state.school_id;
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL + "?id=" + school_id)
  //     .then(res => {
  //       const classes = res.data;
  //       this.setState({
  //         sft_classes: classes,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };


  // getSessionYearHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SESSION_YEAR, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         session_year_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getSelectedClassHandler = (event) => {
  //   const _class_id = event.target.value;
  //   this.setState({ class_id: _class_id });
  // }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.subjects)) {
      this.props.getSubjects();
    }
    if (isEmptyObj(this.props.sessionYears)) {
      this.props.getSessionYears();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_subjects = this.props.subjects;
      if (_all_subjects && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _all_classes = this.props.classes;
    //const _fltr_class = this.props.filteredClassesData;
    if (!isEmptyObj(_all_classes)) {
      const _school_classes = _all_classes.filter((item) => {
        if (item.school_id === _fltr_school.slct_school_id) {
          return item
        }
      })
      this.setState({
        selected_classes: _school_classes
      })
    }

    this.filterByClsHandler()
  }

  filterByClsHandler = () => {
    this.getCurrentLessonHandler();
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getSchoolHandler();
  //           // this.getExamTypeHandler();
  //           // this.getSubjectsHandler();
  //           // this.getClassesHandler();
  //           // this.getSessionYearHandler();
  //           this.getCurrentLessonHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }


  getCurrentLessonHandler() {
    const { match } = this.props;
    const lesson_id = match.params.id;
    const _fltr_class = this.props.filteredClassesData;
    const _all_lesson = this.props.monthlyLesson.lesson_info;
    if (!isEmptyObj(_all_lesson)) {
      const _current_lesson = _all_lesson.filter((item) => {
        if (item.id === lesson_id) {
          return item;
        }
      })
      console.log(_current_lesson);
      this.setState({
        lesson_data: _current_lesson[0]
      },
        () => this.getSubjectsOfClass(_fltr_class.slct_cls_id)
      )
    }
    // axios.get(READ_LESSON + "?id=" + lesson_id)
    //   .then(res => {
    //     const getRes = res.data;
    //     if (getRes.responseData) {
    //       this.setState({
    //         lesson_data: getRes.responseData,
    //       }, () => {
    //         this.filterSchoolById();
    //       });
    //     } else {
    //       Alert.error(getRes.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000,
    //       });
    //     }
    //     ////console.log(this.state.classes);
    //   }).catch((error) => {
    //     // error
    //   })
  }
  // getCurrentClassSubjectHandler() {
  //   const _fltr_class = this.props.filteredClassesData;
  //   const _fltr_school = this.props.filteredSchoolData;
  //   const _all_subjects = this.props.subjects;
  //   // debugger
  //   const _class_subjects = _all_subjects.filter((item) => {
  //     if (item.school_id === _fltr_school.slct_school_id && item.class_id === _fltr_class.slct_cls_id) {
  //       return item
  //     }
  //   })
  //   this.setState({
  //     subjects_of_class: _class_subjects
  //   });
  // }
  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getExamTypeHandler() {
  //   loadProgressBar();
  //   axios.get(READ_EXAM_CATE)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         exam_cat_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getSubjectsHandler() {
  //   loadProgressBar();
  //   axios.get(READ_SUBJECTS)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.message !== undefined) {
  //         Alert.error(resData.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000,
  //         });
  //       } else {
  //         this.setState({
  //           subjects: resData
  //         });
  //         //console.log(this.state.subjects);
  //       }
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       if (this.state.user_category === "1") {
  //         this.setState({
  //           sft_classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       } else {
  //         this.setState({
  //           sft_classes: classes,
  //           selected_classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       }
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  // getConvertedDay(str) {
  //   var currnt_date = new Date(str);
  //   // let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  //   var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  //   return months[currnt_date.getMonth()];
  //   // return days[currnt_date.getDay()].toUpperCase();
  // }

  submitHandler = () => {
    loadProgressBar();

    const { lesson_data } = this.state;
    const date_obj = new Date(lesson_data.les_date);
    const real_month = date_obj.getMonth() + 1;
    const update_data = { "lesson_arr": { ...lesson_data, les_month: real_month } };
    // console.log(update_data);

    console.log(JSON.stringify(update_data));
    this.props.updateLesson(update_data);

    // debugger
    // axios.post(UPDATE_LESSON, update_data)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  };

  convertDateObject(dateObj) {
    const datelesDate = new Date(dateObj);
    return datelesDate;
  }

  render() {
    const { lesson_data, selected_school_index, schools_arr, selected_classes,
      lesson_type_arr, subjects_of_class, user_category,
      formIsHalfFilledOut } = this.state;
    const { sessionYears, filteredSchoolData } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Lesson</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Edit Lesson</div>
        </div>
        <form className="card card-box mt-4 sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
          {lesson_data &&
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="container">
                  <div className="row">
                    <div className="col-sm-4">
                      <div className="mb-3">
                        <ReactYoutubePlayer
                          videoId={lesson_data.les_link}
                          videoClass={"vp-LargeThumb"} />
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4">Lesson Type : </label>
                        <div className="col-sm-8">
                          <select className="form-control form-control-sm"
                            required
                            name="les_type_id"
                            value={lesson_data.les_type_id}
                            onChange={event => this.changeHandler(event, "les_type_id")}>
                            <option value="">Select Type...</option>
                            {lesson_type_arr.map((item, index) => {
                              return (
                                <option key={index} value={item.id}>{item.les_type}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4">Lesson Id : </label>
                        <div className="col-sm-8">
                          <input
                            type="text"
                            required
                            // placeholder="Video ID"
                            className="form-control form-control-sm"
                            autoComplete="off"
                            name="les_link"
                            defaultValue={lesson_data.les_link}
                            onChange={event => this.changeHandler(event, "les_link")} />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4">Start/ End Point : </label>
                        <div className="col-sm-8">
                          <div className="row">
                            <div className="col-6">
                              <input
                                type="text"
                                placeholder="Start Point"
                                className="form-control form-control-sm"
                                autoComplete="off"
                                disabled={true}
                                name="les_sP"
                                defaultValue={lesson_data.les_sP}
                                onChange={event => this.changeHandler(event, "les_sP")} />
                            </div>
                            <div className="col-6">
                              <input
                                type="text"
                                placeholder="End Point"
                                className="form-control form-control-sm"
                                autoComplete="off"
                                disabled={true}
                                name="les_eP"
                                defaultValue={lesson_data.les_eP}
                                onChange={event => this.changeHandler(event, "les_eP")} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-7 ml-auto">
                      <div className="form-group pt-2 row">
                        <label className="control-label col-sm-4 text-right"></label>
                        <div className="col-sm-8">
                          <div className="custom-control custom-checkbox">
                            <input type="checkbox"
                              id="is_active" className="custom-control-input"
                              checked={(lesson_data.is_active === "1" ? true : false)}
                              onChange={event => this.changeHandler(event, 'is_active', true)} />
                            <label className="custom-control-label" htmlFor="is_active">Active</label>
                          </div>
                        </div>
                      </div>
                      {user_category === "1" ?
                        <div className="form-group pt-2 row">
                          <label className="control-label col-sm-4 text-right">Schools :</label>
                          <div className="col-sm-8">
                            <select className="form-control form-control-sm"
                              required
                              ref='school'
                              value={selected_school_index}
                              onChange={event => this.changeHandler(event, 'school')}>
                              <option value="">Select ...</option>
                              {schools_arr.map((item, index) => {
                                return (
                                  <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                )
                              })}
                            </select>
                          </div>
                        </div>
                        : null}
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Medium :</label>
                        <div className="col-sm-8">

                          <select className="form-control form-control-sm"
                            required
                            ref='medium'
                            disabled={filteredSchoolData.school_mediums.length > 1 ? false : true}
                            value={lesson_data.medium}
                            onChange={event => this.changeHandler(event, 'medium')}>
                            <option value="">Select ...</option>
                            {filteredSchoolData.school_mediums.map((item, index) => {
                              return (
                                <option key={index} value={item}>{item}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Class :</label>
                        <div className="col-sm-8">
                          <select className="form-control form-control-sm" name="stu_class"
                            value={lesson_data.class_id}
                            onChange={event => this.changeHandler(event, 'stu_class')}>
                            <option value="">Select...</option>
                            {selected_classes.map((option, index) => {
                              return (
                                <option key={index}
                                  value={option.id}>
                                  {option.class_name} [{option.class_name_portal}]
                                </option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Session Year : </label>
                        <div className="col-sm-8">
                          <select className="form-control form-control-sm"
                            required
                            ref='session_year_id'
                            value={lesson_data.session_year_id}
                            onChange={event => this.changeHandler(event, 'session_year_id')}>
                            <option value="">Select ...</option>
                            {sessionYears.map((item, index) => {
                              return (
                                <option key={index} value={item.id}>{item.ses_year}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Lesson Date : </label>
                        <div className="col-sm-8">
                          <div className="datePicker">
                            <DatePicker
                              onChange={this.lessonDateHandlar}
                              // value={lesson_data.les_date}
                              value={this.convertDateObject(lesson_data.les_date)}
                              showLeadingZeroes={true}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Lesson Subject : </label>
                        <div className="col-sm-8">
                          <select className="form-control form-control-sm"
                            required
                            name="les_sub_id"
                            value={lesson_data.les_sub_id}
                            onChange={event => this.changeHandler(event, "les_sub_id")}>
                            <option value="">Select Subject ...</option>
                            {subjects_of_class.map((item, index) => {
                              return (
                                <option key={index} value={item.id}>{item.sub_name}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Lesson Title : </label>
                        <div className="col-sm-8">
                          <input
                            type="text"
                            required
                            placeholder="Lesson Title"
                            className="form-control form-control-sm"
                            autoComplete="off"
                            name="les_title"
                            defaultValue={lesson_data.les_title}
                            onChange={event => this.changeHandler(event, "les_title")} />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-sm-4 text-right">Lesson Remark : </label>
                        <div className="col-sm-8">
                          <input
                            type="text"
                            placeholder="Remark"
                            className="form-control form-control-sm"
                            autoComplete="off"
                            name="les_remark"
                            defaultValue={lesson_data.les_remark}
                            onChange={event => this.changeHandler(event, "les_remark")} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          }
          <div className="card-footer d-flex">
            <NavLink to="/all_lesson.jsp" className="btn btn-danger btn-sm">All Lesson</NavLink>
            <button type="submit" className="btn btn-primary btn-sm ml-auto mr-2">Update</button>
          </div>
        </form >
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: subjects } = state.subjects;
  const { item: sessionYears } = state.sessionYears;
  const { item: monthlyLesson } = state.monthlyLesson;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, subjects, classes, sessionYears, monthlyLesson,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getSubjects: subjectsAction.getSubjects,
  getSessionYears: sessionYearsAction.getSessionYears,
  updateLesson: monthlyLessonAction.update
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddLesson));