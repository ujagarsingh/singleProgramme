import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { frontSliderActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';
// import { events } from '../_reducers/events.reducer';

import AddSlider from './add_slider';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_SLIDERS = `http://schools.rajpsp.com/api/front_slider/read.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/front_slider/delete.php`;

class AllSlider extends Component {
  state = {
    slider_arr: [],
    formIsHalfFilledOut: false,
    createItem: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };

  componentDidMount() {
    if (isEmptyObj(this.props.frontSlider)) {
      this.props.getFrontSlider();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSliderHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSliderHandler() {
  //   loadProgressBar();
  //   axios.get(GET_SLIDERS)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         slider_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.slider_ar);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteHandlar({ id: del_id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   axios.post(DELETE_URL + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _slider_arr = this.state.slider_arr.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         slider_arr: _slider_arr
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      createItem: !this.state.createItem
    })
  }
  render() {
    const { formIsHalfFilledOut, createItem } = this.state;
    const { user, frontSlider } = this.props;
    //console.log(slider_arr)
    return (
      <div className="page-content">
        <Helmet>
          <title>All Slider</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {/* <div className="page-bar d-flex">
          <div className="page-title">All Sliders</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mt-1">
                <NavLink to="/add_slider.jsp" className="btn btn-primary btn-sm ml-auto">
                  Add New <i className="fa fa-plus" />
                </NavLink>
              </div>
            </div>
          </div>
        </div> */}
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {createItem ? <AddSlider
              toggeleCreate={this.toggeleCreate} />
              : null}
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Images </th>
                    <th> Main Title</th>
                    <th> Sub Title </th>
                    <th> Action </th>
                  </tr>
                </thead>
                {frontSlider &&
                  <tbody>
                    {frontSlider.map((item, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}</td>
                          <td className="rectangle-pic">
                            {item.main_image !== '' ?
                              < img src={`${process.env.PUBLIC_URL}` + item.main_image} alt={item.title_1a} />
                              : <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/slider.jpg`} />
                            }
                          </td>
                          <td><b>{item.title_1a}</b> <br />{item.title_1b}</td>
                          <td>{item.sub_title}</td>
                          <td className="d-flex">
                            <NavLink to={`/edit_slider.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit
                          </NavLink>
                            <button className="btn btn-danger btn-sm"
                              value={item.id}
                              onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                }
              </table>
            </div>
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">Add New
            </button>
            }
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontSlider } = state.frontSlider;
  return { user, frontSlider };
}

const actionCreators = {
  getFrontSlider: frontSliderActions.getFrontSlider,
  deleteHandlar: frontSliderActions.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllSlider));