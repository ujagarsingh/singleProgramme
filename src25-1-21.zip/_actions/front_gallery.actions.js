import { frontGalleryConstants } from '../_constants';
import { frontGalleryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const frontGalleryActions = {
    getFrontGallery,
    createFrontGallery,
    update,
    delete : _delete
};

function getFrontGallery() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontGalleryService.getFrontGallery()
            .then(
                response => {
                    dispatch(success(response.data.gallery_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontGalleryConstants.GALLERY_REQUEST } }
    function success(response) { return { type: frontGalleryConstants.GALLERY_SUCCESS, response } }
    function failure(error) { return { type: frontGalleryConstants.GALLERY_FAILURE, error } }
}
 

function createFrontGallery(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontGalleryService.createFrontGallery(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontGalleryConstants.CREATE_GALLERY_REQUEST } }
    function success(response) { return { type: frontGalleryConstants.CREATE_GALLERY_SUCCESS, response } }
    function failure(error) { return { type: frontGalleryConstants.CREATE_GALLERY_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontGalleryService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontGalleryConstants.UPDATE_GALLERY_REQUEST } }
    function success(response) { return { type: frontGalleryConstants.UPDATE_GALLERY_SUCCESS, response } }
    function failure(error) { return { type: frontGalleryConstants.UPDATE_GALLERY_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontGalleryService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontGalleryConstants.DELETE_GALLERY_REQUEST } }
    function success(response) { return { type: frontGalleryConstants.DELETE_GALLERY_SUCCESS, response } }
    function failure(error) { return { type: frontGalleryConstants.DELETE_GALLERY_FAILURE, error } }
}
