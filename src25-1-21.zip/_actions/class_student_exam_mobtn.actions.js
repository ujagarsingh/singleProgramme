import { classStudentExamMObtnConstants } from '../_constants';
import { classStudentExamMobtnService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classStudentExamMobtnAction = {
    getClassStudentExamMobtn,
};

function getClassStudentExamMobtn() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classStudentExamMobtnService.getClassStudentExamMobtn()
            .then(
                response => {
                    dispatch(success(response.data.class_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_REQUEST } }
    function success(response) { return { type: classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_SUCCESS, response } }
    function failure(error) { return { type: classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_FAILURE, error } }
}
 
