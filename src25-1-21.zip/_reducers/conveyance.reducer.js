import { conveyanceConstants } from '../_constants';

export function conveyance(state = {}, action) {
  switch (action.type) {
    case conveyanceConstants.CONVEYANCE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case conveyanceConstants.CONVEYANCE_SUCCESS:
      return {
        item: action.response
      };
    case conveyanceConstants.CONVEYANCE_FAILURE:
      return {
        error: action.error
      };





    case conveyanceConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true, 
      };
    case conveyanceConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case conveyanceConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    case conveyanceConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case conveyanceConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      
      return {
        item: updated_arr,
        loading: false,
      };
    case conveyanceConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };





    case conveyanceConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case conveyanceConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case conveyanceConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    default:
      return state
  }
}