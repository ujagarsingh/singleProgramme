import { examsTypeConstants } from '../_constants';

export function examsType(state = {}, action) {
  switch (action.type) {
    case examsTypeConstants.EXAMS_TYPE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examsTypeConstants.EXAMS_TYPE_SUCCESS:
      return {
        item: action.response
      };
    case examsTypeConstants.EXAMS_TYPE_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}