import { frontArticleConstants } from '../_constants';

export function frontArticle(state = {}, action) {
  switch (action.type) {
    case frontArticleConstants.ARTICLE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case frontArticleConstants.ARTICLE_SUCCESS:
      return {
        item: action.response
      };
    case frontArticleConstants.ARTICLE_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}