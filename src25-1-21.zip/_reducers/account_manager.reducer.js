import { accountManagerConstants } from '../_constants';

export function accountManager(state = {}, action) {
  switch (action.type) {
    case accountManagerConstants.READ_ACCOUNT_MANAGER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accountManagerConstants.READ_ACCOUNT_MANAGER_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accountManagerConstants.READ_ACCOUNT_MANAGER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}