// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const paymentService = {
    getPayment
};

function getPayment() {
    loadProgressBar();
    const url = USER_URL + 'payment/read.php';
    return Axios.post(url, authHeader()).then()
}
