import React from "react";
class TodoItem extends React.Component {
    constructor() {
        super();
        this.state = {
            isEditing: false
        }
    };
    toggleIsEditing = () => {
        this.setState({
            isEditing: !this.state.isEditing,
        })
    };
    deleteItemFromState = () => {
        this.props.deleteTodo(this.props.index, this.props.todo.id)
    };
    renderItem = () => {
        const { todo } = this.props;
        return (
            <section className="d-flex  w-100">
                <p className="d-flex">{todo.text}</p>
                <button onClick={this.toggleIsEditing} className="btn btn-outline-primary ml-auto">Edit</button>
                <button onClick={this.deleteItemFromState} className="btn btn-outline-danger ml-2">Delete</button>
            </section>
        )
    };
    editItemToState = (ev) => {
        const { todo } = this.props;
        ev.preventDefault();
        this.props.editTodo({
            todo: { ...todo, text: this.refs.edittodo.value },
            index: this.props.index
        })
        this.refs.edittodo.value = ""
        this.toggleIsEditing();
    };
    renderForm = () => {
        const { todo } = this.props;
        return (
            <form className="form-group  w-100 m-0" onSubmit={this.editItemToState}>
                <div className="input-group">
                    <input className="form-control" type="text" defaultValue={todo.text} ref="edittodo" />
                    <div className="input-group-append">
                        <button className="btn btn-primary" type="submit">Edit Todo</button>
                    </div>
                </div>
            </form>
        )
    };

    render() {
        //const {todo, deleteTodo} = this.props;
        //console.log(todo);
        //debugger;
        return (
            <li className="list-group-item d-flex">
                {
                    this.state.isEditing ? this.renderForm() : this.renderItem()
                }
            </li>
        )
    }
}

export default TodoItem;