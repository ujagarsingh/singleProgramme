import React from "react";
class AddTodo extends React.Component {
  addItemToState = (ev) => {
    ev.preventDefault();
    this.props.addTodo({
      text: this.refs.addtodo.value
    })
    this.refs.addtodo.value = ""
  }
  render() {
    return (
      <form className="form-group p-3 bg-light" onSubmit={this.addItemToState}>
        <div className="input-group">
          <input className="form-control" type="text" ref="addtodo" />
          <div className="input-group-append">
            <button className="btn btn-default" type="submit">Add Todo</button>
          </div>
        </div>
      </form>
    )
  }
}
export default AddTodo;