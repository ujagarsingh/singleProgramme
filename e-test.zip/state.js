state = {
    tst_info : // create new test  [section 1]
        {
            id : "",
            tst_exam_id : "",
            start_date : "",
            start_time : "",
            end_date : "",
            end_time : "",
            active_link_date : "",
            active_link_time : "",
            time_control : yes,
            school_id : "",
            title : "",
            subject : "",
            total_marks : "",
            negetive_marking : yes,
            total_time : "",
        },
    quiz: // quiz List
    [ 
        {
        id: 1,
        detail: {
                question: "Which one is correct team name in NBA?",
                options: [
                    { id: 1, opt: "New York Bulls" },
                    { id: 2, opt: "Los Angeles Kings" },
                    { id: 3, opt: "Golden State Warriros" },
                    { id: 4, opt: "Huston Rocket" }
                ],
                right_answer: [4],
                max_marks : "",
                nagetive_marks : ""
            }
        },
        {
        id: 2,
        detail: {
            question: "5 + 7 = ?",
            options: [
                { id: 1, opt: "10" },
                { id: 2, opt: "11" },
                { id: 3, opt: "12" },
                { id: 4, opt: "13" }
                ],
                right_answer: [3],
                max_marks : "",
                nagetive_marks : ""
            }
        },
        {
        id: 3,
        detail: {
            question: "12 - 8 = ?",
            options: [
            { id: 1, opt: "1" },
            { id: 2, opt: "2" },
            { id: 3, opt: "3" },
            { id: 4, opt: "4" },
            { id: 5, opt: "20" }
            ],
            right_answer: [4],
            max_marks : "",
            nagetive_marks : ""
        }
        },
        {
        id: 4,
        detail: {
            question: "What is the capital of Maharashtra?",
            options: [
                { "id": 1, "opt": "Mumbai" },
                { "id": 2, "opt": "Nagpur" },
                { "id": 3, "opt": "Pune" },
                { "id": 4, "opt": "Amaravati" }
            ],
            right_answer: [1, 3],
            max_marks : "",
            nagetive_marks : ""
        }
    }
  ],
    last_max_marks: "",
    last_negative_marks: "",
    active_part: "tst_info"
}