state = {
    tst_repo_summary : { // accourding to user_id  [section 1, 2, 4, 5, 6, 7]
        user_id : "",
        tst_info_id : "",
        tst_title : "",
        subject : "",
        score : "", 
        correct_ans: "", 
        used_time: "", 
        attempt_ans: "", 
        accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
    },
    tst_repo_top :  // accourding to test_id top 10 (maximum scored) [section 3, 5]
    [
        {
            user_id : "", test_info_id : "", test_title : "", subject : "",
            score : "", correct_ans: "", used_time: "", attempt_ans: "", 
            accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
        },
        {
            user_id : "", test_info_id : "", test_title : "", subject : "",
            score : "", correct_ans: "", used_time: "", attempt_ans: "", 
            accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
        },
        {
            user_id : "", test_info_id : "", test_title : "", subject : "",
            score : "", correct_ans: "", used_time: "", attempt_ans: "", 
            accuracy_per: "", correct_per: "", incorrect_per: "", percintileper: ""
        }
    ]


}