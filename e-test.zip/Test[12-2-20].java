package com.welcome.spring.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Test {

	public static void main(String[] args) throws IOException {
	
//      Document doc = Jsoup.connect("http://www.ujagarsingh.com").get();  
//      String title = doc.title();  
//      System.out.println("title is (from URL) : " + title);

//      Document doc_1 = Jsoup.parse(new File("D:\\repository\\genmaster\\src\\master\\address\\address\\address.component.html"),"utf-8");  
//      String title_1 = doc_1.title();  
//      System.out.println("title is (from Page) : " + title_1);
		
		/*Document doc = Jsoup.parse(new File("E:\\ujagar\\aflatoon.html"),"utf-8");
      Elements links = doc.select("a[href]");  
      for (Element link : links) {  
          System.out.println("\nlink : " + link.attr("href"));  
          System.out.println("text : " + link.text());  
      }  
      */
		
		/*Document doc = Jsoup.parse(new File("E:\\ujagar\\aflatoon.html"),"utf-8");
      Elements links = doc.select("a[href]");  
      for (Element link : links) {  
          // System.out.println("\nlink : " + link.attr("href"));  
      	link.attr("title", "jsoup").addClass("round-box");
      	System.out.println("text : " + link.text());
          
      }*/  
		
		// List of files 
		
		/*try (Stream<Path> walk = Files.walk(Paths.get("E:\\ujagar"))) {

			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());

			result.forEach(System.out::println);

		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		/*
		// List of folders
		try (Stream<Path> walk = Files.walk(Paths.get("E:\\ujagar"))) {

			List<String> result = walk.filter(Files::isDirectory)
					.map(x -> x.toString()).collect(Collectors.toList());

			result.forEach(System.out::println);

		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		
		// List of files with extentions
		/*
		try (Stream<Path> walk = Files.walk(Paths.get("C:\\projects"))) {

			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.endsWith(".java")).collect(Collectors.toList());

			result.forEach(System.out::println);

		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		
		// Find a file.
		/*
		try (Stream<Path> walk = Files.walk(Paths.get("C:\\projects"))) {

			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.contains("HeaderAnalyzer.java"))
					.collect(Collectors.toList());

			result.forEach(System.out::println);

		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
			
		File folder = new File("E:\\ujagar\\write-json");
		
		getFilesAndFolders(folder);
	}
	
	// Manipulate files with id, tooltip, translate='key' and 
	// create new json file for tooltip and traslate 
	
	public static void generateJsonAndReWriteFiles(String sorceFile) {
		BufferedWriter  writer = null;
	      try
	      {
	          Document document = Jsoup.parse(new File(sorceFile), "utf-8");
	          
	          Elements links = document.select("a[href]");  
	          //links.attr("rel", "nofollow");
	          requiredAction(links); 
	          
	          Elements options = document.select("option");  
	          options.attr("value", "");
	          
	          File f = new File(sorceFile);
	          
	          String folderPath = f.getParent(); 
	          String targetPath = "";
	          //String fileName = f.getName();
	          targetPath = folderPath.replace("E:\\ujagar\\write-json\\code", "");
	          String alternative = targetPath.replace('\\', '/');
	          
	          directoryAssurance("E:/ujagar/write-json/assets"+ alternative);
	          
	          String finalFilePath = "E:/ujagar/write-json/assets"+ alternative + "/tooltip.json";
	          System.out.println(finalFilePath);

	          writer = new BufferedWriter( new FileWriter(finalFilePath));
	          writer.write(document.html());
	          writer.close();
	            
	       //   writer.write(document.toString());
	      } 
	      catch (IOException e) 
	      {
	          e.printStackTrace();
	      }
	};
	
	// get all folder's and file's name including subfolder's
	public static void getFilesAndFolders(File directoryName) {
		
		File[] listOfFiles = directoryName.listFiles();
		
		// System.out.println("list of files " + Arrays.toString(listOfFiles));
		
		if(listOfFiles != null) {
		for (int i = 0; i < listOfFiles.length; i++) {
		  String path = listOfFiles[i].getAbsolutePath();
		  
		  if (listOfFiles[i].isFile()) {
			String fileExt = listOfFiles[i].getName();
			if(fileExt.endsWith(".html")) {
				System.out.println("File " + listOfFiles[i].getName());
				//System.out.println(path);
				
				generateJsonAndReWriteFiles(path);
			}
		  } else if (listOfFiles[i].isDirectory()) {
			 System.out.println("Directory " + listOfFiles[i].getName());
		     
			 // String path = listOfFiles[i].getAbsolutePath();
		     File folder = new File(path);
		     
		     getFilesAndFolders(folder);
		  }
		}
	    
	 }
	}

	
	/** Creates or Check Drectory Structure  */
	private static void directoryAssurance(String directory) {
		//String path = createImages.getAbsolutePath() + "/Images";
		File f = new File(directory);
		if (!f.isDirectory()) {
		  boolean success = f.mkdirs();
		  if (success) {
		    System.out.println("Created path: " + f.getPath());
		  } else {
		    System.out.println("Could not create path: " + f.getPath());
		  }
		} else {
		  System.out.println("Path exists: " + f.getPath());
		}
	}
	
	
	// create required action
	public static void requiredAction(Elements item) {
		// item = "<button>save</button";
		System.out.println("elem: "+ item);
		item.attr("rel", "nofollow");
		item.attr("id", "aflaottn");
		
		System.out.println("Id+++++++++++++ " + item.attr("id"));
		System.out.println("tagName++++++++ " + item.attr("class"));
		System.out.println("hasClass+++++++ " + item.hasClass("hellow"));
		System.out.println("text+++++++++++ " + item.text());
		
	}

	

}
