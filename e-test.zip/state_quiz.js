state = {
 current_id : 1,
 current_ques_time : 100000, // in milisecond
 test_time : 500000, // in milisecond
 test_title : "",
 test_id : "",
 timer_pause : false, 
 total_marks_obtain : "", 
 total_negative_marks : "", 
  markeDType: [
    { mrk_id: 1, mrk_type: "Answered", counter : 0 },
    { mrk_id: 2, mrk_type: "Not Answered", counter : 4 },
    { mrk_id: 1, mrk_type: "Review Later", counter : 0 },
    { mrk_id: 3, mrk_type: "Not Visited", counter : 0 },
    { mrk_id: 4, mrk_type: "Answred and Revie Later", counter : 0 }
  ],
  quiz: [
    {
      id: 1,
      detail: {
        question: "Which one is correct team name in NBA?",
        options: [
          { id: 1, opt: "New York Bulls" },
          { id: 2, opt: "Los Angeles Kings" },
          { id: 3, opt: "Golden State Warriros" },
          { id: 4, opt: "Huston Rocket" }
        ],
        answer: "2",
        markAS: "3"
      }
    },
    {
      id: 2,
      detail: {
        question: "5 + 7 = ?",
        options: [
          { id: 1, opt: "10" },
          { id: 2, opt: "11" },
          { id: 3, opt: "12" },
          { id: 4, opt: "13" }
        ],
        answer: "2",
        markAS: "3"
      }
    },
    {
      id: 3,
      detail: {
        question: "12 - 8 = ?",
        options: [
          { id: 1, opt: "1" },
          { id: 2, opt: "2" },
          { id: 3, opt: "3" },
          { id: 4, opt: "4" },
          { id: 5, opt: "20" }
        ],
        answer: "2",
        markAS: ""
      }
    },
    {
      id: 4,
      detail: {
        question: "What is the capital of Maharashtra?",
        options: [
          { "id": 1, "opt": "Mumbai" },
          { "id": 2, "opt": "Nagpur" },
          { "id": 3, "opt": "Pune" },
          { "id": 4, "opt": "Amaravati" }
        ],
        answer: "2",
        markAS: ""
      }
    }
  ]

}