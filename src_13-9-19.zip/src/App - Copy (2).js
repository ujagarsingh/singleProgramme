import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";
import Register from "./Register";
function App() {
  return (
    <div className="App">
      <h3>Basic Registration</h3>
      <Register />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
