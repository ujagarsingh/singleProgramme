import React, { Component } from 'react';
import Sidebar from './Sidebar';
import ExcelReader from './ExcelReader';
import SelectBox from './SelectBox';
class AboutMe extends Component {
  state = {
    selectnumber: '',
    dataObj: []
  }
  onClickHandler = (event) => {
    console.log(event.target.value);
  }
  objHandler = (obj) => {
    console.log('This is parent data', obj)
  }
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-4">
            <Sidebar />
          </div>
          <div className="col-sm-8">
            <h2 >About Me</h2>
            {/*<SelectBox onClick={this.onClickHandler}  />*/}
            <ExcelReader objHandler={this.objHandler} />
          </div>
        </div>

      </div>
    );
  }
}

export default AboutMe;