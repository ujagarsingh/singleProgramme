import React, { Component } from 'react';
import { NavLink } from "react-router-dom";
import Sidebar from './Sidebar';
class AllProducts extends Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-4">
            <Sidebar />
          </div>
          <div className="col-sm-8">
            <h2 >All Products</h2>
            <NavLink to="/produts/1" className="btn btn-primary">Single Product
  </NavLink>
          </div>
        </div>

      </div>
    );
  }
}

export default AllProducts;