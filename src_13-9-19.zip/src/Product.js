import React, { Component } from 'react';

import Sidebar from './Sidebar';
class Product extends Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-4">
            <Sidebar />
          </div>
          <div className="col-sm-8">
            <h2 >Single Product</h2>
          </div>
        </div>

      </div>
    );
  }
}

export default Product;