import React from "react";

class FormView extends React.Component {
  handleChange = (e) => {
    e.preventDefault();
    this.props.changeValue(
      e.target.name.value,
      e.target.age.value,
      e.target.gender.value
    );
  }

  render() {
    return (
      <form onSubmit={this.handleChange}>
        <label>
          Name:<br />
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Age:<br />
          <input type="number" name="age" />
        </label>
        <br />
        <label>
          Gender:<br />
          <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </label>
        <br />
        <input type="submit" value="Submit" className="btn btn-primary" />
      </form>
    );
  }
}

export default FormView;
