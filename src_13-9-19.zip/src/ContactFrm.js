import React, { Component } from 'react';
import FormView from "./FormView";
import DisplayView from "./DisplayView";
import Sidebar from './Sidebar';

class ContactFrm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      age: "",
      gender: ""
    };
  }

  changeValue = (name, age, gender) => {
    this.setState(
      {
        name: name,
        age: age,
        gender: gender
      },
      () => console.log(this.state)
    );
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-4">
            <Sidebar />
          </div>
          <div className="col-sm-8">
            <h2 >Contact Me</h2>
            <FormView changeValue={this.changeValue} />
            <DisplayView
              name={this.state.name}
              age={this.state.age}
              gender={this.state.gender}
            />
          </div>
        </div>

      </div>
    );
  }
}


export default ContactFrm;