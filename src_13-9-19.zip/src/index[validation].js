import React from "react";
import ReactDOM from "react-dom";
const intialState = {
  name: "",
  email: "",
  nameErr: "",
  emailErr: ""
};
class App extends React.Component {
  state = intialState;

  validate = e => {
    let nameErr = "";
    let emailErr = "";
	
    if (!this.state.name) {
		
      nameErr = "name is not blank.";
    }

    if (!this.state.email) {
      emailErr = "email is not blank.";
    } else if (!this.state.email.includes("@")) {
      emailErr = "please include '@'";
    }

    if(nameErr || emailErr) {
      this.setState({ nameErr, emailErr },()=>{console.log(0)});
	  return false;
    }
    this.setState({ nameErr, emailErr },()=>{console.log(1)});
    return true;
  };

  handlerName = e => {
    this.setState({ name: e.target.value });
  };
  handlerEmail = e => {
    this.setState({ email: e.target.value });
  };

  handlerSubmit = e => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
		setTimeout(() => {
      console.log(this.state);
	  alert(JSON.stringify(this.state));
	  this.setState(intialState);

		}, 1000);
    }
  };

  render() {
    return (
      <form onSubmit={this.handlerSubmit}>
        <div>
          <h3>Registration form</h3>
          <div>
            <label>Name</label>
            <br />
            <input
              type="text"
              value={this.state.name}
              onChange={this.handlerName}
            />
            <div style={{ color: "red" }}>{this.state.nameErr}</div>
          </div>
          <div>
            <label>Email</label>
            <br />
            <input
              type="text"
              value={this.state.email}
              onChange={this.handlerEmail}
            />
            <div style={{ color: "red" }}>{this.state.emailErr}</div>
          </div>
          <br />
          <div>
            <button>Submit</button>
          </div>
        </div>
      </form>
    );
  }
}
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
