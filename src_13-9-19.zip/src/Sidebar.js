import React, { Component } from 'react';
import { NavLink } from "react-router-dom";

class Home extends Component {
  render() {
    return (
      <div className="list-group">
        <NavLink exact to="/" className="list-group-item list-group-item-action">
          Home
  </NavLink>
        <NavLink to="/about-me"
          className="list-group-item list-group-item-action">
          About Me </NavLink>
        <NavLink to="/contact-me"
          className="list-group-item list-group-item-action">
          About Me </NavLink>
        <NavLink to="/produts" className="list-group-item list-group-item-action">Products
  </NavLink>

      </div>

    );
  }
}

export default Home;