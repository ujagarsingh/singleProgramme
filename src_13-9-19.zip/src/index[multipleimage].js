import React from "react";
import ReactDOM from "react-dom";
const intialState = {
  name: "",
  mainImage: [],
  extraImages: []
};
class App extends React.Component {
  constructor(props) {
    super();
    this.state = intialState;
  }

  handlerName = e => {
    this.setState({ name: e.target.value });
  };
  handlerMainImage = e => {
	  const _mainImage = [...this.state.mainImage];
	  const _imgType = e.target.files[0].type;
	  const _ext = _imgType.split('/')[1].toLowerCase();
	  if (_ext === 'jpg' ||  _ext === 'jpeg' ||  _ext === 'png' ||  _ext === 'gif'){
	  _mainImage.push({
			'name' : e.target.files[0].name, 'type' : 'main'
		})
	  }
    this.setState({ mainImage: _mainImage });
  };
  handlerExtraImages = e => {
    const _extraImages = [...this.state.extraImages];
	const _length = e.target.files.length;
	for(var x = 0; x<_length; x++){
		const _imgType = e.target.files[x].type;
		const _ext = _imgType.split('/')[1].toLowerCase();
		if (_ext === 'jpg' ||  _ext === 'jpeg' ||  _ext === 'png' ||  _ext === 'gif'){
		_extraImages.push({
			'name' : e.target.files[x].name, 'type' : 'second'
		})
		}
	}
    this.setState({ extraImages: _extraImages });
  };
  
  
  handlerSubmit = (e) => {
    e.preventDefault();
    
	/*const reader = new FileReader();
        reader.onloadend = function() {
        return  reader.result;
       }*/
	   setTimeout(() => {
		console.log(this.state)
	   },500)
  };

  render() {
    return (
      <form onSubmit={this.handlerSubmit}>
        <div>
          <h3>Registration form</h3>
          <div>
            <label>Name</label>
            <br />
            <input
              type="text"
              value={this.state.name}
              onChange={this.handlerName}
            />
          </div>
          <div>
            <label>Images</label>
            <br />
            <input
              type="file"
              value={this.state.mainImage.name}
              onChange={this.handlerMainImage}
            />
          </div>
          <div>
            <label>Extra Images</label>
            <br />
            <input
              type="file"
			  multiple
              value={this.state.extraImages.name}
              onChange={this.handlerExtraImages}
            />
          </div>
          <br />
          <div>
            <button>Submit</button>
          </div>
        </div>
      </form>
    );
  }
}
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
