import React from "react";
import ReactDOM from "react-dom";

class Checkbox extends React.Component {
  state = {
    name: "",
    hobbies: []
  };
  componentDidMount(){
    console.log(this.props.values)
  }
  
  render() {
	const checkboxLocal = this.props.values;
    return (
      <div>
        <label>
          <input name={checkboxLocal.name} type="checkbox" />
			{checkboxLocal.name}
        </label>
      </div>
    );
  }
}

export default Checkbox;
