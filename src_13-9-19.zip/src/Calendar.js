import React, { Component } from 'react';
import Sidebar from './Sidebar';
import MonthlyEvents from 'react-monthly-events';
import moment from 'moment';
import { fetchEvents } from '../actions/index';
import AddEvent from '../components/AddEvent';

class MyCalendar extends Component {
  state = {
    currentMonth: new Date('2017-01-01'),
    events: [
      {
        id: 'event-1',
        start: '2017-01-03 18:00:00',
        end: '2017-01-03 19:30:00',
        allDay: false,
        event: 'Learn ReactJS'
      },
      {
        id: 'event-2',
        start: '2017-01-04 17:01:00',
        allDay: false,
        event: 'Go home'
      }
    ]
  }
  constructor(props) {
    super(props);

    this.state = { currentMonth: moment() };
}

componentDidMount = () => {
    this.fetchEvents();
}

handlePrev = () => {
    this.setState({ currentMonth: this.state.currentMonth.subtract(1, 'month') }, this.fetchEvents);
};

handleToday = () => {
    this.setState({ currentMonth: moment() }, this.fetchEvents);
};

handleNext = () => {
    this.setState({ currentMonth: this.state.currentMonth.add(1, 'month') }, this.fetchEvents);
};

addEvent = () => {
    this.child.openModal();
};

fetchEvents = () => {
    this.props.fetchEvents(this.state.currentMonth);
};

getCurrentDate = () => {
    return this.state.currentMonth.format('MMMM YYYY');
};


  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-4">
            <Sidebar />
          </div>
          <div className="col-sm-8">
            <h2 >Event Calendar</h2>

            <MonthlyEvents
              currentMonth={this.state.currentMonth}
              events={this.state.events}
            />

          </div>
        </div>

      </div>
    );
  }
}

export default MyCalendar;