import React from "react";
import Checkbox from "./checkbox";
class CheckboxGroup extends React.Component {
  state = {
    name: "",
    hobbies: []
  };
  componentDidMount(){
    console.log(this.props)
  };
   render() { 
   const currentProps = this.props;
console.log(currentProps);
   return (
	currentProps.hobbiesArr.map((value,index) => {
	return (
	<Checkbox values={value}/>
	)
	})
	)
   
}

}

export default CheckboxGroup;
