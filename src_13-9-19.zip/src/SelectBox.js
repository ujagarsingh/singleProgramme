import React, { Component } from 'react';
class SelectBox extends Component {
    state = {

    }
    onClickHandler = (event) => {
        console.log(event.target.value);
    }
    componentDidMount(){
        console.log(this.props.onClickHandler);
    }
    render() {
        return (
            <select className="form-control"
                onClick={this.props.onClickHandler} >
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
            </select>
        );
    }
}

export default SelectBox;