import React from "react";
import ReactDOM from "react-dom";

import CheckboxGroup from "./checkboxGroup";
const hobbiesArr = [
      { name: "cooking", isChecked: false },
      { name: "photography", isChecked: false },
      { name: "gardining", isChecked: false }
    ];
class Register extends React.Component {
  state = {
    name: "",
    hobbies: []
  };
  handleName = e => {
    this.setState({ name: e.target.value });
  };
  
  componentDidMount(){
  console.log(this.props)
  }
  handleSubmit = (e) => {
	  e.preventDefault();
	  alert(JSON.stringify(this.state))
  }
  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
          <label>Name</label>
          <br />
          <input
            type="text"
            onChange={this.handleName}
            value={this.state.name}
          />
        </div>
        <br />
        <div>
          <label>Hobbies</label>
          <br />
          <CheckboxGroup hobbiesArr={hobbiesArr} />
        </div>
        <hr />
        <div>
          <button type="submit">Register</button>
        </div>
      </form>
    );
  }
}

export default Register;
