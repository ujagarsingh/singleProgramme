import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Home from './Home';
import AboutMe from './AboutMe';
import Product from './Product';
import ContactFrm from './ContactFrm';
import AllProducts from './AllProducts';
class App extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/about-me" component={AboutMe} />
          <Route path="/contact-me" component={ContactFrm} />
          <Route exact path="/produts" component={AllProducts} />
          <Route path="/produts/:id" component={Product} />
        </Switch>
      </Router>
    );
  }
}

export default App;