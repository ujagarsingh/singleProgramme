import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
//import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

//const GET_CLASSES = `http://localhost/schooloffice/api/classes/read.php`;
//const GET_STUDENTS = `http://localhost/schooloffice/api/students/read_students.php`;
//const GET_CLASS_FEE = `http://localhost/schooloffice/api/fee_amount/read_class_fee.php`;
//const GET_FEE_DEPOSIT = `http://localhost/schooloffice/api/fee_deposit/read.php`;
const GET_FEE_DEPOSIT = `http://localhost/schooloffice/api/fee_deposit/read_all.php`;
//const CREATE_FEE_DEPOSIT = `http://localhost/schooloffice/api/fee_deposit/create.php`;
//const GET_PRE_DEPOSIT_RECORD = `http://localhost/schooloffice/api/fee_deposit/read_pre_deposit_months.php`;
const READ_URL = `http://localhost/schooloffice/api/school/read.php`;

class FeesCollection extends Component {
  state = {
    final_deposit_fee_arr: [],
    selected_deposit_fee_arr: [],
    display_student_arr: [],
    id: "",
    sch_name: "",
    sch_reg_no: "",
    sch_recog_no: "",
    sch_contact_num: "",
    sch_mobile_num: "",
    sch_email: "",
    sch_address: "",
    sch_medium: "",
    sch_logo: "",
    sch_wel_mes_title: "",
    sch_wel_mes: '',
    errorMessages: '',
    successMessages: '',
    fee_type: ['all', 'monthly', 'convence', 'sports_fee', 'reg_fee', 'exam_fee'],
    time: ['today', 'monthly', 'yearly'],
    select_time: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    formIsHalfFilledOut: false,
    medium: '',
    fee_status: 'none',
    fee_time: 'none',
    fee_month: 'none',
    selected_fee_month: '',
    fee_type: 'none',
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
    } else if (fieldName === 'fee_status') {
      const _status = event.target.value;
      sessionStorage.setItem("fee_status", _status);
      this.setState({
        fee_status: _status
      }, () => { this.filterHandler() })
    } else if (fieldName === 'fee_time') {
      const _time = event.target.value;
      sessionStorage.setItem("fee_time", _time);
      if (_time === 'Selected Month') {
        this.setState({
          fee_time: _time
        })
      } else {
        this.setState({
          fee_time: _time
        }, () => { this.filterHandler() })
      }
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    }
  };
  mediumHandler(_medium) {
    let _fee_array = this.state.final_deposit_fee_arr;
    if (!this.isEmpty(_fee_array)) {
      const _students = _fee_array.filter((item, inx) => {
        if (item.medium === _medium) {
          return item
        }
      })
      this.setState({
        selected_deposit_fee_arr: _students,
        display_student_arr: JSON.parse(JSON.stringify(_students)),
        medium: _medium
      })
    }
  }
  statusFilter(_fee_array, _fee_status) {
    let _filtered_array = [];
    _fee_array.filter((item, inx) => {
      if (_fee_status === 'none') {
        _filtered_array.push(item);
      } else if (item.abc.length > 0) {
        if (_fee_status === 'Deposited') {
          _filtered_array.push(item)
        } else if (_fee_status === 'Verified') {
          const _vitem = item.abc.filter((vItem) => {
            if (vItem.verify == '1') {
              return vItem
            }
          })
          const newItem = { ...item }
          newItem['abc'] = _vitem;
          _filtered_array.push(newItem)
        } else if (_fee_status === 'Unverified') {
          const _nitem = item.abc.filter((nItem) => {
            if (nItem.verify == '0') {
              return nItem
            }
          })
          const newItem = { ...item }
          newItem['abc'] = _nitem;
          _filtered_array.push(newItem)
        }
      }
    })
    return _filtered_array;
  }
  timeFilter(_fee_array, _fee_status) {
    let _filtered_array = [];

    let today = new Date();
    let dd = String(today.getDate()).padStart(2, '0');
    let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    let yyyy = today.getFullYear();

    let _today = yyyy + '-' + mm + '-' + dd;

    _fee_array.filter((item, inx) => {
      if (_fee_status === 'none') {
        _filtered_array.push(item);
      } else if (item.abc.length > 0) {
        if (_fee_status === 'Today') {
          const _vitem = item.abc.filter((vItem) => {
            // deposit_date: "2019-11-27"
            if (vItem.deposit_date === _today) {
              return vItem
            }
          })
          const newItem = { ...item }
          newItem['abc'] = _vitem;
          _filtered_array.push(newItem)
        } else if (_fee_status === 'Current Month') {
          const _vitem = item.abc.filter((vItem) => {
            const _cmonth = vItem.deposit_date.split('-')[1];
            if (_cmonth == mm) {
              return vItem
            }
          })
          const newItem = { ...item }
          newItem['abc'] = _vitem;
          _filtered_array.push(newItem)
        } else if (_fee_status === 'Last Month') {
          const _nitem = item.abc.filter((vItem) => {
            const _cmonth = vItem.deposit_date.split('-')[1] - 1;
            if (_cmonth == mm-1) {
              return vItem
            }
          })
          const newItem = { ...item }
          newItem['abc'] = _nitem;
          _filtered_array.push(newItem)
        }
      }
    })
    return _filtered_array;
  }
  filterHandler() {
    let _fee_status = this.state.fee_status;
    let _fee_time = this.state.fee_time;
    let _fee_month = this.state.fee_month;
    let _fee_type = this.state.fee_type;
    let _fee_array = this.state.selected_deposit_fee_arr;
    let _status_array = [];
    let _time_array = [];
    console.log(_fee_array);

    _status_array = this.statusFilter(_fee_array, _fee_status);
    _time_array = this.timeFilter(_status_array, _fee_time);

    console.log(JSON.stringify(_time_array));
    this.setState({
      display_student_arr: _time_array
    })
  }
  componentDidMount() {
    loadProgressBar();
    axios.get(GET_FEE_DEPOSIT)
      .then(res => {
        const resData = res.data;
        this.setState({
          final_deposit_fee_arr: resData.record,
          errorMessages: resData.message
        });
        //console.log(this.state.final_deposit_fee_arr);
      }).catch((error) => {
        // error
      })

    axios.get(READ_URL)
      .then(res => {
        const getRes = res.data;
        this.setState({
          id: getRes.id,
          sch_name: getRes.sch_name,
          sch_reg_no: getRes.sch_reg_no,
          sch_recog_no: getRes.sch_recog_no,
          sch_contact_num: getRes.sch_contact_num,
          sch_mobile_num: getRes.sch_mobile_num,
          sch_email: getRes.sch_email,
          sch_address: getRes.sch_address,
          sch_medium: getRes.sch_medium,
          sch_logo: getRes.sch_logo,
          sch_wel_mes_title: getRes.sch_wel_mes_title,
          sch_wel_mes: getRes.sch_wel_mes,
          errorMessages: getRes.message
        });
      }).catch((error) => {
        // error
      })
  };
  price_in_words = (price) => {
    var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
      dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
      tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
      handle_tens = function (dgt, prevDgt) {
        return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
      },
      handle_utlc = function (dgt, nxtDgt, denom) {
        return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
      };

    var str = "",
      digitIdx = 0,
      digit = 0,
      nxtDigit = 0,
      words = [];
    if (price += "", isNaN(parseInt(price))) str = "";
    else if (parseInt(price) > 0 && price.length <= 10) {
      for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--) switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
        case 0:
          words.push(handle_utlc(digit, nxtDigit, ""));
          break;
        case 1:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 2:
          words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
          break;
        case 3:
          words.push(handle_utlc(digit, nxtDigit, "Thousand"));
          break;
        case 4:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 5:
          words.push(handle_utlc(digit, nxtDigit, "Lakh"));
          break;
        case 6:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 7:
          words.push(handle_utlc(digit, nxtDigit, "Crore"));
          break;
        case 8:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 9:
          words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "")
      }
      str = words.reverse().join("")
    } else str = "";
    return str

  }

  printThisReceipt = () => {
    // window.print();
  }

  render() {
    const { formIsHalfFilledOut, display_student_arr, medium, fee_status, fee_time, fee_month, fee_type } = this.state;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Fee Collection</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Fees Collection</div>

          <div className="ml-auto form-inline d-flex" >
            <label className="mr-2">
              Medium :
                     </label>
            <select className="form-control form-control-sm mr-2"
              required
              value={medium}
              onChange={event => this.changeHandler(event, 'medium')}>
              <option >Select ...</option>
              <option value="English">English</option>
              <option value="Hindi" >Hindi</option>
            </select>

            <label className="mr-1">Status :</label>
            <select className="form-control form-control-sm mr-2"
              disabled={medium === '' ? true : false}
              value={fee_status}
              onChange={event => this.changeHandler(event, 'fee_status')}>
              <option value='none'>Select ...</option>
              <option value="Deposited">Deposited</option>
              <option value="Verified">Verified</option>
              <option value="Unverified">Unverified</option>
            </select>
            <label className="mr-1">Time :</label>
            <select className="form-control form-control-sm mr-2"
              disabled={medium === '' ? true : false}
              value={fee_time}
              onChange={event => this.changeHandler(event, 'fee_time')}>
              <option value='none'>Select ...</option>
              <option value="Today">Today</option>
              <option value="Current Month">Current Month</option>
              <option value="Last Month">Last Month</option>
              <option value="Selected Month">Selected Month</option>
            </select>
            <label className="mr-1">Month :</label>
            <select className="form-control form-control-sm mr-2"
              disabled={fee_time === 'Selected Month' ? true : false}
              value={fee_month}
              onChange={event => this.changeHandler(event, 'fee_month')}>
              <option value='none'>Select ...</option>
              <option value="January">January</option>
              <option value="February">February</option>
              <option value="March">March</option>
              <option value="April">April</option>
              <option value="May">May</option>
              <option value="June">June</option>
              <option value="July">July</option>
              <option value="August">August</option>
              <option value="September">September</option>
              <option value="October">October</option>
              <option value="November">November</option>
              <option value="December">December</option>
            </select>
            <label className="mr-1">Type</label>
            <select className="form-control form-control-sm mr-1"
              disabled={medium === '' ? true : false}
              value={fee_type}
              onChange={event => this.changeHandler(event, 'fee_type')}>
              <option>All</option>
              <option>Normal</option>
              <option>Convence</option>
            </select>
          </div>
        </div>
        <div className="card card-box">

          <div className="card-body ">
            <div className="table-scrollable">
              <table className="table table-striped table-sm table-bordered table-sm">
                <thead>
                  <tr>
                    <th className="center" width="60"> </th>
                    <th className="center" width="100"> SR No.</th>
                    <th className="center" width=""> Student Name </th>
                    <th className="center" width="100"> Class</th>
                    <th className="center" width="100"> Status </th>
                    <th className="center" width="100"> Amount</th>
                    <th className="center" width="100"> Action</th>
                  </tr>
                </thead>
              </table>
              {display_student_arr.map((invoice, index) => {
                return (
                  <table key={index} className="table table-sm table-bordered 10">
                    <tbody>
                      <tr >
                        <td className="center" width="60"><input type="checkbox" />{index + 1}</td>
                        <td className="center" width="100">{invoice.admission_number}</td>
                        <td><strong>{invoice.student_name}</strong> S/o <br /> {invoice.father_name}</td>
                        <td className="center" width="100">{invoice.studying_in_class}</td>
                        <td className="center" width="100">P/C</td>
                        <td className="center" width="100">Rs. {invoice.total_amount}</td>
                        <td className="center" width="100">{(invoice.abc.length > 0) ? <button className="btn btn-primary btn-sm"><i className="fa fa-angle-right"></i></button> : null}</td>
                      </tr>
                      {(invoice.abc.length > 0) ?
                        <tr className=" d-none_temp">
                          <td colSpan="11" className="p-0">
                            <table className="table table-bordered table-sm m-0 23">
                              <thead>
                                <tr className="table-secondary">
                                  <th className="text-center" width="60">Id</th>
                                  <th className="text-center" width="150">Fee Amount</th>
                                  <th className="text-center" width="150">Total Amount</th>
                                  <th className="text-center" width="150">Balance Amount</th>
                                  <th className="text-center" width="150">Date</th>
                                  <th className="text-center">Description</th>
                                  <th className="text-center" width="100">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                {invoice.abc.map((in_detail, index) => {
                                  return (
                                    <tr key={index} className="table-warning">
                                      <td colSpan="7" className="p-0">
                                        <table key={index} className="table table-sm table-bordered m-0">
                                          <tbody>
                                            <tr >
                                              <td className="text-center" width="60">{in_detail.id}</td>
                                              <td className="text-right" width="150">{in_detail.fee_amount}</td>
                                              <td className="text-right" width="150">{in_detail.total_amount}</td>
                                              <td className="text-right" width="150">{in_detail.balance_amount}</td>
                                              <td className="text-right" width="150">{in_detail.deposit_date}</td>
                                              <td className="text-left" >{in_detail.description}</td>
                                              <td className="text-center" width="100"><button className="btn btn-primary btn-sm"><i className="fa fa-angle-right"></i></button></td>
                                            </tr>
                                            <tr>
                                              <td colSpan="7" className="p-0">
                                                <table key={index} className="table table-sm table-hover m-0">
                                                  <tbody>
                                                    <tr className="table-danger">
                                                      <th className="text-center">#</th>
                                                      <th className="text-right">Invoice id</th>
                                                      <th className="text-right">Fees Type</th>
                                                      <th className="text-right">Month of fee</th>
                                                      <th className="text-right">Amount</th>
                                                    </tr>
                                                    {(in_detail.xsd.length > 0) ? in_detail.xsd.map((in_detail1, index) => {
                                                      return (
                                                        <tr key={index} className="table-info">
                                                          <td className="text-center">{index + 1}</td>
                                                          <td className="text-right">{in_detail1.id}</td>
                                                          <td className="text-right">{in_detail1.fee_title}</td>
                                                          <td className="text-right">{in_detail1.month_of_fee}</td>
                                                          <td className="text-right">{in_detail1.fee_amount}</td>
                                                        </tr>
                                                      )
                                                    }) : null}
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                        : null
                      }
                    </tbody>
                  </table>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(FeesCollection);