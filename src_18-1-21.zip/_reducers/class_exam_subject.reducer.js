import { classExamSubjectConstants } from '../_constants';

export function classExamSubject(state = {}, action) {
  switch (action.type) {
    case classExamSubjectConstants.CLASS_EXAM_SUBJECT_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classExamSubjectConstants.CLASS_EXAM_SUBJECT_SUCCESS:
      return {
        item: action.response
      };
    case classExamSubjectConstants.CLASS_EXAM_SUBJECT_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}