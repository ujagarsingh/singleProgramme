import { feeDepositedAllConstants } from '../_constants';

export function feeDepositedAll(state = {}, action) {
  switch (action.type) {
    case feeDepositedAllConstants.FEE_COLLECTION_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeDepositedAllConstants.FEE_COLLECTION_SUCCESS:
      return {
        item: action.response
      };
    case feeDepositedAllConstants.FEE_COLLECTION_FAILURE:
      return {
        error: action.error
      };

    case feeDepositedAllConstants.CREATE_FEE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeDepositedAllConstants.CREATE_FEE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case feeDepositedAllConstants.CREATE_FEE_FAILURE:
      return {
        ...state,
        error: action.error
      };


    default:
      return state
  }
}