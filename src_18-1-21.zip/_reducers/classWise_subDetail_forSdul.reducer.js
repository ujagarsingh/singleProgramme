import { classWiseSubDetailsForSdulConstants } from '../_constants';

export function classWiseSubDetailsForShedule(state = {}, action) {
  switch (action.type) {
    case classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_SUCCESS:
      return {
        item: action.response
      };
    case classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}