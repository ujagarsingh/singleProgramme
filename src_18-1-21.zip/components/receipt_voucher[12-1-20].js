import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
// import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  accLedgerActions, professionalAction,
  accGroupActions, accLedgerEntryActions, studentsAction
} from '../_actions';
import { isEmptyObj, isEmpty, checkEntryType, getAllInputs } from '../utility/utilities';

// import CommonFilters from '../utility/Filter/filter-schools';

class ReceiptVoucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    filter_data: [],
    current_ldr: '',
    vchr_type: "Journal",
    voucher: { "vch_no": "3163", "credit": [{ "ldr_ref_id": "5_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Fee Discount" }, { "ldr_ref_id": "1_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Profit & Loss A/c" }, { "ldr_ref_id": "6_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Teaching Staff Salary" }, { "ldr_ref_id": "9_LDR_4", "tr_amount": "545", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Exam Fee" }, { "ldr_ref_id": "14_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Registration Fee" }], "debit": [{ "ldr_ref_id": "49_STU_4", "tr_amount": 743, "tr_type": "DR", "under_grp_id": "10", "under_grp_type": "P", "ledger_name": "AASHISH MEENA S/o RAMBABU MEENA [141/Fourth]" }], "cr_total_amo": 743, "dr_total_amo": 743, "narration": "AASHISH MEENA S/o RAMBABU MEENA Total Due is Rs. 743.", "vchr_type": "Journal" },
    vchr_date: new Date(),
  }

  setArraowKeysHandler() {
    document.addEventListener('keydown', (e) => {
      switch (e.keyCode) {
        case 37:
          // console.log('left');
          this.handleKeyDown("left");
          break;
        case 38:
          // console.log('up');
          this.handleKeyDown("up");
          break;
        case 39:
          // console.log('right');
          this.handleKeyDown("right");
          break;
        case 40:
          // console.log('down');
          this.handleKeyDown("down");
          break;
        case 13:
          // console.log('Enter');
          this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        case 9:
          // console.log('Tab');
          this.tabAndEnterHandler(e);
          break;
        default:
          console.log('something wrong');
      }
    });
  }

  chooseLedgerHandler() {
    debugger
    // current_grp: "credit"
    // current_inx: 0
    // cursor: 4
    // "ldr_ref_id": "5_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Fee Discount"

    // Alias: null
    // group_type: "P"
    // id: "108"
    // ldr_ref_id: "108_STU_4"
    // ledger_name: "AMAN MEENA S/o HARI NARAYAN MEENA [366/Eigth]"
    // ledger_type: "P"
    // school_id: "4"
    // server_date_time: null
    // type: "STU"
    // under_group: 10

    const { filter_data, cursor, current_grp, current_inx } = this.state;
    const current_ldr = filter_data[cursor];
    console.log(current_ldr);
    if (!isEmptyObj(current_ldr)) {
      let sv = this.state.voucher;
      sv[current_grp][current_inx]['ldr_ref_id'] = current_ldr['ldr_ref_id'];
      // sv[current_grp][current_inx]['under_grp_id'] = current_ldr['under_grp_id'];
      // sv[current_grp][current_inx]['under_grp_type'] = current_ldr['under_grp_type'];
      sv[current_grp][current_inx]['ledger_name'] = current_ldr['ledger_name'];
      this.setState({
        voucher: sv
      })
    }
  }

  handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }))
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }))
    }
  }



  changeHandler = (event, fieldName, isCheckbox, indexNo, trType) => {
    if (fieldName === 'left_ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher));
      sv.credit[indexNo].tr_type = _val;
      this.setState({ voucher: sv })
    } else if (fieldName === 'right_ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher));
      sv.debit[indexNo].tr_type = _val;
      this.setState({ voucher: sv })
    } else if (fieldName === 'credit' || fieldName === 'debit') {
      this.filterDataHandler(event, fieldName, indexNo);
    } else if (fieldName === 'credit_amo' || fieldName === 'debit_amo') {
      const tr_side = (fieldName === 'credit_amo') ? 'credit' : 'debit';
      this.updateTransetionAmountHandler(event, tr_side, indexNo, trType);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  updateTransetionAmountHandler(e, fieldName, indexNo, trType) {
    // let sv = JSON.parse(JSON.stringify(this.state.voucher));
    let sv = this.state.voucher;
    const _val = e.target.value;
    sv[fieldName][indexNo].tr_amount = _val;
    this.setState({
      voucher: sv,
      tr_type: trType
    })
  }

  filterDataHandler = (e, fieldName, indexNo) => {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    const _val = e.target.value;
    sv[fieldName][indexNo].ledger_name = _val;

    const ldr_list = (fieldName === "credit") ? "effected_left_ldr" : "effected_right_ldr";

    const _ldr_list = JSON.parse(JSON.stringify(this.state[ldr_list]));
    const val = _val.toUpperCase();
    const filtered_data = _ldr_list.filter((elem) => {
      const _elem = elem.ledger_name.toUpperCase();
      if (!_elem.includes(val)) {
        return false
      }
      return elem
    })
    // console.log(filtered_data);
    this.setState({
      filter_data: filtered_data,
      voucher: sv,
      // current_grp: fieldName,
      // current_inx: indexNo,
    }, () => {
      // this.handleKeyDown(e)
    })
  }

  blurHandler = (event, fieldName, isCheckbox, indexNo) => {
    const _val = event.target.value;
    if (fieldName === 'left_ldr_type') {
      if (_val === "Cr" || _val === "CR") {
        // const efected_group = [10];
        // this.effectedLedgerHandler(_val, efected_group);
      } else if (_val === "Dr" || _val === "DR") {
        // const efected_group = [11];
        // this.effectedLedgerHandler(_val, efected_group);
      } else {
        event.target.focus();
      }
    } else if (fieldName === 'right_ldr_type') {
      if (_val === "Cr" || _val === "CR") {
        // const efected_group = [10];
        // this.effectedLedgerHandler(_val, efected_group);
      } else if (_val === "Dr" || _val === "DR") {
        // const efected_group = [11];
        // this.effectedLedgerHandler(_val, efected_group);
      } else {
        event.target.focus();
      }
    }
  };

  ledgerListHandler = (event, fieldName, isCheckbox, indexNo) => {
    // debugger
    if (fieldName === 'credit') {
      this.setState({
        filter_data: this.state.effected_left_ldr,
        current_grp: fieldName,
        current_inx: indexNo,
      })
    } else if (fieldName === "debit") {
      this.setState({
        filter_data: this.state.effected_right_ldr,
        current_grp: fieldName,
        current_inx: indexNo,
      })
    }
  }
  afterSelectLedgerHandler = (event, fieldName, isCheckbox, indexNo) => {
    this.setState({
      filter_data: []
    })
  }
  effectedLedgerHandler() {
    // debugger
    let ldr_debit = [];
    let ldr_credit = [];
    const vchr_type = this.state.vchr_type;

    switch (vchr_type) {
      case "Payment":
        // code
        ldr_debit = [10];
        ldr_credit = [11];

        break;
      case "Receipt":
        // code
        break;
      default:
        // code
        ldr_credit = [1, 2];
        ldr_debit = [10];
    }
    const { all_ledgers } = this.props.accountManager;
    let efctd_cr_ldr = [];
    let efctd_dr_ldr = [];

    ldr_credit.forEach(el => {
      efctd_cr_ldr = [...efctd_cr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
    })

    ldr_debit.forEach(el => {
      efctd_dr_ldr = [...efctd_dr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
    });


    this.setState({
      effected_left_ldr: efctd_cr_ldr,
      effected_right_ldr: efctd_dr_ldr,
      all_ledgers: all_ledgers
    })
  }

  tabAndEnterHandler(ev) {
    ev.preventDefault();
    // const allinput = (!isEmpty(this.state.allinput) || this.state.allinput === 'undefined') ? getAllInputs() : this.state.allinput;
    const allinput = getAllInputs();
    const _ti = ev.target;
    let _ci = '';
    allinput.map((item, inx) => { if (item === _ti) { _ci = inx; } });

    let nextTi = '';
    if ((ev.shiftKey && ev.key === 'Tab') || (ev.shiftKey && ev.key === 'Enter')) {
      nextTi = (_ci === 0) ? allinput.length - 1 : _ci - 1;
    } else {
      nextTi = (_ci === allinput.length) ? 0 : (_ci === (allinput.length - 1)) ? 0 : _ci + 1;
    }
    (allinput[nextTi]).focus();
  }


  componentDidMount() {
    this.effectedLedgerHandler();
    this.setArraowKeysHandler();
  }

  render() {
    const { user, accountManager } = this.props;
    const { voucher, filter_data, cursor } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Accounting Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> Receipt Voucher</div>
        </div>
        {user && voucher && accountManager &&
          <div className="card card-box sfpage-cover light-trans">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page page-receipt-voucher">
                {(filter_data.length > 0) &&
                  <div className="list-accunts">
                    <div className="list-acc-head">List of Ledger Accunts</div>
                    <div className="list-acc-body">
                      <ul>
                        {filter_data.map((item, index) => {
                          return (
                            <li
                              className={cursor === index ? 'active' : null}
                              key={index}>
                              {item.ledger_name}
                            </li>
                          )
                        })}
                      </ul>
                    </div>
                    <div className="list-acc-footer">more...</div>
                  </div>
                }
                <div className="acc-page-head container-fluid">
                  <div className="sec-title">
                    <div className="title-zone">Particulars</div>
                    <div className="info-zone">
                      <div className="info-zone">
                        <table className="table table-bordered table-sm">
                          <tbody>
                            <tr>
                              <td>
                                <div className="dr-title">Debit</div>
                              </td>
                              <td>
                                <div className="cr-title">Credit</div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="acc-page-body container-fluid">
                  <div className="av-detail-zone">
                    {voucher.credit.map((item, index) => {
                      return (
                        <div className="av-detail-head" key={index}>
                          <div className="main-head" >
                            <div className="head-name d-flex">
                              <span className="txt-normal mr-2">
                                <input type="text"
                                  value={item.tr_type}
                                  maxLength="2"
                                  className="form-control trans-input tr-type form-control-sm"
                                  onChange={event => this.changeHandler(event, `left_ldr_type`, null, index)}
                                  onBlur={event => this.blurHandler(event, `left_ldr_type`, null, index)}
                                />
                              </span>
                              <input type="text"
                                value={item.ledger_name}
                                className="form-control trans-input tr-name form-control-sm"
                                onChange={event => this.changeHandler(event, `credit`, null, index)}
                                onFocus={event => this.ledgerListHandler(event, `credit`, null, index)}
                                onBlur={event => this.afterSelectLedgerHandler(event, `credit`, null, index)}

                              // onClick={() => this.effectedLedgerHandler([10])}
                              />
                            </div>
                            <div className="head-amount">
                              <div className="dr-total">
                                {(item.tr_type == "CR") ?
                                  <input type="text"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `credit_amo`, null, index, `CR`)}
                                  // onFocus={event => this.ledgerListHandler(event, `credit_amo`, null, index, `CR`)}
                                  // onBlur={event => this.afterSelectLedgerHandler(event, `credit_amo`, null, index, `CR`)}
                                  />
                                  : null}
                              </div>
                              <div className="cr-total">
                                {(item.tr_type == "DR") ?
                                  <input type="text"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `credit_amo`, null, index, `DR`)}
                                  // onFocus={event => this.ledgerListHandler(event, `credit_amo`, null, index, `DR`)}
                                  // onBlur={event => this.afterSelectLedgerHandler(event, `credit_amo`, null, index, `DR`)}
                                  />
                                  : null}
                              </div>
                            </div>
                          </div>
                          <div className="crnt-balance-head">
                            <div className="bal-head"><span className="txt-normal">Cur Bal :</span> {item.ldr_ref_id}</div>
                          </div>
                        </div>
                      )
                    })}
                    {voucher.debit.map((item, index) => {
                      return (
                        <div className="av-detail-head" key={index}>
                          <div className="main-head" >
                            <div className="head-name d-flex">
                              <span className="txt-normal mr-2">
                                <input type="text"
                                  value={item.tr_type}
                                  maxLength="2"
                                  className="form-control trans-input tr-type form-control-sm"
                                  onChange={event => this.changeHandler(event, `right_ldr_type`, null, index)}
                                  onBlur={event => this.blurHandler(event, `right_ldr_type`, null, index)}
                                />
                              </span>
                              <input type="text"
                                value={item.ledger_name}
                                className="form-control trans-input tr-name form-control-sm"
                                onChange={event => this.changeHandler(event, `debit`, null, index)}
                                onFocus={event => this.ledgerListHandler(event, `debit`, null, index)}
                                onBlur={event => this.afterSelectLedgerHandler(event, `debit`, null, index)}
                              // onClick={() => this.effectedLedgerHandler([10])}
                              />
                            </div>
                            <div className="head-amount">
                              <div className="dr-total">
                                {(item.tr_type == "CR") ?
                                  <input type="text"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `debit_amo`, null, index, `CR`)}
                                  // onFocus={event => this.ledgerListHandler(event, `debit_amo`, null, index, `CR`)}
                                  // onBlur={event => this.afterSelectLedgerHandler(event, `debit_amo`, null, index, `CR `)}
                                  />
                                  : null}
                              </div>
                              <div className="cr-total">
                                {(item.tr_type == "DR") ?
                                  <input type="text"
                                    value={item.tr_amount}
                                    className="form-control trans-input tr-amount form-control-sm"
                                    onChange={event => this.changeHandler(event, `debit_amo`, null, index, `DR`)}
                                  // onFocus={event => this.ledgerListHandler(event, `debit_amo`, null, index,`DR`)}
                                  // onBlur={event => this.afterSelectLedgerHandler(event, `debit_amo`, null, index,`DR`)}
                                  />
                                  : null}
                              </div>
                            </div>
                          </div>
                          <div className="crnt-balance-head">
                            <div className="bal-head"><span className="txt-normal">Cur Bal :</span> {item.ldr_ref_id}</div>
                          </div>
                        </div>
                      )
                    })}


                    {/* <div className="av-detail-head">
                      <div className="main-head">
                        <div className="head-name"><span className="txt-normal">Dr </span> Fees</div>
                        <div className="head-amount">
                          <div className="dr-total"></div>
                          <div className="cr-total">500.00</div>
                        </div>
                      </div>
                      <div className="crnt-balance-head">
                        <div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Dr</div>
                      </div>
                    </div> */}
                  </div>

                </div>
                <div className="acc-page-footer av-page-footer container-fluid">
                  <div className="sec-foot">
                    <div className="narration-zone">
                      <div className="title">Narration:</div>
                      <textarea
                        value={voucher.narration}
                        onChange={event => this.changeHandler(event, `narration`)}
                        className="form-control" >

                      </textarea>
                    </div>
                    <div className="amount-zone">
                      <div className="dr-total">{voucher.dr_total_amo}</div>
                      <div className="cr-total">{voucher.cr_total_amo}</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accountManager } = state.accountManager;
  return {
    user, accountManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
}

export default connect(mapStateToProps, actionCreators)(withRouter(ReceiptVoucher));
