import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// import CommonFilters from '../utility/Filter/filter-schools';
class GroupSummary extends Component {

	state = {
		groups_list: [],
		formIsHalfFilledOut: false,
	}

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
			this.props.getAccLedgerEntry();
		}

		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}

		if (isEmptyObj(this.props.accGroup)) {
			this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		// this.checkFlag();
		this.getGroupSummaryHandler();
	}

	getGroupSummaryHandler() {
		// debugger
		const { match } = this.props;
		const _id = match.params.id;
		const _type = match.params.type;
		const _grp_id = match.params.grp_id;
		const _groups = this.props.accountManager.group_balance;
		let _groups_list = [];
		if (_type === "2") {
			const filtered_group = _groups.filter((item) => {
				if (item.id === _id) {
					return item
				}
			})
			_groups_list = filtered_group[0]["sub_group"];
		} else if (_type === "3") {
			const filtered_group = _groups.filter((item) => {
				if (item.id === _grp_id) {
					return item
				}
			})
			const filtered_ledger = filtered_group[0].sub_group.filter((l_item) => {
				if (l_item.id === _id) {
					return l_item
				}
			})

			_groups_list = filtered_ledger[0]["sub_ledgers"];
		} else {
			alert("Somthing Wrong!!!")
		}

		this.setState({
			groups_list: _groups_list,
			group_type: _type
		})
	}
	render() {
		const { groups_list, group_type } = this.state;
		const { filteredSchoolData } = this.props;
		// console.log(groups_list)
		return (
			<div className="page-content">
				<Helmet>
					<title>Group Summary</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Group Summary</div>
				</div>
				<div className="card card-box sfpage-cover">
					<div className="card-body p-1 sfpage-body">
						<div className="acc-page page-group-summary">
							<div className="acc-page-head  container-fluid">
								<div className="sec-title">
									<div className="title-zone">Particulars</div>
									<div className="info-zone">
										<div className="info-zone">
											<table className="table table-bordered table-sm">
												<thead>
													<tr>
														<th colSpan="3">
															<div className="group-name">Sundry Debtors</div>
															<div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
															<div className="fy-detail">1-Apr-2020 to 1-Jul-2020</div>
														</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td colSpan="2">
															<div className="blnc-title">Closing Balance</div>
														</td>
													</tr>
													<tr>
														<td>
															<div className="dr-title">Debit</div>
														</td>
														<td>
															<div className="cr-title">Credit</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div className="acc-page-body container-fluid">
								<div className="gs-detail-zone">
									{groups_list.map((item, index) => {
										if (item.type === "S_GRP") {
											return (
												<NavLink key={index} to={`/group_summary.jsp/${'3'}/${item.id}/${item.under_gp_id}`} className="link-without-color">
													<div className="gs-detail-head" >
														<div className="head-name">{(group_type == '2') ? item.group_name : item.ledger_name}</div>
														<div className="head-amount">
															{(item.blnc_type == "DR") ?
																<div className="dr-total">{item.cl_blnc}.00</div>
																:
																<div className="cr-total">{item.cl_blnc}.00</div>
															}
														</div>
													</div>
												</NavLink>
											)
										} else {
											return (
												<NavLink to={`/ledger_monthly_summary.jsp/${item.ldr_ref_id}`} className="link-without-color" key={index}>
													<div className="gs-detail-head" >
														<div className="head-name">{(group_type == '2') ? item.group_name : item.ledger_name}</div>
														<div className="head-amount">
															{(item.blnc_type == "DR") ?
																<div className="dr-total">{(item.cl_blnc === 0) ? '' : item.cl_blnc}</div>
																:
																<div className="cr-total">{(item.cl_blnc === 0) ? '' : item.cl_blnc}</div>
															}
														</div>
													</div>
												</NavLink>
											)
										}
									})}
								</div>
							</div>
							<div className="acc-page-footer container-fluid">
								<div className="sec-foot">
									<div className="title-zone">Ground Total</div>
									<div className="amount-zone">
										<div className="dr-total"></div>
										<div className="cr-total">7,200.00</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	const { item: accountManager } = state.accountManager;
	return {
		user, students, accLedger, accGroup, accLedgerEntry, accountManager,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry
}

export default connect(mapStateToProps, actionCreators)(withRouter(GroupSummary));