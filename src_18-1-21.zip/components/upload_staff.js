import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import CSVReader from 'react-csv-reader'
import { Helmet } from "react-helmet";
import { ExportCSV } from '../utility/Export_CSV/ExportCSV';
import { connect } from 'react-redux';
import { schoolsAction, professionalAction} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const UPDATE_RECORDS = `http://schools.rajpsp.com/api/professional/staff_update_records.php`;
const INSERT_NEW_RECORDS = `http://schools.rajpsp.com/api/professional/staff_insert_records.php`; 
// const READ_SCH_STAFF = `http://schools.rajpsp.com/api/professional/read.php`; 
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`; 

const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
};

class UploadStaff extends Component {
  state = {
    schools: [],
    user_id: 1,
    filtered_staff: [],
    updated_staff: [],
    new_staff: [],
    excel_staff: [],
    isDuplicate: false,
    firstStage: false,
    secondStage: false,
    student_Obj: [],
    medium_arr: [],
    medium: "",
    staff_Obj: [],
    upload_by: "",
    errorMessages: "",
    successMessages: "",
    formIsHalfFilledOut: false,
    is_school_select: false,
    dummy_staff_rte: [],
    dummy_staff_udise: []
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      if (_inx !== "") {
        const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : "";
        const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
        sessionStorage.setItem("school_id", _sch_id);
        this.setState({
          school_id: _sch_id,
          medium_arr: _medium,
          medium: (_medium.length === 1 ? _medium[0] : ""),
          selected_school_index: _inx,
          is_school_select: true
        }, () => {
          this.filterStaffOfSchool(_sch_id);
        })
      } else {
        this.setState({
          is_school_select: false
        })
      }
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      });
    } else if (fieldName === 'set_new') {
      const _val = event.target.value;
      const index = isCheckbox;
      this.manageNewDataWithTaga(index, _val);
    } else if (fieldName === 'set_update') {
      const _filter_inx = event.target.value;
      const _filtered_staff = this.state.filtered_staff;
      const _update_id = _filtered_staff[_filter_inx].id;
      const index = isCheckbox;
      this.manageAddIdofOldRecords(index, _filter_inx, _update_id);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  createDummyStudentCsv() {
    let rte = [{
      id: "", emp_type: "", emp_crnt_designation: "", aadhar_no: "", emp_name: "", emp_f_name: "", dob: "", gender: "",
      caste: "", edu_qulifi: "", pacific_ability: "", is_rtet_qlifid: "",
      appoint_date: "", sec_roll_no: "", sec_year: "", emp_mob: "", emp_cur_sub: ""
    }];

    let udise = [{
      sl_no: "", status: "", teacher_code: "", name: "", gender: "", dob: "", social_category: "", type_of_teacher: "",
      nature_of_appointment: "", date_of_joining_in_service: "", highest_academic_qualification: "",
      highest_professional_qualification: "", classes_taught: "", appointed_for_subject: "", main_subject_taught_1: "",
      main_subject_taught_2: "", brc: "", crc: "", diet: "", others: "", training_received: "", training_need: "",
      no_of__non_teaching_assignments: "", maths_studied_up_to: "", science_studied_up_to: "",
      english_studied_up_to: "", language_studied_upto: "", social_studies_studied_up_to: "",
      working_in_present_school_since_year: "", type_of_disability_if_any: "", trained_for_teaching_cwsn: "",
      trained_computer_and_teaching_through_computer: "", mobile_number: "", e_mail_id: ""
    }];

    this.setState({
      dummy_staff_rte: rte,
      dummy_staff_udise: udise
    })
  }
  manageAddIdofOldRecords(index, filter_inx, update_id) {
    debugger
    const excel_staff = this.state.excel_staff;
    const _excel_staff = excel_staff.filter((item, idx) => {
      if (idx === index) {
        item.update_by = update_id;
        item.filter_inx = filter_inx;
      }
      return item;
    });
    this.setState({
      excel_staff: _excel_staff
    }, () => { this.filterStaffonExcelData() })
  }
  manageNewDataWithTaga(index, tag) {
    debugger
    const excel_staff = this.state.excel_staff;
    const _excel_staff = excel_staff.filter((item, idx) => {
      if (idx === index) {
        if (tag === "") {
          item.data_type = tag;
          item.update_by = "";
          item.filter_inx = "";
        } else {
          item.data_type = tag;
        }
      }
      return item;
    });
    this.setState({
      excel_staff: _excel_staff
    }, () => { this.filterStaffonExcelData() })
  }
  filterStaffonExcelData() {
    const _excel_staff = this.state.excel_staff;
    let _newData = [];
    let _updateData = [];
    _newData = _excel_staff.filter((item) => {
      if (item.data_type === 'New') {
        return item
      }
    })
    _updateData = _excel_staff.filter((item) => {
      if (item.data_type === 'Update' && item.update_by !== "") {
        return item
      }
    })
    this.setState({
      updated_staff: _updateData,
      new_staff: _newData
    })
  }
  filterStaffOfSchool(sch_id) {
    const _staff = this.props.professional;
    const _filtered_staff = _staff.filter((item) => {
      if (item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      filtered_staff: _filtered_staff
    });
  }

  staffObjHandlerUDISE = (udise_obj) => {
    // var self = this;
    let new_obj = [];
    udise_obj.map((elem) => {
      if (!isEmpty(elem.name)) {
        let _crt_obj = {
          id: elem.sl_no,
          emp_type: elem.nature_of_appointment.split('-').pop(),
          emp_crnt_designation: elem.type_of_teacher.split('-').pop(),
          aadhar_no: "",
          emp_name: elem.name,
          emp_f_name: "",
          dob: elem.dob,
          gender: elem.gender.split('-').pop(),
          caste: elem.social_category.split('-').pop(),
          edu_qulifi: elem.highest_academic_qualification.split('-').pop(),
          pacific_ability: elem.highest_professional_qualification.split('-').pop(),
          is_rtet_qlifid: "",
          appoint_date: elem.date_of_joining_in_service,
          sec_roll_no: "",
          sec_year: "",
          emp_mob: elem.mobile_number,
          emp_cur_sub: elem.appointed_for_subject.split('-').pop(),
          update_by: "",
          filter_inx: "",
          data_type: ""
        };
        new_obj.push(_crt_obj);
      }
    });
    console.log(new_obj);
    this.setState({
      excel_staff: new_obj,
      firstStage: true
    })

  };

  staffObjHandler = (new_obj) => {
    debugger
    const _new_obj = new_obj.filter((item) => {
      if (!isEmpty(item.emp_name)) {
        item.data_type = "";
        item.update_by = "";
        item.filter_inx = ""
        return item;
      }
    })
    this.setState({
      excel_staff: _new_obj,
      firstStage: true
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    this.createDummyStudentCsv();
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getSchoolStaffRecords();
  //           this.createDummyStudentCsv();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
 
  // getSchoolStaffRecords() {
  //   const obj = {
  //     group_id: this.state.group_id,
  //     session_year_id: this.state.session_year_id,
  //     user_category: this.state.user_category,
  //     school_id: this.state.school_id
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_SCH_STAFF, obj)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.length > 0) {
  //         this.setState({
  //           sch_staff: resData,
  //           errorMessages: resData.message
  //         });
  //       }
  //     }).catch((error) => {
  //       // error
  //     });
  // }

  handalShowHide = (e) => {
    e.preventDefault();
    const _table = e.target.parentElement.nextSibling;
    const _table_class = e.target.parentElement.nextSibling.classList;
    if (_table_class.length === 0) {
      _table.className = 'd-none';
      e.target.innerText = "Show";
    } else {
      _table.className = "";
      e.target.innerText = "Hide";
    }
  }
  generateMatchedStaffTable(staff, title, flag) {
    return (
      <>
        <h6 className={"d-flex p-1 text-white " +
          ((flag === "OLD_STAFF") ? 'bg-warning' :
            ((flag === "NEW_STAFF") ? 'bg-success' :
              ((flag === "EXC_STAFF") ? 'bg-primary' :
                ((flag === "UPDATE_STAFF") ? 'bg-info' : 'bg-danger'))))}>
          <span className="p-2">{title}</span>
          <button
            type="button"
            className="ml-auto btn btn-secondary btn-sm"
            value={flag}
            onClick={event => this.handalShowHide(event)}
          >Hide</button>
        </h6>
        <div>
          <div className="table-responsive">
            <table className="table table-striped table-bordered table-hover text-nowrap table-sm">
              <thead>
                <tr>
                  <th />
                  {flag === "EXC_STAFF" ?
                    <th>Select....</th>
                    : null}
                  <th>Employee Name</th>
                  <th>Father's Nname</th>
                  <th>Date of birth</th>
                  <th>Gender</th>
                  <th>Caste</th>
                  <th>Emp. Type</th>
                  <th>Emp. Crnt Designation</th>
                  <th>Aadhar No</th>
                  <th>Educational Qualification</th>
                  <th>Qualitative Qualification</th>
                  <th>Teacher RTET / REET / CTET Qualified?</th>
                  <th>Appointment Date</th>
                  <th>Secondary Roll Number</th>
                  <th>Secondary Year</th>
                  <th>emp_mob</th>
                  <th>Current Employee's Subject</th>
                </tr>
              </thead>
              <tbody>
                {staff.map((value, index) => {
                  return (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      {flag === "EXC_STAFF" ?
                        <td>
                          <select
                            // value={selected_school_index}
                            onChange={event => this.changeHandler(event, 'set_new', index)}>
                            <option></option>
                            <option>New</option>
                            <option>Update</option>
                          </select>

                          {value.data_type === "Update" ?
                            <>
                              By: <select style={{ "width": "110px" }}
                                value={value.filter_inx}
                                onChange={event => this.changeHandler(event, 'set_update', index)}>
                                <option></option>
                                {this.state.filtered_staff.map((item, inx) => {
                                  return <option key={inx} value={inx}>
                                    ___ {item.emp_name}, ___
                                {item.emp_f_name}, ___
                                {item.aadhar_no}, ___
                                {item.gender}, ___
                                [{item.sec_roll_no}] </option>
                                })}
                              </select>
                            </>
                            : null}
                        </td>
                        : null}
                      <td>{value.emp_name}</td>
                      <td>{value.emp_f_name}</td>
                      <td>{value.dob}</td>
                      <td>{value.gender}</td>
                      <td>{value.caste}</td>
                      <td>{value.emp_type}</td>
                      <td>{value.emp_crnt_designation}</td>
                      <td>{value.aadhar_no}</td>
                      <td>{value.edu_qulifi}</td>
                      <td>{value.pacific_ability}</td>
                      <td>{value.is_rtet_qlifid}</td>
                      <td>{value.appoint_date}</td>
                      <td>{value.sec_roll_no}</td>
                      <td>{value.sec_year}</td>
                      <td>{value.emp_mob}</td>
                      <td>{value.emp_cur_sub}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </>
    )
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.insertAndUploadStaffHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  insertAndUploadStaffHandler() {
    loadProgressBar();
    const group_id = this.state.group_id;
    const school_id = this.state.school_id;
    const user_id = this.state.user_id;
    const session_year_id = this.state.session_year_id;
    const medium = this.state.medium;
    const updated_staff = this.state.updated_staff;
    const new_staff = this.state.new_staff;

    const obj_update = {
      group_id, school_id, session_year_id, user_id, medium, updated_staff
    }
    const obj_new = {
      group_id, school_id, session_year_id, user_id, medium, new_staff
    }

     console.log(JSON.stringify(obj_new))
     console.log(JSON.stringify(obj_update))
    // debugger
    if (updated_staff.length > 0) {
      axios.post(UPDATE_RECORDS, obj_update)
        .then(res => {
          const getRes = res.data;
          if (getRes.message) {
            Alert.success(getRes.message, {
              position: 'bottom-right',
              effect: 'jelly',
              timeout: 5000, offset: 40
            });
          }
          this.refreshHandler();
        }).catch((error) => {
          //this.setState({ errorMessages: error });
        })
    }  

    if (new_staff.length > 0) {
      axios.post(INSERT_NEW_RECORDS, obj_new)
        .then(res => {
          const getRes = res.data;
          if (getRes.message) {
            Alert.success(getRes.message, {
              position: 'bottom-right',
              effect: 'jelly',
              timeout: 5000, offset: 40
            });
          }
          this.refreshHandler();
        }).catch((error) => {
          // this.setState({ errorMessages: error });
        })
    }  
  }

  refreshHandler() {
    this.setState({
      firstStage: false,
      secondStage: false,
      selected_school_index: "",
      new_staff: [],
      excel_staff: [],
      updated_staff: []
    })
  }

  papaparseOptions = {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    transformHeader: header =>
      header
        .toLowerCase()
        .replace(/\W/g, '_')
  }
  handleDarkSideForce(data) {
    debugger
    console.log(data)
  }
  setRequireVlaues(ev) {
    ev.preventDefault();
    this.setState({
      secondStage: true
    })
  }
  render() {
    const { user, schools, professional  } = this.props;
    const { formIsHalfFilledOut, firstStage, secondStage, new_staff, filtered_staff, excel_staff,
      selected_school_index, updated_staff, medium_arr, medium, upload_by, is_school_select,
      student_Obj, staff_Obj, dummy_staff_rte, dummy_staff_udise } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Upload Staff Data</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Upload Staff Data</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <div className="card-box">
                <div>

                  {new_staff.length > 0 ?
                    this.generateMatchedStaffTable(new_staff, 'New Staff', 'NEW_STAFF')
                    : null}
                  {updated_staff.length > 0 ?
                    this.generateMatchedStaffTable(updated_staff, 'Updated Staff', 'UPDATE_STAFF')
                    : null}
                  {excel_staff.length > 0 ?
                    this.generateMatchedStaffTable(excel_staff, 'Excel Staff', 'EXC_STAFF')
                    : null}
                  {filtered_staff.length > 0 ?
                    this.generateMatchedStaffTable(filtered_staff, 'Existing Staff', 'OLD_STAFF')
                    : null}
                </div>

              </div>
            </div>
          </div>
        </div>


        <div className="card-footer">
          <div className="row text-center mb-1">
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 1</span>
            </div>
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 2</span>
            </div>
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 3</span>
            </div>
          </div>
          <div className="form-body">
            <div className="form-inline">
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Schools :</label>
                <select className="form-control form-control-sm"
                  required
                  ref='school'
                  value={selected_school_index}
                  onChange={event => this.changeHandler(event, 'school')}>
                  <option value="">Select ...</option>
                  {schools.map((item, index) => {
                    return (
                      <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                    )
                  })}
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Medium :</label>
                <select className="form-control form-control-sm"
                  required
                  ref='medium'
                  disabled={medium_arr.length > 1 ? false : true}
                  value={medium}
                  onChange={event => this.changeHandler(event, 'medium')}>
                  <option value="">Select ...</option>
                  {medium_arr.map((item, index) => {
                    return (
                      <option key={index} value={item}>{item}</option>
                    )
                  })}
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Upload By :</label>
                <select className="form-control form-control-sm"
                  required
                  ref='upload_by'
                  value={upload_by}
                  onChange={event => this.changeHandler(event, 'upload_by')}>
                  <option value="">Select ...</option>
                  <option>RTE</option>
                  <option>UDISE</option>

                </select>
              </div>

              {upload_by !== "" ?
                <div className="form-group  ml-auto">
                  {upload_by === 'RTE' ?
                    <CSVReader
                      cssClass="csv-reader-input"
                      label={`By ` + upload_by + `- `}
                      onFileLoaded={this.staffObjHandler}
                      onError={this.handleDarkSideForce}
                      parserOptions={papaparseOptions}
                      inputId="ObiWan"
                      inputStyle={{ color: 'red' }}
                    />
                    :
                    <CSVReader
                      cssClass="csv-reader-input"
                      label={`By ` + upload_by + `- `}
                      onFileLoaded={this.staffObjHandlerUDISE}
                      onError={this.handleDarkSideForce}
                      parserOptions={papaparseOptions}
                      inputId="ObiWan"
                      inputStyle={{ color: 'red' }}
                    />
                  }
                </div>
                : null}
            </div>
            {is_school_select ?
              <div className="mt-1 d-flex">
                {upload_by === 'RTE' ?
                  <ExportCSV
                    csvData={dummy_staff_rte}
                    fileName={`upload_staff_by_` + upload_by} />
                  :
                  <ExportCSV
                    csvData={dummy_staff_udise}
                    fileName={`upload_staff_by_` + upload_by} />
                }
                <span className="ml-auto">

                  <button type="button"
                    className="btn btn-success mr-1"
                    disabled={!firstStage}
                    onClick={event => this.confirmBoxSubmit(event)}>
                    Save and Update
                </button>
                  <button type="button" className="btn btn-danger"
                    onClick={event => this.refreshHandler(event)}>
                    Refresh</button>
                </span>
              </div>
              : null}
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: professional } = state.professional;
  return { user, schools, professional };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getProfessional: professionalAction.getProfessional,
}

export default connect(mapStateToProps, actionCreators)(withRouter(UploadStaff));