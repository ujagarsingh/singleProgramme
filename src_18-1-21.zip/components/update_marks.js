import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { classesAction, studentsAction, examsAction,  maxMarksAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const GET_EXAMS = `http://schools.rajpsp.com/api/exam/read.php`;
const READ_SUB_MARKS = `http://schools.rajpsp.com/api/exam/read_max_marks_subject.php`;
const READ_SUBJECT = `http://schools.rajpsp.com/api/subject/read.phpxxx   `;
const READ_CLASS_STUDENT = `http://schools.rajpsp.com/api/students/read.php`;   
const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
const CREATE_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/create_multiple.php`;
const READ_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/read_specific.php`; 


class UpdateMarks extends Component {
  state = {
    students: [],
    classes: [],
    display_classes: [],
    exams: [],
    subjects: [],
    classwise_subject: [],
    selected_student: [],
    display_student: [], // for add ischeck and max_marks
    update_student: [], // for only check student when submit
    selected_subject: '',
    selected_class: '',
    selected_exam: '',
    class_id: '',
    exam_id: '',
    subject_id: '',
    max_marks: '',
    selectAllStudentCheck: false,
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    });
    if (fieldName === 'selected_class') {
      const _classIdx = event.target.value;
      if (_classIdx !== '') {
        const _class_id = this.state.display_classes[_classIdx].id;
        const _class_name = this.state.display_classes[_classIdx].class_name;
        this.filterStudentOnClass(_class_id);
        this.classWiseSubjectHandler(_class_id);
        this.getExamAccordingClass();
        this.setState({
          class_id: _class_id,
          selected_class: _class_name,
          selected_subject: '',
          selected_exam: '',
          subject_id: '',
          exam_id: '',
          max_marks: ''
        })
      }
    }
    if (fieldName === 'all_checks') {
      this.selectAllStudentHandler();
    }
    if (fieldName === 'selected_exam') {
      const _examIdx = event.target.value;
      if (_examIdx !== '') {
        const _exam_name = this.state.exams[_examIdx].exam_name;
        const _exam_id = this.state.exams[_examIdx].id;
        this.setState({
          selected_exam: _exam_name,
          exam_id: _exam_id,
          selected_subject: '',
          subject_id: '',
          max_marks: ''
        })
      }
      this.resetMarksObtain();

    }
    if (fieldName === 'selected_subject') {
      const _subIdx = event.target.value;
      if (_subIdx !== '') {
        const _class_id = this.state.class_id;
        const _exam_id = this.state.exam_id;
        const _subject_id = this.state.classwise_subject[_subIdx].id;
        const _subject_name = this.state.classwise_subject[_subIdx].sub_name;
        this.getSubMarksAccordingExam(_class_id, _exam_id, _subject_id);
        this.setState({
          subject_id: _subject_id,
          selected_subject: _subject_name
        })
      }
    }
    if (fieldName === 'subject_marks') {
      const _max_marks = parseInt(this.state.max_marks);
      const _marks_val = (parseInt(event.target.value) !== '') ? event.target.value : 0;

      const _stu_idx = event.target.getAttribute('data-stu-idx');
      var _updated_student = this.state.display_student.map((item, index) => {
        if (_stu_idx === index && _marks_val <= _max_marks) {
          //if (_marks_val < _max_marks) {
          return item = { ...item, 'marks_obtain': _marks_val }
          //}
        } else {
          return item
        }
      })
      //console.log(_updated_student);
      this.setState({
        display_student: _updated_student
      })
    }
  };

  resetMarksObtain = () => {
    const _display_student = this.state.display_student.map((chkitem) => {
      const item = { ...chkitem, marks_obtain: '' };
      return item;
    })
    this.setState({
      display_student: _display_student
    })
  };
  checkHandler = (event, fieldName, value) => {
    let _display_student = null;
    let _current_select = JSON.parse(value).admission_number;
    if (fieldName === 'select_this') {
      _display_student = this.state.display_student.map((chkitem) => {
        if (_current_select === chkitem.admission_number) {
          chkitem['checked'] = !chkitem.checked;
          return chkitem;
        }
        return chkitem;
      })
      this.setState({
        update_student: _display_student
      })
    } else if (fieldName === 'select_all') {
      _display_student = this.state.display_student.map((chkitem) => {
        chkitem['checked'] = (event.target.checked) ? true : false;
        return chkitem;
      })
      this.setState({
        update_student: _display_student
      })
    }
    let _update_student = _display_student.filter((chkitem) => {
      return chkitem['checked'] === true
    })
    this.setState({
      display_student: _display_student,
      update_student: _update_student
    }, () => {
      //console.log(_display_student);
      //console.log(this.state.update_student);
    })
  };

  // get all subject name accoding to class
  classWiseSubjectHandler(_class_id) {
    if (_class_id !== '') {
      //classwise_subject
      const _subects = this.state.subjects.filter((item, index) => {
        if (item.class_id === _class_id) {
          return item
        }
      })
      //console.log(JSON.stringify(_subects))
      this.setState({
        classwise_subject: _subects
      })
    }
  }
  selectAllStudentHandler() {
    this.setState({
      selectAllStudentCheck: !this.state.selectAllStudentCheck
    })
  }
  filterStudentOnClass(_class) {
    this.getStudentRecords(_class);
  }
  getExamAccordingClass = () => {
    // read all exas list
    loadProgressBar();
    axios.get(GET_EXAMS)
      .then(res => {
        const getRes = res.data;
        this.setState({
          exams: getRes,
          errorMessages: getRes.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  }

  getSubMarksAccordingExam = (class_id, exam_id, sub_id) => {
    const obj = {
      class_id: class_id,
      exam_id: exam_id,
      sub_id: sub_id
    }
    loadProgressBar();
    console.log(JSON.stringify(obj));
    axios.post(READ_SUB_MARKS, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          max_marks: getRes.max_marks
        })
      }).catch((error) => {
        // error
      });
    axios.post(READ_MAX_MARKS, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        const _display_student = this.state.display_student.map((item, index) => {
          const _admission_number = item.admission_number;
          if (getRes.length > 0) {
            getRes.map((item_1) => {
              if (_admission_number === item_1.admission_number &&
                this.state.exam_id === item_1.exam_id &&
                this.state.subject_id === item_1.sub_id) {
                item['marks_obtain'] = item_1.marks_obtain;
                item['marks_obtain_id'] = item_1.id;
              }
            })
            return item;
          } else {
            item['marks_obtain'] = ''
            return item;
          }
        })
        this.setState({
          display_student: _display_student
        })
      }).catch((error) => {
        // error
      });
  }
  getStudentRecords = (id) => {
    const obj = {
      class_id: id,
      medium: this.state.medium
    }
    axios.post(READ_CLASS_STUDENT, obj)
      .then(res => {
        const students = res.data;
        this.setState({
          students: students,
          errorMessages: students.message
        }, () => {
          const _students = students.map((student) => {
            const xyz = { ...student };
            xyz['checked'] = false;
            xyz['marks_obtain'] = '';
            return xyz;
          })
          this.setState({
            display_student: _students
          })
        });
        ////console.log('DATABASE STUDENT :', this.state.students);
        ////console.log('DISPLAY STUDENT :', this.state.display_student);
      }).catch((error) => {
        // error
      });
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.exams)) {
      this.props.getExams();
    }
    if (isEmptyObj(this.props.maxMarks)) {
      this.props.getMaxMarks();
    }
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getClassesHandler();
            this.getAllSubjectsHandler();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }


  getClassesHandler() {
    const { id } = this.props.match.params;
    const ids_arr = id.split('-');
    // read all existing class
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
    }
    axios.post(READ_CLASS_URL, obj)
      .then(res => {
        let _medium = '';
        const classes = res.data;
        classes.filter((item, inx) => {
          if (item.id === ids_arr[0]) {
            _medium = item.medium
          }
        })

        const _classes = classes.filter((item, inx) => {
          if (item.medium === _medium) {
            return item
          }
        })

        this.setState({
          classes: classes,
          display_classes: _classes,
          class_id: ids_arr[0],
          exam_id: ids_arr[1],
          sub_id: ids_arr[2],
          medium: _medium,
          errorMessages: res.data.message
        });
        //console.log(this.state.classes);
      }).then(res => {
        this.getStudentRecords(ids_arr[0]);
      })
      .catch((error) => {
        // error
      });


  };

  getAllSubjectsHandler() {
    // read all subjes according class
    loadProgressBar();
    axios.get(READ_SUBJECT)
      .then(res => {
        const subjects = res.data;
        this.setState({
          subjects: subjects,
          errorMessages: subjects.message
        });
        //console.log(this.state.subjects);
      }).catch((error) => {
        // error
      })
  }

  singleUpdateHandler = (e, admission_number) => {
    e.preventDefault();
    const obj = [];
    this.state.display_student.filter((item) => {
      if (item['admission_number'] === admission_number) {
        obj[0] = {
          max_marks: this.state.max_marks,
          class_id: this.state.class_id,
          exam_id: this.state.exam_id,
          sub_id: this.state.subject_id,
          admission_number: item.admission_number,
          marks_obtain: item.marks_obtain,
          id: item.marks_obtain_id
        }
      }
    })
    const singleObj = { myObj: obj };
    //console.log(JSON.stringify(singleObj));
    loadProgressBar();
    axios.post(CREATE_MAX_MARKS, singleObj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          // update_student: [],
          selected_subject: '',
          selected_exam: '',
          subject_id: '',
          exam_id: '',
          max_marks: ''
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
    // document.location.reload();
  }
  updateHandler = (e) => {
    e.preventDefault();
    loadProgressBar();
    const _obj = [];
    let counter = 0;
    this.state.update_student.map((item) => {
      _obj[counter] = {
        max_marks: this.state.max_marks,
        class_id: this.state.class_id,
        exam_id: this.state.exam_id,
        sub_id: this.state.subject_id,
        admission_number: item.admission_number,
        marks_obtain: item.marks_obtain,
        id: item.marks_obtain_id
      }
      counter++;
    })
    const obj = { myObj: _obj };
    //console.log(JSON.stringify(obj));
    axios.post(CREATE_MAX_MARKS, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          // update_student: [],
          selected_subject: '',
          selected_exam: '',
          subject_id: '',
          exam_id: '',
          max_marks: ''
        })
        const _display_student = this.state.display_student.map((chkitem) => {
          chkitem['checked'] = false;
          return chkitem;
        })
        this.setState({
          update_student: _display_student
        })
        //document.location.reload();
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  render() {
    const { display_classes, exams, classwise_subject, selected_class, selected_exam,
      selected_subject, display_student, max_marks } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Update Marks</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Add Subject Wise Marks</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mr-2 mt-1">
                <label className="mr-2">Class:</label>
                <select
                  // value={this.state.selected_class}
                  className="form-control form-control-sm" name="selected_class"
                  onChange={event => this.changeHandler(event, 'selected_class')} >
                  <option value="">Select...</option>
                  {display_classes.map((option, index) => {
                    return (<option key={index} value={index}>{option.class_name}</option>)
                  })}
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="mr-2">Exam:</label>
                <select
                  value={this.state.selected_exam}
                  className="form-control form-control-sm" name="selected_exam"
                  onChange={event => this.changeHandler(event, 'selected_exam')} >
                  <option value="">Select...</option>
                  {exams.map((option, index) => {
                    return (<option key={index} value={index}>{option.exam_name}</option>)
                  })}
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="mr-2">Subject:</label>
                <select
                  value={this.state.selected_subject}
                  className="form-control form-control-sm" name="selected_subject"
                  onChange={event => this.changeHandler(event, 'selected_subject')} >
                  <option value="">Select...</option>
                  {classwise_subject.map((option, index) => {
                    return (<option key={index} value={index}>{option.sub_name}</option>)
                  })}
                </select>
              </div>
            </div>
          </div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="p-2">
            Class :
            <span className="badge ml-2 mr-3 badge-pill badge-primary">{selected_class}</span>
            / Exam :
             <span className="badge ml-2 mr-3 badge-pill badge-secondary">{selected_exam}</span>
            / Subject :
              <span className="badge ml-2 mr-3 badge-pill badge-warning">{selected_subject}</span>
          </div>

          <div className="card-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th>
                      <div className="custom-control custom-checkbox">
                        <input type="checkbox"
                          id="select_all" className="custom-control-input"
                          onChange={event => this.checkHandler(event, 'select_all', true)} />
                        <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                      </div>
                    </th>
                    <th />
                    <th>Sr. No.</th>
                    <th>Student & Father's Name</th>
                    <th>Class</th>
                    <th> NUMBER</th>
                    <th>Marks</th>
                    <th>Marks Obtain {}</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {display_student.map((item, index) => {
                    return (
                      <tr className={(item.free_seat === '0') ? 'odd gradeX' : 'odd gradeX table-warning'} key={index}>
                        <td>
                          <div className="custom-control custom-control-inline custom-checkbox">
                            <input type="checkbox"
                              checked={item.checked}
                              id={`check_` + index} name="customRadio" className="custom-control-input"
                              onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
                            <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                          </div>
                        </td>
                        <td className="profile-pic">
                          <NavLink className="" to={`student_profile.jsp/${item.admission_number}`}>
                            {item.student_image !== '' ?
                              < img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
                              : (item.gender === 'Boy' ?
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                :
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                            }
                          </NavLink>
                        </td>
                        <td>{item.admission_number}</td>
                        <td><NavLink className="" to={`student_profile.jsp/${item.admission_number}`}>
                          {item.student_name}
                        </NavLink>
                          <br /> S/o  {item.father_name}</td>
                        <td>{item.stu_class}</td>
                        <td>{item.roll_number}</td>
                        <td>{max_marks}</td>
                        <td>
                          {selected_subject !== '' ?
                            <input type="number"
                              value={item.marks_obtain}
                              data-stu-idx={index}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'subject_marks')} />
                            : null}
                        </td>

                        <td className="">
                          <div className="btn-group btn-group-toggle" data-toggle="buttons">
                            {/*<NavLink to={`student_profile.jsp/${item.admission_number}`} className="btn btn-danger btn-sm">
                                <i className="fa fa-eye"></i>
                              </NavLink>
                              <NavLink to={`/edit_student/${item.admission_number}`} className="btn btn-primary btn-sm">
                                Edit
                      </NavLink>*/}
                            <button type="button" className="btn btn-secondary btn-sm"
                              disabled={(item.marks_obtain !== '') ? false : true}
                              onClick={event => this.singleUpdateHandler(event, item.admission_number)}>
                              <i className="fa fa-check"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}

                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer text-right">
            <button type="button"
              onClick={this.updateHandler}
              className="btn btn-primary mr-2">Update</button>
            <NavLink to="#" className="btn btn-danger">Reset</NavLink>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication; 
  const { item: classes } = state.classes;
  const { item: students } = state.students;
  const { item: maxMarks } = state.maxMarks;
  const { item: exams } = state.exams;
  return { user, schools, classes, students, exams, maxMarks };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
  getStudents: studentsAction.getStudents,
  getMaxMarks: maxMarksAction.getMaxMarks,
  getExams: examsAction.getExams,
}

export default connect(mapStateToProps, actionCreators)(withRouter(UpdateMarks));