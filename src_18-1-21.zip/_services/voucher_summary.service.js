// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const voucherSummaryService = {
    getVoucherEntryHandler,
    getLedgerNameHandler,
};

function getVoucherEntryHandler(resdata) {
    // debugger;
    const data = resdata.ldr_data;
    const _all_ledgers = resdata.all_ledgers;
    const vchrid = resdata.vchrid;

    function getLedgerNameHandler(ledger_folio) {
        const fl = _all_ledgers.filter((item) => {
            if (item.ldr_ref_id === ledger_folio) {
                return item;
            }
        })
        return fl[0].ledger_name;
    }

    return new Promise((resolve, reject) => {
        const m_data = data.filter((vItem) => {
            if (vchrid === vItem.r_id) {
                return vItem
            }
        });
        // console.table(m_data);


        let cr_total = 0;
        let dr_total = 0;
        let cr_item = [];
        let dr_item = [];
        let dr_flag = true;

        m_data[0].ledgers.map((xItem) => {
            const _ledger_name = getLedgerNameHandler(xItem['ldr_ref_id']);
            xItem = {
                ldr_ref_id: xItem['ldr_ref_id'],
                tr_amount: xItem['tr_amount'],
                tr_type: xItem['tr_type'],
                under_grp_id: xItem['under_grp_id'],
                under_grp_type: xItem['under_grp_type'],
                ledger_name: _ledger_name,
                // entry_month: "11"
                // isShow: false
                // ledgers: (4) [{…}, {…}, {…}, {…}]
                // narration: "DILKHUSH MEENA S/o BANWARI LAL MEENA Total Due is Rs. 68."
                // r_id: "3183"
                // school_id: "4"
                // school_name: "Jyoti Public Senior Sec. School"
                // session_year_id: "1"
                // tr_date: "2020-11-19"
            };

            if (xItem.tr_type === "CR") {
                cr_item.push(xItem);
                cr_total += Number(xItem.tr_amount)
            } else {
                if (dr_flag) {
                    dr_item.push(xItem);
                    dr_flag = false;
                }
                dr_total += Number(xItem.tr_amount)
            }
            return false
        });

        const dr_ldr = { ...dr_item[0], "tr_amount": dr_total }

        const mItem = {
            "vch_no": vchrid, "credit": cr_item, "debit": dr_ldr, "total_amo": dr_total,
            "narration": m_data[0].narration,
            "vchr_type": m_data[0].vchr_type
        };

        if (m_data.length > 0) {
            resolve({ "data": { single_voucer: mItem } });
        } else {
            reject("Something went wrong");
        }
        // return mItem;
    });

}

// ledger folio to get ledger name
function getLedgerNameHandler(all_ledgers, ledger_folio) {
    const fl = all_ledgers.filter((item) => {
        if (item.ldr_ref_id === ledger_folio) {
            return item;
        }
    })
    return fl[0].ledger_name;
}

