// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const monthlyLessonService = {
    getMonthlyLesson,
    create,
    update,
    delete :_delete
};

function getMonthlyLesson(obj) {
    loadProgressBar();
    const url = USER_URL + 'lessons/read.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'lessons/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'lessons/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}


function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'lessons/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

