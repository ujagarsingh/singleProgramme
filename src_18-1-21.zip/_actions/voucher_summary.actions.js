import { voucherSummaryConstants } from '../_constants';
import { voucherSummaryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const voucherSummaryActions = {
    getVoucherEntryHandler
};

function getVoucherEntryHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        voucherSummaryService.getVoucherEntryHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data.single_voucer));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: voucherSummaryConstants.ACC_SINGLE_VOUCHER_REQUEST } }
    function success(response) { return { type: voucherSummaryConstants.ACC_SINGLE_VOUCHER_SUCCESS, response } }
    function failure(error) { return { type: voucherSummaryConstants.ACC_SINGLE_VOUCHER_FAILURE, error } }
}
  
   