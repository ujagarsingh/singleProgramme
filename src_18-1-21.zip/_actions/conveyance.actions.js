import { conveyanceConstants } from '../_constants';
import { conveyanceService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const conveyanceAction = {
    getConveyance,
    create,
    update,
    delete : _delete
};

function getConveyance() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        conveyanceService.getConveyance()
            .then(
                response => {
                    dispatch(success(response.data.conv_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: conveyanceConstants.CONVEYANCE_REQUEST } }
    function success(response) { return { type: conveyanceConstants.CONVEYANCE_SUCCESS, response } }
    function failure(error) { return { type: conveyanceConstants.CONVEYANCE_FAILURE, error } }
}


function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        conveyanceService.create(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.new_item),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(
                        failure(error.toString()),
                        toastr.error(error.toString())
                    );
                }
            );
    };

    function request() { return { type: conveyanceConstants.CREATE_REQUEST } }
    function success(response) { return { type: conveyanceConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: conveyanceConstants.CREATE_FAILURE, error } }
}


function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        conveyanceService.update(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.new_item),
                        toastr.success(response.data.message));
                },
                error => {
                    dispatch(
                        failure(error.toString()),
                        toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: conveyanceConstants.UPDATE_REQUEST } }
    function success(response) { return { type: conveyanceConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: conveyanceConstants.UPDATE_FAILURE, error } }
}


function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        conveyanceService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message));
                },
                error => {
                    dispatch(
                        failure(error.toString()),
                        toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: conveyanceConstants.DELETE_REQUEST } }
    function success(response) { return { type: conveyanceConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: conveyanceConstants.DELETE_FAILURE, error } }
}
