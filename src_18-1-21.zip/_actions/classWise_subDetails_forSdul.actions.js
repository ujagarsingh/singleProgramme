import { classWiseSubDetailsForSdulConstants } from '../_constants';
import { classWiseSubjectForSdulService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classWiseSubDetailsAction = {
    getSujectDetailsForSdul, 
};

function getSujectDetailsForSdul(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classWiseSubjectForSdulService.getSujectDetailsForSdul(obj)
            .then(
                response => {
                    dispatch(success(response.data.sub_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_REQUEST } }
    function success(response) { return { type: classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: classWiseSubDetailsForSdulConstants.SUBJECT_DETAILS_FAILURE, error } }
}
 