import { holidayConstants } from '../_constants';

export function holiday(state = {}, action) {
  switch (action.type) {
    case holidayConstants.HOLIDAY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case holidayConstants.HOLIDAY_SUCCESS:
      return {
        item: action.response
      };
    case holidayConstants.HOLIDAY_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}