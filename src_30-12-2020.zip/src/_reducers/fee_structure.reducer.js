import { feeStructureConstants } from '../_constants';

export function feeStructure(state = {}, action) {
  switch (action.type) {
    case feeStructureConstants.FEE_STRUCTURE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeStructureConstants.FEE_STRUCTURE_SUCCESS:
      return {
        item: action.response
      };
    case feeStructureConstants.FEE_STRUCTURE_FAILURE:
      return {
        error: action.error
      };



    case feeStructureConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeStructureConstants.CREATE_SUCCESS:
      debugger;
      const _new = action.response;
      let _new_item = {};
      _new.forEach((cls) => {
        _new_item[cls.cat_name] = cls.fee_amount;
      })
      const oldState = [...state.item];
      const new_arr = oldState.map((item) => {
        if (_new[0].class_id === item.class_id) {
          item = { ...item, ..._new_item }
        }
        return item;
      })

      // const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case feeStructureConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case feeStructureConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeStructureConstants.UPDATE_SUCCESS:
      const _update = action.response;
      // debugger;
      let _update_item = {};
      _update.forEach((cls) => {
        _update_item[cls.cat_name] = cls.fee_amount;
      })
      const prevState = [...state.item];

      const updated_arr = prevState.map((item) => {
        if (_update[0].class_id === item.class_id) {
          item = { ...item, ..._update_item }
        }
        return item;
      })

      // const updated_arr = [action.response, ...state.item];
      return {
        item: updated_arr,
        loading: false,
      };
    case feeStructureConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case feeStructureConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeStructureConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.class_id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case feeStructureConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    default:
      return state
  }
}