import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Picky } from 'react-picky';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_ONE = `http://schools.rajpsp.com/api/fee_category/read_one.php`;
// const UPDATE_URL = `http://schools.rajpsp.com/api/fee_category/update.php`;

class EditTypeNTime extends Component {
  state = {
    months_params: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    collect_time: [],
    id: '',
    ledger_id: '',
    cat_name: '',
    cat_type_arr: [
      { 'value': 'multiple', 'name': 'Multiple in Session' },
      { 'value': 'oneinsession', 'name': 'One Time in Session' },
      { 'value': 'oneinstudying', 'name': 'One Time in Studying' }
    ],
    cat_type: null,
    cat_diff: '',
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'cat_type' && event.target.value !== 'multiple') {
      this.setState({
        collect_time: [],
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  timeHandler = (value) => {
    this.setState({
      collect_time: value,
    });
  }

  componentDidMount() {
    const {selected_item} = this.props;
    this.setValueHandler(selected_item);
  }

  setValueHandler(selected_item) {
    const item = selected_item;
    const _time = item.collect_time;
    let _collect_time = [];
    let _slct_sch_inx = '';
    if (_time.includes(',')) {
      _collect_time = item.collect_time.split(",");
    }
    _collect_time = (_collect_time === "") ? [] : _collect_time;

    this.props.schools.filter((elem, index) => {
      if (elem.id === item.school_id) {
        _slct_sch_inx = index;
      }
      return false
    })

    this.setState({
      id: item.id,
      cat_name: item.cat_name,
      ledger_id: item.ledger_id,
      cat_type: item.cat_type,
      cat_diff: item.cat_diff,
      school_id: item.school_id,
      collect_time: _collect_time,
      selected_school_index: _slct_sch_inx
    })
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }
    const form_obj = {
      id: this.state.id,
      cat_name: this.state.cat_name.replace(/ /g, "_"),
      cat_type: this.state.cat_type,
      cat_diff: this.state.cat_diff,
      ledger_id: this.state.ledger_id,
      collect_time: this.state.collect_time
    }
    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);
  };

  render() {
    const { cat_type_arr, school_id, months_params, ledger_id, id, cat_name, cat_diff, cat_type, collect_time, formIsHalfFilledOut } = this.state;
    const { user, schools, selected_item, accLedger } = this.props;
    // console.log(this.props);
     console.log(this.state); 
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Free Category</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Edit Fee Category
            </div>
          <div className="card-body">
            {user && selected_item && schools &&
              <div className="row" key={id}>
                {(user.user_category === "1") &&
                  <div className="col-sm-3">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        defaultValue={school_id}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }
              
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Category Name
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" placeholder="enter category name" className="form-control form-control-sm"
                        required
                        ref='cat_name'
                        defaultValue={cat_name}
                        onChange={event => this.changeHandler(event, 'cat_name')}
                      />
                      <small className="form-text text-muted">Example : Monthly, Sports, Exam, Library</small>
                    </div>
                  </div>
                </div>

                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Same / Different
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='cat_diff'
                        disabled={cat_name !== '' ? false : true}
                        defaultValue={cat_diff}
                        onChange={event => this.changeHandler(event, 'cat_diff')}>
                        <option >Select ...</option>
                        <option value="Same">Same</option>
                        <option value="Different" >Different</option>
                      </select>
                      <small><strong>Note:</strong> Like Convence Fee different for all Student.</small>
                    </div>
                  </div>
                </div>

                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Category Type
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='cat_type'
                        disabled={cat_name !== '' ? false : true}
                        defaultValue={cat_type}
                        onChange={event => this.changeHandler(event, 'cat_type')} >
                        <option value="">Select...</option>
                        {cat_type_arr.map((option, inx) => {
                          return (
                            <option key={inx} value={option.value}>{option.name}</option>
                          )
                        })}
                      </select>
                      <small className="form-text text-muted">How mutch time you are Charge this Category</small>
                    </div>
                  </div>
                </div>



                {(cat_type !== 'oneinstudying') ?
                  <div className="col-sm-3">
                    <div className="form-group">
                      <label className="control-label">Month(s) of Collection
                        <span className="required"> * </span>
                      </label>
                      <div className="form-input">
                        <div className="row">
                          <div className="col-9 pr-0">
                            <Picky
                              value={collect_time}
                              options={months_params}
                              onChange={this.timeHandler}
                              open={false}
                              valueKey="id"
                              labelKey="name"
                              multiple={true}
                              includeSelectAll={true}
                              includeFilter={true}
                              dropdownHeight={200}
                            /> 
                          </div>
                          <div className="col-3 pl-0">
                            <button type="button" className="btn btn-block btn-sm btn-primary"><i className="fas fa-check"></i></button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  : null}
                {accLedger &&
                  <div className="col-sm-2">
                    <div className="form-group">
                      <label className="control-label">Effected Ledger
                        <span className="required"> * </span>
                      </label>
                      <div className="form-input">
                        <select className="form-control form-control-sm"
                          required
                          value={ledger_id}
                          onChange={event => this.changeHandler(event, 'ledger_id')}>
                          <option value="">Select...</option>
                          {accLedger.map((item, index) => {
                            return (
                              (item.under_group === "2") ?
                                <option key={index} value={item.id}>{item.ledger_name}</option>
                                : null
                            )
                          })}
                        </select>
                        <small className="form-text text-danger">Category of related Ledger for showing Effect of Fee.</small>
                      </div>
                    </div>
                  </div>
                }
              </div>
            }
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-primary btn-sm mr-2">Submit</button>
            {/* <NavLink to="/all_type_n_time.jsp" className="btn btn-danger">Cancel</NavLink> */}
            <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning btn-sm">
              Exit </button>
          </div>
        </form>
      </div>
    )
  }
}
export default withRouter(EditTypeNTime);