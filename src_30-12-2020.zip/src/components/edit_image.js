import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { frontGalleryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';
// import { user } from '../_reducers/user.reducer';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_IMAGE = `http://schools.rajpsp.com/api/galleries/images/read_one.php`;
// const GET_GALLERIES = `http://schools.rajpsp.com/api/galleries/gallery/read.php`; 
// const UPDATE_GALLERY = `http://schools.rajpsp.com/api/galleries/images/update.php`;

class EditImage extends Component {
   state = ({
      title: "",
      isActive: true,
      galleries: [],
      formIsHalfFilledOut: false,
      gallery_index: '',
      gallery_id: '',
      gallery_img: "",
      crop: {
         unit: "%",
         width: 50,
         aspect: 16 / 9
      },
      final_size: {
         width: 800,
         height: 450
      }
   })
   // child (my_image.js) component to get image
   onComplete = (data) => {
      this.setState({
         gallery_img: data
      })
   }

   changeHandler = (event, fieldName, isCheckbox) => {
      if ([fieldName] == "gallery_id") {
         // debugger
         const _id = this.props.frontGallery[event.target.value].id;
         const _title = this.props.frontGallery[event.target.value].title;
         this.setState({
            [fieldName]: _id,
            gallery_title: _title,
            gallery_index: event.target.value,
            formIsHalfFilledOut: true
         })
      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            formIsHalfFilledOut: true
         })
      }
   };

   componentDidMount() {
      if (isEmptyObj(this.props.frontGallery)) {
         this.props.getFrontGallery();
      }
   }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getAllGalleriesHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getAllGalleriesHandler() {
   //    loadProgressBar();
   //    axios.get(GET_GALLERIES)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             galleries: getRes,
   //             errorMessages: getRes.message
   //          }, () => { this.getImageDataHandler() });
   //          //console.log(this.props.frontGallery);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   // getImageDataHandler() {
   //    loadProgressBar();
   //    const { match } = this.props;
   //    axios.get(GET_IMAGE + `?id=` + match.params.id)
   //       .then(res => {
   //          const getRes = res.data;

   //          const _galleries = this.props.frontGallery;
   //          let _gallery_index = '';
   //          _galleries.filter((item, inx) => {
   //             if (item.id === getRes.gallery_id) {
   //                _gallery_index = inx;
   //             }
   //          });

   //          this.setState({
   //             id: getRes.id,
   //             title: getRes.img_title,
   //             isActive: getRes.active,
   //             gallery_title: getRes.gallery_title,
   //             gallery_index: _gallery_index,
   //             gallery_id: getRes.gallery_id,
   //             gallery_img: getRes.img_link,
   //             formIsHalfFilledOut: false,
   //          });
   //          //console.log(this.props.frontGallery);
   //       }).catch((error) => {
   //          // error
   //       });
   // }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to submit this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

   submitHandler() {
      let default_obj = '';
      if (this.props.user.user_category === "1") {
         default_obj = { school_id: this.refs.school.value }
      }

      const form_obj = {
         id: this.props.selected_item.id, // this.state.id,
         title: this.refs.title.value, // this.state.title,
         gallery_id: this.props.frontGallery[this.refs.gallery_id.value].id, // this.state.gallery_id,
         active: (this.refs.active.checked) ? "1" : "0", // this.state.active
         gallery_img: this.props.selected_item.img_link, //this.state.gallery_img
      }
      const obj = { ...form_obj, ...default_obj }
      // console.log(JSON.stringify(obj));
      this.props.updateHandlar(obj);
      // this.props.updateHandlar(obj);
      // axios.post(UPDATE_GALLERY, obj)
      //    .then(res => {
      //       const getRes = res.data;
      //       Alert.success(getRes.message, {
      //          position: 'bottom-right',
      //          effect: 'jelly',
      //          timeout: 5000, offset: 40
      //       });
      //    }).catch((error) => {
      //       //this.setState({ errorMessages: error });
      //    })
   }

   getIndexFromImageIdHanglar(id) {
      let _index = '';
      this.props.frontGallery.filter((item, index) => {
         if (item.id === id) {
            _index = index;
            return index;
         }
      })
      return _index;
   }
   render() {
      const { formIsHalfFilledOut, gallery_img, crop, final_size } = this.state;
      const { selected_item, schools, frontGallery, user } = this.props;
      // console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Image(s)</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  {/* {JSON.stringify(selected_item)} */}
                  Edit Gallery
            </div>
               <div className="card-body">
                  {selected_item && schools && frontGallery && user &&
                     <div className="row" key={selected_item.id}>
                        {(user.user_category === "1") &&
                           <div className="col-sm-2">
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    // defaultValue={this.getSchoolIndexHandlar(selected_item.school_id)}
                                    defaultValue={selected_item.school_id}
                                 // onChange={event => this.changeHandler(event, 'school')}
                                 >
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        }
                        <div className="col-sm-4">
                           <div className="form-group row">
                              <label className="control-label col-3">Image</label>
                              <div className="form-input col-9">
                                 {/* <MyImage
                                    //callbackFromParent={this.myCallback}
                                    cropComplete={this.onComplete}
                                    crop={crop}
                                    final_size={final_size}
                                 /> */}
                                 {selected_item.img_link !== '' ?
                                    <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + selected_item.img_link} />
                                    : null}
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Image Title
                              <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" name="title" placeholder="Gallery Title"
                                    className="form-control form-control-sm"
                                    autoComplete="off"
                                    ref="title"
                                    //required
                                    defaultValue={selected_item.img_title}
                                    onChange={event => this.changeHandler(event, 'title')} />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Gallery Title
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    ref="gallery_id"
                                    defaultValue={this.getIndexFromImageIdHanglar(selected_item.gallery_id)}
                                    onChange={event => this.changeHandler(event, 'gallery_id')}>
                                    <option >Select ...</option>
                                    {frontGallery.map((item, index) => {
                                       return (
                                          <option key={index} value={index}>{item.title}</option>
                                       )
                                    })}

                                 </select>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">
                              </label>
                              <div className="form-input">
                                 <div className="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" className="custom-control-input" id="customCheck2"
                                       // onChange={event => this.changeHandler(event, 'isActive', true)}
                                       ref="active"
                                       defaultChecked={(selected_item.active === '1') ? true : false} />
                                    <label className="custom-control-label" htmlFor="customCheck2">
                                       Is Active
                                 </label>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  }
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-primary mr-2">Submit</button>
                  {/* <NavLink to="/all_images.jsp" className="btn btn-danger">Cancel</NavLink> */}
                  <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                     Exit </button>
               </div>
            </form>
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: frontGallery } = state.frontGallery;
   return { user, frontGallery };
}

const actionCreators = {
   getFrontGallery: frontGalleryActions.getFrontGallery,
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditImage));