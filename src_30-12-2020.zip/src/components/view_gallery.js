import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import axios from 'axios';
//import { HOST_URL } from '../includes/api-config';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const GET_GALLERIES = `http://schools.rajpsp.com/api/galleries/gallery/read_gallery.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/events/delete.php`;

class AllGalleries extends Component {
  state = {
    galleries: [],
    formIsHalfFilledOut: false,
  }
  componentDidMount() {
    const token = sessionStorage.getItem('jwt');
    const obj = { "jwt": token };
    this.checkAuthentication(obj);
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getAllGalleriesHandler();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }
  getAllGalleriesHandler() {
    loadProgressBar();
    axios.get(GET_GALLERIES)
      .then(res => {
        const getRes = res.data;
        this.setState({
          galleries: getRes,
          errorMessages: getRes.message
        });
        //console.log(this.state.galleries);
      }).catch((error) => {
        // error
      })
  };
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(event, del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  deleteHandlar = (event, id) => {
    event.preventDefault();
    axios.post(DELETE_URL + '?id=' + id)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        const _galleries = this.state.galleries.filter((item, index) => {
          return item.id !== id
        })
        this.setState({
          galleries: _galleries
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }

  render() {
    const { galleries, formIsHalfFilledOut } = this.state;
    return (
      <div className="page-content">
        <Helmet>
          <title>All Gallery</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">All Gallery</div>
          <div className="form-inline ml-auto filter-panel">
		  <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
            <div className="form-group mt-1">
              <NavLink to="/add_gallery.jsp" className="btn btn-primary btn-sm">
                Add New <i className="fa fa-plus" />
              </NavLink>
            </div>
          </div>
        </div>
		</div>

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Medium </th>
                    <th> Gallery Title</th>
                    <th> Description </th>
                    <th> Status </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                  {galleries.map((item, index) => {
                    return (
                      <tr key={index} >
                        <td>{index + 1}</td>
                        <td>{item.medium}</td>
                        <td>{item.title}</td>
                        <td>{item.description}</td>
                        <td className="text-center"><span className={`badge badge-pill ` + (item.active === '1' ? ' badge-success' : ' badge-danger')} >
                          {item.active === '1' ? 'Active' : 'Not Active'}
                        </span></td>
                        <td className="d-flex">
                          <NavLink to={`edit_gallery.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                            Edit
                          </NavLink>
                          <button className="btn btn-danger btn-sm"
                            value={item.id}
                            onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(AllGalleries);