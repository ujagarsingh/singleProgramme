import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';
import {  withRouter } from 'react-router';
import { Helmet } from "react-helmet";
class NotFound extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Page not Found</title>
        </Helmet>

        <div className="page-bar d-flex">
              <div className="page-title">Wrong Url</div>
            </div>
        <div className="row">
          <div className="col-md-12 col-sm-12">
            <div className="card card-box sfpage-cover">
              <h1 className="text-center">Page Not Found</h1>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(NotFound);