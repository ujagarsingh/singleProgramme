import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { Picky } from 'react-picky';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { conveyanceAction, classesAction, feeDepositedCurrentStudentAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_PTL_CLASSES = `http://schools.rajpsp.com/api/classes/read_portal_classes.php`;
// const READ_URL = `http://schools.rajpsp.com/api/students/read_one.php`;
// const READ_ALL_STU_IDS = `http://schools.rajpsp.com/api/students/read_all_student_ids.php`;
// const READ_CONV_URL = `http://schools.rajpsp.com/api/conveyance/read.php`; 
const UPDATE_STUDENT_URL = `http://schools.rajpsp.com/api/students/update.php`;

class EditStudent extends Component {
  state = {
    current_id: '',
    prev_id: '',
    next_id: '',
    is_prev: false,
    is_next: false,
    group_id: '',
    session_year_id: '',
    user_category: '',
    school_id: '',
    all_students_ids: [],
    s_id: '',
    medium: '',
    caste: '',
    student_name: '',
    father_name: '',
    mother_name: '',
    admission_number: '',
    gender: '',
    dob: '',
    estimate_date: '',
    roll_number: '',
    stu_class: '',
    software_class: '',
    free_seat: '',
    rte_stationary: '',
    is_rte_student: '',
    convence_area: '',
    message_mob: '',
    convence_discount: '',
    monthly_discount: '',
    conveyance: [],
    convence_months: [],
    convence_months_arr: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    student_image: "",
    ptl_classes: [],
    formIsHalfFilledOut: false,
    crop: { unit: "%", width: 70, aspect: 1 },
    final_size: { width: 210, height: 210 }
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  isValidDate(date_val) {
    let d = new Date(date_val);
    // debugger;
    if (d.getTime() === d.getTime()) {
      return d;
    } else {
      return ''
    }
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  checkHandler = (event, fieldName, value) => {
    if (fieldName === 'convence_months') {
      let _convence_month = event;
      this.setState({
        convence_months: _convence_month,
        formIsHalfFilledOut: true
      })
    }
  };

  componentDidMount() {
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.conveyance)) {
      this.props.getConveyance();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }

    this.checkAuthentication();
  }

  checkAuthentication() {
    loadProgressBar();
    const { match } = this.props;
    const current_id = match.params.id;

    this.setState({
      current_id: current_id,
    }, () => {
      this.getStudentDetailHandler();
      this.getAllStudentIdsHandler();
    })


    // loadProgressBar();
    // const { match } = this.props;
    // let current_id = match.params.id;
    // axios.post(VALIDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     // sessionStorage.setItem("user", getRes.data);
    //     console.log(getRes);
    //     if (getRes.data) {
    //       this.setState({
    //         user: getRes.data,
    //         group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //         school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //         user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //         session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //         current_id: current_id
    //       }, () => {
    //         this.getStudentDetailHandler();
    //         this.getConvenceHandler();
    //         this.getAllStudentIdsHandler();
    //         this.getPortalClassesHandler();
    //       })
    //     }
    //   }).catch((error) => {
    //     this.props.history.push('/login.jsp');
    //   })
  }

  setStudentsItsHandler() {
    // debugger
    const _current_id = this.state.current_id;
    const _student_ids = this.state.all_students_ids;
    let _prev_id = '';
    let _next_id = '';
    let _is_prev = false;
    let _is_next = false;
    let _chnage_state = false;
    for (let i = 0; i < _student_ids.length; i++) {

      if (_current_id === _student_ids[i].s_id && (i >= 0 && i < _student_ids.length)) {

        if (i === 0) {
          _prev_id = _student_ids[_student_ids.length - 1].s_id;
        } else {
          _prev_id = _student_ids[i - 1].s_id;
        }

        if (i === _student_ids.length - 1) {
          _next_id = _student_ids[0].s_id;
        } else {
          _next_id = _student_ids[i + 1].s_id;
        }


        _chnage_state = true;
        if (i == 0) {
          _is_prev = true;
        } else if (i == _student_ids.length - 1) {
          _is_next = true;
        }
        break;
      }
    }

    if (_chnage_state) {
      this.setState({
        prev_id: _prev_id,
        next_id: _next_id,
        is_prev: _is_prev,
        is_next: _is_next
      })
    }
  }
  getPrevStudentRecord(e, _id) {
    e.preventDefault();
    this.setState({
      current_id: _id
    }, () => {
      this.getStudentDetailHandler();
      this.setStudentsItsHandler();
      this.changeUrlHandler();
    })
  }
  changeUrlHandler() {
    this.props.history.push(`/edit_student.jsp/${this.state.current_id}`);
  }
  // getPortalClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   console.log(JSON.stringify(obj));
  //   debugger
  //   axios.post(GET_PTL_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         ptl_classes: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  classFilterByMediumHandler() {
    const _medium = this.state.medium;
    const _ptl_classes = this.state.ptl_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      } else { return false }
    })
    // const _sft_classes = this.state.sft_classes.filter((item, inx) => {
    //   if (item.medium === _medium) {
    //     return item
    //   } else { return false }
    // })
    this.setState({
      ptl_classes_medium: _ptl_classes,
      // sft_classes_medium: _sft_classes
    })
  }
  getAllStudentIdsHandler() {
    // debugger
    const selected_students = this.props.students;
    const school_id = this.props.user.school_id;
    const slct_class = this.props.filteredClassesData.slct_cls_name;

    let all_Ids = [];
    selected_students.map((item) => {
      if (!isEmpty(slct_class)) {
        if (item.school_id === school_id && item.stu_class === slct_class) {
          all_Ids = [...all_Ids, { s_id: item.se_id, student_name: item.student_name }];
        }
      } else {
        if(item.school_id === school_id) {
          all_Ids = [...all_Ids, { s_id: item.se_id, student_name: item.student_name }];
        }
      }
    })

    this.setState({
      all_students_ids: all_Ids
    }, () => {
      this.setStudentsItsHandler();
    })
    // console.log(JSON.stringify(obj));
    // debugger
    // axios.post(READ_ALL_STU_IDS, obj)
    //   .then(res => {
    //     const resData = res.data;
    //     // console.log(resData);
    //     this.setState({
    //       all_students_ids: resData,
    //       errorMessages: resData.message
    //     }, () => {
    //       this.setStudentsItsHandler()
    //     });
    //   }).catch((error) => {
    //     // error
    //   });
  }
  // getConvenceHandler() {
  //   loadProgressBar();
  //   axios.get(READ_CONV_URL)
  //     .then(res => {
  //       const conveyance = res.data;
  //       this.setState({
  //         conveyance: conveyance,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.conveyance);
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  dobDate = (dob) => {
    debugger
    this.setState({ dob });
    //this.to.openCalendar();
  };
  getStudentDetailHandler() {
    const _students = this.props.students;
    const _c_id = this.state.current_id;
    //     debugger
    const _current_student = _students.filter((item) => {
      if (item.se_id === _c_id) {
        return item
      }
    })
    this.setState({
      student_info: _current_student[0]
    }, () => {
      const obj = { student_id: _c_id }
      // console.log(obj);
      this.props.getFeeDepositedCurrentStudent(obj);
      this.setStudentsItsHandler();
    })

    // axios.get(READ_URL + '?id=' + stu_id)
    //   .then(res => {
    //     const student = res.data;

    //     // `id`, `roll_number`, `software_class`, `stu_class`, `student_image`, `free_seat`, `rte_stationary`, `convence_area`, `convence_months`, `message_mob`, `monthly_discount`, `convence_discount`, `session_year_id`, `dis_continue`

    //     this.setState({
    //       s_id: student.s_id,
    //       se_id: student.se_id,
    //       school_id: student.school_id,
    //       group_id: student.group_id,
    //       student_name: student.student_name,
    //       father_name: student.father_name,
    //       mother_name: student.mother_name,
    //       admission_number: student.admission_number,
    //       gender: student.gender,
    //       roll_number: student.roll_number,
    //       student_image: student.student_image,
    //       free_seat: student.free_seat,
    //       rte_stationary: student.rte_stationary,
    //       is_rte_student: student.is_rte_student,
    //       convence_area: student.convence_area,
    //       convence_months: student.convence_months,
    //       stu_class: student.stu_class,
    //       software_class: student.software_class,
    //       message_mob: student.message_mob,
    //       convence_discount: student.convence_discount,
    //       monthly_discount: student.monthly_discount,
    //       medium: student.medium,
    //       s_medium: student.s_medium,
    //       estimate_date: this.isValidDate(student.estimate_date),
    //       session_year_id: student.session_year_id,
    //       dob: this.isValidDate(student.dob),
    //       caste: student.caste,
    //       errorMessages: student.message
    //     })
    //   }).catch((error) => {
    //     // error
    //   });
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler = e => {

    const obj = {
      myObj: [{
        id: this.state.s_id,
        student_name: this.state.student_name,
        stu_class: this.state.stu_class,
        father_name: this.state.father_name,
        mother_name: this.state.mother_name,
        medium: this.state.medium,
        admission_number: this.state.admission_number,
        roll_number: this.state.roll_number,
        student_image: this.state.student_image,
        software_class: this.state.software_class,
        free_seat: this.state.free_seat,
        rte_stationary: this.state.rte_stationary,
        convence_area: this.state.convence_area,
        convence_months: this.state.convence_months,
        convence_discount: this.state.convence_discount,
        monthly_discount: this.state.monthly_discount,
        message_mob: this.state.message_mob,
        dob: this.state.dob,
        gender: this.state.gender,
        caste: this.state.caste,
        is_rte_student: this.state.is_rte_student
      }]
    };
    console.log(JSON.stringify(obj));
    debugger
    axios.post(UPDATE_STUDENT_URL, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          // update_student: [],
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      student_image: data
    })
  }
  render() {
    const { student_info, free_seat, is_rte_student, rte_stationary, roll_number, convence_area, convence_discount,
      convence_months_arr, convence_months, admission_number, father_name, mother_name, student_name, stu_class,
      dob, caste, ptl_classes, monthly_discount, message_mob, crop, final_size, student_image, medium,
      formIsHalfFilledOut, gender, prev_id, next_id, is_prev, is_next } = this.state;
    const { user, conveyance, classes, students } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Student</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Edit Student</div>
        </div>
        {student_info && user && conveyance && classes && students &&
          <form className="card card-box sfpage-cover" onSubmit={this.confirmBoxSubmit}>
            <div className="card-body p-2">
              <div className="table-scrollable">
                <div className="col-sm-12">
                  <div className="form-horizontal">
                    <div className="form-body">
                      <div className="row">
                        <div className="col-md-2">
                          <div className="form-groupmb-3">
                            <label className="control-label d-block pt-0 pb-2">Student Image</label>
                            <div className="col-md-12_">
                              <MyImage
                                //callbackFromParent={this.myCallback}
                                cropComplete={this.onComplete}
                                crop={crop}
                                final_size={final_size}
                              />
                              {student_info.student_image !== '' ?
                                < img src={`${process.env.PUBLIC_URL}` + student_info.student_image} className="img-thumbnail" alt={student_info.student_name} />
                                : (gender === 'Boy' ?
                                  <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                  :
                                  <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                              }
                            </div>
                          </div>
                        </div>

                        <div className="col-md-5 mt-4">

                          <div className="form-group row">
                            <label className="control-label col-5">Enr. Number :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Admission Number"
                                className="form-control form-control-sm"
                                value={student_info.admission_number}
                                onChange={event => this.changeHandler(event, `admission_number`)} />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Student Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Student Name"
                                className="form-control form-control-sm"
                                value={student_info.student_name}
                                onChange={event => this.changeHandler(event, `student_name`)} />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Class :</label>
                            <div className="col-7">
                              {/* <input type="text" placeholder="stu_class"
                              className="form-control form-control-sm"
                              value={student_info.stu_class}
                              onChange={event => this.changeHandler(event, `stu_class`)} /> */}
                              <select className="form-control form-control-sm"
                                value={student_info.stu_class}
                                onChange={event => this.changeHandler(event, 'stu_class')}>
                                <option value>Select...</option>
                                {ptl_classes.map((option, index) => {
                                  return (
                                    <option key={index}>{option.stu_class}</option>
                                  )
                                })}
                              </select>
                              <span className="text-danger">Not for Promote Student.</span>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Father Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Father Name"
                                className="form-control form-control-sm"
                                value={student_info.father_name}
                                onChange={event => this.changeHandler(event, `father_name`)} />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Mother Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Mother Name"
                                className="form-control form-control-sm"
                                value={student_info.mother_name}
                                onChange={event => this.changeHandler(event, `mother_name`)} />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Medium :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Medium"
                                className="form-control form-control-sm"
                                disabled={true}
                                value={student_info.medium}
                                onChange={event => this.changeHandler(event, `medium`)} />
                            </div>
                          </div>


                          <div className="form-group row">
                            <label className="control-label col-5">DOB</label>
                            <div className="col-7">
                              <DatePicker
                                onChange={this.dobDate}
                                value={this.isValidDate(student_info.dob)}
                                showLeadingZeroes={true}
                              //minDate={new Date()}
                              />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Gender</label>
                            <div className="col-7">
                              {/* <input type="text" placeholder="Gender"
                              className="form-control form-control-sm"
                              value={student_info.gender}
                              onChange={event => this.changeHandler(event, `gender`)} /> */}
                              <select className="form-control form-control-sm"
                                required
                                value={student_info.gender}
                                onChange={event => this.changeHandler(event, 'gender')}>
                                <option value="">Select ...</option>
                                <option>Boy</option>
                                <option>Girl</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Caste</label>
                            <div className="col-7">
                              <input type="text" placeholder="Caste"
                                className="form-control form-control-sm"
                                value={student_info.caste}
                                onChange={event => this.changeHandler(event, `caste`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Is RTE Student</label>
                            <div className="col-7">
                              <input type="text" placeholder="is_rte_student"
                                className="form-control form-control-sm"
                                value={student_info.is_rte_student}
                                onChange={event => this.changeHandler(event, `is_rte_student`)} />
                            </div>
                          </div>

                        </div>
                        <div className="col-md-5 mt-4">

                          <div className="form-group row">
                            <label className="control-label col-5">Student Type</label>
                            <div className="col-7">
                              <div className="custom-control custom-checkbox mt-2 mb-2">
                                <input type="checkbox" className="custom-control-input" id={`switch_`}
                                  checked={(student_info.free_seat === '1' ? true : false)}
                                  onChange={event => this.changeHandler(event, `free_seat`, true)} />
                                <label className={'custom-control-label label label-sm ' + ((student_info.free_seat === '0') ? 'label-info' :
                                  'label-danger')} htmlFor={`switch_`}>
                                  {(student_info.free_seat === '0') ? 'Paid' : 'Free'}</label>
                              </div>
                            </div>
                          </div>

                          {student_info.is_rte_student === 'YES' ?
                            <div className="form-group row">
                              <label className="control-label col-5">RTE Stationary</label>
                              <div className="col-7">
                                <div className="custom-control custom-checkbox">
                                  <input type="checkbox" className="custom-control-input" id={`stationary_`}
                                    checked={(student_info.rte_stationary === '1' ? true : false)}
                                    onChange={event => this.changeHandler(event, `rte_stationary`, true)} />
                                  <label className={"custom-control-label label label-sm " +
                                    ((student_info.rte_stationary === '0') ? 'label-warning' :
                                      'label-sucess')} htmlFor={`stationary_`}>
                                    {(student_info.rte_stationary === '0') ? 'Pending' : 'Done'}</label>
                                </div>
                              </div>
                            </div>
                            : null}
                          <div className="form-group row">
                            <label className="control-label col-5"> Roll No </label>
                            <div className="col-7">
                              <input type="number" name="No" placeholder="Roll  No"
                                className="form-control form-control-sm"
                                value={student_info.roll_number}
                                onChange={event => this.changeHandler(event, `roll_number`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence </label>
                            <div className="col-md-7">
                              <select className="form-control form-control-sm" name="proff"
                                value={student_info.convence_area}
                                onChange={event => this.changeHandler(event, `convence_area`)} >
                                <option value>Select...</option>
                                {conveyance.map((option, index) => {
                                  return (
                                    <option key={index}
                                      value={option.stoppage_name}>{option.stoppage_name} [{option.stoppage_amo}] </option>
                                  )
                                })}
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence Months </label>
                            <div className="col-md-7">
                              <div className="row">
                                <Picky
                                  disabled={(student_info.convence_area === '' ? true : false)}
                                  className="col-9 pr-0"
                                  value={student_info.convence_months}
                                  options={convence_months_arr}
                                  onChange={event => this.checkHandler(event, `convence_months`)}
                                  open={false}
                                  valueKey="id"
                                  labelKey="name"
                                  multiple={true}
                                  includeSelectAll={true}
                                  includeFilter={true}
                                  dropdownHeight={200}
                                />
                                <div className="col-3 pl-0">
                                  <button type="button" className="btn btn-block btn-primary"><i className="fas fa-check"></i></button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Mobile No. </label>
                            <div className="col-md-7">
                              <input name="message_mob" type="number" placeholder="mobile number"
                                className="form-control form-control-sm"
                                value={student_info.message_mob}
                                onChange={event => this.changeHandler(event, `message_mob`)} />
                              <span className="text-danger">For Message</span>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence Discount  </label>
                            <div className="col-md-7">
                              <div className="input-group">
                                <input name="convence_discount" type="number" placeholder="Discount in Convence payment"
                                  className="form-control form-control-sm"
                                  value={student_info.convence_discount}
                                  onChange={event => this.changeHandler(event, `convence_discount`)} />
                                <div className="input-group-append">
                                  <span className="input-group-text  pt-1 pb-1">%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Monthly Discount </label>
                            <div className="col-md-7">
                              <div className="input-group">
                                <input name="monthly_discount" type="number" placeholder="Discount in Monthly Payment"
                                  className="form-control form-control-sm"
                                  value={student_info.monthly_discount}
                                  onChange={event => this.changeHandler(event, `monthly_discount`)} />
                                <div className="input-group-append">
                                  <span className="input-group-text pt-1 pb-1">%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer d-flex p-2">
              <button type="button"
                onClick={event => this.getPrevStudentRecord(event, prev_id)}
                disabled={is_prev}
                className="btn btn-primary text-white">
                <i className="fa fa-angle-left"></i>
              </button>
              <button type="button"
                onClick={event => this.getPrevStudentRecord(event, next_id)}
                disabled={is_next}
                className="btn btn-primary ml-3 text-white">
                <i className="fa fa-angle-right"></i>
              </button>
              <button type="submit"
                // disabled={!formIsHalfFilledOut}
                className="btn btn-primary mr-2 ml-auto">Submit</button>
              <NavLink to="/all_students.jsp" className="btn btn-danger">All Student</NavLink>
            </div>
          </form>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: conveyance } = state.conveyance;
  const { item: classes } = state.classes;
  const { item: students } = state.students;
  const filteredClassesData = state.filteredClassesData;
  return { user, conveyance, classes, students, filteredClassesData };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
  getConveyance: conveyanceAction.getConveyance,
  getFeeDepositedCurrentStudent: feeDepositedCurrentStudentAction.getFeeDepositedCurrentStudent,
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditStudent));