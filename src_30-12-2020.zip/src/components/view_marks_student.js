import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { connect } from 'react-redux';
// import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import {
  schoolsAction, classesAction, examsAction, examsTypeAction,
  singleClassCategoryExamsAction,
  examCategoryClassExamAction, singleStudentSubjectExamsMarksobtnAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import SingleReportCard from '../includes/single_report_card'
import AddEditSingleReportCard from '../includes/add_edit_single_report_card'


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_CLASS_EXAM_DETAIL_URL = `http://schools.rajpsp.com/api/exam/one_class_category_exams.php`;
// const READ_URL = `http://schools.rajpsp.com/api/exam/one_student_subject_exams_marksobtn.php`;
// const READ_SCHOOL_URL = `http://schools.rajpsp.com/api/school/read_one.php`;

class ViewMarksStudent extends Component {
  state = {
    id: '',
    school_id: '',
    sch_name: '',
    sch_address: '',
    student: '',
    medium: '',
    updated_exam_detail: {},
    selected_sheet_type: 'Marksheet',
    selected_exam: ["F.A.-1", "F.A.-2", "F.A.-3", "S.A.-1", "S.A.-2"],
    admission_number: '',
    total_max_marks: 0,
    total_obt_marks: 0,
    total_avg_marks: 0,
    student_result: null,
    student_grade: null,
    exam_detail: '', // report card titles
    formIsHalfFilledOut: false,
    addEditMode: true
  }


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.exams)) {
      this.props.getExams();
    }
    if (isEmptyObj(this.props.examsType)) {
      this.props.getExamsType();
    }
    if (isEmptyObj(this.props.examCategoryClassExam)) {
      this.props.getExamCategoryClassExam();
    }
    // if (isEmptyObj(this.props.marksOfaClass)) {
    //   this.props.getMarksOfaClass();
    // }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const all_examcate = this.props.examCategoryClassExam;
      if (_filter && all_examcate) {
        // this.filterBySchoolHandler();
        this.getSingleStudentHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }


  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   const { match } = this.props;
  //   // axios.post(VALIDATE_URL, obj)
  //   //   .then(res => {
  //   //     const getRes = res.data;
  //   //     // sessionStorage.setItem("user", getRes.data);
  //   //     console.log(getRes);
  //   //     if (getRes.data) {
  //   //       this.setState({
  //   //         user: getRes.data,
  //   //         group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //   //         school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //   //         user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //   //         session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //   //         id: match.params.id,
  //   //         school_id: match.params.school_id
  //   //       }, () => {
  //   //         this.getSingleStudentHandler();
  //   //       })
  //   //     }
  //   //   }).catch((error) => {
  //   //     this.props.history.push('/login.jsp');
  //   //   })
  // }


  getSingleStudentHandler() {
    //get student record 
    const { id, class_id } = this.props.match.params;
    this.props.getSingleCCE({ "class_id": class_id });
    this.props.getSingleSSEM({ "stu_id": id, "class_id": class_id });

    this.setState({
      // student: student[0],
      // admission_number: student[0].admission_number,
      // subject: student[0].subject,
      // medium: student[0].medium,
      class_id: class_id,
      stu_id: id,
      // exam_detail: _exam_cate[0].exam_cate
    });

    // const obj = {
    //   id: this.state.id,
    //   group_id: this.state.group_id,
    //   school_id: this.state.school_id,
    // }
    // console.log(JSON.stringify(obj))
    // axios.post(READ_URL, obj)
    //   .then(res => {
    //     const student = res.data;
    //     this.setState({
    //       student: student,
    //       admission_number: student.admission_number,
    //       subject: student.subject,
    //       medium: student.medium,
    //       class_id: student.class_id,
    //       errorMessages: res.data.message
    //     }, () => {
    //       this.getClassWiseExamDetailsHandler(student.class_id);
    //       //this.calculateMarksForReportCardHandler();
    //       this.getSchoolHandler(student.school_id);
    //     });
    //     // console.log(JSON.stringify(this.state.student));
    //   })
    //   .catch((error) => {
    //     // error
    //   });
  };
  // getClassWiseExamDetailsHandler(class_id) {
  //   const obj = {
  //     class_id: class_id,
  //     medium: this.state.medium,
  //     school_id: this.state.school_id,
  //     group_id: this.state.group_id
  //   }
  //   loadProgressBar();
  //   console.log(JSON.stringify(obj));

  //   // axios.post(READ_CLASS_EXAM_DETAIL_URL, obj)
  //   //   .then(res => {
  //   //     const examDetail = res.data;
  //   //     this.setState({
  //   //       exam_detail: examDetail,
  //   //       errorMessages: res.data.message
  //   //     });
  //   //   })
  //   //   .catch((error) => {
  //   //     // error
  //   //   });
  // }
  // getSchoolHandler(id) {
  //   // read school info
  //   loadProgressBar();
  //   // axios.get(READ_SCHOOL_URL + '?id=' + id)
  //   //   .then(res => {
  //   //     const getRes = res.data;
  //   //     this.setState({
  //   //       //id: getRes.id,
  //   //       sch_name: getRes.sch_name,
  //   //       sch_address: getRes.sch_address,
  //   //       errorMessages: getRes.message
  //   //     });
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })
  // }
  toggleAddEditModeHandler(event) {
    event.preventDefault();
    this.setState({
      addEditMode: !this.state.addEditMode
    })
  }
  submitHandler(event){
    event.preventDefault();
    alert('working...........................');
    // old method in add_marks.js
    // 
  }
  render() {
    const { stu_id, class_id, sch_name, selected_exam, selected_sheet_type,
      sch_address, formIsHalfFilledOut, addEditMode } = this.state;
    const { examCategoryClassExam, singleStudentSubjectExamsMarksobtn, singleClassCategoryExams } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content page-wrapper print">
        <Helmet>
          <title>Marks of Student</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Student Report Card</div>
        </div>
        {examCategoryClassExam && singleStudentSubjectExamsMarksobtn && singleClassCategoryExams &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="col-md-12">
                  {addEditMode ?
                    <SingleReportCard
                      key={1}
                      selected_sheet_type={selected_sheet_type}
                      sch_name={sch_name}
                      sch_address={sch_address}
                      // updated_exam_detail={exam_detail}
                      updated_exam_detail={{ "exam_type": singleClassCategoryExams }}
                      selected_exam={selected_exam}
                      index={1}
                      // item={student}
                      item={singleStudentSubjectExamsMarksobtn}
                    />
                    :
                    <AddEditSingleReportCard
                      key={1}
                      selected_sheet_type={selected_sheet_type}
                      sch_name={sch_name}
                      sch_address={sch_address}
                      // updated_exam_detail={exam_detail}
                      updated_exam_detail={{ "exam_type": singleClassCategoryExams }}
                      selected_exam={selected_exam}
                      index={1}
                      // item={student}
                      item={singleStudentSubjectExamsMarksobtn}
                    />
                  }

                </div>
              </div>
            </div>
            <div className="card-footer d-flex">
              {/* <NavLink to={`/add_marks_student.jsp/${stu_id}/${class_id}`} className="btn btn-primary ml-auto mr-2 ">
                Add / Edit
                </NavLink> */}
              {addEditMode ? 
                <button className="btn btn-secondary" type="button"> <span><i className="fa fa-print" /> Print</span> </button>
                : 
                null 
              }
              <button className="btn btn-warning mr-2  ml-auto" type="button"
                onClick={(event) => this.toggleAddEditModeHandler(event)}>
                <span><i className="fa fa-edit" /> {addEditMode ? "Edit Mode" : "Normal Mode"}</span>
              </button>
              {addEditMode ? 
                <button className="btn btn-primary mr-2" type="button"
                onClick={(event) => this.submitHandler(event)}>
                <span><i className="fa fa-save" />Save</span>
              </button>
              : null}
              <NavLink
                to={`/all_marks.jsp`}
                className="btn btn-danger">Back</NavLink>
            </div>
          </div>
        }
      </div>
    )
  }
}
// marksOfaClass
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: exams } = state.exams;
  const { item: examsType } = state.examsType;
  const { item: examCategoryClassExam } = state.examCategoryClassExam;
  const { item: singleClassCategoryExams } = state.singleClassCategoryExams;
  const { item: singleStudentSubjectExamsMarksobtn } = state.singleStudentSubjectExamsMarksobtn;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, classes, exams, examsType, examCategoryClassExam,
    singleStudentSubjectExamsMarksobtn, singleClassCategoryExams,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getExams: examsAction.getExams,
  getExamsType: examsTypeAction.getExamsType,
  getExamCategoryClassExam: examCategoryClassExamAction.getExamCategoryClassExam,
  getSingleCCE: singleClassCategoryExamsAction.getSingleCCE,
  getSingleSSEM: singleStudentSubjectExamsMarksobtnAction.getSingleSSEM
}
export default connect(mapStateToProps, actionCreators)(withRouter(ViewMarksStudent));