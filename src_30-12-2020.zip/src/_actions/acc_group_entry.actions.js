import { accGroupEntryConstants } from '../_constants';
import { accGroupEntryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accGroupEntryActions = {
    getAccGroupEntry,
    getAccGroupEntryByFolio,
};

function getAccGroupEntry() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupEntryService.getAccGroupEntry()
            .then(
                response => {
                    dispatch(success(response.data.acc_group_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupEntryConstants.ACC_GROUP_ENTRY_REQUEST } }
    function success(response) { return { type: accGroupEntryConstants.ACC_GROUP_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accGroupEntryConstants.ACC_GROUP_ENTRY_FAILURE, error } }
}
   

function getAccGroupEntryByFolio() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupEntryService.getAccGroupEntryByFolio()
            .then(
                response => {
                    dispatch(success(response.data.acc_group_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupEntryConstants.ACC_GROUP_BYFOLIO_REQUEST } }
    function success(response) { return { type: accGroupEntryConstants.ACC_GROUP_BYFOLIO_SUCCESS, response } }
    function failure(error) { return { type: accGroupEntryConstants.ACC_GROUP_BYFOLIO_FAILURE, error } }
}
   