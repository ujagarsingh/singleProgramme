

export {
    isEmpty,
    isEmptyObj,
    nuberInWords,
    showVoucherEntries,
    getClosingBlance,
    getRealACCData,
    balanceSheetHandler,
    singleGroupSummaryHandler,
    ledgerSummaryofFinancialYearHandler,
    ledgerSummaryofMonthHandler,
    voucherEntryHandler,
    isNumber,
};



function isNumber(evt) {
    if (evt.which != 8 && evt.which != 0 && evt.which < 48 || evt.which > 57)
    {
        evt.preventDefault();
    }
}

function isEmpty(val) {
    const result = (val === undefined || val == null || val.length <= 0) ? true : false;
    return result
}

function isEmptyObj(obj) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key))
            return false;
    }
    return true;
}

function nuberInWords(price) {
    var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
        dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
        tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
        handle_tens = function (dgt, prevDgt) {
            return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
        },
        handle_utlc = function (dgt, nxtDgt, denom) {
            return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
        };

    var str = "",
        digitIdx = 0,
        digit = 0,
        nxtDigit = 0,
        words = [];
    if (price += "", isNaN(parseInt(price))) str = "";
    else if (parseInt(price) > 0 && price.length <= 10) {
        for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--) switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
            case 0:
                words.push(handle_utlc(digit, nxtDigit, ""));
                break;
            case 1:
                words.push(handle_tens(digit, price[digitIdx + 1]));
                break;
            case 2:
                words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
                break;
            case 3:
                words.push(handle_utlc(digit, nxtDigit, "Thousand"));
                break;
            case 4:
                words.push(handle_tens(digit, price[digitIdx + 1]));
                break;
            case 5:
                words.push(handle_utlc(digit, nxtDigit, "Lakh"));
                break;
            case 6:
                words.push(handle_tens(digit, price[digitIdx + 1]));
                break;
            case 7:
                words.push(handle_utlc(digit, nxtDigit, "Crore"));
                break;
            case 8:
                words.push(handle_tens(digit, price[digitIdx + 1]));
                break;
            case 9:
                words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "")
        }
        str = words.reverse().join("")
    } else str = "";
    return str

}

function showVoucherEntries(vchr_obj) {
    debugger
    let _all_dr = [];
    let _all_cr = [];
    let _total_dr = 0;
    let _total_cr = 0;

    vchr_obj.map((vItem) => {
        if (vItem.tr_type === 'DR') {
            _all_dr = [..._all_dr, vItem];
            _total_dr += Number(vItem.tr_amount);
        } else {
            _all_cr = [..._all_cr, vItem];
            _total_cr += Number(vItem.tr_amount);
        }
    });

    let vchr_table = `<thead>
         <tr>
            <th></th>
            <th className="text-center">Debit</th>
            <th className="text-center">Credit</th>
         </tr>
      </thead>
      <tfoot className="bg-light">
         <tr>
            <th className="text-right">TOTAL</th>
            <th className="text-right">${_total_dr}/-</th>
            <th className="text-right">${_total_cr}/-</th>
         </tr>
      </tfoot>
      <tbody>`;

    vchr_table += _all_dr.map((dr_item, dr_inx) => {
        return (
            `<tr>
                  <td>
                     <span className="ml-0"> ${dr_item.ledger_folio} <b>Ujagar Singh s/o Shri Birdi Chand Meena </b> [ Class : 10nth ] DR </span>
                  </td>
                  <td className="text-right">${dr_item.tr_amount}/-</td>
                  <td className="text-right"></td>
               </tr>`
        )
    });

    vchr_table += _all_cr.map((cr_item, cr_inx) => {
        return (
            `<tr>
                  <td>
                     <span className="ml-4"><i>To,</i> ${cr_item.ledger_folio}</span>
                  </td>
                  <td className="text-right"></td>
                  <td className="text-right">${cr_item.tr_amount}/-</td>
               </tr>`
        )
    });

    vchr_table += `<tr>
            <td>
               <div className="">
                  <p className="m-0"><b>Naretion : </b> <br /> this is the area of Naretion..</p>
               </div>
            </td>
            <td className="text-right"></td>
            <td className="text-right"></td>
         </tr>
      </tbody>`;
    // <table className="table table-sm table-light table-voucher m-0">

    var t = document.createElement("TABLE");
    t.innerHTML = vchr_table;

    return t;
}

function getClosingBlance(oldObj, newObj) {
    let _amo = 0;
    let _type = '';
    const _old_cl_bal = Number(oldObj.cl_balance);
    const _new_tr_amo = Number(newObj.tr_amount);
    if (oldObj.cl_type === newObj.tr_type) {
        _amo = _old_cl_bal + _new_tr_amo;
        _type = oldObj.cl_type;
    } else {
        _amo = Math.abs(_old_cl_bal - _new_tr_amo);
        _type = (_old_cl_bal > _new_tr_amo) ? oldObj.cl_type : newObj.tr_type;
    }
    let obj = {
        type: _type,
        amount: _amo
    }
    return obj;
}

function getRealACCData(res_data, res_students) {
    let ldr_data = [];
    res_data.acc_ledger_entry.map((ldrs) => {
        let ldr_with_details = [];
        const _newLdr = ldrs.ledgers.map((kItem) => {
            const lr_ref = kItem.ldr_ref_id.split("_");

            switch (lr_ref[1]) {
                case 'STU':
                    // Students
                    const ldr_info = res_students.filter((sItem) => {
                        if (lr_ref[0] === sItem.se_id && lr_ref[2] === sItem.school_id) {
                            return sItem;
                        }
                    })
                    kItem = { ...kItem, "ldr_name": ldr_info[0].student_name + ' S/o ' + ldr_info[0].father_name + ' [Enroll : ' + ldr_info[0].admission_number + ']' + ' [Class : ' + ldr_info[0].stu_class + ']' }
                    break;
                case 'STF':
                    // Staff

                    break;
                default:
                    // Other Ledgers
                    const ldr_info1 = res_students.filter((sItem) => {
                        if (lr_ref[0] === sItem.se_id && lr_ref[2] === sItem.school_id) {
                            return sItem;
                        }
                    })
                    kItem = { ...kItem, "ldr_name": ldr_info1[0].ledger_name }
            }
            return kItem;
        })
        ldr_data = [...ldr_data, ..._newLdr];
    });
    return ldr_data;
};
// console.log(ldr_data);

// Balance sheet (current Libilities and Assets)
function balanceSheetHandler(data, allGrp) {
    const _allGRP = allGrp.map((gItem) => {
        let cr_amo = 0;
        let dr_amo = 0;
        data.map((vItem) => {
            if (gItem.id == vItem.under_grp_id) {
                if (vItem.tr_type === "CR") {
                    cr_amo += Number(vItem.tr_amount)
                } else {
                    dr_amo += Number(vItem.tr_amount)
                }
            }
            // return false;
        })
        gItem = { ...gItem, "final_balance": cr_amo - dr_amo }
        return gItem
    });

    let group_with_subgroup = [];
    _allGRP.filter((sub_grp) => {
        if (sub_grp.under_gp_id === null) {
            let _sub_total = 0;
            const _grp = _allGRP.filter((grp) => {
                if (sub_grp.id === grp.under_gp_id) {
                    _sub_total += Math.abs(grp.final_balance);
                    return grp
                }
            })
            sub_grp = { ...sub_grp, "sub_group": _grp, "final_balance": _sub_total }
            group_with_subgroup.push(sub_grp);
        }
    })
    return group_with_subgroup;
}
// let balance_res = balanceSheetHandler(ldr_data, allGrp);
// allGrp => All Groups, ldr_data => all ledger data
// console.log(balance_res);

// Group Summay with detbit and credit
function singleGroupSummaryHandler(data, grpId) {

    let _ldr_ids = [];
    const f_data = data.filter((vItem) => {
        if (grpId == vItem.under_grp_id) {
            if (!_ldr_ids.includes(vItem.ldr_ref_id)) {
                _ldr_ids.push(vItem.ldr_ref_id);
            }
            return vItem
        }
    })
    const _new_obj = _ldr_ids.map((eitem) => {
        let cr_amo = 0;
        let dr_amo = 0;
        const _data = f_data.map((vItem) => {
            if (eitem == vItem.ldr_ref_id) {
                if (vItem.tr_type === "CR") {
                    cr_amo += Number(vItem.tr_amount)
                } else {
                    dr_amo += Number(vItem.tr_amount)
                }
            }
            return false;
        })
        // return eitem = {"item_id" : eitem, "cr_amo" : cr_amo, "dr_amo" : dr_amo, "final_balance" : Math.abs(cr_amo - dr_amo)}
        return eitem = { "item_id": eitem, "cr_amo": cr_amo, "dr_amo": dr_amo, }
    })
    return _new_obj;
}
// let summay_res = singleGroupSummaryHandler(ldr_data, '10')
// ldr_data => all ledger data, 10 => group_id, 
// console.log(summay_res);

// console.log(ldr_data);
// Group Summay with detbit and credit
function ledgerSummaryofFinancialYearHandler(data, grpId) {
    let monly_obj = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
    const m_data = data.filter((vItem) => {
        if (grpId == vItem.ldr_ref_id) {
            return vItem
        }
    })
    const _new_obj = monly_obj.map((mitem) => {
        let cr_amo = 0;
        let dr_amo = 0;
        const _data = m_data.map((vItem) => {
            if (mitem == vItem.entry_month) {
                if (vItem.tr_type === "CR") {
                    cr_amo += Number(vItem.tr_amount)
                } else {
                    dr_amo += Number(vItem.tr_amount)
                }
            }
            return false;
        })
        return mitem = { "month_id": mitem, "cr_amo": cr_amo, "dr_amo": dr_amo, "cl_blnc": Math.abs(cr_amo - dr_amo), "blnc_type": (cr_amo <= dr_amo) ? "Dr" : "Cr" }
    })
    return _new_obj;
}
// let group_summary = ledgerSummaryofFinancialYearHandler(ldr_data, '185_STU_4')
// console.log(group_summary);

// Group Summay with detbit and credit
function ledgerSummaryofMonthHandler(data, grpId, monthId) {
    let monly_obj = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
    const m_data = data.filter((vItem) => {
        if (grpId == vItem.ledger_folio) {
            return vItem
        }
    })
    let cr_total = 0;
    let dr_total = 0;
    const _data = m_data.map((vItem) => {
        let cr_amo = 0;
        let dr_amo = 0;
        if (monthId == vItem.entry_month) {
            if (vItem.tr_type === "CR") {
                cr_amo = Number(vItem.tr_amount);
                cr_total += Number(vItem.tr_amount);
            } else {
                dr_amo = Number(vItem.tr_amount);
                dr_total += Number(vItem.tr_amount);
            }
        }
        return vItem = {
            "ldr_ref_id": vItem.ldr_ref_id,
            "tr_data": vItem.server_date_time,
            "vch_type": "Journal",
            "vchr_ref_id": vItem.vchr_ref_id,
            "cr_amo": cr_amo,
            "dr_amo": dr_amo,
        };
    })

    let f_data = { "data": _data, "cl_blnc": Math.abs(cr_total - dr_total), "blnc_type": (cr_total <= dr_total) ? "Dr" : "Cr" };

    return f_data;
}
// let ldr_summary_a_month = ledgerSummaryofMonthHandler(ldr_data, '185_STU_4', '7')
// ldr_data => all ledger data, 7 => month_id, 185_STU_4 => "ledger ref id", 
// console.log(ldr_summary_a_month);

// console.log(ldr_data);
function voucherEntryHandler(data, grpId, monthId) {
    const m_data = data.filter((vItem) => {
        if (monthId == vItem.vchr_ref_id) {
            return vItem
        }
    });
    // console.table(m_data);

    let cr_total = 0;
    let dr_total = 0;
    let cr_item = [];
    let dr_item = [];
    let dr_flag = true;

    m_data.map((xItem) => {
        xItem = {
            ldr_ref_id: xItem['ldr_ref_id'],
            tr_amount: xItem['tr_amount'],
            tr_type: xItem['tr_type'],
            under_grp_id: xItem['under_grp_id'],
            under_grp_type: xItem['under_grp_type'],
            // cost_center: xItem['cost_center'],
            // entry_month: xItem['entry_month'],
            // l_id: xItem['l_id'],
            // ledger_folio: xItem['ledger_folio'],
            // school_id: xItem['school_id'],
            // server_date_time: xItem['server_date_time'],
            // session_year_id: xItem['session_year_id'],
            // vchr_ref_id: xItem['vchr_ref_id'],
        }
        if (xItem.tr_type === "CR") {
            cr_item.push(xItem);
            cr_total += Number(xItem.tr_amount);
        } else {
            if (dr_flag) {
                dr_item.push(xItem);
                dr_flag = false;
            }
            dr_total += Number(xItem.tr_amount)
        }
    });

    const dr_ldr = { ...dr_item[0], "tr_amount": dr_total }

    const mItem = { "vch_no": monthId, "credit": cr_item, "debit": dr_ldr, "total_amo": dr_total };
    return mItem;
}
// let voucher_entry = voucherEntryHandler(ldr_data, '185_STU_4', '3164')
// ldr_data => all ledger data, 3164 => vchr_ref_id, 185_STU_4 => "ledger ref id", 
// console.log(voucher_entry);