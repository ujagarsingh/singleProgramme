import React, { Component } from 'react';
import {  withRouter } from 'react-router';
//import { Route, NavLink } from 'react-router-dom';

// Components
import FrontInnerHeaderTop from '../includes/front_inner_header_top';
import FrontIndexFooter from '../includes/front_index_footer.js';

class FrontLayoutInner extends Component {
   render() {
      //const { children, ...rest } = this.props;
      const { children } = this.props;
      return (
         <div className="event-details-1">
            {/*<div id="preloader">
               <div id="status">&nbsp;</div>
      </div>*/}
            <header id="header">
               <FrontInnerHeaderTop />
            </header>
            {children}
            <FrontIndexFooter />
         </div>
      )
   }
}
export default withRouter(FrontLayoutInner);
