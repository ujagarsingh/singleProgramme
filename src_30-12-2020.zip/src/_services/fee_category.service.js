// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios'; 
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const feeCategoryService = {
    getFeeCategory,
    create,
    update,
    delete : _delete
};

function getFeeCategory() {
    loadProgressBar();
    const url = USER_URL + 'fee_category/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_category/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_category/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function _delete(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_category/delete.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
