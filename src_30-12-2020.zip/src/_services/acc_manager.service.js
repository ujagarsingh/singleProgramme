// import config from 'config';
/*
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';
*/

export const accManagerService = {
    getACCManager,
    getGroupWiseDetailBalanceSheet,
    mergeAllLedgers,
    getFinalBalanceofLedgers,
    // singleGroupSummaryHandler,
    getLedgerSummaryofFinancialYearHandler,
    getLedgerSummaryofMonthHandler,
    getVoucherEntryHandler,
    getLedgerNameHandler
};

// function getAccCCEntry() {
//     loadProgressBar();
//     const url = USER_URL + 'acc_group_entry/read.php';
//     return Axios.post(url, authHeader()).then()
// }


// console.warn(app_state);

function getGroupWiseDetailBalanceSheet(app_state) {
    // debugger;
    let res_data = app_state.acc_entries;
    let res_students = app_state.students;
    let res_profs = app_state.professional;
    let detaild_ldr = [];
    res_data.map((ldrs) => {
        const _newLdr = ldrs.ledgers.map((kItem) => {
            const lr_ref = kItem.ldr_ref_id.split("_");

            switch (lr_ref[1]) {
                case 'STU':
                    // Students
                    const ldr_info = res_students.filter((sItem) => {
                        if (lr_ref[0] === sItem.se_id && lr_ref[2] === sItem.school_id) {
                            return sItem;
                        }
                    })
                    kItem = { ...kItem, "ldr_name": ldr_info[0].student_name + ' S/o ' + ldr_info[0].father_name + ' [' + ldr_info[0].admission_number + '/' + ldr_info[0].stu_class + ']' }
                    break;
                case 'STF':
                    // Staff
                    const ldr_p_info = res_profs.filter((sItem) => {
                        if (lr_ref[0] === sItem.s_id && lr_ref[2] === sItem.school_id) {
                            return sItem;
                        }
                    })

                    kItem = { ...kItem, "ldr_name": ldr_p_info[0].emp_name + ' S/o ' + ldr_p_info[0].emp_f_name }

                    break;
                default:
                    // Other Ledgers
                    const ldr_info1 = res_students.filter((sItem) => {
                        if (lr_ref[0] === sItem.se_id && lr_ref[2] === sItem.school_id) {
                            return sItem;
                        }
                    })
                    kItem = { ...kItem, "ldr_name": ldr_info1[0].ledger_name }
            }
            return kItem;
        })
        detaild_ldr = [...detaild_ldr, ..._newLdr];
        // return _newLdr
    });

    return detaild_ldr
}
// let ldr_data = getGroupWiseDetailBalanceSheet(app_state);
// allGrp => All Groups, ldr_data => all ledger data
// all voucher entries.....
// console.log({ "All Voucher Entries": ldr_data });


// get merge all ledges (normal + students + staff + other);
function mergeAllLedgers(app_state) {
    let merged_ledger = [];
    const _ledger = app_state.acc_ledgers;
    const _students = app_state.students;
    const _professionals = app_state.professional;
    const _updated_ledger = _ledger.map((l_item) => {
        l_item = { ...l_item, "type": "LDR", "ldr_ref_id": l_item.id + "_LDR_" + l_item.school_id }
        return l_item
    })
    const _stu_data = _students.map((s_item) => {
        const ldr_name = s_item.student_name + ' S/o ' + s_item.father_name + ' [' + s_item.admission_number + '/' + s_item.stu_class + ']';
        const _single_stu = {
            "id": s_item.se_id,
            "school_id": s_item.school_id,
            "under_group": 10,
            "group_type": "P",
            "ledger_name": ldr_name,
            "Alias": null,
            "ledger_type": "P",
            "server_date_time": null,
            "type": "STU",
            "ldr_ref_id": s_item.se_id + "_STU_" + s_item.school_id
        };
        return _single_stu
    });

    const _stf_data = _professionals.map((s_item) => {
        const ldr_name = s_item.emp_name + ' S/o ' + s_item.emp_f_name;
        const _single_stu = {
            "id": s_item.se_id,
            "school_id": s_item.school_id,
            "under_group": 11,
            "group_type": "P",
            "ledger_name": ldr_name,
            "Alias": null,
            "ledger_type": "P",
            "server_date_time": null,
            "type": "STF",
            "ldr_ref_id": s_item.s_id + "_STF_" + s_item.school_id
        };
        return _single_stu
    });

    // console.log(merged_ledger);
    return merged_ledger = [..._updated_ledger, ..._stu_data, ..._stf_data];
}
// let compoundLedgers = mergeAllLedgers(ldr_data, app_state);
// // app_state => app_state, ldr_data => all ledger data
// console.log({ "All Ledgers": compoundLedgers });

function getFinalBalanceofLedgers(data, ledgers) {

    const updated_ledger = ledgers.map((l_item) => {
        const _related_data = data.filter((d_item) => {
            if (l_item.ldr_ref_id === d_item.ldr_ref_id) {
                return d_item
            }
        });
        let cr_amo = 0;
        let dr_amo = 0;

        _related_data.map((vItem) => {
            if (vItem.tr_type === "CR") {
                cr_amo += Number(vItem.tr_amount)
            } else {
                dr_amo += Number(vItem.tr_amount)
            }
        })

        return l_item = { ...l_item, "cl_blnc": Math.abs(cr_amo - dr_amo), "blnc_type": (cr_amo <= dr_amo) ? "DR" : "CR" };
    });
    return updated_ledger;
}
// let final_balance = getFinalBalanceofLedgers(ldr_data, compoundLedgers);
// // ldr_data => all voucher entrys data
// // compoundLedgers => All ledgers (students, fee, staff, and other), 
// console.log({ "Ledger wise Balance": final_balance });


// Balance sheet (current Libilities and Assets)
// get every group wise balance and p&L a/c
// function balanceSheetHandler(ldr_with_balance, app_state) {}



function getACCManager(app_state) {
    return new Promise((resolve, reject) => {
        // debugger
        const ldr_data = getGroupWiseDetailBalanceSheet(app_state);
        const compoundLedgers = mergeAllLedgers(app_state);
        const all_LWB = getFinalBalanceofLedgers(ldr_data, compoundLedgers);

        const _group = app_state.acc_group;
        // const _ledger = app_state.acc_ledgers;
        // const all_LWB = ldr_with_balance;
        // const all_ledger = compoundLedgers;
        // const _school_id = app_state.filteredSchoolData.slct_school_id;

        const main_group = _group.filter((mg_item) => {
            if (mg_item.under_gp_id === null) {
                return mg_item;
            };
        });

        function getSubLedgersHander(all_ledger, s_item) {
            const sub_ledgers = all_ledger.filter((item) => {
                if (item.under_group == s_item.id) {
                    return item;
                }
            });

            let cr_amo = 0;
            let dr_amo = 0;
            const updated_ledgers = sub_ledgers.map((l_item) => {
                if (l_item.blnc_type === "CR") {
                    cr_amo += Number(l_item.cl_blnc)
                } else {
                    dr_amo += Number(l_item.cl_blnc)
                }
                return l_item;
            });

            const update_s_item = {
                "sub_ledgers": updated_ledgers,
                "type": "S_GRP",
                "cl_blnc": Math.abs(cr_amo - dr_amo),
                "blnc_type": (cr_amo <= dr_amo) ? "DR" : "CR"
            };
            return update_s_item;
        };

        function getSubGroupsHandler(_group, m_item) {
            let sub_group_with_ledgers = [];
            const sub_groups = _group.filter((item) => {
                if (item.under_gp_id == m_item.id) {
                    return item;
                }
            })
            let cr_amo = 0;
            let dr_amo = 0;

            if (sub_groups.length > 0) {
                sub_group_with_ledgers = sub_groups.map((s_item) => {
                    const sub_ledgers = getSubLedgersHander(all_LWB, s_item);

                    if (sub_ledgers.blnc_type === "CR") {
                        cr_amo += Number(sub_ledgers.cl_blnc)
                    } else {
                        dr_amo += Number(sub_ledgers.cl_blnc)
                    }
                    s_item = { ...s_item, ...sub_ledgers }
                    return s_item;
                })
            } else {
                const sub_ledgers = getSubLedgersHander(all_LWB, m_item);

                if (sub_ledgers.blnc_type === "CR") {
                    cr_amo += Number(sub_ledgers.cl_blnc)
                } else {
                    dr_amo += Number(sub_ledgers.cl_blnc)
                }

                sub_group_with_ledgers = sub_ledgers.sub_ledgers;
            }

            const update_g_item = {
                "sub_group": sub_group_with_ledgers,
                "type": "P_GRP",
                "cl_blnc": Math.abs(cr_amo - dr_amo),
                "blnc_type": (cr_amo <= dr_amo) ? "DR" : "CR"
            };

            return update_g_item;
        };

        function p_and_l_accountHandler(all_groups) {
            let l_cr_amo = 0;
            let l_dr_amo = 0;
            const left_side = all_groups.filter((l_item) => {
                if (l_item.id == "1") {
                    if (l_item.blnc_type === "CR") {
                        l_cr_amo += Number(l_item.cl_blnc)
                    } else {
                        l_dr_amo += Number(l_item.cl_blnc)
                    }
                    return l_item
                }
            });
            const left_obj = {
                "cl_blnc": Math.abs(l_cr_amo - l_dr_amo),
                "blnc_type": (l_cr_amo <= l_dr_amo) ? "DR" : "CR",
            }

            let r_cr_amo = 0;
            let r_dr_amo = 0;
            const right_side = all_groups.filter((l_item) => {
                if (l_item.id == "2") {
                    if (l_item.blnc_type === "CR") {
                        r_cr_amo += Number(l_item.cl_blnc)
                    } else {
                        r_dr_amo += Number(l_item.cl_blnc)
                    }
                    return l_item
                }
            });
            const right_obj = {
                "cl_blnc": Math.abs(r_cr_amo - r_dr_amo),
                "blnc_type": (r_cr_amo <= r_dr_amo) ? "DR" : "CR",
            }

            const total_blnc = Math.abs((left_obj.cl_blnc > right_obj.cl_blnc) ? left_obj.cl_blnc : right_obj.cl_blnc);
            const cl_blnc = Math.abs(left_obj.cl_blnc - right_obj.cl_blnc);
            const blnc_type = (left_obj.cl_blnc <= right_obj.cl_blnc) ? "DR" : "CR";

            // sub_group impove when working on profit and loss account
            const p_and_l = {
                id: "1001",
                under_gp_id: null, // null
                group_name: "Profit and Loss",
                Alias: null,
                group_type: "S",
                total_blnc: total_blnc,
                cl_blnc: cl_blnc,
                blnc_type: blnc_type,
                sub_group: [...left_side, ...right_side],
            }
            return p_and_l;
        }

        const groups_with_sub_groups = main_group.map((m_item) => {
            const sub_groups = getSubGroupsHandler(_group, m_item);
            m_item = { ...m_item, ...sub_groups }
            return m_item;
        });

        const _p_and_l = p_and_l_accountHandler(groups_with_sub_groups);
        groups_with_sub_groups.push(_p_and_l);

        if (groups_with_sub_groups.length > 0) {
            resolve({ "data": { acc_manager: { "group_balance": groups_with_sub_groups, "ledger_data": ldr_data, "all_ledgers": compoundLedgers } } });
        } else {
            reject("Something went wrong");
        }
    })

    // debugger

}

// let balance_res = accManager(final_balance, app_state);
// // allGrp => All Groups, ldr_data => all ledger data
// console.log({ "Gropu, Sub Group, ledger with Balance": balance_res });
// // console.log(JSON.stringify(balance_res));







// Group Summay with detbit and credit
// currently not use
function singleGroupSummaryHandler(data, grpId) {

    let _ldr_ids = [];
    const f_data = data.filter((vItem) => {
        if (grpId == vItem.under_grp_id) {
            if (!_ldr_ids.includes(vItem.ldr_ref_id)) {
                _ldr_ids.push(vItem.ldr_ref_id);
            }
            return vItem
        }
    })
    const _new_obj = _ldr_ids.map((eitem) => {
        let cr_amo = 0;
        let dr_amo = 0;
        const _data = f_data.map((vItem) => {
            if (eitem == vItem.ldr_ref_id) {
                if (vItem.tr_type === "CR") {
                    cr_amo += Number(vItem.tr_amount)
                } else {
                    dr_amo += Number(vItem.tr_amount)
                }
            }
            return false;
        })
        // return eitem = {"item_id" : eitem, "cr_amo" : cr_amo, "dr_amo" : dr_amo, "final_balance" : Math.abs(cr_amo - dr_amo)}
        return eitem = { "item_id": eitem, "cr_amo": cr_amo, "dr_amo": dr_amo, }
    })
    return _new_obj;
}
// let summay_res = singleGroupSummaryHandler(ldr_data, '10')
// ldr_data => all ledger data, 10 => group_id, 
// console.log(summay_res);

// console.log(ldr_data);
// Group Summay with detbit and credit
function getLedgerSummaryofFinancialYearHandler(obj) {
    return new Promise((resolve, reject) => {
        const grpId = obj.ledger_id;
        const data = obj.acc_manager.ledger_data;
        const all_ledgers = obj.acc_manager.all_ledgers;

        let monly_obj = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
        const m_data = data.filter((vItem) => {
            if (grpId == vItem.ldr_ref_id) {
                return vItem
            }
        })
        const _new_obj = monly_obj.map((mitem) => {
            let cr_amo = 0;
            let dr_amo = 0;
            m_data.map((vItem) => {
                if (mitem == vItem.entry_month) {
                    if (vItem.tr_type === "CR") {
                        cr_amo += Number(vItem.tr_amount)
                    } else {
                        dr_amo += Number(vItem.tr_amount)
                    }
                }
                return false;
            })
            return mitem = {
                "month_id": mitem,
                "cr_amo": cr_amo,
                "dr_amo": dr_amo,
                "cl_blnc": Math.abs(cr_amo - dr_amo),
                "blnc_type": (cr_amo <= dr_amo) ? "Dr" : "Cr"
            }
        })
        // opening balance....
        _new_obj.unshift({
            "lcl_blnc": 0,
            "lcl_type": "Dr",
        })
        // console.table(_new_obj);
        let la = 0;  // final last amount
        let lt = 'Dr';     // final last type
        let tdr = 0;    // total debit balnce
        let tcr = 0;    // total credit balnce

        for (let i = 1; i < _new_obj.length; i++) {
            const oa = _new_obj[i - 1].lcl_blnc; // Old Amount
            const ot = _new_obj[i - 1].lcl_type; // Old Type

            const ca = _new_obj[i].cl_blnc;      // Current Amount
            const ct = _new_obj[i].blnc_type;    // Current Type
            // get clossing balance with type 
            if (ca === 0) {
                la = oa;
                lt = ot;
            } else if (ot === ct) {
                la = oa + ca;
                lt = ot;
            } else {
                la = oa - ca;
                lt = (oa > ca) ? ot : ct;
            }

            // get clossing Debit/Credit Balance
            if (ct === 'Dr') {
                tdr = tdr + ca;
            } else {
                tcr = tcr + ca;
            }

            _new_obj[i]['lcl_blnc'] = Math.abs(la);
            _new_obj[i]['lcl_type'] = lt;
        }
        // console.log(JSON.stringify(_new_obj));
        _new_obj.shift();
        // console.table(_new_obj);

        const _ledger_name = this.getLedgerNameHandler(all_ledgers, grpId);

        if (_new_obj.length > 0) {
            resolve({
                "data": {
                    ledger_fy_report: {
                        data_obj: _new_obj, ledger_name: _ledger_name,
                        g_total: { total_dr: tdr, total_cr: tcr, closing_amo: la, closing_type: lt }
                    }
                }
            });
        } else {
            reject("Something went wrong");
        }

    })
    // return _new_obj;
}
// let group_summary = getLedgerSummaryofFinancialYearHandler(ldr_data, '185_STU_4')
// console.log(group_summary);

// Group Summay with detbit and credit
function getLedgerSummaryofMonthHandler(mydata) {
    debugger
    const data = mydata.acc_manager.ledger_data;
    const all_ledgers = mydata.acc_manager.all_ledgers;
    const _accLedgerEntry = mydata.accLedgerEntry;
    const grpId = mydata.ledger_id;
    const monthId = mydata.month_id;
    return new Promise((resolve, reject) => {
        const m_data = data.filter((vItem) => {
            if (grpId === vItem.ledger_folio && monthId === vItem.entry_month) {
                return vItem
            }
        })
        let d_data = [];
        m_data.filter((vItem) => {
            if (!d_data.includes(vItem.vchr_ref_id)) {
                d_data.push(vItem.vchr_ref_id)
            }
            return false
        })
        let cr_total = 0;
        let dr_total = 0;
        const f_res = d_data.map((item) => {

            const v_data = m_data.filter((vItem) => {
                if (item === vItem.vchr_ref_id) {
                    return vItem
                }
            });

            let group_name = "";
            let group_id = "";
            let group_date = "";
            let group_type = "";
            let cr_amo = 0;
            let dr_amo = 0;

            const _data = v_data.map((vItem, inx) => {
                if (monthId == vItem.entry_month) {
                    if (vItem.tr_type === "CR") {
                        cr_amo = Number(vItem.tr_amount);
                        cr_total += Number(vItem.tr_amount);
                    } else {
                        dr_amo = Number(vItem.tr_amount);
                        dr_total += Number(vItem.tr_amount);
                    }
                }
                const l_name = this.getLedgerNameHandler(all_ledgers, vItem.ldr_ref_id);

                if (inx > 0) {
                    group_name = group_name + " /...";
                } else {
                    group_name = l_name;
                    group_id = vItem.vchr_ref_id;
                    group_date = vItem.server_date_time.split(" ")[0];
                    group_type = _accLedgerEntry.filter(e => e.r_id === vItem.vchr_ref_id)[0].vchr_type; // "Journal"
                }
                return vItem = {
                    "ldr_ref_id": vItem.ldr_ref_id,
                    "tr_date": vItem.server_date_time.split(" ")[0],
                    "vch_type": _accLedgerEntry.filter(e => e.r_id === vItem.vchr_ref_id)[0].vchr_type, // "Journal",
                    "vchr_ref_id": vItem.vchr_ref_id,
                    "cr_amo": cr_amo,
                    "dr_amo": dr_amo,
                    "ldr_name": l_name,
                };
            })

            // debugger
            // let f_data = { "data": _data, "tcr": cr_total, "tdr": dr_total, "cl_blnc": Math.abs(cr_total - dr_total), "blnc_type": (cr_total <= dr_total) ? "Dr" : "Cr" };
            let f_data = {
                "gtr_type": (cr_amo <= dr_amo) ? "Dr" : "Cr",
                "gcr_amo": cr_amo,
                "gdr_amo": dr_amo,
                "g_name": group_name,
                "g_type": group_type,
                "g_id": group_id,
                "g_date": group_date,
                "child_data": (_data.length > 1) ? _data : [],
            };
            return f_data;
        })
        const grp_data = {
            "blnc_type": (cr_total <= dr_total) ? "Dr" : "Cr",
            "cl_blnc": Math.abs(cr_total - dr_total),
            "gt_dr": dr_total,
            "gt_cr": cr_total,
            "child": f_res
        }

        // console.log(f_res)
        // debugger
        if (f_res.length > 0) {
            resolve({ "data": { ledger_summary_of_month: grp_data } });
        } else {
            reject("Something went wrong");
        }

        // return f_data;
    })
}
// let ldr_summary_a_month = getLedgerSummaryofMonthHandler(ldr_data, '185_STU_4', '7')
// ldr_data => all ledger data, 7 => month_id, 185_STU_4 => "ledger ref id", 
// console.log(ldr_summary_a_month);

// console.log(ldr_data);
function getVoucherEntryHandler(resdata) {
    // debugger;
    const data = resdata.ldr_data;
    const _all_ledgers = resdata.all_ledgers;
    const vchrid = resdata.vchrid;

    function getLedgerNameHandler(ledger_folio) {
        const fl = _all_ledgers.filter((item) => {
            if (item.ldr_ref_id === ledger_folio) {
                return item;
            }
        })
        return fl[0].ledger_name;
    }

    return new Promise((resolve, reject) => {
        const m_data = data.filter((vItem) => {
            if (vchrid === vItem.r_id) {
                return vItem
            }
        });
        // console.table(m_data);


        let cr_total = 0;
        let dr_total = 0;
        let cr_item = [];
        let dr_item = [];
        let dr_flag = true;

        m_data[0].ledgers.map((xItem) => {
            const _ledger_name = getLedgerNameHandler(xItem['ldr_ref_id']);
            xItem = {
                ldr_ref_id: xItem['ldr_ref_id'],
                tr_amount: xItem['tr_amount'],
                tr_type: xItem['tr_type'],
                under_grp_id: xItem['under_grp_id'],
                under_grp_type: xItem['under_grp_type'],
                ledger_name: _ledger_name,
                // entry_month: "11"
                // isShow: false
                // ledgers: (4) [{…}, {…}, {…}, {…}]
                // narration: "DILKHUSH MEENA S/o BANWARI LAL MEENA Total Due is Rs. 68."
                // r_id: "3183"
                // school_id: "4"
                // school_name: "Jyoti Public Senior Sec. School"
                // session_year_id: "1"
                // tr_date: "2020-11-19"
            };

            if (xItem.tr_type === "CR") {
                cr_item.push(xItem);
                cr_total += Number(xItem.tr_amount)
            } else {
                if (dr_flag) {
                    dr_item.push(xItem);
                    dr_flag = false;
                }
                dr_total += Number(xItem.tr_amount)
            }
            return false
        });

        const dr_ldr = { ...dr_item[0], "tr_amount": dr_total }

        const mItem = {
            "vch_no": vchrid, "credit": cr_item, "debit": dr_ldr, "total_amo": dr_total,
            "narration": m_data[0].narration,
            "vchr_type": m_data[0].vchr_type
        };

        if (m_data.length > 0) {
            resolve({ "data": { single_voucer: mItem } });
        } else {
            reject("Something went wrong");
        }
        // return mItem;
    });

}

// ledger folio to get ledger name
function getLedgerNameHandler(all_ledgers, ledger_folio) {
    const fl = all_ledgers.filter((item) => {
        if (item.ldr_ref_id === ledger_folio) {
            return item;
        }
    })
    return fl[0].ledger_name;
}

