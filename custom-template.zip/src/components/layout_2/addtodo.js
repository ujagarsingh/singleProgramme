import React from 'react'

class Addtodo extends React.Component{
    addItemToState = (e) => {
        e.preventDefault();
        this.props.addTodo({
          text : this.refs.addtodo.value
        })
        this.refs.addtodo.value = ''
    };

    render(){
        const { addTodo } = this.props;
        return(
            <form onSubmit={this.addItemToState}>
                <h4>{addTodo}</h4>
                <p>Layuout 2 Welcome</p>
                <input type="text" ref="addtodo" />
                <button type="submit">Add Toto</button>
            </form>
        )
    }
}

export default Addtodo;