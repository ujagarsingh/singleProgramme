import React from 'react'
class Addtodo extends React.Component{
      
    render(){
        const { addTodo } = this.props;
        return(
          
            <div className="container">
			<form>
			  <div class="form-row align-items-center">
                <h4>{addTodo}</h4>
				<div class="col-auto">
				  <label class="sr-only" for="inlineFormInputGroup">Innings</label>
				  <div class="input-group mb-2">
					<div class="input-group-prepend">
					  <div class="input-group-text">@</div>
					</div>
					<input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Username"/>
				  </div>
				</div>
				<div class="col-auto">
				  <button type="submit" class="btn btn-primary mb-2">Add Inning</button>
				</div>
			  </div>
			</form>
             
            </div>
        )
    }
}

export default Addtodo;
