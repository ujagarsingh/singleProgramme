let Components = {};

Components['Component1'] = require('./layout_1/addtodo').default;
Components['Component2'] = require('./layout_2/addtodo').default;

export default Components;