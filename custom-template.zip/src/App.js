import React, { Component } from 'react';
import './App.css';

import Components from './components/addtodoindex';

class App extends Component{
  state = ({
     addTodo : 'Aflatoon'
  });
  
  render(){
    const {addTodo} = this.state;
    const type = 'Component1'; // example variable - will change from user input
    const Addtodo = Components[type];
    return (
      <div className="App_">
        <Addtodo addTodo={addTodo} />
      </div>
    );
  }
}

export default App;
