import React, { Component } from "react";
import { withRouter } from 'react-router';
import { Route } from "react-router-dom";
import FrontLayout from "./FrontLayout";
class FrontLayoutRoute extends Component {
  render() {
    const { component: Component, ...rest } = this.props;
    return (
      <Route {...rest} render={matchProps => (
        <FrontLayout>
          <Component {...matchProps} />
        </FrontLayout>
      )} />
    )
  }
}

export default withRouter(FrontLayoutRoute);
