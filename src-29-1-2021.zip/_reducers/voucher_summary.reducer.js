import { voucherSummaryConstants } from '../_constants';

export function voucherSummary(state = {}, action) {
  switch (action.type) {
   
    case voucherSummaryConstants.ACC_SINGLE_VOUCHER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case voucherSummaryConstants.ACC_SINGLE_VOUCHER_SUCCESS:
      // const single_voucher_obj = { ...state.item, single_voucer: action.response };
      return {
        item: action.response,
        loading: false,
      };
    case voucherSummaryConstants.ACC_SINGLE_VOUCHER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}