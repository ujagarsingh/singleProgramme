import { accLedgerConstants } from '../_constants';

export function accLedger(state = {}, action) {
  switch (action.type) {
    case accLedgerConstants.ACC_LEDGER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accLedgerConstants.ACC_LEDGER_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accLedgerConstants.ACC_LEDGER_FAILURE:
      return {
        error: action.error
      };


    case accLedgerConstants.CREATE_ACC_LEDGER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accLedgerConstants.CREATE_ACC_LEDGER_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accLedgerConstants.CREATE_ACC_LEDGER_FAILURE:
      return {
        error: action.error
      };



    case accLedgerConstants.UPDATE_ACC_LEDGER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accLedgerConstants.UPDATE_ACC_LEDGER_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accLedgerConstants.UPDATE_ACC_LEDGER_FAILURE:
      return {
        error: action.error
      };


    case accLedgerConstants.DELETE_ACC_LEDGER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accLedgerConstants.DELETE_ACC_LEDGER_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accLedgerConstants.DELETE_ACC_LEDGER_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}