import { examSdulConstants } from '../_constants';

export function examSdul(state = {}, action) {
  switch (action.type) {
    case examSdulConstants.EXAM_SDUL_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examSdulConstants.EXAM_SDUL_SUCCESS:
      return {
        item: action.response
      };
    case examSdulConstants.EXAM_SDUL_FAILURE:
      return {
        error: action.error
      };



    case examSdulConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examSdulConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case examSdulConstants.CREATE_FAILURE:
      return {
        error: action.error
      };



    case examSdulConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examSdulConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case examSdulConstants.DELETE_FAILURE:
      return {
        error: action.error
      };




    default:
      return state
  }
}