import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { authenticActions } from '../_actions';

import { confirmAlert } from 'react-confirm-alert';


class DashboardHeader extends Component {
  state = {
    showNotification: false,
    isFilter: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  componentDidMount() {

  }
  toggleSidebar() {
    document.querySelector('#rootBody').classList.toggle('sidemenu-closed');
    if (document.querySelector('.sidemenu li.nav-item.active')) {
      document.querySelector('.sidemenu li.nav-item.active').classList.add('off');
    }
  }
  toggleMTopbar() {
    document.querySelector('#rootBody').classList.toggle('top-navbar-show')
    document.querySelector('#rootBody').classList.remove('sidemenu-show')
    document.querySelector('#rootBody').classList.remove('filter-navbar-show')
    document.querySelector('#rootBody').classList.remove('top-navbar-show')
  }
  filterMTopbar() {
    document.querySelector('#rootBody').classList.toggle('filter-navbar-show')
    document.querySelector('#rootBody').classList.remove('filter-show')
    document.querySelector('#rootBody').classList.remove('top-navbar-show')
    document.querySelector('#rootBody').classList.remove('sidemenu-show')
  }
  toggleMSidebar() {
    document.querySelector('#rootBody').classList.toggle('sidemenu-show')
    document.querySelector('#rootBody').classList.remove('filter-show')
    document.querySelector('#rootBody').classList.remove('top-navbar-show')
    document.querySelector('#rootBody').classList.remove('filter-navbar-show')
  }
  confirmBoxLogout = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Logout Now.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.logoutHandlaer(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  logoutHandlaer() {
    this.props.logoutUser();
    this.props.history.push('/');
  }
  notificationBar(event) {
    event.preventDefault();
    this.setState({
      showNotification: !this.state.showNotification
    })
  }
  gotoFAQ(ev) {
    ev.preventDefault();
    alert("Working.....")
  }
  render() {
    const { showNotification } = this.state;
    const { user } = this.props;
    return (
      <div className="dash-header navbar navbar-fixed-top">
        {user &&
          <div className="dash-header-inner d-flex w-100">
            <div className="dash-logo">
              <NavLink to="/Dashboard.jsp">
                <span className="fa fa-book mr-2"></span>
                <span className="logo-default">Demo Admin</span> </NavLink>
              <button className="btn btn-link btn-logout"
                onClick={event => this.logoutHandlaer(event)}>
                <i className="fas fa-sign-out-alt"></i> </button>
            </div>
            <ul className="nav navbar-nav navbar-left in">
              <li className="p-1"><button type="button"
                onClick={event => this.toggleSidebar(event)}
                className="btn btn-outline-primary sidebar-toggler"><i className="fa fa-bars"></i></button></li>
            </ul>
            <div className="mobile-nav">
              <button
                type="button"
                onClick={event => this.toggleMSidebar(event)}
                className="btn btn-outline-primary sidebar-toggler">
                <i className="fa fa-bars"></i>
              </button>
              <span>
                <button
                  type="button"
                  onClick={event => this.filterMTopbar(event)}
                  className="btn btn-outline-primary filter-toggler">
                  <i className="fa fa-filter"></i>
                </button>
                <button
                  type="button"
                  onClick={event => this.toggleMTopbar(event)}
                  className="btn btn-outline-primary responsive-toggler">
                  <i className="fa fa-bars"></i>
                </button>
              </span>
            </div>
            <div className="top-menu ml-auto">
              <ul className="nav navbar-nav ">
                <li className="p-1 fullscreen-btn-li">
                  <button type="button" className="btn btn-link fullscreen-btn">
                    <i to="/" className="fas fa-expand" /></button>
                </li>
                <li className="notification-link p-1 mr-2" >
                  <button type="button"
                    onClick={event => this.notificationBar(event)}
                    className="btn btn-link dropdown-toggle">
                    <i className="las la-bell" />
                    <span className="badge headerBadgeColor1"> 6 </span>
                  </button>
                  {showNotification &&
                    <ul className="dropdown-menu">
                      <li className="external">
                        <h6>Notifications</h6>
                        <span className="notification-label purple-bgcolor">New 6</span>
                      </li>
                      <li>
                        <ul className="dropdown-menu-list">
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle deepPink-bgcolor"><i className="las la-check" /></span>
                                <span className="details-txt">Congratulations!. </span></span>
                              <span className="time"><span className="time-txt">just now</span></span>
                            </button>
                          </li>
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle purple-bgcolor"><i className="las la-user" /></span>
                                <span className="details-txt"><b>John Micle </b>is now following you. is now following you. </span></span>
                              <span className="time"><span className="time-txt">3 mins</span></span>
                            </button>
                          </li>
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle blue-bgcolor"><i className="las la-comments" /></span>
                                <span className="details-txt"><b>Sneha Jogi </b>sent you a message. </span></span>
                              <span className="time"><span className="time-txt">7 mins</span></span>
                            </button>
                          </li>
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle bg-pink"><i className="la la-heart" /></span>
                                <span className="details-txt"><b>Ravi Patel </b>like your photo. </span></span>
                              <span className="time"><span className="time-txt">12 mins</span></span>
                            </button>
                          </li>
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle bg-yellow"><i className="la la-warning" /></span>
                                <span className="details-txt">Warning! </span></span>
                              <span className="time"><span className="time-txt">15 mins</span></span>
                            </button>
                          </li>
                          <li>
                            <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-link">
                              <span className="details">
                                <span className="notification-icon circle bg-red"><i className="la la-times" /></span>
                                <span className="details-txt"> Application error. </span></span>
                              <span className="time"><span className="time-txt">10 hrs</span></span>
                            </button>
                          </li>
                        </ul>
                        <div className="dropdown-menu-footer">
                          <button onClick={(event) => { this.gotoFAQ(event) }} className="notif-all-link"> All notifications </button>
                        </div>
                      </li>
                    </ul>
                  }
                </li>

                {/*<li className="p-1">
                <NavLink to="/new_get_estimate.jsp" className="btn btn-primary btn-sm">
                Estimate</NavLink>
              </li>
              <li className="p-1">
                <NavLink to="/get_estimate.jsp" className="btn btn-primary btn-sm">
                  Discount & Convence</NavLink>
    </li>*/}
                {(user.user_category === "1" || user.user_category === "2") ?
                  <>
                    <li className="p-1">
                      <NavLink to="/get_fees.jsp"
                        // onClick={e => e.preventDefault()}
                        className="btn btn-success btn-sm">
                        Get Fees</NavLink>
                    </li>
                    <li className="p-1">
                      <NavLink to="/new_payment.jsp"
                        // onClick={e => e.preventDefault()}
                        className="btn btn-primary btn-sm">
                        New Payment</NavLink>
                    </li>
                  </>
                  : null}
                <li className="p-1 mr-4 btn-logout">
                  <button className="btn btn-danger btn-sm mr-4"
                    onClick={event => this.confirmBoxLogout(event)}>
                    <i className="fas fa-sign-out-alt"></i></button>
                </li>
              </ul>
            </div>
          </div>
        }
      </div>
    )
  }
}
const actionCreators = {
  logoutUser: authenticActions.logout,
}
export default connect(null, actionCreators)(withRouter(DashboardHeader));

// export default withRouter(DashboardHeader);