import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultSliderActions } from '../_actions';

class FrontIndexSlider extends Component {
  state = {
    slider_arr: [],
  }
  componentDidMount() {
    if (isEmptyObj(this.props.slider)) {
      this.props.getDefaultSlider();
   }
  };
  render() {
    return (
      <div className="index_slider" >
        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/slider-0` + (0 + 1) + `.jpg`} 
          className="rev-slidebg img-responsive" />
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: slider } = state.defaultSlider;
  return { slider };
}

const actionCreators = {
  getDefaultSlider: defaultSliderActions.getDefaultSlider,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexSlider));
