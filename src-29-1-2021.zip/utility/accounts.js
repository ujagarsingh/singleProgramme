

export {
  focusFirstHandler,
  srollListItemHandler,
  getSumOfBalanceHandler,
  filterDataHandler,
  effectedLedgerHandler,
  getNextInputHandler,
  selectAndFocusNext
};

function focusFirstHandler() {
  const allinput = Array.prototype.slice.call(document.querySelector('.sfpage-body').querySelectorAll("textarea, input, select, button"));
  if (allinput.length > 1) {
    (allinput[1]).focus();
    (allinput[1]).select();
  }
}

function srollListItemHandler(key, list_type) {
  // debugger;
  const _div = document.querySelector('#ldrList');
  const _elem = _div.querySelector('.active');

  const _elh = _elem.clientHeight;
  const _dlh = _div.clientHeight + 80;

  let rect = _elem.getBoundingClientRect();
  let rect_div = _div.getBoundingClientRect();
  let elementTop; //x and y
  // let elementBottom; //x and y
  var scrollTop = document.documentElement.scrollTop ?
    document.documentElement.scrollTop : document.body.scrollTop;
  elementTop = Math.round(rect.top) + scrollTop;
  // elementBottom = Math.round(rect.bottom) + scrollTop;
  let divTop = Math.round(rect_div.top);
  // let divBottom = Math.round(rect_div.bottom) ;
  // console.log(elementTop)
  // console.log(elementBottom)
  // console.log(_dlh)

  if (key === "up" || key === "left" || key === "down" || key === "right") {
    if (elementTop > _dlh) {
      _div.scrollBy(0, elementTop - _dlh);
    } else if (elementTop < _dlh) {
      _div.scrollBy(0, elementTop + -divTop);
    } else {
      _div.scrollBy(0, _elh);
    }
  }
}

function getSumOfBalanceHandler(state_voucher) {
  debugger
  let sv = state_voucher;// JSON.parse(JSON.stringify(this.state.voucher));
  let total_cr = 0;
  let total_dr = 0;
  sv.child.forEach(elem => {
    if ((elem.tr_type).toUpperCase() === "CR") {
      total_cr += Number(elem.tr_amount);
    } else {
      total_dr += Number(elem.tr_amount);
    }
  });
  return { total_cr: total_cr, total_dr: total_dr };
}

function filterDataHandler(ldr_list, value) {
  // debugger
  console.log('71-accounts')

  let val_txt = value.toUpperCase();
  let filter_data = ldr_list.filter((elem) => {
    const _elem = elem.ledger_name.toUpperCase();
    if (!_elem.includes(val_txt)) {
      return false
    }
    return elem
  })

  const cursor = getCurrectCursorHandler(filter_data, val_txt);

  // console.log(filter_data);
  if (filter_data.length === 0) {
    alert('Wrong Spelling!!!');
    val_txt = '';
    // filter_data = [{'ledger_name' :"Ledgers Missmatched!"}]
    // wrongSpellingONHandler();
  }

  const obj = { filter_data, val_txt, cursor }
  return obj
}

function getCurrectCursorHandler(filter_data, val_txt) {
  // console.log('97-accounts')
  let _cursor = 0;
  filter_data.forEach((elem, inx) => {
    if (elem === val_txt) {
      _cursor = inx;
    }
  })
  return _cursor;
}

function effectedLedgerHandler(vchr_type, all_ledgers) {
  // debugger
  // console.log('109-accounts')
  let ldr_debit = [];
  let ldr_credit = [];

  switch (vchr_type) {
    case "Payment":
      // code
      ldr_debit = [12];
      ldr_credit = [11];
      break;
    case "Receipt":
      // code
      ldr_credit = [12];
      ldr_debit = [10];
      break;
    default:
      // code
      ldr_credit = [11, 10, 1, 2];
      ldr_debit = [11, 10, 1, 2];
  }
  // const { all_ledgers } = this.props.accountManager;
  let efctd_cr_ldr = [];
  let efctd_dr_ldr = [];

  ldr_credit.forEach(el => {
    efctd_cr_ldr = [...efctd_cr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
  })

  ldr_debit.forEach(el => {
    efctd_dr_ldr = [...efctd_dr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
  });
  const obj = {
    credit_ledgers: efctd_cr_ldr,
    debit_ledgers: efctd_dr_ldr,
    all_ledgers: all_ledgers
  };
  return obj;
}

function getNextInputHandler(event, current_index, allinput) {
  let nextTi = '';
  if ((event.shiftKey && event.key === 'Tab') || (event.shiftKey && event.key === 'Enter')) {
    nextTi = (current_index === 0 || current_index === 1) ? 1 : current_index - 1;
  } else {
    nextTi = (current_index === allinput.length) ? allinput.length : current_index + 1;
  }
  return nextTi;
}

function selectAndFocusNext(inputElem) {
  inputElem.focus();
  inputElem.select();
}