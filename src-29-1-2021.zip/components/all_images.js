import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
// import axios from 'axios';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import ImageLoader from "../utility/ImageLoader/index";
import { connect } from 'react-redux';
import { frontImagesActions, schoolsAction, frontGalleryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddImage from './add_image';
import EditImage from './edit_image';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_IMAGES = `http://schools.rajpsp.com/api/galleries/images/read.php`;
// const GET_GALLERIES = `http://schools.rajpsp.com/api/galleries/gallery/read.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/galleries/images/delete.php`;

class AllImages extends Component {
  state = {
    display_all_images: [], // after add gallery title 
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.frontImages)) {
      this.props.getFrontImages();
    }
    if (isEmptyObj(this.props.frontGallery)) {
      this.props.getFrontGallery();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getGalleriesHandler();
  //           this.getImagesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getGalleriesHandler() {
  //   loadProgressBar();
  //   axios.get(GET_GALLERIES)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         galleries: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.galleries);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  // getImagesHandler(){
  //   loadProgressBar();
  //   axios.get(GET_IMAGES)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         all_images: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.all_images);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteFrontImages({id});
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   debugger;
  //   axios.post(DELETE_URL + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _galleries = this.state.all_images.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         all_images: _galleries
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateFrontImages(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.frontImages.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }
  render() {
    const { formIsHalfFilledOut, createItem, editItem, selected_item } = this.state;
    const { user, frontImages, schools, frontGallery } = this.props;
    //    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All images</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {/* <div className="page-bar d-flex">
          <div className="page-title">All Images</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mt-1">
                <NavLink to="/add_image.jsp" className="btn btn-primary btn-sm">
                  Add New <i className="fa fa-plus" />
                </NavLink>
              </div>
            </div>
          </div>
        </div> */}
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {createItem ? <AddImage
              toggeleCreate={this.toggeleCreate} />
              : null}
            {editItem ? <EditImage
              selected_item={selected_item}
              schools={schools}
              frontGallery={frontGallery}
              updateHandlar={this.updateHandlar}
              openEdit={this.openEdit}
              closeEdit={this.closeEdit}
            />
              : null}
            <div className="table-scrollable container-fluid">
              {frontImages &&
                <div className="row">
                  {frontImages.map((item, index) => {
                    return (
                      <div key={index} className="col-sm-6 col-md-4 col-lg-3  mb-3">
                        <div className="card">
                          <div className="card-body p-3 pb-1 ">
                            <h6 className="card-subtitle text-muted">{item.gallery_title}</h6>
                          </div>
                          <div className="card-body p-0 h-auto card-image">
                            <span className={`badge badge-pill card-badge` + (item.active === '1' ? ' badge-warning' : ' badge-danger')} >
                              {item.active === '1' ? 'Active' : 'Not Active'}
                            </span>
                            <ImageLoader
                              src={`${process.env.PUBLIC_URL}` + item.img_link}
                              fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/no-image.png`}
                            />
                            <p className="card-text card-image-title">{item.img_title}</p>
                          </div>
                          <div className="card-footer p-2 d-flex">
                            {/* <NavLink to={`edit_image.jsp/${item.id}`} className="btn btn-primary btn-sm">
                              Edit
                          </NavLink> */}
                            <button className="btn btn-primary btn-sm mr-1"
                              value={item.id}
                              onClick={event => this.openEdit(event, item.id)}>Edit</button>
                            <button className="btn btn-danger btn-sm ml-auto"
                              value={item.id}
                              onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>

                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              }
            </div>
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">
                Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">
                Add New
            </button>
            }
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontImages } = state.frontImages;
  const { item: schools } = state.schools;
  const { item: frontGallery } = state.frontGallery;
  return { user, frontImages, schools, frontGallery };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getFrontGallery: frontGalleryActions.getFrontGallery,
  getFrontImages: frontImagesActions.getFrontImages,
  updateFrontImages: frontImagesActions.update,
  deleteFrontImages: frontImagesActions.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllImages));
