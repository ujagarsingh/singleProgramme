import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class SingleShedule extends Component {
   state = {
   }
    
   printThisReceipt = () => {
      // window.print();
   }
   convertDate(str) {
      var date = new Date(str),
         mnth = ("0" + (date.getMonth() + 1)).slice(-2),
         day = ("0" + date.getDate()).slice(-2);
      return [day, mnth, date.getFullYear()].join("-");
   }

   getConvertedDay(str) {
      var currnt_date = new Date(str);
      let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      // var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      // return months[this.getMonth()];
      return days[currnt_date.getDay()].toUpperCase();
   }


   render() {
      const { shedule_obj, notes } = this.props;
      console.log(this.props)
      return (
         <div className="page-content">
            <Helmet>
               <title>Single Shedule</title>
            </Helmet>
            <br/>
            <div className="text-center">
               <h5>{shedule_obj.school_info.sch_name} [{shedule_obj.school_info.sch_medium}]</h5>
               <p className="mb-2"><b>{shedule_obj.school_info.sch_address}</b></p>
               <p className="mb-3"><b>{shedule_obj.exam_name} - {shedule_obj.school_info.session_year_id}</b></p>
            </div>
            <div className="d-flex mb-2">
               {shedule_obj.innings.map((item, inx) => {
                  return (
                     <div key={inx} className="mr-3"> {(item.inning_name === 'I') ? "First Shift" :
                        ((item.inning_name === 'II') ? "Second Shift" : "Third Shift")}:  <b>{item.inning_time}</b></div>
                  )
               })}
            </div>
            <table className="table text-center table-bordered table-hover table-sm m-0" id="timeSchedule_1">
               <thead className="bg-light text-secondary">
                  <tr>
                     <th>Date</th>
                     <th>Shifts</th>
                     {shedule_obj.classes.map((item, index) => {
                        return <th key={index}>{item.class_name}</th>
                     })}
                  </tr>
               </thead>
               {shedule_obj.updated_subjects.length > 0 ?
                  <tbody >
                     {shedule_obj.updated_subjects.map((inn_item, day_inx) => {
                        return (
                           <React.Fragment key={day_inx}>
                              {inn_item.innings.map((item_in, innx) => {
                                 return (
                                    <tr className="data_row" key={innx}>
                                       < React.Fragment >
                                          {innx === 0 ?
                                             <td className="" rowSpan={inn_item.innings.length}>
                                                <span className="p-1 d-block">
                                                   <b>{this.convertDate(inn_item.exam_date)}</b><br />
                                                   <b>{this.getConvertedDay(inn_item.exam_date)}</b>
                                                </span>
                                             </td>
                                             : null}
                                          <td className="w-130 data_inning_name text-center">
                                             {item_in.inning}
                                          </td>
                                          {
                                             item_in.class_subject.map((sub_item, s_inx) => {
                                                return (
                                                   <td key={s_inx} className="p-0">
                                                      {sub_item.selected_sub}
                                                   </td>)
                                             })
                                          }
                                       </ React.Fragment>
                                    </tr>
                                 )
                              })}
                           </React.Fragment>
                        )
                     })}
                  </tbody>
                  : null}
            </table>
            <h6 className="mt-2">Notes : </h6>
            <ol className="list-inline ml-4 mb-0">
               {notes.map((item, inx) => {
                  return <li className="list-inline-item ml-3" key={inx}><b>({inx + 1}).</b>   {' ' + item.note}</li>
               })}
            </ol>
            <div className="d-flex mt-4 p-4">
               <div className="pl-4"><b>Exam Incharge</b></div>
               <div className="pr-4 ml-auto"><b>Principal</b></div>
            </div>
         </div >
      )
   }
}
export default withRouter(SingleShedule);