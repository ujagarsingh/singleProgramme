import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

class NewIncome extends Component {
   state = {
      transaction_date: new Date(),
      party_name: '',
      income_type_id: '',
      cr_amo: '',
      amount_in_word: '',
      description: '',
      formIsHalfFilledOut: false,
   }

   componentDidMount() {
      if (isEmptyObj(this.props.accLedger)) {
         this.props.getIndirectIncome();
      }
   }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                //   this.getSchoolHandler();
   //                //   this.getClassesHandler();
   //                //   this.getConvencesHandler();
   //                //   this.getStudentRecords();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }


   nuberInWords = (price) => {
      var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
         dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
         tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
         handle_tens = function (dgt, prevDgt) {
            return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
         },
         handle_utlc = function (dgt, nxtDgt, denom) {
            return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
         };

      var str = "",
         digitIdx = 0,
         digit = 0,
         nxtDigit = 0,
         words = [];
      if (price += "", isNaN(parseInt(price))) str = "";
      else if (parseInt(price) > 0 && price.length <= 10) {
         for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--) switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
            case 0:
               words.push(handle_utlc(digit, nxtDigit, ""));
               break;
            case 1:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 2:
               words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
               break;
            case 3:
               words.push(handle_utlc(digit, nxtDigit, "Thousand"));
               break;
            case 4:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 5:
               words.push(handle_utlc(digit, nxtDigit, "Lakh"));
               break;
            case 6:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 7:
               words.push(handle_utlc(digit, nxtDigit, "Crore"));
               break;
            case 8:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 9:
               words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "")
         }
         str = words.reverse().join("")
      } else str = "";
      return str

   }
   paymentDateHandlar = (_date) => {
      this.setState({ transaction_date: _date });
   };
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })
      if (fieldName === 'cr_amo') {
         const _amount_in_word = this.nuberInWords(event.target.value);
         this.setState({
            amount_in_word: _amount_in_word
         })
      }
   };
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Add this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler() {
      // e.preventDefault();
      const _state = this.state;
      const obj = {
         action: 'indirect_income',
         party_name: _state.party_name,
         income_id: _state.income_type_id,
         cr_amo: _state.cr_amo,
         description: _state.description,
         transaction_date: _state.transaction_date
      }
      console.log(JSON.stringify(obj));
      this.props.createIncomeExpenditure(obj);
   }
   render() {
      const { formIsHalfFilledOut, transaction_date, party_name, cr_amo,
         amount_in_word, description } = this.state;
      const { accLedger } = this.props;
      //console.log(_state)
      return (
         <div className="page-child">
            <Helmet>
               <title>New Income</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  New Income
            </div>
               <div className="card-body">
                  <div className="row">
                     <div className="col-sm-2">
                        <div className="form-group">
                           <label className="control-label">Date
                        <span className="required"> * </span>
                           </label>
                           <div className="form-input">
                              <DatePicker
                                 onChange={this.paymentDateHandlar}
                                 value={transaction_date}
                                 showLeadingZeroes={true}
                              />
                           </div>
                        </div>
                     </div>
                     {accLedger &&
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Income Type
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    onChange={event => this.changeHandler(event, 'income_type_id')}>
                                    <option>Select...</option>
                                    {accLedger.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.income_type}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        </div>
                     }
                     <div className="col-sm-3">
                        <div className="form-group">
                           <label className="control-label">Giver Name
                        <span className="required"> * </span>
                           </label>
                           <div className="form-input">
                              <input type="text" name="party_name"
                                 value={party_name}
                                 required
                                 onChange={event => this.changeHandler(event, 'party_name')}
                                 placeholder="Giver Name" className="form-control form-control-sm" />
                              <small className="form-text text-muted">Govt., Donation or Other Income re-source.</small>
                           </div>
                        </div>
                     </div>
                     <div className="col-sm-2">
                        <div className="form-group">
                           <label className="control-label">Amount
                        <span className="required"> * </span>
                           </label>
                           <div className="form-input">
                              <input type="number" name="cr_amo"
                                 placeholder="Amount in INR"
                                 value={cr_amo}
                                 required
                                 onChange={event => this.changeHandler(event, 'cr_amo')}
                                 className="form-control form-control-sm" />
                              <small className="form-text text-danger">{amount_in_word}</small>
                           </div>
                        </div>
                     </div>
                     <div className="col-sm-3">
                        <div className="form-group">
                           <label className="control-label">Description (Narration)
                        <span className="required"> * </span>
                           </label>
                           <div className="form-input">
                              <input type="text" name="party_name"
                                 placeholder="description"
                                 value={description}
                                 required
                                 onChange={event => this.changeHandler(event, 'description')}
                                 className="form-control form-control-sm" />
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-secondary mr-2">Submit</button>
                  <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
                     Cancel
                  </button>
               </div>
            </form>
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: accLedger } = state.accLedger;
   const { item: incomeExpenditure } = state.incomeExpenditure;
   return { user, accLedger, incomeExpenditure };
}

const actionCreators = {
   getIndirectIncome: accLedgerActions.getIndirectIncome,
}

export default connect(mapStateToProps, actionCreators)(withRouter(NewIncome));
