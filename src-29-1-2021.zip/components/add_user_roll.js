import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class AddUser extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Add User </title>
        </Helmet>

        <div className="page-bar d-flex">
              <div className="page-title">Add User </div>
            </div>
        <div className="row">
          <div className="col-md-12 col-sm-12">
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                <div className="row">
                  <div className="col-md-8">
                    <form action="#" id="form_sample_1" className="form-horizontal">
                      <div className="form-body">
                        <div className="form-group row">
                          <label className="control-label col-md-5">Category Name
                      <span className="required"> * </span>
                          </label>
                          <div className="col-md-5">
                            <input type="text" name="firstname" placeholder="enter first name" className="form-control form-control-sm" />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Category Code
                      <span className="required"> * </span>
                          </label>
                          <div className="col-md-5">
                            <input type="text" name="firstname" placeholder="enter first name" className="form-control form-control-sm" />
                          </div>
                        </div>
                        <div className="form-actions  text-right">
                          <div className="row">
                            <div className="offset-md-5 col-md-7">
                              <button type="submit" className="btn btn-primary mr-2">Submit</button>
                             <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div className="col-md-4">
                    <ul className="list-unorder">
                      <li className="nav-item start">
                        <NavLink to="index" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">dashboard</i>
                          <span className="title">Dashboard</span>
                        </NavLink>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle">
                          <input type="checkbox" /><i className="material-icons">dashboard</i>
                          <span className="title">Main Website</span>
                          <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item   ">
                            <NavLink to="../site/index" target="blank" className="nav-link ">
                              <span className="title">Visit Site</span>
                            </NavLink>
                          </li>
                          <li className="nav-item ">
                            <NavLink to="/" className="nav-link ">
                              <span className="title">Edit</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"><input type="checkbox" /><i className="material-icons">group</i>
                          <span className="title">Students</span><span className="arrow" /></NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_students.jsp" className="nav-link "> <span className="title">All
                          Students</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_student" className="nav-link "> <span className="title">Add
                          Student</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="edit_student" className="nav-link "> <span className="title">Edit
                          Student</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="/student_profile.jsp" className="nav-link "> <span className="title">About
                          Student</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">school</i>
                          <span className="title">Class</span> <span className="selected" />
                          <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_class" className="nav-link "> <span className="title">All
                          Class</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_class" className="nav-link "> <span className="title">Add
                          Class</span>
                              <span className="selected" />
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="edit_class" className="nav-link "> <span className="title">Edit
                          Class</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="class_details" className="nav-link "> <span className="title">About
                          Class</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">person</i>
                          <span className="title">Professors</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_professors" className="nav-link "> <span className="title">All
                          Professors</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_professor" className="nav-link "> <span className="title">Add
                          Professor</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="edit_professor" className="nav-link "> <span className="title">Edit
                          Professor</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="professor_profile" className="nav-link "> <span className="title">About
                          Professor</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">face</i>
                          <span className="title">Staff</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_staffs" className="nav-link "> <span className="title">All
                          Staff</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_staff" className="nav-link "> <span className="title">Add Staff</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="edit_staff" className="nav-link "> <span className="title">Edit
                          Staff</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="staff_profile" className="nav-link "> <span className="title">Staff
                          Profile</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="event" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">event</i>
                          <span className="title">Event Management</span>
                        </NavLink>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <i className="material-icons">airline_seat_individual_suite</i>
                          <span className="title">Holiday</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_holidays" className="nav-link "> <span className="title">All
                          Holiday</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_holiday" className="nav-link "> <span className="title">Add
                          Holiday</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="edit_holiday" className="nav-link "> <span className="title">Edit
                          Holiday</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="holiday_calendar" className="nav-link "> <span className="title">Holiday
                          Calendar</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">monetization_on</i>
                          <span className="title">Fees</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="fees_collection" className="nav-link "> <span className="title">Fees
                          Collection</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_fees" className="nav-link "> <span className="title">Add Fees </span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="fees_receipt" className="nav-link "> <span className="title">Fee
                          Receipt</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">monetization_on</i>
                          <span className="title">Marks</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="all_marks" className="nav-link "> <span className="title">All Marks</span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="add_marks" className="nav-link "> <span className="title">Add Marks </span>
                            </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="fees_receipt" className="nav-link "> <span className="title">Fee
                          Receipt</span>
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <NavLink to="event" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">event</i>
                          <span className="title">Backup</span>
                        </NavLink>
                      </li>
                      <li className="nav-item">
                        <NavLink to="/" className="nav-link nav-toggle"> <input type="checkbox" /><i className="material-icons">monetization_on</i>
                          <span className="title">User</span> <span className="arrow" />
                        </NavLink>
                        <ul className="sub-menu">
                          <li className="nav-item">
                            <NavLink to="user_list" className="nav-link "> <i className="fa fa-paper-plane" /> User List
                      </NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink to="/" className="nav-link nav-toggle">
                              <i className="fa fa-gavel" /> User 
                        <span className="arrow" />
                            </NavLink>
                            <ul className="sub-menu">
                              <li className="nav-item">
                                <NavLink to="user_" className="nav-link "> <i className="fa fa-paper-plane" /> User  List
                          </NavLink>
                              </li>
                              <li className="nav-item">
                                <NavLink to="add_user_" className="nav-link">
                                  <i className="fa fa-power-off" /> Add User </NavLink>
                              </li>
                              <li className="nav-item">
                                <NavLink to="/" className="nav-link">
                                  <i className="fa fa-power-off" /> Edit User </NavLink>
                              </li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(AddUser);