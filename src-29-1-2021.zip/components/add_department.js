import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';

class NotFound extends Component {
  render() {
    return (
      <div >
         <Helmet>
          <title>Add Department</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        Not Found</div>
    )
  }
}
export default NotFound;