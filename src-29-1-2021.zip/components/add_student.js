import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { Picky } from 'react-picky';
import DatePicker from 'react-date-picker';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { conveyanceAction, classesAction, schoolsAction, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_soft_CLASSES = `http://schools.rajpsp.com/api/classes/read_portal_classes.php`;
// const RESD_SCHOOL = `http://schools.rajpsp.com/api/school/read_one.php`;
// const READ_CONV_URL = `http://schools.rajpsp.com/api/conveyance/read.php`;
// const CREATE_STUDENT_URL = `http://schools.rajpsp.com/api/students/create.php`;

class AddStudent extends Component {
  state = {
    sch_medium: [],
    group_id: '',
    session_year_id: '',
    user_category: '',
    school_id: '',
    all_students_ids: [],
    s_id: '',
    medium: '',
    caste: '',
    student_name: '',
    father_name: '',
    mother_name: '',
    admission_number: '',
    gender: '',
    dob: '',
    estimate_date: '',
    roll_number: '',
    stu_class: '',
    software_class: '',
    free_seat: false,
    rte_stationary: false,
    is_rte_student: '',
    convence_area: '',
    message_mob: '',
    convence_discount: '',
    monthly_discount: '',
    conveyance: [],
    convence_months: [],
    convence_months_arr: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    student_image: "",
    soft_classes: [],
    current_class: '',
    formIsHalfFilledOut: false,
    crop: { unit: "%", width: 70, aspect: 1 },
    final_size: { width: 210, height: 210 }
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'convence_discount' || fieldName === 'monthly_discount') {
      const _val = event.target.value;
      if (_val < 100) {
        this.setState({
          [fieldName]: isCheckbox ? event.target.checked : event.target.value,
          formIsHalfFilledOut: true
        })
      } else {
        alert('REQUIRED BELOW 100')
      }
    } else if (fieldName === 'school') {
      // debugger
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      // const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      this.setPortalClassesBySchool(_sch_id);
    } else if (fieldName === 'stu_class') {
      const _inx = event.target.value;
      this.setSoftwareClassesData(_inx);

    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  checkHandler = (event, fieldName, value) => {
    if (fieldName === 'convence_months') {
      let _convence_month = event;
      this.setState({
        convence_months: _convence_month,
        formIsHalfFilledOut: true
      })
    }
  };

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    if (isEmptyObj(this.props.conveyance)) {
      this.props.getConveyance();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_classes = this.props.classes;
      if (_all_classes && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _classes = this.props.classes;
    const _user = this.props.user;
    if (!isEmpty(_classes) && _user.user_category !== "1") {
      const _sch_classes = _classes.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        soft_classes: _sch_classes,
      }, () => {
        this.setPortalClassesBySchool(_user.school_id)
      })
    }
  }
  setPortalClassesBySchool(sch_id) {
    const _classes = this.props.classes;
    const _school = this.props.schools;
    const _slct_school = _school.filter((item) => {
      if (item.id === sch_id) {
        return item
      }
    })
    const _slct_classes = _classes.filter((item) => {
      if (item.school_id === sch_id) {
        return item
      }
    });

    this.setState({
      soft_classes: _slct_classes,
      sch_medium: _slct_school[0].sch_medium,
      school_id: _slct_school[0].id
    })
  }
  setSoftwareClassesData(index) {
    const cls_id = (!isEmpty(index)) ? this.state.soft_classes[index].id : '';
    const all_classes = this.state.soft_classes;
    const _classData = all_classes.filter((item) => {
      if (item.id === cls_id) {
        return item
      }
    })
    // console.log(_classData);
    this.setState({
      current_class: _classData[0],
      software_class: _classData[0].class_name,
      stu_class: index,
    })
  }
  // checkAuthentication(obj) {
  //   const { match } = this.props;
  //   const current_id = match.params.id;
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //           current_id: current_id
  //         }, () => {
  //           this.getSChoolDetailHandler();
  //           this.getConvenceHandler();
  //           // this.getAllStudentIdsHandler();
  //           this.getPortalClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }
  /*
  setStudentsItsHandler() {
    // debugger
    const _current_id = this.state.current_id;
    const _student_ids = this.state.all_students_ids;
    let _prev_id = '';
    let _next_id = '';
    let _is_prev = false;
    let _is_next = false;
    let _chnage_state = false;
    for (let i = 0; i < _student_ids.length; i++) {

      if (_current_id === _student_ids[i].s_id && (i >= 0 && i < _student_ids.length)) {

        if (i === 0) {
          _prev_id = _student_ids[_student_ids.length - 1].s_id;
        } else {
          _prev_id = _student_ids[i - 1].s_id;
        }

        if (i === _student_ids.length - 1) {
          _next_id = _student_ids[0].s_id;
        } else {
          _next_id = _student_ids[i + 1].s_id;
        }


        _chnage_state = true;
        if (i == 0) {
          _is_prev = true;
        } else if (i == _student_ids.length - 1) {
          _is_next = true;
        }
        break;
      }
    }

    if (_chnage_state) {
      this.setState({
        prev_id: _prev_id,
        next_id: _next_id,
        is_prev: _is_prev,
        is_next: _is_next
      })
    }
  }
  getPrevStudentRecord(e, _id) {
    e.preventDefault();
    this.setState({
      current_id: _id
    }, () => {
      this.getStudentDetailHandler();
      this.setStudentsItsHandler();
      this.changeUrlHandler();
    })
  }
  changeUrlHandler() {
    this.props.history.push(`/edit_student.jsp/${this.state.current_id}`);
  }*/
  // getPortalClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   // debugger
  //   axios.post(GET_soft_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         soft_classes: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // };
  // classFilterByMediumHandler() {
  //   const _medium = this.state.medium;
  //   const _soft_classes = this.state.soft_classes.filter((item, inx) => {
  //     if (item.medium === _medium) {
  //       return item
  //     } else { return false }
  //   })
  //   // const _sft_classes = this.state.sft_classes.filter((item, inx) => {
  //   //   if (item.medium === _medium) {
  //   //     return item
  //   //   } else { return false }
  //   // })
  //   this.setState({
  //     soft_classes_medium: _soft_classes,
  //     // sft_classes_medium: _sft_classes
  //   })
  // }
  // getAllStudentIdsHandler() {
  //   const obj = {
  //     group_id: this.state.group_id,
  //     session_year_id: this.state.session_year_id,
  //     user_category: this.state.user_category,
  //     school_id: this.state.school_id
  //   }

  //   // console.log(JSON.stringify(obj));
  //   // debugger
  //   axios.post(READ_ALL_STU_IDS, obj)
  //     .then(res => {
  //       const resData = res.data;
  //       // console.log(resData);
  //       this.setState({
  //         all_students_ids: resData,
  //         errorMessages: resData.message
  //       }, () => {
  //         this.setStudentsItsHandler()
  //       });
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  // getConvenceHandler() {
  //   loadProgressBar();
  //   axios.get(READ_CONV_URL)
  //     .then(res => {
  //       const conveyance = res.data;
  //       this.setState({
  //         conveyance: conveyance,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.conveyance);
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  dobDate = (dob) => {
    // debugger
    this.setState({ dob });
    //this.to.openCalendar();
  };
  // getSChoolDetailHandler() {
  //   const sch_id = this.state.school_id;
  //   axios.get(RESD_SCHOOL + '?id=' + sch_id)
  //     .then(res => {
  //       const school = res.data;

  //       this.setState({
  //         sch_medium: school.sch_medium,
  //         errorMessages: school.message
  //       })
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler = e => {

    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.state.school_id }
    }
    const form_obj = {
      myObj: [{
        student_name: this.state.student_name,
        stu_class: this.state.software_class,
        software_class: this.state.software_class,
        father_name: this.state.father_name,
        mother_name: this.state.mother_name,
        medium: this.state.medium,
        admission_number: this.state.admission_number,
        roll_number: this.state.roll_number,
        student_image: this.state.student_image,
        free_seat: this.state.free_seat,
        rte_stationary: this.state.rte_stationary,
        convence_area: this.state.convence_area,
        convence_months: this.state.convence_months,
        convence_discount: this.state.convence_discount,
        monthly_discount: this.state.monthly_discount,
        message_mob: this.state.message_mob,
        dob: this.state.dob,
        gender: this.state.gender,
        caste: this.state.caste,
        is_rte_student: this.state.is_rte_student,
        // group_id: this.state.group_id,
        // session_year_id: this.state.session_year_id,
        // user_category: this.state.user_category,
        school_id: this.state.school_id
      }]
    };

    const obj = { ...form_obj, ...default_obj }
    // debugger
    // console.log(JSON.stringify(obj));
    this.props.createStudent(obj);

    // debugger
    // axios.post(CREATE_STUDENT_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes);
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       // update_student: [],
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      student_image: data
    })
  }
  render() {
    const { free_seat, sch_medium, is_rte_student, rte_stationary, roll_number, convence_area, convence_discount,
      convence_months_arr, convence_months, admission_number, father_name, mother_name, student_name,
      stu_class, dob, caste, soft_classes, monthly_discount, message_mob, crop, final_size, student_image,
      medium, formIsHalfFilledOut, gender, selected_school_index, current_class } = this.state;
    const { user, schools, classes, students, conveyance } = this.props;
     //  console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Add Student</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Add Student</div>
        </div>
        {schools && conveyance && user && classes && students &&
          <form className="card card-box sfpage-cover" onSubmit={this.confirmBoxSubmit}>
            <div className="card-body p-2 sfpage-body">
              <div className="table-scrollable">
                <div className="col-sm-12">
                  <div className="form-horizontal">
                    <div className="alert alert-dismissible alert-danger p-1">
                      <strong>Note :</strong> This entry is temporary. When you add it by upload using CSV, then it has to be managed again.
                  </div>
                    <div className="form-body">
                      <div className="row">
                        <div className="col-md-3">
                          <div className="form-groupmb-3">
                            <label className="control-label d-block pt-0 pb-2">Student Image</label>
                            <div className="col-md-12_">
                              <MyImage
                                //callbackFromParent={this.myCallback}
                                cropComplete={this.onComplete}
                                crop={crop}
                                final_size={final_size}
                              />
                              {student_image !== '' ?
                                < img src={`${process.env.PUBLIC_URL}` + student_image} className="img-thumbnail" alt={student_name} />
                                : (gender === 'Boy' ?
                                  <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                  :
                                  <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                              }
                            </div>
                          </div>
                        </div>

                        <div className="col-md-4 mt-4">

                          <div className="form-group row">
                            <label className="control-label col-5">Enr. Number :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Admission Number"
                                className="form-control form-control-sm"
                                value={admission_number}
                                required
                                onChange={event => this.changeHandler(event, `admission_number`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Student Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Student Name"
                                className="form-control form-control-sm"
                                value={student_name}
                                required
                                onChange={event => this.changeHandler(event, `student_name`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Father Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Father Name"
                                className="form-control form-control-sm"
                                value={father_name}
                                required
                                onChange={event => this.changeHandler(event, `father_name`)} />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Mother Name :</label>
                            <div className="col-7">
                              <input type="text" placeholder="Mother Name"
                                className="form-control form-control-sm"
                                value={mother_name}
                                required
                                onChange={event => this.changeHandler(event, `mother_name`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Caste</label>
                            <div className="col-7">
                              <input type="text" placeholder="Caste"
                                className="form-control form-control-sm"
                                value={caste}
                                required
                                onChange={event => this.changeHandler(event, `caste`)} />
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Mobile No. </label>
                            <div className="col-md-7">
                              <input name="message_mob" type="number" placeholder="mobile number"
                                className="form-control form-control-sm"
                                value={message_mob}
                                disabled
                                required
                                onChange={event => this.changeHandler(event, `message_mob`)} />
                              <span className="text-danger">For Message</span>
                            </div>
                          </div>


                          <div className="form-group row">
                            <label className="control-label col-5">DOB</label>
                            <div className="col-7">
                              <DatePicker
                                onChange={this.dobDate}
                                value={dob}
                                required
                                showLeadingZeroes={true}
                              //minDate={new Date()}
                              />
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Gender</label>
                            <div className="col-7">
                              {/* <input type="text" placeholder="Gender"
                              className="form-control form-control-sm"
                              value={gender}
                              onChange={event => this.changeHandler(event, `gender`)} /> */}
                              <select className="form-control form-control-sm"
                                required
                                value={gender}
                                onChange={event => this.changeHandler(event, 'gender')}>
                                <option value="">Select ...</option>
                                <option>Boy</option>
                                <option>Girl</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">Medium :</label>
                            <div className="col-7">
                              <select className="form-control form-control-sm"
                                required
                                value={medium}
                                onChange={event => this.changeHandler(event, 'medium')}>
                                <option value="">Select ...</option>
                                {sch_medium.map((item, index) => {
                                  return (
                                    <option key={index} value={item}>{item}</option>
                                  )
                                })}
                              </select>
                            </div>
                          </div>


                        </div>
                        <div className="col-md-5 mt-4">

                          {(user.user_category === '1') ?
                            <div className="form-group row">
                              <label className="control-label col-5">Schools :</label>
                              <div className="col-7">
                                <select className="form-control form-control-sm"
                                  required
                                  value={selected_school_index}
                                  onChange={event => this.changeHandler(event, 'school')}>
                                  <option value="">Select ...</option>
                                  {schools.map((item, index) => {
                                    return (
                                      <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                    )
                                  })}
                                </select>
                              </div>
                            </div>
                            : null}
                          <div className="form-group row">
                            <label className="control-label col-5">Class :</label>
                            <div className="col-7">
                              {/* <input type="text" placeholder="stu_class"
                              className="form-control form-control-sm"
                              value={stu_class}
                              onChange={event => this.changeHandler(event, `stu_class`)} /> */}
                              <select className="form-control form-control-sm"
                                value={stu_class}
                                required
                                onChange={event => this.changeHandler(event, 'stu_class')}>
                                <option value="">Select...</option>
                                {soft_classes.map((option, index) => {
                                  return (
                                    <option key={index} value={index}>{option.class_name}</option>
                                  )
                                })}
                              </select>
                              <span className="text-danger">Not for Promote Student.</span>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5"> Roll No </label>
                            <div className="col-7">
                              <input type="number" name="No" placeholder="Roll  No"
                                className="form-control form-control-sm"
                                value={roll_number}
                                onChange={event => this.changeHandler(event, `roll_number`)} />
                              <span className="text-secondary">
                                Please Insert between :
                                <span className="text-danger">{current_class.roll_num_start} </span>
                                -
                                <span className="text-danger">{current_class.roll_num_end} </span>
                              </span>
                            </div>
                          </div>



                          <div className="form-group row">
                            <label className="control-label col-5">Is RTE Student</label>
                            <div className="col-7">
                              <select className="form-control form-control-sm"
                                required
                                value={is_rte_student}
                                onChange={event => this.changeHandler(event, 'is_rte_student')}>
                                <option value="">Select ...</option>
                                <option>No</option>
                                <option>Yes</option>
                              </select>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-5">Student Type</label>
                            <div className="col-7">
                              <div className="custom-control custom-checkbox mt-2 mb-2">
                                <input type="checkbox" className="custom-control-input" id={`switch_`}
                                  checked={(free_seat ? true : false)}
                                  onChange={event => this.changeHandler(event, `free_seat`, true)} />
                                <label className={'custom-control-label label label-sm ' + ((free_seat) ? 'label-info' :
                                  'label-danger')} htmlFor={`switch_`}>
                                  {(free_seat) ? 'Paid' : 'Free'}</label>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-5">RTE Stationary</label>
                            <div className="col-7">
                              <div className="custom-control custom-checkbox  mt-2 mb-2">
                                <input type="checkbox" className="custom-control-input" id={`stationary_`}
                                  checked={rte_stationary ? true : false}
                                  onChange={event => this.changeHandler(event, `rte_stationary`, true)} />
                                <label className={"custom-control-label label label-sm " + ((rte_stationary) ? 'label-warning' :
                                  'label-sucess')} htmlFor={`stationary_`}>
                                  {(rte_stationary) ? 'Done' : 'Pending'}</label>
                              </div>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence </label>
                            <div className="col-md-7">
                              <select className="form-control form-control-sm" name="proff"
                                value={convence_area}
                                onChange={event => this.changeHandler(event, `convence_area`)} >
                                <option value>Select...</option>
                                {conveyance.map((option, index) => {
                                  return (
                                    <option key={index}
                                      value={option.stoppage_name}>{option.stoppage_name} [{option.stoppage_amo}] </option>
                                  )
                                })}
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence Months </label>
                            <div className="col-md-7">
                              <div className="row">
                                <Picky
                                  disabled={(convence_area === '' ? true : false)}
                                  className="col-9 pr-0"
                                  value={convence_months}
                                  options={convence_months_arr}
                                  onChange={event => this.checkHandler(event, `convence_months`)}
                                  open={false}
                                  valueKey="id"
                                  labelKey="name"
                                  multiple={true}
                                  includeSelectAll={true}
                                  includeFilter={true}
                                  dropdownHeight={200}
                                />
                                <div className="col-3 pl-0">
                                  <button type="button" className="btn btn-block btn-primary btn-sm"><i className="fas fa-check"></i></button>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="control-label col-md-5">Convence Discount  </label>
                            <div className="col-md-7">
                              <div className="input-group">
                                <input name="convence_discount" type="number" placeholder="Discount in Convence payment"
                                  className="form-control form-control-sm"
                                  value={convence_discount}
                                  onChange={event => this.changeHandler(event, `convence_discount`)} />
                                <div className="input-group-append">
                                  <span className="input-group-text  pt-1 pb-1">%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-5">Monthly Discount </label>
                            <div className="col-md-7">
                              <div className="input-group">
                                <input name="monthly_discount" type="number" placeholder="Discount in Monthly Payment"
                                  className="form-control form-control-sm"
                                  value={monthly_discount}
                                  onChange={event => this.changeHandler(event, `monthly_discount`)} />
                                <div className="input-group-append">
                                  <span className="input-group-text pt-1 pb-1">%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer d-flex p-2">
              {/* <button type="button"
              onClick={event => this.getPrevStudentRecord(event, prev_id)}
              disabled={is_prev}
              className="btn btn-primary text-white">
              <i className="fa fa-angle-left"></i>
            </button>
            <button type="button"
              onClick={event => this.getPrevStudentRecord(event, next_id)}
              disabled={is_next}
              className="btn btn-primary ml-3 text-white">
              <i className="fa fa-angle-right"></i>
            </button> */}
              <button type="submit"
                // disabled={!formIsHalfFilledOut}
                className="btn btn-primary mr-2 ml-auto">Submit</button>
              <NavLink to="/all_students.jsp" className="btn btn-danger">All Student</NavLink>
            </div>
          </form>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: conveyance } = state.conveyance;
  const { item: classes } = state.classes;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  const filteredSchoolData = state.filteredSchoolData;
  return { user, conveyance, classes, schools, students, filteredSchoolData };
}

const actionCreators = {
  getConveyance: conveyanceAction.getConveyance,
  getClasses: classesAction.getClasses,
  getSchools: schoolsAction.getSchools,
  createStudent: studentsAction.create,
  getStudents: studentsAction.getStudents,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddStudent));