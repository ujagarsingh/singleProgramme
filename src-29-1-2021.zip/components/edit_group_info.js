import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import { Picky } from 'react-picky';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import MyImage from '../utility/my_image';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/group/read_one.php`;
// const UPDATE_URL = `http://schools.rajpsp.com/api/group/update.php`;

class EditGroupInfo extends Component {
  state = {
    id: '',
    user_name: '',
    reg_no: '',
    mobile: '',
    email: '',
    address: '',
    admin_img: '',
    logo: '',
    wel_mes_title: '',
    wel_mes: '',
    session_year_id: '',
    crop: { unit: "%", width: 30, aspect: 1 },
    final_size: { width: 400, height: 400 },
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    // const token = sessionStorage.getItem('jwt');
    // const obj = { "jwt": token };
    // this.checkAuthentication(obj);
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.group;
    // console.log(obj);
    // debugger;

    this.setState({
      id: obj.id,
      user_name: obj.user_name,
      reg_no: obj.reg_no,
      mobile: obj.mobile,
      email: obj.email,
      address: obj.address,
      logo: obj.logo,
      admin_img: obj.admin_img,
      wel_mes_title: obj.wel_mes_title,
      wel_mes: obj.wel_mes,
      session_year_id: obj.session_year_id
    })
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getGroupInfoHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getGroupInfoHandler() {
  //   loadProgressBar();
  //   const group_id = this.state.group_id;

  //   axios.post(READ_URL + `?id=` + group_id)
  //     .then(res => {
  //       const getRes = res.data;
  //       console.log(getRes);
  //       this.setState({
  //         id: getRes.id,
  //         user_name: getRes.user_name,
  //         reg_no: getRes.reg_no,
  //         mobile: getRes.mobile,
  //         email: getRes.email,
  //         address: getRes.address,
  //         logo: getRes.logo,
  //         admin_img: getRes.admin_img,
  //         wel_mes_title: getRes.wel_mes_title,
  //         wel_mes: getRes.wel_mes,
  //         session_year_id: getRes.session_year_id
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };

  // child (my_image.js) component to get image
  onCompleteLogo = (data) => {
    this.setState({
      logo: data,
      formIsHalfFilledOut: true
    })
  };

  // child (my_image.js) component to get image
  onCompleteAadminImage = (data) => {
    this.setState({
      admin_img: data,
      formIsHalfFilledOut: true
    })
  };

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    loadProgressBar();
    //e.preventDefault();
    const obj = {
      id: this.state.id,
      user_name: this.state.user_name,
      reg_no: this.state.reg_no,
      mobile: this.state.mobile,
      email: this.state.email,
      address: this.state.address,
      logo: this.state.logo,
      admin_img: this.state.admin_img,
      wel_mes_title: this.state.wel_mes_title,
      wel_mes: this.state.wel_mes,
      session_year_id: this.state.session_year_id,
    }
    console.log(JSON.stringify(obj))
    // axios.post(UPDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }

  render() {
    const { user_name, reg_no, mobile, email, address, logo, admin_img, wel_mes_title, wel_mes,
      session_year_id, crop, final_size, formIsHalfFilledOut } = this.state;
    const { group, user } = this.props;
    //console.log(this.state)
    return (
      <form className="card card-box sfpage-cover card-form card-edit"
        onSubmit={event => this.confirmBoxSubmit(event)}>
        <Helmet>
          <title>Update Group Biography</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="card-header">Update Group Biography</div>
        <div className="card-body sfpage-body">
          <div className="table-scrollable">
            <div className="form-horizontal">
              <div className="form-body col">
                <div className="row">
                  <div className="col-sm-7">
                    <div className="form-group row">
                      <label className="control-label col-md-4">Super Admin Name
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <input type="text" name="user_name" placeholder="Admin Super name"
                          className="form-control form-control-sm"
                          value={user_name}
                          onChange={event => this.changeHandler(event, `user_name`)} />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Registratin Number
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <input type="text" name="reg_no"
                          placeholder="" className="form-control form-control-sm"
                          value={reg_no}
                          onChange={event => this.changeHandler(event, `reg_no`)} />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Session Year
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <select className="form-control form-control-sm"
                          required
                          value={session_year_id}
                          onChange={event => this.changeHandler(event, 'session_year_id')}>
                          <option >Select ...</option>
                          <option value="2019-2020">2019-2020</option>
                          <option value="2020-2021">2020-2021</option>
                        </select>
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Email Address</label>
                      <div className="col-md-8">
                        <div className="input-group">
                          <div className="input-group-prepend">
                            <span className="input-group-text"><i className="fa fa-envelope" /></span>
                          </div>
                          <input type="email" className="form-control form-control-sm"
                            name="email" placeholder="Email Address"
                            value={email}
                            onChange={event => this.changeHandler(event, `email`)} /> </div>
                      </div>
                    </div>

                    <div className="form-group row">
                      <label className="control-label col-md-4">Mobile No.
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <input type="text" name="mobile"
                          placeholder="mobile number" className="form-control form-control-sm"
                          value={mobile}
                          onChange={event => this.changeHandler(event, `mobile`)} /> </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Address
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <textarea name="address" placeholder="address"
                          className="form-control-textarea form-control" rows={3}
                          value={address}
                          onChange={event => this.changeHandler(event, `address`)} />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Welcome Message Title
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <input type="text" name="wel_mes_title"
                          placeholder="welcome message title" className="form-control form-control-sm"
                          value={wel_mes_title}
                          onChange={event => this.changeHandler(event, `wel_mes_title`)} /> </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-4">Welcome Message
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-8">
                        <textarea name="wel_mes" placeholder="welcome message"
                          className="form-control-textarea form-control" rows={5}
                          value={wel_mes}
                          onChange={event => this.changeHandler(event, `wel_mes`)} />
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-4 ml-auto">
                    <div className="form-group row">
                      <label className="control-label col-md-6">Group Logo</label>
                      <div className="col-md-6">
                        <MyImage
                          //callbackFromParent={this.myCallback}
                          cropComplete={this.onCompleteLogo}
                          crop={crop}
                          final_size={final_size}
                        />
                        {logo !== '' ?
                          <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + logo} />
                          : null}
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-6">Admin Image</label>
                      <div className="col-md-6">
                        <MyImage
                          //callbackFromParent={this.myCallback}
                          cropComplete={this.onCompleteAadminImage}
                          crop={crop}
                          final_size={final_size}
                        />
                        {admin_img !== '' ?
                          <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + admin_img} />
                          : null}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="card-footer text-right">
          <button
            disabled={!formIsHalfFilledOut}
            type="submit" className="btn btn-sm btn-primary mr-2">Update</button>
          {/* <NavLink to="dashboard.jsp" className="btn btn-sm btn-danger">Back</NavLink> */}
          <button onClick={event => this.props.closeEdit(event)} className="btn btn-sm btn-warning">
            Exit </button>
        </div>
      </form>
    )
  }
}

export default withRouter(EditGroupInfo);