import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
// import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class FrontIndexGallery extends Component {
   render() {
      return (
         <div className="section-paddings gallery-images event-01">
            <div className="container">
               <div className="row">
                  <div className="col-sm-12 section-header-box">
                     <div className="section-header">
                        <h2>Image Gallery</h2>
                     </div>{/* ends: .section-header */}
                  </div>
               </div>
               <div className="row gallery_img_wrapper">
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-01.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-01.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Michel Jusi</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-02.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-02.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Daniel Baci</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-01.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-03.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>John Adam</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-04.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-04.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Michel Jusi</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-05.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-05.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Daniel Baci</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-06.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-06.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>John Adam</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-01.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-01.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Michel Jusi</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-02.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-02.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>Daniel Baci</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
                  <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                     <div className="single-gallery">
                        <figure>
                           <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images-04/courses-01.jpg`}  />
                           <figcaption>
                              <NavLink to={`${process.env.PUBLIC_URL}/images/index-04/courses-03.jpg`} title="">Show</NavLink>
                              <h4>Caption <span>Education Class</span></h4>
                              <h3>Caption By: <span>John Adam</span></h3>
                           </figcaption>
                        </figure>
                     </div>
                  </div> {/* end single-gallery */}
               </div>
            </div>
         </div>
      )
   }
}
export default withRouter(FrontIndexGallery);