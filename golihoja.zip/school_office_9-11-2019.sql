-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2019 at 03:33 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `description`) VALUES
(1, 'Mission', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum interdum  '),
(2, 'Infrastructure', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum interdum diam non mi cursus venenatis. Morbi lacinia libero et elementum vulputate. Vivamus et facilisis mauris. Maecenas nec massa auctor, ultricies massa eu, tristique erat. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Eu pellentesque, accumsan tellus leo, ultrices mi dui lectus sem nulla eu.Eu pellentesque, accumsan tellus leo, ultrices mi dui'),
(3, 'School Profile', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum interdum diam non mi cursus venenatis. Morbi lacinia libero et elementum vulputate. Vivamus et facilisis mauris. Maecenas nec massa auctor, ultricies massa eu, tristique erat. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Eu pellentesque, accumsan tellus leo, ultrices mi dui lectus sem nulla eu.Eu pellentesque, accumsan tellus leo, ultrices mi dui');

-- --------------------------------------------------------

--
-- Table structure for table `class_info`
--

CREATE TABLE `class_info` (
  `id` int(11) NOT NULL,
  `class_name` varchar(10) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `is_section` varchar(5) NOT NULL DEFAULT 'No',
  `parent_class` varchar(10) DEFAULT NULL,
  `class_name_portal` varchar(10) DEFAULT NULL,
  `roll_num_start` varchar(10) DEFAULT NULL,
  `roll_num_end` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_info`
--

INSERT INTO `class_info` (`id`, `class_name`, `medium`, `is_section`, `parent_class`, `class_name_portal`, `roll_num_start`, `roll_num_end`) VALUES
(2, 'UKG', 'Hindi', 'No', NULL, 'PP.5+', '5100', '5199'),
(5, '3', 'English', 'No', NULL, 'Third', '300', '399'),
(21, 'LKG', 'Hindi', 'No', NULL, 'PP.4+', '', ''),
(22, 'First', 'Hindi', 'No', NULL, 'First', '', ''),
(23, '2', 'Hindi', 'No', NULL, 'Second', '', ''),
(24, '4', 'Hindi', 'No', NULL, 'Fourth', '', ''),
(25, '5', 'Hindi', 'No', NULL, 'Fifth', '', ''),
(26, '6', 'English', 'No', NULL, 'Sixth', '', ''),
(27, '7', 'Hindi', 'No', NULL, 'Seventh', '', ''),
(28, '8', 'Hindi', 'No', NULL, 'Eigth', '', ''),
(29, '9', 'Hindi', 'No', NULL, 'Ninth', '', ''),
(30, '10', 'English', 'Yes', NULL, 'Tenth', '', ''),
(31, 'Tenth A', 'Hindi', 'No', NULL, 'Tenth', '1500', '1500'),
(32, 'Tenth B', 'Hindi', 'No', NULL, 'Tenth', '', ''),
(33, 'LKG', 'English', 'No', NULL, 'PP.4+', '100', '800'),
(34, '3', 'Hindi', 'No', NULL, 'Third', '100', '199');

-- --------------------------------------------------------

--
-- Table structure for table `conveyance_info`
--

CREATE TABLE `conveyance_info` (
  `id` int(11) NOT NULL,
  `stoppage_name` varchar(15) DEFAULT NULL,
  `stoppage_amo` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conveyance_info`
--

INSERT INTO `conveyance_info` (`id`, `stoppage_name`, `stoppage_amo`) VALUES
(1, 'Andhi', 200),
(2, 'Tholai', 300),
(3, 'Rampura', 300),
(4, 'Bhondakhera', 350),
(5, 'Birasana', 425),
(6, 'jaipur', 123);

-- --------------------------------------------------------

--
-- Table structure for table `depo_amo_record`
--

CREATE TABLE `depo_amo_record` (
  `id` int(11) NOT NULL,
  `student_id` int(10) DEFAULT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_class` varchar(10) NOT NULL,
  `fee_amount` int(10) DEFAULT NULL,
  `total_amount` int(10) DEFAULT NULL,
  `balance_amount` int(10) DEFAULT NULL,
  `discount` int(5) NOT NULL,
  `deposit_date` date DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(250) NOT NULL,
  `verify` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depo_amo_record`
--

INSERT INTO `depo_amo_record` (`id`, `student_id`, `student_name`, `student_class`, `fee_amount`, `total_amount`, `balance_amount`, `discount`, `deposit_date`, `server_date_time`, `description`, `verify`) VALUES
(102, 478, 'ADITIYA SHARMA', '3', 1150, 1150, 0, 0, '2019-10-06', '2019-10-06 10:44:18', 'ADITIYA SHARMA of 3 Deposited fee : , Monthly : July, Sport Fee, Reg. Fee, Amount : 1150', 1),
(103, 425, 'ANUPRIYA MEENA', '3', 1000, 1000, 0, 0, '2019-11-07', '2019-10-06 10:45:08', 'ANUPRIYA MEENA of 3 Deposited fee : , Monthly : July, August, Amount : 1000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `emp_info_extra`
--

CREATE TABLE `emp_info_extra` (
  `id` int(11) NOT NULL,
  `emp_id_portal` int(10) DEFAULT NULL,
  `profile_image` varchar(100) DEFAULT NULL,
  `responsibility` varchar(200) DEFAULT NULL,
  `class_teacher` varchar(20) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `show_home` varchar(5) NOT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_info_extra`
--

INSERT INTO `emp_info_extra` (`id`, `emp_id_portal`, `profile_image`, `responsibility`, `class_teacher`, `medium`, `address`, `show_home`, `server_date_time`) VALUES
(1, 15, '/assets/images/professionals/5TZ37GHH2H_Z.jpg', '', '10', '', 'Jaipur', '1', '0000-00-00 00:00:00'),
(2, 16, '/assets/images/professionals/ZENPOL8WKZKZ.jpg', 'test ', 'Second', 'English', 'Jaipur', '1', '0000-00-00 00:00:00'),
(3, 17, '/assets/images/professionals/1PXFHJBWL3DT.jpg', 'test test', '7', 'English', 'test', '1', '0000-00-00 00:00:00'),
(4, 18, '', '', '', 'English', '', '1', '0000-00-00 00:00:00'),
(5, 19, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(6, 20, '', '', '', 'English', '', '', '0000-00-00 00:00:00'),
(7, 21, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(8, 22, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(9, 23, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(10, 24, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(11, 25, '', '', '', 'English', '', '', '0000-00-00 00:00:00'),
(12, 26, '', '', '', 'English', '', '', '0000-00-00 00:00:00'),
(13, 27, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00'),
(14, 28, '', '', '', 'Hindi', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `emp_info_portal`
--

CREATE TABLE `emp_info_portal` (
  `id` int(11) NOT NULL,
  `emp_type` varchar(15) DEFAULT NULL,
  `emp_crnt_designation` varchar(30) DEFAULT NULL,
  `emp_name` varchar(30) DEFAULT NULL,
  `emp_f_name` varchar(30) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `caste` varchar(10) DEFAULT NULL,
  `edu_qulifi` varchar(50) DEFAULT NULL,
  `pacific_ability` varchar(20) DEFAULT NULL,
  `is_rtet_qlifid` varchar(5) DEFAULT NULL,
  `appoint_date` date DEFAULT NULL,
  `emp_mob` varchar(15) DEFAULT NULL,
  `emp_cur_sub` varchar(30) DEFAULT NULL,
  `relieve_date` date DEFAULT NULL,
  `relieve_status` varchar(100) DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_info_portal`
--

INSERT INTO `emp_info_portal` (`id`, `emp_type`, `emp_crnt_designation`, `emp_name`, `emp_f_name`, `dob`, `gender`, `caste`, `edu_qulifi`, `pacific_ability`, `is_rtet_qlifid`, `appoint_date`, `emp_mob`, `emp_cur_sub`, `relieve_date`, `relieve_status`, `server_date_time`) VALUES
(15, 'Teaching', 'Prinicipal', 'TANVI DESHMUKH', 'SHIVRAJ DESHMUKH', '1983-06-04', 'Female', 'GENERAL', 'Post Graduate', 'B.Ed.', 'No', '2016-08-01', '9782581389', 'Social Studies', '0000-00-00', '', '0000-00-00 00:00:00'),
(16, 'Teaching', 'TGT Or Senior Teacher', 'JAGJIVAN PRASAD SHARMA', 'GIRIRAJ PRASAD SHARMA', '1991-02-01', 'Male', 'GENERAL', 'Post Graduate', 'B.Ed.', 'No', '2017-07-01', '7791943197', 'Sanskrit', '0000-00-00', '', '0000-00-00 00:00:00'),
(17, 'Teaching', 'Computer Operator', 'SONIYA GUPTA', 'SUBHASH CHANDRA GUPTA', '1996-05-11', 'Female', 'GENERAL', 'Graduate', 'No Any Qualification', 'No', '2016-07-01', '7357271664', 'Mathematics', '0000-00-00', '', '0000-00-00 00:00:00'),
(18, 'Teaching', 'PGT Or Lecturer', 'SHIKHA KHANDELAL', 'BRIJ BIHARI KHANDELWAL', '1994-07-16', 'Female', 'GENERAL', 'Post Graduate', 'B.Ed.', 'No', '2014-11-01', '7737585898', 'English', '0000-00-00', '', '0000-00-00 00:00:00'),
(19, 'Teaching', 'TGT Or Senior Teacher', 'BHAWANA SHARMA', 'LALLU RAM SHARMA', '1994-08-02', 'Female', 'GENERAL', 'Graduate', 'B.Ed.', 'No', '2015-07-01', '7220988460', 'English', '0000-00-00', '', '0000-00-00 00:00:00'),
(20, 'Teaching', 'TGT Or Senior Teacher', 'TEJ PRAKASH SONI', 'BABU LAL SONI', '1992-07-24', 'Male', 'OBC', 'Post Graduate', 'B.Ed.', 'No', '2014-07-01', '9680308347', 'Mathematics', '0000-00-00', '', '0000-00-00 00:00:00'),
(21, 'Teaching', 'TGT Or Senior Teacher', 'MANISHA SHARMA', 'GIRRIRAJ SHARMA', '1996-08-01', 'Female', 'GENERAL', 'Graduate', 'B.Ed.', 'No', '2017-07-01', '7062464094', 'Hindi', '0000-00-00', '', '0000-00-00 00:00:00'),
(22, 'Teaching', 'Teacher Level 2', 'MEENA SHARMA', 'NATHU LAL SHARMA', '1995-10-15', 'Female', 'GENERAL', 'Graduate', 'B.Ed.', 'No', '2017-07-01', '9799807311', 'Social Studies', '0000-00-00', '', '0000-00-00 00:00:00'),
(23, 'NonTeaching', 'Lab Assistant', 'RAM BABU SHARMA', 'SURAJ MAL SHARMA', '1972-09-11', 'Male', 'GENERAL', 'Graduate', 'No Any Qualification', 'No', '2017-06-21', '9799199735', 'Not Applicable', '0000-00-00', '', '0000-00-00 00:00:00'),
(24, 'NonTeaching', 'Art Teacher', 'NEHA SHARMA', 'SHIV DAYAL SHARMA', '1998-08-29', 'Female', 'GENERAL', 'Senior Sec. Or Higher Sec.', 'No Any Qualification', 'No', '2017-06-21', '7568775312', 'Not Applicable', '0000-00-00', '', '0000-00-00 00:00:00'),
(25, 'NonTeaching', 'Office Assistant', 'NEELAM DESHMUKH', 'SHIVRAM GUPTA', '1954-01-17', 'Female', 'GENERAL', 'Graduate', 'No Any Qualification', 'No', '2014-07-01', '9057943840', 'Not Applicable', '0000-00-00', '', '0000-00-00 00:00:00'),
(26, 'Teaching', 'TGT Or Senior Teacher', 'MANASVI DESHMUKH', 'SHIV RAJ DESHMUKH', '1987-10-18', 'Female', 'GENERAL', 'Post Graduate', 'B.Ed.', 'No', '2017-07-01', '8233178224', 'Science', '2017-07-31', '', '0000-00-00 00:00:00'),
(27, 'Teaching', 'Teacher Level 2', 'KAMALA MAHAWAR', 'MANNA LAL', '1993-07-07', 'Female', 'SC', 'Graduate', 'BSTC', 'No', '2017-07-01', '8890933640', 'Hindi (Compulsary)', '2017-07-31', '', '0000-00-00 00:00:00'),
(28, 'Teaching', 'Teacher Level 2', 'VIDHYA SHARMA', 'HANUMAN SAHAY SHARMA', '1995-04-12', 'Female', 'GENERAL', 'Graduate', 'BSTC', 'Yes', '2015-07-01', '8290086378', 'Social Studies', '2017-06-30', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `description` text,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `event_img` varchar(100) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `medium` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `date_start`, `date_end`, `event_img`, `type`, `medium`) VALUES
(6, 'Celebrating Indian Army', 'Lorem ipsum dolor sit amet mollis felis dapibus arcur donec viverra phasellus eget. Etiam maecenas vel vici quis dictum rutrum nec nisi et. Ac penatibus aenean laoreet Pede enim nunc ultricies quis rhoncus.', '2019-08-14', '2019-08-20', '/assets/images/events/EMDHZAUBT_K1.jpg', 'Event', 'Hindi'),
(7, 'Basic UI & UX Design for new development', 'Lorem ipsum dolor sit amet mollis felis dapibus arcur donec viverra phasellus eget. Etiam maecenas vel vici quis dictum rutrum nec nisi et. Ac penatibus aenean laoreet Pede enim nunc ultricies quis rhoncus.', '2019-08-29', '2019-08-30', '', 'Event', ''),
(22, 'Future of film company test', 'tst test', '2019-11-13', '2019-11-14', '/assets/images/events/O1ASMQTPSZR_.jpg', 'Event', 'Hindi'),
(25, 'Future of film company test', 'tst test', '2019-11-13', '2019-11-14', '/assets/images/events/4K2OAPSD6NQ_.jpg', 'Event', 'Hindi');

-- --------------------------------------------------------

--
-- Table structure for table `exam_info`
--

CREATE TABLE `exam_info` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(100) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `exam_priority` varchar(2) DEFAULT NULL,
  `exam_start` date DEFAULT NULL,
  `exam_end` date DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_info`
--

INSERT INTO `exam_info` (`id`, `exam_name`, `medium`, `exam_priority`, `exam_start`, `exam_end`, `server_date_time`) VALUES
(2, 'Second Test', 'English', '2', '2019-09-12', '2019-09-19', '2019-09-12 03:01:41'),
(3, 'First Test', 'English', '1', '2019-09-12', '2019-09-27', '2019-09-12 03:03:02'),
(12, 'Half Yearly', 'English', '3', '2019-09-26', '2019-09-28', '2019-09-14 15:18:17'),
(14, 'Third Test', 'English', '3', '2019-10-15', '2019-10-24', '2019-10-08 17:39:38'),
(15, 'fifth test  test', 'English', '5', '2019-10-15', '2019-10-17', '2019-10-08 17:42:10'),
(16, 'First Test', 'Hindi', '1', '2019-10-25', '2019-10-25', '2019-10-25 01:40:48'),
(17, 'Second Test', 'Hindi', '2', '2019-10-25', '2019-11-05', '2019-10-25 03:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `exam_marks_info`
--

CREATE TABLE `exam_marks_info` (
  `id` int(11) NOT NULL,
  `class_id` varchar(5) DEFAULT NULL,
  `exam_id` varchar(5) DEFAULT NULL,
  `sub_id` varchar(5) DEFAULT NULL,
  `max_marks` varchar(5) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_marks_info`
--

INSERT INTO `exam_marks_info` (`id`, `class_id`, `exam_id`, `sub_id`, `max_marks`, `medium`, `server_date_time`) VALUES
(22, '5', '3', '211', '15', '', '2019-09-21 16:15:47'),
(23, '5', '2', '211', '20', '', '2019-09-21 16:15:47'),
(24, '5', '12', '211', '100', '', '2019-09-21 16:15:47'),
(52, '5', '3', '247', '10', '', '2019-09-24 22:52:57'),
(53, '5', '3', '248', '10', '', '2019-09-24 22:52:57'),
(54, '5', '3', '250', '5', '', '2019-09-24 22:52:57'),
(55, '5', '3', '251', '5', '', '2019-09-24 22:52:57'),
(56, '5', '2', '247', '10', '', '2019-09-24 22:52:57'),
(57, '5', '2', '248', '10', '', '2019-09-24 22:52:57'),
(58, '5', '2', '250', '5', '', '2019-09-24 22:52:57'),
(59, '5', '2', '251', '5', '', '2019-09-24 22:52:57'),
(60, '5', '12', '247', '70', '', '2019-09-24 22:52:57'),
(61, '5', '12', '248', '70', '', '2019-09-24 22:52:57'),
(62, '5', '12', '250', '35', '', '2019-09-24 22:52:57'),
(63, '5', '12', '251', '35', '', '2019-09-24 22:52:57'),
(64, '5', '3', '247', '10', '', '2019-10-26 00:11:02'),
(65, '5', '3', '248', '10', '', '2019-10-26 00:11:02'),
(66, '5', '3', '250', '5', '', '2019-10-26 00:11:02'),
(67, '5', '3', '251', '5', '', '2019-10-26 00:11:02'),
(68, '5', '16', '247', '10', '', '2019-10-26 00:11:02'),
(69, '5', '16', '248', '10', '', '2019-10-26 00:11:02'),
(70, '5', '16', '250', '5', '', '2019-10-26 00:11:02'),
(71, '5', '16', '251', '5', '', '2019-10-26 00:11:02'),
(72, '5', '2', '247', '10', '', '2019-10-26 00:11:02'),
(73, '5', '2', '248', '10', '', '2019-10-26 00:11:02'),
(74, '5', '2', '250', '5', '', '2019-10-26 00:11:02'),
(75, '5', '2', '251', '5', '', '2019-10-26 00:11:02'),
(76, '5', '17', '247', '10', '', '2019-10-26 00:11:02'),
(77, '5', '17', '248', '10', '', '2019-10-26 00:11:02'),
(78, '5', '17', '250', '5', '', '2019-10-26 00:11:02'),
(79, '5', '17', '251', '5', '', '2019-10-26 00:11:02'),
(80, '5', '12', '247', '50', '', '2019-10-26 00:11:02'),
(81, '5', '12', '248', '50', '', '2019-10-26 00:11:02'),
(82, '5', '12', '250', '25', '', '2019-10-26 00:11:02'),
(83, '5', '12', '251', '25', '', '2019-10-26 00:11:02'),
(84, '5', '14', '247', '10', '', '2019-10-26 00:11:02'),
(85, '5', '14', '248', '10', '', '2019-10-26 00:11:02'),
(86, '5', '14', '250', '5', '', '2019-10-26 00:11:02'),
(87, '5', '14', '251', '5', '', '2019-10-26 00:11:02'),
(88, '5', '15', '247', '15', '', '2019-10-26 00:11:02'),
(89, '5', '15', '248', '15', '', '2019-10-26 00:11:02'),
(90, '5', '15', '250', '10', '', '2019-10-26 00:11:02'),
(91, '5', '15', '251', '10', '', '2019-10-26 00:11:02'),
(92, '2', '16', '257', '10', '', '2019-10-26 09:04:39'),
(93, '2', '17', '257', '10', '', '2019-10-26 09:04:39'),
(94, NULL, NULL, NULL, NULL, '', '2019-10-27 05:15:46'),
(95, NULL, NULL, NULL, NULL, '', '2019-10-27 08:05:54'),
(96, NULL, NULL, NULL, NULL, '', '2019-10-27 08:07:15'),
(97, '34', '16', '258', '010', '', '2019-10-27 08:07:40'),
(98, '34', '16', '259', '10', '', '2019-10-27 08:07:40'),
(99, '34', '16', '260', '10', '', '2019-10-27 08:07:40'),
(100, '34', '16', '261', '10', '', '2019-10-27 08:07:40'),
(101, '34', '16', '262', '10', '', '2019-10-27 08:07:40'),
(102, '34', '17', '258', '0', '', '2019-10-27 08:07:40'),
(103, '34', '17', '259', '0', '', '2019-10-27 08:07:40'),
(104, '34', '17', '260', '0', '', '2019-10-27 08:07:40'),
(105, '34', '17', '261', '0', '', '2019-10-27 08:07:40'),
(106, '34', '17', '262', '0', '', '2019-10-27 08:07:40'),
(107, '34', '16', '258', '10', '', '2019-10-27 08:07:58'),
(108, '34', '16', '259', '10', '', '2019-10-27 08:07:58'),
(109, '34', '16', '260', '10', '', '2019-10-27 08:07:58'),
(110, '34', '16', '261', '10', '', '2019-10-27 08:07:58'),
(111, '34', '16', '262', '10', '', '2019-10-27 08:07:58'),
(112, '34', '17', '258', '0', '', '2019-10-27 08:07:58'),
(113, '34', '17', '259', '0', '', '2019-10-27 08:07:58'),
(114, '34', '17', '260', '0', '', '2019-10-27 08:07:58'),
(115, '34', '17', '261', '0', '', '2019-10-27 08:07:58'),
(116, '34', '17', '262', '0', '', '2019-10-27 08:07:58'),
(117, NULL, NULL, NULL, NULL, '', '2019-10-27 08:10:23'),
(118, NULL, NULL, NULL, NULL, '', '2019-10-27 08:11:54'),
(119, NULL, NULL, NULL, NULL, '', '2019-10-27 08:12:07'),
(120, NULL, NULL, NULL, NULL, '', '2019-10-27 08:12:42'),
(121, NULL, NULL, NULL, NULL, '', '2019-10-27 08:17:35'),
(122, NULL, NULL, NULL, NULL, '', '2019-10-27 08:20:15'),
(123, '34', '16', '258', '10', '', '2019-10-27 08:20:41'),
(124, '34', '16', '259', '10', '', '2019-10-27 08:20:41'),
(125, '34', '16', '260', '10', '', '2019-10-27 08:20:41'),
(126, '34', '16', '261', '10', '', '2019-10-27 08:20:41'),
(127, '34', '16', '262', '10', '', '2019-10-27 08:20:41'),
(128, '34', '17', '258', '10', '', '2019-10-27 08:20:41'),
(129, '34', '17', '259', '10', '', '2019-10-27 08:20:41'),
(130, '34', '17', '260', '10', '', '2019-10-27 08:20:41'),
(131, '34', '17', '261', '10', '', '2019-10-27 08:20:41'),
(132, '34', '17', '262', '10', '', '2019-10-27 08:20:41');

-- --------------------------------------------------------

--
-- Table structure for table `exam_marks_obtain`
--

CREATE TABLE `exam_marks_obtain` (
  `id` int(11) NOT NULL,
  `roll_number` varchar(10) DEFAULT NULL,
  `admission_number` varchar(10) NOT NULL,
  `class_id` varchar(5) DEFAULT NULL,
  `exam_id` varchar(5) DEFAULT NULL,
  `sub_id` varchar(5) DEFAULT NULL,
  `marks_obtain` varchar(5) DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fee_amount`
--

CREATE TABLE `fee_amount` (
  `id` int(11) NOT NULL,
  `class_id` int(10) DEFAULT NULL,
  `fee_category_id` int(10) DEFAULT NULL,
  `fee_amount` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee_amount`
--

INSERT INTO `fee_amount` (`id`, `class_id`, `fee_category_id`, `fee_amount`) VALUES
(1, 5, 1, '500'),
(3, 2, 1, '500'),
(4, 5, 2, '400'),
(5, 5, 3, '300'),
(6, 5, 4, '200'),
(7, 5, 5, '100'),
(8, 5, 6, '250');

-- --------------------------------------------------------

--
-- Table structure for table `fee_cat_info`
--

CREATE TABLE `fee_cat_info` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(30) DEFAULT NULL,
  `cat_type` varchar(20) DEFAULT NULL,
  `collect_time` varchar(200) DEFAULT NULL,
  `server_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee_cat_info`
--

INSERT INTO `fee_cat_info` (`id`, `cat_name`, `cat_type`, `collect_time`, `server_time`) VALUES
(1, 'Monthly', 'multiple', 'yes', '2019-10-11 00:16:33'),
(2, 'Registration', 'multiple', 'no', '2019-10-11 00:16:33'),
(3, 'Toution', 'yes', 'no', '2019-10-11 00:16:33'),
(4, 'Convence', 'yes', 'yes', '2019-10-11 00:16:33'),
(5, 'Exam', 'no', 'no', '2019-10-11 00:16:33'),
(6, 'Sports', 'multiple', ',July,August', '2019-10-11 00:16:33'),
(9, 'Library', 'multiple', 'July,August,September,October,November,December,January,February,March,April,May,June', '2019-10-11 00:36:22');

-- --------------------------------------------------------

--
-- Table structure for table `front_slider`
--

CREATE TABLE `front_slider` (
  `id` int(11) NOT NULL,
  `main_image` varchar(100) DEFAULT NULL,
  `title_1a` varchar(50) DEFAULT NULL,
  `title_1b` varchar(50) DEFAULT NULL,
  `sub_title` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `front_slider`
--

INSERT INTO `front_slider` (`id`, `main_image`, `title_1a`, `title_1b`, `sub_title`) VALUES
(2, './front/images/index/slider-01.jpg', 'Better Education for', 'A batter world', 'Lorem ipsum dolor sit amet, consectetuer adipiscingl elit sed diam nonumm nibhy euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.'),
(30, '/assets/images/slider/WK7BA_AUFE3R.jpg', 'ujagar', 'A better World', 'test test');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(150) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `sender_name`, `amount`, `payment_date`, `server_date_time`, `description`) VALUES
(2, 'GOVT. OF RAJASTHAN', 150400, '2019-09-10', '2019-09-10 00:46:05', 'stationary of all class');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `emp_id` int(5) NOT NULL,
  `receiver_name` varchar(50) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `emp_id`, `receiver_name`, `amount`, `payment_date`, `server_date_time`, `description`) VALUES
(4, 0, 'Rajeshwari ', 15000, NULL, '2019-08-14 03:14:34', 'test'),
(6, 0, 'Bharat Kumar Meena', 15000, '2019-08-14', '2019-08-14 03:16:40', 'News Paper payment of jan to dec'),
(7, 0, 'Ujagar Singh Meena', 16000, '2019-08-21', '2019-08-14 03:19:51', 'hello'),
(8, 0, 'Kiran Meena', 245000, '2019-08-15', '2019-08-14 03:29:24', 'test '),
(9, 0, 'Ratan Lal', 12000, '2019-08-14', '2019-08-14 03:31:11', 'test'),
(10, 0, 'Heera Lal Meena', 25000, '2019-08-14', '2019-08-14 03:33:04', 'this'),
(11, 0, 'Heera Lal Meena', 45000, '2019-08-14', '2019-08-14 03:35:05', 'thest'),
(18, 0, 'JAGJIVAN PRASAD SHARMA', 456666, '2019-10-03', '2019-10-03 17:55:09', ''),
(19, 18, 'SHIKHA KHANDELAL', 12555, '2019-10-22', '2019-10-22 16:52:32', '');

-- --------------------------------------------------------

--
-- Table structure for table `school_info`
--

CREATE TABLE `school_info` (
  `id` int(11) NOT NULL,
  `sch_name` varchar(100) DEFAULT NULL,
  `sch_reg_no` varchar(15) DEFAULT NULL,
  `sch_recog_no` varchar(15) DEFAULT NULL,
  `sch_contact_num` varchar(15) DEFAULT NULL,
  `sch_mobile_num` varchar(15) NOT NULL,
  `sch_email` varchar(50) DEFAULT NULL,
  `sch_address` varchar(100) DEFAULT NULL,
  `sch_medium` varchar(10) DEFAULT NULL,
  `sch_logo` varchar(100) DEFAULT NULL,
  `admin_img` varchar(100) NOT NULL,
  `admin_sign` varchar(100) NOT NULL,
  `sch_wel_mes_title` varchar(50) DEFAULT NULL,
  `sch_wel_mes` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_info`
--

INSERT INTO `school_info` (`id`, `sch_name`, `sch_reg_no`, `sch_recog_no`, `sch_contact_num`, `sch_mobile_num`, `sch_email`, `sch_address`, `sch_medium`, `sch_logo`, `admin_img`, `admin_sign`, `sch_wel_mes_title`, `sch_wel_mes`) VALUES
(2, 'Jyoti Public School', '1245/54', '6546541/2020', '9828784536', '', 'info@jyoti.com', 'Andhi, Jamwaramgarh, Jaipur', 'English', '/assets/images/school/BQOIIBX8D56J.jpg', '/assets/images/school/EZYUECYYGVID.jpg', '/assets/images/school/XFVMC4JM6ANY.jpg', 'Welcome To Jyoti Pblic School', 'Aorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod does tempor incididunt ut labore et.dolore magna aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat quis nostrud exercitation ullamco. Aorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod does tempor incididunt ut labore et.dolore magna aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat quis nostrud exercitation ullamco.');

-- --------------------------------------------------------

--
-- Table structure for table `site_template`
--

CREATE TABLE `site_template` (
  `id` int(2) NOT NULL,
  `template_name` varchar(20) NOT NULL,
  `template_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_fee_record`
--

CREATE TABLE `student_fee_record` (
  `id` int(11) NOT NULL,
  `depo_amo_rec_id` int(10) NOT NULL,
  `student_id` int(10) DEFAULT NULL,
  `fee_amount` int(10) DEFAULT NULL,
  `fee_total` int(10) NOT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fee_title` varchar(15) DEFAULT NULL,
  `month_of_fee` varchar(15) NOT NULL,
  `discount` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_fee_record`
--

INSERT INTO `student_fee_record` (`id`, `depo_amo_rec_id`, `student_id`, `fee_amount`, `fee_total`, `server_date_time`, `fee_title`, `month_of_fee`, `discount`) VALUES
(1, 102, 478, 500, 500, '2019-10-06 10:44:18', 'monthly', 'July', 0),
(2, 102, 478, 400, 400, '2019-10-06 10:44:18', 'reg_fee', 'oneTime', 0),
(3, 102, 478, 250, 250, '2019-10-06 10:44:18', 'sports_fee', 'oneTime', 0),
(4, 103, 425, 500, 500, '2019-10-06 10:45:08', 'monthly', 'July', 0),
(5, 103, 425, 500, 500, '2019-10-06 10:45:08', 'monthly', 'August', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(11) NOT NULL,
  `u_dise_code` char(20) DEFAULT NULL,
  `psp_code` char(15) DEFAULT NULL,
  `aadhar_number` char(15) DEFAULT NULL,
  `student_name` char(50) DEFAULT NULL,
  `father_name` char(50) DEFAULT NULL,
  `mother_name` char(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` char(10) DEFAULT NULL,
  `social_category` char(15) DEFAULT NULL,
  `religion` char(15) DEFAULT NULL,
  `mother_tongue` char(15) DEFAULT NULL,
  `rural_urban` char(15) DEFAULT NULL,
  `habitation_or_locality` char(15) DEFAULT NULL,
  `date_of_admission` date DEFAULT NULL,
  `admission_number` char(10) DEFAULT NULL,
  `belong_to_bpl` char(10) DEFAULT NULL,
  `belong_to_disadvantaged_group` char(10) DEFAULT NULL,
  `getting_free_education` char(10) DEFAULT NULL,
  `studying_in_class` char(10) DEFAULT NULL,
  `class_studied_in_prev_year` char(10) DEFAULT NULL,
  `status_of_previous_year` char(10) DEFAULT NULL,
  `days_child_attended_school` char(10) DEFAULT NULL,
  `medium_of_instruction` char(10) DEFAULT NULL,
  `type_of_disablity` char(10) DEFAULT NULL,
  `facilities_received_by_cwsn` char(10) DEFAULT NULL,
  `no_of_uniform_sets` char(10) DEFAULT NULL,
  `free_text_books` char(10) DEFAULT NULL,
  `free_transport` char(10) DEFAULT NULL,
  `free_escort` char(10) DEFAULT NULL,
  `mdm_beneficiary` char(10) DEFAULT NULL,
  `free_hostel_facility` char(10) DEFAULT NULL,
  `child_attended_special_training` char(10) DEFAULT NULL,
  `child_is_homeless` char(10) DEFAULT NULL,
  `appeard` char(10) DEFAULT NULL,
  `passed` char(10) DEFAULT NULL,
  `percentage_marks` char(10) DEFAULT NULL,
  `stream_grades_11_n_12` char(10) DEFAULT NULL,
  `trade_sector_grades_9_to_12` char(10) DEFAULT NULL,
  `iron_n_folic_acid` char(10) DEFAULT NULL,
  `deworming_tablets` char(10) DEFAULT NULL,
  `vitamin_a_supplement` char(10) DEFAULT NULL,
  `mobile_number` char(15) DEFAULT NULL,
  `email_address` char(50) DEFAULT NULL,
  `free_bicycle` char(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id`, `u_dise_code`, `psp_code`, `aadhar_number`, `student_name`, `father_name`, `mother_name`, `dob`, `gender`, `social_category`, `religion`, `mother_tongue`, `rural_urban`, `habitation_or_locality`, `date_of_admission`, `admission_number`, `belong_to_bpl`, `belong_to_disadvantaged_group`, `getting_free_education`, `studying_in_class`, `class_studied_in_prev_year`, `status_of_previous_year`, `days_child_attended_school`, `medium_of_instruction`, `type_of_disablity`, `facilities_received_by_cwsn`, `no_of_uniform_sets`, `free_text_books`, `free_transport`, `free_escort`, `mdm_beneficiary`, `free_hostel_facility`, `child_attended_special_training`, `child_is_homeless`, `appeard`, `passed`, `percentage_marks`, `stream_grades_11_n_12`, `trade_sector_grades_9_to_12`, `iron_n_folic_acid`, `deworming_tablets`, `vitamin_a_supplement`, `mobile_number`, `email_address`, `free_bicycle`) VALUES
(1258, '', '', '', 'AARVIK SHARMA', 'DHARMENDRA SHARMA', 'REKHA SHARMA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '472', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1259, '', '', '', 'AAYUSH KUMAR DHUDIYA', 'BANWARI LAL RAIGAR', 'SUMAN DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '453R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1260, '', '', '', 'AAYUSH MEENA', 'RAKESH MEENA', 'LALITA MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '428', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1261, '', '', '', 'ANIRUDDH SHARMA', 'MUKESH KUMAR SHARMA', 'MEERA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '447', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1262, '', '', '', 'ANKUSH MEENA', 'RAM KHILADI MEENA', 'KOMA DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '440', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1263, '', '', '', 'BHAWANA MEENA', 'CHHOTE LAL MEENA', 'CHANDRA KANTA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '445', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1264, '', '', '', 'BHAWESH SHARMA', 'PAWAN KUMAR SHARMA', 'MAMTA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '441R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1265, '', '', '', 'DAKSH SHARMA', 'HARI NARAYAN SHARMA', 'SUNITA SHARMA', '2016-06-02', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '491', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1266, '', '', '', 'GAJAL VERMA', 'VINOD VERMA', 'HFKHFKHGF', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '464', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1267, '', '', '', 'HARSH SHARMA', 'BABLU SHARMA', 'MAMTA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '462R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1268, '', '', '', 'HARSHIT MAHAWAR', 'DHARAM SINGH', 'SEEMA MAHAWAR', '2015-07-01', 'Boy', 'SC', '', '', '', '', '0000-00-00', '463', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1269, '', '', '', 'HASNEN KHAN', 'ASLAM KHAN', 'HASINA BEGAM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '431R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1270, '', '', '', 'HITESH BUNKAR', 'DEENDAYAL BUNKAR', 'KAUSHLYA DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '476', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1271, '', '', '', 'HUMERA BANO', 'YUNUS TELI', 'RESHMA BEGAM', '2016-06-07', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '485', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1272, '', '', '', 'KANAK SHARMA', 'PRAKASH CHAND SHARMA', 'MEERA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '452', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1273, '', '', '', 'KARTIK SHARMA', 'LALRAM SHARMA', 'POOJA SHARM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '458', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1274, '', '', '', 'KAVYA SHARMA', 'RAM BABU SHARMA', 'KALPANA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '454', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1275, '', '', '', 'KRISHAN KUMAR MEENA', 'ASHOK KUMAR MEENA', 'BHOTI DEVI', '2014-01-01', 'Boy', 'ST', '', '', '', '', '0000-00-00', '438', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1276, '', '', '', 'KUSHAL JAKHIWAL', 'RAMBABU MEENA', 'SUMAN MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '432R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1277, '', '', '', 'LAKSHAY RAIGAR', 'GAJANAND RAIGAR', 'ASHA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '470R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1278, '', '', '', 'MANAV RAIGAR', 'HAJARI LAL RAIGAR', 'SANGITA VERMA', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '461', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1279, '', '', '', 'MAYANK RAWAT', 'ANIL KUMAR RAWAT', 'KIRAN RAWAT', '2015-04-06', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '448R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1280, '', '', '', 'MOHAMMAD ASHIR KHAN', 'IMRAN KHAN', 'SABINA BEGAM', '2015-01-05', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '459R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1281, '', '', '', 'MOHIT KUMHAR', 'RAM SWAROOP KUMHAR', 'NATHI DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '442', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1282, '', '', '', 'NAKSH JALUTHARIA', 'GHANSHYAM JALUTHARIA', 'TULSA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '460', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1283, '', '', '', 'NANNU SHARMA', 'KAMLESH SHARMA', 'HANSA DEVI', '2015-12-03', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '467', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1284, '', '', '', 'NIKUNJ SONI', 'PANKAJ KUMAR SONI', 'RINKI DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '494', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1285, '', '', '', 'PAWAN KUMAR VERMA', 'GIRDHARI RAIGAR', 'SAMPATI DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '456', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1286, '', '', '', 'PRINCE DHULARAWJI', 'VISHRAM KUMHAR', 'KAUSHALYA DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '488', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1287, '', '', '', 'PRIYANSHI MEENA', 'RAMESH CHAND MEENA', 'GULAB DEVI MEENA', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '486', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1288, '', '', '', 'PRIYANSHU KUMAR JALUTHARIYA', 'JITENDRA KUMAR JALUTHARIA', 'RENUKA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '466R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1289, '', '', '', 'RADHA PRAJAPAT', 'RAMESH KUMAR', 'LADA DEVI', '2015-10-09', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '464R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1290, '', '', '', 'RAGHAV SHARMA', 'MANISH KUMAR SHARMA', 'RAKHA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '451', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1291, '', '', '', 'RAKSHITA MEENA', 'RAJA RAM MEENA', 'KRISHNA MEENA', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '429', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1292, '', '', '', 'RENUKA VERMA', 'GAJANAND VERMA', 'VIMLA DEVI', '2015-11-04', 'Girl', 'SC', '', '', '', '', '0000-00-00', '437R', '', '', 'YES', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1293, '', '', '', 'RESHU SHARMA', 'PAWAN KUMAR SHARMA', 'MAMTA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '457', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1294, '', '', '', 'RITIKA DHUDIYA', 'GOURI SHANKAR RAIGAR', 'MAMTA DEVI', '2014-06-12', 'Girl', 'SC', '', '', '', '', '0000-00-00', '465', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1295, '', '', '', 'SARITA MEENA', 'KELI CHAND MEENA', 'CMFYJ', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '484', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1296, '', '', '', 'SHIVANI RAIGAR', 'BANWARI LAL RAIGAR', 'HHJGLKJH', '2019-06-07', 'Girl', 'SC', '', '', '', '', '0000-00-00', '477', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1297, '', '', '', 'SURAJ KUMAR GURJAR', 'KRISHAN KUMAR GURJAR', 'GUDDI DEVI', '2014-01-01', 'Boy', 'SBC', '', '', '', '', '0000-00-00', '455', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1298, '', '', '', 'TANISHK SHARMA', 'JITENDRA PRASAD SHARMA', 'SEEMA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '449', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1299, '', '', '', 'TANISHKA SHARMA', 'RAJESH KUMAR SHARMA', 'ASHA DEVI', '2016-07-07', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '424', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1300, '', '', '', 'TARUN SHARMA', 'RAJESH KUMAR SHARMA', 'ASHA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '423', '', '', 'NO', 'PP.4+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1301, '', '', '', 'AARUL MEENA', 'SHANKAR LAL MEENA', 'BHAGA DEVI', '2014-01-06', 'Boy', 'ST', '', '', '', '', '0000-00-00', '393', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1302, '', '', '', 'AAYUSH SHARMA', 'SUBHASH CHAND SHARMA', 'MAMTA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '44R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1303, '', '', '', 'ABDUL RAHMAN', 'RAMJAN KHAN', 'SALMA BEGAM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '38R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1304, '', '', '', 'ALIYA BANO', 'IMRAN KHAN', 'SABINA BEGAM', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '49R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1305, '', '', '', 'ANAYU SHARMA', 'GOURI SHANKAR SHARMA', 'KAVITA SHARMA', '2013-04-07', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '285', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1306, '', '', '', 'ANKU PRAJAPAT', 'RAJESH PRAJAPAT', 'HANSA DEVI', '0000-00-00', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '391', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1307, '', '', '', 'ASEER KHAN', 'IMRAN KHAN', 'SANNO BEGAM', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '396', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1308, '', '', '', 'BHAWANA', 'DEEPAK REGAR', 'JAYA RAIGAR', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '36', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1309, '', '', '', 'CHANCHAL DHUDIYA', 'MUKESH KUMAR DHUDIYA', 'RENU DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '41R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1310, '', '', '', 'CHHAVI RAIGAR', 'MOHAN LAL RAIGAR', 'MAMTA DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '37', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1311, '', '', '', 'CHINTU RAIGAR', 'RAKESH KUMAR RAIGAR', 'JFILAEUFKSDN', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '337', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1312, '', '', '', 'DARSH SHARMA', 'NIRANJAN SHARMA', 'SHIMLA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '388', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1313, '', '', '', 'DHOLI PRAJAPAT', 'RAMESH PRAJAPAT', 'Dhufiu', '0000-00-00', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '414', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1314, '', '', '', 'FARAMAN KHAN', 'ISLAM KHAN', 'SHABANA BANO', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '46R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1315, '', '', '', 'GORANSHI SHARMA', 'RAMBABU SHARMA', 'KALPANA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '34', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1316, '', '', '', 'GOURAV SHARMA', 'RAMESH SHARMA', 'PINKI SHARMA', '2014-01-05', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '415', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1317, '', '', '', 'HARI OM SAIN', 'BUDDHI PRAKASH SAIN', 'RASIYA', '2014-01-06', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '413', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1318, '', '', '', 'HARSHIT JALUTHARIA', 'KAMLESH KUMAR JALUTHARIA', 'UGANTI DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '30', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1319, '', '', '', 'HIMANSHU MEENA', 'KALU RAM MEENA', 'KAMALI DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '439', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1320, '', '', '', 'IMRAN KHAN', 'IKRAAM KHAN', 'FIRDOSH BEGAM', '2012-07-08', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '293', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1321, '', '', '', 'JASMEEN BANO', 'SARIF KHAN', 'MOSHINA BEGAM', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '386', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1322, '', '', '', 'KANAK BYADWAL', 'RAMESH CHAND MEENA', 'GULAB MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '353', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1323, '', '', '', 'KANIKA SHARMA', 'VIKAS SHARMA', 'ASHA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '275', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1324, '', '', '', 'KANISHKA SHARMA', 'CHANDRA PRAKASH', 'ANITA DEVI SHARMA', '2014-02-11', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '382', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1325, '', '', '', 'KARAN VERMA', 'HANUMAN SAHAY REIGAR', 'SUMAN DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '29', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1326, '', '', '', 'KARTIK VERMA', 'ROSHAN LAL RAIGAR', 'MAMTA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '45R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1327, '', '', '', 'KHUSHBU MEENA', 'DAYARAM MEENA', 'ASHA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '273', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1328, '', '', '', 'KHUSHI PRAJAPAT', 'RAJESH PRAJAPAT', 'HANSHA DEVI PRAJAPAT', '2013-11-09', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '43R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1329, '', '', '', 'KUNAL SHARMA', 'RANJEET SHARMA', 'PUSHPA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '330', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1330, '', '', '', 'MAHINUR BANO', 'SIRAJUDDIN KHAN', 'SALMA BEGAM', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '40R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1331, '', '', '', 'MANISH KUMAR RAIGAR', 'MADAN LAL RAIGAR', 'RADHA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '33', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1332, '', '', '', 'MANISH MEENA', 'SHANKAR LAL MEENA', 'BHAGA DEVI', '2013-01-06', 'Boy', 'ST', '', '', '', '', '0000-00-00', '436', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1333, '', '', '', 'MAYANK SHARMA', 'RAMBABU SHARMA', 'MADHUBALA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '326', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1334, '', '', '', 'MOHAMMAD IRSHAD', 'ABDUL RAZZAK KHAN', 'MADINA BEGUM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '364', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1335, '', '', '', 'MOHAMMAD SHAHID KHAN', 'ABDUL RAJJAK KHAN', 'SHMEEM BANO', '2013-01-07', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '48R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1336, '', '', '', 'MOHD AYAN', 'MOHD NAIM', 'HAMDUSANA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '356', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1337, '', '', '', 'MOHD REHAN KHAN', 'MOHD NAEEM', 'HMDUSANA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '355', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1338, '', '', '', 'MOHD SHEHZAD', 'MOHD NAEEM', 'HAMDUSANA', '2012-02-01', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '357', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1339, '', '', '', 'MUSKAN GURJAR', 'KRISHAN KUMAR GURJAR', 'GUDDI DEVI', '2013-01-01', 'Girl', 'SBC', '', '', '', '', '0000-00-00', '469', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1340, '', '', '', 'MUSKAN MEENA', 'RAMESH CHAND MEENA', 'GULAB DEVI MEENA', '2014-05-04', 'Girl', 'ST', '', '', '', '', '0000-00-00', '271', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1341, '', '', '', 'MUSRAF KHAN', 'ASRAF KHAN', 'KALLI BEGAM', '2013-05-08', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '358', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1342, '', '', '', 'NAJMIN BANO', 'ASPAK KHAN', 'SAYARA KHAN', '2014-03-02', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '395', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1343, '', '', '', 'NEETU PRAJAPAT', 'BABU LAL KUMHAR', 'SAVITA DEVI', '0000-00-00', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '31', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1344, '', '', '', 'PRATIK MEENA', 'RAMBABU MEENA', 'MANJU MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '397', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1345, '', '', '', 'PRIYANSHI MEENA', 'KANHIAY LAL MEENA', 'CHANDA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '340', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1346, '', '', '', 'RESHMA MEENA', 'RANGLALMEENA', 'KALLI DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '446', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1347, '', '', '', 'RIYA SHARMA', 'RAMCHARAN SHARMA', 'CHANDA SHARMA', '2013-07-08', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '336', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1348, '', '', '', 'RONAK SHARMA', 'VIJAY KUMAR SHARMA', 'ARCHNA DEVI', '2013-04-06', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '341', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1349, '', '', '', 'SAHID KHAN', 'RAZAK KHAN', 'SAMMI BEGUM', '2013-06-09', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '329', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1350, '', '', '', 'SAKSHI SHARMA', 'RAMESH CHANDRA SHARMA', 'SUNITA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '390', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1351, '', '', '', 'SAMIT SHARMA', 'RAJENDRA KUMAR SHARMA', 'KAVITA DEVI', '2014-03-02', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '365', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1352, '', '', '', 'SAPNA PRAJAPAT', 'RAJESH PRAJAPAT', 'HANSA DEVI', '2014-01-02', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '394', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1353, '', '', '', 'SHEETAL SAIN', 'BUDDHI PRAKASH SAIN', 'RASIYA DEVI', '2013-02-04', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '35', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1354, '', '', '', 'SHIVANI SHARMA', 'RAJ KUMAR SHARMA', 'MEERA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '430', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1355, '', '', '', 'SUGNA PRAJAPAT', 'CHHOTU RAM', 'MANISHA DEVI', '0000-00-00', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '39R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1356, '', '', '', 'TANISHA MEENA', 'SHIV KUMAR MEENA', 'MANBHAR MEENA', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '381', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1357, '', '', '', 'VANSH SHARMA', 'MUKESH SHARMA', 'ANNU SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '389', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1358, '', '', '', 'VIJAY RAIGAR', 'MADAN LAL RAIGAR', 'RADHA DEVI', '2015-02-04', 'Boy', 'SC', '', '', '', '', '0000-00-00', '384', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1359, '', '', '', 'VINOD PRAJAPAT', 'RAMESH PRAJAPAT', 'LADA DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '47R', '', '', 'YES', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1360, '', '', '', 'VISHVAS RAIGAR', 'OM PRAKASH RAIGAR', 'CHANDANI DEVI', '2013-05-06', 'Boy', 'ST', '', '', '', '', '0000-00-00', '332', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1361, '', '', '', 'YOGITA MEENA', 'CHHOTE LAL MEENA', 'CHANDRA KANTA DEVI', '2013-10-01', 'Girl', 'ST', '', '', '', '', '0000-00-00', '444', '', '', 'NO', 'PP.5+', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1362, '', '', '', 'AAKANSHA LABANIYA', 'MUKESH KUMAR LABANIYA', 'SMT SUGANA DEVI', '2013-03-03', 'Girl', 'SC', '', '', '', '', '0000-00-00', '24', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1363, '', '', '', 'AARIKA SHARMA', 'KRISHAN KUMAR SHATRMA', 'SHEELA DEVI', '2013-05-03', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '482', '', '', 'NO', 'First', '', '', '', 'Hindi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1364, '', '', '', 'AKSHIT SHARMA', 'BABU LAL SHARMA', 'REKHA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '371', '', '', 'NO', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1365, '', '', '', 'ANKUSH KUMAR RAIGAR', 'MUKESH KUMAR RAIGAR', 'PINKI DEVI', '2012-07-08', 'Boy', 'SC', '', '', '', '', '0000-00-00', '22', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1366, '', '', '', 'ANTIMA RAIGAR', 'PAPPU RAM RAIGAR', 'MANNI DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '20', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1367, '', '', '', 'LUCKY MEENA', 'DUHNGER SINGH MEENA', 'ASHA MEENA', '2013-01-08', 'Boy', 'ST', '', '', '', '', '0000-00-00', '230', '', '', 'Not Applic', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1368, '', '', '', 'MAYANK SHARMA', 'VIKASH KUMAR SHARMA', 'ASHA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '216', '', '', 'Not Applic', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1369, '', '', '', 'NAITIK KUMAR RAIGAR', 'SURESH CHAND RAIGAR', 'MAMTA DEVI', '2012-03-06', 'Boy', 'SC', '', '', '', '', '0000-00-00', '23', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1370, '', '', '', 'NAMAN SHARMA', 'RANJEET SHARMA', 'PUSHPA SHARMA', '2013-06-05', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '319', '', '', 'NO', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1371, '', '', '', 'NARENDRA KUMAR LABANIYA', 'NEELAM KUMAR LABANIYA', 'SAMPATI DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '21', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1372, '', '', '', 'PRIYANKA SHARMA', 'SITA RAM SHARMA', 'ANITA SHARMA', '2013-06-05', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '373', '', '', 'NO', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1373, '', '', '', 'SAMEER KUMAR RAIGAR', 'PURAN MAL RAIGAR', 'SUSHILA DEVI', '2012-01-09', 'Boy', 'SC', '', '', '', '', '0000-00-00', '25', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1374, '', '', '', 'UMESH MAHAWAR', 'DEVI SAHAY MAHAWAR', 'KESHARI DEVI', '2013-12-02', 'Boy', 'SC', '', '', '', '', '0000-00-00', '26', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1375, '', '', '', 'YATI VERMA', 'GULAB CHAND RAIGAR', 'MAINKA DEVI', '2013-10-08', 'Girl', 'SC', '', '', '', '', '0000-00-00', '28', '', '', 'YES', 'First', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1376, '', '', '', 'AARYAN TIWARI', 'JAGDISH TIWARI', 'REKHA TIWARI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '474', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1377, '', '', '', 'AAYUSH SHARMA', 'LAXMAN PRASAD SHARMA', 'MAMTA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '1', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1378, '', '', '', 'AAYUSHI MEENA', 'BABU LAL MEENA', 'ANITA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '490', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1379, '', '', '', 'AFTAB HUSSAIN', 'KALU KHAN', 'MOBINA BEGAM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '10', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1380, '', '', '', 'ANSHUL TIWARI', 'JAGDISH TIWARI', 'REKHA TIWARI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '473', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1381, '', '', '', 'ARADHYA SHARMA', 'LAXMAN PRASAD SHARMA', 'MAMTA DEVI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '11', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1382, '', '', '', 'ARJUN MAHAWAR', 'HEERA LAL MAHAWAR', 'LAJWANTI MAHAWAR', '2011-03-08', 'Boy', 'SC', '', '', '', '', '0000-00-00', '16', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1383, '', '', '', 'ARYAN MEENA', 'GIRRAJ PRASAD MEENA', 'BEENA DEVI', '2011-09-09', 'Boy', 'ST', '', '', '', '', '0000-00-00', '308', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1384, '', '', '', 'CHIRAG TAILOR', 'VED PRAKASH TANK', 'POONAM TANK', '2011-08-08', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '19', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1385, '', '', '', 'JUNED KHAN', 'ISLAM KHAN', 'JUBEDA BEGAM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '18', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1386, '', '', '', 'KHUSHI PRAJAPAT', 'YOGESH CHAND KUMHAR', 'SEEMA DEVI', '2012-04-06', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '435', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1387, '', '', '', 'LAKSHYA SHARMA', 'KAMLESH SHARMA', 'KAMLA DEVI', '2011-05-09', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '313', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1388, '', '', '', 'LUCKY BUNKAR', 'DEENDAYAL BUNKAR', 'MANJU DEVI', '2011-09-07', 'Boy', 'SC', '', '', '', '', '0000-00-00', '4', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1389, '', '', '', 'LUCKY SHARMA', 'HANUMAN SHARMA', 'SUNITA SHARMA', '2012-09-10', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '372', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1390, '', '', '', 'MANISH DHUDIYA', 'GAURI SHANKAR RAIGAR', 'MAMTA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '7', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1391, '', '', '', 'NEHA VERMA', 'GHANSHYAM JALUTHARIA', 'TULSA DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '8', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1392, '', '', '', 'NIKHIL KUMAR JALUTHRIYA', 'KAMLESH KUMAR JALUTHARIYA', 'UGANTI DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '5', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1393, '', '', '', 'NISHA MEENA', 'JAI NARAYAN MEENA', 'MANNA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '475', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1394, '', '', '', 'PRASHANT TANK', 'VED PRAKASH TANK', 'POONAM DEVI', '2012-11-12', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '240/16', '', '', 'Not Applic', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1395, '', '', '', 'PRATEEK KUMAR DHUDIYA', 'RAJKUMAR RAIGAR', 'HEM LATA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '2', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1396, '', '', '', 'RIYA', 'SATYA NARAYAN MEENA', 'MAMTA KUMARI MEENA', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '426', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1397, '', '', '', 'SAHIBA BANO', 'ABDUL RAZAK KHAN', 'SAMMY BEGUM', '2012-10-06', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '323', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1398, '', '', '', 'SAHIL MEENA', 'HARI NARAYAN MEENA', 'RAMESWARI DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '489', '', '', 'NO', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1399, '', '', '', 'SHABIR KHAN', 'IDU KHAN', 'SHAHIDA BEGAM', '2011-04-09', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '17', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1400, '', '', '', 'SONIYA BANO', 'ISLAM KHAN', 'JUBEDA BEGAM', '2011-10-11', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '14', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1401, '', '', '', 'TARANA BANU', 'AAMIN KHAN', 'SALMA BEGAM', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '12', '', '', 'YES', 'Second', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1402, '', '', '', 'ADITIYA SHARMA', 'KAILASH CHAND SHARMA', 'SEEMA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '478', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1403, '', '', '', 'ANKUSH MEENA', 'SURESH CHAND MEENA', 'KRISHANA DEVI', '2011-05-10', 'Boy', 'ST', '', '', '', '', '0000-00-00', '147', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1404, '', '', '', 'ANUPRIYA MEENA', 'SATYA NARAYAN MEENA', 'MAMTA KUMARI MEENA', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '425', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1405, '', '', '', 'DILKUSH MEENA', 'KISHAN LAL MEENA', 'ANITA DEVI', '2009-03-07', 'Boy', 'ST', '', '', '', '', '0000-00-00', '155', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1406, '', '', '', 'ISHRAFIL KHAN', 'ASPAK KHAN', 'SHAYARA BEGUM', '2010-02-04', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '283', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1407, '', '', '', 'JOYA KHAN', 'SALEEM KHAN', 'SAYANA BEGAM', '2011-10-08', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '124', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1408, '', '', '', 'KARTIK SHARMA', 'RADHESHYAM SHARMA', 'PINKI SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '434', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1409, '', '', '', 'MONU SHARMA', 'RAMESH CHAND SHARMA', 'REKHA SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '374', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1410, '', '', '', 'NAVYA SHARMA', 'RAM RAI SHARMA', 'KRISHANA DEVI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '150', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1411, '', '', '', 'NOSHEEN', 'MOHD NAEEM', 'HAMDUSANA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '359', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1412, '', '', '', 'PAWAN KUMAR SAIN', 'BUDDHI PRAKASH SAIN', 'RASIYA', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '412', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1413, '', '', '', 'RIJWAN KHAN', 'IMRAN KHAN', 'HASINA BEGAM', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '167', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1414, '', '', '', 'RIYA SHARMA', 'GAURI SHANKAR SHARMA', 'KAVITA SHARNA', '2011-10-12', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '13', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1415, '', '', '', 'SHAILENDRA MEENA', 'THAKARSI MEENA', 'PINKY MEENA', '2012-05-03', 'Boy', 'ST', '', '', '', '', '0000-00-00', '417', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1416, '', '', '', 'VAISHANVI SHARMA', 'RAJESH KUAMR SHARMA', 'SANTOSH DEVI', '2012-04-07', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '181', '', '', 'NO', 'Third', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1417, '', '', '', 'AASHISH MEENA', 'RAMBABU MEENA', 'SAROJ DEVI', '2011-09-09', 'Boy', 'ST', '', '', '', '', '0000-00-00', '141', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1418, '', '', '', 'ADITI SHARMA', 'KAILASH CHAND SHARMA', 'SEEMA SHARMA', '2009-02-01', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '479', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1419, '', '', '', 'AJAY SHARMA', 'DINESH SHARMA', 'ANITA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '280', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1420, '', '', '', 'BITTU SAINI', 'ISHWARMAL', 'MAMTA SAINI', '2009-05-12', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '443', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1421, '', '', '', 'GAURI RAWAT', 'ANIL RAWAT', 'KIRAN DEVI', '2010-10-10', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '200', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1422, '', '', '', 'KINJAL SHARMA', 'MUKESH KUMAR SHARMA', 'ANNU DEVI SHARMA', '2011-01-01', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '411', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1423, '', '', '', 'LUCKY SHARMA', 'VINOD SHARMA', 'MONA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '306', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1424, '', '', '', 'MOHIT SHARMA', 'RAMESH CHAND SHARMA', 'REKHA SHARMA', '2011-12-08', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '375', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1425, '', '', '', 'NAMAN SHARMA', 'SATYA PRAKASH SHARMA', 'POOJA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '226', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1426, '', '', '', 'NISHU RAIGAR', 'MUKESH RAIGAR', 'PINKI DEVI', '2010-08-07', 'Girl', 'SC', '', '', '', '', '0000-00-00', '125', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1427, '', '', '', 'RAVI MEHRA', 'KAILASH MEHRA', 'KALLI DEVI', '2009-08-07', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '487', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1428, '', '', '', 'RAVI RAWAT', 'ANKIT RAWAT', 'LAKSHMI RAWAT', '2010-09-10', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '164', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1429, '', '', '', 'REKHA VERMA', 'BIRDHI CHAND VERMA', 'INDIRA DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '179', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1430, '', '', '', 'SAKSHI SHARMA', 'SATYA PRAKASH SHARMA', 'POOJA DEVI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '227', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1431, '', '', '', 'TANNU TIWARI', 'RAJENDRA PRASAD TIWARI', 'RAKHI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '369', '', '', 'NO', 'Fourth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1432, '', '', '', 'AAKASH MEENA', 'KRISHNA LAL MEENA', 'ANITA MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '154', '', '', 'Not Applic', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1433, '', '', '', 'ADITYA SHARMA', 'RAJU SHARMA', 'BADAM DEVI', '2011-02-02', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '281', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1434, '', '', '', 'AKHILESH SHARMA', 'RAM CHARAN SHARMA', 'SANTRA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '44', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1435, '', '', '', 'ASHUTOSH JANGID', 'KANHAIYA LAL JANGID', 'MEENA DEVI', '0000-00-00', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '483', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1436, '', '', '', 'DEVASHISH SHARMA', 'RAJESH SHARAMA', 'SANTOSH SHARMA', '2009-02-08', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '145', '', '', 'Not Applic', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1437, '', '', '', 'HARSH SHARMA', 'RADHESHYAM SHARMA', 'PINKI SHARMA', '2009-06-10', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '433', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1438, '', '', '', 'LAKSHIT SHARMA', 'PRAMOD SHARMA', 'KANCHAN DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '50', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1439, '', '', '', 'MEHTAB KHAN', 'CHUTTAN KHAN', 'NYANMT BEGAM', '2011-01-01', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '40', '', '', 'Not Applic', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1440, '', '', '', 'MUSKAN SHARMA', 'HANUMAN SHARMA', 'SUNITA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '376', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `student_info` (`id`, `u_dise_code`, `psp_code`, `aadhar_number`, `student_name`, `father_name`, `mother_name`, `dob`, `gender`, `social_category`, `religion`, `mother_tongue`, `rural_urban`, `habitation_or_locality`, `date_of_admission`, `admission_number`, `belong_to_bpl`, `belong_to_disadvantaged_group`, `getting_free_education`, `studying_in_class`, `class_studied_in_prev_year`, `status_of_previous_year`, `days_child_attended_school`, `medium_of_instruction`, `type_of_disablity`, `facilities_received_by_cwsn`, `no_of_uniform_sets`, `free_text_books`, `free_transport`, `free_escort`, `mdm_beneficiary`, `free_hostel_facility`, `child_attended_special_training`, `child_is_homeless`, `appeard`, `passed`, `percentage_marks`, `stream_grades_11_n_12`, `trade_sector_grades_9_to_12`, `iron_n_folic_acid`, `deworming_tablets`, `vitamin_a_supplement`, `mobile_number`, `email_address`, `free_bicycle`) VALUES
(1441, '', '', '', 'RASHI SHARMA', 'GHANSHYAM SHARMA', 'KALAWATI DEVI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '46', '', '', 'Not Applic', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1442, '', '', '', 'SUVRAT MISHRA', 'SARWAN KUMAR MISHRA', 'NEERAJ SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '361', '', '', 'NO', 'Fifth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1443, '', '', '', 'AASHU RAIGAR', 'MUKESH KUMAR RAIGAR', 'PINKI DEVI', '2006-01-01', 'Girl', 'SC', '', '', '', '', '0000-00-00', '132', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1444, '', '', '', 'ADITI SHARMA', 'RANJEET KUMAR SHARMA', 'PUSHPA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '303', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1445, '', '', '', 'AMAR SINGH GURJAR', 'DHARM SINGH GURJAR', 'KAMLA DEVI', '2009-12-11', 'Boy', 'SBC', '', '', '', '', '0000-00-00', '377', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1446, '', '', '', 'ANKITA KUMAWAT', 'KAMLESH KUMAWAT', 'MALA DEVI', '2007-02-06', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '20', '', '', 'Not Applic', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1447, '', '', '', 'HEMANT TIWARI', 'RAJENDRA PRASAD TIWARI', 'MAMTA TIWARI', '2009-05-07', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '420', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1448, '', '', '', 'KHUSHI SHARMA', 'MUKESH SHARMA', 'KIRAN SHARMA', '2010-09-07', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '247', '', '', 'Not Applic', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1449, '', '', '', 'KRISHAN KUMAR MEENA', 'KALU RAM MEENA', 'ANITA DEVI', '2010-01-01', 'Boy', 'ST', '', '', '', '', '0000-00-00', '85', '', '', 'Not Applic', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1450, '', '', '', 'MOHIT MEENA', 'CHETAN PRAKASH MEENA', 'NEHAINA DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '468', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1451, '', '', '', 'NARESH SHARMA', 'RAM RAY SHARMA', 'MANJU DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '362', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1452, '', '', '', 'NEHA MEENA', 'JAI NARAYAN MEENA', 'MANNA DEVI', '0000-00-00', 'Girl', 'ST', '', '', '', '', '0000-00-00', '450', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1453, '', '', '', 'RAJ SHREE TIWARI', 'SHIVSHANKAR TIWARI', 'SONU TIWARI', '2009-11-06', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '370', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1454, '', '', '', 'RAMKESH PRAJAPAT', 'SHANKAR LAL PRAJAPAT', 'SUMAN DEVI', '2007-07-08', 'Boy', 'OBC', '', '', '', '', '0000-00-00', '481', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1455, '', '', '', 'TANISH SHARMA', 'RAM RAI SHARMA', 'KRISHNA SHARMA', '2009-04-02', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '104', '', '', 'Not Applic', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1456, '', '', '', 'VANDANA SHARMA', 'RAMESH CHAND SHARMA', 'ASHA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '305', '', '', 'NO', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1457, '', '', '', 'VINITA SHARMA', 'GURUBAKSH SHARMA', 'ANITA DEVI', '2008-12-11', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '102', '', '', 'Not Applic', 'Sixth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1458, '', '', '', 'AARYAN SHARMA', 'DAYA RAM SHARMA', 'KALLU DEVI SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '69', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1459, '', '', '', 'ABHISHEK SHARMA', 'RAJU SHARMA', 'BADAM DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '304', '', '', 'NO', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1460, '', '', '', 'ANSHU MEENA', 'RAMBABU MEENA', 'SAROJ DEVI', '2008-01-12', 'Boy', 'ST', '', '', '', '', '0000-00-00', '83', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1461, '', '', '', 'ARYAMAN SHARMA', 'MUKESH SHARMA', 'KIRAN SHARMA', '2009-02-01', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '249', '', '', 'NO', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1462, '', '', '', 'DEEPIKA PRAJAPATI', 'KAMAL KISHOR KUMHAR', 'ANITA DEVI', '0000-00-00', 'Girl', 'OBC', '', '', '', '', '0000-00-00', '26', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1463, '', '', '', 'KANAK SHARMA', 'KAMLESH SHARMA', 'MANISHA DEVI', '2005-12-11', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '48', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1464, '', '', '', 'KANIKA SHARMA', 'RAMBABU SHARMA', 'MADHU BALA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '70', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1465, '', '', '', 'PALAK SHARMA', 'GHANSHYAM SHARMA', 'KALAWATI DEVI', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '45', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1466, '', '', '', 'PUSPENDRA SHARMA', 'GIRIRAJ PRASAD SHARMA', 'USHA DEVI SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '204', '', '', 'NO', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1467, '', '', '', 'RAKSHANSH DESHMUKH', 'SHIV RAJ DESHMUKH', 'NEELAM DESHMUKH', '2009-01-01', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '246', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1468, '', '', '', 'RITIKA SHARMA', 'VIJAY KUMAR SHARMA', 'ARCHANA SHARMA', '2007-11-08', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '10', '', '', 'NO', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1469, '', '', '', 'VICKEY VERMA', 'BIRDI CHAND VERMA', 'INDIRA DEVI', '2007-07-02', 'Boy', 'SC', '', '', '', '', '0000-00-00', '22', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1470, '', '', '', 'ZAHEER KHAN', 'CHUTTAN KHAN', 'NYAMAT BANO', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '39', '', '', 'Not Applic', 'Seventh', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1471, '', '', '', 'AMAN MEENA', 'HARI NARAYAN MEENA', 'LEELA DEVI', '2006-04-03', 'Boy', 'ST', '', '', '', '', '0000-00-00', '366', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1472, '', '', '', 'AMIT MEENA', 'RAM KISHOR MEENA', 'SAPNA DEVI', '2011-01-01', 'Boy', 'ST', '', '', '', '', '0000-00-00', '419', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1473, '', '', '', 'AMIT MEENA', 'SURESH MEENA', 'RAMPATI DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '256', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1474, '', '', '', 'ASHISH KUMAR MEENA', 'PRADEEP MEENA', 'SUNITA DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '402', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1475, '', '', '', 'BHAVESH TIWARI', 'YASHODHAR TIWARI', 'CHANDRA DEVI', '2005-02-04', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '401', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1476, '', '', '', 'DILKHUSH MEENA', 'BANWARI LAL MEENA', 'RAM DULARI MEENA', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '409', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1477, '', '', '', 'GOURV SHARMA', 'KAMLESH KUMAR SHARMA', 'MANISHA DEVI SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '257', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1478, '', '', '', 'JATIN RAJ MEENA', 'ASHOK KUMAR MEENA', 'MEERA MEENA', '2007-01-01', 'Boy', 'ST', '', '', '', '', '0000-00-00', '259', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1479, '', '', '', 'KULDEEP MEENA', 'DAYAL CHAND MEENA', 'KRISHNA DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '261', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1480, '', '', '', 'NARENDRA NAWARIYA', 'RAJENDRA NAWARIYA', 'MEENA DEVI', '0000-00-00', 'Boy', 'SC', '', '', '', '', '0000-00-00', '266', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1481, '', '', '', 'PAYAL SHARMA', 'MUKESH KUMAR SHARMA', 'MEERA SHARMA', '2008-01-01', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '405', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1482, '', '', '', 'SHUBHAM SHARMA', 'KAILASH CHAND SHARMA', 'SHEELA DEVI', '2005-12-09', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '399', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1483, '', '', '', 'SONA GURJAR', 'DHARM SINGH GURJAR', 'KAMLA DEVI', '2006-01-07', 'Girl', 'SBC', '', '', '', '', '0000-00-00', '378', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1484, '', '', '', 'SUMIT SHARMA', 'BANWARI LAL SHARMA', 'KAMLA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '480', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1485, '', '', '', 'SURAJ MEENA', 'NAND KISHOR MEENA', 'POONAM DEVI', '2007-07-07', 'Boy', 'ST', '', '', '', '', '0000-00-00', '264', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1486, '', '', '', 'SWAPNIL TIWARI', 'JAGDISH TIWARI', 'REKHA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '471', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1487, '', '', '', 'YASHVERDHAN SINGH', 'ASHOK SINGH', 'HEMA DEVI', '2006-05-10', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '403', '', '', 'NO', 'Eigth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1488, '', '', '', 'MOHAMMAD SARFARAJ', 'NAWAB MOHAMMAD KHAN', 'RAISA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '363', '', '', 'NO', 'Ninth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1489, '', '', '', 'SAKSHI SHARMA', 'RAJENDRA KUMAR SHARMA', 'MITHLESH SHARMA', '2005-09-11', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '301', '', '', 'NO', 'Ninth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1490, '', '', '', 'SALONI SHARMA', 'RAMBABU SHARMA', 'MADHU BALA SHARMA', '0000-00-00', 'Girl', 'GENERAL', '', '', '', '', '0000-00-00', '262', '', '', 'NO', 'Ninth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1491, '', '', '', 'SUMAN VERMA', 'BIRDI CHAND VERMA', 'INDRA DEVI', '0000-00-00', 'Girl', 'SC', '', '', '', '', '0000-00-00', '316', '', '', 'NO', 'Ninth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1492, '', '', '', 'DHEERAJ SHARMA', 'KRISHNA KUMAR SHARMA', 'SITA DEVI SHARMA', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '398', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1493, '', '', '', 'NITESH MEENA', 'THAKUR SINGH', 'PREMA DEVI', '0000-00-00', 'Boy', 'ST', '', '', '', '', '0000-00-00', '298', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1494, '', '', '', 'PRIYANSHU JOSHI', 'GOVIND PRASAD JOSHI', 'INDRA DEVI JOSHI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '379', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1495, '', '', '', 'ROHIT MEENA', 'KANCHAN MEENA', 'SUSHILA DEVI', '2004-01-04', 'Boy', 'ST', '', '', '', '', '0000-00-00', '351', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1496, '', '', '', 'SANJAY MEENA', 'ASHOK KUMAR MEENA', 'MEERA DEVI', '2005-02-07', 'Boy', 'ST', '', '', '', '', '0000-00-00', '328', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1497, '', '', '', 'UDAY CHAND SHARMA', 'GIRRAJ PRASAD SHARMA', 'SITA DEVI', '0000-00-00', 'Boy', 'GENERAL', '', '', '', '', '0000-00-00', '325', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1498, '', '', '', 'VIJAY BHARTI MEENA', 'HARI NARAYAN MEENA', 'LEELA DEVI', '2005-09-02', 'Girl', 'ST', '', '', '', '', '0000-00-00', '368', '', '', 'NO', 'Tenth', '', '', '', 'English', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_info_extra`
--

CREATE TABLE `student_info_extra` (
  `id` int(11) NOT NULL,
  `admission_number` varchar(10) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `roll_number` varchar(10) DEFAULT NULL,
  `software_class` varchar(10) NOT NULL,
  `portal_class` varchar(10) NOT NULL,
  `student_image` varchar(100) DEFAULT NULL,
  `free_seat` int(2) NOT NULL DEFAULT '0',
  `rte_stationary` varchar(3) NOT NULL DEFAULT '0',
  `convence_area` varchar(30) NOT NULL,
  `convence_months` varchar(150) NOT NULL,
  `message_mob` varchar(15) NOT NULL,
  `monthly_discount` varchar(5) NOT NULL,
  `convence_discount` varchar(5) NOT NULL,
  `estimate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info_extra`
--

INSERT INTO `student_info_extra` (`id`, `admission_number`, `medium`, `roll_number`, `software_class`, `portal_class`, `student_image`, `free_seat`, `rte_stationary`, `convence_area`, `convence_months`, `message_mob`, `monthly_discount`, `convence_discount`, `estimate_date`) VALUES
(292, '472', 'English', '', '', 'PP.4+', '', 0, '0', 'Bhondakhera', 'July,August,September,October,November,December,January,February,March,April,May,June', '', '18', '45', '0000-00-00 00:00:00'),
(293, '453R', 'Hindi', '', '', 'PP.4+', '', 0, '', 'Bhondakhera', '', '', '10', '15', '0000-00-00 00:00:00'),
(294, '428', 'Hindi', '', '', 'PP.4+', '', 0, '0', 'Rampura', '', '', '10', '15', '0000-00-00 00:00:00'),
(295, '447', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(296, '440', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(297, '445', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(298, '441R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(299, '491', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(300, '464', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(301, '462R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(302, '463', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(303, '431R', 'English', '', '', 'PP.4+', '', 1, '1', 'Bhondakhera', 'July,August,September,October,November,December,January,February,March,April,May,June', '', '', '', '0000-00-00 00:00:00'),
(304, '476', 'English', '', '', 'PP.4+', '', 0, '0', 'Tholai', '', '', '', '', '0000-00-00 00:00:00'),
(305, '485', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(306, '452', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(307, '458', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(308, '454', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(309, '438', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(310, '432R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(311, '470R', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(312, '461', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(313, '448R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(314, '459R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(315, '442', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(316, '460', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(317, '467', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(318, '494', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(319, '456', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(320, '488', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(321, '486', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(322, '466R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(323, '464R', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(324, '451', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(325, '429', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(326, '437R', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(327, '457', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(328, '465', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(329, '484', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(330, '477', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(331, '455', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(332, '449', 'English', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(333, '424', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(334, '423', 'Hindi', '', '', 'PP.4+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(335, '393', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(336, '44R', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(337, '38R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(338, '49R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(339, '285', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(340, '391', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(341, '396', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(342, '36', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(343, '41R', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(344, '37', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(345, '337', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(346, '388', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(347, '414', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(348, '46R', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(349, '34', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(350, '415', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(351, '413', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(352, '30', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(353, '439', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(354, '293', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(355, '386', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(356, '353', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(357, '275', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(358, '382', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(359, '29', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(360, '45R', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(361, '273', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(362, '43R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(363, '330', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(364, '40R', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(365, '33', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(366, '436', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(367, '326', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(368, '364', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(369, '48R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(370, '356', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(371, '355', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(372, '357', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(373, '469', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(374, '271', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(375, '358', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(376, '395', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(377, '31', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(378, '397', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(379, '340', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(380, '446', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(381, '336', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(382, '341', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(383, '329', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(384, '390', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(385, '365', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(386, '394', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(387, '35', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(388, '430', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(389, '39R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(390, '381', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(391, '389', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(392, '384', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(393, '47R', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(394, '332', 'Hindi', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(395, '444', 'English', '', '', 'PP.5+', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(396, '24', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(397, '482', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(398, '371', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(399, '22', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(400, '20', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(401, '230', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(402, '216', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(403, '23', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(404, '319', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(405, '21', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(406, '373', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(407, '25', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(408, '26', 'English', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(409, '28', 'Hindi', '', '', 'First', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(410, '474', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(411, '1', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(412, '490', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(413, '10', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(414, '473', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(415, '11', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(416, '16', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(417, '308', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(418, '19', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(419, '18', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(420, '435', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(421, '313', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(422, '4', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(423, '372', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(424, '7', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(425, '8', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(426, '5', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(427, '475', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(428, '240/16', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(429, '2', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(430, '426', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(431, '323', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(432, '489', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(433, '17', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(434, '14', 'Hindi', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(435, '12', 'English', '', '', 'Second', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(436, '478', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(437, '147', 'Hindi', NULL, '', 'Third', '/assets/images/students/JY38V2M_6YB9.jpg', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(438, '425', 'Hindi', '', '3', 'Third', '/assets/images/students/DP45GUZNMTVH.jpg', 1, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(439, '155', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(440, '283', 'English', '', '3', 'Third', '/assets/images/students/JYE78SPMVYVL.jpg', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(441, '124', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(442, '434', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(443, '374', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(444, '150', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(445, '359', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(446, '412', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(447, '167', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(448, '13', 'English', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(449, '417', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(450, '181', 'Hindi', '', '3', 'Third', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(451, '141', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(452, '479', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(453, '280', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(454, '443', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(455, '200', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(456, '411', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(457, '306', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(458, '375', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(459, '226', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(460, '125', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(461, '487', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(462, '164', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(463, '179', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(464, '227', 'English', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(465, '369', 'Hindi', '', '', 'Fourth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(466, '154', 'Hindi', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(467, '281', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(468, '44', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(469, '483', 'Hindi', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(470, '145', 'Hindi', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(471, '433', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(472, '50', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(473, '40', 'Hindi', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(474, '376', 'Hindi', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(475, '46', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(476, '361', 'English', '', '', 'Fifth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(477, '132', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(478, '303', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(479, '377', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(480, '20', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(481, '420', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(482, '247', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(483, '85', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(484, '468', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(485, '362', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(486, '450', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(487, '370', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(488, '481', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(489, '104', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(490, '305', 'Hindi', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(491, '102', 'English', '', '', 'Sixth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(492, '69', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(493, '304', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(494, '83', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(495, '249', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(496, '26', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(497, '48', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(498, '70', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(499, '45', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(500, '204', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(501, '246', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(502, '10', 'Hindi', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(503, '22', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(504, '39', 'English', '', '', 'Seventh', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(505, '366', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(506, '419', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(507, '256', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(508, '402', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(509, '401', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(510, '409', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(511, '257', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(512, '259', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(513, '261', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(514, '266', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(515, '405', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(516, '399', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(517, '378', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(518, '480', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(519, '264', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(520, '471', 'English', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(521, '403', 'Hindi', '', '', 'Eigth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(522, '363', 'Hindi', '', '', 'Ninth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(523, '301', 'English', '', '', 'Ninth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(524, '262', 'English', '', '', 'Ninth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(525, '316', 'Hindi', '', '', 'Ninth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(526, '398', 'Hindi', '', 'Tenth A', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(527, '298', 'English', '', 'Tenth A', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(528, '379', 'English', '', 'Tenth A', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(529, '351', 'Hindi', '', 'Tenth A', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(530, '328', 'Hindi', '', 'Tenth B', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(531, '325', 'English', '', 'Tenth B', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00'),
(532, '368', 'English', '', 'Tenth B', 'Tenth', '', 0, '0', '', '', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `subject_info`
--

CREATE TABLE `subject_info` (
  `id` int(11) NOT NULL,
  `sub_name` varchar(30) DEFAULT NULL,
  `medium` varchar(10) NOT NULL,
  `sub_lavel` varchar(2) NOT NULL,
  `sub_parent_id` int(5) NOT NULL,
  `class_id` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_info`
--

INSERT INTO `subject_info` (`id`, `sub_name`, `medium`, `sub_lavel`, `sub_parent_id`, `class_id`) VALUES
(247, 'Hindi', 'English', '1', 0, '5'),
(248, 'Math', 'English', '1', 0, '5'),
(249, 'English', 'English', '2', 0, '5'),
(250, 'English A', 'English', '11', 249, '5'),
(251, 'English B', 'English', '11', 249, '5'),
(252, 'Hindi', 'English', '1', 0, '30'),
(253, 'English', 'English', '2', 0, '30'),
(254, 'English A', 'English', '11', 253, '30'),
(255, 'English B', 'English', '11', 253, '30'),
(256, 'Hindi', 'English', '1', 0, '33'),
(257, 'Hindi', 'Hindi', '1', 0, '2'),
(258, 'Hindi', 'Hindi', '1', 0, '34'),
(259, 'English', 'Hindi', '1', 0, '34'),
(260, 'Math', 'Hindi', '1', 0, '34'),
(261, 'Social Science', 'Hindi', '1', 0, '34'),
(262, 'Science', 'Hindi', '1', 0, '34');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(3) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_category` int(1) NOT NULL,
  `login_id` varchar(20) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `login_pass` varchar(20) NOT NULL,
  `counter` int(11) NOT NULL,
  `is_active` varchar(5) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_name`, `user_category`, `login_id`, `user_id`, `login_pass`, `counter`, `is_active`) VALUES
(2, 'Ujagar', 1, '9828784536', '', '1234', 0, '1'),
(7, 'Rajendra Kr. Sharma', 3, '9828784537', '', '1234', 0, '1'),
(9, 'SHIKHA KHANDELAL', 3, '9828784545', '18', '1234', 0, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_category`
--

CREATE TABLE `user_category` (
  `id` int(3) NOT NULL,
  `user_cate_name` varchar(100) NOT NULL,
  `user_cate_id` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_category`
--

INSERT INTO `user_category` (`id`, `user_cate_name`, `user_cate_id`) VALUES
(1, 'admin', 1),
(2, 'student', 2),
(3, 'employee', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_info`
--
ALTER TABLE `class_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conveyance_info`
--
ALTER TABLE `conveyance_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `depo_amo_record`
--
ALTER TABLE `depo_amo_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_info_extra`
--
ALTER TABLE `emp_info_extra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_id_portal` (`emp_id_portal`);

--
-- Indexes for table `emp_info_portal`
--
ALTER TABLE `emp_info_portal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_info`
--
ALTER TABLE `exam_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_marks_info`
--
ALTER TABLE `exam_marks_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_marks_obtain`
--
ALTER TABLE `exam_marks_obtain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_amount`
--
ALTER TABLE `fee_amount`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `fee_category_id` (`fee_category_id`);

--
-- Indexes for table `fee_cat_info`
--
ALTER TABLE `fee_cat_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `front_slider`
--
ALTER TABLE `front_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_info`
--
ALTER TABLE `school_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_template`
--
ALTER TABLE `site_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_fee_record`
--
ALTER TABLE `student_fee_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_fee_record_ibfk_1` (`depo_amo_rec_id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_info_extra`
--
ALTER TABLE `student_info_extra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_info`
--
ALTER TABLE `subject_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_category`
--
ALTER TABLE `user_category`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `class_info`
--
ALTER TABLE `class_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `conveyance_info`
--
ALTER TABLE `conveyance_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `depo_amo_record`
--
ALTER TABLE `depo_amo_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `emp_info_extra`
--
ALTER TABLE `emp_info_extra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `emp_info_portal`
--
ALTER TABLE `emp_info_portal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `exam_info`
--
ALTER TABLE `exam_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `exam_marks_info`
--
ALTER TABLE `exam_marks_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `exam_marks_obtain`
--
ALTER TABLE `exam_marks_obtain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_amount`
--
ALTER TABLE `fee_amount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fee_cat_info`
--
ALTER TABLE `fee_cat_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `front_slider`
--
ALTER TABLE `front_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `school_info`
--
ALTER TABLE `school_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `site_template`
--
ALTER TABLE `site_template`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_fee_record`
--
ALTER TABLE `student_fee_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1499;

--
-- AUTO_INCREMENT for table `student_info_extra`
--
ALTER TABLE `student_info_extra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=533;

--
-- AUTO_INCREMENT for table `subject_info`
--
ALTER TABLE `subject_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_category`
--
ALTER TABLE `user_category`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `emp_info_extra`
--
ALTER TABLE `emp_info_extra`
  ADD CONSTRAINT `emp_info_extra_ibfk_1` FOREIGN KEY (`emp_id_portal`) REFERENCES `emp_info_portal` (`id`);

--
-- Constraints for table `fee_amount`
--
ALTER TABLE `fee_amount`
  ADD CONSTRAINT `fee_amount_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class_info` (`id`),
  ADD CONSTRAINT `fee_amount_ibfk_2` FOREIGN KEY (`fee_category_id`) REFERENCES `fee_cat_info` (`id`);

--
-- Constraints for table `student_fee_record`
--
ALTER TABLE `student_fee_record`
  ADD CONSTRAINT `student_fee_record_ibfk_1` FOREIGN KEY (`depo_amo_rec_id`) REFERENCES `depo_amo_record` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
