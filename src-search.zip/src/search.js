import React from 'react';

class About extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      cursor : 0,
      data: [
                {userId: 1, id: 1, title: "quidem molestiae enim", }, 
                {userId: 1, id: 2, title: "sunt qui excepturi placeat culpa", }, 
                {userId: 1, id: 3, title: "omnis laborum odio", }, 
                {userId: 1, id: 4, title: "non esse culpa molestiae omnis sed optio", }, 
                {userId: 1, id: 5, title: "eaque aut omnis a", }, 
                {userId: 1, id: 6, title: "natus impedit quibusdam illo est", }, 
                {userId: 1, id: 7, title: "quibusdam autem aliquid et et quia", }, 
                {userId: 1, id: 8, title: "qui fuga est a eum", }, 
                {userId: 1, id: 9, title: "saepe unde necessitatibus rem", }, 
                {userId: 1, id: 10, title: "distinctio laborum qui", },      
        ],
      filter_data : [],
      current_ldr : ''
    }
  }
  componentDidMount(){
      let filter_data = [];
      Object.assign(filter_data, this.state.data);
      console.log(filter_data);
      this.setArraowKeysHandler();
  }
  filterDataHandler=(e)=>{
      // debugger
    const val = e.target.value.toUpperCase();
    const { data } = this.state
    const filtered_data = data.filter((elem) => {
        const _elem = elem.title.toUpperCase();
        if(!_elem.includes(val)){
            return false
        }
        return elem
    })
    console.log(filtered_data);
    this.setState({
        filter_data : filtered_data
    },()=>{
        // this.handleKeyDown(e)
    })
  }
  setArraowKeysHandler(){
      document.addEventListener('keydown', (e) => {
        switch (e.keyCode) {
            case 37:
                    console.log('left');
                    this.handleKeyDown("left");
                break;
                case 38:
                    console.log('up');
                    this.handleKeyDown("up");
                    break;
                case 39:
                    console.log('right');
                    this.handleKeyDown("right");
                break;
            case 40:
                    console.log('down');
                    this.handleKeyDown("down");
                break;
        }
    });
  }
    handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState( prevState => ({
        cursor: prevState.cursor - 1
      }))
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState( prevState => ({
        cursor: prevState.cursor + 1
      }))
    }
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    // debugger
    const {filter_data, cursor} = this.state;
    const current_ldr = filter_data[cursor];
    // console.log(current_ldr);
    this.setState({
        current_ldr : current_ldr
    })
  }

  render() {
    const {filter_data, cursor, current_ldr} = this.state;
    // console.log(this.state)
    return ( 
      <div>
          <h5>Search</h5>
            {filter_data &&
          <form onSubmit={event => this.confirmBoxSubmit(event)}>
              
          <input type="text"
            defaultValue={current_ldr.title}
            value={current_ldr.title}
            onChange={(event)=>{this.filterDataHandler(event)}} />
            <input type="text" value={current_ldr.id} />
            <input type="text" value={current_ldr.userId} />
            <hr/>
            {filter_data.map((elem, inx)=>{
                return (
                    <div key={inx}
                    // key={ item._id }
                    className={cursor === inx ? 'active' : null}>
                    {elem.title}
                    </div>
                )
            })}
            <button type="submit">submit</button>
            </form>
            }
        </div>
    );
  }
}
 
export default About;