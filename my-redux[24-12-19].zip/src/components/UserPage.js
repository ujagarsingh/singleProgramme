import React from "react";
import { NavLink } from "react-router-dom";

class UserPage extends React.Component {
     render() {
        return (
            <div>User Page</div>
        )
    }
}

export default UserPage;