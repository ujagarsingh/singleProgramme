import React from "react";
import { NavLink } from "react-router-dom";

class LoginPage extends React.Component {
     render() {
        return (
            <div>Login Page</div>
        )
    }
}

export default LoginPage;