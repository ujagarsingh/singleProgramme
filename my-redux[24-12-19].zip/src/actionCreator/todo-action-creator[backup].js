import { ADD_TODO, DELETE_TODO, EDIT_TODO, GET_TODOS } from "../actionTypes/todo-action-types";
import Axios from "axios";
//import { assignmentExpression } from "@babel/types";

const ROOT_URL = "http://localhost:7777/todos";
const addTodo = ({ text }) => {
  /*
  return {
    type : ADD_TODO,
    payload:{
      text : text,
      completed : false
    }
  }
  */
  return (dispatch) => {
    Axios.post(ROOT_URL, {
      text: text,
      completed: false
    }).then((response) => {
      //success
      dispatch({
        type: ADD_TODO,
        payload: response.data
      })
      /*dispatch({
        type: ADD_TODO,
        payload: {
          text: text,
          completed: false
        }
      })*/
    }).catch(() => {
      //error
    })
  };
};
const deleteTodo = (index, todoId) => {
  /*return {
    type : DELETE_TODO,
    payload:index,
  }
  */
  return (dispatch) => {
    Axios.delete(ROOT_URL + "/" + todoId).then(() => {
      //success
      dispatch({
        type: DELETE_TODO,
        payload: index
      })
    }).catch(() => {
      //error
    })
  }
};
const editTodo = ({ index, todo }) => {
  /* return {
       type : EDIT_TODO,
       payload:{
         index : index,
         text :text
       }
     }*/
  return (dispatch) => {
    Axios.put(ROOT_URL + "/" + todo.id, {
      ...todo
    }).then(() => {
      //success
      dispatch({
        type: EDIT_TODO,
        payload: {
          index: index,
          text: todo.text
        }
      })
    }).catch(() => {
      //error
    })
  }
};
const getTodos = () => {
  return dispatch => {
    Axios.get(ROOT_URL).then((response) => {
      dispatch({
        type: GET_TODOS,
        payload: response.data
      })
    }).catch(() => {
      //error
    })
  }
};

export { getTodos, addTodo, deleteTodo, editTodo };
