import React, { Component } from 'react';  
const UserPage = ({  classes }) => {  
    return (  
      <div>  
        <h2>Welcome User</h2>  
        <span>Welcome the demo of multiple page this page is rendered using second layout</span>  
      </div>  
    );  
  };  
  
  export default UserPage  