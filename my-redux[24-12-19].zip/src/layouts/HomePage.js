import React, { Component } from 'react';  
const HomePage = ({  classes }) => {  
    return (  
        <section>
        <!-- Navbar Fixed + Default -->
        <nav class="navbar navbar-fixed-top transparent navbar-dark bg-dark-gray">
            <div class="container">
            
                <!-- Navbar Logo -->
                <a class="ui-variable-logo navbar-brand" href="index.html" title="ShalaDarpan - Online School Managment">
                    <!-- Default Logo -->
                    <img class="logo-default" src="assets/img/logo/shala-darpan-logo-white.png" alt="ShalaDarpan - Online School Managment" data-uhd>
                    <!-- Transparent Logo -->
                    <img class="logo-transparent" src="assets/img/logo/shala-darpan-logo-white.png" alt="ShalaDarpan - Online School Managment" data-uhd>
                </a><!-- .navbar-brand -->
    
                <!-- Navbar Navigation -->
                <div class="ui-navigation navbar-center">
                    <ul class="nav navbar-nav">
                        <!-- Nav Item -->
                        <li>
                            <a href="#" data-scrollto="features">Features</a>
                        </li>
                        <!-- Nav Item -->
                        <li>
                            <a href="#" data-scrollto="modules-of-online-school-managment">Modules</a>
                        </li>
                        <!-- Nav Item -->
                        <li>
                            <a href="#" data-scrollto="used-technology">Used Technology</a>
                        </li>
                        <!-- Nav Item -->
                        <li>
                            <a href="#" data-scrollto="pricing">Pricing</a>
                        </li>
                        <!-- Nav Item -->
                        <li class="active">
                            <a href="registration.html">ShalaDarpan Notification</a>
                        </li>
                        <!-- Nav Item -->
                        <li class="active">
                            <a href="contact.html">Contact</a>
                        </li>
                    </ul><!--.navbar-nav -->
                </div><!--.ui-navigation -->
    
                <!-- Navbar Button -->
                <a href="#" class="btn btn-sm ui-gradient-peach pull-right">Registration</a>
    
                <!-- Navbar Toggle -->
                <a href="#" class="ui-mobile-nav-toggle pull-right"></a>
    
            </div><!-- .container -->
        </nav> <!-- nav -->
        
        <!-- Main Wrapper -->
        <div class="main" role="main">
            
            <!-- Hero -->
            <div class="ui-hero hero-lg hero-center hero-bg ui-curve hero-svg-layer-4 bg-dark-gray" >
                <div class="container">
                    <div class="row pt-2 pb-6">
                        <div class="col-sm-12" data-vertical_center="true" data-vertical_offset="16">
                            <h1 class="heading animate" data-show="fade-in-up-big" data-delay="100">
                                The <span class="text-red">easiest</span> &amp; most <span class="text-red">secure</span> online school managment system
                            </h1>
                            <!-- Form -->
                            <form autocomplete="on" class="pt-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <!-- Email Input -->
                                        <input autocomplete="email" class="input form-control" data-validation="required" data-validation-error-msg="Invalid email" name="email" placeholder="Enter your email">
                                        <div class="input-group-append">
                                            <!-- Submit Button -->
                                            <button class="btn ui-gradient-peach">Lets go! <span class="la la-rocket"></span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!-- * Replace data-video with your youtube video id -->
                            <a href="#" class="ui-video-toggle mt-4" data-video="1C75bKax4Eg">
                                <i class=""></i>
                                <span class="icon la la-play bg-red"></span> <span>How ShalaDarpan Works</span>
                            </a>
                        </div>
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .ui-hero -->
      
            <!-- Intro Image -->
            <div class="section intro-image pt-0">
                <img src="assets/demo/img/mockups/shala-darpan-browser-mockup.png" data-uhd data-max_width="1000" class="shadow-xxl responsive-on-lg" alt="ShalaDarpan - Online School Managment" />
            </div><!-- .intro-image -->
            
            <!-- App Features Section -->
            <div id="modules-of-online-school-managment" class="section pt-0">
                   <div class="container ui-icon-blocks ui-blocks-h icons-lg">
                       <div class="section-heading cente">
                           <h2 class="heading text-dark-gray">
                               Modules of ShalaDarpan ERP
                           </h2>
                           <p class="paragraph">
                               Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.
                           </p>
                       </div><!-- .section-heading -->
                       <div class="row">
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-graduation-cap icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Student Admission Management</h4>
                            <p>
                                The organization can handle all complicated process of admission with ease. This includes prospectus sale, student registration, verification & finalization, etc.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-wallet icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Online Fees Collection</h4>
                               <p>
                                With this advance cloud-based fee collection module, parents can pay their child's fee & track fee records. A comfortable platform for parents and organization.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-user-check icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Student Attendance Management</h4>
                            <p>
                                This module provides a convenient platform for taking student's attendance online via smart phone. Parents will receive SMS about their ward's presence in the campus.
                            </p>
                           </div>
                        <div class="col-sm-4 ui-icon-block">
                               <div class="la la-rocket icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Student Administration Management</h4>
                            <p>
                                Student administration module provides the facility to manage all the administration related tasks on a single platform. This module generates various MIS reports useful for the institution.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-id-card icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">ID Card Generation & Printing</h4>
                               <p>
                                Through this School Edu ERP module, school authorities can design and print student identity card as per their standard format.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-door-open icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Parents/Students Login</h4>
                            <p>
                                Parents/ Students will receive a secured login to perform various activities. Parents can also check their ward's attendance, results, fee dues, etc.
                            </p>
                           </div>
                        <div class="col-sm-4 ui-icon-block">
                               <div class="las la-certificate icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Staff Login</h4>
                            <p>
                                Each authorized staff member will receive secured login to perform various tasks efficiently depending on the liberty assigned to them.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-bullseye icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Examination Management</h4>
                               <p>
                                Using this module, schools can define class wise examination scheme, subject offered grades, passing criteria. Any type grace and exam rules can be defined by users.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="lar la-address-book icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Result Processing</h4>
                            <p>
                                This module helps to process examination results from Std. I to XII on the basis of various systems like marks based, grade based and combination of both.
                            </p>
                           </div>
                        <div class="col-sm-4 ui-icon-block">
                               <div class="las la-rupee-sign icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Finance</h4>
                            <p>
                                This module helps to keep track of the expenses and the available funds of the financial and accounting department. Any number of account can be maintained for end number of years.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-globe icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">Web Portal</h4>
                               <p>
                                Give your institute a global gateway and recognition through an elegant web presence. An economical, social and communicative standing of a school/ institute validates excellence.
                            </p>
                           </div>
                           <div class="col-sm-4 ui-icon-block">
                               <div class="las la-sms icon icon-lg icon-circle text-red"></div>
                               <h4 class="text-dark-gray">SMS Integration</h4>
                            <p>
                                With SMS integration, school authorities can send push notification about fee dues, examination schedules, school notices, incoming parent meeting, etc.
                            </p>
                           </div>
                       </div><!-- .row -->
                   </div><!-- .container -->
               </div><!-- .section -->
            
            <!-- Steps Section -->
               <div id="features" class="section bg-light">
                   <div class="container">
                       <!-- Section Heading -->
                       <div class="section-heading center">
                           <h2 class="heading text-dark-gray">
                               Awesome Features
                           </h2>
                           <p class="paragraph">
                               Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                           </p>
                       </div><!-- .section-heading -->
                    
                       <!-- UI Steps -->
                    <div class="ui-showcase-blocks ui-steps">
                        <!-- Step 1 -->
                        <div class="step-wrapper">
                            <span class="step-number ui-gradient-blue">1</span>
                            <div class="row">
                                <div class="col-md-6" data-vertical_center="true">
                                    <h4 class="heading text-dark-gray">
                                        All Device Supported
                                    </h4>
                                    <p class="paragraph">
                                        This Application can be use use in all devices. It is smoothly used and responsible for Mobile, Laptop, and Desktop.
                                    </p>
                                    <a href="#" class="btn-link btn-arrow">Explore</a>
                                </div>
                                <div class="col-md-6">
                                    <img class="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-7.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width="464" />
                                </div>
                            </div>
                        </div>
                        <!-- Step 2 -->
                        <div class="step-wrapper">
                            <span class="step-number ui-gradient-blue">2</span>
                            <div class="row">  
                                <div class="col-md-6" data-vertical_center="true">
                                    <h4 class="heading text-dark-gray">
                                        Easy to Use
                                    </h4>
                                    <p class="paragraph">
                                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                    <a href="#" class="btn-link btn-arrow">Explore</a>
                                </div>
                                <div class="col-md-6">
                                    <img class="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-8.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width="445" />
                                </div>
                            </div>
                        </div>
                        <!-- Step 2 -->
                        <div class="step-wrapper">
                            <span class="step-number ui-gradient-blue">3</span>
                            <div class="row">
                                <div class="col-md-6" data-vertical_center="true">
                                    <h4 class="heading text-dark-gray">
                                        Secure Login and Backpup
                                    </h4>
                                    <p class="paragraph">
                                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                    <a href="#" class="btn-link btn-arrow">Explore</a>
                                </div>
                                <div class="col-sm-6">
                                    <img class="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-10.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width="451" />
                                </div>
                            </div>
                        </div>
                    </div>
                   </div><!-- .container -->
               </div><!-- .section -->
            
            <!-- Integration Section -->
               <div id="used-technology" class="section ui-gradient-blue d-none">
                   <div class="container">
                       <div class="row">
                        
                           <!-- Left Column -->
                           <div class="col-lg-5 col-xl-6" data-vertical_center="true">
                            
                            <!-- Section Heading -->
                            <div class="section-heading mb-2">
                                <h2 class="heading">
                                    Student Administration Management
                                </h2>
                                <p class="paragraph">
                                    Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Ali
                                </p>
                            </div><!-- .section-heading -->
                            
                               <!-- Left blocks -->
                               <ul class="ui-icon-blocks ui-blocks-v icons-sm">
                                   <li class="ui-icon-block">
                                       <span class="la la-gem icon"></span>
                                       <p class="">
                                           Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore
                                       </p>
                                    <a class="btn-link btn-arrow">
                                        Learn More 
                                    </a>
                                   </li>
                                   <li class="ui-icon-block">
                                       <span class="la la-chart-pie icon"></span>
                                       <p class="">
                                           Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit
                                       </p>
                                    <a class="btn-link btn-arrow">
                                        Learn More 
                                    </a>
                                   </li>
                                   <li class="ui-icon-block">
                                       <span class="la la-layer-group icon"></span>
                                       <p class="">
                                           Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod 
                                       </p>
                                    <a class="btn-link btn-arrow">
                                        Learn More
                                    </a>
                                   </li>
                               </ul>
                           </div>
                        
                        <!-- Right Column -->
                           <div class="col-lg-7 col-xl-6">
                               
                            <!-- Logo Cloud -->
                               <div class="ui-logos-cloud">
                                <div data-size="4" class="mt-0 animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/quickbooks.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="10" class="mt-0 animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/salesforce.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="7" class="mt-0 animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/git.svg" alt="Applif App Landing Page" />
                                </div>
                                
                                <!-- Flex Break -->
                                <span class="flex-break"></span>
                                
                                <div data-size="4" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/webflow.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="10" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/shopify.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="4" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/mailchimp.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="6" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/magento.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="3" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/bigcommerce.svg" alt="Applif App Landing Page" />
                                </div>
                                
                                <!-- Flex Break -->
                                <span class="flex-break"></span>
                                
                                <div data-size="8" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/squarespace.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="3" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/sharepoint.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="10" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/slack.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="5" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/paypal.svg" alt="Applif App Landing Page" />
                                </div>
                                
                                <!-- Flex Break -->
                                <span class="flex-break"></span>
                                
                                <div data-size="3" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/fresh-desk.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="10" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/stripe.svg" alt="Applif App Landing Page" />
                                </div>
                                <div data-size="7" class="animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/woocommerce.svg" alt="Applif App Landing Page" />
                                </div>
                                
                                <!-- Flex Break -->
                                <span class="flex-break"></span>
                                
                                <div data-size="4" class="mb-0 animate" data-show="fade-in">
                                    <img src="assets/img/3rd-party-logos/xero.svg" alt="Applif App Landing Page" />
                                </div>
                            </div><!-- .ui-logo-cloud  -->
                            
                           </div>
                       </div><!-- .row -->
                   </div><!-- .container -->
               </div><!-- .section -->
               
              <!-- Showcase Section -->
               <div class="section laptop-showcase">
                   <div class="container">
                       <div class="row">
                        <div class="col-md-5 col-lg-4" data-vertical_center="true">
                            <div>
                                <h2 class="heading text-dark-gray">
                                    Designed For All Apps
                                </h2>
                                <p>
                                    Lorem ipsum dolor  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                </p>
                                <ul class="ui-checklist mt-2">
                                    <li>
                                        <h6 class="heading text-dark-gray">Consectetur adipisicing</h6>
                                    </li>
                                    <li>
                                        <h6 class="heading text-dark-gray">Eiusmod tempor incididunt</h6>
                                    </li>
                                    <li>
                                        <h6 class="heading text-dark-gray">Ut enim ad minim</h6>
                                    </li>
                                </ul>
                                <a href="#" class="btn ui-gradient-peach">Download</a>
                            </div>
                        </div>
                        <div class="col-md-7 col-lg-8">
                            <img class="responsive-on-sm laptop" src="assets/demo/img/mockups/shala-darpan-mockup-11.png" data-uhd alt="ShalaDarpan - Online School Managment" data-max_width="1000" />
                        </div>
                    </div>
                  
                   </div><!-- .container -->
               </div><!-- .section -->
            
            <!-- Showcase Section -->
               <div class="section bg-light pb-6" style="margin: 250px 0">
                <div class="container ">
                      <div class="multi-slider-con">
                      <div class="multi-slider">
        <div class="slidercontainer mobile-view">  
            <div class="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-1.jpg" />  
                <div class="content">Slide1 heading</div>  
            </div>  
            <div class="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-0.jpg" />  
                <div class="content">Slide2 heading</div>  
            </div>  
      
            <div class="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-1.jpg" />  
                <div class="content">Slide3 heading</div>  
            </div>  
            <div class="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-0.jpg" />  
                <div class="content">Slide4 heading</div>  
            </div>  
            <!-- Navigation arrows
            <a class="left" onclick="nextSlide(-1)">❮</a>  
            <a class="right" onclick="nextSlide(1)">❯</a>  
             -->  
        </div>  
        
        <div class="slidercontainer tab-vlew">  
            <div class="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-1.jpg" />  
                <div class="content">Slide1 heading</div>  
            </div>  
            <div class="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-0.jpg" />  
                <div class="content">Slide2 heading</div>  
            </div>  
      
            <div class="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-1.jpg" />  
                <div class="content">Slide3 heading</div>  
            </div>  
            <div class="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-0.jpg" />  
                <div class="content">Slide4 heading</div>  
            </div>  
            <!-- Navigation arrows
            <a class="left" onclick="nextSlide(-1)">❮</a>  
            <a class="right" onclick="nextSlide(1)">❯</a>  
             -->  
        </div>  
     
        <div class="slidercontainer laptop-view">  
            <div class="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-1.jpg" />  
                <div class="content">Slide1 heading</div>  
            </div>  
            <div class="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-0.jpg" />  
                <div class="content">Slide2 heading</div>  
            </div>  
      
            <div class="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-1.jpg" />  
                <div class="content">Slide3 heading</div>  
            </div>  
            <div class="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-0.jpg" />  
                <div class="content">Slide4 heading</div>  
            </div>  
           
        </div>  
        </div>  
       <!-- Navigation arrows -->  
       <div class="controls">
            <a class="left" onclick="nextSlide(-1)">❮</a>  
            <a class="right" onclick="nextSlide(1)">❯</a>  
        </div>
        </div>
                   </div><!-- .container -->
            </div>
    
            <!-- Support Section -->
            <div id="support" class="section bg-dark-gray">
                <div class="container">
                    <div class="row">
                        <!-- Text Column -->
                        <div class="col-lg-6 col-md-5" data-vertical_center="true">
                            <!-- Section Heading -->
                            <div class="section-heading mb-0 center-on-md">
                                <h2 class="heading">
                                    Award-Winning Support
                                </h2>
                                <p class="paragraph">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                </p>
                                <div class="row ui-icon-blocks ui-blocks-h icons-md mt-2">
                                    <div class="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                        <div class="la la-phone icon"></div>
                                        <h4 class="heading mb-1">200k</h4>
                                        <p>
                                            Calls a day
                                        </p>
                                    </div>
                                    <div class="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                        <div class="las la-trophy icon"></div>
                                        <h4 class="heading mb-1">4.5</h4>
                                        <p>
                                            Star Rating
                                        </p>
                                    </div>
                                    <div class="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                                        <div class="la la-support icon"></div>
                                        <h4 class="heading mb-1">500k</h4>
                                        <p>
                                            Experts working 24/7
                                        </p>
                                    </div>
                                </div><!-- .row -->
                            </div><!-- .section-heading -->
                        </div>
                        <!-- Image Column -->
                        <div class="col-lg-6 col-md-7 img-block animate" data-show="fade-in-left"  data-vertical_center="true">
                            <img src="assets/img/support/shala-darpan-support.png" alt="ShalaDarpan - Online School Managment" data-uhd class="img-fluid" data-max_width="460" />
                        </div>
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .section -->
    
               <!-- Pricing Cards Section -->
               <div id="pricing" class="section bg-light">
                   <div class="container">
                       <!-- Section Heading -->
                       <div class="section-heading center">
                           <h2 class="heading text-dark-gray">
                               Pricing Cards
                           </h2>
                           <p class="paragraph">
                               Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                           </p>
                       </div><!-- .section-heading -->
                       
                       <!-- UI Pricing Cards / Owl Carousel On Mobile -->
                       <div class="ui-pricing-cards owl-carousel owl-theme">
                           <!-- Card 1 -->
                           <div class="ui-pricing-card animate" data-show="fade-in-left">
                            <div class="ui-card ui-curve shadow-lg">
                                <div class="card-header bg-dark-gray">
                                    <!-- Heading -->
                                    <h4 class="heading">Start-up</h4>
                                    <!-- Price -->
                                    <div class="price text-red">
                                        <span class="curency">&pound;</span>
                                        <span class="price">Free</span>
                                        <span class="period">/year</span>
                                    </div>
                                    <h6 class="sub-heading">24/7 Support</h6>
                                </div>
                                <!-- Features -->
                                <div class="card-body">
                                    <ul>
                                        <li>
                                            10 GB SSD Disk Space
                                        </li>
                                        <li>
                                            10 SDD Databases
                                        </li>
                                        <li>
                                            2 Subdomains
                                        </li>
                                        <li>
                                            25 Email Accounts
                                        </li>
                                    </ul>
                                    <a href="page-pricing.html" class="btn shadow-md ui-gradient-peach">Get Started</a>
                                </div>
                            </div>
                           </div>
                           <!-- Card 2 -->
                           <div class="ui-pricing-card active animate" data-show="fade-in">
                            <div class="ui-card ui-curve color-card shadow-xl">
                                <div class="card-header ui-gradient-peach">
                                    <!-- Heading -->
                                    <h4 class="heading">Established</h4>
                                    <!-- Price -->
                                    <div class="price">
                                        <span class="curency">&pound;</span>
                                        <span class="price">57</span>
                                        <span class="period">/mo</span>
                                    </div>
                                    <h6 class="sub-heading">24/7 Support</h6>
                                </div>
                                <!-- Features -->
                                <div class="card-body">
                                    <ul>
                                        <li>
                                            20 GB SSD Disk Space
                                        </li>
                                        <li>
                                            20 SDD Databases
                                        </li>
                                        <li>
                                            4 Subdomains
                                        </li>
                                        <li>
                                            50 Email Accounts
                                        </li>
                                    </ul>
                                    <a href="page-pricing.html" class="btn bg-dark-gray shadow-md">Get Started</a>
                                </div>
                            </div>
                          </div>
                          <!-- Card 3 -->
                           <div class="ui-pricing-card animate" data-show="fade-in-right">
                            <div class="ui-card ui-curve shadow-lg">
                                <div class="card-header bg-dark-gray">
                                    <!-- Heading -->
                                    <h4 class="heading">Mastery</h4>
                                    <!-- Price -->
                                    <div class="price text-red">
                                        <span class="curency">&pound;</span>
                                        <span class="price">89</span>
                                        <span class="period">/mo</span>
                                    </div>
                                    <h6 class="sub-heading">24/7 Support</h6>
                                </div>
                                <!-- Features -->
                                <div class="card-body">
                                    <ul>
                                        <li>
                                            60 GB SSD Disk Space
                                        </li>
                                        <li>
                                            30 SDD Databases
                                        </li>
                                        <li>
                                            12 Subdomains
                                        </li>
                                        <li>
                                            200 Email Accounts
                                        </li>
                                    </ul>
                                    <a href="page-pricing.html" class="btn ui-gradient-peach shadow-md">Get Started</a>
                                </div>
                            </div>
                        </div>
                       </div><!-- .ui-pricing-cards -->
                       
                       <!-- Pricing Footer -->
                       <div class="ui-pricing-footer">
                           <p class="paragraph">
                               Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
                           </p>
                           <div class="actions">
                               <a class="btn">Learn More</a>
                           </div>
                       </div><!-- .ui-pricing-footer -->
                       
                   </div><!-- .container -->
               </div><!-- .section -->
            
            <!--  Testimonial Section -->
               <div class="section">
                   <div class="container">
                       <!-- Card Heading -->
                       <div class="section-heading center">
                           <h2 class="heading text-dark-gray">
                               What People Say
                           </h2>
                           <p class="paragraph">
                               Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                           </p>
                       </div><!-- .section-heading -->
                       
                       <!-- Slider  -->
                    <div class="ui-testimonials slider owl-carousel owl-theme">
                        <!-- Testimonials Item 1 -->
                        <div class="item">
                            <!-- Card -->
                            <div class="ui-card shadow-md">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                            </div>
                            <!-- User -->
                            <div class="user">
                                <div class="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar1-sm.png"></div>
                                <div class="info">
                                    <h6 class="heading text-dark-gray">Vicky Stout</h6>
                                    <p class="sub-heading">Founder at Smith &amp; Co</p>
                                </div>
                            </div>
                        </div>
                        <!-- Testimonials Item 2 -->
                        <div class="item">
                            <!-- Card -->
                            <div class="ui-card shadow-md">
                                <p> Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
                            </div>
                            <!-- User -->
                            <div class="user">
                                <div class="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar2-sm.png"></div>
                                <div class="info">
                                    <h6 class="heading text-dark-gray">Jack Smith</h6>
                                    <p class="sub-heading">Founder at Smith &amp; Co</p>
                                </div>
                            </div>
                        </div>
                        <!-- Testimonials Item 3 -->
                        <div class="item">
                            <!-- Card -->
                            <div class="ui-card shadow-md">
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariaturin.</p>
                            </div>
                            <!-- User -->
                            <div class="user">
                                <div class="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar3-sm.png"></div>
                                <div class="info">
                                    <h6 class="heading text-dark-gray">Chérel Doe</h6>
                                    <p class="sub-heading">Founder at Smith &amp; Co</p>
                                </div>
                            </div>
                        </div>
                        <!-- Testimonials Item 4 -->
                        <div class="item">
                            <!-- Card -->
                            <div class="ui-card shadow-md">
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur ac nisi.</p>
                            </div>
                            <!-- User -->
                            <div class="user">
                                <div class="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar4-sm.png"></div>
                                <div class="info">
                                    <h6 class="heading text-dark-gray">Derick Watts</h6>
                                    <p class="sub-heading">Founder at Smith &amp; Co</p>
                                </div>
                            </div>
                        </div>
                        <!-- Testimonials Item 5-->
                        <div class="item">
                            <!-- Card -->
                            <div class="ui-card shadow-md">
                                <p>Donec elementum ligula eu sapien consequat eleifend. Donec nec dolor erat, condimentum sagittis.</p>
                            </div>
                            <!-- User -->
                            <div class="user">
                                <div class="avatar"><img alt="ShalaDarpan App Landing Page" src="assets/img/avatars/avatar5-sm.png"></div>
                                <div class="info">
                                    <h6 class="heading text-dark-gray">Jane Austin</h6>
                                    <p class="sub-heading">Founder at Smith &amp; Co</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- .ui-testimonials  -->
                   </div><!-- .container -->
               </div><!-- .section -->
    
               <!-- Footer -->
               <footer class="ui-footer bg-gray">
                <div class="container pt-6 pb-6">
                       <div class="row">
                          <div class="col-md-4 col-sm-6 footer-about footer-col center-on-sm">
                            <img src="assets/img/logo/shala-darpan-logo-white.png" data-uhd alt="Applif - Online School Managment"/>
                            <p class="mt-1">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Donec elementum ligula eu sapien consequat eleifend.
                            </p>
                        </div>
                        <div class="col-md-2 col-6 footer-col">
                           <!-- <h6 class="heading footer-heading">Quick Nav</h6>
                            <ul class="footer-nav">
                                <li>
                                    <a href="demo-mobile-app-1.html">Mobile App 1</a>
                                </li>
                                <li>
                                    <a href="demo-mobile-app-2.html">Mobile App 2</a>
                                </li>
                                <li>
                                    <a href="demo-saas.html">Mobile Saas</a>
                                </li>
                                <li>
                                    <a href="demo-web-app.html">Web App</a>
                                </li>
                                <li>
                                    <a href="index.html#demos">More Demos</a>
                                </li>
                            </ul>-->
                        </div>
                        <div class="col-md-2 col-6 footer-col">
                           <!-- <h6 class="heading footer-heading">Other Pages</h6>
                            <ul class="footer-nav">
                                <li>
                                    <a href="page-api-docs.html">API Docs</a>
                                </li>
                                <li>
                                    <a href="page-pricing.html">Pricing Page</a>
                                </li>
                                <li>
                                    <a href="page-contact.html">Contact page</a>
                                </li>
                                <li>
                                    <a href="page-blog-grid.html">Blog Grid</a>
                                </li>
                                <li>
                                    <a href="page-coming-soon.html">Comig Soon</a>
                                </li>
                                <li>
                                    <a href="page-404.html">404 Error</a>
                                </li>
                            </ul>-->
                        </div>
                        <div class="col-md-4 col-sm-6 footer-col center-on-sm">
                            <h6 class="heading footer-heading">Newsletter</h6>
                            <!-- Form -->
                            <form autocomplete="on" id="sign-up-form" name="sign-up-form">
                                <div class="form-group">
                                    <div class="input-group">
                                        <!-- Email Input -->
                                        <input autocomplete="email" class="input form-control" data-validation="required" data-validation-error-msg="Please enter your email" name="email" placeholder="Email">
                                        <div class="input-group-append">
                                            <!-- Submit Button -->
                                            <button class="btn ui-gradient-peach">Subscribe <span class="las la-paper-plane"></span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div>
                                <a class="btn ui-gradient-blue btn-circle shadow-md">
                                    <span class="la la-facebook"></span>
                                </a>
                                <a class="btn ui-gradient-peach btn-circle shadow-md">
                                    <span class="la la-instagram"></span>
                                </a>
                                <a class="btn ui-gradient-green btn-circle shadow-md">
                                    <span class="la la-twitter"></span>
                                </a>
                                <a class="btn ui-gradient-purple btn-circle shadow-md">
                                    <span class="la la-pinterest"></span>
                                </a>
                            </div>
                        </div>
                    </div><!-- .row -->
                </div><!-- .container -->
                
                <!-- Footer Copyright -->
                   <div class="footer-copyright bg-dark-gray">
                       <div class="container">
                        <div class="row">
                            <!-- Copyright -->
                            <div class="col-sm-6 center-on-sm">
                                <p>
                                    &copy; 2017 <a href="http://codeytech.com" target="_blank" title="Codeytech">Codeytech</a>
                                </p>
                            </div>
                            <!-- Social Icons -->
                            <div class="col-sm-6 text-right">
                                <ul class="footer-nav">
                                    <li>
                                        <a href="#">
                                            Privacy Policy
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Terms &amp; Conditions
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            FAQ
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                       </div><!-- .container -->
                   </div><!-- .footer-copyright -->
                
               </footer><!-- .ui-footer -->
               
        </div><!-- .main -->
        </section>
    );  
  };  
  
  export default HomePage