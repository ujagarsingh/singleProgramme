export const ADD_USER = "ADD_USER";
export const GET_USERS = "GET_USERS";

export const ADD_TODO = "ADD_TODO";
export const DELETE_TODO = "DELETE_TODO";
export const EDIT_TODO = "EDIT_TODO";
export const GET_TODOS = "GET_TODOS";
