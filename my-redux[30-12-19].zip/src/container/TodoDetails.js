import React from "react";
import { connect } from 'react-redux';
import { NavLink, Redirect } from "react-router-dom"

class TodoDetails extends React.Component {
    render(){
        //debugger
        const { todos, match } = this.props;
        const todo = todos.find((item, index) => {
            return index === parseInt(match.params.id, 10);
        })
        if (typeof todo === "undefined"){
            return <Redirect to="/" />
        }
        return(
            <section>
                <div className="jumbotron">
                    <h1 className="display-4">{todo.text}</h1>
                    <p className="lead">{todo.desc}</p>
                    <hr className="my-4" />
                    <NavLink className="btn btn-primary btn-lg" to="/">Back</NavLink>
                </div>
            </section>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        todos : state.todos
    }
}
export default connect(mapStateToProps, null)(TodoDetails);