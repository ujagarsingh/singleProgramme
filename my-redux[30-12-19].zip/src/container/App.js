// Packages
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Route, Switch, withRouter } from "react-router-dom";
// Components
import AddTodo from "./AddTodo"
import TodoList from "./TodoList"
import TodoDetails from "./TodoDetails"

// Action Creators
import { getTodos, addTodo, deleteTodo, editTodo } from "../actionCreator/todo-action-creator"

class App extends Component {
  componentDidMount() {
    this.props.getTodos();
  }
  render() {
    const { todos, addTodo, deleteTodo, editTodo } = this.props;
    return (
      <div className="App">
        <Switch>
          <Route path="/newtodo" component={AddTodo} />
          <Route exact path="/" component={TodoList} />
          <Route path="/todo/:id" component={TodoDetails} />
          </Switch>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    todos: state.todos
  }
}
export default withRouter(connect(mapStateToProps, { getTodos, addTodo, deleteTodo, editTodo })(App));
