import { ADD_USER, GET_USERS, ADD_TODO, DELETE_TODO, EDIT_TODO, GET_TODOS } from "../actionTypes/todo-action-types";
import Axios from "axios";
//import { assignmentExpression } from "@babel/types";

const ROOT_URLU = "http://localhost:7777/users";
const ROOT_URL = "http://localhost:7777/todos";

const addUser = (obj) => {
  return (dispatch) => {
    Axios.post(ROOT_URLU, {
      user_name     : obj.user_name,
      user_mobile   : obj.user_mobile,
      sch_name      : obj.sch_name,
      sch_address   : obj.sch_address,
      sch_recog     : obj.sch_recog,
      sft_plan      : obj.sft_plan,
      description   : obj.description
    }).then((response) => {
      //success
      dispatch({
        type: ADD_USER,
        payload: response.data
      })
    }).catch(() => {
      //error
    })
  };
};

const getUser = () => {
  return (dispatch) => {
    Axios.get(ROOT_URLU).then((response) => {
      //
      dispatch({
        type: GET_USERS,
        payload: response.data
      })
    }).catch(() => {
      //error
    })
  }
};
const addTodo = ({ text, desc }) => {
  return (dispatch) => {
    Axios.post(ROOT_URL, {
      text: text,
      desc: desc,
      completed: false
    }).then((response) => {
      //success
      dispatch({
        type: ADD_TODO,
        payload: response.data
      })
    }).catch(() => {
      //error
    })
  };
};
const deleteTodo = (index, todoId) => {
  return (dispatch) => {
    Axios.delete(ROOT_URL + "/" + todoId).then(() => {
      //success
      dispatch({
        type: DELETE_TODO,
        payload: index
      })
    }).catch(() => {
      //error
    })
  }
};
const editTodo = ({ index, todo }) => {
  return (dispatch) => {
    Axios.put(ROOT_URL + "/" + todo.id, {
      ...todo
    }).then(() => {
      //success
      dispatch({
        type: EDIT_TODO,
        payload: {
          index: index,
          text: todo.text,
          desc: todo.desc
        }
      })
    }).catch(() => {
      //error
    })
  }
};
const getTodos = () => {
  return dispatch => {
    Axios.get(ROOT_URL).then((response) => {
      dispatch({
        type: GET_TODOS,
        payload: response.data
      })
    }).catch(() => {
      //error
    })
  }
};

export { addUser, getUser, getTodos, addTodo, deleteTodo, editTodo };
