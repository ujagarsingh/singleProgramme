import React from "react";
import { NavLink } from "react-router-dom";

class Navbar extends React.Component {
  render() {
    return (
      <nav className="navbar navbar-fixed-top navbar-dark bg-dark-gray">
        <div className="container">
          <NavLink to="/Home" className="ui-variable-logo navbar-brand" title="ShalaDarpan - Online School Managment">
            <img className="logo-default" src="assets/img/logo/shala-darpan-logo-white.png" alt="ShalaDarpan - Online School Managment" data-uhd />
            <img className="logo-transparent" src="assets/img/logo/shala-darpan-logo-white.png" alt="ShalaDarpan - Online School Managment" data-uhd />
          </NavLink>
          <div className="ui-navigation navbar-center">
            <ul className="nav navbar-nav">
              <li>
                <NavLink to="/Home" data-scrollto="features">Features</NavLink>
              </li>
              <li>
                <NavLink to="/Home" data-scrollto="modules-of-online-school-managment">Modules</NavLink>
              </li>
              <li>
                <NavLink to="/Home" data-scrollto="used-technology">Used Technology</NavLink>
              </li>
              <li>
                <NavLink to="/Home" data-scrollto="pricing">Pricing</NavLink>
              </li>
              <li>
                <a href="http://www.golihoja.com/" target="_blank">Demo</a>
              </li>
            </ul>
          </div>
          <a href="http://www.golihoja.com/" className="btn btn-sm ui-gradient-blue pull-right" target="_blank">Login</a>
          <NavLink to="/Register" className="btn btn-sm ui-gradient-peach pull-right">Registration</NavLink>
          <NavLink to="/Home" className="ui-mobile-nav-toggle pull-right" />
        </div>
      </nav>
    )
  }
}

export default Navbar;