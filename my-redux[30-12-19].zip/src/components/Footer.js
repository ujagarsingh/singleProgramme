import React from "react";
import { NavLink } from "react-router-dom";

class Navbar extends React.Component {
     render() {
        return (
           <footer className="ui-footer bg-gray">
            <div className="container pt-6 pb-6">
              <div className="row">
                <div className="col-md-4 col-sm-6 footer-about footer-col center-on-sm"><img src="assets/img/logo/shala-darpan-logo-white.png" data-uhd alt="Applif - Online School Managment" />
                  <p className="mt-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Donec elementum ligula eu sapien consequat eleifend.</p>
                </div>
                <div className="col-md-2 col-xs-6 footer-col" />
                <div className="col-md-2 col-xs-6 footer-col" />
                <div className="col-md-4 col-sm-6 footer-col center-on-sm">
                  <h6 className="heading footer-heading">Newsletter</h6>
                  <form autoComplete="on" id="sign-up-form" name="sign-up-form">
                    <div className="form-group">
                      <div className="input-group">
                        <input className="input form-control" data-validation-error-msg="Please enter your email" name="email" placeholder="Email" />
                        <div className="input-group-append">
                          <button className="btn ui-gradient-green">Subscribe <span className="las la-paper-plane" /></button>
                        </div>
                      </div>
                    </div>
                  </form>
                  <div><NavLink to="/Home" className="btn ui-gradient-blue btn-circle shadow-md"><span className="la la-facebook" /></NavLink> <NavLink to="/Home" className="btn ui-gradient-peach btn-circle shadow-md"><span className="la la-instagram" /></NavLink> <NavLink to="/Home" className="btn ui-gradient-green btn-circle shadow-md"><span className="la la-twitter" /></NavLink> <NavLink to="/Home" className="btn ui-gradient-purple btn-circle shadow-md"><span className="la la-pinterest" /></NavLink></div>
                </div>
              </div>
            </div>
            <div className="footer-copyright bg-dark-gray">
              <div className="container">
                <div className="row">
                  <div className="col-sm-6 center-on-sm">
                    <p>© 2020 <NavLink to="/Home" target="_blank" title="SmartPSP">SmartPSP</NavLink></p>
                  </div>
                  <div className="col-sm-6 text-right">
                    <ul className="footer-nav">
                      <li><NavLink to="/Home">Privacy Policy</NavLink></li>
                      <li><NavLink to="/Home">Terms &amp; Conditions</NavLink></li>
                      <li><NavLink to="/Home">FAQ</NavLink></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        
        )
    }
}

export default Navbar;