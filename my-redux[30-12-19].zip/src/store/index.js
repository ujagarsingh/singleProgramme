import {createStore, combineReducers, applyMiddleware} from "redux";
import logger from "redux-logger";

import todoreducer from "./todoreducer";
import userReducer from "./userReducer";

import reduxThunk from "redux-thunk";

const store = combineReducers ({
    todos : todoreducer,
    users : userReducer
});

const createStoreWithMiddleware = applyMiddleware(reduxThunk, logger)(createStore);
/*
export default createStore(
    store, 
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    );
    */
export default createStoreWithMiddleware(
    store, 
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    );