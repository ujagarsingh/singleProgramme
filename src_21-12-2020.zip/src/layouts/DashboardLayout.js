import React, { Component, Suspense, lazy } from "react";
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import DashboardHeader from '../includes/dashboard_header';
import DashboardSidebar from '../includes/dashboard_sidebar';

function Welcome(props) {
  return (props.children);
}

class DashboardLayout extends Component {

  render() {
    const { children, user, ...rest } = this.props;
    return (
      <div id="rootBody" className="page-header-fixed sidebar-show">
        {user &&
          <div className="page-wrapper">
            <DashboardHeader user={user} />
            <div className="page-container">
              <DashboardSidebar user={user} />
              <div className="page-content-wrapper">
                 <Suspense fallback={<div>loading...</div>}>
                    <Welcome children={children}></Welcome>
                 </Suspense>
              </div>
              {/*<DashboardEventSidebar />*/}
            </div>
            {/*<DashboardFooter />*/}
          </div>
        }
      </div >
    )

  }
}
function mapStateToProps(state) {
  const { item } = state.authentication;
  const user = item;
  return { user };
}

const actionCreators = {
  // validate: authenticActions.validate,
}

export default connect(mapStateToProps, actionCreators)(withRouter(DashboardLayout));

