import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import axios from 'axios';
import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, professionalAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
let flag = false;

class CreateSalary extends Component {
  state = {
    professional: [],
    filtered_prof: [],
    update_prof: [],
    schools_arr: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    medium: '',
    basicInfo: true,
    formIsHalfFilledOut: false,
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.filterProfOnDemand();
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
      this.filterProfOnDemand();
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      });
    }
  };

  checkHandler = (event, fieldName, value) => {
    let _display_student = null;
    let _current_select = JSON.parse(value).admission_number;
    if (fieldName === 'select_this') {
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['checked'] = !checked_student.checked;
          return checked_student;
        }
        return checked_student;
      })
      this.setState({
        update_student: _display_student
      })
    } else if (fieldName === 'select_all') {
      _display_student = this.state.display_student.map((checked_student) => {
        checked_student['checked'] = (event.target.checked) ? true : false;
        return checked_student;
      })
      this.setState({
        update_student: _display_student
      })
    }  
    let _update_student = _display_student.filter((checked_student) => {
      return checked_student['checked'] === true
    })
    this.setState({
      display_student: _display_student,
      update_student: _update_student
    })
  };

   
  mediumHandler = (medium) => {
    const _proffessionals = this.props.professional.filter((item, inx) => {
      if (medium === item.medium) {
        return item
      }
    })
    this.setState({
      update_prof: _proffessionals
    })
  }
  filterProfOnDemand() {
    setTimeout(() => {
      let _proff = this.props.professional;
      const school_id = (this.refs.school.value !== '') ? this.props.schools[this.refs.school.value].id : null;
      const medium = (this.refs.medium.value !== '') ? this.refs.medium.value : null;

      //console.log('school_id ' + school_id + ' medium ' + medium + ' class_name ' + class_name);

      if (!isEmpty(school_id)) {
        _proff = _proff.filter((item) => {
          if (item.school_id === school_id) {
            return item
          }
        })
      }
      if (!isEmpty(medium)) {
        _proff = _proff.filter((item) => {
          if (item.medium === medium) {
            return item
          }
        })
      }
      this.setState({
        filtered_prof: _proff
      })
    }, 100);
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_proffessional = this.props.professional;
      if (_all_proffessional && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_proffessional = this.props.professional;
    
    if (!isEmpty(_all_proffessional)) {
      const _school_proffessional = _all_proffessional.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        filtered_prof: _school_proffessional
      })
    }
  }
 
  render() {
    const { basicInfo, filtered_prof, formIsHalfFilledOut,
      selected_school_index, medium_arr, medium } = this.state;
    const { user, schools, professional } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content" >
        <Helmet>
          <title>Professional List</title>
        </Helmet> <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && professional &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">Professional List</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    showClassFilter={false}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                  />
                  <div className="form-group mt-1 d-none">
                    <NavLink to="/add_professional.jsp" className="btn btn-primary btn-sm mr-3">
                      Add New <i className="fa fa-plus" />
                    </NavLink>
                  </div>
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                {filtered_prof.length > 0 ?
                  <div className="table-scrollable">
                    <table className="table table-striped table-bordered table-hover table-sm">
                      <thead>
                        <tr>
                          <th />
                           <th>
                            <div className="custom-control custom-checkbox">
                              <input type="checkbox"
                                id="select_all" className="custom-control-input"
                                onChange={event => this.checkHandler(event, 'select_all', true)} />
                              <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                            </div>
                          </th>
                          <th></th>
                          <th>General Information</th>
                          <th>Class Teacher</th>
                          <th>Month Salary</th>
                          <th>Remark/ Narration</th>
                        </tr>
                      </thead>
                      {filtered_prof.length > 0 ?
                        <tbody>
                          {filtered_prof.map((item, index) => {
                            return (
                              <tr key={index}>
                                <td>{index + 1}</td>
                                 <td>
                                  <div className="custom-control custom-control-inline custom-checkbox">
                                    <input type="checkbox"
                                      checked={item.checked}
                                      id={`check_` + index} name="customRadio" className="custom-control-input"
                                      onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
                                    <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                                  </div>
                                </td>
                                <td className="profile-pic">
                                  <NavLink to={`/edit_professional.jsp/${item.id}`} className="">
                                    {!isEmpty(item.profile_image) ?
                                      < img src={`${process.env.PUBLIC_URL}` + item.profile_image} alt={item.emp_name} />
                                      : (item.gender === 'Male' ?
                                        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} />
                                        :
                                        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_female.jpg`} />)
                                    }
                                  </NavLink>
                                </td>
                                <td><NavLink to={`professional_profile.jsp/${item.id}`} className="">
                                  {item.emp_name}
                                </NavLink> S/o <br />
                                  {item.emp_f_name}<br />
                                  {item.address} 
                                </td>
                                <td>{item.class_teacher}</td>
                                <td><input type="text" className="form-control form-control-sm"/></td>
                                <td><textarea className="form-control form-control-sm"></textarea></td>
                              </tr>
                            )
                          }
                          )}
                        </tbody>
                        : null}
                    </table>
                  </div>
                  : null}
              </div>
              <div className="card-footer text-right">
								<button type="button"
									onClick={event => this.confirmBoxSubmit(event)}
									className="btn btn-primary btn-sm mr-2">Update</button>
							</div>
            </div>
          </>
        }
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: professional } = state.professional;
  const filteredSchoolData = state.filteredSchoolData;
  return { user, schools, professional, filteredSchoolData };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getProfessional: professionalAction.getProfessional,
}

export default connect(mapStateToProps, actionCreators)(withRouter(CreateSalary));