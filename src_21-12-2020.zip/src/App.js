import React, { Component, Suspense, lazy } from 'react';
import { Router, Route, Redirect, Switch, withRouter } from 'react-router-dom';
import 'react-picky/dist/picky.css';
import Alert from 'react-s-alert';
// import { connect } from 'react-redux';
import { history } from './_helpers';
import SuspenseFallback from "./utility/suspenseFallback";
// Layouts

// const Home = lazy(() => import("./Home"));
import FrontLayoutRoute from "./layouts/FrontLayoutRoute";
import FrontLayoutInnerRoute from "./layouts/FrontLayoutInnerRoute";
import UserLayoutRoute from "./layouts/UserLayoutRoute";
import DashboardLayoutRoute from "./layouts/DashboardLayoutRoute";
// Components

const FrontIndexPage = lazy(()=> import( "./components/front_index_page"));
const Mission = lazy(()=> import( "./components/front_mission_page"));
const Login = lazy(()=> import( "./components/login"));
const Dashboard = lazy(()=> import( "./components/dashboard"));
const HolidayCalendar = lazy(()=> import( "./components/holiday_calendar"));
/*const PortalStudents = lazy(()=> import( "./components/portal_students"));*/
const AllStudents = lazy(()=> import( "./components/all_students"));
const AddStudent = lazy(()=> import( "./components/add_student"));
const EditStudent = lazy(()=> import( "./components/edit_student"));
const StudentProfile = lazy(()=> import( "./components/student_profile"));
const AllProfessionals = lazy(()=> import( "./components/all_professionals"));
const AssignSubjects = lazy(()=> import( "./components/assign_subjects"));
const AddProfessional = lazy(()=> import( "./components/add_professional"));
const EditProfessional = lazy(()=> import( "./components/edit_professional"));
const ProfessionalProfile = lazy(()=> import( "./components/professional_profile"));
const FeesCollection = lazy(()=> import( "./components/fees_collection"));
const GetFees = lazy(()=> import( "./components/get_fees"));
const AllExamShedules = lazy(()=> import( "./components/all_exam_shedules"));
const CreateExamShedule = lazy(()=> import( "./components/create_exam_shedule"));
const PrintShedule = lazy(()=> import( "./components/print_shedule"));
const SheduleInnings = lazy(()=> import( "./components/shedule_innings"));
const SheduleNotes = lazy(()=> import( "./components/shedule_notes"));
const AddSheduleNotes = lazy(()=> import( "./components/add_shedule_notes"));
const EditSheduleNotes = lazy(()=> import( "./components/edit_shedule_notes"));
/*const GetEstimate = lazy(()=> import( "./components/get_estimate"));
const NewGetEstimate = lazy(()=> import( "./components/new_get_estimate"));*/
const FeesReceipt = lazy(()=> import( "./components/fees_receipt"));
const PaymentList = lazy(()=> import( "./components/payment_list"));
const AllAccLedger = lazy(()=> import( "./components/all_acc_ledger"));
const AllAccGroup = lazy(()=> import( "./components/all_acc_group"));
const NewPayment = lazy(()=> import( "./components/new_payment"));
const EditPayment = lazy(()=> import( "./components/edit_payment"));
const IncomeList = lazy(()=> import( "./components/income_list"));
const NewIncome = lazy(()=> import( "./components/new_income"));
const EditIncome = lazy(()=> import( "./components/edit_income"));
const AllMarks = lazy(()=> import( "./components/all_marks"));
const AddMarks = lazy(()=> import( "./components/add_marks"));
const ExcelToUpdate = lazy(()=> import( "./components/excel_to_update"));
//const UpdateMarks = lazy(()=> import( "./components/update_marks"));
const AllExam = lazy(()=> import( "./components/all_exam"));
const AddExam = lazy(()=> import( "./components/add_exam"));
const EditExam = lazy(()=> import( "./components/edit_exam"));
const SubjectMaxMarks = lazy(()=> import( "./components/subject_max_marks"));
const ViewMarksStudent = lazy(()=> import( "./components/view_marks_student"));
const AddMarksStudent = lazy(()=> import( "./components/add_marks_student"));
const GetMarksSheet = lazy(()=> import( "./components/get_marks_sheet"));
const VisitSite = lazy(()=> import( "./components/visit_site"));
const SelectTemplate = lazy(()=> import( "./components/select_template"));
const GroupInfo = lazy(()=> import( "./components/group_info"));
const SchoolInfo = lazy(()=> import( "./components/school_info"));
const EditGroupInfo = lazy(()=> import( "./components/edit_group_info"));
const AllSlider = lazy(()=> import( "./components/all_slider"));
const AddSlider = lazy(()=> import( "./components/add_slider"));
const EditSlider = lazy(()=> import( "./components/edit_slider"));
const AllArticle = lazy(()=> import( "./components/all_article"));
const UpdateArticle = lazy(()=> import( "./components/update_article"));
const AllEvents = lazy(()=> import( "./components/all_events"));
const AddEvent = lazy(()=> import( "./components/add_event"));
const EditEvent = lazy(()=> import( "./components/edit_event"));
const AllGalleries = lazy(()=> import( "./components/all_galleries"));
const AddGallery = lazy(()=> import( "./components/add_gallery"));
const EditGallery = lazy(()=> import( "./components/edit_gallery"));
const ViewGallery = lazy(()=> import( "./components/view_gallery"));
const AllImages = lazy(()=> import( "./components/all_images"));
const AddImage = lazy(()=> import( "./components/add_image"));
const EditImage = lazy(()=> import( "./components/edit_image"));
const AllReview = lazy(()=> import( "./components/all_review"));
const AddReview = lazy(()=> import( "./components/add_review"));
const AhowReview = lazy(()=> import( "./components/show_review"));
const Backup = lazy(()=> import( "./components/backup"));
const BalanceSheet = lazy(()=> import( "./components/balance_sheet"));
const ProfitAndLoss = lazy(()=> import( "./components/profit_n_loss"));
const AccountingVoucher = lazy(()=> import( "./components/accounting_vouchers"));
const LedgerMonthlySummary = lazy(()=> import( "./components/ledger_monthly_summary"));
const LedgerVouchers = lazy(()=> import( "./components/ledger_vouchers"));
const GroupSummary = lazy(()=> import( "./components/group_summary"));
const CreateMonthlyDues = lazy(()=> import( "./components/create_monthly_dues"));
const AllDuesStatus = lazy(()=> import( "./components/all_dues_status"));
const AllGroupStatus = lazy(()=> import( "./components/all_group_status"));
const AllLedgerStatus = lazy(()=> import( "./components/all_ledger_status"));
const AllCostCenterStatus = lazy(()=> import( "./components/all_cost_center_status"));
const AllTypeNTime = lazy(()=> import( "./components/all_type_n_time"));
const AddTypeNTime = lazy(()=> import( "./components/add_type_n_time"));
const EditTypeNTime = lazy(()=> import( "./components/edit_type_n_time"));
const AllFeeStructure = lazy(()=> import( "./components/all_fee_structure"));
const AddFeeDetails = lazy(()=> import( "./components/add_fee_structure"));
const EditFeeDetails = lazy(()=> import( "./components/edit_fee_structure"));
const AllTranspoartRoot = lazy(()=> import( "./components/all_transpoart_root"));
const AddTranspoartRoot = lazy(()=> import( "./components/add_transpoart_root"));
const EditTranspoartRoot = lazy(()=> import( "./components/edit_transpoart_root"));
const AllLesson = lazy(()=> import( "./components/all_lesson"));
const AddLesson = lazy(()=> import( "./components/add_lesson"));
const EditLesson = lazy(()=> import( "./components/edit_lesson"));
const ViewLesson = lazy(()=> import( "./components/view_lesson"));
const StudentLesson = lazy(()=> import( "./components/student_lesson"));
const LessonFAQs = lazy(()=> import( "./components/lesson_faqs"));
const LessonFAQsReply = lazy(()=> import( "./components/lesson_faqs_reply"));
const AllETest = lazy(()=> import( "./components/all_e_test"));
const AllNewTest = lazy(()=> import( "./components/add_new_test"));
const TestAttempt = lazy(()=> import( "./components/test_attempt"));
const TestResult = lazy(()=> import( "./components/test_result"));
const AllClass = lazy(()=> import( "./components/all_class"));
const AddClass = lazy(()=> import( "./components/add_class"));
const EditClass = lazy(()=> import( "./components/edit_class"));
const AllSubject = lazy(()=> import( "./components/all_subject"));
const AddSubject = lazy(()=> import( "./components/add_subject"));
const EditSubject = lazy(()=> import( "./components/edit_subject"));
const AllUsers = lazy(()=> import( "./components/all_users"));
const AddUser = lazy(()=> import( "./components/add_user"));
const EditUser = lazy(()=> import( "./components/edit_user"));
/*const AllSubjectPart = lazy(()=> import( "./components/all_subject_part"));
const AddSubjectPart = lazy(()=> import( "./components/add_subject_part"));
const EditSubjectPart = lazy(()=> import( "./components/edit_subject_part"));
const AllSubjectPartPart = lazy(()=> import( "./components/all_subject_part_part"));
const AddSubjectPartPart = lazy(()=> import( "./components/add_subject_part_part"));
const EditSubjectPartPart = lazy(()=> import( "./components/edit_subject_part_part"));*/
const UserRoll = lazy(()=> import( "./components/user_roll"));
const AddUserRoll = lazy(()=> import( "./components/add_user_roll"));
const EditUserRoll = lazy(()=> import( "./components/edit_user_roll"));
const UploadStudents = lazy(()=> import( "./components/upload_students"));
const UploadStaff = lazy(()=> import( "./components/upload_staff"));
const AllSchools = lazy(()=> import( "./components/all_schools"));
const AddSchool = lazy(()=> import( "./components/add_school"));
const EditSchool = lazy(()=> import( "./components/edit_school"));
const CreateSalary = lazy(()=> import( "./components/create_salary"));

const NotFound = lazy(()=> import( "./components/not_found"));

class App extends Component {

  constructor(props) {
    super(props);
    history.listen((location, action) => {
      // clear alert on location change
      // this.props.clearAlerts();
      // console.log(history);
    //  console.log("inside history listen");
    });
  }
  render() {
    // console.log(this.props);
    return (
      <Router history={history} >
        <Suspense fallback={<SuspenseFallback />}>
        <Switch>
          <Route exact path={"/"}>
            <Redirect exact to="/Home.jsp" />
          </Route>
          <FrontLayoutRoute exact path="/Home.jsp" component={FrontIndexPage} />
          <FrontLayoutInnerRoute path="/Mission.jsp" component={Mission} />
          <UserLayoutRoute path="/Login.jsp" component={Login} />
          <DashboardLayoutRoute path="/Dashboard.jsp" component={Dashboard} />
          <DashboardLayoutRoute path="/holiday_calendar.jsp" component={HolidayCalendar} />
          {/* <DashboardLayoutRoute path="/portal_students.jsp" component={PortalStudents} /> */}
          <DashboardLayoutRoute path="/all_students.jsp" component={AllStudents} />
          <DashboardLayoutRoute path="/add_student.jsp" component={AddStudent} />
          <DashboardLayoutRoute path="/edit_student.jsp/:id" component={EditStudent} />
          <DashboardLayoutRoute path="/student_profile.jsp/:id" component={StudentProfile} />
          <DashboardLayoutRoute path="/all_professionals.jsp" component={AllProfessionals} />
          <DashboardLayoutRoute path="/assign_subjects.jsp/:id" component={AssignSubjects} />
          <DashboardLayoutRoute path="/add_professional.jsp" component={AddProfessional} />
          <DashboardLayoutRoute path="/edit_professional.jsp/:id" component={EditProfessional} />
          <DashboardLayoutRoute path="/professional_profile.jsp/:id" component={ProfessionalProfile} />
          <DashboardLayoutRoute path="/fees_collection.jsp" component={FeesCollection} />
          <DashboardLayoutRoute path="/get_fees.jsp" component={GetFees} />
          <DashboardLayoutRoute path="/all_exam_shedules.jsp" component={AllExamShedules} />
          <DashboardLayoutRoute path="/create_exam_shedule.jsp" component={CreateExamShedule} />
          <DashboardLayoutRoute path="/print_shedule.jsp" component={PrintShedule} />
          <DashboardLayoutRoute path="/shedule_innings.jsp" component={SheduleInnings} />
          <DashboardLayoutRoute path="/shedule_notes.jsp" component={SheduleNotes} />
          <DashboardLayoutRoute path="/add_shedule_notes.jsp" component={AddSheduleNotes} />
          <DashboardLayoutRoute path="/edit_shedule_notes.jsp/:id" component={EditSheduleNotes} />
          {/*<DashboardLayoutRoute path="/get_estimate.jsp" component={GetEstimate} />
          <DashboardLayoutRoute path="/new_get_estimate.jsp" component={NewGetEstimate} />*/}
          <DashboardLayoutRoute path="/fees_receipt.jsp" component={FeesReceipt} />
          <DashboardLayoutRoute path="/payment_list.jsp" component={PaymentList} />
          <DashboardLayoutRoute path="/all_acc_ledger.jsp" component={AllAccLedger} />
          <DashboardLayoutRoute path="/all_acc_group.jsp" component={AllAccGroup} />
          <DashboardLayoutRoute path="/new_payment.jsp" component={NewPayment} />
          <DashboardLayoutRoute path="/edit_payment.jsp/:id" component={EditPayment} />
          <DashboardLayoutRoute path="/income_list.jsp" component={IncomeList} />
          <DashboardLayoutRoute path="/new_income.jsp" component={NewIncome} />
          <DashboardLayoutRoute path="/edit_income.jsp/:id" component={EditIncome} />
          <DashboardLayoutRoute path="/all_marks.jsp" component={AllMarks} />
          <DashboardLayoutRoute path="/add_marks.jsp" component={AddMarks} />
          <DashboardLayoutRoute path="/excel_to_update.jsp" component={ExcelToUpdate} />
          {/*<DashboardLayoutRoute path="/update_marks.jsp/:id" component={UpdateMarks} />*/}
          <DashboardLayoutRoute path="/all_exam.jsp" component={AllExam} />
          <DashboardLayoutRoute path="/add_exam.jsp" component={AddExam} />
          <DashboardLayoutRoute path="/edit_exam.jsp/:id" component={EditExam} />
          <DashboardLayoutRoute path="/subject_max_marks.jsp" component={SubjectMaxMarks} />
          <DashboardLayoutRoute path="/view_marks_student.jsp/:id/:class_id/" component={ViewMarksStudent} />
          <DashboardLayoutRoute path="/add_marks_student.jsp/:id/:school_id/" component={AddMarksStudent} />
          <DashboardLayoutRoute path="/get_marks_sheet.jsp" component={GetMarksSheet} />
          <DashboardLayoutRoute path="/visit_site.jsp" component={VisitSite} />
          <DashboardLayoutRoute path="/select_template.jsp" component={SelectTemplate} />
          <DashboardLayoutRoute path="/group_info.jsp" component={GroupInfo} />
          <DashboardLayoutRoute path="/school_info.jsp" component={SchoolInfo} />
          <DashboardLayoutRoute path="/edit_group_info.jsp" component={EditGroupInfo} />
          <DashboardLayoutRoute path="/all_slider.jsp" component={AllSlider} />
          <DashboardLayoutRoute path="/add_slider.jsp" component={AddSlider} />
          <DashboardLayoutRoute path="/edit_slider.jsp/:id" component={EditSlider} />
          <DashboardLayoutRoute path="/all_article.jsp" component={AllArticle} />
          <DashboardLayoutRoute path="/update_article.jsp/:id" component={UpdateArticle} />
          <DashboardLayoutRoute path="/all_events.jsp" component={AllEvents} />
          <DashboardLayoutRoute path="/add_event.jsp" component={AddEvent} />
          <DashboardLayoutRoute path="/edit_event.jsp/:id" component={EditEvent} />
          <DashboardLayoutRoute path="/all_galleries.jsp" component={AllGalleries} />
          <DashboardLayoutRoute path="/add_gallery.jsp" component={AddGallery} />
          <DashboardLayoutRoute path="/edit_gallery.jsp/:id" component={EditGallery} />
          <DashboardLayoutRoute path="/view_gallery.jsp/:id" component={ViewGallery} />
          <DashboardLayoutRoute path="/all_images.jsp" component={AllImages} />
          <DashboardLayoutRoute path="/add_image.jsp" component={AddImage} />
          <DashboardLayoutRoute path="/edit_image.jsp/:id" component={EditImage} />
          <DashboardLayoutRoute path="/all_review.jsp" component={AllReview} />
          <DashboardLayoutRoute path="/add_review.jsp" component={AddReview} />
          <DashboardLayoutRoute path="/show_review.jsp" component={AhowReview} />
          <DashboardLayoutRoute path="/backup.jsp" component={Backup} />
          <DashboardLayoutRoute path="/balance_sheet.jsp" component={BalanceSheet} />
          <DashboardLayoutRoute path="/profit_n_loss.jsp" component={ProfitAndLoss} />
          <DashboardLayoutRoute path="/accounting_voucher.jsp/:id" component={AccountingVoucher} />
          <DashboardLayoutRoute path="/ledger_monthly_summary.jsp/:id" component={LedgerMonthlySummary} />
          <DashboardLayoutRoute path="/ledger_vouchers.jsp/:l_id/:m_id" component={LedgerVouchers} />
          <DashboardLayoutRoute path="/group_summary.jsp/:type/:id/:grp_id?" component={GroupSummary} />
          <DashboardLayoutRoute path="/create_monthly_dues.jsp" component={CreateMonthlyDues} />
          <DashboardLayoutRoute path="/all_dues_status.jsp" component={AllDuesStatus} />
          <DashboardLayoutRoute path="/all_group_status.jsp" component={AllGroupStatus} />
          <DashboardLayoutRoute path="/all_ledger_status.jsp" component={AllLedgerStatus} />
          <DashboardLayoutRoute path="/all_cost_center_status.jsp" component={AllCostCenterStatus} />
          <DashboardLayoutRoute path="/all_type_n_time.jsp" component={AllTypeNTime} />
          <DashboardLayoutRoute path="/add_type_n_time.jsp" component={AddTypeNTime} />
          <DashboardLayoutRoute path="/edit_type_n_time.jsp/:id" component={EditTypeNTime} />
          <DashboardLayoutRoute path="/all_fee_structure.jsp" component={AllFeeStructure} />
          <DashboardLayoutRoute path="/add_fee_structure.jsp" component={AddFeeDetails} />
          <DashboardLayoutRoute path="/edit_fee_structure.jsp/:id" component={EditFeeDetails} />
          <DashboardLayoutRoute path="/all_transpoart_root.jsp" component={AllTranspoartRoot} />
          <DashboardLayoutRoute path="/add_transpoart_root.jsp" component={AddTranspoartRoot} />
          <DashboardLayoutRoute path="/edit_transpoart_root.jsp/:id" component={EditTranspoartRoot} />
          <DashboardLayoutRoute path="/all_lesson.jsp" component={AllLesson} />
          <DashboardLayoutRoute path="/add_lesson.jsp" component={AddLesson} />
          <DashboardLayoutRoute path="/edit_lesson.jsp/:id" component={EditLesson} />
          <DashboardLayoutRoute path="/view_lesson.jsp/:id" component={ViewLesson} />
          <DashboardLayoutRoute path="/student_lesson.jsp/:id" component={StudentLesson} />
          <DashboardLayoutRoute path="/lesson_faqs.jsp/:id" component={LessonFAQs} />
          <DashboardLayoutRoute path="/lesson_faqs_reply.jsp/:id" component={LessonFAQsReply} />
          <DashboardLayoutRoute path="/all_e_test.jsp" component={AllETest} />
          <DashboardLayoutRoute path="/add_new_test.jsp" component={AllNewTest} />
          <DashboardLayoutRoute path="/test_attempt.jsp" component={TestAttempt} />
          <DashboardLayoutRoute path="/test_result.jsp" component={TestResult} />
          <DashboardLayoutRoute path="/all_class.jsp" component={AllClass} />
          <DashboardLayoutRoute path="/add_class.jsp" component={AddClass} />
          <DashboardLayoutRoute path="/edit_class.jsp/:id" component={EditClass} />
          <DashboardLayoutRoute path="/all_subject.jsp" component={AllSubject} />
          <DashboardLayoutRoute path="/add_subject.jsp" component={AddSubject} />
          <DashboardLayoutRoute path="/edit_subject.jsp/:id" component={EditSubject} />
          <DashboardLayoutRoute path="/all_users.jsp" component={AllUsers} />
          <DashboardLayoutRoute path="/add_user.jsp" component={AddUser} />
          <DashboardLayoutRoute path="/edit_user.jsp/:id" component={EditUser} />
          {/*<DashboardLayoutRoute path="/all_subject_part.jsp" component={AllSubjectPart} />
          <DashboardLayoutRoute path="/add_subject_part.jsp" component={AddSubjectPart} />
          <DashboardLayoutRoute path="/edit_subject_part.jsp/:id" component={EditSubjectPart} />
          <DashboardLayoutRoute path="/all_subject_part_part.jsp" component={AllSubjectPartPart} />
          <DashboardLayoutRoute path="/add_subject_part_part.jsp" component={AddSubjectPartPart} />
          <DashboardLayoutRoute path="/edit_subject_part_part.jsp/:id" component={EOditSubjectPartPart} />*/}
          <DashboardLayoutRoute path="/user_roll.jsp" component={UserRoll} />
          <DashboardLayoutRoute path="/add_user_rollv" component={AddUserRoll} />
          <DashboardLayoutRoute path="/edit_user_roll.jsp/:id" component={EditUserRoll} />
          <DashboardLayoutRoute path="/upload_students.jsp" component={UploadStudents} />
          <DashboardLayoutRoute path="/upload_staff.jsp" component={UploadStaff} />
          <DashboardLayoutRoute path="/all_schools.jsp" component={AllSchools} />
          <DashboardLayoutRoute path="/add_school.jsp" component={AddSchool} />
          <DashboardLayoutRoute path="/edit_school.jsp/:id" component={EditSchool} />
          <DashboardLayoutRoute path="/create_salary.jsp" component={CreateSalary} />

          <DashboardLayoutRoute component={NotFound} />
        </Switch> 
        <Alert stack={{ limit: 3 }} html={true} />
        </Suspense>
      </Router>
    );
  }
}

// function mapState(state) {
//   //   const { alert } = state;
//   //  return { alert };
// }

// const actionCreators = {
// 	// clearAlerts: alertActions.clear
// };

// export default withRouter(connect(mapState, actionCreators)(App));
export default withRouter(App);
 
