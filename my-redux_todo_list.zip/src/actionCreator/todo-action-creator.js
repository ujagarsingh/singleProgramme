import {ADD_TODO, DELETE_TODO,  EDIT_TODO, GET_TODOS} from "../actionTypes/todo-action-types";
import Axios from "axios";

const ROOT_URL = "http://localhost:7777/todos";
const GET_URL = "http://localhost:7777/todos";

const addTodo = ({ text }) => {
    /*
    return {
      type : ADD_TODO,
      payload:{
        text : text,
        completed : false
      }
    }
    */
   return (dispatch) => {
     Axios.post(ROOT_URL, {
        text : text,
        completed : false
      }).then(()=>{
        //success
        dispatch({
          type : ADD_TODO,
          payload:{
            text : text,
            completed : false
          }
        })
      }).catch(()=>{
        //error
      })
  };
};
const deleteTodo = (index, todoId) => {
    /*return {
      type : DELETE_TODO,
      payload:index,
    }
    */
   return (dispatch) => {
     Axios.delete(ROOT_URL, +"/"+ todoId).then(()=>{
      //success
      dispatch({
        type : DELETE_TODO,
        payload:index
      })
     }).chatch(()=>{
       //error
     })
   }
  };
const editTodo = ({ text, index }) => {
    return {
        type : EDIT_TODO,
        payload:{
          index : index,
          text :text
        }
      }
    };
const getTodos = () => {
    return dispatch => {
        Axios.get(ROOT_URL).then((response)=>{
          dispatch ({
            type:  GET_TODOS, 
            payload : response.data
          })
        }).catch(()=>{
          //error
        })
      }
    };

export { getTodos, addTodo, deleteTodo, editTodo};

/*
import axios from "axios";

export const getPost = () => {
  return (dispatch) => {
    axios.get("https://jsonplaceholder.typicode.com/posts")
    .then((data)=>{
      dispatch({
        type:"  GET_POSTS",
        payload:"  data"
      })
    }).catch(()=>{
      //error
    })
  }
}*/