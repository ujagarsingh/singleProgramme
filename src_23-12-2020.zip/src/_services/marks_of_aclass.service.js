// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const marksOfaClassService = {
    getMarksOfaClass
};

function getMarksOfaClass(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam/one_class_all_marks.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}
