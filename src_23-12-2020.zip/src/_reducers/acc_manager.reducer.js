import { accManagerConstants } from '../_constants';
const initialState = {
  item: {
    ledger_fy_report: { data_obj: [], g_total: {}, ledger_name: '' },
    // ledger_summary_of_month: [],
    // group_balance: [],
    ledger_data: [],
  }
}

export function accManager(state = initialState, action) {
  switch (action.type) {
    case accManagerConstants.ACC_MANAGER_REQUEST:
      return {
        loading: true,
        item: state.item
      };
    case accManagerConstants.ACC_MANAGER_SUCCESS:
      // debugger
      const initial_obj = { ...state.item, ...action.response };
      return {
        item: initial_obj,
        loading: false,
      };
    case accManagerConstants.ACC_MANAGER_FAILURE:
      return {
        error: action.error
      };


    case accManagerConstants.ACC_LDR_YEAR_REPORT_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_LDR_YEAR_REPORT_SUCCESS:
      // debugger
      const new_obj = { ...state.item, ledger_fy_report : action.response.ledger_fy_report};
      console.log(new_obj);
      return {
        item: new_obj,
        loading: false,
      };
    case accManagerConstants.ACC_LDR_YEAR_REPORT_FAILURE:
      return {
        error: action.error
      };


    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_SUCCESS:
      const new_month_obj = { ...state.item, ledger_summary_of_month: action.response, single_voucer: "" };
      return {
        item: new_month_obj,
        loading: false,
      };
    case accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_FAILURE:
      return {
        error: action.error
      };


    case accManagerConstants.ACC_SINGLE_VOUCHER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accManagerConstants.ACC_SINGLE_VOUCHER_SUCCESS:
      const single_voucher_obj = { ...state.item, single_voucer: action.response };
      return {
        item: single_voucher_obj,
        loading: false,
      };
    case accManagerConstants.ACC_SINGLE_VOUCHER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}