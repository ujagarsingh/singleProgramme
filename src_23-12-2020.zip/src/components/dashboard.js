import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Chart } from 'react-google-charts';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { groupActions, schoolsAction, dashCounterAction } from '../_actions';
import { isEmptyObj } from '../utility/utilities';

class Dashboard extends Component {
  state = {
    user_category: '',
    total_student: '',
    total_emp: '',
    jwt: '',
    total_income: '',
    total_paryment: '',
    chart_title: [['Months', 'Income', 'Expenses', 'Profit']],
    chart_data: [
      ['Apr', 15000, 10540, 15050],
      ['May', 25000, 52040, 9350],
      ['Jun', 12450, 20540, 3350],
      ['Jul', 46542, 55040, 8350],
      ['Aug', 32165, 54000, 5350],
      ['Sep', 8452, 45540, 35050],
      ['Oct', 32112, 15540, 4550],
      ['Nov', 120004, 15540, 8550],
      ['Dec', 125004, 52540, 7350],
      ['Jan', 1000, 42400, 6200],
      ['Feb', 1170, 4560, 9250],
      ['Mar', 660, 11820, 4300]
    ],
    final_chart_data: [],
    formIsHalfFilledOut: false,
    schools_arr: []
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.dashCounter)) {
      this.props.getDashCounter();
    }


    const _final_data = this.state.chart_title.concat(this.state.chart_data);
    this.setState({
      final_chart_data: _final_data,
    })
    this.getDimentionOfChart()
  }

  currencyFormate(amo) {
    amo = amo.toString();
    var lastThree = amo.substring(amo.length - 3);
    var otherNumbers = amo.substring(0, amo.length - 3);
    if (otherNumbers !== '')
      lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
    return res;
  }
  getDimentionOfChart() {
    //const 
  }
  sendMessage(event) {
    event.preventDefault();
    alert('on working.....')
  }
  render() {
    const { formIsHalfFilledOut, final_chart_data } = this.state;
    const { dashc, user } = this.props;
    return (
      <div className="page-content d-none">
        <Helmet>
          <title>Dashboard Admin</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Dashboard Admin</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
          </div>
          <div className="filter-con">
          </div>
        </div>

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {user &&
              <div className="table-scrollable">
                {(user.user_category === '1' || user.user_category === '2') ?
                  <div className="col">
                    {/* start widget */}
                    <div className="state-overview">
                      {dashc &&
                        <div className="row">
                          <div className="col-xl-3 col-md-6 col-12">
                            <div className="info-box bg-success">
                              <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-graduate"></i></span>
                              <div className="info-box-content">
                                <span className="info-box-text">Students</span>
                                <span className="info-box-number">{dashc.total_student}</span>
                              </div>
                              {/* /.info-box-content */}
                            </div>
                            {/* /.info-box */}
                          </div>
                          {/* /.col */}
                          <div className="col-xl-3 col-md-6 col-12">
                            <div className="info-box bg-warning">
                              <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-tie"></i></span>
                              <div className="info-box-content">
                                <span className="info-box-text">Employee</span>
                                <span className="info-box-number">{dashc.total_emp}</span>
                              </div>
                              {/* /.info-box-content */}
                            </div>
                            {/* /.info-box */}
                          </div>
                          {/* /.col */}
                          <div className="col-xl-3 col-md-6 col-12">
                            <div className="info-box bg-primary">
                              <span className="info-box-icon m-0 push-bottom"><i className="fas fa-seedling"></i></span>
                              <div className="info-box-content">
                                <span className="info-box-text">Collection</span>
                                <span className="info-box-number">
                                  {(dashc.total_income) ? this.currencyFormate(dashc.total_income) : 0}
                                </span><span><i className="ml-1 fas fa-rupee-sign"></i></span>
                              </div>
                              {/* /.info-box-content */}
                            </div>
                            {/* /.info-box */}
                          </div>
                          {/* /.col */}
                          <div className="col-xl-3 col-md-6 col-12">
                            <div className="info-box bg-danger">
                              <span className="info-box-icon m-0 push-bottom"><i className="fab fa-gripfire"></i></span>
                              <div className="info-box-content">
                                <span className="info-box-text">Expenses</span>
                                <span className="info-box-number">
                                  {(dashc.tatal_expenses)? this.currencyFormate(dashc.tatal_expenses) : 0}
                                </span><span><i className="ml-1 fas fa-rupee-sign"></i></span>
                              </div>
                              {/* /.info-box-content */}
                            </div>
                            {/* /.info-box */}
                          </div>
                          {/* /.col */}
                        </div>
                      }
                    </div>
                    {/* end widget */}
                    {/* chart start */}
                    <div className="pt-3 pb-3">
                      <div className="card card-box">
                        <div className="card-body p-0">
                          <Chart
                            width={'100%'}
                            height={'400px'}
                            chartType="LineChart"
                            loader={<div>Loading Chart</div>}
                            data={[
                              ['x', 'School-1', 'School-2', 'School-3'],
                              ['apr', 18, 10, 12],
                              ['may', 9, 5, 18],
                              ['jun', 11, 3, 13],
                              ['jul', 27, 19, 17],
                              ['aug', 23, 15, 7],
                              ['sep', 17, 9, 9],
                              ['oct', 18, 10, 19],
                              ['nov', 9, 5, 15],
                              ['dec', 11, 3, 3],
                              ['jan', -10, 5, 8],
                              ['feb', 23, 15, 6],
                              ['mar', 17, 9, 9],
                            ]}
                            options={{
                              hAxis: {
                                title: 'Months',
                              },
                              vAxis: {
                                title: 'Profit',
                              },
                              series: {
                                // 0 : { curveType: 'function' },
                              },
                            }}
                            rootProps={{ 'data-testid': '4' }}
                          />
                        </div>
                        <div className="card-head d-flex p-2 bg-light">
                          <div className="form-inline m-auto">
                            <div className="form-group mr-3">
                              <label className="control-label mr-2">Schools :</label>
                              <select className="form-control form-control-sm">
                                <option>All</option>
                                <option>School 1</option>
                                <option>School 2</option>
                                <option>School 3</option>
                              </select>
                            </div>
                            <div className="form-group mr-3">
                              <label className="control-label mr-2">Session :</label>
                              <select className="form-control form-control-sm">
                                <option>All</option>
                                <option>2019 - 2020</option>
                                <option>2020 - 2021</option>
                              </select>
                            </div>
                            <div className="form-group mr-3">
                              <label className="control-label mr-2">Timing :</label>
                              <select className="form-control form-control-sm">
                                <option>All</option>
                                <option>Apr</option>
                                <option>May</option>
                                <option>Jun</option>
                                <option>Jul</option>
                                <option>Aug</option>
                                <option>Sep</option>
                                <option>Oct</option>
                                <option>Nov</option>
                                <option>Dec</option>
                                <option>Jan</option>
                                <option>Feb</option>
                                <option>Mar</option>
                                <option>Mar - May</option>
                                <option>Jun - Aug</option>
                                <option>Sep - Nov</option>
                                <option>Dec - Feb</option>
                              </select>
                            </div>
                            <div className="form-group mr-3">
                              <label className="control-label mr-2">Category :</label>
                              <select className="form-control form-control-sm">
                                <option>Select...</option>
                                <option>Income</option>
                                <option>Payment</option>
                                <option>Profit</option>
                                <option>Fees</option>
                                <option>Donetions</option>
                                <option>Other Income</option>
                                <option>Salary</option>
                                <option>Staff Expences</option>
                                <option>Conveyance</option>
                              </select>
                            </div>
                            <div className="form-group">
                              <button className="btn btn-primary btn-sm">Go</button>
                            </div>
                          </div>
                        </div>

                        <div className="card-body">
                          <table className="table table-bordered table-hover table-striped">
                            <thead>
                              <tr>
                                <th></th>
                                <th>Apr</th>
                                <th>May</th>
                                <th>Jun</th>
                                <th>Jul</th>
                                <th>Aug</th>
                                <th>Sep</th>
                                <th>Oct</th>
                                <th>Nov</th>
                                <th>Dec</th>
                                <th>Jan</th>
                                <th>Feb</th>
                                <th>Mar</th>
                                <th>Total</th>
                              </tr>
                            </thead>
                            <tfoot>
                              <tr>
                                <th>Total</th>
                                <th>561500</th>
                                <th>561653</th>
                                <th>564567</th>
                                <th>569245</th>
                                <th>569999</th>
                                <th>564567</th>
                                <th>561234</th>
                                <th>563056</th>
                                <th>568524</th>
                                <th>565632</th>
                                <th>564521</th>
                                <th>562584</th>
                                <th>56983456</th>
                              </tr>
                            </tfoot>
                            <tbody>
                              <tr>
                                <td>School 1</td>
                                <td>1500</td>
                                <td>1653</td>
                                <td>4567</td>
                                <td>9245</td>
                                <td>9999</td>
                                <td>4567</td>
                                <td>1234</td>
                                <td>3056</td>
                                <td>8524</td>
                                <td>5632</td>
                                <td>4521</td>
                                <td>2584</td>
                                <th>123456</th>
                              </tr>
                              <tr>
                                <td>School 2</td>
                                <td>1500</td>
                                <td>1653</td>
                                <td>4567</td>
                                <td>9245</td>
                                <td>9999</td>
                                <td>4567</td>
                                <td>1234</td>
                                <td>3056</td>
                                <td>8524</td>
                                <td>5632</td>
                                <td>4521</td>
                                <td>2584</td>
                                <th>853456</th>
                              </tr>
                              <tr>
                                <td>School 3</td>
                                <td>1500</td>
                                <td>1653</td>
                                <td>4567</td>
                                <td>9245</td>
                                <td>9999</td>
                                <td>4567</td>
                                <td>1234</td>
                                <td>3056</td>
                                <td>8524</td>
                                <td>5632</td>
                                <td>4521</td>
                                <td>2584</td>
                                <th>983456</th>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div className="row pt-3 pb-3">
                      <div className="col-md-8 col-sm-12">
                        <div className="card card-box">
                          <div className="card-head d-flex p-2 bg-light">
                            <header>New Questions</header>
                          </div>
                          <div className="card-body">
                            <h1 className="display-4">List of New Questions</h1>
                          </div>
                        </div>
                      </div>
                      {/* Quick Mail start */}
                      <div className="col-md-4 col-sm-12">
                        <div className="card-box card">
                          <div className="card-head d-flex p-2 bg-light">
                            <header>Quick Message</header>
                          </div>
                          <div className="card-body">
                            <div className="compose-mail">
                              <form method="post">
                                <div className="form-group mt-1">
                                  <label htmlFor="to" className="">To:</label>
                                  <input type="text" className="form-control form-control-sm" />
                                </div>
                                <div className="form-group mt-1">
                                  <label htmlFor="to" className="">Group:</label>
                                  <select className="form-control form-control-sm">
                                    <option>Select...</option>
                                    <option>Students</option>
                                    <option>Staff</option>
                                  </select>
                                </div>
                                <div className="form-group mt-1">
                                  <label htmlFor="to" className="">Select Class:</label>
                                  <select className="form-control form-control-sm">
                                    <option>Select...</option>
                                    <option>First</option>
                                    <option>Second</option>
                                  </select>
                                </div>
                                <div className="form-group mt-1">
                                  <label htmlFor="to" className="">Select Student:</label>
                                  <select className="form-control form-control-sm">
                                    <option>Select...</option>
                                    <option>Mohan</option>
                                    <option>Sohan</option>
                                  </select>
                                </div>

                                <div className="form-group m-b-10">
                                  <label htmlFor="subject" className="">All Receivers No.:</label>
                                  <textarea className="form-control form-control-sm" defaultValue={""} />
                                </div>
                                <div className="form-group m-b-10">
                                  <label htmlFor="subject" className="">Message:</label>
                                  <textarea className="form-control form-control-sm" defaultValue={""} />
                                </div>
                                <div className="box-footer clearfix">
                                  <button type="button" className="btn btn-primary btn-sm"
                                    onClick={(event) => { this.sendMessage(event) }}
                                  >
                                    Send
                                    <i className="fa fa-paper-plane-o" />
                                  </button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* end new student list */}
                  </div>
                  :
                  <div className="col">
                    {/* start widget */}
                    <div className="state-overview">
                      <div className="row">
                        <div className="col-xl-3 col-md-6 col-12">
                          <div className="info-box bg-success">
                            <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-graduate"></i></span>
                            <div className="info-box-content">
                              <span className="info-box-text">Total Attendance</span>
                              <span className="info-box-number">150</span>
                            </div>
                            {/* /.info-box-content */}
                          </div>
                          {/* /.info-box */}
                        </div>
                        {/* /.col */}
                        <div className="col-xl-3 col-md-6 col-12">
                          <div className="info-box bg-warning">
                            <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-tie"></i></span>
                            <div className="info-box-content">
                              <span className="info-box-text">Subjects</span>
                              <span className="info-box-number">5</span>
                            </div>
                            {/* /.info-box-content */}
                          </div>
                          {/* /.info-box */}
                        </div>
                        {/* /.col */}
                        <div className="col-xl-3 col-md-6 col-12">
                          <div className="info-box bg-primary">
                            <span className="info-box-icon m-0 push-bottom"><i className="fas fa-seedling"></i></span>
                            <div className="info-box-content">
                              <span className="info-box-text">Leave </span>
                              <span className="info-box-number">15</span>
                            </div>
                            {/* /.info-box-content */}
                          </div>
                          {/* /.info-box */}
                        </div>
                        {/* /.col */}
                        <div className="col-xl-3 col-md-6 col-12">
                          <div className="info-box bg-danger">
                            <span className="info-box-icon m-0 push-bottom"><i className="fab fa-gripfire"></i></span>
                            <div className="info-box-content">
                              <span className="info-box-text">Expenses</span>
                              <span className="info-box-number">450</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                }
              </div>
            }
          </div>
        </div>
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: dashc } = state.dashCounter;
  return { user, dashc };
}

const actionCreators = {
  getGroup: groupActions.getGroup,
  getSchools: schoolsAction.getSchools,
  getDashCounter: dashCounterAction.getDashCounter,
}

export default connect(mapStateToProps, actionCreators)(withRouter(Dashboard));