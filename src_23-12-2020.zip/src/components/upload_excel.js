import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import axios from 'axios';
//import { Picky } from 'react-picky';
//import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import CSVReader from 'react-csv-reader'
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
// import ExcelReader from '../utility/ExcelReader';
import { ExportCSV } from '../utility/Export_CSV/ExportCSV';
import { connect } from 'react-redux';
import { schoolsAction, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const SAVEIN_DATABASE = `http://schools.rajpsp.com/api/uploads/save_in_database.php`;
const INSERT_NEW_RECORDS = `http://schools.rajpsp.com/api/uploads/insert_new_records.php`;
const UPLOAD_STUDENTS = `http://schools.rajpsp.com/api/uploads/upload_student.php`;
const READ_CLASS_STUDENT = `http://schools.rajpsp.com/api/students/read.php`; 
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;  

const handleForce = (data, fileInfo) => console.dir(data, fileInfo);
const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
};

class UploadExcel extends Component {
  state = {
    schools_arr: [],
    students: [],
    user_id: 1,
    filtered_students: [],
    dis_continue_students: [],
    updated_students: [],
    new_students: [],
    old_student_Obj: [],
    dup_students: [],
    isDuplicate: false,
    firstStage: false,
    secondStage: false,
    student_Obj: [],
    medium_arr: [],
    medium: '',
    staff_Obj: [],
    formIsHalfFilledOut: false,
    dummy_stu_data: [],
  }

  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].id : '';
      const _medium = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
      }, () => {
        this.filterStudentsOfSchool(_sch_id);
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  createDummyStudentCsv() {
    let item = [{
      s_id: '',
      student_name: '',
      father_name: '',
      mother_name: '',
      stu_class: '',
      medium: '',
      admission_number: '',
      caste: '',
      gender: '',
      dob: '',
      is_rte_student: ''
    }];

    this.setState({
      dummy_stu_data: item
    })
  }
  filterStudentsOfSchool(sch_id) {
    const _students = this.state.students;
    const _filtered_students = _students.filter((item) => {
      if (item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      filtered_students: _filtered_students
    }, () => {
      const dup_students = this.duplicateStudent(_filtered_students);
      this.setState({ dup_students })
    });
  }
  matchStudent(data_1, data_2) {
    // getting data_1 to whitch is not meet in data_2;

    console.log(JSON.stringify(data_1));
    console.log(JSON.stringify(data_2));
    debugger

    const _obj = data_1.filter((online_item) => {
      let flag = 1;
      const _on_val = online_item.admission_number;
      data_2.forEach((sofware_item) => {
        const _off_val = online_item.admission_number;
        if (_on_val == _off_val) {
          flag = 0
        }
      })
      if (flag === 1) {
        return online_item
      }
    })
    return _obj
  }
  duplicateStudent(filtered) {
    let _ids1 = [];
    let _ids2 = [];
    filtered.map((item) => {
      const ct_no = item['admission_number']
      if (_ids1.includes(ct_no)) {
        _ids2.push(ct_no);
      } else {
        _ids1.push(ct_no);
      }
    })
    // debugger
    const dup_student = filtered.filter((item, inx) => {
      const ct_no = item['admission_number']
      if (_ids2.includes(ct_no)) {
        return item
      }
    })
    if (dup_student.length > 0) {
      this.setState({ isDuplicate: true })
    }
    return dup_student;
  }
  matchUpdatedStudent(data_1, data_2) {
    const _obj = data_1.filter((online_item) => {
      let flag = false;
      let _sofware_item = {};
      let _online_item = {};
      data_2.forEach((sofware_item) => {
        if (online_item.admission_number == sofware_item.admission_number) {
          if (
            online_item.student_name !== sofware_item.student_name ||
            online_item.father_name !== sofware_item.father_name ||
            online_item.mother_name !== sofware_item.mother_name ||
            online_item.stu_class !== sofware_item.stu_class ||
            online_item.caste !== sofware_item.caste ||
            online_item.gender !== sofware_item.gender
          ) {
            flag = true;
            _sofware_item = sofware_item;
            _online_item = online_item;
          }
        }
      })
      if (flag) {
        console.log('SoftWare Item --------- > ', _sofware_item)
        console.log('Online Item --------- > ', _online_item)
        // debugger;
        return online_item
      }
    })
    return _obj
  }

  dateInWords(stu_dob) {
    // debugger
    let d = new Date(stu_dob);
    let monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    let new_date = d.getDate() + "-" + monthNames[d.getMonth()] + "-" + d.getFullYear();;
    return new_date;
  }

  studentObjHandler = (new_obj) => {
    this.setState({
      dis_continue_students: [],
      new_students: [],
      updated_students: [],
      dup_students: [],
    }, () => {
      const filtered = this.state.filtered_students;
      const dis_continue_students = this.matchStudent(filtered, new_obj);
      const new_students = this.matchStudent(new_obj, filtered);
      const updated_students = this.matchUpdatedStudent(new_obj, filtered);
      const dup_students = this.duplicateStudent(filtered);
      const dis_cont_stud = dis_continue_students.filter((item) => {
        if (item.dis_continue === '0') {
          return item;
        }
      })
      if (dup_students.length > 0) {
        confirmAlert({
          title: 'stay one moment!',
          message: 'Please Check duplicate Student List and Do Update First.',
          buttons: [
            {
              label: 'Yes',
              // onClick: () => {
              //   this.props.history('/home/');
              // }
            },
            {
              label: 'No',
            }
          ]
        });
        this.setState({
          dup_students: dup_students
        })
      } else {
        this.setState({
          dis_continue_students: dis_cont_stud,
          new_students: new_students,
          updated_students: updated_students,
          // dup_students: dup_students,
          excel_student: new_obj,
          firstStage: true
        })
      }
    })
  }

  staffObjHandler = (obj) => {
    loadProgressBar();
    const _obj = obj.map((item) => {
      const _dob = item.dob;
      const _newdob = _dob.replace(/(..).(..).(....)/, "$3-$1-$2")
      const _item = { ...item };
      _item.dob = _newdob;
      _item.u_dise_code = ''; _item.psp_code = ''; _item.aadhar_number = ''; _item.religion = '';
      _item.mother_tongue = ''; _item.rural_urban = ''; _item.habitation_or_locality = '';
      _item.date_of_admission = ''; _item.admission_number = ''; _item.belong_to_bpl = '';
      _item.belong_to_disadvantaged_group = ''; _item.is_rte_student = '';
      _item.stu_class = ''; _item.class_studied_in_prev_year = ''; _item.status_of_previous_year = '';
      _item.days_child_attended_school = ''; _item.medium = ''; _item.type_of_disablity = '';
      _item.facilities_received_by_cwsn = ''; _item.no_of_uniform_sets = ''; _item.free_text_books = '';
      _item.free_transport = ''; _item.free_escort = ''; _item.mdm_beneficiary = ''; _item.free_hostel_facility = '';
      _item.child_attended_special_training = ''; _item.child_is_homeless = ''; _item.appeard = ''; _item.passed = '';
      _item.percentage_marks = ''; _item.stream_grades_11_n_12 = ''; _item.trade_sector_grades_9_to_12 = '';
      _item.iron_n_folic_acid = ''; _item.deworming_tablets = ''; _item.vitamin_a_supplement = '';
      _item.mobile_number = ''; _item.email_address = ''; _item.free_bicycle = '';
      return _item;
    })
    this.setState({
      staff_Obj: _obj
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getSchoolHandler();
            this.getStudentRecords();
            this.createDummyStudentCsv();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }



  getSchoolHandler() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id
    }
    axios.post(READ_SCHOOLS, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          schools_arr: getRes,
          errorMessages: getRes.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  }
  getStudentRecords() {
    const obj = {
      group_id: this.state.group_id,
      session_year_id: this.state.session_year_id,
      user_category: this.state.user_category,
      school_id: this.state.school_id
    }
    // console.log(JSON.stringify(obj));
    axios.post(READ_CLASS_STUDENT, obj)
      .then(res => {
        const resData = res.data;
        if (resData.length > 0) {
          this.setState({
            students: resData,
            errorMessages: resData.message
          });
        }
      }).catch((error) => {
        // error
      });
  }
  uploadStudentHandler = e => {
    loadProgressBar();
    e.preventDefault();
    const group_id = this.state.group_id;
    const school_id = this.state.school_id;
    const user_id = this.state.user_id;
    const session_year_id = this.state.session_year_id;
    const excel_student = this.state.excel_student;
    const obj = {
      group_id, school_id, session_year_id, user_id, excel_student: excel_student
    }
    console.log(JSON.stringify(obj))
    debugger
    axios.post(UPLOAD_STUDENTS, obj)
      .then(res => {
        const getRes = res.data;
        console.log(getRes)
        debugger
        this.setState({
          dis_continue_students: getRes.tc_student,
          new_students: getRes.new_student,
          updated_students: getRes.modify_student,
          secondStage: true
        })
        if (getRes.message) {
          Alert.success(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }

  generateMatchedStudentTable(students, title, flag) {
    // debugger
    return (
      <div className="table-responsive">
        <h6 className={"p-2 text-white " +
          ((flag === "NEW_STU") ? 'bg-success' :
            ((flag === "DUP_STU") ? 'bg-warning' :
              ((flag === "UPDATE_STU") ? 'bg-info' : 'bg-danger')))}>
          {title}
        </h6>
        <table className="table table-striped table-bordered table-hover text-nowrap table-sm">
          <thead>
            <tr>
              <th />
              <th>STUDENT NAME</th>
              <th>FATHER NAME</th>
              <th>MOTHER NAME</th>
              <th>DOB</th>
              <th>GENDER</th>
              <th>SOCIAL CATEGORY</th>
              <th>ENROL NO.</th>
              <th>CLASS</th>
            </tr>
          </thead>
          <tbody>
            {students.map((value, index) => {
              return (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{value.student_name}</td>
                  <td>{value.father_name}</td>
                  <td>{value.mother_name}</td>
                  <td>{value.dob}</td>
                  <td>{value.gender}</td>
                  <td>{value.caste}</td>
                  <td>{value.admission_number}</td>
                  <td>{value.stu_class}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    )
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.saveOnDatabaseStudentHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  saveOnDatabaseStudentHandler() {
    const group_id = this.state.group_id;
    const school_id = this.state.school_id;
    const user_id = this.state.user_id;
    const session_year_id = this.state.session_year_id;
    const obj = {
      group_id, school_id, session_year_id, user_id,
    }
    console.log(JSON.stringify(obj))
    debugger
    axios.post(SAVEIN_DATABASE, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        // debugger
        if (getRes.message) {
          Alert.success(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  refreshHandler() {
    this.setState({
      firstStage: false,
      secondStage: false,
      dup_students: [],
      dis_continue_students: [],
      new_students: [],
      selected_school_index: '',
      updated_students: []
    })
  }
  addNewRecords(ev) {
    ev.preventDefault();
    const group_id = this.state.group_id;
    const school_id = this.state.school_id;
    const user_id = this.state.user_id;
    const session_year_id = this.state.session_year_id;
    const new_students = this.state.new_students;
    const obj = {
      group_id, school_id, session_year_id, user_id, new_students
    }
    console.log(JSON.stringify(obj))
    debugger
    axios.post(INSERT_NEW_RECORDS, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        // debugger
        if (getRes.message) {
          Alert.success(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  papaparseOptions = {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    transformHeader: header =>
      header
        .toLowerCase()
        .replace(/\W/g, '_')
  }
  handleForce(data) {
    debugger
    console.log(data)

  }
  handleDarkSideForce(data) {
    debugger
    console.log(data)

  }
  render() {
    const { formIsHalfFilledOut, firstStage, secondStage, dup_students, dis_continue_students, new_students,
      selected_school_index, updated_students, schools_arr, medium_arr, medium,
      student_Obj, staff_Obj, dummy_stu_data } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Upload Excel</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Upload Student Data</div>

        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body">
            <div className="table-scrollable">
              <div className="card-box">
                <div>
                  {dup_students.length > 0 ?
                    this.generateMatchedStudentTable(dup_students, 'Allready You Have Duplicate Student', 'DUP_STU')
                    : null}

                  {new_students.length > 0 ?
                    this.generateMatchedStudentTable(new_students, 'New Student', 'NEW_STU')
                    : null}
                  {/* {new_students.length > 0 ?
                    <button className="btn btn-primary mb-4" onClick={event => { this.addNewRecords(event) }}>Add New Record</button>
                    : null} */}
                  {updated_students.length > 0 ?
                    this.generateMatchedStudentTable(updated_students, 'Updated Student', 'UPDATE_STU')
                    : null}
                  {/* {updated_students.length > 0 ?
                    <button className="btn btn-primary mb-4" onClick={event => { this.updateNewRecords(event) }}>Update New Record</button>
                    : null} */}
                  {dis_continue_students.length > 0 ?
                    this.generateMatchedStudentTable(dis_continue_students, 'Now Dis Continued Student', 'DIS_CONTI')
                    : null}
                  {/* {dis_continue_students.length > 0 ?
                    <button className="btn btn-primary mb-4" onClick={event => { this.disContinueRecords(event) }}>Dis Continue Record</button>
                    : null} */}
                  {staff_Obj.length > 0 ?
                    <div className="table-responsive">
                      <table className="table table-striped table-bordered table-hover table-sm">
                        <thead>
                          <tr>
                            <th />
                            <th>U-DISE CODE</th>
                            <th>PSP CODE</th>
                            <th>AADHAR NUMBER</th>
                            <th>STUDENT NAME</th>
                            <th>FATHER NAME</th>
                            <th>MOTHER NAME</th>
                            <th>DOB</th>
                            <th>GENDER</th>
                            <th>SOCIAL CATEGORY</th>
                            <th>RELIGION</th>
                            <th>MOTHER TONGUE</th>
                            <th>RURAL/URBAN</th>
                            <th>HABITATION OR LOCALITY</th>
                            <th>DATE OF ADMISSION</th>
                            <th>ADMISSION NUMBER</th>
                            <th>BELONG TO BPL</th>
                            <th>BELONG TO DISADVANTAGED GROUP</th>
                            <th>GETTING FREE EDUCATION</th>
                            <th>STUDYING IN CLASS</th>
                            <th>CLASS STUDIED IN PREV. YEAR</th>
                            <th>IF IN CLASS 1, STATUS OF PREVIOUS YEAR</th>
                            <th>DAYS CHILD ATTENDED SCHOOL (IN THE PREV. YEAR)</th>
                            <th>MEDIUM OF INSTRUCTION</th>
                            <th>TYPE OF DISABLITY</th>
                            <th>FACILITIES RECEIVED BY CWSN</th>
                            <th>NO. OF UNIFORM SETS</th>
                            <th>FREE TEXT BOOKS</th>
                            <th>FREE TRANSPORT</th>
                            <th>FREE ESCORT</th>
                            <th>MDM BENEFICIARY</th>
                            <th>FREE HOSTEL FACILITY</th>
                            <th>CHILD ATTENDED SPECIAL TRAINING</th>
                            <th>CHILD IS HOMELESS</th>
                            <th>APPEARD</th>
                            <th>PASSED</th>
                            <th>% MARKS</th>
                            <th>STREAM (GRADES 11 & 12)</th>
                            <th>TRADE/SECTOR (GRADES 9 TO 12)</th>
                            <th>IRON & FOLIC ACID</th>
                            <th>DEWORMING TABLETS</th>
                            <th>VITAMIN-A SUPPLEMENT</th>
                            <th>MOBILE NUMBER</th>
                            <th>EMAIL ADDRESS</th>
                            <th>FREEBICYCLE</th>
                          </tr>
                        </thead>
                        <tbody>
                          {student_Obj.map((value, index) => {
                            return (
                              <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{value.u_dise_code}</td>
                                <td>{value.psp_code}</td>
                                <td>{value.aadhar_number}</td>
                                <td>{value.student_name}</td>
                                <td>{value.father_name}</td>
                                <td>{value.mother_name}</td>
                                <td>{value.dob}</td>
                                <td>{value.gender}</td>
                                <td>{value.caste}</td>
                                <td>{value.religion}</td>
                                <td>{value.mother_tongue}</td>
                                <td>{value.rural_urban}</td>
                                <td>{value.habitation_or_locality}</td>
                                <td>{value.date_of_admission}</td>
                                <td>{value.admission_number}</td>
                                <td>{value.belong_to_bpl}</td>
                                <td>{value.belong_to_disadvantaged_group}</td>
                                <td>{value.is_rte_student}</td>
                                <td>{value.stu_class}</td>
                                <td>{value.class_studied_in_prev_year}</td>
                                <td>{value.status_of_previous_year}</td>
                                <td>{value.days_child_attended_school}</td>
                                <td>{value.medium}</td>
                                <td>{value.type_of_disablity}</td>
                                <td>{value.facilities_received_by_cwsn}</td>
                                <td>{value.no_of_uniform_sets}</td>
                                <td>{value.free_text_books}</td>
                                <td>{value.free_transport}</td>
                                <td>{value.free_escort}</td>
                                <td>{value.mdm_beneficiary}</td>
                                <td>{value.free_hostel_facility}</td>
                                <td>{value.child_attended_special_training}</td>
                                <td>{value.child_is_homeless}</td>
                                <td>{value.appeard}</td>
                                <td>{value.passed}</td>
                                <td>{value.percentage_marks}</td>
                                <td>{value.stream_grades_11_n_12}</td>
                                <td>{value.trade_sector_grades_9_to_12}</td>
                                <td>{value.iron_n_folic_acid}</td>
                                <td>{value.deworming_tablets}</td>
                                <td>{value.vitamin_a_supplement}</td>
                                <td>{value.mobile_number}</td>
                                <td>{value.email_address}</td>
                                <td>{value.free_bicycle}</td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>
                    : null}
                </div>

              </div>
            </div>
          </div>
        </div>


        <div className="card-footer">
          <div className="row text-center mb-1">
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 1</span>
            </div>
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 2</span>
            </div>
            <div className="col">
              <span className="badge badge-pill badge-primary">Stap 3</span>
            </div>
          </div>
          <div className="form-body">
            {!firstStage ?
              <div className="form-inline">
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools_arr.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group  ml-auto">
                  {/* <ExcelReader studentObjHandler={this.studentObjHandler} /> */}

                  <CSVReader
                    cssClass="csv-reader-input"
                    // label="Select CSV with secret Death Star statistics"
                    onFileLoaded={this.studentObjHandler}
                    onError={this.handleDarkSideForce}
                    parserOptions={papaparseOptions}
                    inputId="ObiWan"
                    inputStyle={{ color: 'red' }}
                  />
                </div>
              </div>
              : null}
            <div className="mt-1 d-flex">
              <ExportCSV
                csvData={dummy_stu_data}
                fileName={'upload_student_data'} />

              <button type="button"
                className="btn btn-secondary ml-auto mr-1"
                disabled={(dis_continue_students.length > 0 ||
                  new_students.length > 0 || updated_students.length > 0 && !secondStage) ? false : true}
                onClick={this.uploadStudentHandler}>
                Upload
                </button>
              <button type="button"
                className="btn btn-success mr-1"
                disabled={!secondStage}
                onClick={event => this.confirmBoxSubmit(event)}>
                Save
                </button>

              <button type="button" className="btn btn-danger"
                onClick={event => this.refreshHandler(event)}>
                Refresh</button>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  return { user, schools, students  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getStudents: studentsAction.getStudents,
}

export default connect(mapStateToProps, actionCreators)(withRouter(UploadExcel));