import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { Picky } from 'react-picky';

class FeeField extends Component {
   state = {
      name: '',
      options: [],
      values: [],
	  formIsHalfFilledOut: false,
   }

   componentDidMount() {
      const { name, options } = this.props;
      this.setState({
         name: name,
         options: options

      })
   }

   singleFeeHandler = (value) => {
      //console.log(this.state);
      //console.count('onChange');
      this.setState({
         values: value,
		 formIsHalfFilledOut: true
      }, () => {
         const obj = this.state;
         this.props.singleFeeHandler(obj);
      });
   }
   render() {
      const { name, options, values } = this.state;
      // console.log(this.state)
      // debugger
      return (
         <div className="col-md-4">
            <div className="form-group row mb-1">
               <label className="control-label col-md-4">{name} </label>
               <div className="col-md-8">
                  <div className="input-group mb-1">
                     <div className="form-control p-0 border-0">
                        <Picky
                           value={values}
                           options={options}
                           disabled={(options.length > 0) ? false : true}
                           onChange={this.singleFeeHandler}
                           open={false}
                           valueKey="id"
                           labelKey={name}
                           multiple={true}
                           includeSelectAll={true}
                           includeFilter={true}
                           dropdownHeight={200}
                        />
                     </div>
                     <div className="input-group-append">
                        <button 
                        disabled={(options.length > 0) ? false : true}
                        type="button" className="btn btn-block btn-primary btn-sm">
                           <i className="fas fa-check"></i>
                           </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      )
   }
}
export default withRouter(FeeField);