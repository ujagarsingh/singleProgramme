import { eventsConstants } from '../_constants';
import { eventsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const eventsActions = {
    getEvents,
    create, 
    update,
    delete : _delete
};

function getEvents() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        eventsService.getEvents()
            .then(
                response => {
                    dispatch(success(response.data.event_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: eventsConstants.EVENTS_REQUEST } }
    function success(response) { return { type: eventsConstants.EVENTS_SUCCESS, response } }
    function failure(error) { return { type: eventsConstants.EVENTS_FAILURE, error } }
}
 

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        eventsService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: eventsConstants.CREATE_REQUEST } }
    function success(response) { return { type: eventsConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: eventsConstants.CREATE_FAILURE, error } }
}
 

function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        eventsService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: eventsConstants.UPDATE_REQUEST } }
    function success(response) { return { type: eventsConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: eventsConstants.UPDATE_FAILURE, error } }
}
 

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        eventsService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                        );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: eventsConstants.DELETE_REQUEST } }
    function success(response) { return { type: eventsConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: eventsConstants.DELETE_FAILURE, error } }
}
 