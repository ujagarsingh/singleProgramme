import { defaultEventsConstants } from '../_constants';
import { defaultEventsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultEventsActions = {
    getDefaultEvents
};

function getDefaultEvents() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultEventsService.getDefaultEvents()
            .then(
                response => {
                    dispatch(success(response.data.event_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultEventsConstants.EVENTS_REQUEST } }
    function success(response) { return { type: defaultEventsConstants.EVENTS_SUCCESS, response } }
    function failure(error) { return { type: defaultEventsConstants.EVENTS_FAILURE, error } }
}
 