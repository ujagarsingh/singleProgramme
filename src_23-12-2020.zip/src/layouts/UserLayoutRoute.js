import React, { Component } from "react";
import { withRouter } from 'react-router';
import { Route } from "react-router-dom";
import UserLayout from "./UserLayout";

class UserLayoutRoute extends Component {
  render() {
    const { component: Component, ...rest } = this.props;
    return (
      <Route {...rest} 
      render = {matchProps => (
          <UserLayout>
            <Component {...matchProps} />
          </UserLayout>
        )} />
    );
  };
};

export default withRouter(UserLayoutRoute);
