import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
  schoolsAction, examCategoryClassExamAction,
  singleClassCategoryExamsAction, singleStudentSubjectExamsMarksobtnAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_CLASS_EXAM_DETAIL_URL = `http://schools.rajpsp.com/api/exam/one_class_category_exams.php`;
// getStudentofClass(class_id)
const READ_URL = `http://schools.rajpsp.com/api/exam/one_student_subject_exams_marksobtn.php`;
// const READ_SCHOOL_URL = `http://schools.rajpsp.com/api/school/read.php`;
const CREATE_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/create_multiple.php`;
// const DELETE_EXISTING_MARKS = `http://schools.rajpsp.com/api/marks_obtain/delete_existing_records.php`;

class AddMarksStudent extends Component {
  state = {
    id: '',
    school_id: '',
    sch_name: '',
    sch_address: '',
    student: '',
    admission_number: '',
    class_id: '',
    subject: [],
    total_max_marks: 0,
    total_obt_marks: 0,
    total_avg_marks: 0,
    student_result: null,
    student_grade: null,
    exam_detail: '', // report card titles
    formIsHalfFilledOut: false,
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    });
    if (fieldName === 'marks_obtain') {
      const sub_id = event.target.attributes['data-sub-id'].value;
      const exam_id = event.target.attributes['data-exm-id'].value;
      const tga_value = (event.target.value !== "") ? parseInt(event.target.value) : '';

      const allSub = this.state.student.subject;
      allSub.map((item, index) => {
        if (sub_id === item.id) {
          item.exams.map((item_e, idx) => {
            if (exam_id === item_e.id && tga_value <= parseInt(item_e.max_marks)) {
              item_e['marks_obtain'] = Math.abs(tga_value);
              return item_e;
            } else {
              return item_e;
            }
          })
          return item;
        } else {
          return item;
        }
      })
      // //console.log(_allSub);

      this.calculateMarksForReportCardHandler();
    }
  };

  getStudentofClass(class_id) {
    const classData = this.props.examCategoryClassExam.filter((item) => {
      if (item.class_id === class_id) {
        return item
      }
    })
    this.setState({
      exam_detail: classData[0].exam_cate
    });
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const all_examcate = this.props.examCategoryClassExam;
      if (_filter && all_examcate) {
        // this.filterBySchoolHandler();
        this.getSingleStudentHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  // checkAuthentication(obj) {
  //   let { match } = this.props;
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //           id: match.params.id,
  //           school_id: match.params.school_id
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getSingleStudentHandler();
  //           // this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  getSingleStudentHandler() {
    //get student record 
    const { id, class_id } = this.props.match.params;
    this.props.getSingleCCE({ "class_id": class_id });
    this.props.getSingleSSEM({ "stu_id": id, "class_id": class_id });

    this.setState({
      // student: student[0],
      // admission_number: student[0].admission_number,
      // subject: student[0].subject,
      // medium: student[0].medium,
      class_id: class_id,
      stu_id: id,
      // exam_detail: _exam_cate[0].exam_cate
    });
    // //get student record 
    // loadProgressBar();
    // const obj = {
    //   id: this.state.id,
    //   group_id: this.state.group_id,
    //   school_id: this.state.school_id,
    // }
    // // console.log(JSON.stringify(obj))
    // axios.post(READ_URL, obj)
    //   .then(res => {
    //     const student = res.data;
    //     this.setState({
    //       student: student,
    //       admission_number: student.admission_number,
    //       subject: student.subject,
    //       medium: student.medium,
    //       class_id: student.class_id,
    //       errorMessages: res.data.message
    //     }, () => {
    //       this.getClassWiseExamDetailsHandler(student.class_id);
    //       this.calculateMarksForReportCardHandler();
    //       this.getSchoolHandler(student.school_id);
    //     });
    //     // console.log(JSON.stringify(this.state.student));
    //   })
    //   .catch((error) => {
    //     // error
    //   });
  };
  getClassWiseExamDetailsHandler(class_id) {
    const obj = {
      class_id: class_id,
      medium: this.state.medium,
      school_id: this.state.school_id,
      group_id: this.state.group_id
    }
    loadProgressBar();
    // console.log(JSON.stringify(obj));
    axios.post(READ_CLASS_EXAM_DETAIL_URL, obj)
      .then(res => {
        // debugger;
        const examDetail = res.data;
        this.setState({
          exam_detail: examDetail,
          errorMessages: res.data.message
        });
      })
      .catch((error) => {
        // error
      });
  }
  // getSchoolHandler(id) {
  //   // read school info
  //   loadProgressBar();
  //   axios.get(READ_SCHOOL_URL + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         //id: getRes.id,
  //         sch_name: getRes.sch_name,
  //         /*sch_reg_no: getRes.sch_reg_no,
  //         sch_recog_no: getRes.sch_recog_no,
  //         sch_contact_num: getRes.sch_contact_num,
  //         sch_mobile_num: getRes.sch_mobile_num,
  //         sch_email: getRes.sch_email,*/
  //         sch_address: getRes.sch_address,
  //         /*sch_medium: getRes.sch_medium,
  //         sch_logo: getRes.sch_logo,
  //         sch_wel_mes_title: getRes.sch_wel_mes_title,
  //         sch_wel_mes: getRes.sch_wel_mes,*/
  //         errorMessages: getRes.message
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  calculateMarksForReportCardHandler() {
    const allSub = this.state.student.subject;
    ////console.log(JSON.stringify(allSub));
    let _total_max_marks = 0;
    let _total_obt_marks = 0;
    const _allSub = allSub.map((item, index) => {
      let max_marks = 0;
      let mks_obtain = 0;
      const _exam = item.exams.map((item_e, idx) => {
        max_marks += (item_e.max_marks !== '') ? parseInt(item_e.max_marks) : 0;
        mks_obtain += (item_e.marks_obtain !== '') ? parseInt(item_e.marks_obtain) : 0;
      })

      _total_max_marks += max_marks;
      _total_obt_marks += mks_obtain;

      item['t_mm'] = max_marks;
      item['t_mo'] = mks_obtain;
      return item;
    })
    ////console.log(_allSub);
    this.getReport(_total_max_marks, _total_obt_marks)
  }

  getReport(max_marks, otn_marsk) {
    let grade = "";
    let result = "";

    let totalMarks = otn_marsk;
    let averageMarks = (otn_marsk / max_marks) * 100;
    switch (
    (averageMarks > 60 && averageMarks <= 100) ? 1 :
      (averageMarks > 50 && averageMarks < 60) ? 2 :
        (averageMarks > 40 && averageMarks < 50) ? 3 : 0
    ) {
      case 1: grade = "A"; result = "First Class"; break;
      case 2: grade = "B"; result = "Second Class"; break;
      case 3: grade = "C"; result = "Third Class"; break;
      case 0: grade = "D"; result = "Fail"; break;
    }

    this.setState({
      total_max_marks: max_marks,
      total_obt_marks: totalMarks,
      total_avg_marks: averageMarks,
      student_result: result,
      student_grade: grade
    })


    /*
    document.getElementById('txtStudentName').value = document.getElementById('txtName').value;
            document.getElementById('txtStudentClass').value = document.getElementById('txtClass').value;
            document.getElementById('txtTotalMarks').value = totalMarks;
            document.getElementById('txtAvgMarks').value = averageMarks;
            document.getElementById('txtGrade').value = grade;
            document.getElementById('txtResult').value = result;*/
  }
  confirmBoxSubmit = (event, stu_id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            //this.deleteExistingRecords(stu_id);
            this.singleUpdateHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  // deleteExistingRecords(stu_id) {
  //   //event.preventDefault();
  //   axios.post(DELETE_EXISTING_MARKS + '?id=' + stu_id)
  //     .then(res => {
  //       const getRes = res.data;
  //       if (getRes.success !== undefined) {
  //         Alert.success(getRes.success, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //         this.singleUpdateHandler();
  //       } else if (getRes.error !== undefined) {
  //         Alert.error(getRes.error, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //         this.singleUpdateHandler();
  //       }
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  singleUpdateHandler = () => {
    //e.preventDefault();
    loadProgressBar();
    var _obj = [];
    let counter = 0;
    this.state.subject.map((item, index) => {
      //item = subject
      if (item.sub_lavel !== '2') {
        item.exams.map((item_e, idx) => {
          //item = exam
          if (item_e.marks_obtain !== '') {
            _obj[counter] = {
              max_marks: item_e.max_marks,
              class_id: this.state.class_id,
              exam_id: item_e.id,
              sub_id: item.id,
              admission_number: this.state.admission_number,
              marks_obtain: item_e.marks_obtain,
              id: item_e.mark_entry_id,
            }
            counter++;
          }
        })
      }
    })
    const singleObj = { myObj: _obj };
    //console.log(JSON.stringify(singleObj));
    axios.post(CREATE_MAX_MARKS, singleObj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
    // document.location.reload();
  }

  render() {
    const { stu_id, admission_number, class_id,  formIsHalfFilledOut } = this.state;
    const { singleStudentSubjectExamsMarksobtn, singleClassCategoryExams } = this.props;
    console.log(this.props)
    return (
      <div className="page-content">
        <Helmet>
          <title>Add Marks of Student</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Add/ Edit Marks of Student</div>
        </div>
        {singleStudentSubjectExamsMarksobtn && singleClassCategoryExams &&
          <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event, admission_number)}>
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="col-md-12">
                  <div className="d-flex">

                    <table className="table-sm mr-auto table-bordered mb-3">
                      <tbody>
                        <tr>
                          <td className="p-1">Name : </td>
                          <td className="p-1"><strong>{singleStudentSubjectExamsMarksobtn.student_name}</strong></td>
                          <td className="p-1"> Roll No.</td>
                          <td className="p-1">{singleStudentSubjectExamsMarksobtn.roll_number}</td>
                        </tr>
                        <tr>
                          <td className="p-1">Mother Name</td>
                          <td className="p-1">{singleStudentSubjectExamsMarksobtn.mother_name} </td>
                          <td className="p-1">Father Name</td>
                          <td className="p-1">{singleStudentSubjectExamsMarksobtn.father_name} </td>
                        </tr>
                        <tr>
                          <td className="p-1">Class</td>
                          <td className="p-1" >{singleStudentSubjectExamsMarksobtn.class_name_portal}</td>
                          <td className="p-1">Medium</td>
                          <td className="p-1" >{singleStudentSubjectExamsMarksobtn.medium}</td>
                        </tr>
                        <tr>
                          <td className="p-1">Address</td>
                          <td className="p-1" colSpan="3"><strong>ANDHI, JAIPUR - 303109</strong></td>
                        </tr>
                      </tbody>
                    </table>
                    <div className="img-thumbnail mb-3 ml-3">
                      {singleStudentSubjectExamsMarksobtn.student_image !== '' ?
                        < img src={`${process.env.PUBLIC_URL}` + singleStudentSubjectExamsMarksobtn.student_image} width="120px" alt={singleStudentSubjectExamsMarksobtn.student_name} />
                        : (singleStudentSubjectExamsMarksobtn.gender === 'Boy' ?
                          <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} width="120px" />
                          :
                          <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} width="120px" />)
                      }
                    </div>
                  </div>
                  {singleClassCategoryExams !== '' ?
                    <div className="table-responsive m-t-40">
                      <table className="table table-hover table-bordered table-sm">
                        <thead className="thead-light">
                          <tr>
                            <th rowSpan={2} className="text-center"></th>
                            <th rowSpan={2} className="text-center">SUBJECT</th>
                            {singleClassCategoryExams.exams.map((item, index) => {
                              return (
                                <th key={index} rowSpan={2} className="text-center">
                                  <strong>{item.exam_name}</strong>
                                  <table className="table m-0">
                                    <tbody>
                                      <tr>
                                        <td width="50%" className="p-1">MAX</td>
                                        <td className="p-1">OBTAIN</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              )
                            })
                            }
                            <th colSpan={2} className="text-center">
                              <strong>TOTAL</strong>
                              <table className="table m-0">
                                <tbody>
                                  <tr>
                                    <td width="50%" className="p-1">MAX</td>
                                    <td className="p-1">OBTAIN</td>
                                  </tr>
                                </tbody>
                              </table>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {singleStudentSubjectExamsMarksobtn.exam_type.map((subject, sub_inx) => {
                            return (
                              <React.Fragment key={sub_inx}>
                                {(subject !== '') ? subject.subjects.map((item, index) => {
                                  return (
                                    <tr key={index}>
                                      <td className="text-center">{index + 1}</td>
                                      <td className="text-left">
                                        <span className={(item.sub_lavel === '11') ? "pl-3" : ""}>
                                          {item.sub_name}
                                        </span>
                                      </td>
                                      {(item.exams_cat.length > 0) ? item.exams_cat.map((item_e, index) => {
                                        return (
                                          <td key={index} className="text-right">
                                            {(item_e.max_marks != '0') ?
                                              <table className="table m-0" data-exam={item_e.exam_name}>
                                                <tbody>
                                                  {(item.sub_lavel !== '2') ?
                                                    (<tr>
                                                      <td width="50%" className="p-1">{item_e.max_marks}</td>
                                                      <td className="p-1">
                                                        <input type="number"
                                                          name="marks_obtain"
                                                          value={item_e.marks_obtain}
                                                          data-sub-id={item.id}
                                                          data-exm-id={item_e.id}
                                                          onChange={event => this.changeHandler(event, 'marks_obtain')}
                                                          className="form-control form-control-sm text-center" />
                                                      </td>
                                                    </tr>
                                                    ) : (
                                                      <tr className="invisible">
                                                        <td width="50%" className="p-1">&nbsp;</td>
                                                        <td className="p-1">&nbsp;</td>
                                                      </tr>
                                                    )}
                                                </tbody>
                                              </table>
                                              : null}
                                          </td>
                                        )
                                      }) : null}
                                      <td className="text-right total_marks">
                                        {(item.sub_lavel === 2 || item.t_mm === 0) ? '' : item.t_mm}
                                      </td>
                                      <td className="text-right totel_obtain_marks">
                                        <strong>{(item.sub_lavel === 2 || item.t_mo === 0) ? '' : item.t_mo}</strong>
                                      </td>
                                    </tr>
                                  )
                                }) : null}
                              </React.Fragment>
                            )
                          })}


                        </tbody>
                      </table>
                    </div>
                    : null}
                </div>
              </div>
            </div>
            <div className="card-footer text-right">
              <button className="btn btn-primary mr-2" type="submit">
                Update </button>
              <NavLink
                to={`/view_marks_student.jsp/${stu_id}/${class_id}`}
                className="btn btn-secondary mr-2">View Marksheet</NavLink>
              <NavLink
                to={`/all_marks.jsp`}
                className="btn btn-danger">Back</NavLink>
            </div>
          </form>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: singleClassCategoryExams } = state.singleClassCategoryExams;
  const { item: singleStudentSubjectExamsMarksobtn } = state.singleStudentSubjectExamsMarksobtn;
  return { user, schools, singleStudentSubjectExamsMarksobtn, singleClassCategoryExams };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getSingleCCE: singleClassCategoryExamsAction.getSingleCCE,
  getSingleSSEM: singleStudentSubjectExamsMarksobtnAction.getSingleSSEM
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddMarksStudent));