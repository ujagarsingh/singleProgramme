import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
import { Helmet } from "react-helmet";

class ProfitAndLoss extends Component {

  state = {
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.accLedgerEntry)) {
      this.props.getAccLedgerEntry();
    }

    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }

    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    // this.checkFlag();
  }


  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Profit and Loss</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title">Profit and Loss</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body p-1 sfpage-body">
            <div className="acc-page acc-midline page-profit-n-loss">
              <div className="acc-page-head  container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="sec-title">
                      <div className="title-zone">Particulars</div>
                      <div className="info-zone">
                        <div className="org-name">School Name</div>
                        <div className="fy-detail">1-Apr-2020 to 1-Sep-2020</div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="sec-title">
                      <div className="title-zone">Particulars</div>
                      <div className="info-zone">
                        <div className="org-name">School Name</div>
                        <div className="fy-detail">1-Apr-2020 to 1-Sep-2020</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="acc-page-body container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="pl-detail-zone">
                      <div className="pl-detail-head">
                        <div className="head-name">Indirect Expenses</div>
                        <div className="head-amount">5,750.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Electricity Bill</div>
                        <div className="sub-head-amount">750.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Staff Sallary</div>
                        <div className="sub-head-amount">5,000.00</div>
                      </div>
                    </div>
                    <div className="pl-detail-zone">
                      <div className="pl-detail-head">
                        <div className="head-name">Excess of income over expenditure (P&L)</div>
                        <div className="head-amount">9,450.00</div>
                      </div>
                      <div className="pl-detail-sub-head"></div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="pl-detail-zone">
                      <div className="pl-detail-head">
                        <div className="head-name">Indirect Incomes</div>
                        <div className="head-amount">15,200.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Admission Fees</div>
                        <div className="sub-head-amount">1,500.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Bus Fees</div>
                        <div className="sub-head-amount">2,000.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Exam Fees</div>
                        <div className="sub-head-amount">1,000.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Hostel Fees</div>
                        <div className="sub-head-amount">2,000.00</div>
                      </div>
                      <div className="pl-detail-sub-head">
                        <div className="sub-head-name">Tution Fees</div>
                        <div className="sub-head-amount">8,700.00</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="acc-page-footer container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="sec-foot">
                      <div className="title-zone">Total</div>
                      <div className="amount-zone">15,200.00</div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="sec-foot">
                      <div className="title-zone">Total</div>
                      <div className="amount-zone">15,200.00</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: students } = state.students;
  const { item: accLedger } = state.accLedger;
  const { item: accGroup } = state.accGroup;
  const { item: accLedgerEntry } = state.accLedgerEntry;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, students, accLedger, accGroup, accLedgerEntry,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getStudents: studentsAction.getStudents,
  getAccLedger: accLedgerActions.getAccLedger,
  getAccGroup: accGroupActions.getAccGroup,
  getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,

}

export default connect(mapStateToProps, actionCreators)(withRouter(ProfitAndLoss));
