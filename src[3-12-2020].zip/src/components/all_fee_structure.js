import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, feeStructureAction, feeCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';
// import Alert from 'react-s-alert';
// import axios from 'axios';
// import { NavLink } from 'react-router-dom';

import AddFeeDetails from './add_fee_structure.js';
import EditFeeDetails from './edit_fee_structure.js';

import CommonFilters from '../utility/Filter/filter-schools';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const FEE_CATEGORY = `http://schools.rajpsp.com/api/fee_category/read_with_classiid_and_medium.php`; // old
// const FEE_CATEGORY = `http://schools.rajpsp.com/api/fee_category/fee_category_structure.php`; // new
// const FEE_DETAIL = `http://schools.rajpsp.com/api/fee_amount/read_classWise_cat_fee.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/fee_amount/delete.php`;

class AllFeeStructure extends Component {
  state = {
    medium: '',
    medium_arr: [],
    selected_classes: [],
    fee_category: '',
    fee_detail: '',
    display_fee_detail: [],
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {

    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterFeeStructureOnSchool(_sch_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: ''
    //   })
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   const _fee_detail = this.state.fee_detail.filter((item) => {
    //     if (item.medium === _medium) {
    //       return item
    //     }
    //   });
    //   this.setState({
    //     display_fee_detail: _fee_detail,
    //     formIsHalfFilledOut: true
    //   })
    // } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    // }
  }


  filterFeeStructureOnSchool() {

    const _filter = this.props.filteredSchoolData;

    const _allFeeStructure = this.props.feeStructure;
    const _feeStructure = _allFeeStructure.filter((item) => {
      if (item.school_id === _filter.slct_school_id) {
        return item
      }
    })

    setTimeout(() => {
      this.setState({
        display_fee_detail: _feeStructure
      })
    }, 10);
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.feeStructure)) {
      this.props.getFeeStructure();
    }
    if (isEmptyObj(this.props.feeCategory)) {
      this.props.getFeeCategory();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _feeStructure = this.props.feeStructure;
      if (_feeStructure && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    this.filterFeeStructureOnSchool();
    // const _all_student = this.props.students;
    // if (!isEmpty(_all_student)) {
    //   const _school_student = _all_student.filter((item) => {
    //     if (_filter.slct_school_id) {
    //       if (item.school_id === _filter.slct_school_id) {
    //         return item
    //       }
    //     } else {
    //       return item
    //     }
    //   })
    //   this.setState({
    //     display_student: _school_student,
    //   }, () => this.filterByClsHandler())
    // }
  }

  // filterByClsHandler = () => {
  //   const _fltr_school = this.props.filteredSchoolData;
  //   const _fltr_class = this.props.filteredClassesData;
  //   const _all_student = this.props.students;
  //   if (_all_student) {
  //     const _school_student = _all_student.filter((item) => {
  //       if (!isEmpty(_fltr_class.slct_cls_name)) {
  //         if (item.school_id === _fltr_school.slct_school_id &&
  //           item.stu_class === _fltr_class.slct_cls_name) {
  //           return item
  //         }
  //       } else {
  //         if (item.school_id === _fltr_school.slct_school_id) {
  //           return item
  //         }
  //       }
  //     })
  //     this.setState({
  //       display_student: _school_student
  //     })
  //   }
  // }


  
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getFeeDetailHandler();
  //           this.getFeeCategoryHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getFeeDetailHandler() {
  //   loadProgressBar();
  //   axios.get(FEE_DETAIL)
  //     .then(res => {
  //       const resData = res.data;
  //       this.setState({
  //         fee_detail: resData,
  //         display_fee_detail: resData,
  //         errorMessages: resData.message
  //       });
  //       //console.log(this.state.fee_category);
  //     }).catch((error) => {
  //       // error
  //     })

  // };

  // getFeeCategoryHandler() {
  //   loadProgressBar();
  //   axios.get(FEE_CATEGORY)
  //     .then(res => {
  //       const fee_category = res.data;
  //       this.setState({
  //         fee_category: fee_category,
  //         errorMessages: fee_category.message
  //       });
  //       //console.log(this.state.fee_category);
  //     }).catch((error) => {
  //       // error
  //     })
  // }


  getKeys = () => {
    return Object.keys(this.state.display_fee_detail[0]);
  }

  getHeader = () => {
    var keys = this.getKeys();
    keys.unshift('#');
    keys.push('Action');
    return keys.map((key) => {
      if (key.toUpperCase() === "SCHOOL_ID" || key.toUpperCase() === "CLASS_ID") {
        return false;
      } else {
        return <th key={key}>{key.toUpperCase()}</th>
      }
    })

  }

  getRowsData = () => {
    var items = this.state.display_fee_detail;
    var keys = this.getKeys();
    //    debugger
    return items.map((row, index) => {
      return (
        <tr key={index}>
          <td>{index + 1}</td>
          <RenderRow key={index} data={row} keys={keys} />
          <td className="d-flex">
            {/* <NavLink to={`edit_fee_details.jsp/${row.class_id}-${row.medium}`}
              className="btn btn-primary btn-sm mr-1">
              Edit
            </NavLink> */}
            <button className="btn btn-primary btn-sm mr-1"
              type="button"
              onClick={event => this.openEdit(event, row.class_id)}>Edit</button>

            <button className="btn btn-danger btn-sm"
              onClick={event => this.confirmBoxDelete(event, row.class_id, row.medium)}>
              Del
            </button>
          </td>
        </tr>
      )
    })
  }


  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteFeeStructure({id : id});
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  // deleteHandlar = (event, id, medium) => {
  //   event.preventDefault();
  //   const obj = {
  //     class_id: id,
  //     medium: medium
  //   }
  //   axios.post(DELETE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _display_fee_detail = this.state.display_fee_detail.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         display_fee_detail: _display_fee_detail
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  
  componentWillReceiveProps(nextProps) {
    if (nextProps.feeStructure) {
      setTimeout(() => {
        this.filterBySchoolHandler()
      }, 100);
    }
  }

  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateFeeStructure(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, cls_id) => {
    event.preventDefault();
    const _selected_item = this.props.feeStructure.filter((item) => {
      if (item.class_id === cls_id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  render() {
    const { createItem, editItem, selected_item, display_fee_detail, formIsHalfFilledOut } = this.state;
    const { user, schools, feeStructure, feeCategory } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Fee Structure</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">

            <div className="page-bar d-flex">
              {/* <div className="page-title">All Fee Structure</div> */}
              {user && schools && feeStructure && feeCategory &&
                <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                    <button type="button" className="btn btn-danger filter-toggler-c">
                      <i className="fa fa-times"></i>
                    </button>
                  </span>
                  <div className="filter-con">
                    {/* <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Medium :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='medium'
                        disabled={medium_arr.length > 1 ? false : true}
                        value={medium}
                        onChange={event => this.changeHandler(event, 'medium')}>
                        <option value="">Select ...</option>
                        {medium_arr.map((item, index) => {
                          return (
                            <option key={index} value={item}>{item}</option>
                          )
                        })}
                      </select>
                    </div> */}
                    <CommonFilters
                      showSchoolFilter={true}
                      showMediumFilter={false}
                      // showClassFilter={false}
                      filterBySchoolHandler={this.filterBySchoolHandler}
                      // filterByClsHandler={this.filterByClsHandler}
                    />

                  </div>
                </div>
              }
            </div>

            {createItem ? <AddFeeDetails
              resetFeeStructure={this.filterFeeStructureOnSchool}
              toggeleCreate={this.toggeleCreate} />
              : null}

            {editItem ?
              <>
                <EditFeeDetails
                  selected_item={selected_item}
                  schools={schools}
                  user={user}
                  feeCategory={feeCategory}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                <div className="backdrop edit-mode"></div>
              </>
              : null}

            <div className="table-scrollable">
              {display_fee_detail.length > 0 ?
                <table className="table table-striped table-bordered table-hover table-sm">
                  <thead>
                    <tr>
                      {this.getHeader()}
                    </tr>
                  </thead>
                  <tbody>
                    {this.getRowsData()}
                  </tbody>
                </table>
                : null}
            </div>

          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">
                Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">
                Add New
            </button>
            }
          </div>
        </div>
      </div>
    )
  }
}

const RenderRow = (props) => {
  const _newData = props.keys.map((key, index) => {
    //return <td key={props.data[key]}>{props.data[key]}</td>
    if (key.toUpperCase() === "SCHOOL_ID" || key.toUpperCase() === "CLASS_ID") {
      return false
    } else {
      return <td key={index}>{props.data[key]}</td>
    }
  })
  return _newData;
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: feeStructure } = state.feeStructure;
  const { item: schools } = state.schools;
  const { item: feeCategory } = state.feeCategory;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, feeStructure, feeCategory,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getFeeStructure: feeStructureAction.getFeeStructure,
  deleteFeeStructure: feeStructureAction.delete,
  updateFeeStructure: feeStructureAction.update,
  getSchools: schoolsAction.getSchools,
  getFeeCategory: feeCategoryAction.getFeeCategory,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllFeeStructure));