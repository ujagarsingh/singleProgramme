import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { Picky } from 'react-picky';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { classesAction, professionalAction, conveyanceAction, } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;  
const READ_CONVENCE = `http://schools.rajpsp.com/api/conveyance/read.php`;   
const GET_CLASS_FEE = `http://schools.rajpsp.com/api/fee_amount/read_class_fee.php`;

class NewGetEstimate extends Component {
   state = {
      medium: '',
      depo_fee_students: [],
      all_classes: [],
      classes: [],
      conveyances: [],
      conveyance_id: '', // selected Convence Id
      conveyance_area: '', // selected Convence Area
      selected_class_id: '',
      students: [],
      selected_student_id: '',
      selected_student: '',
      selected_student_info: '',
      fee_date: '',
      pre_fee_deposit_arr: {},
      class_fee_arr: [],
      class_fee_Has: false,
      deposit_fee_arr: [],
      final_deposit_fee_arr: [],
      varified_deposit_fee_arr: [],
      monthly_fee_amo: 0, // from database
      convence_fee_amo: 0, // from database 
      exam_fee_amo: 0, // from database
      reg_fee_amo: 0, // from database
      sports_fee_amo: 0, // from database
      total_amount: 0,
      total_discount: 0,
      ground_total: 0,
      total_monthly_amount: 0,
      total_convence_amount: 0,
      total_monthly_discount: 0,
      total_convence_discount: 0,
      monthly_discount: 0, // in percentage
      convence_discount: 0, // in percengage
      fee_amount: 0,
      current_depo_amount: 0,
      balance_amount: 0,
      current_date: '2019-10-20',
      fee_date: new Date(),
      monthly_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'], // all months of getting fee 
      monthly_selected_deposit_months: [], // current months of fee deposit
      monthly_difference_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'], // not paymented months
      set_monthly_fee_amo: 0,
      // this will be updated by database
      convence_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
      convence_selected_deposit_months: [],
      convence_diffrence_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
      set_convence_fee_amo: 0,
      set_exam_fee_amo: 0,
      set_reg_fee_amo: 0,
      set_sports_fee_amo: 0,
      reg_fee: false,
      sports_fee: false,
      exam_fee: false,
      seat_type: '',
      description: '',
      visitor_name: '',
      visitor_address: '',
      visitor_mobile: '',
      enquiry_class: '',
      monthly: '',
      convence: '',
      monthly_discount: 0, // in percentage
      convence_discount: 0, // in percengage
      formIsHalfFilledOut: false,

   }
   changeHandler = (event, fieldName, isCheckbox) => {
      const _temp_arr = ['oneTime'];
      const _tempTarget = event.target.checked;
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      });
      if (fieldName === 'medium') {
         const _medium = event.target.value;
         const _classes = this.state.all_classes.filter((item, inx) => {
            if (item.medium === _medium) {
               return item
            }
         })
         this.setState({
            classes: _classes
         })
      }
   };

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
       }
       if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
       }
       if (isEmptyObj(this.props.professional)) {
         this.props.getProfessional();
       }
   }

   checkAuthentication(obj) {
      loadProgressBar();
      axios.post(VALIDATE_URL, obj)
         .then(res => {
            const getRes = res.data;
            // sessionStorage.setItem("user", getRes.data);
            console.log(getRes);
            if (getRes.data) {
               this.setState({
                  user: getRes.data,
                  group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
                  school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
                  user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
                  session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
               }, () => {
                  this.getClassesHandler();
                  this.getConvencesHandler();
               })
            }
         }).catch((error) => {
            this.props.history.push('/login.jsp');
         })
   }

   getClassesHandler() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id,
      }
      axios.obj(GET_CLASSES, obj)
         .then(res => {
            const getRes = res.data;
            this.setState({
               classes: getRes,
               all_classes: getRes,
               errorMessages: getRes.message
            });
            ////console.log(this.state.classes);
         }).catch((error) => {
            // error
         })

   };
   getConvencesHandler() {
      axios.get(READ_CONVENCE)
         .then(res => {
            const conveyances = res.data;
            this.setState({
               conveyances: conveyances,
               errorMessages: res.data.message
            });
            //console.log(this.state.conveyance);
         }).catch((error) => {
            // error
         })
   }
   getSectedClassHandler = (event) => {
      loadProgressBar();
      this.setState({
         selected_class_id: JSON.parse(event.target.value).id,
         student_class: JSON.parse(event.target.value).class_name
      }, () => {
         axios.get(GET_CLASS_FEE + '?class_id=' + this.state.selected_class_id)
            .then(res => {
               if (Array.isArray(res.data)) {
                  this.setState({
                     class_fee_arr: res.data,
                     class_fee_Has: true
                  }, () => {
                     this.classFeeUpdate();
                  });
                  //  //console.log(this.state);
               } else {
                  Alert.warning('This Class Fee Structure Not Added Please Update it first using [ Setting > Pamnent ]', {
                     position: 'bottom-right',
                     effect: 'jelly',
                     timeout: 5000, offset: 40
                  });
                  this.setState({
                     class_fee_Has: false
                  })
               }
               //console.log(this.state);
            }).catch((error) => {
               // error
            })
      });
   }
   getSectedConvenceHandler = (event) => {
      loadProgressBar();
      this.setState({
         conveyance_id: JSON.parse(event.target.value).id,
         conveyance_area: JSON.parse(event.target.value).stoppage_name,
         convence_fee_amo: JSON.parse(event.target.value).stoppage_amo
      })
   }
   getFeeTime = (elem) => {
      let fee_time = [];
      if (elem.collect_time_jul = 'yes') { fee_time.push('July') }
      if (elem.collect_time_aug = 'yes') { fee_time.push('August') }
      if (elem.collect_time_sep = 'yes') { fee_time.push('September') }
      if (elem.collect_time_oct = 'yes') { fee_time.push('October') }
      if (elem.collect_time_nov = 'yes') { fee_time.push('November') }
      if (elem.collect_time_dec = 'yes') { fee_time.push('December') }
      if (elem.collect_time_jan = 'yes') { fee_time.push('January') }
      if (elem.collect_time_feb = 'yes') { fee_time.push('Fabruary') }
      if (elem.collect_time_mar = 'yes') { fee_time.push('March') }
      if (elem.collect_time_apr = 'yes') { fee_time.push('April') }
      if (elem.collect_time_may = 'yes') { fee_time.push('May') }
      if (elem.collect_time_jun = 'yes') { fee_time.push('June') }
      return fee_time;
   }
   classFeeUpdate = () => {
      //const new_class_fee = this.state.class_fee_arr;
      this.state.class_fee_arr.map((class_fee) => {
         if (class_fee.cat_name === 'Monthly') {
            const fee_time = this.getFeeTime(class_fee);//Object.values(class_fee);
            this.setState({ monthly_fee_amo: parseInt(class_fee.fee_amount), monthly_will_deposit_months: fee_time })
         } else if (class_fee.cat_name === 'Convence') {
            const fee_time = this.getFeeTime(class_fee);
            this.setState({ convence_fee_amo: parseInt(class_fee.fee_amount), convence_will_deposit_months: fee_time })
         } else if (class_fee.cat_name === 'Exam') {
            this.setState({ exam_fee_amo: parseInt(class_fee.fee_amount) })
         } else if (class_fee.cat_name === 'Registration') {
            this.setState({ reg_fee_amo: parseInt(class_fee.fee_amount) })
         } else if (class_fee.cat_name === 'Sports') {
            this.setState({ sports_fee_amo: parseInt(class_fee.fee_amount) })
         }
      })
      //console.log(this.state);
   }
   render() {
      const { medium, classes, fee_date, visitor_name, visitor_mobile, visitor_address, conveyances,
         description, total_amount, total_discount, ground_total, exicutive_note } = this.state;
      console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Get Estimate</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div className="page-bar d-flex">
               <div className="page-title">Fee Estimate</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <div className="form-group mt-1">
                        <label className="control-label mr-2">Collection Date</label>
                        <div className="input-group">
                           <DatePicker
                              disabled={true}
                              onChange={this.feeDepositDate}
                              value={fee_date}
                              showLeadingZeroes={true}
                              minDate={new Date()}
                           />
                        </div>
                     </div>
                  </div>
               </div></div>
            <form className="card card-box sfpage-cover" onSubmit={this.submitHandler}>
               <div className="card-body" >
                  <div className="table-scrollable">
                     <div className="col">
                        <div className="form-body form-horizontal">
                           <div className="row">
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label text-left mb-2 col-12">Visitor Name
                              <span className="required"> * </span>
                                    </label>
                                    <div className="col-md-12">
                                       <input type="text" placeholder="Name"
                                          className="form-control form-control-sm"
                                          required
                                          value={visitor_name}
                                          onChange={event => this.changeHandler(event, 'visitor_name')} />
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label text-left mb-2 col-12">Visitor Mobile
                              <span className="required"> * </span>
                                    </label>
                                    <div className="col-md-12">
                                       <input type="number" placeholder="Mobile"
                                          className="form-control form-control-sm"
                                          required
                                          value={visitor_mobile}
                                          onChange={event => this.changeHandler(event, 'visitor_mobile')} />
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label text-left mb-2 col-12">Visitor Address
                              <span className="required"> * </span>
                                    </label>
                                    <div className="col-md-12">
                                       <input type="text" placeholder="Address"
                                          className="form-control form-control-sm"
                                          required
                                          value={visitor_address}
                                          onChange={event => this.changeHandler(event, 'visitor_address')} />
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div className="row">
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Medium :</label>
                                    <div className="col-md-7">
                                       <select className="form-control form-control-sm"
                                          onChange={event => this.changeHandler(event, 'medium')}>
                                          <option >Select ...</option>
                                          <option value="English">English</option>
                                          <option value="Hindi" >Hindi</option>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Class<span className="required"> * </span>
                                    </label>
                                    <div className="col-md-7">
                                       <select className="form-control form-control-sm"
                                          disabled={medium === '' ? true : false}
                                          onChange={this.getSectedClassHandler}>
                                          <option value>Select...</option>
                                          {classes.map((option, index) => {
                                             return (
                                                <option key={index} value={JSON.stringify(option)}>{option.class_name}</option>
                                             )
                                          })}
                                       </select>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-4">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Convence Area
                                    </label>
                                    <div className="col-md-7">
                                       <select className="form-control form-control-sm"
                                          disabled={medium === '' ? true : false}
                                          onChange={this.getSectedConvenceHandler}>
                                          <option value>Select...</option>
                                          {conveyances.map((option, index) => {
                                             return (
                                                <option key={index} value={JSON.stringify(option)}>
                                                   {option.stoppage_name}-[{option.stoppage_amo}]
                                                </option>
                                             )
                                          })}
                                       </select>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Monthly
                                    </label>
                                    <div className="col-md-7">
                                       <input type="text" placeholder="Monthly"
                                          className="form-control form-control-sm"
                                          disabled={true}
                                          value={monthly}
                                          onChange={event => this.changeHandler(event, 'monthly')} />
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Monthly Discount
                                    </label>
                                    <div className="col-md-7">
                                       <input type="text" placeholder="Monthly Discount"
                                          className="form-control form-control-sm"
                                          disabled={medium === '' ? true : false}
                                          value={monthly_discount}
                                          onChange={event => this.changeHandler(event, 'monthly_discount')} />
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Convence
                                    </label>
                                    <div className="col-md-7">
                                       <input type="text" placeholder="Convence"
                                          className="form-control form-control-sm"
                                          disabled={true}
                                          value={convence}
                                          onChange={event => this.changeHandler(event, 'convence')} />
                                    </div>
                                 </div>
                              </div>
                              <div className="col-md-3">
                                 <div className="form-group row">
                                    <label className="control-label col-md-5">Convence Discount
                                    </label>
                                    <div className="col-md-7">
                                       <input type="text" placeholder="Convence"
                                          className="form-control form-control-sm"
                                          disabled={medium === '' ? true : false}
                                          value={convence_discount}
                                          onChange={event => this.changeHandler(event, 'convence_discount')} />
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div className="card card-primary bg-light">
                              <div className="card-header">Payment Summary</div>
                              <div className="card-body">
                                 <div className="row">
                                    <div className="col-md-6">
                                       <div className="form-group mb-2">
                                          <textarea
                                             value={description}
                                             onChange={event => this.changeHandler(event, 'description')}
                                             placeholder="payment details" className="form-control form-control-sm-textarea form-control-sm"
                                             rows={5} />
                                       </div>
                                       <div className="form-group mb-0">
                                          <label className="control-label text-left pb-1">Exicutive Note</label>
                                          <textarea
                                             value={exicutive_note}
                                             onChange={event => this.changeHandler(event, 'exicutive_note')}
                                             placeholder="exicutie note" className="form-control form-control-sm-textarea form-control-sm"
                                             rows={5} />
                                       </div>
                                    </div>
                                    <div className="col-md-6">
                                       <div className="form-group row">
                                          <label className="control-label col-md-5">Total Fee
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={total_amount}
                                                type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                                       </div>
                                       <div className="form-group row">
                                          <label className="control-label col-md-5">Total Discount
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={total_discount}
                                                type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                                       </div>
                                       <div className="form-group row">
                                          <label className="control-label col-md-5">Ground Total
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={ground_total}
                                                type="text" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                                       </div>

                                    </div>
                                 </div>
                              </div>
                           </div>

                        </div>
                     </div>
                  </div>
               </div>
               <div className="card-footer d-flex">
                  <button type="submit" className="btn btn-primary mr-2 ml-auto">Submit</button>
                  <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
               </div>
            </form>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: classes } = state.classes;
   const { item: professional } = state.professional;
   return { user, classes, professional };
 }
 
 const actionCreators = {
   getClasses: classesAction.getClasses,
   getProfessional: professionalAction.getProfessional,
 }
 
 export default connect(mapStateToProps, actionCreators)(withRouter(NewGetEstimate));