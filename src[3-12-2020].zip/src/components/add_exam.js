import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { Picky } from 'react-picky';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, examsTypeAction, examsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const CREATE_EXAM = `http://schools.rajpsp.com/api/exam/create.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`; 
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
// const READ_EXAM_CAT = `http://schools.rajpsp.com/api/exam_type/read.php`;  

class AddExam extends Component {
   state = {
      exam_category_arr: [],
      selected_exam_cat_id: '',
      selected_exam_cat_inx: '',
      schools: [],
      school_id: '',
      selected_school_index: '',
      medium_arr: [],
      medium: '',
      sft_classes: [],
      selected_classes: [],
      selected_classes_arr: [],
      used_classes_arr: [],
      used_classes_ids: [],
      class_id: '',
      exam_name: '',
      exam_priority: '',
      exam_start: new Date(),
      exam_end: new Date(),
      formIsHalfFilledOut: false,
   }

   changeHandler = (event, fieldName, isCheckbox) => {
      if (fieldName === 'school') {
         const _inx = event.target.value;
         const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
         const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
         sessionStorage.setItem("school_id", _sch_id);
         this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
         this.setState({
            school_id: _sch_id,
            medium_arr: _medium,
            medium: (_medium.length === 1 ? _medium[0] : ''),
            selected_school_index: _inx,
            selected_class_inx: ''
         })
      } else if (fieldName === 'exam_category') {
         const _id = event.target.value;
         this.setState({
            selected_exam_cat_id: _id,
         })
      }
      else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            formIsHalfFilledOut: true
         })
      }
   };
   filterClassesOnSchool(sch_id, group_id) {
      let _class_arr = [];
      const _classes = this.props.classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            _class_arr.push(item.class_name);
            return item
         }
      })

      this.setState({
         selected_classes: _classes,
         selected_classes_arr: _class_arr
      })
   }
   examStartDate = (feeDate) => {
      this.setState({ exam_start: feeDate, exam_end: feeDate });
      this.to.openCalendar();
   };
   examEndDate = (feeDate) => {
      this.setState({ exam_end: feeDate });
   };
   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.examsType)) {
         this.props.getExamsType();
      }
   }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //                this.getExamTypeHandler();
   //                this.getClassesHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          ////console.log(this.state.classes);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // getClassesHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //    }
   //    // console.log(JSON.stringify(obj));
   //    axios.post(READ_CLASS_URL, obj)
   //       .then(res => {
   //          const classes = res.data;
   //          this.setState({
   //             sft_classes: classes,
   //             errorMessages: res.data.message
   //          });
   //          //console.log(this.state.classes);
   //       })
   //       .catch((error) => {
   //          // error
   //       });
   // };
   // getExamTypeHandler() {
   //    loadProgressBar();
   //    // console.log(JSON.stringify(obj));
   //    axios.get(READ_EXAM_CAT)
   //       .then(res => {
   //          const resData = res.data;
   //          this.setState({
   //             exam_category_arr: resData,
   //             errorMessages: resData.message
   //          });
   //          //console.log(this.state.classes);
   //       })
   //       .catch((error) => {
   //          // error
   //       });
   // };

   getSectedClassHandler = (event) => {
      const _class_id = event.target.value;
      this.setState({ class_id: _class_id });
      //this.subjectsClasswise(_class_id);
   }
   selectClassHandler = (value) => {
      console.count('onChange');
      let _class_ids = [];
      this.state.selected_classes.forEach((item, index) => {
         if (value.includes(item.class_name)) {
            _class_ids.push(item.id);
         }
      })
      this.setState({
         used_classes_arr: value, //july, august
         used_classes_ids: _class_ids
      });
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Submit this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler() {
      //e.preventDefault();
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         exam_name: this.state.exam_name,
         medium: this.state.medium,
         // class_id: this.state.class_id,
         used_classes_ids: this.state.used_classes_ids,
         exam_cat_id: this.state.selected_exam_cat_id,
         exam_priority: this.state.exam_priority,
         exam_start: this.state.exam_start,
         exam_end: this.state.exam_end
      }
      // console.log(JSON.stringify(obj));
      this.props.create(obj);
      // axios.post(CREATE_EXAM, obj)
      //    .then(res => {
      //       const getRes = res.data;
      //       //console.log(getRes)
      //       Alert.success(getRes.message, {
      //          position: 'bottom-right',
      //          effect: 'jelly',
      //          timeout: 5000, offset: 40
      //       });
      //       // this.setState({
      //       //    group_id: '',
      //       //    school_id: '',
      //       //    exam_name: '',
      //       //    medium: '',
      //       //    used_classes_ids: [],
      //       //    selected_exam_cat_id: '',
      //       //    exam_priority: '',
      //       //    exam_start: new Date(),
      //       //    exam_end: new Date()
      //       // });
      //    }).catch((error) => {
      //       //this.setState({ errorMessages: error });
      //    })

   };
   render() {
      const { selected_school_index, medium_arr, medium, exam_start, exam_end, selected_classes_arr,
         used_classes_arr, selected_exam_cat_id, formIsHalfFilledOut } = this.state;
      const { user, schools, classes, examsType } = this.props;
      // console.log(this.state);
      return (
         <div className="page-child">
            <Helmet>
               <title>Add New Exam</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  Add Exam
               </div>
               <div className="card-body">
                  {user && schools && classes && examsType &&
                     <div className="row">
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Schools :</label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    value={selected_school_index}
                                    onChange={event => this.changeHandler(event, 'school')}>
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Medium :</label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='medium'
                                    disabled={medium_arr.length > 1 ? false : true}
                                    value={medium}
                                    onChange={event => this.changeHandler(event, 'medium')}>
                                    <option value="">Select ...</option>
                                    {medium_arr.map((item, index) => {
                                       return (
                                          <option key={index} value={item}>{item}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Exam Start
                                       </label>
                              <div className="form-input">
                                 <DatePicker
                                    onChange={this.examStartDate}
                                    value={exam_start}
                                    showLeadingZeroes={true}
                                 //minDate={new Date()}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">To End
                                       </label>
                              <div className="form-input">
                                 <DatePicker
                                    ref={el => (this.to = el)}
                                    onChange={this.examEndDate}
                                    value={exam_end}
                                    showLeadingZeroes={true}
                                    minDate={exam_start}
                                 //minDate={new Date()}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Exam Name
                          <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input name="exam_name"
                                    required
                                    type="text" placeholder="Test Name"
                                    className="form-control form-control-sm"
                                    onChange={event => this.changeHandler(event, 'exam_name')}
                                 />
                                 <small id="emailHelp" className="form-text text-muted">
                                    Like 'First Test', Second Test, Half Yearly etc.</small>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Exam Type
                                 <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm" name="select"
                                    value={selected_exam_cat_id}
                                    onChange={event => this.changeHandler(event, 'exam_category')}>
                                    <option value="">Select...</option>
                                    {examsType.map((option, index) => {
                                       return (
                                          <option key={index}
                                             value={option.id}>
                                             {option.cat_name}
                                          </option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Class
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 {/* <select className="form-control form-control-sm" name="select"
                                       value={class_id}
                                       onChange={event => this.getSectedClassHandler(event)}>
                                       <option value="">Select...</option>
                                       {selected_classes.map((option, index) => {
                                          return (
                                             <option key={index}
                                                value={option.id}>
                                                {option.class_name} [{option.class_name_portal}]
                              </option>
                                          )
                                       })}
                                    </select> */}
                                 <Picky
                                    className="input-sm"
                                    value={used_classes_arr}
                                    options={selected_classes_arr}
                                    onChange={this.selectClassHandler}
                                    open={false}
                                    valueKey="id"
                                    labelKey="name"
                                    multiple={true}
                                    includeSelectAll={true}
                                    //includeFilter={true}
                                    dropdownHeight={200}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-3">
                           <div className="form-group">
                              <label className="control-label">Priority
                          <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <select name="exam_priority"
                                    required
                                    className="form-control form-control-sm"
                                    onChange={event => this.changeHandler(event, 'exam_priority')}
                                 >
                                    <option>Select ...</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                 </select>
                                 <small id="emailHelp" className="form-text text-muted">
                                    Set Priority of any Exam this is reflect in Marksheet Column.</small>
                              </div>
                           </div>
                        </div>
                     </div>
                  }
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-secondary mr-2">Submit</button>
                  <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
                     Cancel
                  </button>
               </div>
            </form>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: examsType } = state.examsType;
   return { user, schools, classes, examsType };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getExamsType: examsTypeAction.getExamsType,
   create: examsAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddExam));