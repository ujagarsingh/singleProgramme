import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import SingleShedule from './single_shedule';
import { connect } from 'react-redux';
import { schoolsAction, examsCategoryAction} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`; 
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;  

class SheduleInnings extends Component {
   state = {
      innings_sub: [
         { inning_name: "FIRST INNING", subject: "" }
      ],
      showInningsData: false,
      showSheduleData: false,
      shedule_obj: {
         school_info: {},
         shedule_note: [],
         identity_card_note: [],
         innings: [
            { inning_name: "FIRST INNING", inning_time: "8:30 AM to 11:00 AM" },
            { inning_name: "SECOND INNING", inning_time: "2:30 PM to 5:00 PM" }
         ],
         classes: [],
         updated_subjects: [],
      },
      shedule_note_item: "",
      shedule_note_inx: "",
      subjects: [],
      shedule_date: "",
      schools_arr: [],
      school_name: '',
      medium: '',
      medium_arr: [],
      exams: [],
      selected_exams: [],
      current_inning_inx: '',
      inn_name: '',
      inn_time: '',
      exam_name: '',
      current_exam_inx: '',
      exam_id: '',
      formIsHalfFilledOut: false,
   }
   isEmpty(val) {
      return (val === undefined || val == null || val.length <= 0) ? true : false;
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      if (fieldName === 'school') {
         const _inx = event.target.value;
         const _shedule_obj = this.state.shedule_obj;
         const _school_info = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx] : '';
         const _sch_id = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].id : '';
         const _sch_name = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_name : '';
         const _medium = (!this.isEmpty(_inx)) ? this.state.schools_arr[_inx].sch_medium : [];
         sessionStorage.setItem("school_id", _sch_id);
         this.filterExamsCategoriesHandler(_sch_id);

         _shedule_obj['school_info'] = _school_info;
         _shedule_obj['updated_subjects'] = [];
         _shedule_obj['classes'] = [];

         this.setState({
            school_id: _sch_id,
            school_name: _sch_name,
            medium_arr: _medium,
            medium: (_medium.length === 1 ? _medium[0] : ''),
            selected_school_index: _inx,
            exam_name: '',
            current_exam_inx: '',
            exam_id: '',
            shedule_obj: _shedule_obj,
         })
      } else if (fieldName === 'current_exam') {
         const _examIdx = event.target.value;
         if (_examIdx !== '') {
            const _exam_id = this.state.selected_exams[_examIdx].id;
            const _exam_name = this.state.selected_exams[_examIdx].cat_name;
            this.setState({
               exam_name: _exam_name,
               current_exam_inx: _examIdx,
               exam_id: _exam_id
            }, () => { this.getClassWiseSubject() })

         } else {
            this.setState({
               exam_name: '',
               current_exam_inx: '',
               exam_id: ''
            })
         }
      } else if (fieldName === 'innings') {
         const _examIdx = event.target.value;
         this.setState({
            current_inning_inx: _examIdx
         })
      } else if (fieldName === 'shedule_note') {
         const _sheduleNote = event.target.value;
         this.setState({
            shedule_note_item: _sheduleNote
         })
      } else if (fieldName === 'show_inning') {
         this.setState({
            showInningsData: !this.state.showInningsData
         })
      } else if (fieldName === 'show_shedule') {
         this.setState({
            showSheduleData: !this.state.showSheduleData
         })
      } else if (fieldName === 'select_subject') {
         const _subjectIdx = event.target.value;
         const _class_inx = event.target.getAttribute('class_data');
         const _inning_inx = event.target.closest(".data_row").getAttribute('data_row');
         const _date_inx = event.target.closest(".data_date_row").getAttribute('data_date_row');
         this.dataUpdatedSubjectsHndlar(_date_inx, _inning_inx, _class_inx, _subjectIdx);

      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
            formIsHalfFilledOut: true
         });
      }
   }
   dataUpdatedSubjectsHndlar(date_inx, inning_inx, class_inx, inning_sub) {
      const _shedule_obj = this.state.shedule_obj;
      const _updated_subject = _shedule_obj.updated_subjects;
      const final_innings = _updated_subject.map((date_item, d_inx) => {
         // console.log(_updated_subject);
         if (parseInt(date_inx) === d_inx) {
            const new_date_item = date_item.innings.map((inn_item, i_idx) => {
               // console.log(inn_item);
               if (parseInt(inning_inx) === i_idx) {
                  const new_inn_item = inn_item.class_subject.map((class_item, c_idx) => {
                     // console.log(class_item);
                     if (parseInt(class_inx) === c_idx) {
                        class_item['selected_sub'] = inning_sub;
                        class_item['selected_sub_inx'] = c_idx;
                        return class_item;
                     } else {
                        return class_item;
                     }
                  })
                  return { ...inn_item, class_subject: new_inn_item };
               } else {
                  return inn_item;
               }
            })
            return { ...date_item, innings: new_date_item };
         } else {
            return date_item;
         }
      })
      // console.log(final_innings);
      _shedule_obj.updated_subjects = final_innings;
      this.setState({
         updated_subjects: _shedule_obj
      })
   }
   filterExamsCategoriesHandler(school_id) {
      let _school_id = school_id;
      const _exams_cate = this.state.exams.filter((item) => {
         if (_school_id === item.school_id) {
            return item;
         }
      })
      this.setState({
         selected_exams: _exams_cate
      })
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
       }
       if (isEmptyObj(this.props.examsCategory)) {
          this.props.getExamsCategory();
       }
   }

   checkAuthentication(obj) {
      loadProgressBar();
      axios.post(VALIDATE_URL, obj)
         .then(res => {
            const getRes = res.data;
            // sessionStorage.setItem("user", getRes.data);
            console.log(getRes);
            if (getRes.data) {
               this.setState({
                  user: getRes.data,
                  group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
                  school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
                  user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
                  session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
               }, () => {
                  this.getSchoolHandler();
                  this.getExamsCategories();
               })
            }
         }).catch((error) => {
            this.props.history.push('/login.jsp');
         })
   }

   getClassWiseSubject() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id,
         exam_name: this.state.exam_name,
      }
      console.log(JSON.stringify(obj));
      axios.post(READ_SUBJECTS, obj)
         .then(res => {
            const getRes = res.data;
            this.setState({
               subjects: getRes,
               // updated_subjects: [...this.state.updated_subjects, getRes],
               errorMessages: getRes.message
            }, () => {
               this.getClassObj();
               this.addNewRow();
            })
            // console.log(this.state);
         }).catch((error) => {
            // error
         })
   }

   getExamsCategories() {
      loadProgressBar();
      axios.get(READ_EXAM_CATE)
         .then(res => {
            const getRes = res.data;
            this.setState({
               exams: getRes,
               errorMessages: getRes.message
            })
            // console.log(this.state);
         }).catch((error) => {
            // error
         })
   }
   getSchoolHandler() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id
      }
      axios.post(READ_SCHOOLS, obj)
         .then(res => {
            const getRes = res.data;
            this.setState({
               schools_arr: getRes,
               errorMessages: getRes.message
            });
            // console.log(this.state);
         }).catch((error) => {
            // error
         })
   }
   addItemToState = (e) => {
      e.preventDefault();
      this.props.addTodo({
         text: this.refs.addtodo.value
      })
      this.refs.addtodo.value = ''
   };

   getClassObj() {
      const _exam_subject = this.state.subjects;
      const _shedule_obj = this.state.shedule_obj;
      let _new_class_arr = [];
      // debugger;
      _exam_subject.innings[0].class_subject.forEach((item) => {
         _new_class_arr = [..._new_class_arr, { 'id': item.id, 'class_name': item.class_name }]
      })
      // console.log(_new_class_arr);
      _shedule_obj['classes'] = _new_class_arr;

      this.setState({
         shedule_obj: _shedule_obj
      })
   }
   addInnings(ev) {
      // debugger
      ev.preventDefault();
      const _exam_subject = this.state.subjects;
      const _update = [...this.state.updated_subjects, _exam_subject];

      this.setState({
         updated_subjects: _update
      })
   }
   addNewRow() {
      // ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const _innings = _shedule_obj.innings;
      const _exam_subject = this.state.subjects;
      let count_innings = []
      for (let x = 0; x < _innings.length; x++) {
         const new_exam_subject = JSON.parse(JSON.stringify(_exam_subject.innings[0]));
         new_exam_subject['inning'] = _innings[x].inning_name;
         new_exam_subject['inning_time'] = _innings[x].inning_time;
         count_innings.push(new_exam_subject);
      }
      const n_exam_subject = {
         exam_date: "",
         holiday: false,
         reason: "",
         innings: count_innings
      }
      _shedule_obj.updated_subjects = [..._shedule_obj.updated_subjects, n_exam_subject]

      this.setState({
         shedule_obj: _shedule_obj
         //updated_subjects: _update
      })
   }
   removeRow(ev, inx) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.filter((item, index) => {
         if (index != inx) {
            return item
         }
      })
      _shedule_obj.updated_subjects = _update_subjects;
      this.setState({
         updated_subjects: _shedule_obj
      })
   }

   dayTypeHandler(ev, inx) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === inx) {
            return item = {
               ...item,
               holiday: !item.holiday
            }
         } else {
            return item;
         }
      })
      _shedule_obj.updated_subjects = _update_subjects
      this.setState({
         updated_subjects: _shedule_obj
      })
   }

   formatAMPM(date) {
      // const hours = date.getHours();
      // const minutes = date.getMinutes();
      let hours = parseInt(date.split(":")[0]);
      let minutes = parseInt(date.split(":")[1]);
      let ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0' + minutes : minutes;
      let strTime = hours + ':' + minutes + ' ' + ampm;
      return strTime;
   }
   addInningHandler(ev) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const inn_name = this.state.inn_name;
      const inn_time = this.state.inn_time;
      const inn_subject = "";
      const newInning = { inning_name: inn_name, inning_time: inn_time, inn_subject: inn_subject }
      _shedule_obj.innings.push(newInning);
      this.setState({
         //innings: [...this.state.innings, newInning],
         inn_name: "",
         inn_time: "",
         shedule_obj: { ...this.state.shedule_obj, updated_subjects: [] },
      }, () => {
         // this.updatedSubjectsHndlar();
         this.addNewRow();
      })
   }
   removeEnning(ev) {
      ev.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  const inx = parseInt(this.state.current_inning_inx);
                  const _shedule_obj = this.state.shedule_obj;
                  const updateInnings = _shedule_obj.innings.filter((item, idx) => {
                     if (idx != inx) {
                        return item
                     }
                  })
                  _shedule_obj.innings = updateInnings;
                  _shedule_obj.updated_subjects = [];

                  this.setState({
                     current_inning_inx: '',
                     shedule_obj: _shedule_obj
                  }, () => {
                     this.addNewRow();
                  })
               }
            },
            {
               label: 'No',
            }
         ]
      });

   }
   // updatedSubjectsHndlar() {
   //    // debugger
   //    const new_obj = this.state.innings;
   //    const sub_obj = this.state.updated_subjects;

   //    const final_subject = sub_obj.map((item) => {
   //       item = { ...item, innings: this.checkUpdatedInnings(new_obj, item.innings) }
   //       return item;
   //    });
   //    this.setState({
   //       updated_subjects: final_subject
   //    })
   // }
   // checkUpdatedInnings(new_obj, old_obj) {
   //    const final_obj = new_obj.map((item) => {
   //       let subject = '';
   //       old_obj.forEach((item_o) => {
   //          if (item.inning_name == item_o.inning_name) {
   //             subject = item_o.inn_subject;
   //          }
   //       })
   //       return item = { ...item, inn_subject: subject };
   //    })
   //    return final_obj;
   // }
   getSubjectSlectionGroup(inn_item) {
      const _inn_item = inn_item;
      const all_subject = this.state.subjects;
      // debugger
      const final_subject = all_subject.innings.map((item, index) => {
         return (
            <table key={index}>
               <tbody>
                  <tr>
                     {item.class_subject.map((item_e, idex) => {
                        return (this.getSubjectSlection(item_e, idex))
                     })}
                  </tr>
               </tbody>
            </table>
         )
      })
      return final_subject;
   }
   getSubjectSlection(_obj, inx) {
      const _innings = this.state.innings;
      const subjects = _obj.subject_arr;
      // debugger
      return (
         <td key={inx} className="p-0">
            <select class_data={inx} className="form-control form-control-sm"
               // value={selected_sub_inx}
               onChange={event => this.changeHandler(event, 'select_subject')}>
               <option value="">...</option>
               {subjects.map((item, index) => {
                  // console.log(item);
                  return (
                     (item.child && item.child.length > 0) ?
                        <optgroup key={index} label={item.sub_name}>
                           {item.child.map((item_s, idx) => {
                              return <option key={idx} value={item.sub_name + ' (' + item_s.sub_name + ")"}>
                                 {item.sub_name + ' (' + item_s.sub_name + ")"}
                              </option>
                           })}
                        </optgroup>
                        :
                        <option key={index} value={item.sub_name}>{item.sub_name}</option>
                  )
               })}
            </select>
         </td>
      )
   }
   holidayHandler(ev, index) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const holiText = ev.target.value.toUpperCase();
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === index) {
            return item = {
               ...item,
               reason: holiText
            }
         } else {
            return item;
         }
      })
      _shedule_obj.updated_subjects = _update_subjects;

      this.setState({
         shedule_obj: _shedule_obj
      })
   }

   examDateHandler = (feeDate, index) => {
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === index) {
            return item = { ...item, exam_date: feeDate }
         } else {
            return item;
         }
      })
      // const _shedule_obj = this.state.shedule_obj;
      // _shedule_obj.updated_subjects = [..._shedule_obj.updated_subjects, _update_subjects]
      _shedule_obj.updated_subjects = _update_subjects
      this.setState({
         shedule_date: feeDate,
         shedule_obj: { ...this.state.shedule_obj, updated_subjects: _update_subjects }
      })
   };
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      let del_id = id;
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.deleteHandlar(del_id);
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   saveInDatabase(ev) {
      ev.preventDefault();
   }

   addSheduleNoteHandler(ev) {
      ev.preventDefault();
      const _note = this.state.shedule_note_item;
      const _shedule_obj = this.state.shedule_obj;
      const _shedule_note = _shedule_obj.shedule_note;
      _shedule_note.push({ note: _note })

      _shedule_obj['shedule_note'] = _shedule_note;

      this.setState({
         shedule_obj: _shedule_obj,
         shedule_note_item: ''
      })
   }

   render() {
      const { shedule_date, shedule_note_item, showSheduleData, showInningsData, shedule_obj, selected_exams, selected_school_index, school_name, schools_arr,
         medium_arr, current_exam_inx, current_inning_inx, inn_name, inn_time, medium, innings, formIsHalfFilledOut } = this.state;
      console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Exam Schedule</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div className="page-bar d-flex">
               <div className="page-title">Exam Schedule</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <div className="form-group mr-2 mt-1">
                        <label className="control-label mr-2">Schools :</label>
                        <select className="form-control form-control-sm"
                           required
                           ref='school'
                           value={selected_school_index}
                           onChange={event => this.changeHandler(event, 'school')}>
                           <option value="">Select ...</option>
                           {schools_arr.map((item, index) => {
                              return (
                                 <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                              )
                           })}
                        </select>
                     </div>
                     <div className="form-group mr-2 mt-1">
                        <label className="control-label mr-2">Medium :</label>
                        <select className="form-control form-control-sm"
                           required
                           ref='medium'
                           disabled={medium_arr.length > 1 ? false : true}
                           value={medium}
                           onChange={event => this.changeHandler(event, 'medium')}>
                           <option value="">Select ...</option>
                           {medium_arr.map((item, index) => {
                              return (
                                 <option key={index} value={item}>{item}</option>
                              )
                           })}
                        </select>
                     </div>
                     <div className="form-group mt-1">
                        <label className="mr-2">Exam:</label>
                        <select
                           value={current_exam_inx}
                           disabled={school_name === '' ? true : false}
                           className="form-control form-control-sm" name="current_exam"
                           onChange={event => this.changeHandler(event, 'current_exam')} >
                           <option value="">Select...</option>
                           {selected_exams.map((option, index) => {
                              return (<option key={index} value={index}>{option.cat_name}</option>)
                           })}
                        </select>
                     </div>
                  </div></div>
            </div>
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  <div className="bg-info text-white d-flex mb-1">
                     <div className="form-inline">
                        <div className="form-group p-1">
                           <div className="input-group">
                              <select className="form-control form-control-sm"
                                 ref="innList"
                                 onChange={event => this.changeHandler(event, 'innings')}>
                                 <option value="">Select ...</option>
                                 {shedule_obj.innings.map((item, index) => {
                                    return (
                                       <option key={index} value={index}>{item.inning_name} [{item.inning_time}]</option>
                                    )
                                 })}
                              </select>
                              <button type="button" className="btn btn-danger btn-sm"
                                 disabled={current_inning_inx !== "" ? false : true}
                                 onClick={event => this.removeEnning(event)}>
                                 Delete
                                 </button>
                           </div>
                        </div>
                     </div>
                     <form className="form-inline ml-auto" onSubmit={event => this.addInningHandler(event)}>
                        <div className="form-group mt-1">
                           <label className="p-2">Inning Name</label>
                           <div className="input-group">
                              <input type="text"
                                 value={inn_name}
                                 onChange={event => this.changeHandler(event, 'inn_name')}
                                 className="form-control form-control-sm" />
                           </div>
                        </div>
                        <div className="form-group mt-1">
                           <label className="p-2" >Time</label>
                           <div className="input-group">
                              <div className="input-group-prepend">
                                 <div className="input-group-text"><i className="fa fa-clock"></i></div>
                              </div>
                              <input type="text"
                                 value={inn_time}
                                 onChange={event => this.changeHandler(event, 'inn_time')}
                                 className="form-control form-control-sm" />
                           </div>
                        </div>
                        <div className="form-group mr-1">
                           <button type="submit"
                              disabled={(inn_name !== "" && inn_time !== "") ? false : true}
                              className="btn btn-primary btn-sm ml-2">Add Inning</button>
                        </div>
                     </form>

                  </div>

                  <div className="table-scrollable">

                     <div className="container-fluid_ ">
                        <div className="row">
                           <div className="col-md-6">
                              <h6>Shedule Note List</h6>
                              <ol className="list-group">
                                 {shedule_obj.shedule_note.map((item, index) => {
                                    return (<li key={index} className="list-group-item p-1 pl-2">
                                       <div className="d-flex">
                                          <div className="d-flex">
                                             <b className="mr-2">{index + 1}.</b>
                                             <p className="mb-1">{item.note}</p>
                                          </div>
                                          <div className="ml-auto">
                                             <div className=" btn-group">
                                                <button className="btn btn-outline-danger btn-sm"
                                                   onClick={event => this.deleteSheduleNote(event, index)}><i className="fa fa-minus"></i>
                                                </button>
                                                <button className="btn btn-outline-success btn-sm"
                                                   onClick={event => this.editSheduleNote(event, index)}><i className="fa fa-edit"></i>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                    </li>)
                                 })}
                              </ol>
                           </div>
                           <div className="col-md-6">
                              <form className="card" onSubmit={event => this.addSheduleNoteHandler(event)}>
                                 <div className="card-header p-2"><b>Add Shedule Note</b></div>
                                 <div className="card-body p-2">
                                    <div className="form-group mb-0">
                                       <textarea rows="10"
                                          value={shedule_note_item}
                                          onChange={event => this.changeHandler(event, 'shedule_note')}
                                          className="form-control form-control-sm mb-0" />
                                    </div>
                                 </div>
                                 <div className="card-footer text-right p-2">
                                    <button type="submit"
                                       disabled={this.isEmpty(shedule_note_item)}
                                       className="btn btn-primary btn-sm">Add</button>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="card-footer d-flex p-2">

                  <button type="button" className="btn btn-primary ml-auto"
                     onClick={event => this.saveInDatabase(event)}>
                     Save</button>
               </div>
            </div >
         </div >
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: examsCategory } = state.examsCategory;
   return { user, schools, examsCategory };
 }
 
 const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getExamsCategory: examsCategoryAction.getExamsCategory,
 }
 
 export default connect(mapStateToProps, actionCreators)(withRouter(SheduleInnings));