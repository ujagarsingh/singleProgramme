import { portalClassesConstants } from '../_constants';
import { portalClassesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const portalClassesAction = {
    getPortalClasses
};

function getPortalClasses() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        portalClassesService.getPortalClasses()
            .then(
                response => {
                    dispatch(success(response.data.classes_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: portalClassesConstants.PORTAL_CLASSES_REQUEST } }
    function success(response) { return { type: portalClassesConstants.PORTAL_CLASSES_SUCCESS, response } }
    function failure(error) { return { type: portalClassesConstants.PORTAL_CLASSES_FAILURE, error } }
}
