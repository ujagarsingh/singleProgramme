import { frontArticleConstants } from '../_constants';
import { frontArticleService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const frontArticleActions = {
    getFrontArticle
};

function getFrontArticle() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontArticleService.getFrontArticle()
            .then(
                response => {
                    dispatch(success(response.data.article_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontArticleConstants.ARTICLE_REQUEST } }
    function success(response) { return { type: frontArticleConstants.ARTICLE_SUCCESS, response } }
    function failure(error) { return { type: frontArticleConstants.ARTICLE_FAILURE, error } }
}
 