import { schoolsConstants } from '../_constants';

export function schools(state = {}, action) {
  switch (action.type) {
    case schoolsConstants.SCHOOLS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case schoolsConstants.SCHOOLS_SUCCESS:
      return {
        item: action.response
      };
    case schoolsConstants.SCHOOLS_FAILURE:
      return {
        error: action.error
      };



    case schoolsConstants.CREATE_SCHOOL_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case schoolsConstants.CREATE_SCHOOL_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case schoolsConstants.CREATE_SCHOOL_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case schoolsConstants.UPDATE_SCHOOL_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case schoolsConstants.UPDATE_SCHOOL_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case schoolsConstants.UPDATE_SCHOOL_FAILURE:
      return {
        ...state,
        error: action.error
      };



    default:
      return state
  }
}