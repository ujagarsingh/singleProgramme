import { frontSliderConstants } from '../_constants';

// let app_state = JSON.parse(localStorage.getItem('app_state'));
// const initialState = app_state ?  app_state.frontSlider  : {};

export function frontSlider(state = {}, action) {
  switch (action.type) {
    case frontSliderConstants.SLIDER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case frontSliderConstants.SLIDER_SUCCESS:
      return {
        item: action.response
      };
    case frontSliderConstants.SLIDER_FAILURE:
      return {
        error: action.error
      };


    case frontSliderConstants.CREATE_SLIDER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontSliderConstants.CREATE_SLIDER_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case frontSliderConstants.CREATE_SLIDER_FAILURE:
      return {
        error: action.error
      };



    case frontSliderConstants.DELETE_SLIDER_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontSliderConstants.DELETE_SLIDER_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case frontSliderConstants.DELETE_SLIDER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}