// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const accVoucherEntry = {
    getAccVoucherEntry,
    createAccVoucherEntry,
    update,
    delete : _delete 
};

function getAccVoucherEntry() {
    loadProgressBar();
    const url = USER_URL + 'acc_voucher_entry/read.php';
    return Axios.post(url, authHeader()).then()
}

function createAccVoucherEntry(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_voucher_entry/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_voucher_entry/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_voucher_entry/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

