import { defaultGroupConstants } from '../_constants';

export function defaultGroup(state = {}, action) {
  switch (action.type) {
    case defaultGroupConstants.GROUP_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultGroupConstants.GROUP_SUCCESS:
      return {
        item: action.response
      };
    case defaultGroupConstants.GROUP_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}