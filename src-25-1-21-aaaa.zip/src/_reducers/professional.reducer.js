import { professionalConstants } from '../_constants';

export function professional(state = {}, action) {
  switch (action.type) {
    case professionalConstants.PROFESSIONAL_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case professionalConstants.PROFESSIONAL_SUCCESS:
      return {
        item: action.response
      };
    case professionalConstants.PROFESSIONAL_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}