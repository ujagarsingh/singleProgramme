import { feeDetailedCollectionConstants } from '../_constants';

export function feeDetailed(state = {}, action) {
  switch (action.type) {
    case feeDetailedCollectionConstants.FEE_COLLECTION_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeDetailedCollectionConstants.FEE_COLLECTION_SUCCESS:
      return {
        item: action.response
      };
    case feeDetailedCollectionConstants.FEE_COLLECTION_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}