import { defaultEventsConstants } from '../_constants';

export function defaultEvents(state = {}, action) {
  switch (action.type) {
    case defaultEventsConstants.EVENTS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultEventsConstants.EVENTS_SUCCESS:
      return {
        item: action.response
      };
    case defaultEventsConstants.EVENTS_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}