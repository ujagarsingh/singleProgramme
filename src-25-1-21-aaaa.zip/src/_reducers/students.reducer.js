import { studentsConstants } from '../_constants';

export function students(state = {}, action) {
  switch (action.type) {
    case studentsConstants.STUDENTS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case studentsConstants.STUDENTS_SUCCESS:
      return {
        item: action.response
      };
    case studentsConstants.STUDENTS_FAILURE:
      return {
        error: action.error
      };


    case studentsConstants.CREATE_STUDENTS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case studentsConstants.CREATE_STUDENTS_SUCCESS:
      // const new_arr = [action.response, ...state.item];
      const _all_stu = state.item;
      const _new_stu = action.response[0];
      let _inx = '';
      let _inx_flag = true;
      _all_stu.filter((item, index) => {
        if ((_new_stu.school_id === item.school_id) && (_new_stu.stu_class === item.stu_class)) {
          if (_inx_flag) {
            _inx = index;
            _inx_flag = false;
          }
        }
      })

      _all_stu.splice(_inx - 1, 0, _new_stu);
      // console.log();

      return {
        item: _all_stu,
        loading: false,
      };
    case studentsConstants.CREATE_STUDENTS_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}