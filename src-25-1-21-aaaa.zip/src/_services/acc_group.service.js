// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const accGroupService = {
    getAccGroup,
    createAccGroup,
    update,
    delete : _delete 
};

function getAccGroup() {
    loadProgressBar();
    const url = USER_URL + 'acc_group/read.php';
    return Axios.post(url, authHeader()).then()
}

function createAccGroup(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_group/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_group/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_group/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

