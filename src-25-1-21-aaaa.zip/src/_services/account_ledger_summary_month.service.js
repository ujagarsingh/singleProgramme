// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const accountLedgerSummaryMonthService = {
    getLedgerNameHandler,
    getLedgerSummaryofMonthHandler,
};

function getLedgerSummaryofMonthHandler(mydata) {
    debugger
    const data = mydata.acc_manager.ledger_data;
    const all_ledgers = mydata.acc_manager.all_ledgers;
    const _accLedgerEntry = mydata.accLedgerEntry;
    const grpId = mydata.ledger_id;
    const monthId = mydata.month_id;
    return new Promise((resolve, reject) => {
        const m_data = data.filter((vItem) => {
            if (grpId === vItem.ledger_folio && monthId === vItem.entry_month) {
                return vItem
            }
        })
        let d_data = [];
        m_data.filter((vItem) => {
            if (!d_data.includes(vItem.vchr_ref_id)) {
                d_data.push(vItem.vchr_ref_id)
            }
            return false
        })
        let cr_total = 0;
        let dr_total = 0;
        const f_res = d_data.map((item) => {

            const v_data = m_data.filter((vItem) => {
                if (item === vItem.vchr_ref_id) {
                    return vItem
                }
            });

            let group_name = "";
            let group_id = "";
            let group_date = "";
            let group_type = "";
            let cr_amo = 0;
            let dr_amo = 0;

            const _data = v_data.map((vItem, inx) => {
                if (monthId == vItem.entry_month) {
                    if (vItem.tr_type === "CR") {
                        cr_amo = Number(vItem.tr_amount);
                        cr_total += Number(vItem.tr_amount);
                    } else {
                        dr_amo = Number(vItem.tr_amount);
                        dr_total += Number(vItem.tr_amount);
                    }
                }
                const l_name = this.getLedgerNameHandler(all_ledgers, vItem.ldr_ref_id);

                if (inx > 0) {
                    group_name = group_name + " /...";
                } else {
                    group_name = l_name;
                    group_id = vItem.vchr_ref_id;
                    group_date = vItem.server_date_time.split(" ")[0];
                    group_type = _accLedgerEntry.filter(e => e.r_id === vItem.vchr_ref_id)[0].vchr_type; // "Journal"
                }
                return vItem = {
                    "ldr_ref_id": vItem.ldr_ref_id,
                    "tr_date": vItem.server_date_time.split(" ")[0],
                    "vch_type": _accLedgerEntry.filter(e => e.r_id === vItem.vchr_ref_id)[0].vchr_type, // "Journal",
                    "vchr_ref_id": vItem.vchr_ref_id,
                    "cr_amo": cr_amo,
                    "dr_amo": dr_amo,
                    "ldr_name": l_name,
                };
            })

            // debugger
            // let f_data = { "data": _data, "tcr": cr_total, "tdr": dr_total, "cl_blnc": Math.abs(cr_total - dr_total), "blnc_type": (cr_total <= dr_total) ? "Dr" : "Cr" };
            let f_data = {
                "gtr_type": (cr_amo <= dr_amo) ? "Dr" : "Cr",
                "gcr_amo": cr_amo,
                "gdr_amo": dr_amo,
                "g_name": group_name,
                "g_type": group_type,
                "g_id": group_id,
                "g_date": group_date,
                "child_data": (_data.length > 1) ? _data : [],
            };
            return f_data;
        })
        const grp_data = {
            "blnc_type": (cr_total <= dr_total) ? "Dr" : "Cr",
            "cl_blnc": Math.abs(cr_total - dr_total),
            "gt_dr": dr_total,
            "gt_cr": cr_total,
            "child": f_res
        }

        // console.log(f_res)
        // debugger
        if (f_res.length > 0) {
            resolve({ "data": { ledger_summary_of_month: grp_data } });
        } else {
            reject("Something went wrong");
        }

        // return f_data;
    })
} 
// ledger folio to get ledger name
function getLedgerNameHandler(all_ledgers, ledger_folio) {
    const fl = all_ledgers.filter((item) => {
        if (item.ldr_ref_id === ledger_folio) {
            return item;
        }
    })
    return fl[0].ledger_name;
}

