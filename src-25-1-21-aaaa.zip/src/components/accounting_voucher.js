import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { confirmAlert } from 'react-confirm-alert';
import { connect } from 'react-redux';
import DatePicker from 'react-date-picker';

import * as accMethod from '../utility/accounts';
import SingleEntry from '../includes/single_entry'; 

import { isEmptyObj, isEmpty, checkEntryType, getAllInputs } from '../utility/utilities';

class AccountingVoucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    filter_data: [],
    credit_ledgers: [],
    debit_ledgers: [],
    current_ldr: '',
    voucher_type: 'Payment',
    first_vchr_type: 'CR',
    voucher_obj: {
      "child": [
        { "ldr_ref_id": "", "tr_amount": "", "tr_type": "CR", "ledger_name": "" }
      ]
    },
    vchr_date: new Date(),
    lockInputs: false,
    vchr_type: "",
  }

  setArraowKeysHandler() {
    document.addEventListener('keydown', (e) => {
      switch (e.keyCode) {
        case 37:          // console.log('left');
          this.handleKeyDown("left");
          break;
        case 38:          // console.log('up');
          this.handleKeyDown("up");
          break;
        case 39:          // console.log('right');
          this.handleKeyDown("right");
          break;
        case 40:          // console.log('down');
          this.handleKeyDown("down");
          break;
        case 13:          // console.log('Enter');
          // this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        case 9:          // console.log('Tab');
          // this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        default:        // console.log('something wrong');
      }
    });
    accMethod.focusFirstHandler();
  }
 

  examStartDate = (feeDate) => {
    this.setState({ vchr_date: feeDate });
    // this.to.openCalendar();
  };
  chooseLedgerHandler() {
    //  debugger
    const { filter_data, cursor, current_inx } = this.state;
    const current_ldr = filter_data[cursor];
    // console.log(current_ldr);
    if (!isEmptyObj(current_ldr)) {
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv.child[current_inx]['ldr_ref_id'] = current_ldr['ldr_ref_id'];
      sv.child[current_inx]['ledger_name'] = current_ldr['ledger_name'];
      this.setState({
        voucher_obj: sv,
        filter_data: []
      })
    }
  }

  handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }), () => { accMethod.srollListItemHandler(key) })
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }), () => { accMethod.srollListItemHandler(key) })
    }
  }

  


  valueTOchangeHandler = (val, indexNo) => {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    sv.child[indexNo].tr_type = val;
    this.setState({ voucher_obj: sv })
  };

  changeHandler = (event, fieldName, isCheckbox, indexNo, trType) => {
    // debugger
    if (fieldName === 'ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv.child[indexNo].tr_type = _val.toUpperCase();
      this.setState({ voucher_obj: sv })
    } else if (fieldName === 'narration') {
      // debugger;
      const _val = event.target.value;
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      sv['narration'] = _val;
      this.setState({ voucher_obj: sv })
    } else if (fieldName === 'ldr_name') {
      // debugger;
      let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
      const _val = event.target.value;

      const ldr_list = (event.target.getAttribute('data-type') === "CR") ? "credit_ledgers" : "debit_ledgers";

      const ledger_list = JSON.parse(JSON.stringify(this.state[ldr_list]));
      const resData = accMethod.filterDataHandler(ledger_list, _val);

      sv.child[indexNo].ledger_name = resData['val_txt'];

      this.setState({
        filter_data: resData['filter_data'],
        voucher_obj: sv
      })

    } else if (fieldName === 'ldr_amo') {

      this.updateTransetionAmountHandler(event, indexNo, trType);

    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };


  updateTransetionAmountHandler(e, indexNo, trType) {
    // debugger
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    const _val = e.target.value;
    sv.child[indexNo].tr_amount = _val;
    this.setState({
      voucher_obj: sv,
      tr_type: trType
    })
  }



  ledgerListHandler = (obj) => {
    this.setState({
      filter_data: obj['filter_data'],
      current_inx: obj['current_inx'],
      cursor: obj['cursor']
    })
  }


  tabAndEnterHandler(ev) {
    ev.preventDefault();
    const allinput = getAllInputs();
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    const _ti = ev.target;
    let _ci = '';
    allinput.map((item, inx) => { if (item === _ti) { _ci = inx; } });

    let nextTi = '';
    if ((ev.shiftKey && ev.key === 'Tab') || (ev.shiftKey && ev.key === 'Enter')) {
      nextTi = (_ci === 0 || _ci === 1) ? 1 : _ci - 1;
    } else {
      nextTi = (_ci === allinput.length) ? allinput.length : _ci + 1;
    }

    if (nextTi !== -1) {
      if (nextTi === (allinput.length - 1)) {
        const gTotal = accMethod.getSumOfBalanceHandler(sv);
        // console.log("last transaction");
        if (gTotal.total_cr !== gTotal.total_dr) {
          this.checkEntriesHandler(ev, gTotal);
        } else {
          (allinput[nextTi]).focus();
          (allinput[nextTi]).select();
        }
      } else if (nextTi === 1) {
        // console.log("first")
        (allinput[nextTi]).focus();
        (allinput[nextTi]).select();
      } else if (nextTi === allinput.length) {
        // console.log("last")
        debugger;
        if (!isEmpty(sv.cr_total_amo) || !isEmpty(sv.dr_total_amo)) {
          this.setState({
            lockInputs: true
          })
          this.confirmBoxSubmit(ev)
        } else {
          alert('Something is Wrong!')
        }
      } else {
        (allinput[nextTi]).focus();
        (allinput[nextTi]).select();
      }
    }
    if (ev.target.dataset.name === 'ldr_name') {
      this.chooseLedgerHandler();
    }
  }


  checkEntriesHandler(ev, gTotal) {
    const gt = gTotal;
    let sv = JSON.parse(JSON.stringify(this.state.voucher_obj));
    sv['cr_total_amo'] = (gt.total_cr > gt.total_dr) ? gt.total_cr : gt.total_dr;
    sv['dr_total_amo'] = (gt.total_cr > gt.total_dr) ? gt.total_cr : gt.total_dr;
    sv.child.push({
      ldr_ref_id: "", tr_amount: Math.abs(gt.total_cr - gt.total_dr),
      tr_type: (gt.total_cr < gt.total_dr) ? "CR" : "DR", ledger_name: ""
    })
    this.setState({
      voucher_obj: sv
    }, () => this.tabAndEnterHandler(ev))
  };

  componentDidMount() {
    this.componentDidMountHandler()
  }

  getRelativeLedgerListHandler(){
    const { accountManager: { all_ledgers }, accLedgerEntry, match } = this.props;
    const _av_id = match.params.id;
    if(_av_id){
      this.props.getVoucherEntryHandler({ "vchrid": _av_id, "ldr_data": accLedgerEntry, "all_ledgers": all_ledgers });
    }
  }

  componentDidMountHandler() {
    const { all_ledgers } = this.props.accountManager;
    const { voucher_type } = this.state;
    const resData = accMethod.effectedLedgerHandler(voucher_type, all_ledgers);
    this.setState({
      credit_ledgers: resData['credit_ledgers'],
      debit_ledgers: resData['debit_ledgers'],
    }, () => { 
      this.setArraowKeysHandler(); 
      this.getRelativeLedgerListHandler();
    })
  }


  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          type: 'submit',
          onClick: () => {
            this.createHandler();
          }
        },
        {
          label: 'No',
          onClick: () => {
            this.cancleHandler()
          }
        }
      ]
    });
  };
  cancleHandler = () => {
    this.setState({
      lockInputs: true,
    }, () => {
      accMethod.focusFirstHandler();
    })
  }
  createHandler = () => {

    const tr_type = this.state.first_vchr_type;
    this.addNewVoucher(tr_type)

  }



  selectVoucherTypeHandler(ev, val) {
    ev.preventDefault();
    switch (val) {
      case "Receipt":
        // Receipt Voucher
        this.addNewVoucher("CR", val);
        break;
      case "Payment":
        // Receipt Voucher
        this.addNewVoucher("DR", val);
        break;
      case "Contra":
        // Receipt Voucher
        this.addNewVoucher("CR", val);

        break;
      default:
        // Journal
        this.addNewVoucher("CR", val);

    }
  }

  addNewVoucher(tr_type, voucher_type) {
    debugger;
    this.setState({
      voucher_obj: {
        "child": [{ "ldr_ref_id": "", "tr_amount": "", "tr_type": tr_type, "ledger_name": "" }],
        narration: ''
      },
      lockInputs: false,
      voucher_type: voucher_type,
      first_vchr_type : tr_type,
    }, () => {
      this.componentDidMountHandler();
      accMethod.focusFirstHandler();
    })
  }

  staticHeader() {
    return <div className="acc-page-head container-fluid">
      <div className="sec-title">
        <div className="title-zone">Particulars</div>
        <div className="info-zone">
          <div className="info-zone">
            <table className="table table-bordered table-sm">
              <tbody>
                <tr>
                  <td>
                    <div className="dr-title">Debit</div>
                  </td>
                  <td>
                    <div className="cr-title">Credit</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  }

  render() {
    const { user, accountManager } = this.props;
    const { voucher_obj, filter_data, voucher_type, cursor, vchr_date, lockInputs, credit_ledgers, debit_ledgers, first_vchr_type } = this.state;
    console.log(this.state.filter_data);
    return (
      <div className="page-content">
        <Helmet>
          <title>{voucher_type} Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> {voucher_type} Voucher</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con inline-box">
              <div className="form-group mr-2 mt-2">
                <ul className="nav d-flex mr-4">
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Receipt")}
                      className="btn btn-outline-secondary btn-sm">Receipt</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Payment")}
                      className="btn btn-outline-secondary btn-sm">Payment</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Journal")}
                      className="btn btn-outline-secondary btn-sm">Journal</button>
                  </li>
                  <li className="nav-item mr-1">
                    <button
                      type="button"
                      onClick={(event) => this.selectVoucherTypeHandler(event, "Contra")}
                      className="btn btn-outline-secondary btn-sm">Contra</button>
                  </li>
                </ul>
              </div>
              <div className="form-group mt-1">
                <DatePicker
                  onChange={this.examStartDate}
                  value={vchr_date}
                  showLeadingZeroes={true}
                //minDate={new Date()}
                />
              </div>
            </div>
          </div>
        </div>
        {user && voucher_obj && accountManager &&
          <div className="card card-box sfpage-cover light-trans">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page page-receipt-voucher">
                {(filter_data.length > 0) &&
                  <div className="list-accunts">
                    <div className="list-acc-head">List of Ledger Accunts</div>
                    <div className="list-acc-body" id="ldrList">
                      <ul>
                        {filter_data.map((item, index) => {
                          return (
                            <li
                              className={cursor === index ? 'active' : null}
                              key={index}>
                              {item.ledger_name}
                            </li>
                          )
                        })}
                      </ul>
                    </div>
                    <div className="list-acc-footer">more...</div>
                  </div>
                }
                {this.staticHeader()}
                <div className="acc-page-body container-fluid">
                  <div className="av-detail-zone">
                    {voucher_obj.child.map((item, index) => {
                      return (
                        <div className="av-detail-head" key={index}>
                          <SingleEntry
                            eIndex={index}
                            lockInputs={lockInputs}
                            eItem={item}
                            credit_ledgers={credit_ledgers}
                            debit_ledgers={debit_ledgers}
                            ledgerListHandler={this.ledgerListHandler}
                            setFilteredDataHandler={this.setFilteredDataHandler}
                            changeHandler={this.changeHandler}
                            valueTOchangeHandler={this.valueTOchangeHandler}
                          />
                        </div>
                      )
                    })}
                  </div>

                </div>
                <div className="acc-page-footer av-page-footer container-fluid">
                  <div className="sec-foot">
                    <div className="narration-zone">
                      <div className="title">Narration:</div>
                      <textarea
                        value={voucher_obj.narration}
                        onChange={event => this.changeHandler(event, `narration`)}
                        className="form-control" >
                      </textarea>
                    </div>
                    <div className="amount-zone">
                      <div className="dr-total">{voucher_obj.dr_total_amo}</div>
                      <div className="cr-total">{voucher_obj.cr_total_amo}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accountManager } = state.accountManager;
  return {
    user, accountManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
}

export default connect(mapStateToProps, actionCreators)(withRouter(AccountingVoucher));