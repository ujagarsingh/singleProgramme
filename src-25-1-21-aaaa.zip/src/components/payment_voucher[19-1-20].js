import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { confirmAlert } from 'react-confirm-alert';
import { connect } from 'react-redux';
import DatePicker from 'react-date-picker';
import {
  accLedgerActions, professionalAction,
  accGroupActions, accLedgerEntryActions, studentsAction
} from '../_actions';
import { isEmptyObj, isEmpty, checkEntryType, getAllInputs } from '../utility/utilities';
import * as accMethod from '../utility/accounts';
import SingleEntry from '../includes/single_entry';
import FilteredDataList from '../includes/filtered_data_list';

// import CommonFilters from '../utility/Filter/filter-schools';

class Voucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    filter_data: [],
    credit_ledgers: [],
    debit_ledgers: [],
    current_ldr: '',
    vchr_type: "Payment",
    voucher: {
      "vch_no": "3163", "child": [
        { "ldr_ref_id": "5_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Fee Discount" },
        { "ldr_ref_id": "1_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Profit & Loss A/c" },
        { "ldr_ref_id": "6_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Teaching Staff Salary" },
        { "ldr_ref_id": "9_LDR_4", "tr_amount": "545", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Exam Fee" },
        { "ldr_ref_id": "14_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Registration Fee" },
        { "ldr_ref_id": "49_STU_4", "tr_amount": "743", "tr_type": "DR", "under_grp_id": "10", "under_grp_type": "P", "ledger_name": "AASHISH MEENA S/o RAMBABU MEENA [141/Fourth]" }],
      "cr_total_amo": 743, "dr_total_amo": 743, "narration": "AASHISH MEENA S/o RAMBABU MEENA Total Due is Rs. 743.", "vchr_type": "Journal"
    },
    vchr_date: new Date(),
  }

  setArraowKeysHandler() {
    document.addEventListener('keydown', (e) => {
      switch (e.keyCode) {
        case 37:          // console.log('left');
          this.handleKeyDown("left");
          break;
        case 38:          // console.log('up');
          this.handleKeyDown("up");
          break;
        case 39:          // console.log('right');
          this.handleKeyDown("right");
          break;
        case 40:          // console.log('down');
          this.handleKeyDown("down");
          break;
        case 13:          // console.log('Enter');
          this.chooseLedgerHandler();
          this.tabAndEnterHandler(e);
          break;
        case 9:          // console.log('Tab');
          this.tabAndEnterHandler(e);
          break;
        default:        // console.log('something wrong');
      }
    });
    accMethod.focusFirstHandler();
  }

  examStartDate = (feeDate) => {
    this.setState({ vchr_date: feeDate });
    // this.to.openCalendar();
  };
  chooseLedgerHandler() {
    //  debugger

    const { filter_data, cursor, current_inx } = this.state;
    const current_ldr = filter_data[cursor];
    // console.log(current_ldr);
    if (!isEmptyObj(current_ldr)) {
      let sv = this.state.voucher;
      sv.child[current_inx]['ldr_ref_id'] = current_ldr['ldr_ref_id'];
      sv.child[current_inx]['ledger_name'] = current_ldr['ledger_name'];
      this.setState({
        voucher: sv
      })
    }
  }

  handleKeyDown = (key) => {
    const { cursor, filter_data } = this.state
    // arrow up/down button should select next/previous list element
    if ((key === "up" || key === "left") && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }), () => { accMethod.srollListItemHandler(key) })
    } else if ((key === "down" || key === "right") && cursor < filter_data.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }), () => { accMethod.srollListItemHandler(key) })
    }
  }


  changeHandler = (event, fieldName, isCheckbox, indexNo, trType) => {
    debugger
    if (fieldName === 'ldr_type') {
      // debugger;
      const _val = checkEntryType(event);
      let sv = JSON.parse(JSON.stringify(this.state.voucher));
      sv.child[indexNo].tr_type = _val;
      this.setState({ voucher: sv })
    } else if (fieldName === 'ldr_name') {

      let sv = JSON.parse(JSON.stringify(this.state.voucher));
      const _val = event.target.value;
      sv.child[indexNo].ledger_name = _val;

      const ldr_list = (event.target.getAttribute('data-type') === "CR") ? "credit_ledgers" : "debit_ledgers";

      const ledger_list = JSON.parse(JSON.stringify(this.state[ldr_list]));
      const resData = accMethod.filterDataHandler(ledger_list, _val);
      this.setState({
        filter_data: resData,
        voucher: sv
      })

    } else if (fieldName === 'ldr_amo') {
      this.updateTransetionAmountHandler(event, indexNo, trType);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  updateTransetionAmountHandler(e, indexNo, trType) {
    let sv = this.state.voucher;
    const _val = e.target.value;
    sv.child[indexNo].tr_amount = _val;
    this.setState({
      voucher: sv,
      tr_type: trType
    })
  }

  setFilteredDataHandler = (data) => {
    this.setState({
      filter_data: data
    })
  }

  ledgerListHandler = (obj) => {
    this.setState({
      filter_data: obj['filter_data'],
      current_inx: obj['current_inx'],
      cursor: obj['cursor']
    })
  }


  tabAndEnterHandler(ev) {
    ev.preventDefault();
    // const allinput = (!isEmpty(this.state.allinput) || this.state.allinput === 'undefined') ? getAllInputs() : this.state.allinput;
    const allinput = getAllInputs();
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    const _ti = ev.target;
    let _ci = '';
    allinput.map((item, inx) => { if (item === _ti) { _ci = inx; } });

    let nextTi = '';
    if ((ev.shiftKey && ev.key === 'Tab') || (ev.shiftKey && ev.key === 'Enter')) {
      // nextTi = (_ci === 0) ? allinput.length - 1 : _ci - 1;
      nextTi = (_ci === 0 || _ci === 1) ? 1 : _ci - 1;
    } else {
      // nextTi = (_ci === allinput.length) ? 0 : (_ci === (allinput.length - 1)) ? 0 : _ci + 1;
      nextTi = (_ci === allinput.length) ? allinput.length : _ci + 1;
    }
    if (nextTi === (allinput.length - 1)) {
      const gTotal = accMethod.getSumOfBalanceHandler(sv);
      // console.log("last transaction");
      if (gTotal.total_cr !== gTotal.total_dr) {
        this.checkEntriesHandler(ev, gTotal);
      } else {
        (allinput[nextTi]).focus();
      }
    } else if (nextTi === 1) {
      // console.log("first")
      (allinput[nextTi]).focus();
    } else if (nextTi === allinput.length) {
      // console.log("last")
      this.confirmBoxSubmit(ev)
    } else {
      (allinput[nextTi]).focus();
    }
  }

  checkEntriesHandler(ev, gTotal) {
    const gt = gTotal;
    let sv = JSON.parse(JSON.stringify(this.state.voucher));
    sv['cr_total_amo'] = gt.total_cr;
    sv['dr_total_amo'] = gt.total_dr;
    sv.child.push({ ldr_ref_id: "", tr_amount: Math.abs(gt.total_cr - gt.total_dr), tr_type: (gt.total_cr < gt.total_dr) ? "CR" : "DR", ledger_name: "" })
    this.setState({
      voucher: sv
    }, () => this.tabAndEnterHandler(ev))
  };

  componentDidMount() {
    const vchr_type = this.state.vchr_type;
    const { all_ledgers } = this.props.accountManager;
    const resData = accMethod.effectedLedgerHandler(vchr_type, all_ledgers);
    this.setState({
      credit_ledgers: resData['credit_ledgers'],
      debit_ledgers: resData['debit_ledgers'],
      all_ledgers: resData['all_ledgers']
    })
    this.setArraowKeysHandler();
  }


  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.createHandler();
          }
        },
        {
          label: 'No',
          onClick: () => {
            this.focusFirstHandler();
          }
        }
      ]
    });
  };
  createHandler = () => {
    alert(JSON.stringify(this.state.voucher));
  }
 
  staticHeader() {
    return <div className="acc-page-head container-fluid">
      <div className="sec-title">
        <div className="title-zone">Particulars</div>
        <div className="info-zone">
          <div className="info-zone">
            <table className="table table-bordered table-sm">
              <tbody>
                <tr>
                  <td>
                    <div className="dr-title">Debit</div>
                  </td>
                  <td>
                    <div className="cr-title">Credit</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  }
  render() {
    const { user, accountManager } = this.props;
    const { voucher, filter_data, cursor, vchr_date, credit_ledgers, debit_ledgers } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Payment Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> Payment Voucher</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con inline-box">
              <div className="form-group mt-1">
                <DatePicker
                  onChange={this.examStartDate}
                  value={vchr_date}
                  showLeadingZeroes={true}
                //minDate={new Date()}
                />
              </div>
            </div>
          </div>
        </div>
        {user && voucher && accountManager &&
          <div className="card card-box sfpage-cover light-trans">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page page-receipt-voucher">
                {(filter_data.length > 0) &&
                  <FilteredDataList
                    cursor={cursor}
                    filter_data={filter_data}
                  />
                }
                {this.staticHeader()}
                <div className="acc-page-body container-fluid">
                  <div className="av-detail-zone">
                    {voucher.child.map((item, index) => {
                      return (
                        <div key={index}>
                          <SingleEntry
                            eIndex={index}
                            eItem={item}
                            credit_ledgers={credit_ledgers}
                            debit_ledgers={debit_ledgers}
                            ledgerListHandler={this.ledgerListHandler}
                            setFilteredDataHandler={this.setFilteredDataHandler}
                            changeHandler={this.changeHandler}
                          />
                        </div>
                      )
                    })}
                  </div>

                </div>
                <div className="acc-page-footer av-page-footer container-fluid">
                  <div className="sec-foot">
                    <div className="narration-zone">
                      <div className="title">Narration:</div>
                      <textarea
                        value={voucher.narration}
                        onChange={event => this.changeHandler(event, `narration`)}
                        className="form-control" >
                      </textarea>
                    </div>
                    <div className="amount-zone">
                      <div className="dr-total">{voucher.dr_total_amo}</div>
                      <div className="cr-total">{voucher.cr_total_amo}</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accountManager } = state.accountManager;
  return {
    user, accountManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
}

export default connect(mapStateToProps, actionCreators)(withRouter(Voucher));