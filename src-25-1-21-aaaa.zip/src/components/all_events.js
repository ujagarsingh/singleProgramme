import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import axios from 'axios';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { isEmptyObj, isEmpty } from '../utility/utilities';
import { eventsActions, schoolsAction } from '../_actions';

import AddEvent from './add_event';
import EditEvent from './edit_event';
import CommonFilters from '../utility/Filter/filter-schools';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_EVENTS = `http://schools.rajpsp.com/api/events/read.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/events/delete.php`;

class AllEvents extends Component {
  state = {
    medium_arr: [],
    events: [],
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.getSelectedEventsHandler(_sch_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: ''
    //   })
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   sessionStorage.setItem("medium", _medium);
    //   this.setState({
    //     [fieldName]: isCheckbox ? event.target.checked : event.target.value
    //   });
    // } else {
    // }
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value
    });
  };
  getSelectedEventsHandler() {
    const _school_id = this.props.filteredSchoolData.slct_school_id;
    const _selected_item = this.props.allEvents.filter((item) => {
      if (item.school_id === _school_id) { return item }
    })
    this.setState({
      schools_events: _selected_item
    })
  }
  componentDidMount() {
    if (isEmptyObj(this.props.allEvents)) {
      this.props.getEvents();
    }
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _allEvents = this.props.allEvents;
      if (_allEvents && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    // const _filter = this.props.filteredSchoolData;
    // const _allEvents = this.props.allEvents;
    // if (!isEmpty(_allEvents)) {
    //   const _school_allEvents = _allEvents.filter((item) => {
    //     if (_filter.slct_school_id) {
    //       if (item.school_id === _filter.slct_school_id) {
    //         return item
    //       }
    //     } else {
    //       return item
    //     }
    //   })
    //   this.setState({
    //     schools_events: _school_allEvents,
    //   })
    // }
    setTimeout(() => {
      this.getSelectedEventsHandler();
    }, 100)
  }

  // filterByClsHandler = () => {
  //   const _fltr_school = this.props.filteredSchoolData;
  //   const _fltr_class = this.props.filteredClassesData;
  //   const _all_student = this.props.students;
  //   if (_all_student) {
  //     const _school_student = _all_student.filter((item) => {
  //       if (!isEmpty(_fltr_class.slct_cls_name)) {
  //         if (item.school_id === _fltr_school.slct_school_id &&
  //           item.stu_class === _fltr_class.slct_cls_name) {
  //           return item
  //         }
  //       } else {
  //         if (item.school_id === _fltr_school.slct_school_id) {
  //           return item
  //         }
  //       }
  //     })
  //     this.setState({
  //       display_student: _school_student
  //     })
  //   }
  // }


  componentWillReceiveProps(nextProps) {
    if (nextProps.allEvents) {
      this.filterBySchoolHandler();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getAllEventsHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getAllEventsHandler() {
  //   loadProgressBar();
  //   axios.get(GET_EVENTS)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         events: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.events);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteEvents({ id: id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   axios.post(DELETE_URL + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _events = this.state.events.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         events: _events
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }



  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateEvents(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.allEvents.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  render() {
    const { createItem, editItem, formIsHalfFilledOut, schools_events, selected_item } = this.state;
    const { allEvents, user, schools } = this.props;
    // console.log(this.props);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Events</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {/* <div className="page-bar d-flex">
          <div className="page-title">All Event</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mt-1">
                <NavLink to="/add_event.jsp" className="btn btn-primary btn-sm">
                  Add New <i className="fa fa-plus" />
                </NavLink>
              </div>
            </div>
          </div>
          </div> */}
        <div className="page-bar d-flex">
          <div className="page-title">Events List</div>
          {user && schools && allEvents &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div> */}
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  // showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                // filterByClsHandler={this.filterByClsHandler}
                />

              </div>
            </div>
          }
        </div>

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {createItem ? <AddEvent
              toggeleCreate={this.toggeleCreate} />
              : null}
            {editItem ?
              <>
                <EditEvent
                  selected_item={selected_item}
                  schools={schools}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                <div className="backdrop edit-mode"></div>
              </>
              : null}

            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th>School(s)</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Description </th>
                    <th width="100">Start Date</th>
                    <th width="100">End Date</th>
                    <th>Action </th>
                  </tr>
                </thead>
                {schools_events && user &&
                  <tbody>
                    {schools_events.map((item, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}.</td>
                          <td>{item.school_name}, {item.school_medium}</td>
                          <td className="rectangle-pic">
                            {item.event_img !== '' ?
                              < img src={`${process.env.PUBLIC_URL}` + item.event_img} alt={item.title_1a} />
                              : <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/event.jpg`} />
                            }
                          </td>
                          <td>{item.title}</td>
                          <td>{item.type}</td>
                          <td>{item.description}</td>
                          <td>{item.date_start}</td>
                          <td>{item.date_end}</td>
                          <td>
                            <div className="d-flex">
                              {/* <NavLink to={`edit_event.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                                Edit
                          </NavLink> */}
                              <button className="btn btn-primary btn-sm mr-1"
                                type="button"
                                onClick={event => this.openEdit(event, item.id)}>Edit</button>
                              <button className="btn btn-danger btn-sm"
                                value={item.id}
                                onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                }
              </table>
            </div>
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">
                Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">
                Add New
            </button>
            }
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: allEvents } = state.events;
  const { item: schools } = state.schools;
  const filteredSchoolData = state.filteredSchoolData;
  // const filteredClassesData = state.filteredClassesData;
  return { allEvents, user, schools, filteredSchoolData };
}

const actionCreators = {
  getEvents: eventsActions.getEvents,
  updateEvents: eventsActions.update,
  deleteEvents: eventsActions.delete,
  getSchools: schoolsAction.getSchools,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllEvents));