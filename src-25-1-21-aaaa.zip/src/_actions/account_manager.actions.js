import { accountManagerConstants } from '../_constants';
import { accountManager } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accountManagerActions = {
    getAccountManager,
};

 

function getAccountManager() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accountManager.getAccountManager()
            .then(
                response => {
                    dispatch(success(response.data.account_manger),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accountManagerConstants.READ_ACCOUNT_MANAGER_REQUEST } }
    function success(response) { return { type: accountManagerConstants.READ_ACCOUNT_MANAGER_SUCCESS, response } }
    function failure(error) { return { type: accountManagerConstants.READ_ACCOUNT_MANAGER_FAILURE, error } }
}
 