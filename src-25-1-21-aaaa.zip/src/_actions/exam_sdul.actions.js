import { examSdulConstants } from '../_constants';
import { examSdulService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examSdulAction = {
    getExamSdul,
    create,
    delete: _delete
};

function getExamSdul() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulService.getExamSdul()
            .then(
                response => {
                    dispatch(success(response.data.innings_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulConstants.EXAM_SDUL_REQUEST } }
    function success(response) { return { type: examSdulConstants.EXAM_SDUL_SUCCESS, response } }
    function failure(error) { return { type: examSdulConstants.EXAM_SDUL_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item), toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulConstants.CREATE_REQUEST } }
    function success(response) { return { type: examSdulConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: examSdulConstants.CREATE_FAILURE, error } }
}

function _delete(obj) {
    return dispatch => {
        dispatch(request());
        examSdulService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulConstants.DELETE_REQUEST } }
    function success(response) { return { type: examSdulConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: examSdulConstants.DELETE_FAILURE, error } }
}
