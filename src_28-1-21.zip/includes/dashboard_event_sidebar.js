import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';

class DashboardEventSidebar extends Component {
  render() {
    return (
      <div className="chat-sidebar-container" data-close-on-body-click="false">
      <div className="chat-sidebar">
        <ul className="nav nav-tabs">
          <li className="nav-item">
            <a href="#quick_sidebar_tab_1" className="nav-link active tab-icon" data-toggle="tab"> <i className="material-icons">chat</i>Holidays
              <span className="badge badge-danger">16</span>
            </a>
          </li>
          <li className="nav-item">
            <a href="#quick_sidebar_tab_2" className="nav-link tab-icon" data-toggle="tab"> <i className="material-icons">group</i>
              Events
              <span className="badge badge-info">3</span>
            </a>
          </li>
          <li className="nav-item">
            <a href="#quick_sidebar_tab_3" className="nav-link tab-icon" data-toggle="tab"> <i className="material-icons">settings</i>
              Settings
            </a>
          </li>
        </ul>
        <div className="tab-content">
          {/* Start Doctor Chat */}
          <div className="tab-pane active chat-sidebar-chat in active show" role="tabpanel" id="quick_sidebar_tab_1">
            <div className="chat-sidebar-list">
              <div className="chat-sidebar-chat-users slimsc-style" data-rail-color="#ddd" data-wrapper-className="chat-sidebar-list">
                <div className="chat-header">
                  <h5 className="list-heading">School Holidays List</h5>
                </div>
                <ul className="media-list list-items">
                  <li className="media"><img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof3.jpg`} width={35} height={35}  />
                    <i className="online dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Public Holiday</h5>
                      <div className="media-heading-sub">26 January 2020</div>
                    </div>
                  </li>
                  <li className="media">
                    <div className="media-status">
                      <span className="badge badge-success">5</span>
                    </div> <img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} width={35} height={35}  />
                    <i className="busy dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Holiday By School</h5>
                      <div className="media-heading-sub">18 August 2019</div>
                    </div>
                  </li>
                  <li className="media"><img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof5.jpg`} width={35} height={35}  />
                    <i className="away dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Independence Day </h5>
                      <div className="media-heading-sub">15 August 2019</div>
                    </div>
                  </li>
                  <li className="media">
                    <div className="media-status">
                      <span className="badge badge-danger">8</span>
                    </div> <img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof4.jpg`} width={35} height={35}  />
                    <i className="online dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Annual Function</h5>
                      <div className="media-heading-sub">25 February 2020</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* End Doctor Chat */}
          {/* Start Setting Panel */}
          <div className="tab-pane chat-sidebar-chat" role="tabpanel" id="quick_sidebar_tab_2">
            <div className="chat-sidebar-list">
              <div className="chat-sidebar-chat-users slimsc-style" data-rail-color="#ddd" data-wrapper-className="chat-sidebar-list">
                <div className="chat-header">
                  <h5 className="list-heading">Event List</h5>
                </div>
                <ul className="media-list list-items">
                  <li className="media"><img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof3.jpg`} width={35} height={35}  />
                    <i className="online dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Public Holiday</h5>
                      <div className="media-heading-sub">26 January 2020</div>
                    </div>
                  </li>
                  <li className="media">
                    <div className="media-status">
                      <span className="badge badge-success">5</span>
                    </div> <img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} width={35} height={35}  />
                    <i className="busy dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Holiday By School</h5>
                      <div className="media-heading-sub">18 August 2019</div>
                    </div>
                  </li>
                  <li className="media"><img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof5.jpg`} width={35} height={35}  />
                    <i className="away dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Independence Day </h5>
                      <div className="media-heading-sub">15 August 2019</div>
                    </div>
                  </li>
                  <li className="media">
                    <div className="media-status">
                      <span className="badge badge-danger">8</span>
                    </div> <img alt="SmartPSP" className="media-object" src={`${process.env.PUBLIC_URL}/assets/img/prof/prof4.jpg`}width={35} height={35}  />
                    <i className="online dot" />
                    <div className="media-body">
                      <h5 className="media-heading">Annual Function</h5>
                      <div className="media-heading-sub">25 February 2020</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* Start Setting Panel */}
          <div className="tab-pane chat-sidebar-settings" role="tabpanel" id="quick_sidebar_tab_3">
            <div className="chat-sidebar-settings-list slimsc-style">
              <div className="chat-header">
                <h5 className="list-heading">Layout Settings</h5>
              </div>
              <div className="chatpane inner-content ">
                <div className="settings-list">
                  <div className="setting-item">
                    <div className="setting-text">Sidebar Position</div>
                    <div className="setting-set">
                      <select className="sidebar-pos-option form-control input-inline input-sm input-small ">
                        <option value="left">Left</option>
                        <option value="right">Right</option>
                      </select>
                    </div>
                  </div>
                  <div className="setting-item">
                    <div className="setting-text">Header</div>
                    <div className="setting-set">
                      <select className="page-header-option form-control input-inline input-sm input-small ">
                        <option value="fixed" >Fixed</option>
                        <option value="default">Default</option>
                      </select>
                    </div>
                  </div>
                  <div className="setting-item">
                    <div className="setting-text">Footer</div>
                    <div className="setting-set">
                      <select className="page-footer-option form-control input-inline input-sm input-small ">
                        <option value="fixed">Fixed</option>
                        <option value="default" >Default</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
      )
  }
}
export default DashboardEventSidebar;