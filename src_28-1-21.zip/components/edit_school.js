import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import { Picky } from 'react-picky';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import MyImage from '../utility/my_image';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/school/read_one.php`;
// const UPDATE_URL = `http://schools.rajpsp.com/api/school/update.php`;

class EditSchool extends Component {
  state = {
    medium_opt: ["Hindi", "English"],
    id: "",
    sch_name: "",
    session_year_id: "",
    sch_reg_no: "",
    sch_recog_no: "",
    sch_contact_num: "",
    sch_mobile_num: "",
    sch_email: "",
    sch_address: "",
    sch_medium: [],
    sch_wel_mes_title: "",
    sch_wel_mes: '',
    logo_data: "",
    admin_img_data: "",
    admin_sign_data: "",
    crop: { unit: "%", width: 30, aspect: 1 },
    crop1: { unit: "%", width: 50, aspect: 1 },
    final_size: { width: 400, height: 400 },
    signature_size: { width: 300, height: 100 },
    signature_crop: { unit: "%", width: 30, aspect: 3 / 1 },
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.selected_item;
    // console.log(obj);
    // debugger;

    this.setState({
      id: obj.id,
      sch_name: obj.sch_name,
      session_year_id: obj.session_year_id,
      sch_reg_no: obj.sch_reg_no,
      sch_recog_no: obj.sch_recog_no,
      sch_contact_num: obj.sch_contact_num,
      sch_mobile_num: obj.sch_mobile_num,
      sch_email: obj.sch_email,
      sch_address: obj.sch_address,
      sch_medium: obj.sch_medium,
      sch_wel_mes_title: obj.sch_wel_mes_title,
      sch_wel_mes: obj.sch_wel_mes,
      sch_logo: obj.sch_logo,
      admin_img: obj.admin_img,
      admin_sign: obj.admin_sign,
    })
    
  }
  // setIndexHandler(school_id) {
  //   let session_year_index = '';
  //   this.props.sessionYears.map((item, index) => {
  //     if (item.id === school_id) {
  //       session_year_index = index;
  //     }
  //   })
  // }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const { match } = this.props;
  //   axios.get(READ_URL + `?id=` + match.params.id)
  //     .then(res => {
  //       const getRes = res.data.responceData;
  //       if (getRes) {
  //         this.setState({
  //           school_info: getRes
  //         });
  //       } else {
  //         Alert.error(res.data.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //       }
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  setMediumHandler = (value) => {
    //console.count('onChange')
    this.setState({
      sch_medium: value
    })
  }
  // child (my_image.js) component to get image
  onCompleteLogo = (data) => {
    this.setState({
      sch_logo: data
    })
  }
  // child (my_image.js) component to get image
  onCompleteAadminImage = (data) => {
    this.setState({
      admin_img: data
    })
  }
  // child (my_image.js) component to get image
  onCompleteAdminSignature = (data) => {
    this.setState({
      admin_sign: data
    })
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    const obj = {
      id: this.state.id,
      sch_name: this.state.sch_name,
      session_year_id: this.state.session_year_id,
      sch_reg_no: this.state.sch_reg_no,
      sch_recog_no: this.state.sch_recog_no,
      sch_contact_num: this.state.sch_contact_num,
      sch_mobile_num: this.state.sch_mobile_num,
      sch_email: this.state.sch_email,
      sch_address: this.state.sch_address,
      sch_medium: this.state.sch_medium,
      sch_wel_mes_title: this.state.sch_wel_mes_title,
      sch_wel_mes: this.state.sch_wel_mes,
      sch_logo: this.state.sch_logo,
      admin_img: this.state.admin_img,
      admin_sign: this.state.admin_sign,
    }
    // console.log(JSON.stringify(obj))
    
    this.props.updateHandlar(obj);
    // axios.post(UPDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }

  render() {
    const {
      id, medium_opt, sch_name, session_year_id, sch_reg_no, sch_recog_no, sch_contact_num, sch_mobile_num,
      sch_email, sch_address, sch_medium, sch_wel_mes_title, sch_wel_mes, logo_data, admin_img_data,
      admin_sign_data, crop, crop1, final_size, sch_logo, admin_img, admin_sign,
      signature_crop, signature_size, formIsHalfFilledOut } = this.state;
    const { user, schools, selected_item, sessionYears } = this.props;
    console.log(this.props)
    return (
      <div className="page-content">
        <Helmet>
          <title>Update School Biography</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && selected_item && sessionYears &&
          <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">
              Update School Biography
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Name
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_name" placeholder="school name"
                        className="form-control form-control-sm"
                        value={sch_name}
                        onChange={event => this.changeHandler(event, `sch_name`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Registratin Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_reg_no"
                        placeholder="" className="form-control form-control-sm"
                        value={sch_reg_no}
                        onChange={event => this.changeHandler(event, `sch_reg_no`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Recognition Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_recog_no"
                        placeholder="" className="form-control form-control-sm"
                        value={sch_recog_no}
                        onChange={event => this.changeHandler(event, `sch_recog_no`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Session Year
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        value={session_year_id}
                        onChange={event => this.changeHandler(event, 'session_year_id')}>
                        <option >Select ...</option>
                        {sessionYears.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.ses_year}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Email Address</label>
                    <div className="form-input">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-envelope" /></span>
                        </div>
                        <input type="email" className="form-control form-control-sm"
                          name="sch_email" placeholder="Email Address"
                          value={sch_email}
                          onChange={event => this.changeHandler(event, `sch_email`)} /> </div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Landline Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_contact_num"
                        placeholder="enter  no" className="form-control form-control-sm"
                        value={sch_contact_num}
                        onChange={event => this.changeHandler(event, `sch_contact_num`)} /> </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Mobile No.
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_mobile_num"
                        placeholder="mobile number" className="form-control form-control-sm"
                        value={sch_mobile_num}
                        onChange={event => this.changeHandler(event, `sch_mobile_num`)} /> </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Medium
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <Picky
                        value={(sch_medium) ? sch_medium : []}
                        options={medium_opt}
                        onChange={this.setMediumHandler}
                        open={false}
                        valueKey="id"
                        labelKey="name"
                        multiple={true}
                        includeSelectAll={true}
                        includeFilter={true}
                        dropdownHeight={200}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Address
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_mobile_num"
                        placeholder="address" className="form-control form-control-sm"
                        value={sch_address}
                        onChange={event => this.changeHandler(event, `sch_address`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Logo</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteLogo}
                        crop={crop1}
                        final_size={final_size}
                      />
                      {sch_logo !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail"
                          src={`${process.env.PUBLIC_URL}` + sch_logo} />
                        : null}
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Admin Image</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteAadminImage}
                        crop={crop}
                        final_size={final_size}
                      />
                      {admin_img !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail"
                          src={`${process.env.PUBLIC_URL}` + admin_img} />
                        : null}
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Admin Signature</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteAdminSignature}
                        crop={signature_crop}
                        final_size={signature_size}
                      />
                      {admin_sign !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail"
                          src={`${process.env.PUBLIC_URL}` + admin_sign} />
                        : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer  text-right">
              <button type="submit" className="btn btn-primary mr-2">Update</button>
              {/* <NavLink to="/all_schools.jsp" className="btn btn-danger">Back</NavLink> */}
              <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
              Exit </button>
            </div>
          </form>
        }
      </div>
    )
  }
}
export default withRouter(EditSchool);