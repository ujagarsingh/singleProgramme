import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
//import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class Mission extends Component {
  render() {
    return (
      <div className="mt-5 mb-2">
        <div className="container">
          <div className="row">
            <div className="col-sm-8">
              <h1>Mission</h1>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque.
                Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum interdum diam
                non mi cursus venenatis. Morbi lacinia libero et elementum vulputate. Vivamus et
                facilisis mauris. Maecenas nec massa auctor, ultricies massa eu, tristique erat.
                 Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Eu pellentesque,
                  accumsan tellus leo, ultrices mi dui lectus sem nulla eu.Eu pellentesque, accumsan
              tellus leo, ultrices mi dui</p>
            </div>
            <div className="col-sm-4">

              <div className="sidebar-text-post">
                <div className="row">
                  <div className="col-sm-12">
                    <h3>Next Events</h3>
                    <div className="categories-item-post">
                      <ul className="list-unstyled">
                        <li><NavLink to="/"><i className="fa fa-angle-right" />USA <span>(23)</span></NavLink></li>
                        <li><NavLink to="/"><i className="fa fa-angle-right" />Norway<span>(23)</span></NavLink></li>
                        <li><NavLink to="/"><i className="fa fa-angle-right" />Russia<span>(23)</span></NavLink></li>
                        <li><NavLink to="/"><i className="fa fa-angle-right" />London<span>(23)</span></NavLink></li>
                        <li><NavLink to="/"><i className="fa fa-angle-right" />Australia <span>(23)</span></NavLink></li>
                        <li><NavLink to="/"><i className="fa fa-angle-right" />Singapur <span>(23)</span></NavLink></li>
                      </ul>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(Mission);