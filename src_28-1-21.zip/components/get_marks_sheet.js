import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
//import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
//import { HOST_URL } from '../includes/api-config';
import { Picky } from 'react-picky';
import { Helmet } from "react-helmet";
import SingleReportCard from '../includes/single_report_card'
import { connect } from 'react-redux';
import {
  schoolsAction, classesAction, examsAction, examsTypeAction,
  examCategoryClassExamAction, marksOfaClassAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_EXAMS = `http://schools.rajpsp.com/api/exam/read.php`;
// const READ_EXAM_CAT = `http://schools.rajpsp.com/api/exam_type/read.php`;
// const READ_CLASS_EXAM_DETAIL_URL = `http://schools.rajpsp.com/api/exam/one_class_category_exams.php`;
// const READ_SCHOOL_URL = `http://schools.rajpsp.com/api/school/read.php`; 
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
// const ONE_CLASS_ALL_MARKS = `http://schools.rajpsp.com/api/exam/one_class_all_marks.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;   

class GetMarksSheet extends Component {
  state = {
    exam_category_arr: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    sch_name: '',
    sch_address: '',
    classes: [],
    selected_classes: [],
    selected_class_inx: '',
    exams: [],
    display_exams: [],
    selected_exam: [],
    exam_detail: '',
    updated_exam_detail: {},
    class_id: '',
    selected_sheet_type: '',
    sheet_type: [{ 'name': 'Marksheet' }, { 'name': 'Information' }],
    selected_class: '',
    medium: '',
    stu_marks_obtain_detail: '', //student marks obtain detail
    updated_students: { 'student': [{ 'exams': [] }] }, // with selected exams 
    generate_report_card: false,
    update_reportCard_data: false,
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   // const _inx = event.target.value;
    //   // const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   // const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   // sessionStorage.setItem("school_id", _sch_id);
    //   // this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
    //   // this.filterSchoolOnSchool(_sch_id);
    //   // this.setState({
    //   //   school_id: _sch_id,
    //   //   medium_arr: _medium,
    //   //   medium: (_medium.length === 1 ? _medium[0] : ''),
    //   //   selected_school_index: _inx,
    //   //   selected_class_inx: '',
    //   //   updated_students: { 'student': [{ 'exams': [] }] }
    //   // })
    // } else if (fieldName === 'selected_class') {
    //   // const _class_inx = event.target.value;
    //   // const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
    //   // sessionStorage.setItem("class_name_portal", _class_name);
    //   // this.classHandler(_class_inx);
    // } else
    
    if (fieldName === 'selected_sheet_type') {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true,
        generate_report_card: false,
        update_reportCard_data: false,
      });
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      //this.filterClassesOnSchool(_medium);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      });
    }
  };

  // filterSchoolOnSchool(sch_id) {
  //   const _school = this.props.schools.filter((item) => {
  //     if (item.id === sch_id) {
  //       return item
  //     }
  //   })
  //   /*
  //   id: "4"
  //   sch_name: "Jyoti Public Senior Sec. School"
  //   sch_reg_no: "199/195-96"
  //   sch_recog_no: "150/2015-16"
  //   sch_contact_num: "8829050400"
  //   sch_mobile_num: "7978424990"
  //   sch_email: "rajpratik75@gmail.com"
  //   sch_address: "VPO - Andhi, TEH. - Jamwaramgarh, Andhi"
  //   sch_medium: ["English"]
  //   sch_logo: "/assets/images/school/6EMNROVHE1F3.png"
  //   admin_sign: "/assets/images/school/OJCXR_TOPRZU.png"
  //   admin_img: "/assets/images/school/3WKACML92E8P.png"
  //   session_year_id: "2019-2020"
  //    */
  //   this.setState({
  //     sch_name: _school[0].sch_name,
  //     sch_address: _school[0].sch_address
  //   })
  // }
  // filterClassesOnSchool(sch_id, group_id) {
  //   const _classes = this.props.classes.filter((item) => {
  //     if (item.group_id === group_id && item.school_id === sch_id) {
  //       return item
  //     }
  //   })
  //   this.setState({
  //     selected_classes: _classes,
  //     selected_class_inx: 'All'
  //   })
  // }
  classHandler() {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;

    if (_fltr_class.slct_cls_id !== '') {
      // const _class_inx = parseInt(_classIdx);
      // const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
      // const group_id = this.props.user.group_id;
      const school_id = _fltr_school.slct_school_id;
      const _class_id = _fltr_class.slct_cls_id;
      // debugger
      const _exams = this.props.exams.filter((item, inx) => {
        if (item.school_id === school_id && item.class_id === _class_id) {
          return item
        }
      })
      const _exams_arr = _exams.map((item, inx) => {
        return item.exam_name
      })

      this.setState({
        generate_report_card: false,
        update_reportCard_data: false,
        display_exams: _exams_arr,
        stu_marks_obtain_detail: '',
        class_id: _class_id,
        selected_sheet_type : '',
        selected_exam: [],
      }, () => {
        this.getStudentofClass(_class_id);
      })
    } else {
      this.setState({
        stu_marks_obtain_detail: ''
      })
    }
  }

  getStudentofClass(class_id) {
    const classData = this.props.examCategoryClassExam.filter((item) => {
      if (item.class_id === class_id) {
        return item
      }
    })
    this.setState({
      exam_detail: classData[0].exam_cate
    });

    let obj = { class_id: class_id };
    console.log(JSON.stringify(obj))
    this.props.getMarksOfaClass(obj);
  }

  componentWillReceiveProps(nextProps) {
    // invoke function with updated store
    // console.log(this.props); // prevProps
    // console.log(nextProps); // currentProps after updating the store
    if (nextProps.marksOfaClass) {
      const resData = nextProps.marksOfaClass;
      this.setState({
        stu_marks_obtain_detail: resData,
        updated_students: resData,
      });
    }
  }


  // getStudentofClass_(class_id) {

  //   loadProgressBar();

  //   // axios.post(ONE_CLASS_ALL_MARKS, obj)
  //   //   .then(res => {
  //   //     //debugger
  //   //     const students = res.data;
  //   //     //console.log(students);
  //   //     this.setState({
  //   //       stu_marks_obtain_detail: students,
  //   //       updated_students: students,
  //   //       //selected_class: students.class_name_portal,
  //   //       errorMessages: res.data.message
  //   //     }, () => {
  //   //       // loadProgressBar();
  //   //       // //debugger
  //   //       // const obj = {
  //   //       //   group_id: this.state.group_id,
  //   //       //   school_id: this.state.school_id,
  //   //       //   class_id: this.state.class_id,
  //   //       //   medium: this.state.medium,
  //   //       // }
  //   //       // // console.log(JSON.stringify(obj))
  //   //       // axios.post(READ_CLASS_EXAM_DETAIL_URL, obj)
  //   //       //   .then(res => {
  //   //       //     const examDetail = res.data;
  //   //       //     this.setState({
  //   //       //       exam_detail: examDetail,
  //   //       //       errorMessages: res.data.message
  //   //       //     });
  //   //       //   })
  //   //       //   .catch((error) => {
  //   //       //     // error
  //   //       //   });
  //   //     });
  //   //     ////console.log(JSON.stringify(this.state.stu_marks_obtain_detail));
  //   //   })
  //   //   .catch((error) => {
  //   //     // error
  //   //   });
  // }

  updateRecords() {
    // class info update start
    let _classObj = this.state.stu_marks_obtain_detail;
    var _selectedExams = this.state.selected_exam; //['First Test', 'Second Test'];

    let _new_studentData = _classObj.student.map((el_student, inx) => {

      let _new_examTypeData = el_student.exam_type.map((el_examType, iex) => {

        let _new_subjects = el_examType.subjects.map((el_subject, idv) => {

          let _filteredExamCat = el_subject.exams_cat.filter((el_examCat, idx) => {
            var _abc = null;
            // for only who exam marks we want to shwo in information sheet.
            _selectedExams.filter((element) => {
              if (el_examCat.exam_name === element) {
                _abc = el_examCat;
              }
            })
            return _abc;
          });
          const filteredExam = { ...el_subject, 'exams_cat': _filteredExamCat };
          return filteredExam;

        })

        const sub_record = { ...el_examType, 'subjects': _new_subjects };
        // sub_record['id'] = el_examType.id;
        // sub_record['sub_lavel'] = el_examType.sub_lavel;
        // sub_record['sub_name'] = el_examType.sub_name;
        // sub_record['exam_cat_id'] = el_examType.exam_cat_id;
        // sub_record['t_mm'] = el_examType.t_mm;
        // sub_record['t_mo'] = el_examType.t_mo;
        // sub_record['exams'] = _new_subjects;

        return sub_record;
      });

      const student_record = { ...el_student, 'exam_type': _new_examTypeData };

      return student_record;
    });
    const _update_class = { ..._classObj, 'student': _new_studentData };

    // class info update end
    // exam info update start
    let _exam_info = this.state.exam_detail;

    let _new_subjects_title = _exam_info.exams.map((el_subject, idv) => {

      let _filteredExamCat = el_subject.exams.filter((el_examCat, idx) => {
        var _abc = null;
        // for only who exam marks we want to shwo in information sheet.
        _selectedExams.filter((element) => {
          if (el_examCat.exam_name === element) {
            _abc = el_examCat;
          }
        })
        return _abc;
      });
      const filteredExam = { ...el_subject, exams: _filteredExamCat };
      return filteredExam;

    })

    const _update_exam = { ..._exam_info, 'exams': _new_subjects_title };
    // exam info update end
    this.setState({
      updated_students: _update_class,
      updated_exam_detail: _update_exam,
      update_reportCard_data: true
    }, () => {
      // this.updateReoprtEveryStudent(_update_class);
    })
  }

  showReportCard() {
    // show Report Card
    const _flag = this.state.generate_report_card;
    let divToPrint = document.getElementsByClassName('page-wrapper');
    if (!_flag) {
      divToPrint[0].classList.add('print');
    } else {
      divToPrint[0].classList.remove('print');
    }
    this.setState({
      generate_report_card: !this.state.generate_report_card,
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.exams)) {
      this.props.getExams();
    }
    if (isEmptyObj(this.props.examsType)) {
      this.props.getExamsType();
    }
    if (isEmptyObj(this.props.examCategoryClassExam)) {
      this.props.getExamCategoryClassExam();
    }
    // if (isEmptyObj(this.props.marksOfaClass)) {
    //   this.props.getMarksOfaClass();
    // }
    // this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      if (_all_student && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
        updated_students: { 'student': [{ 'exams': [] }] }
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    // const _fltr_school = this.props.filteredSchoolData;
    // const _fltr_class = this.props.filteredClassesData;
    // const _all_student = this.props.students;
    // if (_all_student) {
    //   const _school_student = _all_student.filter((item) => {
    //     if (!isEmpty(_fltr_class.slct_cls_name)) {
    //       if (item.school_id === _fltr_school.slct_school_id &&
    //         item.stu_class === _fltr_class.slct_cls_name) {
    //         return item
    //       }
    //     } else {
    //       if (item.school_id === _fltr_school.slct_school_id) {
    //         return item
    //       }
    //     }
    //   })
    //   this.setState({
    //     display_student: _school_student
    //   })
    // }
    this.classHandler()
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getExamxHandler();
  //           this.getClassesHandler();
  //           this.getExamTypeHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  /*
  getClassesHandler() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
    }
    // console.log(JSON.stringify(obj));
    // debugger
    axios.post(READ_SCHOOL_URL, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          selected_classes: getRes,
          all_classes: getRes,
          errorMessages: getRes.message
        });
        ////console.log(this.state.selected_classes);
      }).catch((error) => {
        // error
      })
  }*/
  // getClassesHandler() {
  //   // read all existing class
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const resData = res.data;
  //       const _classes = resData.filter((item, index) => {
  //         if (item.is_section !== 'Yes') {
  //           return item;
  //         }
  //       })
  //       this.setState({
  //         classes: _classes,
  //         errorMessages: resData.message
  //       });
  //       //console.log(this.state.classes);
  //     }).then(res => {
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // }
  // getExamxHandler() {
  //   axios.get(GET_EXAMS)
  //     .then(res => {
  //       //debugger
  //       const resData = res.data;
  //       if (resData.message !== undefined) {
  //         Alert.error(resData.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //       } else {
  //         this.setState({
  //           exams: resData
  //         });
  //       }
  //       //console.log(this.state.exams);
  //     }).then(res => {
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  //   // read school info
  // }
  // getExamTypeHandler() {
  //   loadProgressBar();
  //   // console.log(JSON.stringify(obj));
  //   axios.get(READ_EXAM_CAT)
  //     .then(res => {
  //       const resData = res.data;
  //       this.setState({
  //         exam_category_arr: resData,
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };
  updateReoprtEveryStudent(classData) {
    const allStudent = classData.student;
    const _after_report_classDat = { ...classData, allStudent }
    this.setState({
      updated_students: _after_report_classDat
    })
  }

  selectExamHandler = (value) => {
    // console.count('onChange');
    this.setState({
      selected_exam: value, //july, august
      generate_report_card: false,
      update_reportCard_data: false,
    });
  }
  printHandler(e) {
    window.print()
    var divToPrint = document.getElementsByClassName('page-wrapper');
    divToPrint[0].classList.remove('print');
    this.setState({
      generate_report_card: false,
      update_reportCard_data: false,
    });
  }
  render() {
    const { user, schools, exams, examsType } = this.props;
    const { medium, selected_classes, selected_class, selected_exam, display_exams, selected_sheet_type,
      sheet_type, update_reportCard_data, generate_report_card, selected_class_inx,
      selected_school_index, medium_arr, exam_category_arr,
      updated_students, updated_exam_detail, sch_address, sch_name, formIsHalfFilledOut } = this.state;
    console.log(this.state);
    return (
      <div id="printarea_1" className="page-content">
        <Helmet>
          <title>Get Report Card</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div id="printarea" className="page-bar d-flex">
          <div className="page-title">Get Report Card</div>
          {user && schools && exams && examsType &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div>
                {selected_classes.length > 0 ?
                  <div className="form-group mr-2 mt-1">
                    <label className="mr-2">Class:</label>
                    <select
                      value={selected_class_inx}
                      disabled={medium === '' ? true : false}
                      className="form-control form-control-sm" name="selected_class"
                      onChange={event => this.changeHandler(event, 'selected_class')} >
                      <option value="All">Select...</option>
                      {selected_classes.map((option, index) => {
                        return (<option key={index} value={index}>{option.class_name}</option>)
                      })}
                    </select>
                  </div>
                  : null} */}

                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />

                <div className="form-group mr-2 mt-1">
                  <label className="mr-2">Exam:</label>
                  <div className="d-flex" style={{ minWidth: '200px' }}>
                    <Picky
                      className="input-sm"
                      value={selected_exam}
                      // disabled={medium === '' ? true : false}
                      options={display_exams}
                      onChange={this.selectExamHandler}
                      open={false}
                      valueKey="id"
                      labelKey="name"
                      multiple={true}
                      includeSelectAll={true}
                      //includeFilter={true}
                      dropdownHeight={200}
                    />
                  </div>
                </div>
                {(selected_exam !== '') ?
                  <div className="form-group mr-2 mt-1">
                    <label className="mr-2">Type:</label>
                    <select
                      value={selected_sheet_type}
                      // disabled={medium === '' ? true : false}
                      className="form-control form-control-sm"
                      onChange={event => this.changeHandler(event, 'selected_sheet_type')} >
                      <option value="">Select...</option>
                      {sheet_type.map((option, index) => {
                        return (<option key={index} >{option.name}</option>)
                      })}
                    </select>
                  </div>
                  : null}
                <div className="form-group mt-1">
                  <button className="btn btn-secondary btn-sm mr-1"
                    disabled={(selected_sheet_type !== '') ? false : true}
                    onClick={event => this.updateRecords(event)}>
                    Generate
                </button>
                  <button className={"btn btn-sm " + `${(!generate_report_card ? "btn-primary" : "btn-danger")}`}
                    disabled={!update_reportCard_data}
                    onClick={event => this.showReportCard(event)}>
                    {!generate_report_card ? "Show" : "Hide"}
                  </button>
                </div>
              </div>
            </div>
          }
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body">
            <div className="table-scrollable" >
              <div className="container-fluid">
                <div className="row-print">
                  {(generate_report_card) ? updated_students.student.map((item, index) => {
                    return (
                      <div key={index} className={(selected_sheet_type === 'Marksheet') ? 'col-sm-12-print print-mark with-bg' :
                        (selected_exam.length === '1') ? 'col-sm-4-print print-mark' :
                          (selected_exam.length === 2) ? 'col-sm-6-print print-mark' : 'col-sm-12-print print-mark'}>
                        <SingleReportCard
                          key={index}
                          stu_class={selected_class}
                          exam_category_arr={exam_category_arr}
                          selected_sheet_type={selected_sheet_type}
                          sch_name={sch_name}
                          sch_address={sch_address}
                          updated_exam_detail={updated_exam_detail}
                          selected_exam={selected_exam}
                          index={index}
                          item={item}
                        />
                      </div>

                    )
                  }) : null}
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer print-btn text-right">
            <button className="btn btn-danger"
              onClick={event => this.printHandler(event)}
              type="button"> <span><i className="fa fa-print" /> Print</span> </button>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: exams } = state.exams;
  const { item: examsType } = state.examsType;
  const { item: examCategoryClassExam } = state.examCategoryClassExam;
  const { item: marksOfaClass } = state.marksOfaClass;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, classes, exams, examsType, marksOfaClass, examCategoryClassExam,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getExams: examsAction.getExams,
  getExamsType: examsTypeAction.getExamsType,
  getExamCategoryClassExam: examCategoryClassExamAction.getExamCategoryClassExam,
  getMarksOfaClass: marksOfaClassAction.getMarksOfaClass
}
export default connect(mapStateToProps, actionCreators)(withRouter(GetMarksSheet));