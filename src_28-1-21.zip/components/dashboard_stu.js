import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
//import { NavLink } from 'react-router-dom';
import { Chart } from 'react-google-charts';
import axios from 'axios';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

const READ_COUNTER = `http://schools.rajpsp.com/api/dashboard/read_counter.php`;

class DashboardStu extends Component {
  state = {
    total_student: '',
    total_emp: '',
    total_income: '',
    total_paryment: '',
    chart_title: [['Months', 'Income', 'Expenses', 'Profit']],
    chart_data: [
      ['Apr', 15000, 10540, 350],
      ['May', 25000, 52040, 350],
      ['Jun', 12450, 20540, 350],
      ['Jul', 46542, 55040, 350],
      ['Aug', 32165, 54000, 350],
      ['Sep', 8452, 45540, 350],
      ['Oct', 32112, 15540, 350],
      ['Nov', 120004, 15540, 350],
      ['Dec', 125004, 52540, 350],
      ['Jan', 1000, 42400, 200],
      ['Feb', 1170, 4560, 250],
      ['Mar', 660, 11820, 300],
    ],
    final_chart_data: [],
	formIsHalfFilledOut: false,
  }
  componentDidMount() {
    const _final_data = this.state.chart_title.concat(this.state.chart_data);
    this.setState({
      final_chart_data: _final_data,
		formIsHalfFilledOut: true
    })
    axios.get(READ_COUNTER)
      .then(res => {
        const resDate = res.data;
        this.setState({
          total_student: resDate.total_student,
          total_emp: resDate.total_emp,
          total_income: this.currencyFormate(resDate.total_income),
          total_paryment: this.currencyFormate(resDate.tatal_expenses)
        });
      }).catch((error) => {
        // error
      });
  };
  currencyFormate(amo) {
    amo = amo.toString();
    var lastThree = amo.substring(amo.length - 3);
    var otherNumbers = amo.substring(0, amo.length - 3);
    if (otherNumbers !== '')
      lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
    return res;
  }
  render() {
    const _state = this.state;
    //console.log(_state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Dashboard Student</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
              <div className="page-title">Dashboard Student</div>
            </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body">
            <div className="table-scrollable">
              <div className="col">
                {/* start widget */}
                <div className="state-overview">
                  <div className="row">
                    <div className="col-xl-3 col-md-6 col-12">
                      <div className="info-box bg-success">
                        <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-graduate"></i></span>
                        <div className="info-box-content">
                          <span className="info-box-text">Students</span>
                          <span className="info-box-number">{_state.total_student}</span>
                        </div>
                        {/* /.info-box-content */}
                      </div>
                      {/* /.info-box */}
                    </div>
                    {/* /.col */}
                    <div className="col-xl-3 col-md-6 col-12">
                      <div className="info-box bg-warning">
                        <span className="info-box-icon m-0 push-bottom"><i className="fas fa-user-tie"></i></span>
                        <div className="info-box-content">
                          <span className="info-box-text">Employee</span>
                          <span className="info-box-number">{_state.total_emp}</span>
                        </div>
                        {/* /.info-box-content */}
                      </div>
                      {/* /.info-box */}
                    </div>
                    {/* /.col */}
                    <div className="col-xl-3 col-md-6 col-12">
                      <div className="info-box bg-primary">
                        <span className="info-box-icon m-0 push-bottom"><i className="fas fa-seedling"></i></span>
                        <div className="info-box-content">
                          <span className="info-box-text">Income</span>
                          <span className="info-box-number">{_state.total_income}</span><span><i className="ml-1 fas fa-rupee-sign"></i></span>
                        </div>
                        {/* /.info-box-content */}
                      </div>
                      {/* /.info-box */}
                    </div>
                    {/* /.col */}
                    <div className="col-xl-3 col-md-6 col-12">
                      <div className="info-box bg-danger">
                        <span className="info-box-icon m-0 push-bottom"><i className="fab fa-gripfire"></i></span>
                        <div className="info-box-content">
                          <span className="info-box-text">Expenses</span>
                          <span className="info-box-number">{_state.total_paryment}</span><span><i className="ml-1 fas fa-rupee-sign"></i></span>
                        </div>
                        {/* /.info-box-content */}
                      </div>
                      {/* /.info-box */}
                    </div>
                    {/* /.col */}
                  </div>
                </div>
                {/* end widget */}
                {/* chart start */}
                <div className="row">
                  <div className="col-sm-8">
                    <div className="card card-box sfpage-cover">
                      <div className="card-head d-flex">
                        <header>Fees Collection</header>
                      </div>
                      <div className="card-body p-0">
                        <Chart
                          //width={'500px'}
                          height={'300px'}
                          chartType="Bar"
                          loader={<div>Loading Chart</div>}
                          data={_state.final_chart_data}
                          options={{
                            // Material design options
                            chart: {
                              legend: { position: 'bottom', alignment: 'middle' },
                              chartArea: { width: '100%' },
                              //title: 'Company Performance',
                              subtitle: 'Income, Expenses, and Profit: 2019-2020',
                              hAxis: {
                                  title: 'Total Population',
                                  minValue: 0,
                              },
                              vAxis: {
                                  title: 'City',
                              },
                            },
                          }}
                          // For tests
                          rootProps={{ 'data-testid': '2' }}
                        />
                      </div>
                    </div>
                  </div>
                  {/*
						<!-- Quick Mail start */}
                  <div className="col-lg-4 col-md-12 col-sm-12 col-12">
                    <div className="card-box card">
                      <div className="card-head d-flex">
                        <header>Quick Message</header>
                      </div>
                      <div className="card-body">
                        <div className="compose-mail">
                          <form method="post">
                            <div className="form-group mt-1">
                              <label htmlFor="to" className="">To:</label>
                              <input type="text" className="form-control form-control-sm" />
                            </div>
                            <div className="form-group mt-1">
                              <label htmlFor="to" className="">Group:</label>
                              <select className="form-control form-control-sm">
                                <option>Select...</option>
                                <option>Students</option>
                                <option>Staff</option>
                              </select>
                            </div>
                            <div className="form-group m-b-10">
                              <label htmlFor="subject" className="">Message:</label>
                              <textarea className="form-control form-control-sm" defaultValue={""} />
                            </div>
                            <div className="box-footer clearfix">
                              <button type="button" className="btn btn-primary btn-sm">Send
                            <i className="fa fa-paper-plane-o" /></button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Chart end *}
                <div className="row">
                  <div className="col-md-12 col-sm-12">
                    <div className="card  card-box">
                      <div className="card-head d-flex">
                        <header>New Student List</header>
                      </div>
                      <div className="card-body sfpage-body">
                        <div className="table-wrap">
                          <div className="table-responsive">
                            <table className="table display table-sm product-overview mb-30">
                              <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Name</th>
                                  <th>Assigned Professor</th>
                                  <th>Date Of Admit</th>
                                  <th>Fees</th>
                                  <th>Branch</th>
                                  <th>Edit</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>1</td>
                                  <td>Jens Brincker</td>
                                  <td>Kenny Josh</td>
                                  <td>27/05/2016</td>
                                  <td>
                                    <span className="label label-sm label-success">paid</span>
                                  </td>
                                  <td>Mechanical</td>
                                  <td><NavLink to="javascript:void(0)" className="" data-toggle="tooltip" title="Edit"><i className="fa fa-check" /></NavLink>
                                    <NavLink to="javascript:void(0)" className="text-inverse" title="Delete" data-toggle="tooltip"><i className="fa fa-trash" /></NavLink></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* end new student list */}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(DashboardStu);