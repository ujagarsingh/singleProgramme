import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, accLedgerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const CREATE_GALLERY = `http://schools.rajpsp.com/api/galleries/gallery/create.php`;

class AddAccLedger extends Component {
  state = ({
    school_id: '',
    ledger_name: "",
    acc_group_id: "",
    op_balance: "",
    op_balance_type: "",
    formIsHalfFilledOut: false,
  })
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      // this.filterClassesOnSchool(_sch_id, this.props.user.acc_group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.state.school_id }
    }
    const form_obj = {
      ledger_name: this.state.ledger_name,
      acc_group_id: this.state.acc_group_id,
      op_balance: this.state.op_balance,
      op_balance_type: this.state.op_balance_type,
    }
    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));
    this.props.createAccLedger(obj);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.accLedger) {
      this.setState({
        ledger_name: '',
        formIsHalfFilledOut: false
      })
    }
  }
  render() {
    const { selected_school_index, acc_group_id, op_balance, op_balance_type, formIsHalfFilledOut, ledger_name } = this.state;
    const { user, schools, accGroup } = this.props;
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Ledger</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Ledger
          </div>
          <div className="card-body">
            {user && schools &&
              <div className="row">
                {(user.user_category === "1") &&
                  <div className="col-sm-2">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }
                <div className="col-sm-4">
                  <div className="form-group">
                    <label className="control-label">Ledger Name
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="ledger_name" placeholder="Ledger Name"
                        className="form-control form-control-sm"
                        required
                        value={ledger_name}
                        onChange={event => this.changeHandler(event, 'ledger_name')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Under </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='acc_group_id'
                        value={acc_group_id}
                        onChange={event => this.changeHandler(event, 'acc_group_id')}
                      >
                        <option value="">Select ...</option>
                        {accGroup.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.group_name}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Opening Balance
                    </label>
                    <div className="form-input">
                      <input type="number" ref="op_balance" placeholder="Opening Balance"
                        className="form-control form-control-sm"
                        value={op_balance}
                        onChange={event => this.changeHandler(event, 'op_balance')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Balance Type</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='op_balance_type'
                        defaultValue={op_balance_type}
                        onChange={event => this.changeHandler(event, 'op_balance_type')}>
                        <option value="">Select...</option>
                        <option value="CR">CR</option>
                        <option value="DR">DR</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
          <div className="card-footer d-flex">
            <span className="text-danger p-2">CR : Liability, DR : Assets</span>
            <button type="submit"
              className="btn btn-secondary  mr-2 ml-auto">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  return { user, schools };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  createAccLedger: accLedgerActions.createAccLedger,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddAccLedger));
