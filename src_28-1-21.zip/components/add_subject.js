import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, examsTypeAction, subjectsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const CREATE_SUBJECT = `http://schools.rajpsp.com/api/subject/create.php`;
// const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_subjects_of_class.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`; 
// const READ_URL = `http://schools.rajpsp.com/api/subject/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_type/read.php`;  

class AddSubject extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    sft_classes: [],
    selected_classes: [],
    class_id: '',
    medium: '',
    sub_lavel: [{ sub_lavel: 1 }, { sub_lavel: 2 }],
    sub_lavel_1: [{ sub_lavel: 1 }],
    existsubject: [{ sub_name: "", sub_lavel: 1, exam_cat: 1 }],
    subjects_obj: [{ sub_name: "", sub_lavel: 1, exam_cat: 1, sub_p: [] }],
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      const _classes = this.props.classes.filter((item, inx) => {
        if (item.medium === _medium) {
          return item
        }
      })
      this.setState({
        selected_classes: _classes
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      //selected_subjects: ''
    })
  }
  handleSubNameHandler = (event, index) => {
    const _str = event.target.value;
    const _lastChar = _str.charAt(_str.length - 1);
    if (_lastChar === '(' || _lastChar === ')') {
      confirmAlert({
        title: 'stay one moment!',
        message: 'Please cannot use "(" or ")" character there!!.',
        buttons: [
          {
            label: 'Yes',
            onClick: () => {
              return false;
            }
          },
          {
            label: 'No',
          }
        ]
      });
    } else {
      const _newItem = this.state.subjects_obj.map((item, sidx) => {
        if (index !== sidx) return item;
        return { ...item, sub_name: event.target.value };
      });
      this.setState({ subjects_obj: _newItem });
    }
  };
  handleSubLavelHandler = (event, index) => {
    event.preventDefault();
    const _sub_lavel = (event.target.value === "Faculty" ? 2 : 1);
    const _newItem = this.state.subjects_obj.map((item, sidx) => {
      if (index !== sidx) return item;
      if (_sub_lavel === 2) {
        return {
          ...item,
          sub_lavel: _sub_lavel,
          sub_p: [{ sub_name_1: "", sub_lavel_1: 11, exam_cat_1: 1, sub_p_1: [] }]
        };
      } else {
        return {
          ...item,
          sub_lavel: _sub_lavel,
          sub_p: []
        };
      }
    });
    this.setState({ subjects_obj: _newItem });
  };
  handleExamTypeHandler = (event, index) => {
    debugger;
    event.preventDefault();
    const _exam_cat = (event.target.value === "Effective" ? 1 : 2);
    const _newItem = this.state.subjects_obj.map((item, sidx) => {
      if (index !== sidx) {
        return item;
      } else {
        return {
          ...item,
          exam_cat: _exam_cat
        };
      }
    });
    this.setState({ subjects_obj: _newItem });
  }
  handleAddSubject = (event, index) => {
    this.setState({
      subjects_obj: this.state.subjects_obj.concat([{ sub_name: "", sub_lavel: 1, exam_cat: 1, sub_p: [] }])
    });
  };
  handleRemoveSubject = (event, index) => {
    if (this.state.subjects_obj.length > 1) {
      this.setState({
        subjects_obj: this.state.subjects_obj.filter((s, sidx) => index !== sidx)
      })
    }
  };



  /** */
  handleSubNameHandler_1 = (event, index) => {
    let _subject = this.state.subjects_obj;
    const _p_index = event.target.getAttribute('data-parent-index');
    const _new_subjects = _subject.map((item, pidx) => {
      if (eval(_p_index) !== pidx) {
        return item
      } else {
        const _new_item = { ...item }
        const _new_sub_Item = item.sub_p.map((item_s, sidx) => {
          if (index !== sidx) return item_s;
          return { ...item_s, sub_name_1: event.target.value };
        });
        _new_item.sub_p = _new_sub_Item;
        return _new_item;
      }
    })
    this.setState({ subjects_obj: _new_subjects });
  };

  handleSubLavelHandler_1 = (event, index) => {
    const _newItem = this.state.subjects_obj.map((item, sidx) => {
      if (index !== sidx) return item;
      if (event.target.value === 2) {
        return {
          ...item,
          sub_lavel: event.target.value,
          sub_p: [{ sub_name_1: "", sub_lavel_1: 11, exam_cat: 1, sub_p_1: [] }]
        };
      } else {
        return {
          ...item,
          sub_lavel: event.target.value,
          sub_p: []
        };
      }
    });
    this.setState({ subjects_obj: _newItem });
  };
  handleAddSubject_1 = (event, index) => {
    event.preventDefault();
    let _subject = this.state.subjects_obj;
    const _p_index = event.target.getAttribute('data-parent-index');
    const _new_subjects = _subject.map((item, index) => {
      if (eval(_p_index) === index) {
        const _new_item = item.sub_p.concat([{ sub_name_1: "", sub_lavel_1: 11, exam_cat_1: 1, sub_p_1: [] }])
        item.sub_p = _new_item;
      }
      return item;
    })
    ////console.log(_new_subjects);
    this.setState({
      subjects_obj: _new_subjects
    });

    ////console.log(this.state.subjects_obj);
  };
  handleRemoveSubject_1 = (event, index) => {
    event.preventDefault();
    let _subject = this.state.subjects_obj;
    const _p_index = event.target.getAttribute('data-parent-index');
    const _new_subjects = _subject.map((item, index) => {
      if (eval(_p_index) === index) {
        const _new_item = item.sub_p.filter((s, sidx) => index !== sidx)
        item.sub_p = _new_item;
      }
      return item;
    })
    this.setState({
      subjects_obj: _new_subjects
    });
  };

  getSectedClassHandler = (event) => {
    const _class_id = event.target.value;
    this.setState({ class_id: _class_id });
    //this.subjectsClasswise(_class_id);
  }

  // // get subjects according to class
  // subjectsClasswise = (_class_id) => {
  //   this.setState({
  //     class_id: _class_id,
  //     existsubject: '',
  //   }, () => {
  //     loadProgressBar();
  //     axios.get(READ_SUBJECTS + `?id=` + _class_id)
  //       .then(res => {
  //         const getRes = res.data;
  //         (getRes.message === undefined) ?
  //           this.setState({
  //             existsubject: getRes,
  //             subjects_obj: getRes,
  //           }) :
  //           this.setState({
  //             errorMessages: getRes.message,
  //             subjects_obj: [{ sub_name: "", sub_lavel: "1", sub_p: [] }]
  //           })
  //         ////console.log(this.state.classes);
  //       }).catch((error) => {
  //         // error
  //       })
  //   })
  // }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.examsType)) {
      this.props.getExamsType();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getExamTypeHandler();
  //           this.getSubjectsHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }
  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getExamTypeHandler() {
  //   loadProgressBar();
  //   axios.get(READ_EXAM_CATE)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         examsType: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getSubjectsHandler() {
  //   loadProgressBar();
  //   axios.get(READ_URL)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.message !== undefined) {
  //         Alert.error(resData.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000,
  //         });
  //       } else {
  //         this.setState({
  //           subjects: resData
  //         });
  //         //console.log(this.state.subjects);
  //       }
  //     }).catch((error) => {
  //       // error
  //     })
  // };
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       this.setState({
  //         sft_classes: classes,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = () => {
    const { class_id, medium, subjects_obj } = this.state;
    const _subject = subjects_obj.filter((item, index) => {
      return item.sub_name.length > 0
    })
    const obj = {
      class_id: class_id,
      sub_names: _subject,
      medium: medium,
    };
    console.log(JSON.stringify(obj));
    this.props.createSubject(obj);
    // axios.post(CREATE_SUBJECT, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       class_id: 0,
    //       subjects_obj: [{ sub_name: "", sub_lavel: "1", sub_p: [] }]
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
    
  };
  render() {
    const { subjects_obj, medium, selected_school_index, medium_arr, selected_classes, sub_lavel,
      class_id, sub_lavel_1, formIsHalfFilledOut } = this.state;
    const { user, schools, classes, examsType } = this.props;
    // console.log(this.state);
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Subject</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Subject
        </div>
          <div className="card-body">
            {user && schools && classes && examsType &&
              <>
                <div className="row">
                  <div className="col-sm-3">
                    <div className="d-flex">
                      <label className="control-label mr-2">Schools :</label>
                      <div className="form-input w-100">
                        <select className="form-control form-control-sm"
                          required
                          ref='school'
                          value={selected_school_index}
                          onChange={event => this.changeHandler(event, 'school')}>
                          <option value="">Select ...</option>
                          {schools.map((item, index) => {
                            return (
                              <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                            )
                          })}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="col-sm-3">
                    <div className="d-flex">
                      <label className="control-label mr-2">Medium :</label>
                      <div className="form-input w-100">
                        <select className="form-control form-control-sm"
                          required
                          ref='medium'
                          disabled={medium_arr.length > 1 ? false : true}
                          value={medium}
                          onChange={event => this.changeHandler(event, 'medium')}>
                          <option value="">Select ...</option>
                          {medium_arr.map((item, index) => {
                            return (
                              <option key={index} value={item}>{item}</option>
                            )
                          })}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-3">
                    <div className="d-flex">
                      <label className="control-label mr-2">Class
                        <span className="required"> * </span>
                      </label>
                      <div className="form-input w-100">
                        <select className="form-control form-control-sm" name="select"
                          value={class_id}
                          onChange={event => this.getSectedClassHandler(event)}>
                          <option value="">Select...</option>
                          {selected_classes.map((option, index) => {
                            return (
                              <option key={index}
                                value={option.id}>
                                {option.class_name} [{option.class_name_portal}]
                              </option>
                            )
                          })}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  {(subjects_obj.length > 0 && class_id !== '') ? subjects_obj.map((item, index) => (
                    <div className="col-sm-6" key={index}>
                      <div className="row" key={index}>
                        <label className="control-label col-auto">Subject Name
                        <span className="required"> * </span>
                        </label>
                        <div className="col">
                          <div className="form-group mt-1">
                            <div className="input-group mb-1">
                              <div className="input-group-prepend">
                                <button
                                  type="button"
                                  className="btn btn-danger btn-sm"
                                  onClick={event => this.handleRemoveSubject(event, index)} >
                                  Del
                                      </button>
                              </div>
                              <input
                                type="text"
                                className="form-control form-control-sm"
                                //placeholder={`#${index + 1} `}
                                // placeholder={`Subject Name`}
                                value={item.sub_name}
                                onChange={event => this.handleSubNameHandler(event, index)}
                              />
                              <select className="form-control form-control-sm" name="sub_lavel"
                                value={item.sub_lavel}
                                onChange={event => this.handleSubLavelHandler(event, index)}>
                                {sub_lavel.map((option, index) => {
                                  return (
                                    <option key={index}>
                                      {option.sub_lavel === 2 ? 'Faculty' : "No Faculty"}
                                    </option>
                                  )
                                })}
                              </select>
                              <select className="form-control form-control-sm" name="exam_cat"
                                //value={item.select_exam_cat}
                                onChange={event => this.handleExamTypeHandler(event, index)}>
                                {examsType.map((option, index) => {
                                  return (
                                    <option key={index}>
                                      {option.cat_name}
                                    </option>
                                  )
                                })}
                              </select>
                              <div className="input-group-append">
                                <button
                                  type="button"
                                  className="btn btn-info btn-sm"
                                  onClick={event => this.handleAddSubject(event)}
                                >
                                  More
                                      </button>
                              </div>
                            </div>
                            {(item.sub_p.length > 0) ? item.sub_p.map((item, index_1) => {
                              return (
                                <div key={index_1} className="row child">
                                  <label className="control-label col-md-3">Part <span className="required"> * </span>
                                  </label>
                                  <div className="col-md-9">
                                    <div className="form-group mb-1">
                                      <div className="input-group mb-1">
                                        <div className="input-group-prepend">
                                          <button
                                            type="button"
                                            className="btn btn-danger btn-sm"
                                            data-parent-index={index}
                                            onClick={event => this.handleRemoveSubject_1(event, index_1)} >
                                            Del
                                              </button>
                                        </div>
                                        <input
                                          type="text"
                                          className="form-control form-control-sm"
                                          //placeholder={`#${index_1 + 1} `}
                                          // placeholder={`Subject Name`}
                                          value={item.sub_name_1}
                                          data-parent-index={index}
                                          onChange={event => this.handleSubNameHandler_1(event, index_1)}
                                        />
                                        <select className="form-control form-control-sm" name="sub_lavel"
                                          value={item.sub_lavel}
                                        //onChange={event => this.handleSubLavelHandler_1(event, index_1)}
                                        >
                                          {sub_lavel_1.map((option, index_1) => {
                                            return (
                                              <option key={index_1}>
                                                {option.sub_lavel === 2 ? 'Faculty' : "No Faculty"}
                                              </option>
                                            )
                                          })}
                                        </select>
                                        <select className="form-control form-control-sm" name="exam_cat"
                                        //value={item.select_exam_cat}
                                        //onChange={event => this.handleExamTypeHandler_1(event, index)}
                                        >
                                          {examsType.map((option, index) => {
                                            return (
                                              <option key={index}>
                                                {option.cat_name}
                                              </option>
                                            )
                                          })}
                                        </select>
                                        <div className="input-group-append">
                                          <button
                                            type="button"
                                            data-parent-index={index}
                                            className="btn btn-secondary btn-sm"
                                            onClick={event => this.handleAddSubject_1(event, index_1)}
                                          >
                                            More
                                              </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              )
                            }) : null}
                          </div>
                        </div>
                      </div>
                    </div>
                  )) : null}
                </div>
              </>
            }
          </div>

          <div className="card-footer d-flex">
            <span className="p-2">1. if One Subject have <b>Oral</b> It means All subject created with <b>Oral</b></span>
            <button type="submit" className="btn btn-secondary ml-auto mr-2">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: examsType } = state.examsType;
  return { user, schools, classes, examsType };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getExamsType: examsTypeAction.getExamsType,
  createSubject: subjectsAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddSubject));
