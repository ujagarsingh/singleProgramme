import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const UPDATE_ARTICLE = `http://schools.rajpsp.com/api/articles/update.php`;
const GET_ARTICLE = `http://schools.rajpsp.com/api/articles/read_one.php`;

class UpdateArticle extends Component {
  state = {
    id: "",
    title: "",
    description: "",
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };

  componentDidMount() {
    const token = sessionStorage.getItem('jwt');
    const obj = { "jwt": token };
    this.checkAuthentication(obj);
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getAllArticlesHandler();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }

  getAllArticlesHandler() {
    loadProgressBar();
    const { match } = this.props;
    axios.get(GET_ARTICLE + '?id=' + match.params.id)
      .then(res => {
        const getRes = res.data;
        this.setState({
          id: match.params.id,
          title: getRes.title,
          description: getRes.description
        });
        //console.log(getRes);
      }).catch((error) => {
        ////console.log(error)
      })
  };
  
  submitHandler = e => {
    loadProgressBar();
    e.preventDefault();
    const obj = {
      id: this.state.id,
      title: this.state.title,
      description: this.state.description
    }
    axios.post(UPDATE_ARTICLE, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        if (getRes.message !== undefined) {
          Alert.success(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  render() {
    const { formIsHalfFilledOut, title, description } = this.state;
    return (
      <div className="page-content">
        <Helmet>
          <title>Update Article</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Add Article</div>
        </div>
        <form className="card card-box sfpage-cover" onSubmit={this.submitHandler}>
          <div className="card-body sfpage-body">
            <div className="form-horizontal" >
              <div className="form-body">
                <div className="form-group row">
                  <label className="control-label col-md-2">Article Title
                      <span className="required"> * </span>
                  </label>
                  <div className="col-md-5">
                    <input type="text" name="firstname"
                      value={title}
                      className="form-control form-control-sm"
                      onChange={event => this.changeHandler(event, 'title')} />
                  </div>
                </div>
                <div className="form-group row">
                  <label className="control-label col-md-2">Article Content
                      <span className="required"> * </span>
                  </label>
                  <div className="col-md-8">
                    <textarea placeholder="description"
                      name="description"
                      className="form-control-textarea form-control" rows={5}
                      value={description}
                      onChange={event => this.changeHandler(event, 'description')} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer  text-right">
            <button type="submit" className="btn btn-primary mr-2">Update</button>
            <NavLink to="/all_article.jsp" className="btn btn-danger">Back</NavLink>
          </div>
        </form>
      </div>
    )
  }
}
export default withRouter(UpdateArticle);