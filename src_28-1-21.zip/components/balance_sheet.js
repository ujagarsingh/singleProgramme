import React, { Component } from 'react';
import { withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
  accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction,
  professionalAction, schoolsAction, classesAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


import CommonFilters from '../utility/Filter/filter-schools';
import { NavLink } from 'react-router-dom';

class BalanceSheet extends Component {

  state = {
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.accLedgerEntry)) {
      this.props.getAccLedgerEntry();
    }
    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }
    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      const _accGroup = this.props.accGroup;
      const _all_professional = this.props.professional;
      const _accLedgerEntry = this.props.accLedgerEntry;
      if (_all_student && _all_professional && _filter && _accGroup && _accLedgerEntry) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    const _all_professional = this.props.professional;
    const _all_groups = this.props.accGroup;
    const _all_ledger = this.props.accLedger;
    const _all_accLedgerEntry = this.props.accLedgerEntry;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      if (_school_student.length > 0) {
        this.setState({
          display_student: _school_student
        })
      }
    }
  }

  getGroupwiseDetail = (group_title, group_id) => {
    // debugger
    const _blanceData = this.props.accountManager.group_balance;
    if (!isEmptyObj(_blanceData)) {
      const _crnt_grp = _blanceData.filter((item) => {
        if (item.id === group_id) {
          return item
        }
      });
      const g_total = _crnt_grp[0].cl_blnc;
      let parent_row =
        <NavLink to={`group_summary.jsp/${'2'}/${_crnt_grp[0].id}`} className="link-without-color">
          <div className="bs-detail-head">
            <div className="head-name">{group_title}</div>
            <div className="head-amount">{(g_total === 0) ? '' : g_total}</div>
          </div>
        </NavLink>;
      let child_rows = _crnt_grp[0].sub_group.map((item, index) => {
        const sub_total = item.cl_blnc;
        return (
          <NavLink key={index} to={`group_summary.jsp/${'3'}/${item.id}/${_crnt_grp[0].id}`} className="link-without-color">
            <div className="bs-detail-sub-head" >
              <div className="sub-head-name">{item.group_name}</div>
              <div className="sub-head-amount">{(sub_total === 0) ? '' : sub_total}</div>
            </div>
          </NavLink>
        )
      });
      const abc = <div className="bs-detail-zone">{parent_row} {child_rows}</div>;
      return abc;
    }
  }
  getPandLDetail = (group_title, group_id, group_type) => {
    const _blanceData = this.props.accountManager.group_balance;
    if (!isEmptyObj(_blanceData)) {
      const _crnt_grp = _blanceData.filter((item) => {
        if (item.id === group_id) {
          return item
        }
      });
      const g_total = _crnt_grp[0].cl_blnc;
      if (_crnt_grp[0].blnc_type === group_type) {
        let parent_row =
          <NavLink to={`profit_n_loss.jsp`} className="link-without-color">
            <div className="bs-detail-head">
              <div className="head-name">{group_title}</div>
              <div className="head-amount">{(g_total === 0) ? '' : g_total}</div>
            </div>
          </NavLink>;
        let child_rows = <>
          <div className="bs-detail-sub-head">
            <div className="sub-head-name">Opening Balance</div>
            <div className="sub-head-amount"></div>
          </div>
          <div className="bs-detail-sub-head">
            <div className="sub-head-name">Current Period</div>
            <div className="sub-head-amount">{(g_total === 0) ? '' : g_total}</div>
          </div>
        </>;
        const abc = <div className="bs-detail-zone">{parent_row} {child_rows}</div>;
        return abc;
      }
    }
  }

  getTotalBalanceHandler() {
    const _balanceData = this.props.accountManager.group_balance;
    let total_libilities = 0;
    let total_assets = 0;
    _balanceData.forEach((elem) => {
      // debugger
      if (elem.id === "5" || elem.id === "4" || (elem.id === "1001" && elem.blnc_type === "DR")) {
        if (elem.blnc_type === "CR" || (elem.id === "1001" && elem.blnc_type === "DR")) {
          total_libilities += elem.cl_blnc
        } else {
          total_libilities -= elem.cl_blnc
        }
      } else if (elem.id === "3" || (elem.id === "1001" && elem.blnc_type === "CR")) {
        if (elem.blnc_type === "DR" || (elem.id === "1001" && elem.blnc_type === "CR")) {
          total_assets += elem.cl_blnc
        } else {
          total_assets -= elem.cl_blnc
        }
      }
    })
    // console.log(total_libilities);
    // console.log(total_assets);
    return <div className="row">
      <div className="col-sm-6">
        <div className="sec-foot">
          <div className="title-zone">Total</div>
          <div className="amount-zone">{total_libilities}</div>
        </div>
      </div>
      <div className="col-sm-6">
        <div className="sec-foot">
          <div className="title-zone">Total</div>
          <div className="amount-zone">{total_assets}</div>
        </div>
      </div>
    </div>
  }

  render() {
    const { user, students, professional, schools, filteredSchoolData, accountManager } = this.props;
    // console.log(this.props.accountManager)
    return (
      <div className="page-content">
        <Helmet>
          <title>Balance Sheet</title>
        </Helmet>
        {(user && students && professional && schools) &&
          <div className="page-bar d-flex">
            <div className="page-title">Balance Sheet</div>
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />
              </div>
            </div>
          </div>
        }
        { accountManager &&
          <div className="card card-box sfpage-cover">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page acc-midline page-balance-sheet">
                <div className="acc-page-head container-fluid ">
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="sec-title">
                        <div className="title-zone">Liabilities</div>
                        <div className="info-zone">
                          <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                          <div className="fy-detail">as at 1-Jul-2020</div>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="sec-title">
                        <div className="title-zone">Assets</div>
                        <div className="info-zone">
                          <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                          <div className="fy-detail">as at 1-Jul-2020</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="acc-page-body container-fluid ">
                  <div className="row">
                    <div className="col-sm-6">
                      {this.getGroupwiseDetail('Capital Account', "5")}
                      <div className="bs-detail-zone">
                        <div className="bs-detail-head">
                          <div className="head-name">Loans (Liability)</div>
                          <div className="head-amount"></div>
                        </div>
                        <div className="bs-detail-sub-head"></div>
                      </div>
                      {this.getGroupwiseDetail('Current Liabilities', "4")}
                      {this.getPandLDetail('Excess of income over expenditure (P&L)', "1001", "DR")}
                      {/* <div className="bs-detail-zone">
                        <div className="bs-detail-head">
                          <div className="head-name">Excess of income over expenditure (P&L)</div>
                          <div className="head-amount">9,450.00</div>
                        </div>
                        <div className="bs-detail-sub-head">
                          <div className="sub-head-name">Opening Balance</div>
                          <div className="sub-head-amount">6,750.00</div>
                        </div>
                        <div className="bs-detail-sub-head">
                          <div className="sub-head-name">Current Period</div>
                          <div className="sub-head-amount">2,700.00</div>
                        </div>
                      </div> */}
                    </div>

                    <div className="col-sm-6">
                      {this.getGroupwiseDetail('Current Assets', "3")}
                      {this.getPandLDetail('Excess of income over expenditure (P&L)', "1001", "CR")}
                    </div>
                  </div>
                </div>
                <div className="acc-page-footer container-fluid ">
                  {this.getTotalBalanceHandler()}

                </div>
              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  const { item: professional } = state.professional;
  const { item: accLedger } = state.accLedger;
  const { item: accGroup } = state.accGroup;
  const { item: accLedgerEntry } = state.accLedgerEntry;
  const { item: accountManager } = state.accountManager;
  return {
    user, students, accLedger, accGroup, accLedgerEntry, schools, accountManager,
    professional, filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getStudents: studentsAction.getStudents,
  getProfessional: professionalAction.getProfessional,
  getAccLedger: accLedgerActions.getAccLedger,
  getAccGroup: accGroupActions.getAccGroup,
  getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,

}

export default connect(mapStateToProps, actionCreators)(withRouter(BalanceSheet));
