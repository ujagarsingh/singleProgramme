// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const accountLedgerSummaryFYService = {
    getLedgerNameHandler,
    getLedgerSummaryofFinancialYearHandler,
};

function getLedgerSummaryofFinancialYearHandler(obj) {
    return new Promise((resolve, reject) => {
        const grpId = obj.ledger_id;
        const data = obj.acc_manager.ledger_data;
        const all_ledgers = obj.acc_manager.all_ledgers;

        let monly_obj = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
        const m_data = data.filter((vItem) => {
            if (grpId == vItem.ldr_ref_id) {
                return vItem
            }
        })
        const _new_obj = monly_obj.map((mitem) => {
            let cr_amo = 0;
            let dr_amo = 0;
            m_data.map((vItem) => {
                if (mitem == vItem.entry_month) {
                    if (vItem.tr_type === "CR") {
                        cr_amo += Number(vItem.tr_amount)
                    } else {
                        dr_amo += Number(vItem.tr_amount)
                    }
                }
                return false;
            })
            return mitem = {
                "month_id": mitem,
                "cr_amo": cr_amo,
                "dr_amo": dr_amo,
                "cl_blnc": Math.abs(cr_amo - dr_amo),
                "blnc_type": (cr_amo <= dr_amo) ? "Dr" : "Cr"
            }
        })
        // opening balance....
        _new_obj.unshift({
            "lcl_blnc": 0,
            "lcl_type": "Dr",
        })
        // console.table(_new_obj);
        let la = 0;  // final last amount
        let lt = 'Dr';     // final last type
        let tdr = 0;    // total debit balnce
        let tcr = 0;    // total credit balnce

        for (let i = 1; i < _new_obj.length; i++) {
            const oa = _new_obj[i - 1].lcl_blnc; // Old Amount
            const ot = _new_obj[i - 1].lcl_type; // Old Type

            const ca = _new_obj[i].cl_blnc;      // Current Amount
            const ct = _new_obj[i].blnc_type;    // Current Type
            // get clossing balance with type 
            if (ca === 0) {
                la = oa;
                lt = ot;
            } else if (ot === ct) {
                la = oa + ca;
                lt = ot;
            } else {
                la = oa - ca;
                lt = (oa > ca) ? ot : ct;
            }

            // get clossing Debit/Credit Balance
            if (ct === 'Dr') {
                tdr = tdr + ca;
            } else {
                tcr = tcr + ca;
            }

            _new_obj[i]['lcl_blnc'] = Math.abs(la);
            _new_obj[i]['lcl_type'] = lt;
        }
        // console.log(JSON.stringify(_new_obj));
        _new_obj.shift();
        // console.table(_new_obj);

        const _ledger_name = this.getLedgerNameHandler(all_ledgers, grpId);

        if (_new_obj.length > 0) {
            resolve({
                "data": {
                    data_obj: _new_obj, ledger_name: _ledger_name,
                    g_total: { total_dr: tdr, total_cr: tcr, closing_amo: la, closing_type: lt }
                }
            });
        } else {
            reject("Something went wrong");
        }

    })
    // return _new_obj;
}

// ledger folio to get ledger name
function getLedgerNameHandler(all_ledgers, ledger_folio) {
    const fl = all_ledgers.filter((item) => {
        if (item.ldr_ref_id === ledger_folio) {
            return item;
        }
    })
    return fl[0].ledger_name;
}

