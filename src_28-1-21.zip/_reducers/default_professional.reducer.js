import { defaultProfessionalConstants } from '../_constants';

export function defaultProfessional(state = {}, action) {
  switch (action.type) {
    case defaultProfessionalConstants.PROFESSIONAL_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultProfessionalConstants.PROFESSIONAL_SUCCESS:
      return {
        item: action.response
      };
    case defaultProfessionalConstants.PROFESSIONAL_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}