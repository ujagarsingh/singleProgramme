import { feeWithCategoryConstants } from '../_constants';
import { feeWithCategoryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeWithCategoryAction = {
    getFeeWithCategory
};

function getFeeWithCategory() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeWithCategoryService.getFeeWithCategory()
            .then(
                response => {
                    dispatch(success(response.data.fee_amo_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: feeWithCategoryConstants.FEE_WITH_CATEGORY_REQUEST } }
    function success(response) { return { type: feeWithCategoryConstants.FEE_WITH_CATEGORY_SUCCESS, response } }
    function failure(error) { return { type: feeWithCategoryConstants.FEE_WITH_CATEGORY_FAILURE, error } }
}
 