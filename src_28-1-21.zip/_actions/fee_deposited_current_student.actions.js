import { feeDepositedCurrentStudentConstants } from '../_constants';
import { feeDepositedCurrentStudentService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeDepositedCurrentStudentAction = {
    getFeeDepositedCurrentStudent
}; 


function getFeeDepositedCurrentStudent(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeDepositedCurrentStudentService.getFeeDepositedCurrentStudent(obj)
            .then(
                response => {
                    dispatch(success(response.data.fee_amo_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_REQUEST } }
    function success(response) { return { type: feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_SUCCESS, response } }
    function failure(error) { return { type: feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_FAILURE, error } }
}
 