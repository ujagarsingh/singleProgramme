import { accountLedgerSummaryFYConstants } from '../_constants';
import { accountLedgerSummaryFYService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accountLedgerSummaryFYActions = {
    getLedgerSummaryofFinancialYearHandler,
};

function getLedgerSummaryofFinancialYearHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accountLedgerSummaryFYService.getLedgerSummaryofFinancialYearHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_REQUEST } }
    function success(response) { return { type: accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_SUCCESS, response } }
    function failure(error) { return { type: accountLedgerSummaryFYConstants.ACC_LDR_YEAR_REPORT_FAILURE, error } }
}