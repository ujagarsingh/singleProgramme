import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, sessionYearsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddSchool from './add_school';
import EditSchool from './edit_school';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/school/delete.php`;

class AllSchools extends Component {
   state = {
      schools: [],
      branch_opt: [{ "id": 1, "type": 'School' }, { "id": 2, "type": 'Coaching' }],
      medium: '',
      classes: [],
      selected_class: '',
      classes_medium: [],
      createItem: false,
      editItem: false,
      formIsHalfFilledOut: false,
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.sessionYears)) {
         this.props.getSessionYears();
      }
      this.checkFlag();
   }
 
 
   checkFlag() {
     setTimeout(() => {
       const _filter = this.props.filteredSchoolData;
       const _all_schools = this.props.schools;
       if (_all_schools && _filter) {
         this.filterBySchoolHandler();
       } else {
         this.checkFlag()
       }
     }, 100);
   }


   getBranchNameHandler = (id) =>{
      let _type = "Not Avalable";
      const _crmt_type = this.state.branch_opt.filter(e => Number(id) === e.id)[0];
      if(!isEmpty(_crmt_type)){
         _type = _crmt_type.type
      }
      return _type
   }
 
   filterBySchoolHandler = () => {
     const _filter = this.props.filteredSchoolData;
     const _schools = this.props.schools;
     if (!isEmpty(_schools)) {
       const _sch_schools = _schools.filter((item) => {
         if (_filter.slct_school_id) {
           if (item.id === _filter.slct_school_id) {
             return item
           }
         } else {
           return item
         }
       })
       this.setState({
         display_schools: _sch_schools,
       })
     }
   }
 

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }


   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      let del_id = id;
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  //this.deleteHandlar(del_id);
                  this.props.deleteSchoolHandler({ id: del_id });
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   // deleteHandlar = (id) => {
   //    //event.preventDefault();
   //    // this.props.deleteAccGroup({ id: del_id });
   //    const _id = id;
   //    axios.post(DELETE_URL + '?id=' + _id)
   //       .then(res => {
   //          const getRes = res.data;
   //          //console.log(getRes)
   //          Alert.success(getRes.message, {
   //             position: 'bottom-right',
   //             effect: 'jelly',
   //             timeout: 5000, offset: 40
   //          });
   //          const _schools = this.state.schools.filter((item, index) => {
   //             return item.id !== _id
   //          })
   //          this.setState({
   //             display_schools: _schools
   //          })
   //       }).catch((error) => {
   //          //this.setState({ errorMessages: error });
   //       })
   // }

   updateHandlar = (obj) => {
      console.log(JSON.stringify(obj));
      this.props.updateSchoolHandler(obj);
   }
   toggeleCreate = (event) => {
      event.preventDefault();
      this.setState({
         editItem: false,
         createItem: !this.state.createItem
      })
   }
   openEdit = (event, id) => {
      event.preventDefault();
      const _selected_item = this.props.schools.filter((item) => {
         if (item.id === id) {
            return item
         }
      })

      this.setState({
         // editItem: !this.state.editItem,
         editItem: true,
         createItem: false,
         selected_item: _selected_item[0]
      })
   }
   closeEdit = (event) => {
      event.preventDefault();
      this.setState({
         editItem: false,
         selected_item: ''
      })
   }
   render() {
      const { formIsHalfFilledOut, createItem, editItem, selected_item, display_schools } = this.state;
      const { user, schools, sessionYears } = this.props;
      //console.log(_state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Afilated Schools</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div className="page-bar d-flex">
               <div className="page-title">Afilated Schools</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <CommonFilters
                        showSchoolFilter={true}
                        showMediumFilter={false}
                        // showClassFilter={true}
                        filterBySchoolHandler={this.filterBySchoolHandler}
                        // filterByClsHandler={this.filterByClsHandler}
                     />
                     {/* <div className="form-group mt-1">
                        <NavLink to="/add_school.jsp" className="btn btn-primary btn-sm">
                           Add School <i className="fa fa-plus" />
                        </NavLink>
                     </div> */}
                  </div>
               </div>
            </div>
            {user && schools && sessionYears &&
               <div className="card card-box sfpage-cover">
                  <div className="card-body sfpage-body">
                     {createItem ?
                        <AddSchool
                           user={user}
                           toggeleCreate={this.toggeleCreate}
                        />
                        : null}
                     {editItem ?
                        <>
                           <EditSchool
                              selected_item={selected_item}
                              schools={schools}
                              user={user}
                              sessionYears={sessionYears}
                              updateHandlar={this.updateHandlar}
                              openEdit={this.openEdit}
                              closeEdit={this.closeEdit}
                           />
                           <div className="backdrop edit-mode"></div>
                        </>
                        : null}
                     <div className="table-scrollable">
                        <table className="table table-striped table-bordered table-hover table-sm">
                           <thead>
                              <tr>
                                 <th />
                                 <th>School Logo</th>
                                 <th>Admin Image</th>
                                 <th>Admin Sign</th>
                                 <th>School Info</th>
                                 <th>Contacts</th>
                                 <th> Action </th>
                              </tr>
                           </thead>
                           {display_schools &&
                              <tbody>
                                 {display_schools.map((item, index) => {
                                    return (
                                       <tr key={index} >
                                          <td>{index + 1}</td>
                                          <td className="left">
                                             {item.sch_logo !== '' ?
                                                <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + item.sch_logo} />
                                                : null}
                                          </td>
                                          <td className="left">
                                             {item.admin_img !== '' ?
                                                <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + item.admin_img} />
                                                : null}
                                          </td>
                                          <td className="left">
                                             {item.admin_sign !== '' ?
                                                <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + item.admin_sign} />
                                                : null}
                                          </td>
                                          <td className="left">
                                             <p className="text-nowrap mb-1"><b>Type :</b> {this.getBranchNameHandler(item.branch_type)}</p>
                                             <p className="text-nowrap mb-1"><b>Name :</b> {item.sch_name}</p>
                                             <p className="text-nowrap mb-1"><b>Reg. No. :</b> {item.sch_reg_no}</p>
                                             <p className="text-nowrap mb-1"><b>Recog. No. :</b> {item.sch_recog_no}</p>
                                             <p className="text-nowrap mb-1"><b>Medium(s) :</b> {item.sch_medium}</p>
                                             <p className="text-nowrap mb-1"><b>Current Session :</b> {item.current_session}</p>
                                          </td>
                                          <td className="left">
                                             <p className="text-nowrap mb-1"><b>Contact No :</b> {item.sch_contact_num}</p>
                                             <p className="text-nowrap mb-1"><b>Mobile No :</b> {item.sch_mobile_num}</p>
                                             <p className="text-nowrap mb-1"><b>Email Id :</b> {item.sch_email}</p>
                                             <p className="text-nowrap mb-1"><b>Address :</b> {item.sch_address}</p>
                                          </td>
                                          <td className="d-flex">
                                             {/* <NavLink to={`/ edit_school.jsp / ${item.id}`} className="btn btn-primary btn-sm mr-1">
                                                Edit</NavLink> */}
                                             <button className="btn btn-primary btn-sm mr-1"
                                                type="button"
                                                onClick={event => this.openEdit(event, item.id)}>Edit</button>

                                             <button className="btn btn-danger btn-sm"
                                                value={item.id}
                                                onClick={event => this.confirmBoxDelete(event, item.id)}>
                                                Del</button>
                                          </td>
                                       </tr>
                                    )
                                 })
                                 }
                              </tbody>
                           }
                        </table>
                     </div>
                  </div>
               </div>
            }
            <div className="card-footer">
               {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-danger btn-sm ">
                     Cancel            </button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-primary btn-sm">
                     Add New
            </button>
               }
            </div>
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: sessionYears } = state.sessionYears;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return { user, schools, sessionYears, filteredSchoolData, filteredClassesData };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   updateSchoolHandler: schoolsAction.update,
   deleteSchoolHandler: schoolsAction.delete,
   getSessionYears: sessionYearsAction.getSessionYears,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllSchools));