import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class TestPaper extends Component {
	state = {
		selected_school_index: "",
	}
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	componentDidMount() {
		const token = sessionStorage.getItem('jwt');
		const obj = { "jwt": token };
		this.checkAuthentication(obj);
	}
	checkAuthentication(obj) {
		loadProgressBar();
		axios.post(VALIDATE_URL, obj)
			.then(res => {
				const getRes = res.data;
				// sessionStorage.setItem("user", getRes.data);
				console.log(getRes);
				if (getRes.data) {
					this.setState({
						user: getRes.data,
						group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
						school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
						user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
						session_year: (getRes.data.session_year) ? getRes.data.session_year : "",
					}, () => {
						// this.getSchoolHandler();
						// this.getExamsCategories();
						// this.getSheduleNotes();
					})
				}
			}).catch((error) => {
				this.props.history.push('/login.jsp');
			})
	}

	getSchoolHandler() {
		loadProgressBar();
		const obj = {
			group_id: this.state.group_id
		}
		axios.post(READ_SCHOOLS, obj)
			.then(res => {
				const getRes = res.data;
				this.setState({
					schools_arr: getRes,
					errorMessages: getRes.message
				});
				// console.log(this.state);
			}).catch((error) => {
				// error
			})
	}

	showInstruction(event) {
		event.preventDefault();

	}
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}

	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (
			<div className="page-content">
				<Helmet>
					<title>Test Result</title>
				</Helmet>
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				{user &&
					<>
						<div className="page-bar d-flex">
							<div className="page-title">All E-Test</div>
							<div className="form-inline ml-auto filter-panel">
								<span className="filter-closer">
									<button type="button" className="btn btn-danger filter-toggler-c">
										<i className="fa fa-times"></i>
									</button>
								</span>
								<div className="filter-con">
									<div className="filter-con">
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-warning btn-sm">Download Report <i className="fa fa-plus" /></NavLink>
										</div>
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-primary btn-sm">View Solutions <i className="fa fa-plus" /></NavLink>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="card card-box sfpage-cover">
							<div className="card-body sfpage-body">
								<div className="table-scrollable">
									<div className="container">
										<div className="d-flex">
											<h4 className="mr-auto">Title of This etest</h4>
										</div>
										<hr />
										<div className="row">
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Scrore</div>
													<div className="score-detail">3.00/100</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Accuracy</div>
													<div className="score-detail">100.00%</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Rank AIS</div>
													<div className="score-detail">32/54</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Percentage</div>
													<div className="score-detail">3.00%</div>
												</div>
											</div>
											<div className="col">
												<div className="scoreBox">
													<div className="score-title">Percentile</div>
													<div className="score-detail">72.00%</div>
												</div>
											</div>
										</div>
										<hr />
										<div className="row">
											<div className="col">
												<div className="card">
													<div className="card-body">
														<h5 className="card-title">Leaderboard</h5>
														<ul className="list-unstyled">
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Rahul Sharma</h5>
																	<p>Marks 45/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Sandeep Gupta</h5>
																	<p>Marks 75/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Prashant Khandelwal</h5>
																	<p>Marks 87/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Manohar Lal Rana</h5>
																	<p>Marks 63/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Kamal Kishore</h5>
																	<p>Marks 30/100</p>
																</div>
															</li>
														</ul>
													</div>
												</div>
											</div>
											<div className="col">
												<div className="card">
													<div className="card-body">
														<h5 className="card-title">Overview</h5>
														<img src={`${process.env.PUBLIC_URL}/assets/images/circle-pie-chart.jpg`} alt="Status" className="img-fluid"
														/>
													</div>
												</div>
											</div>
											<div className="col">
												<div className="card">
													<div className="card-body">
														<h5 className="card-title">You v/s Topper</h5>
														<table className="table">
															<thead>
																<tr>
																	<th scope="col">#</th>
																	<th scope="col">Comprison</th>
																	<th scope="col">You</th>
																	<th scope="col">Topper</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<th scope="row">
																		<i className="fa fa-battery-half"></i>
																	</th>
																	<td>Score</td>
																	<td>3.00</td>
																	<td>98.00</td>
																</tr>
																<tr>
																	<th scope="row">
																		<i className="fa fa-bullseye"></i>
																	</th>
																	<td>Accuracy</td>
																	<td>100.00</td>
																	<td>96.67</td>
																</tr>
																<tr>
																	<th scope="row">
																		<i className="fa fa-check-circle"></i>
																	</th>
																	<td>Correct</td>
																	<td>2</td>
																	<td>116</td>
																</tr>
																<tr>
																	<th scope="row">
																		<i className="fa fa-times-circle"></i>
																	</th>
																	<td>Incorrect</td>
																	<td>0</td>
																	<td>4</td>
																</tr>
																<tr>
																	<th scope="row">
																		<i className="fa fa-stopwatch"></i>
																	</th>
																	<td>Time</td>
																	<td>75 Min 10 Sec</td>
																	<td>10 Min 33 Sec</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<hr />
										<div className="row">
											<div className="col">
												<div className="card">
													<div className="card-body">
														<h4>Section wise distribution</h4>
														<h6>You attempted 2% question correct in [test name]. Keep praticing to increase your score!.</h6>
														<p>Your detailed section performance is shown below.</p>
														<table className="table">
															<thead>
																<tr>
																	<th scope="col">Paper</th>
																	<th scope="col">Attempted</th>
																	<th scope="col">Correct</th>
																	<th scope="col">Accuracy</th>
																	<th scope="col">Time</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<th scope="row">[Test Name]</th>
																	<td>2/100</td>
																	<td>2/100</td>
																	<td>100.00%</td>
																	<td>01:30:20</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<hr />
										<div className="row">
											<div className="col">
												<h4>Summary</h4>
												<div className="row">
													<div className="col">
														<div className="card">
															<div className="card-body">
																<h5>Attempted</h5>
																<h5>2/100</h5>
															</div>
														</div>
													</div>
													<div className="col">
														<div className="card">
															<div className="card-body">
																<h5>Correct</h5>
																<h5>2/100</h5>
															</div>
														</div>
													</div>
													<div className="col">
														<div className="card">
															<div className="card-body">
																<h5>Accuracy</h5>
																<h5>100.00%</h5>
															</div>
														</div>
													</div>
													<div className="col">
														<div className="card">
															<div className="card-body">
																<h5>Time</h5>
																<h5>01:30:20</h5>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									{/* <img className="thumbnail"
										alt="Test Result"
										src={`${process.env.PUBLIC_URL}/assets/images/dummy_rudult.png`} /> */}
								</div>
							</div>
						</div>
					</>
				}
			</div>
		)
	}
}
export default withRouter(TestPaper);