import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import { connect } from 'react-redux';
import { schoolsAction, classesAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const DELETE_SHEDULE = `http://schools.rajpsp.com/api/exam_sdul/delete.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const READ_SHEDULE = `http://schools.rajpsp.com/api/exam_sdul/read.php`;

class AllETest extends Component {
  state = {
    schools_arr: [],
    medium_arr: [],
    selected_classes: [],
    group_id: '',
    school_id: '',
    user_category: '',
    session_year_id: '',
    formIsHalfFilledOut: false,
    showSheduleData: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    }
  };

  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes
    })
  }


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getSchoolHandler();
            this.getExamShedules();
            this.getExamsCategories();
            this.getSheduleNotes();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }

  getSheduleNotes() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
      exam_id: this.state.exam_name,
    }
    // console.log(JSON.stringify(obj));
    // debugger;
    axios.post(READ_SDUL_NOTE, obj)
      .then(res => {
        const getRes = res.data;
        let _notes = [];
        getRes.forEach((item) => {
          _notes.push({ "note": item.notes })
        })
        this.setState({
          notes: _notes,
          // updated_subjects: [...this.state.updated_subjects, getRes],
          errorMessages: getRes.message
        })
        // console.log(this.state);
      }).catch((error) => {
        // error
      })
  }


  getExamsCategories() {
    loadProgressBar();
    axios.get(READ_EXAM_CATE)
      .then(res => {
        const getRes = res.data;
        this.setState({
          exams: getRes,
          errorMessages: getRes.message
        })
        // console.log(this.state);
      }).catch((error) => {
        // error
      })
  }
  getExamShedules() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id
    }
    console.log(JSON.stringify(obj));
    axios.post(READ_SHEDULE, obj)
      .then(res => {
        const getRes = res.data;
        if (!this.isEmpty(getRes.message)) {
          Alert.success(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        } else {
          this.setJsonToSheduleObject(getRes.db_data);
        }
      }).catch((error) => {
        // error
      })
  }
  setJsonToSheduleObject(data) {
    const final_arr = data.map((item) => {
      let shedule_data = JSON.parse(item.shedule);
      item['shedule'] = shedule_data;
      return item
    })
    this.setState({
      shedule_arr: final_arr
    })
  }
  getSchoolHandler() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id
    }
    axios.post(READ_SCHOOLS, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          schools_arr: getRes,
          errorMessages: getRes.message
        });
        // console.log(this.state);
      }).catch((error) => {
        // error
      })
  }
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  deleteHandlar = (id) => {
    //event.preventDefault();
    const _id = id;
    axios.post(DELETE_SHEDULE + '?id=' + _id)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        const _shedule_arr = this.state.shedule_arr.filter((item, index) => {
          return item.id !== _id
        })
        this.setState({
          shedule_arr: _shedule_arr
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  getExamCatNameHandler(exam_id) {
    const _exams = this.state.exams;
    const _selected_obj = _exams.filter((item) => {
      if (item.id === exam_id) {
        return item;
      }
    })
    return _selected_obj[0].cat_name;
  }
  getSchoolNameHandler(school_id) {
    const _schools = this.state.schools_arr;
    if (!this.isEmpty(_schools)) {
      const _selected_obj = _schools.filter((item) => {
        if (item.id === school_id) {
          return item
        }
      })
      return _selected_obj[0].sch_name;
    } else {
      return false
    }
  }
  viewSheduleHandler(ev, sdul_id) {
    ev.preventDefault();
    const _shedule_arr = this.state.shedule_arr;
    const selected_data = _shedule_arr.filter((item) => {
      if (item.id === sdul_id) {
        return item
      }
    })
    this.setState({
      final_shedule: selected_data[0].shedule,
      showSheduleData: true
    })
  }
  hideSheduleHandler(ev) {
    ev.preventDefault();
    this.setState({
      showSheduleData: false
    })
  }
  render() {
    const { selected_school_index, medium_arr, medium, selected_class, selected_classes, formIsHalfFilledOut } = this.state;
    const { user, schools } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All E-Test</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">All E-Test</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Class : </label>
                    <select
                      // disabled={medium === '' ? true : false}
                      value={selected_class}
                      className="form-control form-control-sm " name="selected_class"
                      onChange={event => this.changeHandler(event, 'selected_class')}>
                      <option value="All">Select...</option>
                      {selected_classes.map((option, index) => {
                        return (<option key={index} value={option.id}>{option.class_name}</option>)
                      })}
                    </select>
                  </div>
                  <div className="filter-con">
                    <div className="form-group ml-2">
                      <NavLink to="/add_new_test.jsp" className="btn btn-primary btn-sm">Add New <i className="fa fa-plus" /></NavLink>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm">
                    <thead className="text-center">
                      <tr>
                        <th />
                        <th>School Name</th>
                        <th>Test Title</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Total Question</th>
                        <th>Total Marks</th>
                        <th>Action </th>
                      </tr>
                    </thead>

                    <tbody>
                      <tr>
                        <td>1.</td>
                        <td>JyotiPSSS</td>
                        <td>Test One</td>
                        <td>25-5-2020</td>
                        <td>28-5-2020</td>
                        <td>20</td>
                        <td>30</td>
                        <td>
                          <NavLink to="/test_attempt.jsp" className="btn btn-success btn-sm mr-2">Attempt</NavLink>
                          {user.user_category !== "4" ?
                            <>
                              <button type="button" className="btn btn-sm btn-primary mr-2">View</button>
                              <button type="button" className="btn btn-sm btn-warning mr-2">Edit</button>
                              <button type="button" className="btn btn-sm btn-danger mr-2">Remove</button>
                            </>
                            : null}
                        </td>
                      </tr>
                      <tr>
                        <td>2.</td>
                        <td>JyotiPSSS</td>
                        <td>Test One</td>
                        <td>25-5-2020</td>
                        <td>28-5-2020</td>
                        <td>20</td>
                        <td>30</td>
                        <td>
                          <NavLink to="/test_attempt.jsp" className="btn btn-success btn-sm mr-2">Attempt</NavLink>
                          {user.user_category !== "4" ?
                            <>
                              <button type="button" className="btn btn-sm btn-primary mr-2">View</button>
                              <button type="button" className="btn btn-sm btn-warning mr-2">Edit</button>
                              <button type="button" className="btn btn-sm btn-danger mr-2">Remove</button>
                            </>
                            : null}
                        </td>
                      </tr>
                      <tr>
                        <td>2.</td>
                        <td>JyotiPSSS</td>
                        <td>Test One</td>
                        <td>25-5-2020</td>
                        <td>28-5-2020</td>
                        <td>20</td>
                        <td>30</td>
                        <td>
                          <NavLink to="/test_attempt.jsp" className="btn btn-success btn-sm mr-2">Attempt</NavLink>
                          {user.user_category !== "4" ?
                            <>
                              <button type="button" className="btn btn-sm btn-primary mr-2">View</button>
                              <button type="button" className="btn btn-sm btn-warning mr-2">Edit</button>
                              <button type="button" className="btn btn-sm btn-danger mr-2">Remove</button>
                            </>
                            : null}
                        </td>
                      </tr>
                    </tbody>

                  </table>
                </div>
              </div>
            </div>
          </>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  return { user, schools, classes };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
}


export default connect(mapStateToProps, actionCreators)(withRouter(AllETest));