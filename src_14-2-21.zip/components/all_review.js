import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class AllReview extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>All Review</title>
        </Helmet>

        <div className="page-bar d-flex">
          <div className="page-title">All Review</div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tabbable-line">
              {/* <ul className="nav nav-tabs">
                                  <li className="active">
                                      <NavLink to="#tab1" data-toggle="tab"> List View </NavLink>
                                  </li>
                                  <li>
                                      <NavLink to="#tab2" data-toggle="tab"> Grid View </NavLink>
                                  </li>
                              </ul> 
              <ul className="nav customtab nav-tabs" role="tablist">
                <li className="nav-item"><NavLink to="#tab1" className="nav-link active" data-toggle="tab">List
                    View</NavLink></li>
                <li className="nav-item"><NavLink to="#tab2" className="nav-link" data-toggle="tab">Grid
                    View</NavLink></li>
              </ul>
              */}
              <div className="tab-content">
                <div className="tab-pane active fontawesome-demo" id="tab1">
                  <div className="row">
                    <div className="col-md-12">
                      <div className="card card-box sfpage-cover">
                        <div className="card-head d-flex">
                          <header>All Reviews</header>
                          <div className="ml-auto">
                            <NavLink className="fa fa-repeat btn-color box-refresh" to="/" />
                            <NavLink className="t-collapse btn-color fa fa-chevron-down" to="/" />
                            <NavLink className="t-close btn-color fa fa-times" to="/" />
                          </div>
                        </div>
                        <div className="card-body sfpage-body">
                          <div className="row">
                            <div className="col-md-6 col-sm-6 col-6">
                              <div className="btn-group">
                                <NavLink to="add_professor" className="btn btn-info">
                                  Add New <i className="fa fa-plus" />
                                </NavLink>
                              </div>
                            </div>
                            <div className="col-md-6 col-sm-6 col-6">
                              <div className="btn-group pull-right">
                                <NavLink className="btn deepPink-bgcolor  btn-outline dropdown-toggle" data-toggle="dropdown">Tools
                                <i className="fa fa-angle-down" />
                                </NavLink>
                                <ul className="dropdown-menu pull-right">
                                  <li>
                                    <NavLink to="/">
                                      <i className="fa fa-print" /> Print </NavLink>
                                  </li>
                                  <li>
                                    <NavLink to="/">
                                      <i className="fa fa-file-pdf-o" /> Save as
                                    PDF </NavLink>
                                  </li>
                                  <li>
                                    <NavLink to="/">
                                      <i className="fa fa-file-excel-o" />
                                      Export to Excel </NavLink>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                          <div className="table-scrollable">
                            <table className="table table-striped table-bordered table-hover table-sm">
                              <thead>
                                <tr>
                                  <th />
                                  <th> Image</th>
                                  <th> Name</th>
                                  <th> Designation</th>
                                  <th> Stars</th>
                                  <th> Review</th>
                                  <th> Action </th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr >
                                  <td>1.</td>
                                  <td className="profile-pic">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                                  </td>
                                  <td>Radha Mohan Sharma</td>
                                  <td>Village Sarpanch</td>
                                  <td>5</td>
                                  <td>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</td>
                                  <td>
                                    <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                                      Edit
                                    </NavLink>
                                    <button className="btn btn-danger btn-sm">
                                      Del
                                    </button>
                                  </td>
                                </tr>
                                <tr >
                                  <td>2.</td>
                                  <td className="profile-pic">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                                  </td>
                                  <td>Radha Mohan Sharma</td>
                                  <td>Village Sarpanch</td>
                                  <td>5</td>
                                  <td>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</td>
                                  <td>
                                    <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                                      Edit
                                    </NavLink>
                                    <button className="btn btn-danger btn-sm">
                                      Del
                                    </button>
                                  </td>
                                </tr>
                                <tr >
                                  <td>3.</td>
                                  <td className="profile-pic">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                                  </td>
                                  <td>Radha Mohan Sharma</td>
                                  <td>Village Sarpanch</td>
                                  <td>5</td>
                                  <td>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</td>
                                  <td>
                                    <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                                      Edit
                                    </NavLink>
                                    <button className="btn btn-danger btn-sm">
                                      Del
                                    </button>
                                  </td>
                                </tr>
                                <tr >
                                  <td>4.</td>
                                  <td className="profile-pic">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                                  </td>
                                  <td>Radha Mohan Sharma</td>
                                  <td>Village Sarpanch</td>
                                  <td>5</td>
                                  <td>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</td>
                                  <td>
                                    <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                                      Edit
                                    </NavLink>
                                    <button className="btn btn-danger btn-sm">
                                      Del
                                    </button>
                                  </td>
                                </tr>
                                <tr >
                                  <td>2.</td>
                                  <td className="profile-pic">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`}  />
                                  </td>
                                  <td>Radha Mohan Sharma</td>
                                  <td>Village Sarpanch</td>
                                  <td>5</td>
                                  <td>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</td>
                                  <td>
                                    <NavLink to="edit_professor" className="btn btn-primary btn-sm">
                                      Edit
                                    </NavLink>
                                    <button className="btn btn-danger btn-sm">
                                      Del
                                    </button>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="tab-pane" id="tab2">
                  <div className="row">
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Pooja Patel </div>
                              <div className="name-center"> Mathematics </div>
                            </div>
                            <p>A-103, shyam gokul flats, Mahatma Road <br />Mumbai</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Rajesh </div>
                              <div className="name-center"> Science </div>
                            </div>
                            <p>45, Krishna Tower, Near Bus Stop, Satellite, <br />Mumbai
                          </p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Sarah Smith </div>
                              <div className="name-center"> Computer </div>
                            </div>
                            <p>456, Estern evenue, Courtage area, <br />New York</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">John Deo </div>
                              <div className="name-center"> Engineering </div>
                            </div>
                            <p>A-103, shyam gokul flats, Mahatma Road <br />Mumbai</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Jay Soni </div>
                              <div className="name-center"> Music </div>
                            </div>
                            <p>45, Krishna Tower, Near Bus Stop, Satellite, <br />Mumbai
                          </p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Jacob Ryan </div>
                              <div className="name-center"> Commerce </div>
                            </div>
                            <p>456, Estern evenue, Courtage area, <br />New York</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Megha Trivedi </div>
                              <div className="name-center"> Mechanical </div>
                            </div>
                            <p>A-103, shyam gokul flats, Mahatma Road <br />Mumbai</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Rajesh </div>
                              <div className="name-center"> Science </div>
                            </div>
                            <p>45, Krishna Tower, Near Bus Stop, Satellite, <br />Mumbai
                          </p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Sarah Smith </div>
                              <div className="name-center"> Computer </div>
                            </div>
                            <p>456, Estern evenue, Courtage area, <br />New York</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Pooja Patel </div>
                              <div className="name-center"> Mathematics </div>
                            </div>
                            <p>A-103, shyam gokul flats, Mahatma Road <br />Mumbai</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">Rajesh </div>
                              <div className="name-center"> Science </div>
                            </div>
                            <p>45, Krishna Tower, Near Bus Stop, Satellite, <br />Mumbai
                          </p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="card card-box sfpage-cover">
                        <div className="card-body no-padding ">
                          <div className="doctor-profile">
                            <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="doctor-pic"  />
                            <div className="profile-usertitle">
                              <div className="doctor-name">John Deo </div>
                              <div className="name-center"> Engineering </div>
                            </div>
                            <p>A-103, shyam gokul flats, Mahatma Road <br />Mumbai</p>
                            <div>
                              <p><i className="fa fa-phone" /><NavLink to="tel:(123)456-7890"> (123)456-7890</NavLink></p>
                            </div>
                            <div className="profile-userbuttons">
                              <NavLink to="professor_profile" className="btn btn-circle deepPink-bgcolor btn-sm">Read
                              More</NavLink>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(AllReview);