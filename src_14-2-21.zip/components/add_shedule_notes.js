import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import axios from 'axios';
import { connect } from 'react-redux';
import { schoolsAction, examSdulNotesAction, examsCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SHEDULES_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`; 
const CREATE_SHEDULE_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/create.php`;

class AddSheduleNotes extends Component {
    state = {
        shedule_note_arr: [],
        selected_school_index: "",
        schools: [],
        examSdulNotes: [],
        display_notes_arr: [],
        medium_arr: [],
        medium: "",
        current_exam_inx: "",
        school_name: "",
        shedule_note: "",
        exams: [],
        exam_id: "",
        selected_exams: [],
        formIsHalfFilledOut: false,
    }
    changeHandler = (event, fieldName, isCheckbox) => {
        if (fieldName === 'school') {
            const _inx = event.target.value;
            const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
            const _sch_name = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_name : '';
            const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
            sessionStorage.setItem("school_id", _sch_id);
            this.filterExamsCategoriesHandler(_sch_id);
            this.setState({
                school_id: _sch_id,
                school_name: _sch_name,
                medium_arr: _medium,
                medium: (_medium.length === 1 ? _medium[0] : ''),
                selected_school_index: _inx,
                exam_name: '',
                current_exam_inx: '',
                exam_id: '',
                formIsHalfFilledOut: true
            })
        } else if (fieldName === 'current_exam') {
            const _examIdx = event.target.value;
            if (_examIdx !== '') {
                const _exam_id = this.state.selected_exams[_examIdx].id;
                const _exam_name = this.state.selected_exams[_examIdx].cat_name;
                this.setState({
                    exam_name: _exam_name,
                    current_exam_inx: _examIdx,
                    exam_id: _exam_id,
                    formIsHalfFilledOut: true
                })
            } else {
                this.setState({
                    exam_name: '',
                    current_exam_inx: '',
                    exam_id: ''
                })
            }
        } else if (fieldName === 'shedule_note') {
            const _shedule_note = event.target.value;
            if (_shedule_note.length <= 200) {
                this.setState({
                    shedule_note: _shedule_note,
                    formIsHalfFilledOut: true
                })
            }
        } else {
            this.setState({
                [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
                formIsHalfFilledOut: true
            });
        }
    }
    filterExamsCategoriesHandler(school_id) {
        let _school_id = school_id;
        const _exams_cate = this.props.examsCategory.filter((item) => {
            if (_school_id === item.school_id) {
                return item;
            }
        })
        this.setState({
            selected_exams: _exams_cate
        })
    }
    componentDidMount() {
        if (isEmptyObj(this.props.schools)) {
            this.props.getSchools();
        }
        if (isEmptyObj(this.props.examSdulNotes)) {
            this.props.getExamSdulNotes();
        }
        if (isEmptyObj(this.props.examsCategory)) {
           this.props.getExamsCategory();
        }
    }

    // checkAuthentication(obj) {
    //     loadProgressBar();
    //     axios.post(VALIDATE_URL, obj)
    //         .then(res => {
    //             const getRes = res.data;
    //             // sessionStorage.setItem("user", getRes.data);
    //             console.log(getRes);
    //             if (getRes.data) {
    //                 this.setState({
    //                     user: getRes.data,
    //                     group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //                     school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //                     user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //                     session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //                 }, () => {
    //                     this.getSchoolHandler();
    //                     this.getExamsCategories();
    //                     this.getSheduleNotesHandler();
    //                 })
    //             }
    //         }).catch((error) => {
    //             this.props.history.push('/login.jsp');
    //         })
    // }

    // getExamsCategories() {
    //     loadProgressBar();
    //     axios.get(READ_EXAM_CATE)
    //         .then(res => {
    //             const getRes = res.data;
    //             this.setState({
    //                 exams: getRes,
    //                 errorMessages: getRes.message
    //             })
    //             // console.log(this.state);
    //         }).catch((error) => {
    //             // error
    //         })
    // }
    // getSchoolHandler() {
    //     loadProgressBar();
    //     const obj = {
    //         group_id: this.state.group_id
    //     }
    //     axios.post(READ_SCHOOLS, obj)
    //         .then(res => {
    //             const getRes = res.data;
    //             this.setState({
    //                 schools: getRes,
    //                 errorMessages: getRes.message
    //             });
    //             // console.log(this.state);
    //         }).catch((error) => {
    //             // error
    //         })
    // }
    // getSheduleNotesHandler() {
    //     loadProgressBar();
    //     const obj = {
    //         group_id: this.state.group_id,
    //         school_id: this.state.school_id,
    //         user_category: this.state.user_category,
    //         session_year_id: this.state.session_year_id
    //     }
    //     console.log(JSON.stringify(obj));

    //     axios.post(READ_SHEDULES_NOTE, obj)
    //         .then(res => {
    //             const getRes = res.data;
    //             this.setState({
    //                 examSdulNotes: getRes,
    //                 errorMessages: getRes.message
    //             });
    //             // console.log(this.state);
    //         }).catch((error) => {
    //             // error
    //         })
    // }

    confirmBoxSubmit = (event) => {
        event.preventDefault();
        confirmAlert({
            title: 'stay one moment!',
            message: 'Are you sure do you want to submit this.',
            buttons: [
                {
                    label: 'Yes',
                    onClick: () => {
                        this.submitHandler();
                    }
                },
                {
                    label: 'No',
                }
            ]
        });
    };

    submitHandler = () => {
        //e.preventDefault();
        const obj = {
            medium: this.state.medium,
            // group_id: this.state.group_id,
            // session_year_id: this.state.session_year_id,
            school_id: this.state.school_id,
            exam_id: this.state.exam_id,
            notes: this.state.shedule_note,
        }
        console.log(JSON.stringify(obj));

        this.props.createExamSdulNotes(obj);
        // // debugger
        // axios.post(CREATE_SHEDULE_NOTE, obj)
        //     .then(res => {
        //         const getRes = res.data;
        //         Alert.success(getRes.message, {
        //             position: 'bottom-right',
        //             effect: 'jelly',
        //             timeout: 5000, offset: 40
        //         });
        //         this.setState({
        //             shedule_note: "",
        //             formIsHalfFilledOut: false
        //         }, () => { this.getSheduleNotesHandler(); })
        //     }).catch((error) => {
        //         //this.setState({ errorMessages: error });
        //     })
    }
    render() {
        const { selected_school_index, shedule_note, medium, medium_arr,
            selected_exams, school_name, current_exam_inx, formIsHalfFilledOut } = this.state;
        const {user, schools, examSdulNotes, examsCategory} = this.props;
        console.log(this.state);
        return (
            <div className="page-content">
                <Helmet>
                    <title>Add Shedule Notes</title>
                </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
                <div className="page-bar d-flex">
                    <div className="page-title">Add Shedule Notes</div>
                </div>
                {user && schools && examSdulNotes && examsCategory &&
                    <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
                        <div className="card-body">
                            <div className="table-scrollable">
                                <div className="col-md-12">
                                    <div className="form-body form-horizontal">
                                            <div className="form-group row">
                                                <label className="control-label col-md-3">School <span className="required"> * </span>
                                                </label>
                                                <div className="col-md-5">
                                                    <select className="form-control form-control-sm"
                                                        required
                                                        ref='school'
                                                        value={selected_school_index}
                                                        onChange={event => this.changeHandler(event, 'school')}>
                                                        <option value="">Select ...</option>
                                                        {schools.map((item, index) => {
                                                            return (
                                                                <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                                            )
                                                        })}
                                                    </select>
                                                </div>
                                            </div>
                                        <div className="form-group row">
                                            <label className="control-label col-md-3">Medium<span className="required"> * </span>
                                            </label>
                                            <div className="col-md-5">
                                                <select className="form-control form-control-sm"
                                                    required
                                                    ref='medium'
                                                    disabled={medium_arr.length > 1 ? false : true}
                                                    value={medium}
                                                    onChange={event => this.changeHandler(event, 'medium')}>
                                                    <option value="">Select ...</option>
                                                    {medium_arr.map((item, index) => {
                                                        return (
                                                            <option key={index} value={item}>{item}</option>
                                                        )
                                                    })}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="form-group row">
                                            <label className="control-label col-md-3">Exams<span className="required"> * </span>
                                            </label>
                                            <div className="col-md-5">
                                                <select
                                                    value={current_exam_inx}
                                                    disabled={school_name === '' ? true : false}
                                                    className="form-control form-control-sm" name="current_exam"
                                                    onChange={event => this.changeHandler(event, 'current_exam')} >
                                                    <option value="">Select...</option>
                                                    {selected_exams.map((option, index) => {
                                                        return (<option key={index} value={index}>{option.cat_name}</option>)
                                                    })}
                                                </select>
                                            </div>
                                        </div>

                                        <div className="form-group row">
                                            <label className="control-label col-md-3">Shedule Note<span className="required"> * </span>
                                            </label>
                                            <div className="col-md-5">
                                                <textarea name="shedule_note" placeholder="Note"
                                                    className="form-control-textarea form-control" rows={3}
                                                    value={shedule_note}
                                                    onChange={event => this.changeHandler(event, 'shedule_note')} />
                                                <small className="form-text text-muted">Max Length <b><span className="ml-auto text-danger">{shedule_note.length}</span> / 200.</b> </small>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="card border-primary mt-2 h-auto">
                                        <div className="card-header">Notes</div>
                                        <div className="card-body  h-auto">
                                            <ol className="pl-2 m-0 list-inline ml-4 mb-0">
                                                {examSdulNotes.map((item, inx) => {
                                                    return (
                                                        <li className="list-inline-item ml-3" key={inx}><b>{inx + 1}.</b> {item.notes}</li>
                                                    )
                                                })}
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card-footer text-right">
                            <button type="submit" className="btn btn-primary mr-2">Submit</button>
                            <NavLink to="/shedule_notes.jsp" className="btn btn-danger">Back</NavLink>
                        </div>
                    </form>
                }
            </div>
        )
    }
}
function mapStateToProps(state) {
    const { item: user } = state.authentication;
    const { item: schools } = state.schools;
    const { item: examSdulNotes } = state.examSdulNotes;
    const { item: examsCategory } = state.examsCategory;
    return { user, schools, examSdulNotes, examsCategory };
}

const actionCreators = {
    getSchools: schoolsAction.getSchools,
    getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
    createExamSdulNotes: examSdulNotesAction.create,
    getExamsCategory: examsCategoryAction.getExamsCategory,
   
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddSheduleNotes));