import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import FrontIndexAriticle from './front_index_article';
import FrontIndexWelcome from './front_index_welcome';
import FrontIndexProfessional from './front_index_professional';
import FrontIndexEvents from './front_index_events';
import FrontIndexImageGallery from './front_index_image_gallery';
import { defaultGroupActions } from '../_actions';
import { isEmptyObj } from '../utility/utilities';
 
class FrontIndexPage extends Component {
   
   componentDidMount() {
      if (isEmptyObj(this.props.group)) {
         this.props.getDefaultGroup();
      }
   };
   render() {
      const { group } = this.props;
      //console.log(_state);
      return ( 
         <div className="cover">
            <FrontIndexAriticle />
            {group &&
               <FrontIndexWelcome
                  wel_mes_title={group.wel_mes_title}
                  wel_mes={group.wel_mes}
               />
            }
            <FrontIndexProfessional />
            <FrontIndexEvents />
            <FrontIndexImageGallery />
            {/*<FrontIndexCounter />
            <FrontIndexGallery />
            <FrontIndexStudents />*/}
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: group } = state.defaultGroup;
   return { group };
}

const actionCreators = {
  // getDefaultGroup: defaultGroupActions.getDefaultGroup,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexPage));