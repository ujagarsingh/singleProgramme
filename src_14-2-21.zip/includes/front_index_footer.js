import React, { Component } from 'react';
import ImageLoader from "../utility/ImageLoader/index";

class FrontIndexFooter extends Component {
   render() {
      const { group } = this.props;
      const { logo, org_name, mobile, email, address } = group;
      //console.log(_state);
      return (
         <footer className="footer_front">
            <div className="footer_inner">
               <div className="container">
                  <div className="row">
                     <div className="col-sm-12">
                        <h3 className="d-flex"><span className="mr-2">
                           <ImageLoader
                              src={`${process.env.PUBLIC_URL}`+logo}
                              fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/logo.png`}
                           />
                        </span> {org_name}</h3>
                        <ul className="list-unstyled">
                           <li><span><i className="fa fa-phone" /></span>{mobile}</li>
                           <li><span><i className="fa fa-envelope" /></span>{email}</li>
                           <li><span><i className="fa fa-map-marker" /></span>{address}</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
      )
   }
}
export default FrontIndexFooter;