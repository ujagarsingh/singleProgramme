import React, { Component } from 'react';
import { withRouter } from 'react-router';

class SingleReportCard extends Component {
   state = {
      item: '',
      exam_category_arr: '',
      effective_exam: '',
      nonEffective_exam: '',
      isEffective: true,
      isNonEffective: true,
   }
   componentDidMount() {
      const stu_result = this.calculateMarksForReportCardHandler(this.props.item.exam_type);
      const exam_category_arr = this.props.exam_category_arr;

      // console.log(exam_category_arr);
      this.setState({
         item: { ...this.props.item, stu_result },
         exam_category_arr: exam_category_arr
      }, () => { this.setExamsData() })
   };
   setExamsData() {
      const _data = this.state.item;
      let effective_exam = '';
      let nonEffective_exam = '';

      _data.exam_type.forEach(element => {
         if (element.id == 1) {
            effective_exam = element
         } else if (element.id == 2) {
            nonEffective_exam = element
         }
      });

      this.setState({
         effective_exam, nonEffective_exam
      })
   }
   calculateMarksForReportCardHandler(getData) {
      // console.log(getData);
      ////console.log(JSON.stringify(subject));
      let _total_max_marks = 0;
      let _total_obt_marks = 0;
      getData.map((examType) => {

         examType.subjects.map((item) => {
            let max_marks = 0;
            let mks_obtain = 0;
            item.exams_cat.map((item_e, idx) => {
               max_marks += (item_e.max_marks !== '') ? parseInt(item_e.max_marks) : 0;
               mks_obtain += (item_e.marks_obtain !== '') ? parseInt(item_e.marks_obtain) : 0;
            })

            _total_max_marks += max_marks;
            _total_obt_marks += mks_obtain;

            item['t_mm'] = max_marks;
            item['t_mo'] = mks_obtain;
            return item;
         })
         ////console.log(subject);

      })
      const _get_rteurn = this.getReport(_total_max_marks, _total_obt_marks);
      return _get_rteurn;
   }

   getReport(max_marks, otn_marsk) {

      let grade = "";
      let result = "";

      let totalMarks = otn_marsk;
      let averageMarks = (otn_marsk / max_marks) * 100;
      switch (
      (averageMarks >= 86 && averageMarks <= 100) ? 1 :
         (averageMarks >= 71 && averageMarks <= 85) ? 2 :
            (averageMarks >= 51 && averageMarks <= 70) ? 3 :
               (averageMarks >= 31 && averageMarks <= 50) ? 4 : 5
      ) {
         case 1: grade = "A"; /* result = "First Class"; */ break;
         case 2: grade = "B"; /* result = "Second Class"; */ break;
         case 3: grade = "C"; /* result = "Third Class"; */ break;
         case 4: grade = "D"; /* result = "Third Class"; */ break;
         case 5: grade = "E"; /* result = "Fail"; */ break;
      }

      let stu_result = {
         total_max_marks: max_marks,
         total_obt_marks: totalMarks,
         total_avg_marks: averageMarks,
         // student_result: result,
         student_grade: grade
      }
      return stu_result;
   }

   render() {
      const { item, nonEffective_exam, effective_exam } = this.state;
      const { sch_name, selected_sheet_type, sch_address, stu_class, selected_exam } = this.props;
      // console.log(this.props);
      // console.log(this.state);
      return (

         <div className="single-marksheet row">
            {item !== '' ?
               <div className="w-100">
                  {(selected_sheet_type === 'Marksheet') ?
                     <div className="col-md-12">
                        {/* <h3 className="text-center"><strong>{sch_name} </strong> <small> ({sch_address})</small></h3> */}
                        <table className="table p-0 mb-1">
                           <tbody>
                              <tr>
                                 {/* <td className=" p-0 border-0" >
                                    <img alt="SmartPSP" src="/assets/images/logo.png" width="90" className="rounded-circle img-responsive" />
                                 </td> */}
                                 <td className=" p-0  border-0">
                                    <div className="d-flex">
                                       <table className="table-sm table-bordered">
                                          <tbody>
                                             <tr>
                                                <td className="p-1">NAME : </td>
                                                <td className="p-1"><strong>{item.student_name}</strong></td>
                                                <td className="p-1"> ROLL NO.</td>
                                                <td className="p-1">{item.roll_number}</td>
                                             </tr>
                                             <tr>
                                                <td className="p-1">MOTHER NAME</td>
                                                <td className="p-1"><strong>{item.mother_name} </strong></td>
                                                <td className="p-1">DOB</td>
                                                <td className="p-1"><strong>{item.dob}</strong></td>
                                             </tr>
                                             <tr>
                                                <td className="p-1">FATHER NAME</td>
                                                <td className="p-1"><strong>{item.father_name} </strong></td>
                                                <td className="p-1">CLASS</td>
                                                <td className="p-1"><strong>{stu_class}</strong></td>
                                             </tr>
                                          </tbody>
                                       </table>
                                       <div className="img-thumbnail ml-auto ">
                                          {item.student_image !== '' ?
                                             < img src={`${process.env.PUBLIC_URL}` + item.student_image} width="120" className="img-responsive" alt={item.student_name} />
                                             : (item.gender === 'Boy' ?
                                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} width="120" className="img-responsive" />
                                                :
                                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} width="120" className="img-responsive" />)
                                          }

                                       </div>
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     : null}
                  {(selected_sheet_type === 'Information') ?
                     <div className="col-md-12">
                        <h3 className="text-center"><strong>{item.student_name} </strong> <small> (Roll No.: {item.roll_number})</small></h3>
                     </div>
                     : null}
                  <div className="col-md-12">
                     <div className="table-responsive m-t-40">
                        {(effective_exam != '') ?
                           <table className="table table-hover table-bordered table-sm">
                              <thead className="thead-light">
                                 <tr>
                                    <th rowSpan={2} className="text-center"></th>
                                    <th rowSpan={2} className="text-center ms-width">SUBJECT</th>
                                    {effective_exam.subjects[0].exams_cat.map((item, izx) => {
                                       return (
                                          <th key={izx} rowSpan={2} className="text-center">
                                             <strong>{item.exam_name}</strong>
                                             <table className="table m-0">
                                                <tbody>
                                                   <tr>
                                                      <td width="50%" className="p-1">MAX</td>
                                                      <td className="p-1">OBTAIN</td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </th>
                                       )
                                    })}
                                    {(selected_exam.length > 1) ?
                                       <th colSpan={2} className="text-center">
                                          <strong>TOTAL</strong>
                                          <table className="table m-0">
                                             <tbody>
                                                <tr>
                                                   <td width="50%" className="p-1">MAX</td>
                                                   <td className="p-1">OBTAIN</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </th>
                                       : null}
                                 </tr>
                              </thead>
                              <tbody>
                                 {effective_exam.subjects.map((item_c, index) => {
                                    return (
                                       <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-left ms-width">
                                             <span className={(item_c.sub_lavel === '11') ? "pl-3" : ""}>
                                                {item_c.sub_name}
                                             </span>
                                          </td>
                                          {(item_c.exams_cat.length > 0) ? item_c.exams_cat.map((item_e, index) => {
                                             return (
                                                <td key={index} className="text-right das">
                                                   {(item_e.max_marks != '0') ?
                                                      <table className="table m-0" data-exam={item_e.exam_name}>
                                                         <tbody>
                                                            {(item_c.sub_lavel !== '2') ?
                                                               (<tr>
                                                                  <td width="50%" className="p-1">{item_e.max_marks}</td>
                                                                  <td className="p-1">{item_e.marks_obtain}</td>
                                                               </tr>
                                                               ) : (
                                                                  <tr className="invisible">
                                                                     <td width="50%" className="p-1">&nbsp;</td>
                                                                     <td className="p-1">&nbsp;</td>
                                                                  </tr>
                                                               )}
                                                         </tbody>
                                                      </table>
                                                      : null}
                                                </td>
                                             )
                                          }) : null}
                                          {(selected_exam.length > 1) ?
                                             <>
                                                <td className="text-right">
                                                   {(item_c.sub_lavel === 2 || item_c.t_mm === 0) ? '' : item_c.t_mm}
                                                </td>
                                                <td className="text-right">
                                                   <strong>{(item_c.sub_lavel === 2 || item_c.t_mo === 0) ? '' : item_c.t_mo}</strong>
                                                </td>
                                             </>
                                             : null}
                                       </tr>

                                    )
                                 })}
                              </tbody>
                           </table>
                           : null}
                        {(nonEffective_exam != '' && selected_sheet_type === 'Marksheet') ?
                           <table className="table table-hover table-bordered table-sm">
                              <thead className="thead-light">
                                 <tr>
                                    <th rowSpan={2} className="text-center"></th>
                                    <th rowSpan={2} className="text-center ms-width">SUBJECT</th>
                                    {nonEffective_exam.subjects[0].exams_cat.map((item, izx) => {
                                       return (
                                          <th key={izx} rowSpan={2} className="text-center">
                                             <strong>{item.exam_name}</strong>
                                             <table className="table m-0">
                                                <tbody>
                                                   <tr>
                                                      <td width="50%" className="p-1">MAX</td>
                                                      <td className="p-1">OBTAIN</td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </th>
                                       )
                                    })}
                                    {(selected_exam.length > 1) ?
                                       <th colSpan={2} className="text-center">
                                          <strong>TOTAL</strong>
                                          <table className="table m-0">
                                             <tbody>
                                                <tr>
                                                   <td width="50%" className="p-1">MAX</td>
                                                   <td className="p-1">OBTAIN</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </th>
                                       : null}
                                 </tr>
                              </thead>
                              <tbody>
                                 {nonEffective_exam.subjects.map((item_c, index) => {
                                    return (
                                       <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-left ms-width">
                                             <span className={(item_c.sub_lavel === '11') ? "pl-3" : ""}>
                                                {item_c.sub_name}
                                             </span>
                                          </td>
                                          {(item_c.exams_cat.length > 0) ? item_c.exams_cat.map((item_e, index) => {
                                             return (
                                                <td key={index} className="text-right das">
                                                   {(item_e.max_marks != '0') ?
                                                      <table className="table m-0" data-exam={item_e.exam_name}>
                                                         <tbody>
                                                            {(item_c.sub_lavel !== '2') ?
                                                               (<tr>
                                                                  <td width="50%" className="p-1">{item_e.max_marks}</td>
                                                                  <td className="p-1">{item_e.marks_obtain}</td>
                                                               </tr>
                                                               ) : (
                                                                  <tr className="invisible">
                                                                     <td width="50%" className="p-1">&nbsp;</td>
                                                                     <td className="p-1">&nbsp;</td>
                                                                  </tr>
                                                               )}
                                                         </tbody>
                                                      </table>
                                                      : null}
                                                </td>
                                             )
                                          }) : null}
                                          {(selected_exam.length > 1) ?
                                             <>
                                                <td className="text-right">
                                                   {(item_c.sub_lavel === 2 || item_c.t_mm === 0) ? '' : item_c.t_mm}
                                                </td>
                                                <td className="text-right">
                                                   <strong>{(item_c.sub_lavel === 2 || item_c.t_mo === 0) ? '' : item_c.t_mo}</strong>
                                                </td>
                                             </>
                                             : null}
                                       </tr>

                                    )
                                 })}
                              </tbody>
                           </table>
                           : null}


                        <div className="d-flex align-items-end">
                           {(selected_sheet_type === 'Marksheet') ?
                              <table width="450" className="table-sm table-bordered table-info">
                                 <tbody>
                                    <tr>
                                       <td className="p-1">GRADE : </td>
                                       <td className="p-1"><strong>{item.stu_result.student_grade}</strong></td>
                                       <td className="p-1">RESULT :</td>
                                       <td className="p-1"><strong>{ /* item.stu_result.student_result */} </strong></td>
                                    </tr>
                                    <tr>
                                       <td className="p-1">DOB</td>
                                       <td colSpan="3" className="p-1"><strong>10-JULY-1995</strong></td>
                                    </tr>
                                 </tbody>
                              </table>
                              : null}
                           <div className="ml-auto p-1"><b>AUTHENTIC SIGNATORY</b></div>
                        </div>
                     </div>
                  </div>
               </div>
               : null}
         </div>

      )
   }
}
export default withRouter(SingleReportCard);