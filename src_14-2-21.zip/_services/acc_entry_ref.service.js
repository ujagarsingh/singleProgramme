// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const accEntryRefs = {
    readAccEntryRef,
    update,
    delete: _delete
};

function readAccEntryRef() {
    loadProgressBar();
    const url = USER_URL + 'acc_entry_refs/read.php';
    return Axios.post(url, { ...authHeader() }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_entry_refs/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'acc_entry_refs/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

