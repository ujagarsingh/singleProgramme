import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultGroupActions } from '../_actions';

// Components
import FrontIndexHeaderTop from '../includes/front_index_header_top.js';
import FrontIndexSlider from '../includes/front_index_slider.js';
import FrontIndexFooter from '../includes/front_index_footer.js';


class FrontLayout extends Component {

   componentDidMount() {
      if (isEmptyObj(this.props.group)) {
         this.props.getDefaultGroup();
      }

   };
   render() {
      const { children, group } = this.props;
      return (
         <div>
            {group &&
               <>
                  <header id="header">
                     <FrontIndexHeaderTop
                        group={group} />
                     <FrontIndexSlider />
                  </header>
                  {children}
                  <FrontIndexFooter
                     group={group} />
               </>
            }
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: group } = state.defaultGroup;
   return { group };
}

const actionCreators = {
   getDefaultGroup: defaultGroupActions.getDefaultGroup,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontLayout));
