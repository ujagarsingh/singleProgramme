import React, { Component } from "react";
import { withRouter } from "react-router";
import { Route } from "react-router-dom";
import FrontLayoutInner from "./FrontLayoutInner";
class FrontLayoutInnerRoute extends Component {
  render() {
    const { component: Component, ...rest } = this.props;
    return (
      <Route {...rest} render={matchProps => (
        <FrontLayoutInner>
          <Component {...matchProps} />
        </FrontLayoutInner>
      )} />
    )
  }
}

export default withRouter(FrontLayoutInnerRoute);
