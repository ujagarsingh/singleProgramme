import { feeCategoryStructureConstants } from '../_constants';

export function feeCategoryStructure(state = {}, action) {
  switch (action.type) {
    case feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_SUCCESS:
      return {
        item: action.response
      };
    case feeCategoryStructureConstants.FEE_CATEGORY_STRUCTURE_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}