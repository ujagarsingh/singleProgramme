import { portalClassesConstants } from '../_constants';

export function portalClasses(state = {}, action) {
  switch (action.type) {
    case portalClassesConstants.PORTAL_CLASSES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case portalClassesConstants.PORTAL_CLASSES_SUCCESS:
      return {
        item: action.response
      };
    case portalClassesConstants.PORTAL_CLASSES_FAILURE:
      return {
        error: action.error
      };
 

    default:
      return state
  }
}