import { marksOfaClassConstants } from '../_constants';

export function marksOfaClass(state = {}, action) {
  switch (action.type) {
    case marksOfaClassConstants.MARKS_OF_ACLASS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case marksOfaClassConstants.MARKS_OF_ACLASS_SUCCESS:
      return {
        item: action.response
      };
    case marksOfaClassConstants.MARKS_OF_ACLASS_FAILURE:
      return {
        error: action.error
      };
      
    default:
      return state
  }
}