import { professionalConstants } from '../_constants';
import { professionalService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const professionalAction = {
    getProfessional
};

function getProfessional() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        professionalService.getProfessional()
            .then(
                response => {
                    dispatch(success(response.data.prof_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: professionalConstants.PROFESSIONAL_REQUEST } }
    function success(response) { return { type: professionalConstants.PROFESSIONAL_SUCCESS, response } }
    function failure(error) { return { type: professionalConstants.PROFESSIONAL_FAILURE, error } }
}
 