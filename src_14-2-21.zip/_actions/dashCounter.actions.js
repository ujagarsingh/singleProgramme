import { dashCounterConstants } from '../_constants';
import { dashCounterService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const dashCounterAction = {
    getDashCounter
};

function getDashCounter() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        dashCounterService.getDashCounter()
            .then(
                response => {
                    dispatch(success(response.data.dash_counter));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: dashCounterConstants.DASH_COUNTER_REQUEST } }
    function success(response) { return { type: dashCounterConstants.DASH_COUNTER_SUCCESS, response } }
    function failure(error) { return { type: dashCounterConstants.DASH_COUNTER_FAILURE, error } }
}
 