import { accEntryRefsConstants } from '../_constants';
import { accEntryRefs } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accEntryRefActions = {
    readAccEntryRef,
    update,
    delete : _delete
};

 

function readAccEntryRef() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryRefs.readAccEntryRef()
            .then(
                response => {
                    dispatch(success(response.data.acc_entry_adjustment),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accEntryRefsConstants.READ_ENTRY_REF_REQUEST } }
    function success(response) { return { type: accEntryRefsConstants.READ_ENTRY_REF_SUCCESS, response } }
    function failure(error) { return { type: accEntryRefsConstants.READ_ENTRY_REF_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryRefs.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryRefsConstants.UPDATE_ENTRY_REF_REQUEST } }
    function success(response) { return { type: accEntryRefsConstants.UPDATE_ENTRY_REF_SUCCESS, response } }
    function failure(error) { return { type: accEntryRefsConstants.UPDATE_ENTRY_REF_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryRefs.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryRefsConstants.DELETE_ENTRY_REF_REQUEST } }
    function success(response) { return { type: accEntryRefsConstants.DELETE_ENTRY_REF_SUCCESS, response } }
    function failure(error) { return { type: accEntryRefsConstants.DELETE_ENTRY_REF_FAILURE, error } }
}
