import { incomeProviderConstants } from '../_constants';
import { incomeProviderService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const incomeProviderAction = {
    getIncomeProvider
};

function getIncomeProvider() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        incomeProviderService.getIncomeProvider()
            .then(
                response => {
                    dispatch(success(response.data.income_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: incomeProviderConstants.INCOME_PROVIDER_REQUEST } }
    function success(response) { return { type: incomeProviderConstants.INCOME_PROVIDER_SUCCESS, response } }
    function failure(error) { return { type: incomeProviderConstants.INCOME_PROVIDER_FAILURE, error } }
}
 