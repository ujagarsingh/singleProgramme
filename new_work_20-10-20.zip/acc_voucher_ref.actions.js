import { accVoucherRefConstants } from '../_constants';
import { accVoucherRefService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accVoucherRefActions = {
    getAccVoucherRef, 
};

function getAccVoucherRef() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherRefService.getAccVoucherRef()
            .then(
                response => {
                    dispatch(success(response.data.acc_voucher_ref));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accVoucherRefConstants.ACC_VOUCHER_REQUEST } }
    function success(response) { return { type: accVoucherRefConstants.ACC_VOUCHER_SUCCESS, response } }
    function failure(error) { return { type: accVoucherRefConstants.ACC_VOUCHER_FAILURE, error } }
}
   
 