<?php
class AccGroup{
 
    // database connection and table name
    private $conn;
    private $table_name = "acc_ledger_entry";
    private $table_school = "school_info";
	
    // object properties
	public $id; 
    public $school_id;
    public $vchr_ref_id;
    public $ledger_id;
    public $ledger_type;
    public $ledger_folio;
    public $op_balance;
    public $op_type;
    public $tr_amount;
    public $tr_type;
    public $cl_balance;
    public $cl_type;
    public $session_year_id;
    public $server_date_time;
    public $group_code;
	
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	// `id`, `school_id`, `vchr_ref_id`, `ledger_id`, `ledger_type`, `ledger_folio`, `op_balance`, `op_type`, `tr_amount`, `tr_type`, `cl_balance`, `cl_type`, `session_year_id`, `server_date_time`, `group_code`
// read Classes
function read(){
    
    // select all query
    $query = "SELECT I.*, S.sch_name, S.sch_medium FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
 
    return $stmt;
}
 
// used when filling up the update product form
function readOne(){
 
    // query to read single record
     
    $query = "SELECT I.*, S.sch_name,  S.sch_name, S.sch_medium FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        WHERE
                I.ledger_folio = ?
            LIMIT
                0,1";

	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->ledger_folio);
    // execute query
    $stmt->execute();
 
    return $stmt;
  
 
}

   
 

}



 