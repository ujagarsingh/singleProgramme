import { accLedgerEntryConstants } from '../_constants';
import { accLedgerEntryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accLedgerEntryActions = {
    getAccLedgerEntry,
    getAccLedgerEntryByFolio,
};

function getAccLedgerEntry() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerEntryService.getAccLedgerEntry()
            .then(
                response => {
                    dispatch(success(response.data.acc_ledger_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accLedgerEntryConstants.ACC_LEDGER_REQUEST } }
    function success(response) { return { type: accLedgerEntryConstants.ACC_LEDGER_SUCCESS, response } }
    function failure(error) { return { type: accLedgerEntryConstants.ACC_LEDGER_FAILURE, error } }
}
   

function getAccLedgerEntryByFolio() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerEntryService.getAccLedgerEntryByFolio()
            .then(
                response => {
                    dispatch(success(response.data.acc_ledger_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_REQUEST } }
    function success(response) { return { type: accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_SUCCESS, response } }
    function failure(error) { return { type: accLedgerEntryConstants.ACC_LEDGER_BYFOLIO_FAILURE, error } }
}
   