import { accCCEntryConstants } from '../_constants';
import { accCCEntryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accCCEntryActions = {
    getAccCCEntry,
    getAccCCEntryByFolio,
};

function getAccCCEntry() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accCCEntryService.getAccCCEntry()
            .then(
                response => {
                    dispatch(success(response.data.acc_group_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accCCEntryConstants.ACC_CC_REQUEST } }
    function success(response) { return { type: accCCEntryConstants.ACC_CC_SUCCESS, response } }
    function failure(error) { return { type: accCCEntryConstants.ACC_CC_FAILURE, error } }
}
   

function getAccCCEntryByFolio() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accCCEntryService.getAccCCEntryByFolio()
            .then(
                response => {
                    dispatch(success(response.data.acc_group_entry));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accCCEntryConstants.ACC_CC_BYFOLIO_REQUEST } }
    function success(response) { return { type: accCCEntryConstants.ACC_CC_BYFOLIO_SUCCESS, response } }
    function failure(error) { return { type: accCCEntryConstants.ACC_CC_BYFOLIO_FAILURE, error } }
}
   