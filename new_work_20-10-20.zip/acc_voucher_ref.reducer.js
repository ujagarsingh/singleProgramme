import { accVoucherRefConstants } from '../_constants';

export function accVoucherRef(state = {}, action) {
  switch (action.type) {
    case accVoucherRefConstants.ACC_VOUCHER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accVoucherRefConstants.ACC_VOUCHER_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accVoucherRefConstants.ACC_VOUCHER_FAILURE:
      return {
        error: action.error
      };
   

    default:
      return state
  }
}