var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
  $scope.newObj = [{
	  "id" : 1,
	  "name" : "ujagar",
	  "dob" : "04-07-1977"
  }]
  $scope.amount = 0;
  
  $scope.$watch('amount',function(newVal, oldVal){
	  console.log(newVal);
	  console.log("-----");
	  console.log(oldVal);
  })
  $scope.funSubmitAmo = function(){
	  console.log($scope.amount)
  };
  $scope.xyz = function(){
	  console.log($scope.amount)
	  //$scope.$digest()
  };
});