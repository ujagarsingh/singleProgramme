var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
  $scope.newObj = [
	  {  "id" : 1,	  "name" : "ujagar", "salary" : 11000  },
	  {	 "id" : 2,	  "name" : "singh",	 "salary" : 15000  },
	  {	 "id" : 3,	  "name" : "meena",	 "salary" : 10000  }
  ]
  //$scope.modal = {'amount':0}
  
  $scope.credits = $scope.newObj.reduce(function(acc, object) {
    acc[object.id] = { amount: 0 };

    return acc;
  }, {});
  
  $scope.funSubmitAmo = function(obj){
	  var balance = obj.salary - Number($scope.credits[obj.id].amount)
	  alert(obj.name + ' balance is : ' + balance);
  };
  
});