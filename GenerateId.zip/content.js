chrome.runtime.sendMessage({todo: "showPageAction"});
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    if (request.todo == "generateId"){





 
    function addUniqeId(input, label_txt) {
        label_txt = label_txt.split(' ').join('_');
        label_txt = label_txt.split('/').join('_');
        label_txt = label_txt.toLowerCase();
        input.setAttribute('id', label_txt);
    }

    function createLink() {
        const _path = document.location.href;
        const _path_arr = _path.split('/');
        const _page_name = _path_arr[_path_arr.length - 1];
        const _page_name_class = _page_name.split('.')[0];
		const _page_class = _page_name_class.split('-').join('_');
        const _data_child = Array.prototype.slice.call(document.body.children);
        _data_child.map((item) => {
            if (item.nodeName !== 'ROUTER-OUTLET') {
                item.classList.add(_page_class);
            }
        })
        const _data = document.body.innerHTML;
        var url = "data:text/plain;charset=utf-8," + encodeURIComponent(_data);
        var _link = document.createElement('a');
        var t = document.createTextNode("download");
        _link.appendChild(t);
        _link.setAttribute("id", "download_link");
        _link.setAttribute("href", url);
        _link.setAttribute('style', 'height:100px;display:block');
        _link.setAttribute("download", _page_name);
        document.body.prepend(_link);
    }

    function myFunction() {
        var copyText = document.getElementById("myInput");
        copyText.select();
        document.execCommand("copy");
        console.log(copyText.value);
    }

    function copy(target) {
        var _inp = document.createElement("INPUT");
        _inp.setAttribute("type", "text");
        _inp.setAttribute('style', 'opacity:.1');
        _inp.setAttribute("id", "myInput");
        _inp.setAttribute("value", target);
        var _btn = document.createElement("INPUT");
        _btn.setAttribute("type", "button");
        _btn.setAttribute('style', 'opacity:.1');
        _btn.setAttribute("id", "myBtn");
        _btn.setAttribute("value", "Copy text");

        document.body.appendChild(_inp);
        document.body.appendChild(_btn);

        const _btnfun = document.getElementById('myBtn');
        _btnfun.addEventListener("click", function() {
            myFunction();
        });

        const _btn_1 = document.getElementById('download_link');
        _btn_1.addEventListener("click", function() {
            document.getElementById('myBtn').click();
        });
    }

    function callFinal() {
        let _target = null;
        const _url = window.location.href;
        const _target_1 = _url.substring(0, _url.lastIndexOf('/') + 1);
        if (_target_1.includes('///')) {
            const _target_2 = _target_1.split('///')[1];
            _target = _target_2.split('/').join('\\');
        } else {
            _target = 'C:/Users/t127/Desktop/';
        }
        createLink();
        copy(_target);

    }

    function applyId() {
        const _all_inputs = Array.prototype.slice.call(document.querySelectorAll('input, select, button'));

        let _inside_tbl = document.querySelectorAll('table');
        let _table_inputs = [];
        _inside_tbl.forEach(function(item) {
            _table_inputs = Array.prototype.slice.call(item.querySelectorAll('input, select, button'));
        });

        const _inputs = _all_inputs.filter(function(el) {
            return _table_inputs.indexOf(el) < 0;
        });
        let _input_id_array = [];
        _inputs.forEach(function(item, idx) {
            if (item.id !== '') {
                _input_id_array.push(item.id);
            }
        })
        _input_id_array.sort();

        let _id_array = [{ 'name': 'inp', 'lastid': 0 }, { 'name': 'chk', 'lastid': 0 }, { 'name': 'btn', 'lastid': 0 }, { 'name': 'oth', 'lastid': 0 }];
        _input_id_array.forEach(function(item, idx) {
                let item_arr = item.split('_');
                if (item_arr[0] == 'btn' || item_arr[0] == 'inp' || item_arr[0] == 'chk') {
                    const obj = {};
                    obj['type'] = item_arr[0];
                    obj['lastid'] = item_arr[1];
                    _id_array.filter((item, index) => {
                        if (item.name === item_arr[0]) {
                            item.lastid = item_arr[1];
                        }
                    })

                }
            })
            //console.log(_id_array);
        let _ild = 0; // input, select last id
        let _cld = 0; // checkbox last id
        let _bld = 0; // button last id
        let _old = 0; // other last id

        _id_array.filter((item) => {
            if (item.name == 'inp') {
                _ild = item.lastid;
            } else if (item.name == 'chk') {
                _cld = parseInt(item.lastid);
            } else if (item.name == 'btn') {
                _bld = parseInt(item.lastid);
            } else {
                _oth = parseInt(item.lastid);
            }
        })
        let _inp_array = [];
        let _chk_array = [];
        let _btn_array = [];
        let _oth_array = [];

        _inputs.map((item) => {
            if (item.getAttribute('id') === '' || item.getAttribute('id') === null) {
                if (item.type == "text" || item.nodeName == "SELECT") {
                    _inp_array.push(item);
                } else if (item.type == "checkbox") {
                    _chk_array.push(item);
                } else if (item.type == "button" || item.type == "submit" || item.type == "reset") {
                    _btn_array.push(item);
                } else {
                    _oth_array.push(item);
                }
            }
        })

        _inp_array.map((item, inx) => {
            const idx = parseInt(_ild) + inx + 1;
            let _label_txt = item.parentElement.parentElement.querySelector('label').textContent;
            let str_arr = _label_txt.split(/(\s+)/).filter(e => e.trim().length > 0);
            let _finaltxt = str_arr.slice(0, 3).toString().split(',').join('_');;
            addUniqeId(item, 'inp' + '_' + idx + '_' + _finaltxt.toString());
        })
        _chk_array.map((item, inx) => {
            const idx = parseInt(_cld) + inx + 1;
            let _label_txt = item.parentElement.querySelector('label').textContent;
            let str_arr = _label_txt.split(/(\s+)/).filter(e => e.trim().length > 0);
            let _finaltxt = str_arr.slice(0, 3).toString().split(',').join('_');;
            addUniqeId(item, 'chk' + '_' + idx + '_' + _finaltxt);
        })
        _btn_array.map((item, inx) => {
            const idx = parseInt(_bld) + inx + 1;
            let _label_txt = item.textContent;
            let str_arr = _label_txt.split(/(\s+)/).filter(e => e.trim().length > 0);
            let _finaltxt = str_arr.slice(0, 3).toString().split(',').join('_');;
            addUniqeId(item, 'btn' + '_' + idx + '_' + _finaltxt.toString());
        })
        _oth_array.map((item, inx) => {
            const idx = parseInt(_old) + inx + 1;
            let _label_txt = item.textContent;
            let str_arr = _label_txt.split(/(\s+)/).filter(e => e.trim().length > 0);
            let _finaltxt = str_arr.slice(0, 3).toString().split(',').join('_');;
            addUniqeId(item, 'oth' + '_' + idx + '_' + _finaltxt.toString());
        })


        setTimeout(function() {
            callFinal();
        }, 100)
    }

    applyId();
	
	
	
	
	
	
	
    }
		
});

