import { examsTypeConstants } from '../_constants';
import { examsTypeService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examsTypeAction = {
    getExamsType
};

function getExamsType() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsTypeService.getExamsType()
            .then(
                response => {
                    dispatch(success(response.data.exam_type_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsTypeConstants.EXAMS_TYPE_REQUEST } }
    function success(response) { return { type: examsTypeConstants.EXAMS_TYPE_SUCCESS, response } }
    function failure(error) { return { type: examsTypeConstants.EXAMS_TYPE_FAILURE, error } }
}
