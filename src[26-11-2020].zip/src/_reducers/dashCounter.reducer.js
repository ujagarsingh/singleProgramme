import { dashCounterConstants } from '../_constants';

export function dashCounter(state = {}, action) {
    switch (action.type) {
        case dashCounterConstants.DASH_COUNTER_REQUEST:
            return {
                loading: true,
                //items : action.users
            };
        case dashCounterConstants.DASH_COUNTER_SUCCESS:
            return {
                loading: false,
                item: action.response
            };
        case dashCounterConstants.DASH_COUNTER_FAILURE:
            return {
                error: action.error
            };


        default:
            return state
    }
}