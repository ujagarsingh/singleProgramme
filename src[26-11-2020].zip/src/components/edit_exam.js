import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import DatePicker from 'react-date-picker';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, examsTypeAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_EXAM = `http://schools.rajpsp.com/api/exam/read_one.php`;
// const UPDATE_EXAM = `http://schools.rajpsp.com/api/exam/update.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
// const READ_EXAM_CAT = `http://schools.rajpsp.com/api/exam_type/read.php`;

class EditExam extends Component {
  state = {
    examsType: [],
    exam_cat_id: '',
    selected_exam_cat_inx: '',
    id: '',
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    medium: '',
    sft_classes: [],
    selected_classes: [],
    class_id: '',
    exam_name: '',
    exam_priority: '',
    exam_start: new Date(),
    exam_end: new Date(),
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.filterClassesOnSchool(_sch_id, this.state.group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'exam_category') {
      const _id = event.target.value;
      this.setState({
        exam_cat_id: _id,
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      //selected_subjects: ''
    })
  }
  examStartDate = (feeDate) => {
    this.setState({ exam_start: feeDate });
    this.to.openCalendar();
  };
  examEndDate = (feeDate) => {
    this.setState({ exam_end: feeDate });
  };

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.examsType)) {
      this.props.getExamsType();
    }
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.selected_item;
    // console.log(obj);
    // debugger;
    const _exam_start = new Date(this.state.exam_start);
    const _exam_end = new Date(this.state.exam_end);

    this.setState({
      id: obj.id,
      cat_name: obj.cat_name,
      class_id: obj.class_id,
      class_name: obj.class_name,
      class_name_portal: obj.class_name_portal,
      exam_cat_id: obj.exam_cat_id,
      exam_name: obj.exam_name,
      exam_priority: obj.exam_priority,
      exam_start: _exam_start,
      exam_end: _exam_end,
      group_id: obj.group_id,
      medium: obj.medium,
      school_id: obj.school_id,
    })

    this.getSchoolIndexHandler(obj.school_id);
  }
  getSchoolIndexHandler(id) {
    let _inx = "";
    let _medium = "";
    this.props.schools.map((item, index) => {
      if (item.id === id) {
        _inx = index;
        _medium = item.sch_medium;
      }
    })
    const _classes = this.props.classes.filter((item) => {
      if (item.school_id === id) {
        return item
      }
    })
    this.setState({
      medium_arr: _medium,
      selected_school_index: _inx,
      selected_classes: _classes
    })
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getExamTypeHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       }, () => { this.getExamByIdHandlar() });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getExamTypeHandler() {
  //   loadProgressBar();
  //   // console.log(JSON.stringify(obj));
  //   axios.get(READ_EXAM_CAT)
  //     .then(res => {
  //       const resData = res.data;
  //       this.setState({
  //         examsType: resData,
  //         errorMessages: resData.message
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       this.setState({
  //         sft_classes: classes,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };
  getSectedClassHandler = (event) => {
    const _class_id = event.target.value;
    this.setState({ class_id: _class_id });
    //this.subjectsClasswise(_class_id);
  }
  // getExamByIdHandlar() {
  //   loadProgressBar();
  //   const { match } = this.props;
  //   axios.get(READ_EXAM + `?id=` + match.params.id)
  //     .then(res => {
  //       const getRes = res.data;
  //       const exam_start = getRes.exam_start !== "0000-00-00" ? new Date(getRes.exam_start) : new Date();
  //       const exam_end = getRes.exam_end !== "0000-00-00" ? new Date(getRes.exam_end) : new Date();
  //       let _school_inx = '';
  //       let _sch_medium = '';
  //       this.props.schools.forEach((item, inx) => {
  //         if (item.id === getRes.school_id) {
  //           _school_inx = inx;
  //           _sch_medium = item.sch_medium;
  //         }
  //       });
  //       this.filterClassesOnSchool(getRes.school_id, getRes.group_id);
  //       this.setState({
  //         id: getRes.id,
  //         exam_name: getRes.exam_name,
  //         medium: getRes.medium,
  //         group_id: getRes.group_id,
  //         school_id: getRes.school_id,
  //         class_id: getRes.class_id,
  //         exam_cat_id: getRes.exam_cat_id,
  //         medium_arr: _sch_medium,
  //         selected_school_index: _school_inx,
  //         exam_priority: getRes.exam_priority,
  //         exam_start: exam_start,
  //         exam_end: exam_end,
  //         errorMessages: getRes.message,
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {

    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }
    const form_obj = {
      id: this.state.id,
      // group_id: this.state.group_id,
      // school_id: this.state.school_id,
      exam_name: this.state.exam_name,
      medium: this.state.medium,
      class_id: this.state.class_id,
      exam_cat_id: this.state.exam_cat_id,
      exam_priority: this.state.exam_priority,
      exam_start: this.state.exam_start,
      exam_end: this.state.exam_end
    }

    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);


    // axios.post(UPDATE_EXAM, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  };
  render() {
    const { selected_school_index, medium_arr, medium, exam_start, exam_end, class_id, selected_classes,
      exam_name, exam_priority, exam_cat_id, formIsHalfFilledOut } = this.state;
    const { user, schools, classes, examsType, selected_item } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit User</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && selected_item && classes && examsType &&
          <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">
              Edit Exam
            </div>
            <div className="card-body">
              <div className="row" >

                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Schools :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        disabled={(user.user_category === "1") ? false : true}
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Medium :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='medium'
                        disabled={((medium_arr.length > 1) || (user.user_category === "1")) ? false : true}
                        value={medium}
                        onChange={event => this.changeHandler(event, 'medium')}>
                        <option value="">Select ...</option>
                        {medium_arr.map((item, index) => {
                          return (
                            <option key={index} value={item}>{item}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>

                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Class
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm" name="select"
                        value={class_id}
                        disabled={(user.user_category === "1") ? false : true}
                        onChange={event => this.getSectedClassHandler(event)}>
                        <option value="">Select...</option>
                        {selected_classes.map((option, index) => {
                          return (
                            <option key={index}
                              value={option.id}>
                              {option.class_name} [{option.class_name_portal}]
                            </option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Exam Start</label>
                    <div className="form-input">
                      <DatePicker
                        onChange={this.examStartDate}
                        value={exam_start}
                        showLeadingZeroes={true}
                      //minDate={new Date()}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">To End</label>
                    <div className="form-input">
                      <DatePicker
                        ref={el => (this.to = el)}
                        onChange={this.examEndDate}
                        value={exam_end}
                        showLeadingZeroes={true}
                      //minDate={new Date()}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Exam Name
                          <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input name="exam_name"
                        value={exam_name}
                        required
                        type="text" placeholder="Test Name"
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'exam_name')}
                      />
                      <small id="emailHelp" className="form-text text-muted">
                        Like 'First Test', Second Test, Half Yearly etc.</small>
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Exam Category
                                 <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm" name="select"
                        value={exam_cat_id}
                        onChange={event => this.changeHandler(event, 'exam_category')}>
                        <option value="">Select...</option>
                        {examsType.map((option, index) => {
                          return (
                            <option key={index} value={option.id}> {option.cat_name} </option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Priority
                          <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select name="exam_priority"
                        required
                        value={exam_priority}
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'exam_priority')}
                      >
                        <option>select ...</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                      </select>
                      <small id="emailHelp" className="form-text text-muted">
                        Set Priority of any Exam this is reflect in Marksheet Column.</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer text-right">
              <button type="submit" className="btn btn-primary mr-2" >Update</button>
              {/* <NavLink to="/all_exam.jsp" className="btn btn-danger">All Exam</NavLink> */}
              <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                Exit </button>
            </div>
          </form>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: examsType } = state.examsType;
  return { user, schools, classes, examsType };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getExamsType: examsTypeAction.getExamsType,
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditExam));