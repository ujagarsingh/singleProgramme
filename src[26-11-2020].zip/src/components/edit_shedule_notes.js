import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
// import axios from 'axios';
// import { connect } from 'react-redux';
// import { examSdulNotesAction, examsCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SHEDULES_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`; 
// const READ_ONE_SHEDULE_NOTE = ` http://schools.rajpsp.com/api/exam_sdul_notes/read_one.php`;
// const UPDATE_SHEDULE_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/update.php`;

class EditSheduleNotes extends Component {
  state = {
    id: '',
    group_id: '',
    school_id: '',
    session_year_id: '',
    exam_id: '',
    shedule_note: '',
    shedule_note_arr: [],
    selected_school_index: "",
    schools: [],
    shedule_notes_arr: [],
    display_notes_arr: [],
    current_sdul_note_obj: {},
    medium_arr: [],
    medium: "",
    current_exam_inx: "",
    school_name: "",
    shedule_note: "",
    exams: [],
    exam_id: "",
    selected_exams: [],
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'shedule_note') {
      const _shedule_note = event.target.value;
      if (_shedule_note.length <= 200) {
        this.setState({
          shedule_note: _shedule_note,
          formIsHalfFilledOut: true
        })
      }
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
        formIsHalfFilledOut: true
      });
    }
  }

  // filterExamsCategoriesHandler(school_id) {
  //     let _school_id = school_id;
  //     const _exams_cate = this.state.exams.filter((item) => {
  //         if (_school_id === item.school_id) {
  //             return item;
  //         }
  //     })
  //     this.setState({
  //         selected_exams: _exams_cate
  //     })
  // }

  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.selected_item;
    const sdulObj = this.props.SchoolExamSdulNotes;
    // console.log(obj);
    // debugger;

    this.setState({
      current_sdul_note_obj: obj,
      shedule_notes_arr: sdulObj,
      id: obj.id,
      medium: obj.medium,
      group_id: obj.group_id,
      school_id: obj.school_id,
      session_year_id: obj.ses_year,
      exam_id: obj.exam_id,
      shedule_note: obj.notes
    })

  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSheduleNotesHandler();
  //           this.getOneSheduleNotesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }


  // getExamsCategories() {
  //     loadProgressBar();
  //     axios.get(READ_EXAM_CATE)
  //         .then(res => {
  //             const getRes = res.data;
  //             this.setState({
  //                 exams: getRes,
  //                 errorMessages: getRes.message
  //             } )
  //             // console.log(this.state);
  //         }).catch((error) => {
  //             // error
  //         })
  // }
  // getSchoolHandler() {
  //     loadProgressBar();
  //     const obj = {
  //         group_id: this.state.group_id
  //     }
  //     axios.post(READ_SCHOOLS, obj)
  //         .then(res => {
  //             const getRes = res.data;
  //             this.setState({
  //                 schools: getRes,
  //                 errorMessages: getRes.message
  //             });
  //             // console.log(this.state);
  //         }).catch((error) => {
  //             // error
  //         })
  // }
  // getSheduleNotesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id
  //   }
  //   console.log(JSON.stringify(obj));

  //   axios.post(READ_SHEDULES_NOTE, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         shedule_notes_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       // console.log(this.state);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getOneSheduleNotesHandler() {
  //   loadProgressBar();
  //   const { match } = this.props;
  //   axios.get(READ_ONE_SHEDULE_NOTE + `?id=` + match.params.id)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         current_sdul_note_obj: getRes,
  //         errorMessages: getRes.message
  //       }, () => {
  //         this.setValuesAccordingGetData()
  //       });
  //       // console.log(this.state);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // setValuesAccordingGetData() {
  //   const _ctn_obj = this.state.current_sdul_note_obj;
  //   debugger

  //   this.setState({
  //     id: _ctn_obj.id,
  //     medium: _ctn_obj.medium,
  //     group_id: _ctn_obj.group_id,
  //     school_id: _ctn_obj.school_id,
  //     session_year_id: _ctn_obj.ses_year,
  //     exam_id: _ctn_obj.exam_id,
  //     shedule_note: _ctn_obj.notes
  //   })
  // }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    const _state = this.state;
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }

    const form_obj = {
      id: _state.id,
      medium: _state.medium,
      ses_year: _state.session_year_id,
      exam_id: _state.exam_id,
      notes: _state.shedule_note,
    }
    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);

    // debugger
    // axios.post(UPDATE_SHEDULE_NOTE, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       formIsHalfFilledOut: false
    //     }, () => {
    //       this.getSheduleNotesHandler();
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  render() {
    const { shedule_notes_arr, shedule_note, formIsHalfFilledOut } = this.state;
    const { user, schools, selected_item } = this.props;
    console.log(this.props);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Shedule Notes</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">Edit Shedule Notes</div>
          <div className="card-body">
            <div className="form-body form-horizontal">
              <div className="row">
                <div className="col-sm-6">
                  {/* <div className="form-group">
                        <label className="control-label">School
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select className="form-control form-control-sm"
                            required
                            ref='school'
                            value={selected_school_index}
                            onChange={event => this.changeHandler(event, 'school')}>
                            <option value="">Select ...</option>
                            {schools.map((item, index) => {
                              return (
                                <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="control-label">Medium
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select className="form-control form-control-sm"
                            required
                            ref='medium'
                            disabled={medium_arr.length > 1 ? false : true}
                            value={medium}
                            onChange={event => this.changeHandler(event, 'medium')}>
                            <option value="">Select ...</option>
                            {medium_arr.map((item, index) => {
                              return (
                                <option key={index} value={item}>{item}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="control-label">Exams
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select
                            value={current_exam_inx}
                            disabled={school_name === '' ? true : false}
                            className="form-control form-control-sm" name="current_exam"
                            onChange={event => this.changeHandler(event, 'current_exam')} >
                            <option value="">Select...</option>
                            {selected_exams.map((option, index) => {
                              return (<option key={index} value={index}>{option.cat_name}</option>)
                            })}
                          </select>
                        </div>
                      </div> */}

                  <div className="form-group">
                    <label className="control-label">Shedule Note
                          <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <textarea name="shedule_note" placeholder="Note"
                        className="form-control-textarea form-control" rows={3}
                        value={shedule_note}
                        onChange={event => this.changeHandler(event, 'shedule_note')} />
                      <small className="form-text text-muted">Max Length <b><span className="ml-auto text-danger">{shedule_note.length}</span> / 200.</b> </small>
                    </div>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="card border-secondary">
                    <div className="card-header">All Notes : </div>
                    <div className="card-body h-auto">
                      <ol className="list-inline mb-0">
                        {shedule_notes_arr.map((item, inx) => {
                          return (
                            <li className="list-inline-item ml-3" key={inx}>
                              <span className="d-flex">
                                <i className="fas fa-check mt-1 mr-2"></i>
                                {item.notes}</span>
                            </li>
                          )
                        })}
                      </ol>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-primary mr-2">Submit</button>
            {/* <NavLink to="/shedule_notes.jsp" className="btn btn-danger">Back</NavLink> */}
            <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
              Exit </button>
          </div>
        </form>
      </div>
    )
  }
}

export default withRouter(EditSheduleNotes);