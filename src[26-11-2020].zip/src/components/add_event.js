import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { schoolsAction, eventsActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const CREATE_EVENT = `http://schools.rajpsp.com/api/events/create.php`;

class AddEvent extends Component {
  state = ({
    medium_arr: [],
    medium: "",
    title: "",
    type: "",
    description: "",
    date_start: new Date(),
    date_end: new Date(),
    formIsHalfFilledOut: false,
    event_img: "",
    crop: {
      unit: "%",
      width: 50,
      aspect: 16 / 9
    },
    final_size: {
      width: 640,
      height: 360
    }
  })
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else if (fieldName === 'type') {
      this.setState({
        type: event.target.value
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  startDateHandler = (getDate) => {
    this.setState({ date_start: getDate });
    this.to.openCalendar();
  };
  endDateHandler = (getDate) => {
    this.setState({ date_end: getDate });
    //this.to.openCalendar();
  };
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      event_img: data
    })
  }
  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    loadProgressBar();
    //e.preventDefault();
    const obj = {
      school_id: this.state.school_id,
      event_img: this.state.event_img,
      medium: this.state.medium,
      title: this.state.title,
      type: this.state.type,
      description: this.state.description,
      date_start: this.state.date_start,
      date_end: this.state.date_end
    }
    console.log(JSON.stringify(obj));
    this.props.createEvent(obj);
    // axios.post(CREATE_EVENT, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       event_img: "",
    //       title: "",
    //       type: "",
    //       medium: "",
    //       description: "",
    //       date_start: new Date(),
    //       date_end: new Date(),
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  render() {
    const { crop, event_img, selected_school_index, medium_arr, medium, final_size, date_end, date_start, title, description, formIsHalfFilledOut } = this.state;
    const { user, schools } = this.props;
    console.log(this.props);
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Event</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        {user && schools &&
          <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">
              Add Event
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-sm-3">
                    <div className="form-group">
                      <label className="control-label">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  <div className="form-group">
                    <label className="control-label">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="control-label">Event Title
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="title" placeholder="Event Title"
                        className="form-control form-control-sm"
                        required
                        value={title}
                        onChange={event => this.changeHandler(event, 'title')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Select Type
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        onChange={event => this.changeHandler(event, 'type')}>
                        <option >Select ...</option>
                        <option >Event</option>
                        <option >Holiday</option>
                        <option >Event and Holiday</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label">Start Date Of Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <DatePicker
                        onChange={this.startDateHandler}
                        value={date_start}
                        showLeadingZeroes={true}
                        minDate={new Date()}
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="control-label">End Date Of Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <DatePicker
                        ref={el => (this.to = el)}
                        onChange={this.endDateHandler}
                        value={date_end}
                        showLeadingZeroes={true}
                        minDate={new Date()}
                      />
                    </div>
                  </div>
                </div>

                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">About Event
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <textarea name="description" placeholder="About Event" className="form-control-textarea form-control" rows={5}
                        value={description}
                        onChange={event => this.changeHandler(event, 'description')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Event Image
                      </label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onComplete}
                        crop={crop}
                        final_size={final_size}
                      />
                      {event_img !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + event_img} />
                        : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer text-right">
              <button type="submit" className="btn btn-secondary mr-2">Submit</button>
              <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
                Cancel
            </button>
            </div>
          </form>
        }
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  return { user, schools };
}

const actionCreators = {
  createEvent: eventsActions.create,
  getSchools: schoolsAction.getSchools,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddEvent));