import React, { Component } from 'react';
import { withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
// import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class FrontIndexStudents extends Component {
   render() {
      return (
         <section className="students-say-area">
            <div className="container">
               <div className="row">
                  <div className="col-sm-12 section-header-box">
                     <div className="section-header">
                        <h2>What Students Parent SAY</h2>
                     </div>{/* ends: .section-header */}
                  </div>
               </div>
               <div className="row">
                  <div className="img-full-box w-100">
                     <div className="col-sm-3 ml-auto mr-auto">
                        <div className="carousel-images slider-nav">
                           <div>
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/stu-parent-01.jpg`} alt={1} className="img-responsive img-circle" />
                           </div>
                           <div>
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/stu-parent-02.jpg`} alt={2} className="img-responsive img-circle" />
                           </div>
                           <div>
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/stu-parent-03.jpg`} alt={3} className="img-responsive img-circle" />
                           </div>
                           <div>
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/stu-parent-04.jpg`} alt={3} className="img-responsive img-circle" />
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="col-sm-8 ml-auto mr-auto">
                     <div className="carousel-text slider-for">
                        <div className="single-box">
                           <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibh euismod tincidunt ut laoreet dolor you magna aliquam eratm volutpat. Ut wisiyp oenim adefra miniumyp veniam, quis nostrud exerci tation ullavolutpat ipsum.</p>
                           <ul className="list-unstyled rank-icons">
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                           </ul>
                           <h3>Jhonthan Smith</h3>
                           <span>Alexis, Parents</span>
                        </div>
                        <div className="single-box">
                           <p>Maecenas ut dui vitae magna vestibulum fermentum ut non est. Fusce finibus viverra enim, et laoreet metus fringilla sit amet. Ut dui nunc, aliquet ut malesuada sit amet, sagittis aliquam laoreet lorem. In hac habitasse platea dictumst.</p>
                           <ul className="list-unstyled rank-icons">
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                           </ul>
                           <h3>Jhon Doe</h3>
                           <span>Martin, Parent</span>
                        </div>
                        <div className="single-box">
                           <p>Aenean at leo hendrerit, congue erat ut, volutpat felis. Suspendisse et sapien purus. Aenean tincidunt diam ac magna scelerisque dapibus. Quisque non elit et justo tristique semper. Sed a urna eros. Etiam tempus tempus leo vel aliquam.</p>
                           <ul className="list-unstyled rank-icons">
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                           </ul>
                           <h3>Jhonthan Smith</h3>
                           <span>Alexis, Parents</span>
                        </div>
                        <div className="single-box">
                           <p>Cras ut ipsum et erat accumsan aliquam. Cras feugiat eu dolor a imperdiet. Vestibulum ornare, nunc a pulvinar pellentesque, mi ipsum elementum velit, lobortis convallis lacus ipsum eget nisl. Mauris eget est lorem praesent et metus laoreet.</p>
                           <ul className="list-unstyled rank-icons">
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                              <li><i className="fa fa-star" /></li>
                           </ul>
                           <h3>Jessica Alaba</h3>
                           <span>Martin, Parent</span>
                        </div>
                     </div>
                  </div>{/* /.block-text */}
               </div>	{/*./End row*/}
            </div>
         </section>
      )
   }
}
export default withRouter(FrontIndexStudents);