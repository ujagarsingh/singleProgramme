import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, accLedgerEntryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class AllLedgerStatus extends Component {
   state = {
      schools: [],
      school_id: '',
      selected_school_index: '',
      medium_arr: [],
      subjects: [],
      selected_accLedgerEntry: [],
      sft_classes: [],
      selected_class: '',
      selected_class_inx: '',
      selected_classes: [],
      medium: '',
      createItem: false,
   }

   changeHandler = (event, fieldName, isCheckbox) => {

      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value
      })
   };

   filterClassesOnSchool(sch_id, group_id) {
      const _classes = this.props.classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         selected_classes: _classes,
         //selected_accLedgerEntry: ''
      })
   }

   classHandler() {
      const _fltr_school = this.props.filteredSchoolData;
      const _fltr_class = this.props.filteredClassesData;

      const subjects = this.props.accLedgerEntry;
      let _subject = '';
      if (!isEmpty(_fltr_class.slct_cls_index)) {
         // const _class_name = selected_classes[_classIdx].class_name;
         const _class_id = _fltr_class.slct_cls_id;
         _subject = subjects.filter((item) => {
            if (item.class_id === _class_id) {
               return item
            }
         })
      } else {
         _subject = subjects.filter((item) => {
            if (item.medium === _fltr_school.slct_school_medium) {
               return item
            }
         })
      }

      if (!isEmpty(_subject)) {
         const f_subjects = _subject.map((item) => {
            let _class_name = '';
            this.props.classes.filter((item_c) => {
               if (item.class_id === item_c.id) {
                  _class_name = item_c.class_name
               }
            })
            return item = { ...item, class_name: _class_name }
         })
         this.setState({
            selected_accLedgerEntry: f_subjects
         })
      } else {
         this.setState({
            selected_accLedgerEntry: []
         })
      }
   }

   basicInfoHandler = (event) => {
      event.preventDefault();
      this.setState({
         basicInfo: !this.state.basicInfo
      })
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.accLedgerEntry)) {
         this.props.getAccLedgerEntry();
      }
      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         const _all_accLedgerEntry = this.props.accLedgerEntry;
         if (_all_accLedgerEntry && _filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   filterBySchoolHandler = () => {
      const _filter = this.props.filteredSchoolData;
      const _all_accLedgerEntry = this.props.accLedgerEntry;
      if (!isEmpty(_all_accLedgerEntry)) {
         const _school_subjects = _all_accLedgerEntry.filter((item) => {
            if (_filter.slct_school_id) {
               if (item.school_id === _filter.slct_school_id) {
                  return item
               }
            } else {
               return item
            }
         })
         this.setState({
            selected_accLedgerEntry: _school_subjects,
         }, () => this.filterByClsHandler())
      }
   }

   filterByClsHandler = () => {

      this.classHandler();
   }



   componentWillReceiveProps(nextProps) {
      if (nextProps.subjects) {

         this.filterBySchoolHandler();
      }
   }


   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  // this.props.deleteSubjects({ id: id });
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

 
   render() {
      const {  selected_accLedgerEntry } = this.state;
      const { user, schools, classes, accLedgerEntry } = this.props;
      // console.log(this.state)
      return (
         <div className="page-content">
            <Helmet>
               <title>All Group Status</title>
            </Helmet>
            <div className="page-bar d-flex">
               <div className="page-title">All Group Status</div>
               {user && schools && classes && accLedgerEntry &&
                  <div className="form-inline ml-auto filter-panel">
                     <span className="filter-closer">
                        <button type="button" className="btn btn-danger filter-toggler-c">
                           <i className="fa fa-times"></i>
                        </button>
                     </span>
                     <div className="filter-con">

                        <CommonFilters
                           showSchoolFilter={true}
                           showMediumFilter={false}
                           showClassFilter={true}
                           filterBySchoolHandler={this.filterBySchoolHandler}
                           filterByClsHandler={this.filterByClsHandler}
                        />

                     </div>
                  </div>
               }
            </div>
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  <div className="table-scrollable">
                     <table className="table table-striped table-sm table-bordered table-hover table-sm">
                        <thead>
                           <tr>
                              <th rowSpan="2">Id</th>
                              <th rowSpan="2">School Name</th>
                              <th rowSpan="2">Ledgers</th>
                              <th rowSpan="2">Type</th>
                              <th colSpan="2">Opning Balance</th>
                              <th colSpan="2">Closing Balance</th>
                              <th rowSpan="2">Action</th>
                           </tr>
                           <tr>
                              <th>Debit</th>
                              <th>Credit</th>
                              <th>Debit</th>
                              <th>Credit</th>
                           </tr>
                        </thead>
                        {selected_accLedgerEntry.length > 0 ?
                           <tbody>
                              {selected_accLedgerEntry.map((item, index) => {
                                 return (
                                    <tr key={index}>
                                       <td>{index + 1}</td>
                                       <td>{item.school_name} [{item.sch_medium}]</td>
                                       <td>{item.ledger_name}</td>
                                       <td>{item.ledger_type}</td>
                                       <td className="text-right">{(item.op_type == "DR") ? item.op_balance + ".00" : ''}</td>
                                       <td className="text-right">{(item.op_type == "CR") ? item.op_balance + ".00" : ''}</td>
                                       <td className="text-right">{(item.cl_type == "DR") ? item.cl_balance + ".00" : ''}</td>
                                       <td className="text-right">{(item.cl_type == "CR") ? item.cl_balance + ".00" : ''}</td>
                                       <td>
                                          <button className="btn btn-danger btn-sm"
                                             value={item.id}
                                             type="button"
                                             onClick={event => this.confirmBoxDelete(event, item.id)}
                                          >
                                             Delete</button>
                                       </td>
                                    </tr>
                                 )
                              })}
                           </tbody>
                           : null}
                     </table>
                  </div>
               </div>
            </div>
            <div className="card-footer">
               {/* {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-danger btn-sm ">
                     Cancel</button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-primary btn-sm">
                     Add New</button>
               } */}
            </div>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: accLedgerEntry } = state.accLedgerEntry;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, classes, accLedgerEntry,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
   getAccLedgerEntryByFolio: accLedgerEntryActions.getAccLedgerEntryByFolio,
}
export default connect(mapStateToProps, actionCreators)(withRouter(AllLedgerStatus));