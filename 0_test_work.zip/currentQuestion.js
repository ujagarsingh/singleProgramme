import React, { Component } from "react";

class CurrentQuestion extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  selectOptionHandler = (event, inx, queObj) =>{
    event.preventDefault();
    // console.log(inx);
    // console.log(queObj);
    let _queObj = JSON.parse(JSON.stringify(queObj));
    _queObj.detail.answer = _queObj.detail.options[inx].id;
    _queObj.detail.markAS = "1";
    console.log(_queObj);
    this.props.updateQuizDataHandler(_queObj);
  }

  render() {
      const {crnt_question : cq} = this.props;
    return (
     <div className="card-body  p-0">
        <div className="d-flex question-info p-2 mb-1">
            <h5 className="card-title ml-2 m-0">Question 1</h5>
            <div className="ml-auto d-flex">
                <div className="question-time d-flex p-2">
                    <label className="label-header">
                        Time :</label>
                    <div className="show-time">
                        25:10</div>
                </div>
                <div className="obtain-marks d-flex  p-2">
                    <label className="label-header">
                        Marks:</label>
                    <div className="get-marks text-success"> +20</div>
                    <div className="loss-marks text-danger"> -10</div>
                </div>
            </div>
        </div>
        {cq &&
        <div className="p-3">
            <div className="question-text">
                {console.log(cq)}
                {cq.detail.question}
            </div>
            <div className="form-group answer-options">
                {cq.detail.options.map((opts, inx) => {
                    return (
                        <div key={inx} 
                        onClick={(event)=>{this.selectOptionHandler(event, inx, cq)}}
                        className="custom-control custom-radio">
                            <input type="radio" id={"ansRadio1_"+inx} name="ansRadio" 
                            defaultChecked={(cq.detail.answer == opts.id) ? true : false}
                            className="custom-control-input" />
                            <label className="custom-control-label" htmlFor={"ansRadio1_"+inx}>
                                {opts.opt}
                            </label>
                        </div>

                    )
                })}
                 
            </div>
        </div>
        }
    </div>
        
    );
  }
}

export default CurrentQuestion;
