-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:45 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_cc_entry`
--

CREATE TABLE `acc_cc_entry` (
  `id` int(11) NOT NULL,
  `school_id` int(4) NOT NULL,
  `vchr_ref_id` int(11) NOT NULL,
  `c_center_folio` varchar(11) NOT NULL COMMENT 'class_id _ school_id',
  `class_id` int(5) NOT NULL,
  `op_balance` int(15) NOT NULL,
  `op_type` varchar(2) NOT NULL,
  `tr_amount` int(15) NOT NULL,
  `tr_type` varchar(2) NOT NULL,
  `cl_balance` int(15) NOT NULL,
  `cl_type` varchar(2) NOT NULL,
  `session_year_id` varchar(3) NOT NULL COMMENT 'current session id	',
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_cc_entry`
--
ALTER TABLE `acc_cc_entry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sch_id` (`vchr_ref_id`),
  ADD KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_cc_entry`
--
ALTER TABLE `acc_cc_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_cc_entry`
--
ALTER TABLE `acc_cc_entry`
  ADD CONSTRAINT `acc_cc_entry_ibfk_1` FOREIGN KEY (`vchr_ref_id`) REFERENCES `acc_voucher_ref` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `acc_cc_entry_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `school_info` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
