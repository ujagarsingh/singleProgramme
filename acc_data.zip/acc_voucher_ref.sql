-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:48 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_voucher_ref`
--

CREATE TABLE `acc_voucher_ref` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `description` varchar(300) NOT NULL COMMENT 'Naretion',
  `session_year_id` varchar(3) NOT NULL COMMENT 'current session id	',
  `entry_month` int(2) NOT NULL COMMENT 'month of entry',
  `tr_date` date NOT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_voucher_ref`
--
ALTER TABLE `acc_voucher_ref`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sch_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_voucher_ref`
--
ALTER TABLE `acc_voucher_ref`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2474;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_voucher_ref`
--
ALTER TABLE `acc_voucher_ref`
  ADD CONSTRAINT `acc_voucher_ref_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school_info` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
