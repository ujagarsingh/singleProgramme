-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:47 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_group`
--

CREATE TABLE `acc_group` (
  `id` int(10) NOT NULL,
  `parent_id` int(5) NOT NULL COMMENT 'Parent Group Id',
  `group_code` int(4) NOT NULL,
  `school_id` int(5) NOT NULL,
  `group_name` varchar(50) DEFAULT NULL,
  `group_type` varchar(1) NOT NULL DEFAULT 'S' COMMENT 'PreDefine > P, UserDefine > S',
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `acc_group`
--

INSERT INTO `acc_group` (`id`, `parent_id`, `group_code`, `school_id`, `group_name`, `group_type`, `server_date_time`) VALUES
(1, 0, 1001, 0, 'Indirect Expenses', 'P', '2020-09-15 22:26:56'),
(2, 0, 1002, 0, 'Indirect Income', 'P', '2020-09-16 01:13:33'),
(3, 0, 1003, 0, 'Current Assets', 'P', '2020-09-15 22:26:56'),
(4, 0, 1004, 0, 'Current Liabilities', 'P', '2020-09-15 22:45:18'),
(5, 0, 1005, 0, 'Cash in Hand', 'P', '2020-09-16 01:43:33'),
(6, 0, 1006, 0, 'Bank Accounts', 'P', '2020-09-16 01:43:33'),
(9, 1, 1001, 0, 'Salary', 'P', '2020-09-19 02:25:43'),
(10, 2, 1002, 0, 'Fee', 'P', '2020-09-19 10:09:36'),
(17, 1, 1001, 4, 'Newspaper Exp.', 'S', '2020-09-25 02:38:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_group`
--
ALTER TABLE `acc_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_group`
--
ALTER TABLE `acc_group`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_group`
--
ALTER TABLE `acc_group`
  ADD CONSTRAINT `acc_group_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school_info` (`id`),
  ADD CONSTRAINT `acc_group_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `acc_group` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
