-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:47 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_ledger`
--

CREATE TABLE `acc_ledger` (
  `id` int(10) NOT NULL,
  `school_id` int(5) NOT NULL,
  `acc_group_id` int(2) NOT NULL COMMENT 'Under Group Id',
  `group_code` int(4) NOT NULL,
  `ledger_name` varchar(50) NOT NULL,
  `ledger_type` varchar(1) NOT NULL DEFAULT 'S' COMMENT 'PreDefine > P, UserDefine > S',
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `acc_ledger`
--

INSERT INTO `acc_ledger` (`id`, `school_id`, `acc_group_id`, `group_code`, `ledger_name`, `ledger_type`, `server_date_time`) VALUES
(1, 0, 1, 1001, 'Indirect Expenses', 'P', '2020-09-15 22:26:56'),
(2, 0, 2, 1002, 'Indirect Income', 'P', '2020-09-16 01:13:33'),
(3, 0, 1, 1001, 'Salary', 'P', '2020-09-15 22:26:56'),
(4, 0, 2, 1002, 'Fees', 'P', '2020-09-15 22:45:18'),
(5, 0, 5, 1005, 'Cash', 'P', '2020-09-16 01:43:33'),
(6, 0, 6, 1006, 'Bank Accounts', 'P', '2020-09-16 01:43:33'),
(7, 0, 1, 1001, 'Fee Discount', 'P', '2020-09-18 01:28:41'),
(13, 4, 9, 1001, 'Teaching Staff', 'S', '2020-09-23 01:49:51'),
(14, 4, 10, 1002, 'Admission Fee', 'S', '2020-09-24 20:38:29'),
(15, 4, 10, 1002, 'Sport Fee', 'S', '2020-09-24 20:38:42'),
(16, 4, 10, 1002, 'Exam Fee', 'S', '2020-09-24 20:38:51'),
(17, 4, 10, 1002, 'Tuition Fee', 'S', '2020-09-24 20:39:01'),
(18, 4, 10, 1002, 'Transpoart Fee', 'S', '2020-09-24 20:44:04'),
(19, 4, 10, 1002, 'Practical Fee', 'S', '2020-09-24 20:44:21'),
(20, 4, 10, 1002, 'Library Fee', 'S', '2020-09-24 20:44:41'),
(21, 4, 10, 1002, 'Registration Fee', 'S', '2020-09-24 20:45:16'),
(22, 0, 3, 1003, 'Sundry Debtors', 'P', '2020-10-08 21:45:21'),
(23, 0, 4, 1004, 'Sundry Creditors', 'P', '2020-10-08 21:45:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_ledger`
--
ALTER TABLE `acc_ledger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acc_group_id` (`acc_group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_ledger`
--
ALTER TABLE `acc_ledger`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_ledger`
--
ALTER TABLE `acc_ledger`
  ADD CONSTRAINT `acc_ledger_ibfk_1` FOREIGN KEY (`acc_group_id`) REFERENCES `acc_group` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
