import React, { Component } from "react";

class ReportDistribution extends Component {
  constructor(props) {
    super(props);

  };

    
  componentDidMount(){
  }

  render() {
    return (
     	<div className="card-body">
            <h5 className="card-title">You v/s Topper</h5>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Comprison</th>
                        <th scope="col">You</th>
                        <th scope="col">Topper</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-battery-half"></i>
                        </th>
                        <td>Score</td>
                        <td>3.00</td>
                        <td>98.00</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-bullseye"></i>
                        </th>
                        <td>Accuracy</td>
                        <td>100.00</td>
                        <td>96.67</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-check-circle"></i>
                        </th>
                        <td>Correct</td>
                        <td>2</td>
                        <td>116</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-times-circle"></i>
                        </th>
                        <td>Incorrect</td>
                        <td>0</td>
                        <td>4</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-stopwatch"></i>
                        </th>
                        <td>Time</td>
                        <td>75 Min 10 Sec</td>
                        <td>10 Min 33 Sec</td>
                    </tr>
                </tbody>
            </table>
        </div>
    
																												   
    );
  }
}

export default ReportDistribution;
