import React, { Component } from "react";

class ReportSummary extends Component {
  constructor() {
    super();

  };
    
  componentDidMount(){
  }

  render() {
    return (
     	<div className="col">
            <h4>Summary</h4>
            <div className="row">
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h5>Attempted</h5>
                            <h5>2/100</h5>
                        </div>
                    </div>
                </div>
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h5>Correct</h5>
                            <h5>2/100</h5>
                        </div>
                    </div>
                </div>
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h5>Accuracy</h5>
                            <h5>100.00%</h5>
                        </div>
                    </div>
                </div>
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h5>Time</h5>
                            <h5>01:30:20</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
																												   
    );
  }
}

export default ReportSummary;
