import React, { Component } from "react";

class ReportLeaderboard extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
	  const {leader_board} = this.props;
    return (
     <div className="card-body">
		<h5 className="card-title">Leaderboard</h5>
		<ul className="list-unstyled">
			{leader_board.map((item, inx)=>{
				return (
					<li className="media" key={inx}>
						<img className="mr-3 rounded-circle"
							src={item.url} alt="Generic placeholder" />
						<div className="media-body">
							<h5 className="mt-0 mb-1">{item.name}</h5>
							<p>Marks {item.mobtain} / {item.mmarks}</p>
						</div>
					</li>
				)
			})}
		</ul>
	</div>
    );
  }
}

export default ReportLeaderboard;
