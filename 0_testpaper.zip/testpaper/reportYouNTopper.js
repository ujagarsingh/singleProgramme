import React, { Component } from "react";

class ReportUNTopper extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  
quizSummaryHandler = () =>{
    const t1 = rpot_score_summary;
    const t2 = topper_score_summary;
    const header = Object.keys(t1);
    let score_obj = [];
    header.forEach((el, inx)=>{
        let name = "";

        if(el === "score"){name = "Score"}
        else if(el === "usedtime"){name = "Time"}
        else if(el === "accuracy"){name = "Accuracy"}
        else if(el === "correct"){name = "Correct"}
        else if(el === "incorrect"){name = "Incorrect"}

        const obj = {"title" : name, "key" : el, "t1" : t1[el], "t2" : t2[el]};
        score_obj.push(obj);
    })
    console.log(score_obj);
}

  render() {
    return (
     	<div className="card-body">
            <h5 className="card-title">You v/s Topper</h5>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Comprison</th>
                        <th scope="col">You</th>
                        <th scope="col">Topper</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-battery-half"></i>
                        </th>
                        <td>Score</td>
                        <td>3.00</td>
                        <td>98.00</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-bullseye"></i>
                        </th>
                        <td>Accuracy</td>
                        <td>100.00</td>
                        <td>96.67</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-check-circle"></i>
                        </th>
                        <td>Correct</td>
                        <td>2</td>
                        <td>116</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-times-circle"></i>
                        </th>
                        <td>Incorrect</td>
                        <td>0</td>
                        <td>4</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <i className="fa fa-stopwatch"></i>
                        </th>
                        <td>Time</td>
                        <td>75 Min 10 Sec</td>
                        <td>10 Min 33 Sec</td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
  }
}

export default ReportUNTopper;
