import React, { Component } from "react";

class QuizSummay extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <ul className="quiz-summay">
        <li className="q-answered"><span className="box bg-success">10</span>Answered</li>
        <li className="q-not-answered"><span className="box bg-red">5</span>Not Answered</li>
        <li className="q-review-without-ans"><span className="box bg-yellow">1</span>Review Later</li>
        <li className="q-not-visited"><span className="box bg-white">1</span>Not Visited</li>
        <li className="q-review-with-ans w-100"><span className="box bg-yellow">5</span>Answered &amp; Review Later</li>
    </ul>
								   
    );
  }
}

export default QuizSummay;
