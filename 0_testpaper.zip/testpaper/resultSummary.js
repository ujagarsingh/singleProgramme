import React, { Component } from "react";
import { NavLink } from 'react-router-dom';

class ResultSummary extends Component {
  constructor(props) {
    super(props);

  };

    
  componentDidMount(){
  }


  render() {
    const {markeDType, quiz} = this.props;
    return (
     <div className="modal result-modal d-block">
        <div className="modal-dialog">
            <div className="modal-content">
                <div className="modal-header bg-light">
                    <div className="d-flex flex-column">
                        <h4 className="modal-title text-primary">Test Summary</h4>
                        <h6>Your answer have been saved successfully please take few moments to review this summary.</h6>
                    </div>
                    <button type="button" className="btn btn-danger" 
                    onClick={event => this.submitTest(event)}>×</button>
                </div>
                <div className="modal-body">
                    <ul className="list-group">
                        <li className="list-group-item d-flex justify-content-between align-items-center">
                            No.of questions
                            <span className="badge badge-primary badge-pill">
                                {quiz.length + 1}
                            </span>
                        </li>
                        {markeDType.map((item, inx)=>{
                            return(
                                <li key={inx} 
                                className="list-group-item d-flex justify-content-between align-items-center">
                                    {item.mrk_type}
                                    <span className="badge badge-primary badge-pill">
                                        {item.counter}
                                    </span>
                                </li>
                            )
                        })}
                    </ul>
                </div>
                <div className="modal-footer bg-light">
                    <NavLink to="/test_result.jsp" 
                    className="btn btn-success btn-sm">Continue</NavLink>
                </div>
            </div>
        </div>
    </div>
								   
    );
  }
}

export default ResultSummary;
