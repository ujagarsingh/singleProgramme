import React, { Component } from "react";

class ReportScoreSummary extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }
 
  render() {
	  const {rpot_score_summary : rss} = this.props;
    return (
     <div className="row">
		<div className="col">
			<div className="scoreBox">
				<div className="score-title">Score</div>
				<div className="score-detail">{rss.score}</div>
			</div>
		</div>
		<div className="col">
			<div className="scoreBox">
				<div className="score-title">Accuracy</div>
				<div className="score-detail">{rss.accuracy}</div>
			</div>
		</div>
		<div className="col">
			<div className="scoreBox">
				<div className="score-title">Rank AIS</div>
				<div className="score-detail">{rss.rank}</div>
			</div>
		</div>
		<div className="col">
			<div className="scoreBox">
				<div className="score-title">Percentage</div>
				<div className="score-detail">{rss.percentage}</div>
			</div>
		</div>
		<div className="col">
			<div className="scoreBox">
				<div className="score-title">Percentile</div>
				<div className="score-detail">{rss.percentile}</div>
			</div>
		</div>
	</div>
    );
  }
}

export default ReportScoreSummary;
