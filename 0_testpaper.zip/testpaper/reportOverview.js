import React, { Component } from "react";

class ReportOverview extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <div className="card-body">
        <h5 className="card-title">Overview</h5>
        <img 
          src={`${process.env.PUBLIC_URL}/assets/images/circle-pie-chart.jpg`} 
          alt="Status" 
          className="img-fluid"/>
    </div>
																												   
    );
  }
}

export default ReportOverview;
