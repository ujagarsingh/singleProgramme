// nuberInWords
// isEmpty
const UTILS = {
   imgError: function (image,defaultImg) {
      image.onerror = "";
      image.src = defaultImg;
      return true;
   }
}
export default UTILS;