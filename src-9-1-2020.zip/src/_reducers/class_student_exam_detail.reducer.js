import { classStudentsExamDetailConstants } from '../_constants';

export function classStudentExamDetail(state = {}, action) {
  switch (action.type) {
    case classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_SUCCESS:
      return {
        item: action.response
      };
    case classStudentsExamDetailConstants.CLASS_STUDENTS_EXAM_DETAIL_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}