import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const UPDATE_GALLERY = `http://schools.rajpsp.com/api/galleries/gallery/update.php`;
// const GET_GALLERY = `http://schools.rajpsp.com/api/galleries/gallery/read_one.php`;

class EditGallery extends Component {
   state = ({
      id: "",
      medium: "",
      title: "",
      description: "",
      active: true,
      selected_item: '',
      formIsHalfFilledOut: false,
   })
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })

   };
   componentDidMount() {
      this.setState({
         selected_item: this.props.selected_item
      })
   }

   // getSchoolIndexHandlar(id) {
   //    const { schools } = this.props;
   //    let school_index = '';
   //    schools.forEach((item, index) => {
   //       if (item.id === id) {
   //          school_index = index
   //       }
   //    })
   //    return school_index
   // }


   // componentDidUpdate(prevProps) {
   //    if (prevProps.selected_item !== this.props.selected_item) {
   //       this.setState({ selected_item: this.props.selected_item });
   //    }
   // }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getGalleryHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getGalleryHandler() {
   //    loadProgressBar();
   //    const { match } = this.props;
   //    axios.get(GET_GALLERY + `?id=` + match.params.id)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             id: getRes.id,
   //             medium: getRes.medium,
   //             title: getRes.title,
   //             description: getRes.description,
   //             active: (getRes.active === '1' ? true : false)
   //          });
   //          //console.log(this.state.galleries);
   //       }).catch((error) => {
   //          // error
   //       })
   // };

   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

   submitHandler = e => {
      loadProgressBar();

      //e.preventDefault();
      let default_obj = '';
      if (this.props.user.user_category === "1") {
         default_obj = { school_id: this.refs.school.value }
      }
      const form_obj = {
         id: this.props.selected_item.id,// this.state.id,
         title: this.refs.title.value, // this.state.title,
         description: this.refs.description.value, // this.state.description,
         active: (this.refs.active.checked) ? "1" : "0" // this.state.active
      }
      const obj = { ...form_obj, ...default_obj }
      // console.log(JSON.stringify(obj));

      this.props.updateHandlar(obj);

      // axios.post(UPDATE_GALLERY, obj)
      //    .then(res => {
      //       const getRes = res.data;
      //       Alert.success(getRes.message, {
      //          position: 'bottom-right',
      //          effect: 'jelly',
      //          timeout: 5000, offset: 40
      //       });
      //       this.setState({
      //          formIsHalfFilledOut: false
      //       })
      //    }).catch((error) => {
      //       //this.setState({ errorMessages: error });
      //    })
   }
   render() {
      const { formIsHalfFilledOut } = this.state;
      const { selected_item, schools, user } = this.props;
      // console.log(this.props);
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Gallery</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  Edit Gallery
               </div>
               <div className="card-body">
                  {selected_item && schools && user &&
                     <div className="row" key={selected_item.id}>
                        {(user.user_category === "1") &&
                           <div className="col-sm-2">
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    // defaultValue={this.getSchoolIndexHandlar(selected_item.school_id)}
                                    defaultValue={selected_item.school_id}
                                 // onChange={event => this.changeHandler(event, 'school')}
                                 >
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        }
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">Gallery Title
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" placeholder="Gallery Title"
                                    className="form-control form-control-sm"
                                    required
                                    ref="title"
                                    defaultValue={selected_item.title}
                                 // onChange={event => this.changeHandler(event, 'title')} 
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">About Gallery
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" placeholder="About This Galary"
                                    className="form-control form-control-sm"
                                    required
                                    ref="description"
                                    defaultValue={selected_item.description}
                                 // onChange={event => this.changeHandler(event, 'description')}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">

                           <div className="form-group">
                              <label className="control-label"></label>
                              <div className="form-input">
                                 <div className="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" className="custom-control-input" id="customCheck2"
                                       ref="active"
                                       // onChange={event => this.changeHandler(event, 'active', true)}
                                       defaultChecked={(selected_item.active === '1') ? true : false}
                                    />
                                    <label className="custom-control-label" htmlFor="customCheck2">
                                       {/* {(selected_item.active === '1') ? 'Yes' : 'No'} */}
                                       Is Active
                                    </label>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  }
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-primary mr-2">Submit</button>
                  {/* <NavLink to="/all_galleries.jsp" className="btn btn-danger">Cancel</NavLink> */}
                  <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                     Exit </button>
               </div>
            </form>
         </div>
      )
   }
}

export default withRouter(EditGallery);