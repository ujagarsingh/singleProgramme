import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultArticleActions } from '../_actions';

class FrontIndexAriticle extends Component {
   state = {
      
      formIsHalfFilledOut: false,
   }
   componentDidMount() {
      if (isEmptyObj(this.props.defaultArticle)) {
         this.props.getDefaultArticle();
      }
   };
   render() {
      const { defaultArticle } = this.props;
      return (
         <section className="index_article_secion">
            <div className="container">
               {defaultArticle &&
                  <div className="row article_inner">
                     {defaultArticle.map((item, index) => {
                        return (
                           <div key={index} className={`col-md-4 p-1`}>
                              <div
                                 className={`article_box color_box_0` + (index + 1)}>
                                 <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/article_icon_0` + (index + 1) + `.png`} className="btm-item-icon" />
                                 <h3>{item.title}</h3>
                                 <p>{`${item.description.substring(0, 100)}...`}</p>
                                 <NavLink className="d-none" to={item.title}>
                                    read more
                              <i className="fa fa-long-arrow-right" />
                                 </NavLink>
                              </div>
                           </div>

                        )
                     })}
                  </div>
               }
            </div>
         </section>
      )
   }
}

function mapStateToProps(state) {
   const { item: defaultArticle } = state.defaultArticle;
   return { defaultArticle };
}

const actionCreators = {
   getDefaultArticle: defaultArticleActions.getDefaultArticle,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexAriticle));

