import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import DatePicker from 'react-date-picker';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { classesAction, schoolsAction, professionalAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
// const GET_PROFESSIONAL = `http://schools.rajpsp.com/api/professional/read_one.php`;
const UPDATE_PROFESSIONAL = `http://schools.rajpsp.com/api/professional/update.php`;
// const READ_ALL_STAFF_IDS = `http://schools.rajpsp.com/api/professional/read_all_staff_ids.php`;

class EditProfessional extends Component {
  state = {
    current_id: '',
    prev_id: '',
    next_id: '',
    is_prev: false,
    is_next: false,
    all_staffs_ids: [],
    proff: {},
    classes: [],
    id: "",
    emp_type: "",
    emp_crnt_designation: "",
    edu_qulifi: "",
    pacific_ability: "",
    is_rtet_qlifid: "",
    appoint_date: "",
    sec_roll_no: "",
    sec_year: "",
    emp_mob: "",
    emp_cur_sub: "",
    dob: "",
    gender: "",
    caste: "",
    aadhar_no: "",
    emp_name: "",
    emp_f_name: "",
    responsibility: "",
    class_teacher: "",
    address: "",
    show_home: false,
    errorMessages: "",
    successMessages: "",
    profile_image: "",
    formIsHalfFilledOut: false,
    medium: "",
    crop: {
      unit: "%",
      width: 30,
      aspect: 1
    },
    final_size: {
      width: 400,
      height: 400
    }
  }

  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  isValidDate(date_val) {
    let d = new Date(date_val);
    // debugger;
    if (d.getTime() === d.getTime()) {
      return d;
    } else {
      return ''
    }
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
    if (fieldName === 'class_teacher') {
      var _obj = event.target.value;
      this.setState({
        class_teacher: _obj
      })
    }
  };

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    this.checkAuthentication();
  }

  checkAuthentication() {
    const { match } = this.props;
    let current_id = match.params.id;

    this.setState({
      current_id: current_id
    }, () => {
      // this.getClassesHandler();
      this.getProffRecords();
      this.getAllStaffIdsHandler()
    })

    // axios.post(VALIDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     // sessionStorage.setItem("user", getRes.data);
    //     console.log(getRes);
    //     if (getRes.data) {
    //       this.setState({
    //         user: getRes.data,
    //         group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //         school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //         user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //         session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //         current_id: current_id
    //       }, () => {
    //         this.getClassesHandler();
    //         this.getProffRecords();
    //         this.getAllStaffIdsHandler()
    //       })
    //     }
    //   }).catch((error) => {
    //     this.props.history.push('/login.jsp');
    //   })
  }


  setStaffItsHandler() {
    debugger
    const _current_id = this.state.current_id;
    const _staff_ids = this.state.all_staffs_ids;
    let _prev_id = '';
    let _next_id = '';
    let _is_prev = false;
    let _is_next = false;
    let _chnage_state = false;
    for (let i = 0; i < _staff_ids.length; i++) {

      if (_current_id === _staff_ids[i].s_id && (i >= 0 && i < _staff_ids.length)) {

        if (i === 0) {
          _prev_id = _staff_ids[_staff_ids.length - 1].s_id;
        } else {
          _prev_id = _staff_ids[i - 1].s_id;
        }

        if (i === _staff_ids.length - 1) {
          _next_id = _staff_ids[0].s_id;
        } else {
          _next_id = _staff_ids[i + 1].s_id;
        }


        _chnage_state = true;
        if (i == 0) {
          _is_prev = true;
        } else if (i == _staff_ids.length - 1) {
          _is_next = true;
        }
        break;
      }
    }

    if (_chnage_state) {
      this.setState({
        prev_id: _prev_id,
        next_id: _next_id,
        is_prev: _is_prev,
        is_next: _is_next
      })
    }
  }
  getPrevStaffRecord(e, _id) {
    e.preventDefault();
    this.setState({
      current_id: _id
    }, () => {
      this.getProffRecords();
      this.setStaffItsHandler();
      this.changeUrlHandler();
    })
  }
  changeUrlHandler() {
    this.props.history.push(`/edit_professional.jsp/${this.state.current_id}`);
  }

  getAllStaffIdsHandler() {
    const _professional = this.props.professional;
    const school_id = this.props.user.school_id;
    let all_Ids = [];
    _professional.map((item) => {
      if (item.school_id === school_id) {
        all_Ids = [...all_Ids, { s_id: item.id, emp_name: item.emp_name }]
      }
    })

    this.setState({
      all_staffs_ids: all_Ids
    }, () => {
      this.setStaffItsHandler()
    })

    // const obj = {
    //   group_id: this.state.group_id,
    //   session_year_id: this.state.session_year_id,
    //   user_category: this.state.user_category,
    //   school_id: this.state.school_id
    // }

    // console.log(JSON.stringify(obj));
    // //debugger
    // axios.post(READ_ALL_STAFF_IDS, obj)
    //   .then(res => {
    //     const resData = res.data;
    //     // console.log(resData);
    //     this.setState({
    //       all_staffs_ids: resData,
    //       errorMessages: resData.message
    //     }, () => {
    //       this.setStaffItsHandler()
    //     });
    //   }).catch((error) => {
    //     // error
    //   });
  }
  getProffRecords() {
    const staff_id = this.state.current_id;
    const _professional = this.props.professional;

    const _proff = _professional.filter((item, index) => {
      if (item.id === staff_id) {
        return item
      }
    })

    this.setState({
      proff: _proff[0]
    });

    // const staff_id = this.state.current_id;
    // //const { match } = this.props;
    // axios.get(GET_PROFESSIONAL + '?id=' + staff_id)
    //   .then(res => {
    //     const proff = res.data;
    //     //console.log(proff);
    //     const _show_home = (proff.show_home === '1') ? true : false;
    //     this.setState({
    //       proff: proff,
    //       id: proff.id,
    //       emp_type: proff.emp_type,
    //       emp_crnt_designation: proff.emp_crnt_designation,
    //       edu_qulifi: proff.edu_qulifi,
    //       pacific_ability: proff.pacific_ability,
    //       is_rtet_qlifid: proff.is_rtet_qlifid,
    //       appoint_date: this.isValidDate(proff.appoint_date),
    //       emp_mob: proff.emp_mob,
    //       emp_cur_sub: proff.emp_cur_sub,
    //       sec_roll_no: proff.sec_roll_no,
    //       sec_year: proff.sec_year,
    //       aadhar_no: res.data.aadhar_no,
    //       dob: this.isValidDate(proff.dob),
    //       gender: proff.gender,
    //       caste: proff.caste,
    //       emp_name: proff.emp_name,
    //       emp_f_name: proff.emp_f_name,
    //       profile_image: proff.profile_image,
    //       responsibility: proff.responsibility,
    //       class_teacher: proff.class_teacher,
    //       address: proff.address,
    //       medium: proff.medium,
    //       show_home: _show_home,
    //       errorMessages: res.data.message,
    //     });
    //   }).catch((error) => {
    //     // error
    //   })
  }

  dobDate = (dob) => {
    // debugger
    this.setState({ dob });
    // this.to.openCalendar();
  };
  appointDate = (appoint_date) => {
    // debugger
    this.setState({ appoint_date });
    // this.to.openCalendar();
  };
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   console.log(JSON.stringify(obj));
  //   axios.post(GET_CLASSES, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       this.setState({
  //         classes: classes,
  //         errorMessages: res.data.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  selectIndexIntoArr = (_arr, _key, _value) => {
    let _index = '';
    _arr.map((value, index) => {
      if (value[_key] === _value) { _index = index }
      return true;
    })
    return _index;
  }
  confirmBoxSubmitHandler(event) {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler() {
    loadProgressBar();
    // e.preventDefault();

    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      id: this.state.id,
      emp_name: this.state.emp_name,
      emp_f_name: this.state.emp_f_name,
      sec_roll_no: this.state.sec_roll_no,
      sec_year: this.state.sec_year,
      emp_type: this.state.emp_type,
      emp_crnt_designation: this.state.emp_crnt_designation,
      edu_qulifi: this.state.edu_qulifi,
      pacific_ability: this.state.pacific_ability,
      is_rtet_qlifid: this.state.is_rtet_qlifid,
      appoint_date: this.state.appoint_date,
      emp_mob: this.state.emp_mob,
      emp_cur_sub: this.state.emp_cur_sub,
      dob: this.state.dob,
      gender: this.state.gender,
      caste: this.state.caste,
      aadhar_no: this.state.aadhar_no,
      id: this.state.id,
      profile_image: this.state.profile_image,
      class_teacher: this.state.class_teacher,
      address: this.state.address,
      show_home: this.state.show_home,
      responsibility: this.state.responsibility,
      medium: this.state.medium,
    }
    // console.log(JSON.stringify(obj))
    // debugger
    axios.post(UPDATE_PROFESSIONAL, obj)
      .then(res => {
        const getRes = res.data;
        ////console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });

      }).catch((error) => {
      })
  }

  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      profile_image: data
    })
  }

  render() {
    const { show_home, emp_name, emp_f_name, address, class_teacher, responsibility, sec_roll_no, sec_year,
      emp_type, emp_crnt_designation, edu_qulifi, pacific_ability, is_rtet_qlifid, appoint_date, emp_mob, emp_cur_sub,
      aadhar_no, medium, dob, gender, caste, crop, final_size, profile_image, formIsHalfFilledOut,
      prev_id, next_id, is_prev, is_next, proff } = this.state;
    const { user, classes, schools, professional } = this.props;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Professional</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Edit Professional</div>
        </div>
        {user && professional && proff &&
          <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmitHandler(event)}>
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="col-md-12 col-sm-12">
                  <div className="form-body form-horizontal">
                    <div className="row">
                      <div className="col-md-2" >
                        <div className="form-group row">
                          <label className="control-label d-block pt-0 pb-2">Profile Picture</label>
                          <div className="col-md-12_">
                            <MyImage
                              //callbackFromParent={this.myCallback}
                              cropComplete={this.onComplete}
                              crop={crop}
                              final_size={final_size}
                            />
                            {!isEmpty(proff.profile_image) ?
                              < img src={`${process.env.PUBLIC_URL}` + proff.profile_image} alt="SmartPSP" className="img-thumbnail" />
                              : ('Male' === 'Male' ?
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="img-thumbnail" />
                                :
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_female.jpg`} className="img-thumbnail" />)
                            }
                          </div>
                        </div>
                        <div className="form-group">
                          <div className="custom-control custom-checkbox mt-2">
                            <input type="checkbox"
                              checked={proff.show_home}
                              id="show_home" className="custom-control-input"
                              onChange={event => this.changeHandler(event, 'show_home', true)}
                            />
                            <label className="custom-control-label" htmlFor="show_home">This Profile Show in Home page</label>
                          </div>
                        </div>


                      </div>
                      <div className="col-md-5 mt-4">
                        <div className="form-group row">
                          <label className="control-label col-md-5">Name
                        </label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.emp_name) ? proff.emp_name : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_name')}
                            />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Father's Name
                        </label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.emp_f_name) ? proff.emp_f_name : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_f_name')}
                            />
                          </div>
                        </div>

                        <div className="form-group row">
                          <label className="control-label col-md-5">Date of Birth</label>
                          <div className="col-md-7">
                            <DatePicker
                              onChange={this.dobDate}
                              value={this.isValidDate(proff.dob)}
                              showLeadingZeroes={true}
                            //minDate={new Date()}
                            />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Gender</label>
                          <div className="col-md-7">
                            <select className="form-control form-control-sm"
                              value={!isEmpty(proff.gender) ? proff.gender : ''}
                              onChange={event => this.changeHandler(event, 'gender')}>
                              <option>Select...</option>
                              <option>Male</option>
                              <option>Female</option>
                            </select>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Caste</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.caste) ? proff.caste : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'caste')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Medium</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.medium) ? proff.medium : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'medium')} />
                          </div>
                        </div>

                        <div className="form-group row">
                          <label className="control-label col-md-5">Mobile No.</label>
                          <div className="col-md-7">
                            <input type="number"
                              value={!isEmpty(proff.emp_mob) ? proff.emp_mob : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_mob')} />
                          </div>
                        </div>

                        <div className="form-group row">
                          <label className="control-label col-md-5">Address</label>
                          <div className="col-md-7">
                            <textarea name="address"
                              className="form-control-textarea form-control" rows={3}
                              value={!isEmpty(proff.address) ? proff.address : ''}
                              onChange={event => this.changeHandler(event, 'address')}></textarea>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Aadhar No.
                            </label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.aadhar_no) ? proff.aadhar_no : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'aadhar_no')}
                            />
                          </div>
                        </div>

                      </div>
                      <div className="col-md-5 mt-4" >
                        <div className="form-group row">
                          <label className="control-label col-md-5">Emp. Type</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.emp_type) ? proff.emp_type : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_type')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Emp Crnt Designation</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.emp_crnt_designation) ? proff.emp_crnt_designation : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_crnt_designation')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Education Quali.</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.edu_qulifi) ? proff.edu_qulifi : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'edu_qulifi')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Pacific Ability</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.pacific_ability) ? proff.pacific_ability : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'pacific_ability')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">RTET / REET / CTET</label>
                          <div className="col-md-7">
                            <select className="form-control form-control-sm"
                              value={!isEmpty(proff.is_rtet_qlifid) ? proff.is_rtet_qlifid : ''}
                              onChange={event => this.changeHandler(event, 'is_rtet_qlifid')}>
                              <option>Select...</option>
                              <option>No</option>
                              <option>Yes</option>
                            </select>
                            <small className="form-text text-muted">qualified ?</small>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Appointment Date</label>
                          <div className="col-md-7">
                            <DatePicker
                              onChange={this.appointDate}
                              value={this.isValidDate(appoint_date)}
                              showLeadingZeroes={true}
                            //minDate={new Date()}
                            />
                            {/* <input type="text" name="appoint_date"
                            placeholder={appoint_date}
                            className="form-control form-control-sm"
                          onChange={event => this.changeHandler(event, 'appoint_date')} /> */}
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Secondary Roll No.</label>
                          <div className="col-md-7">
                            <input type="number"
                              value={!isEmpty(proff.sec_roll_no) ? proff.sec_roll_no : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'sec_roll_no')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Secondary Year</label>
                          <div className="col-md-7">
                            <input type="number"
                              value={!isEmpty(proff.sec_year) ? proff.sec_year : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'sec_year')} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="control-label col-md-5">Current Subject</label>
                          <div className="col-md-7">
                            <input type="text"
                              value={!isEmpty(proff.emp_cur_sub) ? proff.emp_cur_sub : ''}
                              className="form-control form-control-sm"
                              onChange={event => this.changeHandler(event, 'emp_cur_sub')} />
                          </div>
                        </div>

                        <div className="form-group row">
                          <label className="control-label col-md-5">Class Teacher</label>
                          <div className="col-md-7">
                            {(classes.length > 0) ?
                              <select className="form-control form-control-sm"
                                value={!isEmpty(proff.class_teacher) ? proff.class_teacher : ''}
                                onChange={event => this.changeHandler(event, 'class_teacher')}>
                                <option>Select...</option>
                                {classes.map((option, index) => {
                                  return (
                                    <option key={index} >{option.class_name}</option>
                                  )
                                })}
                              </select>
                              : <p className="text-danger">Classes Not Found</p>}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-group">
                      <label className="control-label mb-2">Responsibility</label>
                      <textarea name="responsibility" className="form-control-textarea form-control"
                        rows={3}
                        value={!isEmpty(proff.responsibility) ? proff.responsibility : ''}
                        onChange={event => this.changeHandler(event, 'responsibility')}></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="card-footer d-flex p-2">
              <button type="button"
                onClick={event => this.getPrevStaffRecord(event, prev_id)}
                disabled={is_prev}
                className="btn btn-primary text-white">
                <i className="fa fa-angle-left"></i>
              </button>
              <button type="button"
                onClick={event => this.getPrevStaffRecord(event, next_id)}
                disabled={is_next}
                className="btn btn-primary ml-3 text-white">
                <i className="fa fa-angle-right"></i>
              </button>
              <button type="submit" className="btn btn-primary mr-2 ml-auto">Submit</button>
              <NavLink className="btn btn-danger" to="/all_professionals.jsp">Cancel</NavLink>
            </div>
          </form>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: professional } = state.professional;
  return { user, schools, classes, professional };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
  getSchools: schoolsAction.getSchools,
  getProfessional: professionalAction.getProfessional,
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditProfessional));