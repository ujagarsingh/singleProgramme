import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import Alert from 'react-s-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { frontArticleActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_ARTICLES = `http://schools.rajpsp.com/api/articles/read.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/articles/delete.php`;

class AllArticle extends Component {
  state = {
    article_arr: [],
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  componentDidMount() {
    if (isEmptyObj(this.props.frontArticle)) {
      this.props.getFrontArticle();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getArticleHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // };

  // getArticleHandler() {
  //   loadProgressBar();
  //   axios.get(GET_ARTICLES)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         article_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.article_arr);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  deleteHandlar = (event) => {
    event.preventDefault();
    const _id = event.target.value;

    axios.post(DELETE_URL + '?id=' + _id)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        const _events = this.state.events.filter((item, index) => {
          return item.id !== _id
        })
        this.setState({
          events: _events
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }

  render() {
    const { formIsHalfFilledOut } = this.state;
    const { user, frontArticle } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>All Article</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title">All Article</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Title</th>
                    <th> Detail </th>
                    <th> Action </th>
                  </tr>
                </thead>
                {frontArticle &&
                  <tbody>
                    {frontArticle.map((item, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}</td>
                          <td>{item.title}</td>
                          <td>{item.description}</td>
                          <td>
                            <NavLink className="btn btn-primary btn-sm"
                              to={`/update_article.jsp/${item.id}`}>
                              Edit
                          </NavLink>
                            {/*<button className="btn btn-danger btn-sm"
                            value={item.id}
                    onClick={event => this.deleteHandlar(event)}>Del</button>*/}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                }
              </table>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontArticle } = state.frontArticle;
  return { user, frontArticle };
}

const actionCreators = {
  getFrontArticle: frontArticleActions.getFrontArticle,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllArticle));