import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class NotFound extends Component {
  render() {
    return (
      <div >
        <Helmet>
          <title>Email Compose</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        Not Found</div>
    )
  }
}
export default NotFound;