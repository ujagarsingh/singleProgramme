import React, { Component } from 'react';
import { withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
// import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class SingleSheduleIdCard extends Component {
   state = {
   }
   isEmpty(val) {
      return (val === undefined || val == null || val.length <= 0) ? true : false;
    }
   
   dateInWords(date_obj) {
      let d = new Date(date_obj);
      let monthNames = [
         "Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      ];
      let newDate = d.getDate() + "-" + monthNames[d.getMonth()] + "-" + d.getFullYear();;
      return newDate;
   }
   nuberInWords = (price) => {
      var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
         dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
         tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
         handle_tens = function (dgt, prevDgt) {
            return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
         },
         handle_utlc = function (dgt, nxtDgt, denom) {
            return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
         };

      var str = "",
         digitIdx = 0,
         digit = 0,
         nxtDigit = 0,
         words = [];
      if (price += "", isNaN(parseInt(price))) str = "";
      else if (parseInt(price) > 0 && price.length <= 10) {
         for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--) switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
            case 0:
               words.push(handle_utlc(digit, nxtDigit, ""));
               break;
            case 1:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 2:
               words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
               break;
            case 3:
               words.push(handle_utlc(digit, nxtDigit, "Thousand"));
               break;
            case 4:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 5:
               words.push(handle_utlc(digit, nxtDigit, "Lakh"));
               break;
            case 6:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 7:
               words.push(handle_utlc(digit, nxtDigit, "Crore"));
               break;
            case 8:
               words.push(handle_tens(digit, price[digitIdx + 1]));
               break;
            case 9:
               words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "")
         }
         str = words.reverse().join("")
      } else str = "";
      return str

   }
   render() {
      const { key_index, update_student, school_logo, school_medium, school_name, school_address, exam_name, session_year_id } = this.props;
      // console.log(this.props)
      return (
         <div className="clearfix shedule-id-card" key={key_index}>
            <div className="row mb-2">
               <div className="col-3">
                  {school_logo !== '' ?
                     <img src={`${process.env.PUBLIC_URL}` + school_logo} width="130" alt={school_name} />
                     : null
                  }
               </div>
               <div className="col-6">
                  <div className="text-center">
                     <h4 className="text-uppercase">{school_name}</h4>
                     <h5>[ Medium : {school_medium} ]</h5>
                     <p className="mb-2"><b>{school_address}</b></p>
                     <p className="mb-3"><b>{exam_name} - {session_year_id}</b></p>
                     <h5>Exam ID-Card</h5>
                  </div>
               </div>
               <div className="col-3">
                  <div className="float-right">
                     <div className="img-thumbnail" >
                        {!this.isEmpty(update_student.student_image) ?
                           < img src={`${process.env.PUBLIC_URL}` + update_student.student_image} width="130" alt={update_student.student_name} />
                           : (update_student.gender === 'Boy' ?
                              <img alt="SmartPSP" width="130" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                              :
                              <img alt="SmartPSP" width="130" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                        }
                     </div>
                  </div>
               </div>
            </div>
            <div className="d-flex">
               <div className="w-100">
                  <div className="row">
                     <div className="col-9">
                        <table className="table table-sm table-bordered m-0 user-data">
                           <tbody>
                              <tr>
                                 <td>Roll No. : </td>
                                 <td colSpan="3">
                                    <span className="roll-no"><b>{update_student.roll_number}</b></span>
                                 </td>
                              </tr>
                              <tr>
                                 <td></td>
                                 <td colSpan="3">
                                    <span className="roll-no">{this.nuberInWords(update_student.roll_number)}</span>
                                 </td>
                              </tr>
                              <tr>
                                 <td>Student's Name:</td>
                                 <td>
                                    <b>{update_student.student_name}</b>
                                 </td>
                                 <td> Enrol No.: </td>
                                 <td>
                                    <b>{update_student.admission_number}</b>
                                 </td>
                              </tr>
                              <tr>
                                 <td>Father's Name</td>
                                 <td>
                                    Mr. {update_student.father_name}
                                 </td>
                                 <td>Date of Birth</td>
                                 <td>
                                    <b>{this.dateInWords(update_student.dob)}</b>
                                 </td>
                              </tr>
                              <tr>
                                 <td>Mother's Name</td>
                                 <td>
                                    Mrs. {update_student.mother_name}
                                 </td>
                                 <td> Class : </td>
                                 <td>
                                    <b> {update_student.stu_class}</b>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <div className="col-3">
                        <span className="d-flex justify-content-end text-center flex-column h-100">
                           <b>PRINCIPAL SIGN WITH SEAL</b>
                        </span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      )
   }
}
export default withRouter(SingleSheduleIdCard);