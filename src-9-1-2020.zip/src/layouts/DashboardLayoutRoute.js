import React, { Component } from "react";
import { withRouter } from 'react-router';
import { Route, Redirect } from "react-router-dom";

import DashboardLayout from "./DashboardLayout";

class DashboardLayoutRoute extends Component {
  render() {
    const { component: Component, ...rest } = this.props;
    return (
      <Route {...rest} render={matchProps => (
        sessionStorage.getItem('app_state')
          ? <DashboardLayout>
            <Component {...matchProps} />
          </DashboardLayout>
          : <Redirect to={{ pathname: '/login.jsp' }} />
      )} />
    )
  }
}

export default withRouter(DashboardLayoutRoute);
