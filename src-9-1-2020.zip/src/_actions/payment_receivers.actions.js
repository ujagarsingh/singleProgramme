import { paymentReceiverConstants } from '../_constants';
import { paymentReceiverService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const paymentReceiverAction = {
    getPaymentReceiver
};

function getPaymentReceiver() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        paymentReceiverService.getPaymentReceiver()
            .then(
                response => {
                    dispatch(success(response.data.payment_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: paymentReceiverConstants.PAYMENT_RECEIVER_REQUEST } }
    function success(response) { return { type: paymentReceiverConstants.PAYMENT_RECEIVER_SUCCESS, response } }
    function failure(error) { return { type: paymentReceiverConstants.PAYMENT_RECEIVER_FAILURE, error } }
}
 