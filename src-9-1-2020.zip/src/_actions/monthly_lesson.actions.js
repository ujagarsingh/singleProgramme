import { monthlyLessonConstants } from '../_constants';
import { monthlyLessonService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const monthlyLessonAction = {
    getMonthlyLesson,
    create,
    update,
    delete: _delete
};

function getMonthlyLesson(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        monthlyLessonService.getMonthlyLesson(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.monthly_lesson)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: monthlyLessonConstants.LESSON_REQUEST } }
    function success(response) { return { type: monthlyLessonConstants.LESSON_SUCCESS, response } }
    function failure(error) { return { type: monthlyLessonConstants.LESSON_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        monthlyLessonService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.monthly_lesson),
                        toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: monthlyLessonConstants.CREATE_LESSON_REQUEST } }
    function success(response) { return { type: monthlyLessonConstants.CREATE_LESSON_SUCCESS, response } }
    function failure(error) { return { type: monthlyLessonConstants.CREATE_LESSON_FAILURE, error } }
}

function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        monthlyLessonService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.update_lesson),
                        toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: monthlyLessonConstants.UPDATE_LESSON_REQUEST } }
    function success(response) { return { type: monthlyLessonConstants.UPDATE_LESSON_SUCCESS, response } }
    function failure(error) { return { type: monthlyLessonConstants.UPDATE_LESSON_FAILURE, error } }
}

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        monthlyLessonService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.id),
                        toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: monthlyLessonConstants.DELETE_LESSON_REQUEST } }
    function success(response) { return { type: monthlyLessonConstants.DELETE_LESSON_SUCCESS, response } }
    function failure(error) { return { type: monthlyLessonConstants.DELETE_LESSON_FAILURE, error } }
}
