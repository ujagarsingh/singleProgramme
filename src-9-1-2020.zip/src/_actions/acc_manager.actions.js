import { accManagerConstants } from '../_constants';
import { accManagerService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accManagerActions = {
    getACCManager,
    getLedgerSummaryofFinancialYearHandler,
    getLedgerSummaryofMonthHandler,
    getVoucherEntryHandler
};


function getACCManager(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accManagerService.getACCManager(obj)
            .then(
                response => {
                    dispatch(success(response.data.acc_manager));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accManagerConstants.ACC_MANAGER_REQUEST} }
    function success(response) { return { type: accManagerConstants.ACC_MANAGER_SUCCESS, response } }
    function failure(error) { return { type: accManagerConstants.ACC_MANAGER_FAILURE, error } }
}
  
function getLedgerSummaryofFinancialYearHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accManagerService.getLedgerSummaryofFinancialYearHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: accManagerConstants.ACC_LDR_YEAR_REPORT_REQUEST } }
    function success(response) { return { type: accManagerConstants.ACC_LDR_YEAR_REPORT_SUCCESS, response } }
    function failure(error) { return { type: accManagerConstants.ACC_LDR_YEAR_REPORT_FAILURE, error } }
}
  
  
function getLedgerSummaryofMonthHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accManagerService.getLedgerSummaryofMonthHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data.ledger_summary_of_month));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_REQUEST } }
    function success(response) { return { type: accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_SUCCESS, response } }
    function failure(error) { return { type: accManagerConstants.ACC_LDR_SUMMARY_OF_MONTH_FAILURE, error } }
}
  
function getVoucherEntryHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accManagerService.getVoucherEntryHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data.single_voucer));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: accManagerConstants.ACC_SINGLE_VOUCHER_REQUEST } }
    function success(response) { return { type: accManagerConstants.ACC_SINGLE_VOUCHER_SUCCESS, response } }
    function failure(error) { return { type: accManagerConstants.ACC_SINGLE_VOUCHER_FAILURE, error } }
}
  
   
