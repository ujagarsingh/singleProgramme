import { classesConstants } from '../_constants';
import { classesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classesAction = {
    getClasses,
    create,
    update
};

function getClasses() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classesService.getClasses()
            .then(
                response => {
                    dispatch(success(response.data.classes_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classesConstants.CLASSES_REQUEST } }
    function success(response) { return { type: classesConstants.CLASSES_SUCCESS, response } }
    function failure(error) { return { type: classesConstants.CLASSES_FAILURE, error } }
}
 
function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classesService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),
                    toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classesConstants.CREATE_REQUEST } }
    function success(response) { return { type: classesConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: classesConstants.CREATE_FAILURE, error } }
}
 
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classesService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classesConstants.UPDATE_REQUEST } }
    function success(response) { return { type: classesConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: classesConstants.UPDATE_FAILURE, error } }
}
 