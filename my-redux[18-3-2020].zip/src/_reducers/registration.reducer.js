import { userConstants } from '../_constants';

export function registration(state = {}, action) {
  switch (action.type) {
    case userConstants.REGISTER_REQUEST:
	// // debugger
      return { registering: true };
    case userConstants.REGISTER_SUCCESS:
	// // debugger
      return {};
    case userConstants.REGISTER_FAILURE:
	// // debugger
      return {};
    default:
	// // debugger
      return state
  }
}