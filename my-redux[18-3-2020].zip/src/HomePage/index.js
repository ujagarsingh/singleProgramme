import React, { Component } from 'react';  
const FaqsPage = ({  classes }) => {  
    return (  
      <div>  
        <h1>faq</h1>
      </div>
    );  
  };  
  
export default FaqsPage