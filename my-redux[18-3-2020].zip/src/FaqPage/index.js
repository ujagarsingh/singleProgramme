import React, { Component } from 'react';  
const IndexPage = ({  classes }) => {  
    return (  
      <div>  
  {/* Main Wrapper */}
  <div className="main" role="main">
    {/* Hero */}
    <div className="ui-hero hero-lg hero-center hero-bg ui-curve hero-svg-layer-4 bg-dark-gray">
      <div className="container">
        <div className="row pt-2 pb-6">
          <div className="col-sm-12" data-vertical_center="true" data-vertical_offset={16}>
            <h1 className="heading animate" data-show="fade-in-up-big" data-delay={100}>
              The <span className="text-red">easiest</span> &amp; most <span className="text-red">secure</span> online school managment system
            </h1>
            {/* Form */}
            <form autoComplete="on" className="pt-2">
              <div className="form-group">
                <div className="input-group">
                  {/* Email Input */}
                  <input autoComplete="email" className="input form-control" data-validation="required" data-validation-error-msg="Invalid email" name="email" placeholder="Enter your email" />
                  <div className="input-group-append">
                    {/* Submit Button */}
                    <button className="btn ui-gradient-peach">Lets go! <span className="la la-rocket" /></button>
                  </div>
                </div>
              </div>
            </form>
            {/* * Replace data-video with your youtube video id */}
            <a href="#" className="ui-video-toggle mt-4" data-video="1C75bKax4Eg">
              <i className />
              <span className="icon la la-play bg-red" /> <span>How RajPSP Works</span>
            </a>
          </div>
        </div>{/* .row */}
      </div>{/* .container */}
    </div>{/* .ui-hero */}
    {/* Intro Image */}
    <div className="section intro-image pt-0">
      <img src="assets/demo/img/mockups/shala-darpan-browser-mockup.png" data-uhd data-max_width={1000} className="shadow-xxl responsive-on-lg" alt="RajPSP - Online School Managment" />
    </div>{/* .intro-image */}
    {/* App Features Section */}
    <div id="modules-of-online-school-managment" className="section pt-0">
      <div className="container ui-icon-blocks ui-blocks-h icons-lg">
        <div className="section-heading cente">
          <h2 className="heading text-dark-gray">
            Modules of RajPSP
          </h2>
          <p className="paragraph">
            These are RajPSP online school management system Modules..
          </p>
        </div>{/* .section-heading */}
        <div className="row">
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-graduation-cap icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Student Admission Management</h4>
            <p>
              The organization can handle all complicated process of admission with ease. This includes prospectus sale, student registration, verification &amp; finalization, etc.
            </p>
          </div>
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-user-check icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Fee Tracking System</h4>
            <p>
              This module provides a convenient platform for taking student's attendance online via smart phone. Parents will receive SMS about their ward's presence in the campus.
            </p>
          </div>
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-id-card icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Exam Managment</h4>
            <p>
              Through this School Edu module, school authorities can design and print student identity card as per their standard format.
            </p>
          </div>
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-door-open icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Web Portal Managment</h4>
            <p>
              Parents/ Students will receive a secured login to perform various activities. Parents can also check their ward's attendance, results, fee dues, etc.
            </p>
          </div>
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-certificate icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Student/Staff Login</h4>
            <p>
              Each authorized staff member will receive secured login to perform various tasks efficiently depending on the liberty assigned to them.
            </p>
          </div>
          <div className="col-sm-4 ui-icon-block">
            <div className="las la-bullseye icon icon-lg icon-circle text-red" />
            <h4 className="text-dark-gray">Multiple Schools Management</h4>
            <p>
              Using this module, schools can define class wise examination scheme, subject offered grades, passing criteria. Any type grace and exam rules can be defined by users.
            </p>
          </div>
        </div>{/* .row */}
        <p className="paragraph">
          and many more...
        </p>
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Steps Section */}
    <div id="features" className="section bg-light">
      <div className="container">
        {/* Section Heading */}
        <div className="section-heading center">
          <h2 className="heading text-dark-gray">
            Awesome Features
          </h2>
          <p className="paragraph">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          </p>
        </div>{/* .section-heading */}
        {/* UI Steps */}
        <div className="ui-showcase-blocks ui-steps">
          {/* Step 1 */}
          <div className="step-wrapper">
            <span className="step-number ui-gradient-blue">1</span>
            <div className="row">
              <div className="col-md-6" data-vertical_center="true">
                <h4 className="heading text-dark-gray">
                  Global Presence
                </h4>
                <p className="paragraph">
                  This Application can be use use in all devices. It is smoothly used and responsible for Mobile, Laptop, and Desktop.
                </p>
                <a href="#" className="btn-link btn-arrow">Explore</a>
              </div>
              <div className="col-md-6">
                <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-7.png" data-uhd alt="RajPSP - Online School Managment" data-max_width={464} />
              </div>
            </div>
          </div>
          {/* Step 2 */}
          <div className="step-wrapper">
            <span className="step-number ui-gradient-blue">2</span>
            <div className="row">  
              <div className="col-md-6" data-vertical_center="true">
                <h4 className="heading text-dark-gray">
                  Report's Analytics
                </h4>
                <p className="paragraph">
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <a href="#" className="btn-link btn-arrow">Explore</a>
              </div>
              <div className="col-md-6">
                <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-8.png" data-uhd alt="RajPSP - Online School Managment" data-max_width={445} />
              </div>
            </div>
          </div>
          {/* Step 3 */}
          <div className="step-wrapper">
            <span className="step-number ui-gradient-blue">3</span>
            <div className="row">
              <div className="col-md-6" data-vertical_center="true">
                <h4 className="heading text-dark-gray">
                  Easy to use
                </h4>
                <p className="paragraph">
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <a href="#" className="btn-link btn-arrow">Explore</a>
              </div>
              <div className="col-sm-6">
                <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-10.png" data-uhd alt="RajPSP - Online School Managment" data-max_width={451} />
              </div>
            </div>
          </div>
          {/* Step 4 */}
          <div className="step-wrapper">
            <span className="step-number ui-gradient-blue">2</span>
            <div className="row">  
              <div className="col-md-6" data-vertical_center="true">
                <h4 className="heading text-dark-gray">
                  Suggestion &amp; Promotion Income
                </h4>
                <p className="paragraph">
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <a href="#" className="btn-link btn-arrow">Explore</a>
              </div>
              <div className="col-md-6">
                <img className="responsive-on-xs" src="assets/img/mockups/shala-darpan-mockup-8.png" data-uhd alt="RajPSP - Online School Managment" data-max_width={445} />
              </div>
            </div>
          </div>
        </div>
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Integration Section */}
    <div id="used-technology" className="section ui-gradient-blue">
      <div className="container">
        <div className="row">
          {/* Left Column */}
          <div className="col-lg-5 col-xl-6" data-vertical_center="true">
            {/* Section Heading */}
            <div className="section-heading mb-2">
              <h2 className="heading">
                Used Technology in Software
              </h2>
              <p className="paragraph">
                Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Ali
              </p>
            </div>{/* .section-heading */}
            {/* Left blocks */}
            <ul className="ui-icon-blocks ui-blocks-v icons-sm">
              <li className="ui-icon-block">
                <span className="la la-gem icon" />
                <p className>
                  Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore
                </p>
                <a className="btn-link btn-arrow">
                  Learn More 
                </a>
              </li>
              <li className="ui-icon-block">
                <span className="la la-chart-pie icon" />
                <p className>
                  Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit
                </p>
                <a className="btn-link btn-arrow">
                  Learn More 
                </a>
              </li>
              <li className="ui-icon-block">
                <span className="la la-layer-group icon" />
                <p className>
                  Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit Sed Do Eiusmod 
                </p>
                <a className="btn-link btn-arrow">
                  Learn More
                </a>
              </li>
            </ul>
          </div>
          {/* Right Column */}
          <div className="col-lg-7 col-xl-6">
            {/* Logo Cloud */}
            <div className="ui-logos-cloud">
              <div data-size={4} className="mt-0 animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/quickbooks.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={10} className="mt-0 animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/salesforce.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={7} className="mt-0 animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/git.svg" alt="Applif Online School Managment" />
              </div>
              {/* Flex Break */}
              <span className="flex-break" />
              <div data-size={4} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/webflow.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={10} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/shopify.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={4} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/mailchimp.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={6} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/magento.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={3} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/bigcommerce.svg" alt="Applif Online School Managment" />
              </div>
              {/* Flex Break */}
              <span className="flex-break" />
              <div data-size={8} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/squarespace.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={3} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/sharepoint.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={10} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/slack.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={5} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/paypal.svg" alt="Applif Online School Managment" />
              </div>
              {/* Flex Break */}
              <span className="flex-break" />
              <div data-size={3} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/fresh-desk.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={10} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/stripe.svg" alt="Applif Online School Managment" />
              </div>
              <div data-size={7} className="animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/woocommerce.svg" alt="Applif Online School Managment" />
              </div>
              {/* Flex Break */}
              <span className="flex-break" />
              <div data-size={4} className="mb-0 animate" data-show="fade-in">
                <img src="assets/img/3rd-party-logos/xero.svg" alt="Applif Online School Managment" />
              </div>
            </div>{/* .ui-logo-cloud  */}
          </div>
        </div>{/* .row */}
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Showcase Section 
   		<div class="section laptop-showcase">
   			<div class="container">
   				<div class="row">
              <div class="col-md-5 col-lg-4" data-vertical_center="true">
	                    <div>
	                        <h2 class="heading text-dark-gray">
	                            Designed For All Apps
	                        </h2>
	                        <p>
	                            Lorem ipsum dolor  sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
	                        </p>
	                        <ul class="ui-checklist mt-2">
	                            <li>
	                                <h6 class="heading text-dark-gray">Consectetur adipisicing</h6>
	                            </li>
	                            <li>
	                                <h6 class="heading text-dark-gray">Eiusmod tempor incididunt</h6>
	                            </li>
	                            <li>
	                                <h6 class="heading text-dark-gray">Ut enim ad minim</h6>
	                            </li>
	                        </ul>
	                        <a href="#" class="btn ui-gradient-peach">Download</a>
	                    </div>
              </div>
              <div class="col-md-7 col-lg-8">
                  <img class="responsive-on-sm laptop" src="assets/demo/img/mockups/shala-darpan-mockup-11.png" data-uhd alt="RajPSP - Online School Managment" data-max_width="1000" />
              </div>
          </div>
        
   			</div><!-- .container  
   		</div><!-- .section */}
    {/* Showcase Section */}
    <div className="section pb-6">
      <div className="container ">
        <div className="multi-slider-con">
          <div className="multi-slider">
            <div className="slidercontainer mobile-view">  
              <div className="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-1.jpg" />  
                <div className="content">Slide1 heading</div>  
              </div>  
              <div className="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-0.jpg" />  
                <div className="content">Slide2 heading</div>  
              </div>  
              <div className="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-1.jpg" />  
                <div className="content">Slide3 heading</div>  
              </div>  
              <div className="showSlide animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-m-0.jpg" />  
                <div className="content">Slide4 heading</div>  
              </div>  
              {/* Navigation arrows
  <a class="left" onclick="nextSlide(-1)">❮</a>  
  <a class="right" onclick="nextSlide(1)">❯</a>  
		 */}  
            </div>  
            <div className="slidercontainer tab-vlew">  
              <div className="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-1.jpg" />  
                <div className="content">Slide1 heading</div>  
              </div>  
              <div className="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-0.jpg" />  
                <div className="content">Slide2 heading</div>  
              </div>  
              <div className="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-1.jpg" />  
                <div className="content">Slide3 heading</div>  
              </div>  
              <div className="showSlide0 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-t-0.jpg" />  
                <div className="content">Slide4 heading</div>  
              </div>  
              {/* Navigation arrows
  <a class="left" onclick="nextSlide(-1)">❮</a>  
  <a class="right" onclick="nextSlide(1)">❯</a>  
		 */}  
            </div>  
            <div className="slidercontainer laptop-view">  
              <div className="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-1.jpg" />  
                <div className="content">Slide1 heading</div>  
              </div>  
              <div className="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-0.jpg" />  
                <div className="content">Slide2 heading</div>  
              </div>  
              <div className="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-1.jpg" />  
                <div className="content">Slide3 heading</div>  
              </div>  
              <div className="showSlide1 animate animated fade-in-bottom">  
                <img src="assets/img/slider/fullimage-l-0.jpg" />  
                <div className="content">Slide4 heading</div>  
              </div>  
            </div>  
          </div>  
          {/* Navigation arrows */}  
          <div className="controls">
            <a className="left" onclick="nextSlide(-1)">❮</a>  
            <a className="right" onclick="nextSlide(1)">❯</a>  
          </div>
        </div>
      </div>{/* .container */}
    </div>
    {/* Support Section */}
    <div id="support" className="section bg-dark-gray">
      <div className="container">
        <div className="row">
          {/* Text Column */}
          <div className="col-lg-6 col-md-5" data-vertical_center="true">
            {/* Section Heading */}
            <div className="section-heading mb-0 center-on-md">
              <h2 className="heading">
                Mirror of Success
              </h2>
              <p className="paragraph">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
              </p>
              <div className="row ui-icon-blocks ui-blocks-h icons-md mt-2">
                <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                  <div className="la la-phone icon" />
                  <h4 className="heading mb-1">200k</h4>
                  <p>
                    Happy Clients
                  </p>
                </div>
                <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                  <div className="las la-trophy icon" />
                  <h4 className="heading mb-1">4.5</h4>
                  <p>
                    Student's Recored Manage
                  </p>
                </div>
                <div className="col-4 ui-icon-block animate text-left mb-0 center-on-md" data-show="fade-in-up">
                  <div className="la la-support icon" />
                  <h4 className="heading mb-1">500k <small>(upto)</small></h4>
                  <p>
                    income by Suggestion and Promotiton
                  </p>
                </div>
              </div>{/* .row */}
            </div>{/* .section-heading */}
          </div>
          {/* Image Column */}
          <div className="col-lg-6 col-md-7 img-block animate" data-show="fade-in-left" data-vertical_center="true">
            <img src="assets/img/support/shala-darpan-support.png" alt="RajPSP - Online School Managment" data-uhd className="img-fluid" data-max_width={460} />
          </div>
        </div>{/* .row */}
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Pricing Cards Section */}
    <div id="pricing" className="section bg-light">
      <div className="container">
        {/* Section Heading */}
        <div className="section-heading center">
          <h2 className="heading text-dark-gray">
            Pricing Cards
          </h2>
          <p className="paragraph">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          </p>
        </div>{/* .section-heading */}
        {/* UI Pricing Cards / Owl Carousel On Mobile */}
        <div className="ui-pricing-cards owl-carousel owl-theme">
          {/* Card 1 */}
          <div className="ui-pricing-card animate" data-show="fade-in-left">
            <div className="ui-card ui-curve shadow-lg">
              <div className="card-header bg-dark-gray">
                {/* Heading */}
                <h4 className="heading">Free Plan</h4>
                {/* Price */}
                <div className="price text-red">
                  <span className="curency">£</span>
                  <span className="price">Free</span>
                  <span className="period">/year</span>
                </div>
                <h6 className="sub-heading">On the RajPSP.com</h6>
              </div>
              {/* Features */}
              <div className="card-body">
                <ul>
                  <li>
                    No Backup
                  </li>
                  <li>
                    No Support
                  </li>
                  <li>
                    Single User
                  </li>
                  <li>
                    Upto 250 Student
                  </li>
                </ul>
                <a href="page-pricing.html" className="btn shadow-md ui-gradient-peach">Get Started</a>
              </div>
            </div>
          </div>
          {/* Card 2 */}
          <div className="ui-pricing-card active animate" data-show="fade-in">
            <div className="ui-card ui-curve color-card shadow-xl">
              <div className="card-header ui-gradient-peach">
                {/* Heading */}
                <h4 className="heading">Silver</h4>
                {/* Price */}
                <div className="price">
                  <span className="curency">£</span>
                  <span className="price">57</span>
                  <span className="period">/mo</span>
                </div>
                <h6 className="sub-heading">On the RajPSP.com</h6>
              </div>
              {/* Features */}
              <div className="card-body">
                <ul>
                  <li>
                    Every 15 Day's Backup 
                  </li>
                  <li>
                    Support on Request
                  </li>
                  <li>
                    Admin, Student Login
                  </li>
                  <li>
                    No Limit
                  </li>
                </ul>
                <a href="page-pricing.html" className="btn bg-dark-gray shadow-md">Get Started</a>
              </div>
            </div>
          </div>
          {/* Card 3 */}
          <div className="ui-pricing-card animate" data-show="fade-in-right">
            <div className="ui-card ui-curve shadow-lg">
              <div className="card-header bg-dark-gray">
                {/* Heading */}
                <h4 className="heading">Gold</h4>
                {/* Price */}
                <div className="price text-red">
                  <span className="curency">£</span>
                  <span className="price">89</span>
                  <span className="period">/mo</span>
                </div>
                <h6 className="sub-heading">With Web Portal</h6>
              </div>
              {/* Features */}
              <div className="card-body">
                <ul>
                  <li>
                    Every 15 Day's Backup 
                  </li>
                  <li>
                    Support 24/7
                  </li>
                  <li>
                    Admin, Staff and Student Login
                  </li>
                  <li>
                    No Limit
                  </li>
                </ul>
                <a href="page-pricing.html" className="btn ui-gradient-peach shadow-md">Get Started</a>
              </div>
            </div>
          </div>
        </div>{/* .ui-pricing-cards */}
        {/* Pricing Footer */}
        <div className="ui-pricing-footer">
          <p className="paragraph">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.
          </p>
          <div className="actions">
            <a className="btn">Learn More</a>
          </div>
        </div>{/* .ui-pricing-footer */}
      </div>{/* .container */}
    </div>{/* .section */}
    {/*  Testimonial Section */}
    <div className="section">
      <div className="container">
        {/* Card Heading */}
        <div className="section-heading center">
          <h2 className="heading text-dark-gray">
            What People Say
          </h2>
          <p className="paragraph">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          </p>
        </div>{/* .section-heading */}
        {/* Slider  */}
        <div className="ui-testimonials slider owl-carousel owl-theme">
          {/* Testimonials Item 1 */}
          <div className="item">
            {/* Card */}
            <div className="ui-card shadow-md">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
            </div>
            {/* User */}
            <div className="user">
              <div className="avatar"><img alt="RajPSP Online School Managment" src="assets/img/avatars/avatar1-sm.png" /></div>
              <div className="info">
                <h6 className="heading text-dark-gray">Vicky Stout</h6>
                <p className="sub-heading">Founder at Smith &amp; Co</p>
              </div>
            </div>
          </div>
          {/* Testimonials Item 2 */}
          <div className="item">
            {/* Card */}
            <div className="ui-card shadow-md">
              <p> Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
            </div>
            {/* User */}
            <div className="user">
              <div className="avatar"><img alt="RajPSP Online School Managment" src="assets/img/avatars/avatar2-sm.png" /></div>
              <div className="info">
                <h6 className="heading text-dark-gray">Jack Smith</h6>
                <p className="sub-heading">Founder at Smith &amp; Co</p>
              </div>
            </div>
          </div>
          {/* Testimonials Item 3 */}
          <div className="item">
            {/* Card */}
            <div className="ui-card shadow-md">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariaturin.</p>
            </div>
            {/* User */}
            <div className="user">
              <div className="avatar"><img alt="RajPSP Online School Managment" src="assets/img/avatars/avatar3-sm.png" /></div>
              <div className="info">
                <h6 className="heading text-dark-gray">Chérel Doe</h6>
                <p className="sub-heading">Founder at Smith &amp; Co</p>
              </div>
            </div>
          </div>
          {/* Testimonials Item 4 */}
          <div className="item">
            {/* Card */}
            <div className="ui-card shadow-md">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur ac nisi.</p>
            </div>
            {/* User */}
            <div className="user">
              <div className="avatar"><img alt="RajPSP Online School Managment" src="assets/img/avatars/avatar4-sm.png" /></div>
              <div className="info">
                <h6 className="heading text-dark-gray">Derick Watts</h6>
                <p className="sub-heading">Founder at Smith &amp; Co</p>
              </div>
            </div>
          </div>
          {/* Testimonials Item 5*/}
          <div className="item">
            {/* Card */}
            <div className="ui-card shadow-md">
              <p>Donec elementum ligula eu sapien consequat eleifend. Donec nec dolor erat, condimentum sagittis.</p>
            </div>
            {/* User */}
            <div className="user">
              <div className="avatar"><img alt="RajPSP Online School Managment" src="assets/img/avatars/avatar5-sm.png" /></div>
              <div className="info">
                <h6 className="heading text-dark-gray">Jane Austin</h6>
                <p className="sub-heading">Founder at Smith &amp; Co</p>
              </div>
            </div>
          </div>
        </div>{/* .ui-testimonials  */}
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Footer */}
    <footer className="ui-footer bg-gray">
      <div className="container pt-6 pb-6">
        <div className="row">
          <div className="col-md-4 col-sm-6 footer-about footer-col center-on-sm">
            <img src="assets/img/logo/shala-darpan-logo-white.png" data-uhd alt="Applif - Online School Managment" />
            <p className="mt-1">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Donec elementum ligula eu sapien consequat eleifend.
            </p>
          </div>
          <div className="col-md-2 col-6 footer-col">
            {/* <h6 class="heading footer-heading">Quick Nav</h6>
                  <ul class="footer-nav">
                      <li>
                          <a href="demo-mobile-app-1.html">Mobile App 1</a>
                      </li>
                      <li>
                          <a href="demo-mobile-app-2.html">Mobile App 2</a>
                      </li>
                      <li>
                          <a href="demo-saas.html">Mobile Saas</a>
                      </li>
                      <li>
                          <a href="demo-web-app.html">Web App</a>
                      </li>
                      <li>
                          <a href="index.html#demos">More Demos</a>
                      </li>
                  </ul>*/}
          </div>
          <div className="col-md-2 col-6 footer-col">
            {/* <h6 class="heading footer-heading">Other Pages</h6>
                  <ul class="footer-nav">
                      <li>
                          <a href="page-api-docs.html">API Docs</a>
                      </li>
                      <li>
                          <a href="page-pricing.html">Pricing Page</a>
                      </li>
                      <li>
                          <a href="page-contact.html">Contact page</a>
                      </li>
                      <li>
                          <a href="page-blog-grid.html">Blog Grid</a>
                      </li>
                      <li>
                          <a href="page-coming-soon.html">Comig Soon</a>
                      </li>
                      <li>
                          <a href="page-404.html">404 Error</a>
                      </li>
                  </ul>*/}
          </div>
          <div className="col-md-4 col-sm-6 footer-col center-on-sm">
            <h6 className="heading footer-heading">Newsletter</h6>
            {/* Form */}
            <form autoComplete="on" id="sign-up-form" name="sign-up-form">
              <div className="form-group">
                <div className="input-group">
                  {/* Email Input */}
                  <input autoComplete="email" className="input form-control" data-validation="required" data-validation-error-msg="Please enter your email" name="email" placeholder="Email" />
                  <div className="input-group-append">
                    {/* Submit Button */}
                    <button className="btn ui-gradient-peach">Subscribe <span className="las la-paper-plane" /></button>
                  </div>
                </div>
              </div>
            </form>
            <div>
              <a className="btn ui-gradient-blue btn-circle shadow-md">
                <span className="la la-facebook" />
              </a>
              <a className="btn ui-gradient-peach btn-circle shadow-md">
                <span className="la la-instagram" />
              </a>
              <a className="btn ui-gradient-green btn-circle shadow-md">
                <span className="la la-twitter" />
              </a>
              <a className="btn ui-gradient-purple btn-circle shadow-md">
                <span className="la la-pinterest" />
              </a>
            </div>
          </div>
        </div>{/* .row */}
      </div>{/* .container */}
      {/* Footer Copyright */}
      <div className="footer-copyright bg-dark-gray">
        <div className="container">
          <div className="row">
            {/* Copyright */}
            <div className="col-sm-6 center-on-sm">
              <p>
                © 2017 <a href="http://codeytech.com" target="_blank" title="Codeytech">Codeytech</a>
              </p>
            </div>
            {/* Social Icons */}
            <div className="col-sm-6 text-right">
              <ul className="footer-nav">
                <li>
                  <a href="#">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#">
                    Terms &amp; Conditions
                  </a>
                </li>
                <li>
                  <a href="#">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>{/* .container */}
      </div>{/* .footer-copyright */}
    </footer>{/* .ui-footer */}
  </div>{/* .main */}
</div>
    );  
  };  
  
export default IndexPage 