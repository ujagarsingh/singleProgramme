import React from 'react';

import { AuthUserContext } from '../Session';
import { PasswordForgetForm } from '../PasswordForget';
import PasswordChangeForm from '../PasswordChange';
import { withAuthorization } from '../Session';

const AccountPage = () => (
  <AuthUserContext.Consumer>
    {authUser => (
      <div >
        <h3>Account: {authUser.email}</h3>
        <hr />
        <div className="row">
          <div className="col-md-6">
            <div className="card border-primary mb-3">
              <div className="card-header">SignUp</div>
              <div className="card-body">
                <PasswordForgetForm />
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="card border-primary mb-3">
              <div className="card-header">SignUp</div>
              <div className="card-body">
                <PasswordChangeForm />
              </div>
            </div>
          </div>
        </div>
      </div>
    )}
  </AuthUserContext.Consumer >
);

const authCondition = authUser => !!authUser;

export default withAuthorization(authCondition)(AccountPage);
