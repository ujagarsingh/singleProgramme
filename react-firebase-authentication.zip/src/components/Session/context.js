import React from 'react';

const AuthUserContext = React.createContext(null);

export default AuthUserContext;
