<?php
// http://localhost/schooloffice/api/acc_group/read_one.php?id=2
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
// include database and object files
include_once '../database.php';
include_once '../objects/acc_group.php';

// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccGroup($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
 
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      $stmt = $Item->readOne();
      $num = $stmt->rowCount();

      // check if more than 0 record found
      if ($num > 0) {
		$expenses_type = array();
        while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
            extract($row);
         
            
            $expenses_type['id'] = $row['id'];  
            $expenses_type['expenses_type'] = $row['expenses_type'];  
            $expenses_type['school_id'] = $row['school_id'];  
            $expenses_type['school_name'] = $row['school_name'];  
            $expenses_type['server_date_time'] = $row['server_date_time'];  
            
         }
         // echo json_encode($expenses_type);
		 http_response_code(200); 
		 echo json_encode(array(
			 "message" => "Access granted.",
			 "expenses_arr" => $expenses_type
		 ));
      }
		/* get data end */
		
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}


?>