<?php
/*
http://localhost/schooloffice/api/acc_group/update.php
*/
// required headers

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../database.php';
include_once '../objects/acc_group.php';

 
// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccGroup($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
      // echo"<pre>";print_r($decoded);echo"</pre>";die();
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      if($Item->user_category === '1'){
         $Item->school_id = $data->school_id;
      }
      $Item->id = $data->id;
      $Item->expenses_type = $data->expenses_type;
      
      
      // check if more than 0 record found
      if (!empty($Item->expenses_type)) {
         
         if($Item->update()){
            
            $stmt = $Item->readOne();
            $num = $stmt->rowCount();
            
            // check if more than 0 record found
            // echo"<pre>";print_r($num);echo"</pre>";die();
            
            if ($num > 0) {
               $expenses_info = array();
               while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
                  extract($row);
                  
                  $expenses_info['id'] = $row['id'];  
                  $expenses_info['school_id'] = $row['school_id'];  
                  $expenses_info['school_name'] = $row['sch_name'];  
                  $expenses_info['parent_id'] = $row['parent_id'];  
                  $expenses_info['parent_group_name'] = $row['parent_group_name'];  
                  $expenses_info['type_name'] = $row['type_name'];  
                  $expenses_info['group_type'] = $row['group_type'];  
                  $expenses_info['op_balance'] = $row['op_balance'];  
                  $expenses_info['crnt_balance'] = $row['crnt_balance'];  
                  $expenses_info['server_date_time'] = $row['server_date_time'];   
                  
               }

               http_response_code(200); 
               echo json_encode(array(
                  "message" => "Access granted.",
                  "updated_item" => $expenses_info
               ));
            }

         }
         // echo json_encode($expenses_arr);
      }
		/* get data end */
		
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}
 

?>