import { accGroupConstants } from '../_constants';
import { accGroupService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accGroupActions = {
    getAccGroup,
    createAccGroup,
    update,
    delete : _delete
};

function getAccGroup() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupService.getAccGroup()
            .then(
                response => {
                    dispatch(success(response.data.expenses_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupConstants.ACC_GROUP_REQUEST } }
    function success(response) { return { type: accGroupConstants.ACC_GROUP_SUCCESS, response } }
    function failure(error) { return { type: accGroupConstants.ACC_GROUP_FAILURE, error } }
}
 

function createAccGroup(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupService.createAccGroup(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupConstants.CREATE_ACC_GROUP_REQUEST } }
    function success(response) { return { type: accGroupConstants.CREATE_ACC_GROUP_SUCCESS, response } }
    function failure(error) { return { type: accGroupConstants.CREATE_ACC_GROUP_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupConstants.UPDATE_ACC_GROUP_REQUEST } }
    function success(response) { return { type: accGroupConstants.UPDATE_ACC_GROUP_SUCCESS, response } }
    function failure(error) { return { type: accGroupConstants.UPDATE_ACC_GROUP_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accGroupService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accGroupConstants.DELETE_ACC_GROUP_REQUEST } }
    function success(response) { return { type: accGroupConstants.DELETE_ACC_GROUP_SUCCESS, response } }
    function failure(error) { return { type: accGroupConstants.DELETE_ACC_GROUP_FAILURE, error } }
}
