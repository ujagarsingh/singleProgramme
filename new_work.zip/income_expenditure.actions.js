import { incomeExpenditureConstants } from '../_constants';
import { incomeExpenditureService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const incomeExpenditureActions = {
    getIncomeExpenditure,
    createIncomeExpenditure,
    update,
    delete : _delete
};

function getIncomeExpenditure() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        incomeExpenditureService.getIncomeExpenditure()
            .then(
                response => {
                    dispatch(success(response.data.inc_exp_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: incomeExpenditureConstants.INCOME_EXPENDITURE_REQUEST } }
    function success(response) { return { type: incomeExpenditureConstants.INCOME_EXPENDITURE_SUCCESS, response } }
    function failure(error) { return { type: incomeExpenditureConstants.INCOME_EXPENDITURE_FAILURE, error } }
}
 

function createIncomeExpenditure(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        incomeExpenditureService.createIncomeExpenditure(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_REQUEST } }
    function success(response) { return { type: incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_SUCCESS, response } }
    function failure(error) { return { type: incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        incomeExpenditureService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_REQUEST } }
    function success(response) { return { type: incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_SUCCESS, response } }
    function failure(error) { return { type: incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        incomeExpenditureService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_REQUEST } }
    function success(response) { return { type: incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_SUCCESS, response } }
    function failure(error) { return { type: incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_FAILURE, error } }
}
