<?php
class AccEntryBook{
 
    // database connection and table name
    private $conn;
    private $table_name = "acc_entry_book";
    private $table_school = "school_info";
	
    // object properties
    public $action;
    public $id;
	public $school_id;
	public $ledger_id;
    public $person_id;
    public $tr_type;
    public $amount;
    public $transaction_date;
    public $server_date_time;
    public $description;
    public $session_year_id;
    public $last_id;
    
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
// read Classes
function read(){
 
    // select all query
    $query = "SELECT I.*, S.sch_name FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        ";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
 
    return $stmt;
}

// create product
function create(){
    $balance = $this->getCurrentBalance();

    if($this->action === 'indirect_income'){
        $this->balance_amo = $balance + $this->amount;
        $this->tr_type = 'CR';
    } 
    else if($this->action === 'indirect_expenses') {
        $this->balance_amo = $balance - $this->amount;
        $this->tr_type = 'CR';
    }

    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                school_id = :school_id,
                ledger_id = :ledger_id,
                person_id = :person_id,
                amount = :amount,
                tr_type = :tr_type,
                description = :description,
                transaction_date = :transaction_date,
                session_year_id = :session_year_id";

    // prepare query
    $stmt = $this->conn->prepare($query);
    
    // sanitize
    $this->school_id = $this->school_id;
    $this->ledger_id = $this->ledger_id;
    $this->person_id = $this->person_id;
    $this->tr_type = $this->tr_type;
    $this->amount = $this->amount;
    $this->description = $this->description;
    $this->transaction_date = $this->transaction_date;
    $this->session_year_id = $this->session_year_id;

    // bind values
    $stmt->bindParam(":school_id", $this->school_id);
    $stmt->bindParam(":ledger_id", $this->ledger_id);
    $stmt->bindParam(":person_id", $this->person_id);
    $stmt->bindParam(":tr_type", $this->tr_type);
    $stmt->bindParam(":amount", $this->amount);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":transaction_date", $this->transaction_date);
    $stmt->bindParam(":session_year_id", $this->session_year_id);

    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute query
    if($stmt->execute()){
        $this->last_id = $this->conn->lastInsertId();
        return true;
    }
 
    return false;
     
}

// used when filling up the update product form
function readOne(){
 
    // query to read single record
     
    $query = "SELECT I.*, S.sch_name FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        WHERE
                I.id = ?
            LIMIT
                0,1";

	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->id);
    // execute query
    $stmt->execute();
 
    return $stmt;
  
 
}

  
// update the product
function update(){
	
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
				school_id = :school_id,
                ledger_id = :ledger_id,
                person_id = :person_id,
                amount = :amount,
                tr_type = :tr_type,
                description = :description,
                transaction_date = :transaction_date,
                session_year_id = :session_year_id
				
            WHERE
                id = :id";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
	
    // sanitize
    $this->id 				= $this->id;
	$this->school_id = $this->school_id;
    $this->ledger_id = $this->ledger_id;
    $this->person_id = $this->person_id;
    $this->tr_type = $this->tr_type;
    $this->amount = $this->amount;
    $this->description = $this->description;
    $this->transaction_date = $this->transaction_date;
    $this->session_year_id = $this->session_year_id;
    
    // bind values
	$stmt->bindParam(":id", $this->id);
	$stmt->bindParam(":school_id", $this->school_id);
    $stmt->bindParam(":ledger_id", $this->ledger_id);
    $stmt->bindParam(":person_id", $this->person_id);
    $stmt->bindParam(":tr_type", $this->tr_type);
    $stmt->bindParam(":amount", $this->amount);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":transaction_date", $this->transaction_date);
    $stmt->bindParam(":session_year_id", $this->session_year_id);
    
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute the query
    if($stmt->execute()){
        return true;  
    }
 
    return false;
}

// delete the product
function delete(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->id=htmlspecialchars(strip_tags($this->id));
 
    // bind id of record to delete
    $stmt->bindParam(':id', $this->id);
 
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute query
    if($stmt->execute()){
        return true;
    }
    return false;
}
 

// Get Balance
function getCurrentBalance(){
    // delete query
    $query = "SELECT 
    COALESCE( 
        (SELECT SUM(cr_amo) FROM " . $this->table_name . ") - 
        (SELECT SUM(amount) FROM " . $this->table_name . "), 0) 
        AS balance 
        FROM " . $this->table_name . " 
        GROUP BY balance";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    $num = $stmt->rowCount();
    $balance = null;

    // check if more than 0 record found
    if ($num > 0) {
		while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
            extract($row);
            $balance = $row['balance'];
         }
    }
        
    return $balance;
}
 

}



 