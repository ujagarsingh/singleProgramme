import { incomeExpenditureConstants } from '../_constants';

export function incomeExpenditure(state = {}, action) {
  switch (action.type) {
    case incomeExpenditureConstants.INCOME_EXPENDITURE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case incomeExpenditureConstants.INCOME_EXPENDITURE_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case incomeExpenditureConstants.INCOME_EXPENDITURE_FAILURE:
      return {
        error: action.error
      };


    case incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case incomeExpenditureConstants.CREATE_INCOME_EXPENDITURE_FAILURE:
      return {
        error: action.error
      };



    case incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case incomeExpenditureConstants.UPDATE_INCOME_EXPENDITURE_FAILURE:
      return {
        error: action.error
      };


    case incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case incomeExpenditureConstants.DELETE_INCOME_EXPENDITURE_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}