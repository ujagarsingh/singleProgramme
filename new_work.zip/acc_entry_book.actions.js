import { accEntryBookConstants } from '../_constants';
import { accEntryBook } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accEntryBookActions = {
    getAccEntryBook,
    createAccEntryBook,
    update,
    delete : _delete
};

function getAccEntryBook() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryBook.getAccEntryBook()
            .then(
                response => {
                    dispatch(success(response.data.inc_exp_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryBookConstants.ENTRY_BOOK_REQUEST } }
    function success(response) { return { type: accEntryBookConstants.ENTRY_BOOK_SUCCESS, response } }
    function failure(error) { return { type: accEntryBookConstants.ENTRY_BOOK_FAILURE, error } }
}
 

function createAccEntryBook(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryBook.createAccEntryBook(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accEntryBookConstants.CREATE_ENTRY_BOOK_REQUEST } }
    function success(response) { return { type: accEntryBookConstants.CREATE_ENTRY_BOOK_SUCCESS, response } }
    function failure(error) { return { type: accEntryBookConstants.CREATE_ENTRY_BOOK_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryBook.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryBookConstants.UPDATE_ENTRY_BOOK_REQUEST } }
    function success(response) { return { type: accEntryBookConstants.UPDATE_ENTRY_BOOK_SUCCESS, response } }
    function failure(error) { return { type: accEntryBookConstants.UPDATE_ENTRY_BOOK_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryBook.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryBookConstants.DELETE_ENTRY_BOOK_REQUEST } }
    function success(response) { return { type: accEntryBookConstants.DELETE_ENTRY_BOOK_SUCCESS, response } }
    function failure(error) { return { type: accEntryBookConstants.DELETE_ENTRY_BOOK_FAILURE, error } }
}
