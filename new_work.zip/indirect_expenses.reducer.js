import { indirectExpensesConstants } from '../_constants';

export function indirectExpenses(state = {}, action) {
  switch (action.type) {
    case indirectExpensesConstants.INDIRECT_EXPENSES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case indirectExpensesConstants.INDIRECT_EXPENSES_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case indirectExpensesConstants.INDIRECT_EXPENSES_FAILURE:
      return {
        error: action.error
      };


    case indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_FAILURE:
      return {
        error: action.error
      };


    case indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_FAILURE:
      return {
        error: action.error
      };


    case indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}