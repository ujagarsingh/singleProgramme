import { indirectExpensesConstants } from '../_constants';
import { indirectExpensesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const indirectExpensesActions = {
    getIndirectExpenses,
    createIndirectExpenses,
    update,
    delete : _delete
};

function getIndirectExpenses() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectExpensesService.getIndirectExpenses()
            .then(
                response => {
                    dispatch(success(response.data.expenses_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectExpensesConstants.INDIRECT_EXPENSES_REQUEST } }
    function success(response) { return { type: indirectExpensesConstants.INDIRECT_EXPENSES_SUCCESS, response } }
    function failure(error) { return { type: indirectExpensesConstants.INDIRECT_EXPENSES_FAILURE, error } }
}
 

function createIndirectExpenses(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectExpensesService.createIndirectExpenses(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_REQUEST } }
    function success(response) { return { type: indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_SUCCESS, response } }
    function failure(error) { return { type: indirectExpensesConstants.CREATE_INDIRECT_EXPENSES_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectExpensesService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_REQUEST } }
    function success(response) { return { type: indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_SUCCESS, response } }
    function failure(error) { return { type: indirectExpensesConstants.UPDATE_INDIRECT_EXPENSES_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectExpensesService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_REQUEST } }
    function success(response) { return { type: indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_SUCCESS, response } }
    function failure(error) { return { type: indirectExpensesConstants.DELETE_INDIRECT_EXPENSES_FAILURE, error } }
}
