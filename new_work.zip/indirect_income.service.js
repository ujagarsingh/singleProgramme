// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const indirectIncomeService = {
    getIndirectIncome,
    createIndirectIncome,
    update,
    delete : _delete 
};

function getIndirectIncome() {
    loadProgressBar();
    const url = USER_URL + 'indirect_income/read.php';
    return Axios.post(url, authHeader()).then()
}

function createIndirectIncome(obj) {
    loadProgressBar();
    const url = USER_URL + 'indirect_income/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'indirect_income/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'indirect_income/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

