import { accLedgerConstants } from '../_constants';
import { accLedgerService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accLedgerActions = {
    getAccLedger,
    createAccLedger,
    update,
    delete : _delete
};

function getAccLedger() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerService.getAccLedger()
            .then(
                response => {
                    dispatch(success(response.data.income_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accLedgerConstants.ACC_LEDGER_REQUEST } }
    function success(response) { return { type: accLedgerConstants.ACC_LEDGER_SUCCESS, response } }
    function failure(error) { return { type: accLedgerConstants.ACC_LEDGER_FAILURE, error } }
}
 

function createAccLedger(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerService.createAccLedger(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accLedgerConstants.CREATE_ACC_LEDGER_REQUEST } }
    function success(response) { return { type: accLedgerConstants.CREATE_ACC_LEDGER_SUCCESS, response } }
    function failure(error) { return { type: accLedgerConstants.CREATE_ACC_LEDGER_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accLedgerConstants.UPDATE_ACC_LEDGER_REQUEST } }
    function success(response) { return { type: accLedgerConstants.UPDATE_ACC_LEDGER_SUCCESS, response } }
    function failure(error) { return { type: accLedgerConstants.UPDATE_ACC_LEDGER_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accLedgerService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accLedgerConstants.DELETE_ACC_LEDGER_REQUEST } }
    function success(response) { return { type: accLedgerConstants.DELETE_ACC_LEDGER_SUCCESS, response } }
    function failure(error) { return { type: accLedgerConstants.DELETE_ACC_LEDGER_FAILURE, error } }
}
