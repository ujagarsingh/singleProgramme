// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const incomeExpenditureService = {
    getIncomeExpenditure,
    createIncomeExpenditure,
    update,
    delete : _delete 
};

function getIncomeExpenditure() {
    loadProgressBar();
    const url = USER_URL + 'income_expenditure/read.php';
    return Axios.post(url, authHeader()).then()
}

function createIncomeExpenditure(obj) {
    loadProgressBar();
    const url = USER_URL + 'income_expenditure/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'income_expenditure/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'income_expenditure/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

