<?php
/*
http://localhost/schooloffice/api/acc_entry_book/create.php
*/
// required headers

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../database.php';
include_once '../objects/acc_entry_book.php';

 
// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccEntryBook($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
      // echo"<pre>";print_r($data);echo"</pre>";die();   
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      if($Item->user_category === '1'){
         $Item->school_id = $data->school_id;
      }
      
      $Item->action = isset($data->action) ? $data->action : "";
      $Item->party_id = isset($data->party_id) ? $data->party_id : "";
      $Item->party_name = isset($data->party_name) ? $data->party_name : "";
      $Item->income_id = isset($data->income_id) ? $data->income_id : "";
      $Item->cr_amo = isset($data->cr_amo) ? $data->cr_amo : "";
      $Item->expenses_id = isset($data->expenses_id) ? $data->expenses_id : "";
      $Item->dr_amo = isset($data->dr_amo) ? $data->dr_amo : "";
      $Item->balance_amo = isset($data->balance_amo) ? $data->balance_amo : "";
      $Item->transaction_date = isset($data->transaction_date) ? $data->transaction_date : "";
      $Item->description = isset($data->description) ? $data->description : "";
      
      // check if more than 0 record found
      if (!empty($Item->action)) {

         if($Item->create()){

            $Item->id = $Item->last_id;  
            
            $stmt = $Item->readOne();
            $num = $stmt->rowCount();
            
            // check if more than 0 record found
            // echo"<pre>";print_r($num);echo"</pre>";die();
            
            if ($num > 0) {
               $inc_exp_type = array();
               while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
                  extract($row);

                  $inc_exp_type['id'] = $row['id'];
                  $inc_exp_type['school_id'] = $row['school_id'];
                  $inc_exp_type['party_id'] = $row['party_id'];
                  $inc_exp_type['party_name'] = $row['party_name'];
                  $inc_exp_type['tr_type'] = $row['tr_type'];
                  $inc_exp_type['income_id'] = $row['income_id'];
                  $inc_exp_type['cr_amo'] = $row['cr_amo'];
                  $inc_exp_type['expenses_id'] = $row['expenses_id'];
                  $inc_exp_type['dr_amo'] = $row['dr_amo'];
                  $inc_exp_type['balance_amo'] = $row['balance_amo'];
                  $inc_exp_type['transaction_date'] = $row['transaction_date'];
                  $inc_exp_type['description'] = $row['description'];
                  $inc_exp_type['session_year_id'] = $row['session_year_id'];
               
               }

               http_response_code(200); 
               echo json_encode(array(
                  "message" => "Access granted.",
                  "new_item" => $inc_exp_type
               ));
            }

         }
         // echo json_encode($income_arr);
      }
		/* get data end */
		
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}
 

?>