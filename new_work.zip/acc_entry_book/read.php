<?php
// http://localhost/schooloffice/api/acc_entry_book/read.php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// include database and object files
include_once '../database.php';
include_once '../objects/acc_entry_book.php';
 
// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccEntryBook($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
 
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      $stmt = $Item->read();
      $num = $stmt->rowCount();
	  $inc_exp_arr = array();

      // check if more than 0 record found
      if ($num > 0) {
         while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
            extract($row);
         
			$inc_exp_type = array();
			
			$inc_exp_type['id'] = $row['id'];
			$inc_exp_type['school_id'] = $row['school_id'];
			$inc_exp_type['party_id'] = $row['party_id'];
			$inc_exp_type['party_name'] = $row['party_name'];
			$inc_exp_type['tr_type'] = $row['tr_type'];
			$inc_exp_type['income_id'] = $row['income_id'];
			$inc_exp_type['cr_amo'] = $row['cr_amo'];
			$inc_exp_type['expenses_id'] = $row['expenses_id'];
			$inc_exp_type['dr_amo'] = $row['dr_amo'];
			$inc_exp_type['balance_amo'] = $row['balance_amo'];
			$inc_exp_type['transaction_date'] = $row['transaction_date'];
			$inc_exp_type['server_date_time'] = $row['server_date_time'];
			$inc_exp_type['description'] = $row['description'];
			$inc_exp_type['session_year_id'] = $row['session_year_id'];
            
            $inc_exp_arr[] = $inc_exp_type;
         
         }
         // echo json_encode($inc_exp_arr); 
      }
		/* get data end */
		
		http_response_code(200); 
		echo json_encode(array(
			"message" => "Access granted.",
			"inc_exp_arr" => $inc_exp_arr
		));
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}

?>