SELECT * FROM `acc_entry_book`

`id`,
`school_id`,
`ledger_id`,
`person_id`,
`amount`,
`tr_type`,
`description`,
`session_year_id`,
`transaction_date`,
`server_date_time`


SELECT * FROM `acc_group`

`id`,
`parent_id`,
`school_id`,
`type_name`,
`group_type`,
`op_balance`,
`crnt_balance`,
`server_date_time`


SELECT * FROM `acc_ledger`

`id`,
`school_id`,
`acc_group_id`,
`type_name`,
`ledger_type`,
`op_balance`,
`crnt_balance`,
`server_date_time`