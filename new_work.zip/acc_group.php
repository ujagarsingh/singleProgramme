<?php
class AccGroup{
 
    // database connection and table name
    private $conn;
    private $table_name = "acc_group";
    private $table_school = "school_info";
	
    // object properties
	public $id; 
	public $school_id;
	public $parent_id;
	public $type_name;
	public $group_type;
	public $op_balance;
	public $crnt_balance;
	public $expenses_type;
	public $server_date_time;
    public $last_id;
	
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
// read Classes
function read(){
 
    // select all query
    $query = "SELECT I.*, S.sch_name, II.id FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        LEFT JOIN " . $this->table_school . " AS II
        ON I.parent_id = II.id";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
 
    return $stmt;
}

// create product
function create(){
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                expenses_type = :expenses_type,
                school_id = :school_id,
                parent_id = :parent_id,
                type_name = :type_name,
                group_type = :group_type,
                op_balance = :op_balance,
                crnt_balance = :crnt_balance
                ";
                
	// prepare query
	$stmt = $this->conn->prepare($query);
 
    // sanitize
	$this->expenses_type = $this->expenses_type;
	$this->school_id = $this->school_id;
	$this->parent_id = $this->parent_id;
	$this->type_name = $this->type_name;
	$this->group_type = $this->group_type;
	$this->op_balance = $this->op_balance;
	$this->crnt_balance = $this->crnt_balance;
 
	// bind values
	$stmt->bindParam(":expenses_type", $this->expenses_type);
    $stmt->bindParam(":school_id", $this->school_id);
	$stmt->bindParam(":parent_id", $this->parent_id);
    $stmt->bindParam(":type_name", $this->type_name);
	$stmt->bindParam(":group_type", $this->group_type);
    $stmt->bindParam(":op_balance", $this->op_balance);	
    $stmt->bindParam(":crnt_balance", $this->crnt_balance);	
    
    // execute query
    if($stmt->execute()){
        $this->last_id = $this->conn->lastInsertId();
        return true;
    }
 
    return false;
     
}

// used when filling up the update product form
function readOne(){
 
    // query to read single record
     
    $query = "SELECT I.*, S.sch_name, II.id FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        LEFT JOIN " . $this->table_school . " AS II
        ON I.parent_id = II.id
        WHERE
                I.id = ?
            LIMIT
                0,1";

	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->id);
    // execute query
    $stmt->execute();
 
    return $stmt;
  
 
}

  
// update the product
function update(){
	
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
				expenses_type = :expenses_type,
                school_id = :school_id,
                parent_id = :parent_id,
                type_name = :type_name,
                group_type = :group_type,
                op_balance = :op_balance,
                crnt_balance = :crnt_balance
				
            WHERE
                id = :id";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
	
    // sanitize
    $this->id = $this->id;
	$this->expenses_type = $this->expenses_type;
	$this->school_id = $this->school_id;
	$this->parent_id = $this->parent_id;
	$this->type_name = $this->type_name;
	$this->group_type = $this->group_type;
	$this->op_balance = $this->op_balance;
	$this->crnt_balance = $this->crnt_balance;
 
    // bind values
	$stmt->bindParam(":id", $this->id);
	$stmt->bindParam(":expenses_type", $this->expenses_type);
    $stmt->bindParam(":school_id", $this->school_id);
	$stmt->bindParam(":parent_id", $this->parent_id);
    $stmt->bindParam(":type_name", $this->type_name);
	$stmt->bindParam(":group_type", $this->group_type);
    $stmt->bindParam(":op_balance", $this->op_balance);	
    $stmt->bindParam(":crnt_balance", $this->crnt_balance);	
    
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute the query
    if($stmt->execute()){
        return true;  
    }
 
    return false;
}

// delete the product
function delete(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->id=htmlspecialchars(strip_tags($this->id));
 
    // bind id of record to delete
    $stmt->bindParam(':id', $this->id);
 
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
 

}



 