import { indirectIncomeConstants } from '../_constants';
import { indirectIncomeService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const indirectIncomeActions = {
    getIndirectIncome,
    createIndirectIncome,
    update,
    delete : _delete
};

function getIndirectIncome() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectIncomeService.getIndirectIncome()
            .then(
                response => {
                    dispatch(success(response.data.income_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectIncomeConstants.INDIRECT_INCOME_REQUEST } }
    function success(response) { return { type: indirectIncomeConstants.INDIRECT_INCOME_SUCCESS, response } }
    function failure(error) { return { type: indirectIncomeConstants.INDIRECT_INCOME_FAILURE, error } }
}
 

function createIndirectIncome(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectIncomeService.createIndirectIncome(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: indirectIncomeConstants.CREATE_INDIRECT_INCOME_REQUEST } }
    function success(response) { return { type: indirectIncomeConstants.CREATE_INDIRECT_INCOME_SUCCESS, response } }
    function failure(error) { return { type: indirectIncomeConstants.CREATE_INDIRECT_INCOME_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectIncomeService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectIncomeConstants.UPDATE_INDIRECT_INCOME_REQUEST } }
    function success(response) { return { type: indirectIncomeConstants.UPDATE_INDIRECT_INCOME_SUCCESS, response } }
    function failure(error) { return { type: indirectIncomeConstants.UPDATE_INDIRECT_INCOME_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        indirectIncomeService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: indirectIncomeConstants.DELETE_INDIRECT_INCOME_REQUEST } }
    function success(response) { return { type: indirectIncomeConstants.DELETE_INDIRECT_INCOME_SUCCESS, response } }
    function failure(error) { return { type: indirectIncomeConstants.DELETE_INDIRECT_INCOME_FAILURE, error } }
}
