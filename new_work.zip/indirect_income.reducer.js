import { indirectIncomeConstants } from '../_constants';

export function indirectIncome(state = {}, action) {
  switch (action.type) {
    case indirectIncomeConstants.INDIRECT_INCOME_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case indirectIncomeConstants.INDIRECT_INCOME_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case indirectIncomeConstants.INDIRECT_INCOME_FAILURE:
      return {
        error: action.error
      };


    case indirectIncomeConstants.CREATE_INDIRECT_INCOME_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectIncomeConstants.CREATE_INDIRECT_INCOME_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case indirectIncomeConstants.CREATE_INDIRECT_INCOME_FAILURE:
      return {
        error: action.error
      };



    case indirectIncomeConstants.UPDATE_INDIRECT_INCOME_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectIncomeConstants.UPDATE_INDIRECT_INCOME_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case indirectIncomeConstants.UPDATE_INDIRECT_INCOME_FAILURE:
      return {
        error: action.error
      };


    case indirectIncomeConstants.DELETE_INDIRECT_INCOME_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case indirectIncomeConstants.DELETE_INDIRECT_INCOME_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case indirectIncomeConstants.DELETE_INDIRECT_INCOME_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}