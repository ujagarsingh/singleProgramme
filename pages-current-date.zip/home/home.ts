import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public minDate = "2019-05-07T05:20:09.926Z";
  public _targetDate = "2019-05-07T11:53:09.926Z";
  public targetDate = new Date().toISOString();
  
  constructor(public navCtrl: NavController) {
	console.log(this.myDate = this._targetDate);
 
  }
	
}
