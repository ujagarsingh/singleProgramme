[
  {
    "title": "Update School Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      
    ]
  },
  {
    "title": "Upload Staff Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Update Student's Image",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Upload Student Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Update Student's RTE",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Free Seat",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Image",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Roll Number",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Class according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Subject according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Subject ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Subject ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Subject ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Subject Max-Marks according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Student Marks Obtain according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Mark-sheets according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Mark-sheets",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Mark-sheets",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Mark-sheets",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Fee Structure according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Class",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Conveyance Route.",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Conveyance Fee according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Events/Holiday according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      {
        "breadcrumb": "",
        "description": ""
      }
    ],
    "child": [
      {
        "title": "Create  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          {
            "breadcrumb": "",
            "description": ""
          }
        ],
        "child": [
          
        ]
      }
    ]
  }
]