var faqs = [
  {
    "title": "Update School Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Main Website > School > Update Info", "Setting > Main Website > School > Update Info", "Setting > Main Website > School > Update Info", 
        
    ],
    "child": [
      
    ]
  },
  {
    "title": "Upload Staff Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Upload Excel",
        
    ],
    "child": [
      {
        "title": "Update Staff's Image",
        "tag": [
          'page-name'
        ],
        "body": [
          "Professional > Edit ",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Upload Student Info according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Upload Excel ",
        
    ],
    "child": [
      {
        "title": "Update Student's RTE",
        "tag": [
          'page-name'
        ],
        "body": [
          "Students > Software Data > Select Student > Edit ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Free Seat",
        "tag": [
          'page-name'
        ],
        "body": [
          "Students > Software Data > Select Student > Edit ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Image",
        "tag": [
          'page-name'
        ],
        "body": [
          "Students > Software Data > Select Student > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student's Roll Number",
        "tag": [
          'page-name'
        ],
        "body": [
          "Students > Software Data > Generate Roll Nummber",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Class according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Class ",
        
    ],
    "child": [
      {
        "title": "Create Class",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Class > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Class",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Class > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Class",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Class > Delete",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Subject according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Subject ",
        
    ],
    "child": [
      {
        "title": "Create Subject",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Subject > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Subject",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Subject > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Subject",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Subject > Delete",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": " Manage Subject Max-Marks according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Exam > Max Marks",
        
    ],
    "child": [
      {
        "title": "Create Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > Max Marks > Add New ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > All Exam > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Subject Max-Marks",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > All Exam > Delete",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Student Marks Obtain according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Exam > All Exam > ",
        
    ],
    "child": [
      {
        "title": "Create Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > All Exam > ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > All Exam > ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Student Marks Obtain",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Exam > All Exam > ",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Report Card(Mark-Sheet) according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Report Card ",
        
    ],
    "child": [
      {
        "title": "Add Obtain Marks of individual student ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Report Card > Marks Class Wise > Add/Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Add Obtain Marks Indivisual Subject of a Class",
        "tag": [
          'page-name'
        ],
        "body": [
          "Report Card > Add Marks Subject wise > ",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Obtain Marks of Indivisual Class Using Excel",
        "tag": [
          'page-name'
        ],
        "body": [
          "Report Card > Excel to Update",
          "Select Desired Exam of a Class"
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Fee Category according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Fee > Category",
        
    ],
    "child": [
      {
        "title": "Create Category",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Category > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Category",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Category > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Category",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Category > Del",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Fee Structure (Amount) according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Fee > Structure",
        
    ],
    "child": [
      {
        "title": "Create Structure",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Structure > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Structure",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Structure > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Structure",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Fee > Structure > Del",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Conveyance Route and Fee according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Payment > Transpoart ",
        
    ],
    "child": [
      {
        "title": "Create Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Payment > Transpoart > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Payment > Transpoart > Edit",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete Conveyance Fee ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Payment > Transpoart > Delete",
            
        ],
        "child": [
          
        ]
      }
    ]
  },
  {
    "title": "Manage Events/Holiday according to Session",
    "tag": [
      'page-name'
    ],
    "body": [
      "Setting > Events/Holiday",
        
    ],
    "child": [
      {
        "title": "Create  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Events / Holiday > Add New",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Update  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Events / Holiday > Update",
            
        ],
        "child": [
          
        ]
      },
      {
        "title": "Delete  Events/Holiday ",
        "tag": [
          'page-name'
        ],
        "body": [
          "Setting > Events / Holiday > Delete",
            
        ],
        "child": [
          
        ]
      }
    ]
  }
];