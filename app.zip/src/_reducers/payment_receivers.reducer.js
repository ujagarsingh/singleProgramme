import { paymentReceiverConstants } from '../_constants';

export function paymentReceiver(state = {}, action) {
  switch (action.type) {
    case paymentReceiverConstants.PAYMENT_RECEIVER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case paymentReceiverConstants.PAYMENT_RECEIVER_SUCCESS:
      return {
        item: action.response
      };
    case paymentReceiverConstants.PAYMENT_RECEIVER_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}