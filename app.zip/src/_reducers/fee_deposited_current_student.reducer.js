import { feeDepositedCurrentStudentConstants } from '../_constants';

export function feeDepositedCurrentStudent(state = {}, action) {
  switch (action.type) {
    
    case feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case feeDepositedCurrentStudentConstants.FEE_DEPOSITED_CURRENT_STUDENT_FAILURE:
      return {
        ...state,
        error: action.error
      };


    default:
      return state
  }
}