import { maxMarksConstants } from '../_constants';

export function maxMarks(state = {}, action) {
  switch (action.type) {
    case maxMarksConstants.MAX_MARKS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case maxMarksConstants.MAX_MARKS_SUCCESS:
      return {
        item: action.response
      };
    case maxMarksConstants.MAX_MARKS_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}