import { accGroupEntryConstants } from '../_constants';

export function accGroupEntry(state = {}, action) {
  switch (action.type) {
    case accGroupEntryConstants.ACC_GROUP_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accGroupEntryConstants.ACC_GROUP_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accGroupEntryConstants.ACC_GROUP_FAILURE:
      return {
        error: action.error
      };
   
    case accGroupEntryConstants.ACC_GROUP_BYFOLIO_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accGroupEntryConstants.ACC_GROUP_BYFOLIO_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accGroupEntryConstants.ACC_GROUP_BYFOLIO_FAILURE:
      return {
        error: action.error
      };
   

    default:
      return state
  }
}