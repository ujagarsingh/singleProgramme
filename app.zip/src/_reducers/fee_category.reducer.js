import { feeCategoryConstants } from '../_constants';

export function feeCategory(state = {}, action) {
  switch (action.type) {
    case feeCategoryConstants.FEE_CATEGORY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case feeCategoryConstants.FEE_CATEGORY_SUCCESS:
      return {
        item: action.response
      };
    case feeCategoryConstants.FEE_CATEGORY_FAILURE:
      return {
        error: action.error
      };



    case feeCategoryConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeCategoryConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case feeCategoryConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case feeCategoryConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeCategoryConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case feeCategoryConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    case feeCategoryConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case feeCategoryConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case feeCategoryConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    default:
      return state
  }
}