import React, { Component } from 'react';

class FrontInnerSlider extends Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="intro-text ">
              <h1>Inner Page</h1>
              <p><span><a href>Home <i className="fa fa-angle-right" /></a></span> <span><a href> Event <i className="fa fa-angle-right" /></a></span> <span className="b-active">Event Details</span></p>
            </div>
          </div>
        </div>{/* /.row */}
      </div>
    )
  }
}
export default FrontInnerSlider;