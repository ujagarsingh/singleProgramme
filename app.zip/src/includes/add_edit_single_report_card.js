import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';

class AddEditSingleReportCard extends Component {
   state = {
      student: '',
      exam_category_arr: '',
      effective_exam: '',
      nonEffective_exam: '',
      isEffective: true,
      isNonEffective: true,
      formIsHalfFilledOut: false,
   }

   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      });
      if (fieldName === 'marks_obtain') {
         const sub_id = event.target.attributes['data-sub-id'].value;
         const exam_type_id = event.target.attributes['data-cat-id'].value;
         const exam_id = event.target.attributes['data-exm-id'].value;
         const tga_value = (event.target.value !== "") ? parseInt(event.target.value) : '';

         const allSub = this.state.student.exam_type;

         const _allSub = allSub.map((eCategory) => {
            if (eCategory.id === exam_type_id) {
               const _eCategory = eCategory.subjects.map((item) => {
                  if (sub_id === item.id) {
                     const _item = item.exams_cat.map((item_e, idx) => {
                        if (exam_id === item_e.id && tga_value <= parseInt(item_e.max_marks)) {
                           item_e['marks_obtain'] = Math.abs(tga_value);
                           return item_e;
                        } else {
                           return item_e;
                        }
                     })
                     const new_item = { ...item, exams_cat: _item }
                     return new_item;
                  } else {
                     return item;
                  }
               })
               const new_eCategory = { ...eCategory, subjects: _eCategory }
               return new_eCategory;
            } else {
               return eCategory;
            }
         })

         // console.log(allSub[0]);
         // console.log(_allSub[0]);

         const stu_result = this.calculateMarksForReportCardHandler(this.state.student.exam_type);
         this.setState({
            student: { ...this.props.item, stu_result },
            formIsHalfFilledOut: true,
         })


      }
   };

   calculateMarksForReportCardHandler(all_exams) {
      const allSub = all_exams;// this.state.student.exam_type;
      ////console.log(JSON.stringify(allSub));
      let _total_max_marks = 0;
      let _total_obt_marks = 0;
      const _allSub = allSub.map((item, index) => {
         let max_marks = 0;
         let mks_obtain = 0;
         const _exam = item.exams.map((item_e, idx) => {
            max_marks += (item_e.max_marks !== '') ? parseInt(item_e.max_marks) : 0;
            mks_obtain += (item_e.marks_obtain !== '') ? parseInt(item_e.marks_obtain) : 0;
         })

         _total_max_marks += max_marks;
         _total_obt_marks += mks_obtain;

         item['t_mm'] = max_marks;
         item['t_mo'] = mks_obtain;
         return item;
      })
      ////console.log(_allSub);
      this.getReport(_total_max_marks, _total_obt_marks)
   }
   // getReport(max_marks, otn_marsk) {
   //    let grade = "";
   //    let result = "";

   //    let totalMarks = otn_marsk;
   //    let averageMarks = (otn_marsk / max_marks) * 100;
   //    switch (
   //    (averageMarks > 60 && averageMarks <= 100) ? 1 :
   //       (averageMarks > 50 && averageMarks < 60) ? 2 :
   //          (averageMarks > 40 && averageMarks < 50) ? 3 : 0
   //    ) {
   //       case 1: grade = "A"; result = "First Class"; break;
   //       case 2: grade = "B"; result = "Second Class"; break;
   //       case 3: grade = "C"; result = "Third Class"; break;
   //       case 0: grade = "D"; result = "Fail"; break;
   //    }

   //    this.setState({
   //       total_max_marks: max_marks,
   //       total_obt_marks: totalMarks,
   //       total_avg_marks: averageMarks,
   //       student_result: result,
   //       student_grade: grade
   //    })


   //    /*
   //    document.getElementById('txtStudentName').value = document.getElementById('txtName').value;
   //            document.getElementById('txtStudentClass').value = document.getElementById('txtClass').value;
   //            document.getElementById('txtTotalMarks').value = totalMarks;
   //            document.getElementById('txtAvgMarks').value = averageMarks;
   //            document.getElementById('txtGrade').value = grade;
   //            document.getElementById('txtResult').value = result;*/
   // }

   componentDidMount() {
      const { sch_name, selected_sheet_type, sch_address, stu_class, selected_exam } = this.props;
      const stu_result = this.calculateMarksForReportCardHandler(this.props.item.exam_type);
      const exam_category_arr = this.props.exam_category_arr;

      // console.log(exam_category_arr);
      this.setState({
         student: { ...this.props.item, stu_result },
         exam_category_arr: exam_category_arr,
         sch_name: sch_name,
         selected_sheet_type: selected_sheet_type,
         sch_address: sch_address,
         stu_class: stu_class,
         selected_exam: selected_exam

      }, () => { this.setExamsData() })
   };
   setExamsData() {
      const _data = this.state.student;
      let effective_exam = '';
      let nonEffective_exam = '';

      _data.exam_type.forEach(element => {
         if (element.id == 1) {
            effective_exam = element
         } else if (element.id == 2) {
            nonEffective_exam = element
         }
      });

      this.setState({
         effective_exam, nonEffective_exam
      })
   }
   calculateMarksForReportCardHandler(getData) {
      // console.log(getData);
      ////console.log(JSON.stringify(subject));
      let _total_max_marks = 0;
      let _total_obt_marks = 0;
      getData.map((examType) => {

         examType.subjects.map((item) => {
            let max_marks = 0;
            let mks_obtain = 0;
            item.exams_cat.map((item_e, idx) => {
               max_marks += (item_e.max_marks !== '') ? parseInt(item_e.max_marks) : 0;
               mks_obtain += (item_e.marks_obtain !== '') ? parseInt(item_e.marks_obtain) : 0;
            })

            _total_max_marks += max_marks;
            _total_obt_marks += mks_obtain;

            item['t_mm'] = max_marks;
            item['t_mo'] = mks_obtain;
            return item;
         })
         ////console.log(subject);

      })
      const _get_rteurn = this.getReport(_total_max_marks, _total_obt_marks);
      return _get_rteurn;
   }

   getReport(max_marks, otn_marsk) {

      let grade = "";
      let result = "";

      let totalMarks = otn_marsk;
      let averageMarks = (otn_marsk / max_marks) * 100;
      switch (
      (averageMarks >= 86 && averageMarks <= 100) ? 1 :
         (averageMarks >= 71 && averageMarks <= 85) ? 2 :
            (averageMarks >= 51 && averageMarks <= 70) ? 3 :
               (averageMarks >= 31 && averageMarks <= 50) ? 4 : 5
      ) {
         case 1: grade = "A"; /* result = "First Class"; */ break;
         case 2: grade = "B"; /* result = "Second Class"; */ break;
         case 3: grade = "C"; /* result = "Third Class"; */ break;
         case 4: grade = "D"; /* result = "Third Class"; */ break;
         case 5: grade = "E"; /* result = "Fail"; */ break;
      }

      let stu_result = {
         total_max_marks: max_marks,
         total_obt_marks: totalMarks,
         total_avg_marks: averageMarks,
         // student_result: result,
         student_grade: grade
      }
      return stu_result;
   }

   
   render() {
      const { student, nonEffective_exam, effective_exam, sch_name, selected_sheet_type, sch_address, stu_class, selected_exam,
         formIsHalfFilledOut } = this.state;
      // console.log(this.state);
      return (

         <div className="single-marksheet row">
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            {student !== '' ?
               <div className="w-100">

                  <div className="col-md-12">
                     {/* <h3 className="text-center"><strong>{sch_name} </strong> <small> ({sch_address})</small></h3> */}
                     <table className="table p-0 mb-1">
                        <tbody>
                           <tr>
                              {/* <td className=" p-0 border-0" >
                                    <img alt="SmartPSP" src="/assets/images/logo.png" width="90" className="rounded-circle img-responsive" />
                                 </td> */}
                              <td className=" p-0  border-0">
                                 <div className="d-flex">
                                    <div>
                                       <table className="table-sm table-bordered">
                                          <tbody>
                                             <tr>
                                                <td className="p-1">NAME : </td>
                                                <td className="p-1"><strong>{student.student_name}</strong></td>
                                                <td className="p-1"> ROLL NO.</td>
                                                <td className="p-1">{student.roll_number}</td>
                                             </tr>
                                             <tr>
                                                <td className="p-1">MOTHER NAME</td>
                                                <td className="p-1"><strong>{student.mother_name} </strong></td>
                                                <td className="p-1">DOB</td>
                                                <td className="p-1"><strong>{student.dob}</strong></td>
                                             </tr>
                                             <tr>
                                                <td className="p-1">FATHER NAME</td>
                                                <td className="p-1"><strong>{student.father_name} </strong></td>
                                                <td className="p-1">CLASS</td>
                                                <td className="p-1"><strong>{student.stu_class}</strong></td>
                                             </tr>
                                          </tbody>
                                       </table>
                                       <span className="display-4 text-danger m-auto">Edit Mode</span>
                                    </div>
                                    <div className="img-thumbnail ml-auto ">
                                       {student.student_image !== '' ?
                                          < img src={`${process.env.PUBLIC_URL}` + student.student_image} width="120" className="img-responsive" alt={student.student_name} />
                                          : (student.gender === 'Boy' ?
                                             <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} width="120" className="img-responsive" />
                                             :
                                             <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} width="120" className="img-responsive" />)
                                       }

                                    </div>
                                 </div>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>


                  <div className="col-md-12">
                     <div className="table-responsive m-t-40">
                        {(effective_exam != '') ?
                           <table className="table table-hover table-bordered table-sm">
                              <thead className="thead-light">
                                 <tr>
                                    <th rowSpan={2} className="text-center"></th>
                                    <th rowSpan={2} className="text-center ms-width">SUBJECT</th>
                                    {effective_exam.subjects[0].exams_cat.map((item, izx) => {
                                       return (
                                          <th key={izx} rowSpan={2} className="text-center">
                                             <strong>{item.exam_name}</strong>
                                             <table className="table m-0">
                                                <tbody>
                                                   <tr>
                                                      <td width="50%" className="p-1">MAX</td>
                                                      <td className="p-1">OBTAIN</td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </th>
                                       )
                                    })}
                                    {(selected_exam.length > 1) ?
                                       <th colSpan={2} className="text-center">
                                          <strong>TOTAL</strong>
                                          <table className="table m-0">
                                             <tbody>
                                                <tr>
                                                   <td width="50%" className="p-1">MAX</td>
                                                   <td className="p-1">OBTAIN</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </th>
                                       : null}
                                 </tr>
                              </thead>
                              <tbody>
                                 {student.exam_type[0].subjects.map((item_c, index) => {
                                    return (
                                       <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-left ms-width">
                                             <span className={(item_c.sub_lavel === '11') ? "pl-3" : ""}>
                                                {item_c.sub_name}
                                             </span>
                                          </td>
                                          {(item_c.exams_cat.length > 0) ? item_c.exams_cat.map((item_e, index) => {
                                             return (
                                                <td key={index} className="text-right das">
                                                   {(item_e.max_marks != '0') ?
                                                      <table className="table m-0" data-exam={item_e.exam_name}>
                                                         <tbody>
                                                            {(item_c.sub_lavel !== '2') ?
                                                               (<tr>
                                                                  <td width="50%" className="p-1">{item_e.max_marks}</td>
                                                                  <td className="p-1">
                                                                     {/* {item_e.marks_obtain} */}
                                                                     <input type="number"
                                                                        name="marks_obtain"
                                                                        value={item_e.marks_obtain}
                                                                        data-sub-id={item_c.id}
                                                                        data-cat-id={student.exam_type[0].id}
                                                                        data-exm-id={item_e.id}
                                                                        onChange={event => this.changeHandler(event, 'marks_obtain')}
                                                                        className="form-control form-control-sm text-center" />
                                                                  </td>
                                                               </tr>
                                                               ) : (
                                                                  <tr className="invisible">
                                                                     <td width="50%" className="p-1">&nbsp;</td>
                                                                     <td className="p-1">&nbsp;</td>
                                                                  </tr>
                                                               )}
                                                         </tbody>
                                                      </table>
                                                      : null}
                                                </td>
                                             )
                                          }) : null}
                                          {(selected_exam.length > 1) ?
                                             <>
                                                <td className="text-right">
                                                   {(item_c.sub_lavel === 2 || item_c.t_mm === 0) ? '' : item_c.t_mm}
                                                </td>
                                                <td className="text-right">
                                                   <strong>{(item_c.sub_lavel === 2 || item_c.t_mo === 0) ? '' : item_c.t_mo}</strong>
                                                </td>
                                             </>
                                             : null}
                                       </tr>

                                    )
                                 })}
                              </tbody>
                           </table>
                           : null}
                        {(nonEffective_exam != '' && selected_sheet_type === 'Marksheet') ?
                           <table className="table table-hover table-bordered table-sm">
                              <thead className="thead-light">
                                 <tr>
                                    <th rowSpan={2} className="text-center"></th>
                                    <th rowSpan={2} className="text-center ms-width">SUBJECT</th>
                                    {nonEffective_exam.subjects[0].exams_cat.map((item, izx) => {
                                       return (
                                          <th key={izx} rowSpan={2} className="text-center">
                                             <strong>{item.exam_name}</strong>
                                             <table className="table m-0">
                                                <tbody>
                                                   <tr>
                                                      <td width="50%" className="p-1">MAX</td>
                                                      <td className="p-1">OBTAIN</td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </th>
                                       )
                                    })}
                                    {(selected_exam.length > 1) ?
                                       <th colSpan={2} className="text-center">
                                          <strong>TOTAL</strong>
                                          <table className="table m-0">
                                             <tbody>
                                                <tr>
                                                   <td width="50%" className="p-1">MAX</td>
                                                   <td className="p-1">OBTAIN</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </th>
                                       : null}
                                 </tr>
                              </thead>
                              <tbody>
                                 {student.exam_type[1].subjects.map((item_c, index) => {
                                    return (
                                       <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-left ms-width">
                                             <span className={(item_c.sub_lavel === '11') ? "pl-3" : ""}>
                                                {item_c.sub_name}
                                             </span>
                                          </td>
                                          {(item_c.exams_cat.length > 0) ? item_c.exams_cat.map((item_e, index) => {
                                             return (
                                                <td key={index} className="text-right das">
                                                   {(item_e.max_marks != '0') ?
                                                      <table className="table m-0" data-exam={item_e.exam_name}>
                                                         <tbody>
                                                            {(item_c.sub_lavel !== '2') ?
                                                               (<tr>
                                                                  <td width="50%" className="p-1">{item_e.max_marks}</td>
                                                                  <td className="p-1">
                                                                     {/* {item_e.marks_obtain} */}

                                                                     <input type="number"
                                                                        name="marks_obtain"
                                                                        value={item_e.marks_obtain}
                                                                        data-sub-id={item_c.id}
                                                                        data-exm-id={item_e.id}
                                                                        data-cat-id={student.exam_type[1].id}
                                                                        onChange={event => this.changeHandler(event, 'marks_obtain')}
                                                                        className="form-control form-control-sm text-center" />
                                                                  </td>
                                                               </tr>
                                                               ) : (
                                                                  <tr className="invisible">
                                                                     <td width="50%" className="p-1">&nbsp;</td>
                                                                     <td className="p-1">&nbsp;</td>
                                                                  </tr>
                                                               )}
                                                         </tbody>
                                                      </table>
                                                      : null}
                                                </td>
                                             )
                                          }) : null}
                                          {(selected_exam.length > 1) ?
                                             <>
                                                <td className="text-right">
                                                   {(item_c.sub_lavel === 2 || item_c.t_mm === 0) ? '' : item_c.t_mm}
                                                </td>
                                                <td className="text-right">
                                                   <strong>{(item_c.sub_lavel === 2 || item_c.t_mo === 0) ? '' : item_c.t_mo}</strong>
                                                </td>
                                             </>
                                             : null}
                                       </tr>

                                    )
                                 })}
                              </tbody>
                           </table>
                           : null}


                        <div className="d-flex align-items-end">
                           {(selected_sheet_type === 'Marksheet') ?
                              <table width="450" className="table-sm table-bordered table-info">
                                 <tbody>
                                    <tr>
                                       <td className="p-1">GRADE : </td>
                                       <td className="p-1"><strong>{student.stu_result.student_grade}</strong></td>
                                       <td className="p-1">RESULT :</td>
                                       <td className="p-1"><strong>{ /* item.stu_result.student_result */} </strong></td>
                                    </tr>
                                    <tr>
                                       <td className="p-1">DOB</td>
                                       <td colSpan="3" className="p-1"><strong>10-JULY-1995</strong></td>
                                    </tr>
                                 </tbody>
                              </table>
                              : null}
                           <div className="ml-auto p-1"><b>AUTHENTIC SIGNATORY</b></div>
                        </div>
                     </div>
                  </div>
               </div>
               : null}
         </div>

      )
   }
}
export default withRouter(AddEditSingleReportCard);