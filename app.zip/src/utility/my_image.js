import React, { PureComponent } from "react";
import ReactCrop from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";

class MyImage extends PureComponent {
   state = {
      src: null,
      /*crop: {
        unit: "%",
        width: 30,
        aspect: 1
      },*/
      crop: {},
      final_size: {},
      base64Image: "",
      isActive: false
   };

   componentDidMount() {
      //console.log(this.props);
      const crop = this.props.crop;
      const final_size = this.props.final_size;
      this.setState({ crop, final_size });
   }

   onSelectFile = e => {
      if (e.target.files && e.target.files.length > 0) {
         const reader = new FileReader();
         reader.addEventListener("load", () =>
            this.setState({ src: reader.result, isActive: true })
         );
         reader.readAsDataURL(e.target.files[0]);
      }
   };

   // If you setState the crop in here you should return false.
   onImageLoaded = image => {
      this.imageRef = image;
   };

   onCropComplete = crop => {
      this.makeClientCrop(crop);
   };

   onCropChange = (crop, percentCrop) => {
      // You could also use percentCrop:
      // this.setState({ crop: percentCrop });
      this.setState({ crop });
   };

   async makeClientCrop(crop) {
      if (this.imageRef && crop.width && crop.height) {
         const croppedImageUrl = await this.getCroppedImg(
            this.imageRef,
            crop,
            "newFile.jpeg"
         );
         this.setState({ croppedImageUrl });
      }
   }

   getCroppedImg(image, crop, fileName) {
      const canvas = document.createElement("canvas");
      const scaleX = image.naturalWidth / image.width;
      const scaleY = image.naturalHeight / image.height;
      canvas.width = crop.width;
      canvas.height = crop.height;
      /*canvas.width = 400;
      canvas.height = 400;*/
      const ctx = canvas.getContext("2d");

      ctx.drawImage(
         image,
         crop.x * scaleX,
         crop.y * scaleY,
         crop.width * scaleX,
         crop.height * scaleY,
         0,
         0,
         crop.width,
         crop.height
      );

      // As Base64 string
      const base64Image = canvas.toDataURL("image/png");

      return new Promise((resolve, reject) => {
         canvas.toBlob(blob => {
            if (!blob) {
               //reject(new Error('Canvas is empty'));
               console.error("Canvas is empty");
               return;
            }
            blob.name = fileName;
            window.URL.revokeObjectURL(this.fileUrl);
            this.fileUrl = window.URL.createObjectURL(blob);
            resolve(this.fileUrl);
            this.setState({ base64Image });
            //this.imageHandlar(base64Image);
         }, "image/png");
      });
   }

   setImageHandlar = () => {
      this.setState({
         src: null,
         croppedImageUrl: "",
         isActive: false
      });
      document.querySelector("#inputGroupFile").value = "";
      //this.props.cropComplete(this.state.base64Image);
      this.resizeImage(this.state.base64Image);
   };
   resetImageHandlar = () => {
      this.setState({
         src: null,
         croppedImageUrl: "",
         isActive: false
      });
      document.querySelector("#inputGroupFile").value = "";
      //this.props.callbackFromParent('');
   };
   /*
      imageHandlar = base64Image => {
         this.props.callbackFromParent(base64Image);
      };*/

   // convert image size according to requery display size
   resizeImage = data => {
      var canvas = document.createElement("canvas");
      var ctx = canvas.getContext("2d");

      canvas.width = this.state.final_size.width; //1680; // target width
      canvas.height = this.state.final_size.height; //815; // target height

      var image = new Image();
      //document.getElementById("original").appendChild(image);
      var _img = "";
      var self = this;
      image.onload = function (e) {
         ctx.drawImage(
            image,
            0,
            0,
            image.width,
            image.height,
            0,
            0,
            canvas.width,
            canvas.height
         );
         // create a new base64 encoding
         var resampledImage = new Image();
         resampledImage.src = canvas.toDataURL();
         _img = resampledImage.src;
         //document.getElementById("resampled").appendChild(resampledImage);
         self.managePhotoSize(_img);
      };
      image.src = this.state.base64Image;
   };


   managePhotoSize = finalimg => {
      this.props.cropComplete(finalimg);
   };

   render() {
      const { crop, croppedImageUrl, src, isActive } = this.state;
      //console.log(this.state);
      return (
         <div
            className={isActive === true ? "image-cropper active" : "image-cropper"}
         >
            <div className="imgae-croper-inner">
               <div className="croper-container">
                  <div className="croper-body">
                     <div className="row">
                        <div className="col-sm-8">
                           {src &&
                              <ReactCrop
                                 src={`${process.env.PUBLIC_URL}` + src}
                                 crop={crop}
                                 ruleOfThirds
                                 onImageLoaded={this.onImageLoaded}
                                 onComplete={this.onCropComplete}
                                 onChange={this.onCropChange}
                              />}
                        </div>
                        <div className="col-sm-4">
                           {croppedImageUrl &&
                              <img alt="SmartPSP"
                                 style={{ width: "100%" }}
                                 src={`${process.env.PUBLIC_URL}` + croppedImageUrl}
                              />}
                        </div>
                     </div>
                  </div>
                  <div className="croper-footer">
                     <div className="form-group">
                        <div className="input-group mb-1">
                           <div className="custom-file">
                              <input
                                 type="file"
                                 onChange={this.onSelectFile}
                                 className="custom-file-input"
                                 id="inputGroupFile"
                              />
                              <label className="custom-file-label" htmlFor="inputGroupFile">
                                 Choose file
              </label>
                           </div>
                           <div className="input-group-append">
                              <span
                                 onClick={this.setImageHandlar}
                                 className="btn btn-primary btn-sm"
                              >
                                 Done
              </span>
                              <span
                                 onClick={this.resetImageHandlar}
                                 className="btn btn-danger"
                              >
                                 Cancel
              </span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      );
   }
}
export default MyImage;
