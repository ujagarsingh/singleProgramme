import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, subjectsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddSubject from './add_subject';

import CommonFilters from '../utility/Filter/filter-schools';

class AllCostCenterStatus extends Component {
   state = {
      schools: [],
      school_id: '',
      selected_school_index: '',
      medium_arr: [],
      subjects: [],
      selected_subjects: [],
      sft_classes: [],
      selected_class: '',
      selected_class_inx: '',
      selected_classes: [],
      medium: '',
      createItem: false,
   }

   changeHandler = (event, fieldName, isCheckbox) => {
      
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value
      })
   };

   filterClassesOnSchool(sch_id, group_id) {
      const _classes = this.props.classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         selected_classes: _classes,
         //selected_subjects: ''
      })
   }

   classHandler() {
      const _fltr_school = this.props.filteredSchoolData;
      const _fltr_class = this.props.filteredClassesData;

      const subjects = this.props.subjects;
      let _subject = '';
      if (!isEmpty(_fltr_class.slct_cls_index)) {
         // const _class_name = selected_classes[_classIdx].class_name;
         const _class_id = _fltr_class.slct_cls_id;
         _subject = subjects.filter((item) => {
            if (item.class_id === _class_id) {
               return item
            }
         })
      } else {
         _subject = subjects.filter((item) => {
            if (item.medium === _fltr_school.slct_school_medium) {
               return item
            }
         })
      }

      if (!isEmpty(_subject)) {
         const f_subjects = _subject.map((item) => {
            let _class_name = '';
            this.props.classes.filter((item_c) => {
               if (item.class_id === item_c.id) {
                  _class_name = item_c.class_name
               }
            })
            return item = { ...item, class_name: _class_name }
         })
         this.setState({
            selected_subjects: f_subjects
         })
      } else {
         this.setState({
            selected_subjects: []
         })
      }
   }

   basicInfoHandler = (event) => {
      event.preventDefault();
      this.setState({
         basicInfo: !this.state.basicInfo
      })
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.subjects)) {
         this.props.getSubjects();
      }
      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         const _all_subjects = this.props.subjects;
         if (_all_subjects && _filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   filterBySchoolHandler = () => {
      const _filter = this.props.filteredSchoolData;
      const _all_subjects = this.props.subjects;
      if (!isEmpty(_all_subjects)) {
         const _school_subjects = _all_subjects.filter((item) => {
            if (_filter.slct_school_id) {
               if (item.school_id === _filter.slct_school_id) {
                  return item
               }
            } else {
               return item
            }
         })
         this.setState({
            selected_subjects: _school_subjects,
         }, () => this.filterByClsHandler())
      }
   }

   filterByClsHandler = () => {
      
      this.classHandler();
   }



   componentWillReceiveProps(nextProps) {
      if (nextProps.subjects) {
          
         this.filterBySchoolHandler();
      }
   }

 
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.props.deleteSubjects({ id: id });
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

 
   toggeleCreate = (event) => {
      event.preventDefault();
      this.setState({
         createItem: !this.state.createItem
      })
   }
   render() {
      const { createItem, selected_subjects } = this.state;
      const { user, schools, classes, subjects } = this.props;
      // console.log(this.state)
      return (
         <div className="page-content">
            <Helmet>
               <title>All Cost Center Status</title>
            </Helmet>
            <div className="page-bar d-flex">
               <div className="page-title">All Cost Center Status</div>
               {user && schools && classes && subjects &&
                  <div className="form-inline ml-auto filter-panel">
                     <span className="filter-closer">
                        <button type="button" className="btn btn-danger filter-toggler-c">
                           <i className="fa fa-times"></i>
                        </button>
                     </span>
                     <div className="filter-con">
                         
                        <CommonFilters
                           showSchoolFilter={true}
                           showMediumFilter={false}
                           showClassFilter={true}
                           filterBySchoolHandler={this.filterBySchoolHandler}
                           filterByClsHandler={this.filterByClsHandler}
                        />
                        
                     </div>
                  </div>
               }
            </div>
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  {createItem ? <AddSubject
                     toggeleCreate={this.toggeleCreate} />
                     : null}
                  <div className="table-scrollable">
                     <table className="table table-striped table-sm table-bordered table-hover table-sm">
                        <thead>
                           <tr>
                              <th>Id</th>
                              <th>Class Name</th>
                              {/* <th>Subject Lavel</th> */}
                              <th>Subject Name</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        {selected_subjects.length > 0 ?
                           <tbody>
                              {selected_subjects.map((item, index) => {
                                 return (
                                    <tr key={index}>
                                       <td>{index + 1}</td>
                                       <td>{item.class_name}</td>
                                       {/* <td><span className={(item.sub_lavel > 2) ? 'pl-4' : 'pl-0'}>{item.sub_lavel}</span></td> */}
                                       <td><span className={(item.sub_lavel > 2) ? 'pl-4' : 'pl-0'}>{item.sub_name}</span></td>
                                       <td>
                                          {/*<NavLink to={`/edit_subject.jsp/${item.class_id}`} className="btn btn-primary btn-sm">
                                          Edit
                                       </NavLink>
                                          */}
                                          <button className="btn btn-danger btn-sm"
                                             value={item.id}
                                             type="button"
                                             onClick={event => this.confirmBoxDelete(event, item.id)}>
                                             Delete</button>
                                       </td>
                                    </tr>
                                 )
                              })}
                           </tbody>
                           : null}
                     </table>
                  </div>
               </div>
            </div>
            <div className="card-footer">
               {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-danger btn-sm ">
                     Cancel</button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                     className="btn btn-primary btn-sm">
                     Add New</button>
               }
            </div>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: subjects } = state.subjects;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, classes, subjects,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getSubjects: subjectsAction.getSubjects,
   deleteSubjects: subjectsAction.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllCostCenterStatus));