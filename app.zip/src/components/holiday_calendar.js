import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { connect } from 'react-redux';
import { Helmet } from "react-helmet";
import { holidayAction } from '../_actions';
import { isEmpty } from '../utility/utilities';

class HolidayCalendar extends Component {
  state = {
    formIsHalfFilledOut: false
  }
  componentDidMount() {
    if(isEmpty(this.props.event_arr)){
      this.props.getHoliday()
    }
  }

  deleteHandlar = (e, id) => {
    e.preventDefault();
    alert(id);
  }
  render() {
    const { formIsHalfFilledOut } = this.state;
    const { event_arr } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>Holiday</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">All Event</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Title</th>
                    <th> Type</th>
                    <th> Description </th>
                    <th> Start Date  </th>
                    <th> End Date  </th>
                  </tr>
                </thead>
                {event_arr &&
                  <tbody>
                    {event_arr.map((value, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}.</td>
                          <td>{value.title}</td>
                          <td>{value.type}</td>
                          <td>{value.description}</td>
                          <td>{value.date_start}</td>
                          <td>{value.date_end}</td>

                        </tr>
                      )
                    })}
                  </tbody>
                }
              </table>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: event_arr } = state.holiday;
  return { event_arr };
}

const actionCreators = {
  getHoliday: holidayAction.getHoliday,
}

export default connect(mapStateToProps, actionCreators)(withRouter(HolidayCalendar));