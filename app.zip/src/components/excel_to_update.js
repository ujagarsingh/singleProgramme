import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink, Link } from 'react-router-dom';
import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { ExportCSV } from '../utility/Export_CSV/ExportCSV';
import ExcelReader from '../utility/ExcelReader';
import { connect } from 'react-redux';
import {
   schoolsAction, classesAction, classExamSubjectAction,
   marksObtainAction, classStudentExamDetailAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
// const GET_DETAILD_EXAM = `http://schools.rajpsp.com/api/exam/class_exam_subject.php`;
// const READ_STUDENT_MARKS_DETAIL_URL = `http://schools.rajpsp.com/api/exam/class_examOne_subject_student.php`;
// const CREATE_MAX_MARKS = `http://schools.rajpsp.com/api/marks_obtain/create_multiple.php`;

class ExcelToUpdate extends Component {
   state = {
      schools: [],
      school_id: '',
      selected_school_inx: '',
      medium_arr: [],
      classes: [],
      selected_classes: [],
      stu_mobt_detail: [], // student marks obtain detail
      display_stu_mobt_detail: '', // student marks obtain detail
      submitable_mobt_detail: [], // student marks obtain detail for submit
      exam_detail: [],
      selected_class_exams: [],
      selected_exam_id: '',
      selected_exam_cat_id: '',
      selected_exam_name: '',
      selected_exam_subjects: [],
      filter_keys_arr: [],
      fileName: 'export_csv_file',
      slct_class_exam_detail: '',
      selected_exam_index: '',
      selected_class_index: '',
      class_id: '',
      selected_class: '',
      selected_class_soft: '',
      medium: '',
      formIsHalfFilledOut: false,
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value });
      // if (fieldName === 'school') {
      //    const _inx = event.target.value;
      //    const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      //    const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      //    sessionStorage.setItem("school_id", _sch_id);
      //    this.setState({
      //       school_id: _sch_id,
      //       medium_arr: _medium,
      //       medium: (_medium.length === 1 ? _medium[0] : ''),
      //       selected_school_inx: _inx,
      //       selected_class_inx: '',
      //       selected_exam_index: '',
      //       stu_mobt_detail: '',
      //       display_stu_mobt_detail: '',
      //       selected_class: ''
      //    }, () => { this.filterClassesOnSchool(_sch_id, this.props.user.group_id); })
      // } else if (fieldName === 'selected_class') {
      //    // debugger
      //    const _class_inx = parseInt(event.target.value);
      //    const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
      //    const _class_id = this.state.selected_classes[_class_inx].id;
      //    sessionStorage.setItem("class_name_portal", _class_name);

      //    this.setState({
      //       class_id: _class_id,
      //       selected_class_inx: _class_inx,
      //       class_id: _class_id,
      //       stu_mobt_detail: '',
      //       display_stu_mobt_detail: '',
      //       selected_class: ''
      //    }, () => {
      //       // this.getDetaildExamHandler();
      //       this.classHandler();
      //    })
      // } else if (fieldName === 'medium') {
      //    const _medium = event.target.value;
      //    sessionStorage.setItem("medium", _medium);
      // } else 
      if (fieldName === 'selected_exam') {
         const _index = event.target.value;
         if (!isEmpty(_index)) {
            const _exam_id = this.state.selected_class_exams[_index].id;
            const _exam_name = this.state.selected_class_exams[_index].exam_name;
            const _exam_cat_id = this.state.selected_class_exams[_index].exam_cat_id;

            // Create Array of Subject of Selected Exam
            // with max marks
            const exam_subject = this.state.selected_class_exams[_index].subject;
            // debugger
            let exam_arr = [];
            let subject_name = [];
            exam_subject.filter((item) => {
               if (parseInt(item.sub_lavel) !== 2) {
                  const _obj = {};
                  _obj['sub_name'] = item.sub_name;
                  _obj['max_marks'] = item.max_marks;
                  _obj['sub_id'] = item.id;
                  _obj['exam_cat_id'] = item.exam_cat_id;
                  subject_name.push(item.sub_name + ' (' + item.max_marks + ')');
                  exam_arr.push(_obj);
               } else {
                  item.subject_sec.filter((sItem) => {
                     const _obj = {};
                     _obj['sub_name'] = item.sub_name + '_' + sItem.sub_name;
                     _obj['max_marks'] = sItem.max_marks;
                     _obj['sub_id'] = sItem.id;
                     _obj['exam_cat_id'] = sItem.exam_cat_id;
                     subject_name.push(item.sub_name + '_' + sItem.sub_name + ' (' + sItem.max_marks + ')');
                     exam_arr.push(_obj);
                  })
               }
            })
            if (exam_arr.length === 0) {
               Alert.error('Subject(s) are Not Added!!', {
                  position: 'bottom-right',
                  effect: 'jelly',
                  timeout: 5000,
               });
            }
            //create file name 
            const _crnt_sch = this.props.filteredSchoolData;
            const _crnt_cls = this.props.filteredClassesData.slct_cls;
            const today = new Date();
            const date = today.getDate() + '_' + (today.getMonth() + 1) + '_' + today.getFullYear();
            const _filenameStr = _crnt_sch.slct_school.sch_name + '_' +
               _crnt_sch.slct_medium + '_' +
               _crnt_cls.class_name + '_[' + _exam_name + ']_' + date;
            const _filteredName = (_filenameStr.replace(/[ &\/\\#,+()$~%.'":*?<>{}]/g, ""));
            const _filename = (_filteredName.toLowerCase()); // use this name
            this.setState({
               selected_exam_id: _exam_id,
               selected_exam_cat_id: _exam_cat_id,
               selected_exam_name: _exam_name,
               selected_exam_subjects: exam_arr,
               filter_keys_arr: subject_name,
               selected_exam_index: _index,
               fileName: _filename
            }, () => {
               this.getStudentofClass();
            })
         } else {
            this.setState({
               selected_exam_id: '',
               selected_exam_cat_id: '',
               selected_exam_name: '',
               selected_exam_subjects: '',
               filter_keys_arr: '',
               selected_exam_index: _index,
               fileName: ''
            })
         }

      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            // formIsHalfFilledOut: true
         });
      }
   };
   filterClassesOnSchool(sch_id, group_id) {
      const _classes = this.props.classes.filter((item) => {
         if (item.group_id === group_id && item.school_id === sch_id) {
            return item
         }
      })
      this.setState({
         selected_classes: _classes,
         selected_class_index: '',
      })
   }
   classHandler() {
      const _cls_filter = this.props.filteredClassesData;
      if (_cls_filter.slct_cls_index !== '') {
         const class_id = _cls_filter.slct_cls_id;
         const _exam_detail = this.props.classExamSubject.filter((item) => {
            if (class_id === item.id) {
               return item
            }
         })
         this.setState({
            stu_mobt_detail: '',
            selected_exam_id: '',
            selected_exam_name: '',
            selected_exam_index: '',
            display_stu_mobt_detail: '',
            selected_class_exams: _exam_detail[0].exams
         })
      } else {
         this.setState({
            stu_mobt_detail: '',
            selected_exam_id: '',
            selected_exam_name: '',
            selected_exam_index: '',
            selected_class_exams: [],
            display_stu_mobt_detail: '',
         })
      }
      // const _cls_filter = this.props.filteredClassesData;
      // if (_cls_filter.slct_cls_index !== '') {
      //    const _class_id = _cls_filter.slct_cls_id;
      //    const _class_name_portal = _cls_filter.slct_cls_name;
      //    const _class_name = _cls_filter.slct_cls_name;
      //    // this.getStudentofClass(_class_id);
      //    this.setState({
      //       class_id: _class_id,
      //       selected_class: _class_name_portal,
      //       selected_class_soft: _class_name,
      //       selected_class_index: _cls_filter.slct_cls_index,
      //       stu_mobt_detail: '',
      //       selected_exam_id: '',
      //       selected_exam_name: '',
      //       selected_exam_index: '',
      //    }, () => {
      //       this.getSelectedExam();
      //    })
      // } else {
      //    this.setState({
      //       stu_mobt_detail: '',
      //       selected_exam_id: '',
      //       selected_exam_name: '',
      //       selected_exam_index: '',
      //    })
      // }
   }
   getMaxMarks = (sub) => {
      var mData = this.state.selected_exam_subjects;
      const _sub = sub.split(' (')[0];
      const _mData = mData.filter((item) => {
         if (item.sub_name === _sub) {
            return item
         }
      })
      return _mData[0];
   }
   // after upload excel use validations
   excelDataValidate(newData) {
      //var _mData = [{"Jan":"5"}];
      //var _oldData = [{"Com_id":"2","Name":"abc","Jan":""},{"Com_id":"2","Name":"efg","Jan":""},{"Com_id":"2","Name":"hij","Jan":""},{"Com_id":"2","Name":"kal","Jan":"5"},{"Com_id":"2","Name":"mno","Jan":""}];
      //var _newData = [{"Com_id":"2","Name":"abc","Jan":"4","Feb":"4"},{"Com_id":"2","Name":"efg","Jan":"3"},{"Com_id":"2","Name":"hij","Jan":"5"},{"Com_id":"2","Name":"kal","Jan":"3"},{"Com_id":"2","Name":"mno","Jan":"4"}];

      //var _mData = this.state.selected_exam_subjects; // this is use in getMaxMarks Function
      var oldData = this.props.classStudentExamDetail.student;
      var _finalData = [];
      var _updableData = [];
      var _filter_key = this.state.filter_keys_arr;
      let _class_id = this.props.filteredClassesData.slct_cls_id;
      let _exam_id = this.state.selected_exam_id;

      const _old_lenth = oldData.length;
      const _new_lenth = newData.length;
      let isError = false;
      let message = '';

      if (_old_lenth !== _new_lenth) {
         message = 'File are Wrong !!!';
         Alert.error(message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
         });
         this.setState({
            fileName: ''
         })
         window.location.reload();
         return false;
      }

      oldData.map((oItem, oInx) => {
         const _old_keys = Object.keys(oldData[oInx]);
         // const _new_keys = Object.keys(newData[oInx]);

         const _inx = oInx + 2;
         let _currentData = {};
         let _singleData = {};

         /*if (JSON.stringify(_old_keys) !== JSON.stringify(_new_keys)) {
            alert('Field Name(s) are Wrong in Line >__ ' + _inx);
            isError = true;
            return false;
         } else {*/
         if (parseInt(oldData[oInx]['group_id']) !== parseInt(newData[oInx]['group_id'])) {
            alert('[Group Id] are changed in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (parseInt(oldData[oInx]['school_id']) !== parseInt(newData[oInx]['school_id'])) {
            alert('[School Id] are changed in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (parseInt(oldData[oInx]['admission_number']) !== parseInt(newData[oInx]['admission_number'])) {
            alert('[Admission Number] are changed in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (parseInt(oldData[oInx]['exam_id']) !== parseInt(newData[oInx]['exam_id'])) {
            alert('[Exam id] are Wrong in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (oldData[oInx]['student_name'] !== newData[oInx]['student_name']) {
            alert('[Student Name] are changed in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (oldData[oInx]['father_name'] !== newData[oInx]['father_name']) {
            alert('[Father Name] are changed in Line >__ ' + _inx);
            isError = true;
            return false;
         } else if (!isError) {
            _old_keys.map((kItem, kInx) => {

               if (_filter_key.includes(kItem)) {
                  const max_marks = this.getMaxMarks(kItem);
                  if (!isEmpty(max_marks)) {
                     const _max_marks = parseInt(max_marks.max_marks);
                     const _sub_id = max_marks.sub_id;
                     const _newData = parseInt(newData[oInx][kItem]);

                     if (_newData <= _max_marks && _newData >= 1) {
                        _currentData[kItem] = _newData;
                        _singleData = {
                           ..._singleData,
                           "sub_id": _sub_id,
                           "max_marks": _max_marks,
                           "marks_obtain": _newData
                        }
                        _updableData.push(_singleData);
                     } else if (parseInt(oldData[oInx][kItem]) > 0) {
                        _currentData[kItem] = '';
                        alert('Previous Marks are changed  [' + kItem + ']  Line  >__ ' + _inx);
                        _singleData = {
                           ..._singleData,
                           "sub_id": _sub_id,
                           "max_marks": _max_marks,
                           "marks_obtain": ''
                        }
                        _updableData.push(_singleData);
                     } else {
                        _currentData[kItem] = '';
                        if (newData[oInx][kItem] === '') {
                           alert('Marks of [' + kItem + '] is Blank, Line  >__ ' + _inx);
                        } else {
                           alert('Marks of [' + kItem + '] is Higher [' + _max_marks + '], Line  >__ ' + _inx);

                        }
                     }
                  } else {
                     isError = true;
                     // return false;
                  }

               } else {
                  _currentData[kItem] = newData[oInx][kItem];
                  if (kItem === 'admission_number') {
                     _singleData = {
                        ..._singleData,
                        "admission_number": newData[oInx][kItem],
                        "class_id": _class_id,
                        "exam_id": _exam_id
                     }
                  }
               }
            })
            _finalData.push(_currentData);
         }
         //}

      })
      if (!isError) {
         // console.log(_finalData);
         // console.log(_updableData);
         let _display_data = this.state.display_stu_mobt_detail;
         _display_data['student'] = _finalData
         message = 'If Everything Ok. then Update';
         Alert.success(message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
         });

         this.setState({
            display_stu_mobt_detail: _display_data,
            submitable_mobt_detail: _updableData,
            formIsHalfFilledOut: true
         })
      } else {
         const message = 'Some thing is wrong !!!';
         Alert.success(message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
         });
      }
   };

   getSelectedExam() {
      // debugger
      const class_id = this.props.filteredClassesData.slct_cls_id;
      const _exam_detail = this.props.classExamSubject.filter((item) => {
         if (class_id === item.id) {
            return item
         }
      })
      this.setState({
         selected_class_exams: _exam_detail[0].exams
      })
   }



   //get all students for download excel
   getStudentofClass() {
      const _fltr_school = this.props.filteredSchoolData;
      const _fltr_class = this.props.filteredClassesData;
      const obj = {
         school_id: _fltr_school.slct_school_id,
         class_id: _fltr_class.slct_cls_id,
         medium: _fltr_school.slct_medium,
         exam_id: this.state.selected_exam_id,
         exam_cat_id: this.state.selected_exam_cat_id
      };
      console.log(JSON.stringify(obj))
      this.props.getClassStudentExamDetail(obj);



      // axios.post(READ_STUDENT_MARKS_DETAIL_URL, obj)
      //    .then(res => {
      //       // debugger
      //       const resData = res.data;
      //       this.setState({
      //          stu_mobt_detail: resData,
      //          display_stu_mobt_detail: JSON.parse(JSON.stringify(resData)),
      //          selected_class: resData.class_name_portal,
      //          errorMessages: resData.message
      //       });
      //       ////console.log(JSON.stringify(this.state.stu_mobt_detail));
      //    })
      //    .catch((error) => {
      //       // error
      //    });
   }
   // getDetaildExamHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       class_id: this.state.class_id,
   //    }

   //    console.log(JSON.stringify(obj));
   //    axios.post(GET_DETAILD_EXAM, obj)
   //       .then(res => {
   //          // debugger
   //          const examDetail = res.data;
   //          this.setState({
   //             exam_detail: examDetail,
   //             errorMessages: res.data.message
   //          }, () => {
   //             this.classHandler()
   //          });
   //          // //console.log(this.state.examDetail);
   //       })
   //       .catch((error) => {
   //          // error
   //       });
   // }
   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.classExamSubject)) {
         this.props.getClassExamSubject();
      }
      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         // const _all_student = this.props.students;
         if (_filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   filterBySchoolHandler = () => {
      // const _filter = this.props.filteredSchoolData;
      // const _all_student = this.props.students;
      // if (!isEmpty(_all_student)) {
      //    const _school_student = _all_student.filter((item) => {
      //       if (_filter.slct_school_id) {
      //          if (item.school_id === _filter.slct_school_id) {
      //             return item
      //          }
      //       } else {
      //          return item
      //       }
      //    })
      //    this.setState({
      //       display_student: _school_student,
      //    }, () => this.filterByClsHandler())
      // }
      this.filterByClsHandler();
   }

   filterByClsHandler = () => {
      // const _fltr_school = this.props.filteredSchoolData;
      // const _fltr_class = this.props.filteredClassesData;
      // const _all_student = this.props.students;
      // if (_all_student) {
      //    const _school_student = _all_student.filter((item) => {
      //       if (!isEmpty(_fltr_class.slct_cls_name)) {
      //          if (item.school_id === _fltr_school.slct_school_id &&
      //             item.stu_class === _fltr_class.slct_cls_name) {
      //             return item
      //          }
      //       } else {
      //          if (item.school_id === _fltr_school.slct_school_id) {
      //             return item
      //          }
      //       }
      //    })
      //    this.setState({
      //       display_student: _school_student
      //    }, () => {
      //       this.classHandler()
      //    })
      // }
      this.classHandler()
   }
   componentWillReceiveProps(nextProps) {
      //invoke function with updated store
      //this.foo(nextProps)
      // console.log(this.props); // prevProps
      // console.log(nextProps); // currentProps after updating the store
      if (nextProps.classStudentExamDetail) {
         const resData = nextProps.classStudentExamDetail;
         this.setState({
            display_stu_mobt_detail: resData,
            selected_class: resData.class_name_portal,
         });
      }
   }
   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //                this.getClassesHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          ////console.log(this.state.classes);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // getClassesHandler() {
   //    // read all existing class
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //    }
   //    axios.post(READ_CLASS_URL, obj)
   //       .then(res => {
   //          const classes = res.data;
   //          const _classes = classes.filter((item, index) => {
   //             if (item.is_section !== 'Yes') {
   //                return item;
   //             }
   //          })
   //          this.setState({
   //             classes: _classes,
   //             errorMessages: res.data.message
   //          });
   //          ////console.log(this.state.classes);
   //       })
   //       .catch((error) => {
   //          // error
   //       });
   // };


   getKeys = () => {
      return Object.keys(this.state.display_stu_mobt_detail.student[0]);
   }

   getHeader = () => {
      //   debugger
      var keys = this.getKeys();
      keys.unshift('#');
      //keys.push('Action');
      return keys.map((key, index) => {
         return <th key={key}>{key.toUpperCase()}</th>
      })

   }

   getRowsData = () => {
      // debugger
      var items = this.state.display_stu_mobt_detail.student;
      var keys = this.getKeys();
      //debugger
      return items.map((row, index) => {
         return (
            <tr key={index}>
               <td>{index + 1}</td>
               <RenderRow key={index} data={row} keys={keys} />
            </tr>
         )
      })
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.singleUpdateHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   singleUpdateHandler() {
      let default_obj = '';
      if (this.props.user.user_category === "1") {
         default_obj = { school_id: this.props.filteredSchoolData.slct_school_id }
      }
      const form_obj = {
         myObj: this.state.submitable_mobt_detail
      }
      const obj = { ...form_obj, ...default_obj }

      // const singleObj = { myObj: this.state.submitable_mobt_detail };
      
      console.log(JSON.stringify(obj));
      // debugger;
      this.props.createMultiple(obj);

      // axios.post(CREATE_MAX_MARKS, singleObj)
      //    .then(res => {
      //       const getRes = res.data;
      //       //console.log(getRes);
      //       Alert.success(getRes.message, {
      //          position: 'bottom-right',
      //          effect: 'jelly',
      //          timeout: 5000, offset: 40
      //       });
      //    }).catch((error) => {
      //       //this.setState({ errorMessages: error });
      //    })
      // document.location.reload();
   }
   studentObjHandler = (obj) => {
      this.excelDataValidate(obj);
   }
   render() {
      const { selected_class_exams, selected_exam_index,
         display_stu_mobt_detail, fileName,
         formIsHalfFilledOut, submitable_mobt_detail } = this.state;
      const { user, schools, classes, classExamSubject } = this.props;
      // console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Excel to Update Marks</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div className="page-bar d-flex">
               <div className="page-title">Excel to Update Marks</div>
               {user && schools && classes && classExamSubject &&
                  <div className="form-inline ml-auto filter-panel">
                     <span className="filter-closer">
                        <button type="button" className="btn btn-danger filter-toggler-c">
                           <i className="fa fa-times"></i>
                        </button>
                     </span>
                     <div className="filter-con">
                        {/* <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Schools :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='school'
                              value={selected_school_inx}
                              onChange={event => this.changeHandler(event, 'school')}>
                              <option value="">Select ...</option>
                              {schools.map((item, index) => {
                                 return (
                                    <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                 )
                              })}
                           </select>
                        </div>
                        <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Medium :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='medium'
                              disabled={medium_arr.length > 1 ? false : true}
                              value={medium}
                              onChange={event => this.changeHandler(event, 'medium')}>
                              <option value="">Select ...</option>
                              {medium_arr.map((item, index) => {
                                 return (
                                    <option key={index} value={item}>{item}</option>
                                 )
                              })}
                           </select>
                        </div>
                        <div className="form-group mr-2 mt-1">
                           <label className="mr-2">Class:</label>
                           <select
                              value={selected_class_index}
                              disabled={medium === '' ? true : false}
                              className="form-control form-control-sm" name="selected_class"
                              onChange={event => this.changeHandler(event, 'selected_class')} >
                              <option value="100">Select...</option>
                              {selected_classes.map((option, index) => {
                                 return (<option key={index} value={index}>{option.class_name}</option>)
                              })}
                           </select>
                        </div> */}
                        <CommonFilters
                           showSchoolFilter={true}
                           showMediumFilter={false}
                           showClassFilter={true}
                           filterBySchoolHandler={this.filterBySchoolHandler}
                           filterByClsHandler={this.filterByClsHandler}
                        />
                        {selected_class_exams !== '' ?
                           <div className="form-group mt-1">
                              <label className="mr-2">Exam:</label>
                              <select
                                 value={selected_exam_index}
                                 // disabled={class_id === '' ? true : false}
                                 className="form-control form-control-sm"
                                 onChange={event => this.changeHandler(event, 'selected_exam')} >
                                 <option value="">Select...</option>
                                 {selected_class_exams.map((option, index) => {
                                    return (<option key={index} value={index}>{option.exam_name}</option>)
                                 })}
                              </select>
                           </div>
                           : null}
                     </div>
                  </div>
               }
            </div>
            {display_stu_mobt_detail &&
               <div className="card card-box sfpage-cover">
                  <div className="card-body sfpage-body">
                     <div className="table-scrollable">
                        <table className="table table-striped table-bordered table-hover table-sm">
                           <thead>
                              <tr>
                                 {this.getHeader()}
                              </tr>
                           </thead>
                           <tbody>
                              {this.getRowsData()}
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div className="card-footer">
                     <div className="row">
                        <div className="col">
                           <span className="d-flex">
                              <ExportCSV
                                 csvData={display_stu_mobt_detail.student}
                                 fileName={fileName} />
                              <ExcelReader studentObjHandler={this.studentObjHandler} />
                           </span>
                        </div>
                        <div className="col-auto">
                           <button className="btn btn-primary btn-sm ml-auto mr-2 "
                              type="button"
                              disabled={submitable_mobt_detail.length > 0 ? false : true}
                              onClick={(event) => this.confirmBoxSubmit(event)}>
                              Update </button>
                           <NavLink
                              to={`/all_marks.jsp`}
                              className="btn btn-danger">Marks Class wise</NavLink>
                        </div>
                     </div>
                  </div>
               </div>
            }
         </div>
      )
   }
}

const RenderRow = (props) => {
   const _newData = props.keys.map((key, index) => {
      //return <td key={props.data[key]}>{props.data[key]}</td>
      return <td key={index}>{props.data[key]}</td>
   })
   return _newData;
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: classExamSubject } = state.classExamSubject;
   const { item: classStudentExamDetail } = state.classStudentExamDetail;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, classes, classExamSubject, classStudentExamDetail,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getClassExamSubject: classExamSubjectAction.getClassExamSubject,
   getClassStudentExamDetail: classStudentExamDetailAction.getClassStudentExamDetail,
   createMultiple: marksObtainAction.createMultiple,
}

export default connect(mapStateToProps, actionCreators)(withRouter(ExcelToUpdate));