import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Picky } from 'react-picky';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, feeCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

class AddTypeNTime extends Component {
  state = {
    months_params: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    collect_time: [],
    cat_name: '',
    ledger_id : '',
    cat_type_arr: [
      { 'value': 'multiple', 'name': 'Multiple in Session' },
      { 'value': 'oneinsession', 'name': 'One Time in Session' },
      { 'value': 'oneinstudying', 'name': 'One Time in Studying' }
    ],
    cat_type: '',
    cat_diff: 'Same',
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  timeHandler = (value) => {
    this.setState({
      collect_time: value,
    });
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to add this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.state.school_id }
    }
    const form_obj = {
      school_id: this.state.school_id,
      cat_name: this.state.cat_name.replace(/ /g, "_"),
      cat_type: this.state.cat_type,
      ledger_id: this.state.ledger_id,
      collect_time: this.state.collect_time,
      cat_diff: this.state.cat_diff
    }
    const obj = { ...form_obj, ...default_obj }
    // console.log(JSON.stringify(obj));
    this.props.create(obj);
     
  };


  componentWillReceiveProps(nextProps) {
    if (nextProps.feeCategory) {
      this.setState({
        cat_name: "",
        cat_type: "",
        ledger_id: "",
        collect_time: [],
        cat_diff: "",
        formIsHalfFilledOut: false
      })
    }
  }
  render() {
    const { selected_school_index, ledger_id, cat_diff, cat_name, cat_type, collect_time, cat_type_arr, months_params, formIsHalfFilledOut } = this.state;
    const { user, accLedger, schools } = this.props;
    //console.log(this.state);
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Fee Category</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Fee Category
          </div>
          <div className="card-body">
            {user && schools && accLedger &&
              <div className="row">
                {(user.user_category === "1") &&
                  <div className="col-sm-2">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }

                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Category Name
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" placeholder="enter category name"
                        className="form-control form-control-sm"
                        required
                        value={cat_name}
                        onChange={event => this.changeHandler(event, 'cat_name')}
                      />
                      <small className="form-text text-muted">Example : Monthly, Sports, Exam, Library</small>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Same / Different
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        disabled={cat_name !== '' ? false : true}
                        value={cat_diff}
                        onChange={event => this.changeHandler(event, 'cat_diff')}>
                        <option >Select ...</option>
                        <option value="Same">Same</option>
                        <option value="Different" >Different</option>
                      </select>
                      <small><strong>Note:</strong> Like Convence Fee different for all Student.</small>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Category Type
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        disabled={cat_name !== '' ? false : true}
                        value={cat_type}
                        onChange={event => this.changeHandler(event, 'cat_type')} >
                        <option value="">Select...</option>
                        {cat_type_arr.map((option, inx) => {
                          return (
                            <option key={inx} value={option.value}>{option.name}</option>
                          )
                        })}
                      </select>
                      <small className="form-text text-muted">How mutch time you are Charge this Category</small>
                    </div>
                  </div>
                </div>
                
                {(cat_type !== 'oneinstudying') ?
                  <div className="col-sm-3">
                    <div className="form-group">
                      <label className="control-label">Month(s) of Collection
                        <span className="required"> * </span>
                      </label>
                      <div className="form-input">
                        <div className="row">
                          <div className="col-9 pr-0">
                            <Picky
                              value={collect_time}
                              options={months_params}
                              onChange={this.timeHandler}
                              open={false}
                              valueKey="id"
                              labelKey="name"
                              multiple={true}
                              includeSelectAll={true}
                              includeFilter={true}
                              dropdownHeight={200}
                            /> 
                             
                          </div>
                          <div className="col-3 pl-0">
                            <button type="button" className="btn btn-block btn-sm btn-primary"><i className="fas fa-check"></i></button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  : null}
               {accLedger &&
                  <div className="col-sm-2">
                    <div className="form-group">
                      <label className="control-label">Effected Ledger
                        <span className="required"> * </span>
                      </label>
                      <div className="form-input">
                        <select className="form-control form-control-sm"
                          required
                          value={ledger_id}
                          onChange={event => this.changeHandler(event, 'ledger_id')}>
                          <option value="">Select...</option>
                          {accLedger.map((item, index) => {
                            return (
                              (item.under_group === "2") ?
                                <option key={index} value={item.id}>{item.ledger_name}</option>
                                : null
                            )
                          })}
                        </select>
                        <small className="form-text text-danger">Category of related Ledger for showing Effect of Fee.</small>
                      </div>
                    </div>
                  </div>
                }
              </div>
            }
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-secondary btn-sm mr-2">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning btn-sm">
              Cancel
            </button>
          </div>
        </form >
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: feeCategory } = state.feeCategory;
  return { user, schools, feeCategory };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  create: feeCategoryAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddTypeNTime));
