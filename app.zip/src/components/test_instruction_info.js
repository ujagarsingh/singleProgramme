import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';

class TestInstructionInfo extends Component {
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}

	render() {
		const { step_first, step_second } = this.props;
		// console.log(this.props)
		return (
			<div className="card-paper d-flex">
				<div className="card left-test-panel border-primary">
					<div className="card-header">INSTRUCTIONS</div>
					<div className="card-body" style={{ 'height': 464 + 'px', 'overflow': 'auto' }}>
						<div className="d-flex mb-3">
							<h5 className="card-title">General Instructions</h5>
							<div className="ml-auto d-flex">
								<label className="text-nowrap mb-0 mr-2">View in:</label>
								<select className="form-control form-control-sm form-control form-control-sm-sm">
									<option>English</option>
								</select>
							</div>
						</div>
						{step_first ?
							<div>
								<ol className="test-instructions">
									<li>Total duration of the examination is 120 Min</li>
									<li>Your clock will be set at the server. The countdown timer at the top right
									corner of screen will display the remaining time available for you to complete
									the examination. When the timer reaches zero, the examination will end by itself.
                                You need not terminate the examination or submit your paper.</li>
									<li>The Question Palette displayed on the right side of screen will
                                show the status of each question using one of the following symbols:</li>
								</ol>
								<ul className="epaper-instructions setp_first">
									<li className="q-answered">
										<span className="box bg-success"></span>
                                You have answered the question.
                            </li>
									<li className="q-not-answered">
										<span className="box bg-red"></span>
                                You have visited but not answered the question yet.
                                </li>
									<li className="q-review-without-ans">
										<span className="box bg-yellow"></span>
                                You have not answered the question but have marked for review.
                                </li>
									<li className="q-review-with-ans">
										<span className="box bg-yellow"></span>
                                You have answered the question but have marked for review.
                                </li>
									<li className="q-not-visited">
										<span className="box bg-white"></span>
                                You have not visited the question yet.
                                </li>
								</ul>
							</div>
							: null
						}
						{step_second ?
							<div>
								<h5 className="card-title">Read the following instructions carefully.</h5>
								<table className="table table-bordered table-sm">
									<thead>
										<tr>
											<th>Sl No.</th>
											<th>Exam Name</th>
											<th>No. of Question</th>
											<th>Maximum Marks</th>
											<th>Negative Marks</th>
											<th>Positive Marks</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>1</td>
											<td>Class 8th First Test</td>
											<td>15</td>
											<td>10</td>
											<td>0</td>
											<td>
												<ul className="list-group">
													<li className="list-group-item d-flex justify-content-between align-items-center p-1">
														1 - 10
<span className="badge badge-primary badge-pill">0.5</span>
													</li>
													<li className="list-group-item d-flex justify-content-between align-items-center p-1">
														11 - 15
<span className="badge badge-primary badge-pill">1</span>
													</li>
												</ul>
											</td>
										</tr>
									</tbody>
								</table>
								<ol className="test-instructions">
									<li>Total duration of the examination is 120 Min</li>
									<li>Your clock will be set at the server. The countdown timer at the top right corner of screen will
									display the remaining time available for you to complete the examination. When the timer reaches zero,
                        the examination will end by itself. You need not terminate the examination or submit your paper.</li>
									<li>However, this exam will be conducted with sectional timing. You need to complete a given section in
									the mentioned time. You will not be able to proceed to the next section unless you finish the current
                        section in its allotted time frame.</li>
								</ol>
								<div className="well bg-light p-3 mb-3 border">
									<div className="d-flex mb-3">
										<h6 className="card-title">Choose your default language</h6>
										<div className="ml-2">
											<select className="form-control form-control-sm form-control form-control-sm-sm">
												<option>English</option>
											</select>
										</div>
									</div>
									<p className="text-danger">Please note all questions will appear in your default language.
                        This language can be changed for a particular question later on.</p>
									<div className="custom-control custom-checkbox">
										<input type="checkbox" className="custom-control-input" id="customCheck1" />
										<label className="custom-control-label" htmlFor="customCheck1">I have read and understood the
										instructions. All computer hardware allotted to me are in proper working condition. I declare that
										I am not in possession of /not wearing /not carrying any prohibited gadget like mobile phone,
										bluetooth devices etc. /any prohibited material with me into the Examination Hall. I agree that
										in case of not adhering to the instructions, I shall be liable to be debarred from this Test
                            and/or to a disciplinary action, which may include ban from future Tests/Examinations.</label>
									</div>
								</div>
							</div>
							: null
						}
					</div>
					<div className="card-footer d-flex p-2">
						{step_first ?
							<button
								className="btn btn-primary btn-sm ml-auto"
								onClick={event => this.nextStep(event)}>Next</button>
							: null}
						{step_second ?
							<>
								<button
									className="btn btn-danger btn-sm"
									onClick={event => this.prevStep(event)}>Back</button>
								<button
									className="btn btn-success btn-sm ml-auto"
									onClick={event => this.startTest(event)}>Start Test</button>
							</>
							: null}
					</div>
				</div>
				<div className="student-info right-test-panel">
					<img className="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" />
					<div className="user_name">Ujagar Singh Meena</div>
				</div>
			</div>
		)
	}
}
export default withRouter(TestInstructionInfo);