import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, schoolsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import NewIncome from './new_income';
import EditIncome from './edit_income';

class IncomeList extends Component {
  state = {
    accLedger: [],
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.incomeExpenditure)) {
      this.props.getIncomeExpenditure();
    }
  }

  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _s_item = this.props.incomeExpenditure.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      editItem: true,
      createItem: false,
      selected_item: { ..._s_item[0], 'transaction_date': new Date(_s_item[0].transaction_date) }
    })
  }

  closeEdit = (event) => {
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  deleteHandlar = (id) => {
    const obj = { id: id };
    this.props.deleteIncomeExpenditure(obj);
  }

  updateHandlar = (obj) => {
    // console.log(JSON.stringify(obj));
    this.props.updateIncomeExpenditure(obj);
  }
  render() {
    const { formIsHalfFilledOut, createItem, editItem, selected_item } = this.state;
    const { user, incomeExpenditure, schools } = this.props;

    return (
      <div className="page-content">
        <Helmet>
          <title>Income List</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {createItem ? <NewIncome
              toggeleCreate={this.toggeleCreate} />
              : null}
            {editItem ? <EditIncome
              selected_item={selected_item}
              schools={schools}
              user={user}
              updateHandlar={this.updateHandlar}
              openEdit={this.openEdit}
              closeEdit={this.closeEdit}
            />
              : null}
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th className="center"> </th>
                    <th className=" "> Name </th>
                    <th className="text-right"> Amount </th>
                    <th className="text-right"> Balance </th>
                    <th className="center"> Date (YYYY-MM-DD)</th>
                    <th className="center"> Discription </th>
                    <th className="center"> Action </th>
                  </tr>
                </thead>


                {incomeExpenditure &&
                  <tbody>
                    {
                      incomeExpenditure.map((item, index) => {
                        return (
                          <React.Fragment key={index}>
                            {(item.cr_amo > 0) ?
                              <tr key={index} >
                                <td className="center">{item.id}</td>
                                <td className=" ">{item.party_name}</td>
                                <td className="text-right">{item.cr_amo}</td>
                                <td className="text-right">{item.balance}</td>
                                <td className="center">{item.transaction_date}</td>
                                <td className="">{item.description}</td>
                                <td className="d-flex">
                                  <button className="btn btn-primary btn-sm mr-1"
                                    item={item.id}
                                    type="button"
                                    onClick={event => this.openEdit(event, item.id)}>Edit</button>
                                  <button className="btn btn-danger btn-sm"
                                    onClick={event => this.confirmBoxDelete(event, item.id)}>
                                    Del</button>
                                </td>
                              </tr>
                              : null}
                          </React.Fragment>
                        )
                      })
                    }
                  </tbody>
                }
              </table>
            </div>
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">Cancel
                     </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">Add New
                     </button>
            }
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: accLedger } = state.accLedger;
  const { item: incomeExpenditure } = state.incomeExpenditure;
  const { item: schools } = state.schools;
  return { user, accLedger, incomeExpenditure, schools };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getIndirectIncome: accLedgerActions.getIndirectIncome
}

export default connect(mapStateToProps, actionCreators)(withRouter(IncomeList));