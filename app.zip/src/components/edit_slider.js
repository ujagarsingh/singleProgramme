import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
//import ReactCrop from 'react-image-crop';
import MyImage from '../utility/my_image';
//import ReactFileReader from 'react-file-reader';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const UPDATE_SLIDER = `http://schools.rajpsp.com/api/front_slider/update.php`;
const READ_SLIDER = `http://schools.rajpsp.com/api/front_slider/read_one.php`;

class EditSlider extends Component {
   state = {
      id: "",
      main_image: "",
      title_1a: "",
      title_1b: "",
      sub_title: "",
      formIsHalfFilledOut: false,
      crop: {
         unit: "%",
         width: 30,
         aspect: 16 / 8
      },
      final_size: {
         width: 1680,
         height: 815
      }
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })
   };
   // child (my_image.js) component to get image
   onComplete = (data) => {
      this.setState({
         main_image: data
      })
   }

   componentDidMount() {
      const token = sessionStorage.getItem('jwt');
      const obj = { "jwt": token };
      this.checkAuthentication(obj);
   }

   checkAuthentication(obj) {
      loadProgressBar();
      axios.post(VALIDATE_URL, obj)
         .then(res => {
            const getRes = res.data;
            // sessionStorage.setItem("user", getRes.data);
            console.log(getRes);
            if (getRes.data) {
               this.setState({
                  user: getRes.data,
                  group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
                  school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
                  user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
                  session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
               }, () => {
                  this.getSliderDetailHandler();
               })
            }
         }).catch((error) => {
            this.props.history.push('/login.jsp');
         })
   }

   getSliderDetailHandler() {
      loadProgressBar();
      const { match } = this.props;
      axios.get(READ_SLIDER + `?id=` + match.params.id)
         .then(res => {
            const getRes = res.data;
            this.setState({
               id: getRes.id,
               main_image: getRes.main_image,
               title_1a: getRes.title_1a,
               title_1b: getRes.title_1b,
               sub_title: getRes.sub_title,
            });
         }).catch((error) => {
            // error
         })
   };

   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler() {
      loadProgressBar();
      //e.preventDefault();
      const obj = {
         id: this.state.id,
         main_image: this.state.main_image,
         title_1a: this.state.title_1a,
         title_1b: this.state.title_1b,
         sub_title: this.state.sub_title
      }
      console.log(JSON.stringify(obj));
      axios.post(UPDATE_SLIDER, obj)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes)
            Alert.success(getRes.message, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })
   }


   render() {
      const { crop, main_image, final_size, title_1a, title_1b, sub_title, formIsHalfFilledOut } = this.state;
      console.log(this.state)
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Slider</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

            <div className="page-bar d-flex">
               <div className="page-title">Edit Slider</div>
            </div>
            <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-body">
                  <div className="table-scrollable">
                     <div className="col-sm-12">
                        <div className="form-horizontal">
                           <div className="form-body">
                              <div className="form-group row">
                                 <label className="control-label col-md-3">First Line of Title
                        <span className="required"> * </span>
                                 </label>
                                 <div className="col-md-5">
                                    <input type="text" name="title_1a"
                                       placeholder="First Line of Title"
                                       className="form-control form-control-sm"
                                       value={title_1a}
                                       onChange={event => this.changeHandler(event, 'title_1a')} />
                                 </div>
                              </div>
                              <div className="form-group row">
                                 <label className="control-label col-md-3">Second Line of Title
                        <span className="required"> * </span>
                                 </label>
                                 <div className="col-md-5">
                                    <input type="text" name="title_1b"
                                       placeholder="Second Line of Title"
                                       className="form-control form-control-sm"
                                       value={title_1b}
                                       onChange={event => this.changeHandler(event, 'title_1b')} />
                                 </div>
                              </div>
                              <div className="form-group row">
                                 <label className="control-label col-md-3">Sub Title
                        <span className="required"> * </span>
                                 </label>
                                 <div className="col-md-5">
                                    <textarea name="sub_title" placeholder="Sub Title"
                                       className="form-control-textarea form-control" rows={5}
                                       value={sub_title}
                                       onChange={event => this.changeHandler(event, 'sub_title')} />
                                 </div>
                              </div>

                              <div className="form-group row">
                                 <label className="control-label col-md-3">Slidter Image</label>
                                 <div className="col-md-5">
                                    <MyImage
                                       //callbackFromParent={this.myCallback}
                                       cropComplete={this.onComplete}
                                       crop={crop}
                                       final_size={final_size}
                                    />
                                    {main_image !== '' ?
                                       <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + main_image} />
                                       : null}
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="card-footer  text-right">
                  <button type="submit" className="btn btn-primary mr-2">Update</button>
                  <NavLink to="/all_slider.jsp" className="btn btn-danger">Cancel</NavLink>
               </div>
            </form>
         </div >
      )
   }
}
export default withRouter(EditSlider);