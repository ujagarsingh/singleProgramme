import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
// import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

//const READ_URL = `http://schools.rajpsp.com/api/school/read.php`; 

class FrontIndexWelcome extends Component {
   state = {
      formIsHalfFilledOut: false,
   }
   componentDidMount() {

   };
   render() {
      const { wel_mes_title, wel_mes } = this.props;
      //console.log(this.props);
      return (
         <section className="welcome_section">
            <div className="container">
               <div className="section_header welcome_header d-lg-none d-md-block">
                  <h2>{wel_mes_title}</h2>
               </div>
               <div className="row">
                  <div className="col-sm-6">
                     <div className="welcome_section_text">
                        <div className="section_header welcome_header d-none d-lg-block">
                           <h2>{wel_mes_title}</h2>
                        </div>
                        {wel_mes && <p>{`${wel_mes.substring(0, 400)}...`}</p>}
                        <NavLink to="/" className="read-more-btn fa fa-long-arrow-right d-none">read more</NavLink>
                     </div>
                  </div>
                  <div className="col-sm-6">
                     <div className="welcome_img">
                        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/welcome.png`} className="img-responsive" />
                     </div>
                  </div>
               </div>
            </div>
         </section>
      )
   }
}
export default withRouter(FrontIndexWelcome);