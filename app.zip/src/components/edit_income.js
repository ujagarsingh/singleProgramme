import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { confirmAlert } from 'react-confirm-alert';
import { connect } from 'react-redux';
import { Helmet } from "react-helmet";
import { accLedgerActions } from '../_actions';
import { isEmptyObj, isEmpty, nuberInWords } from '../utility/utilities';

class EditIncome extends Component {
   state = {
      id: '',
      payment_date: '',
      party_name: '',
      amount: '',
      amount_in_word: '',
      description: '',
      formIsHalfFilledOut: false,
   }

   componentDidMount() {
      if (isEmptyObj(this.props.accLedger)) {
         this.props.getIndirectIncome();
      }

      this.setState({
         id: this.props.selected_item.id,
         party_name: this.props.selected_item.party_name,
         income_id: this.props.selected_item.income_id,
         dr_amo: this.props.selected_item.dr_amo,
         description: this.props.selected_item.description,
         transaction_date: this.props.selected_item.transaction_date
      })
   }


   paymentDateHandlar = (_date) => {
      this.setState({ transaction_date: _date });
   };

   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value })
      if (fieldName === 'cr_amo') {
         const _amount_in_word = nuberInWords(event.target.value);
         this.setState({
            amount_in_word: _amount_in_word
         })
      }
   };

   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

   submitHandler() {
      const _state = this.state;
      const obj = {
         id: _state.id,
         action: 'indirect_income',
         party_name: _state.party_name,
         income_id: _state.income_id,
         cr_amo: _state.cr_amo,
         description: _state.description,
         transaction_date: _state.transaction_date
      }
      console.log(JSON.stringify(obj));
      this.props.updateHandlar(obj);
   }

   render() {
      const { formIsHalfFilledOut, amount_in_word, party_name,
         income_id, cr_amo, description, transaction_date } = this.state;
      const { accLedger, selected_item } = this.props;
      console.log(this.props);
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Income</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  Edit Income
               </div>
               {selected_item &&
                  <div className="card-body">
                     <div className="row">
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Date
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <DatePicker
                                    onChange={this.paymentDateHandlar}
                                    value={transaction_date}
                                    showLeadingZeroes={true}
                                 />
                              </div>
                           </div>
                        </div>

                        {accLedger &&
                           <div className="col-sm-2">
                              <div className="form-group">
                                 <label className="control-label">Income Type
                        <span className="required"> * </span>
                                 </label>
                                 <div className="form-input">
                                    <select className="form-control form-control-sm"
                                       required
                                       defaultValue={income_id}
                                       onChange={event => this.changeHandler(event, 'income_id')}>
                                       <option>Select...</option>
                                       {accLedger.map((item, index) => {
                                          return (
                                             <option key={index} value={item.id}>{item.income_type}</option>
                                          )
                                       })}
                                    </select>
                                 </div>
                              </div>
                           </div>
                        }
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Giver Name
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" name="party_name"
                                    required
                                    defaultValue={party_name}
                                    onChange={event => this.changeHandler(event, 'party_name')}
                                    placeholder="Giver Name" className="form-control form-control-sm" />
                                 <small className="form-text text-muted">Govt., Donation or Other Income re-source.</small>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Amount
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="number" name="cr_amo"
                                    required
                                    placeholder="Amount in INR"
                                    defaultValue={cr_amo}
                                    onChange={event => this.changeHandler(event, 'cr_amo')}
                                    className="form-control form-control-sm" />
                                 <small className="form-text text-danger">{amount_in_word}</small>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">Description (Narration)
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="test" name="description"
                                    placeholder="description"
                                    required
                                    defaultValue={description}
                                    onChange={event => this.changeHandler(event, 'description')}
                                    className="form-control form-control-sm" />
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               }
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-primary mr-2">Update</button>
                  <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                     Exit </button>
               </div>
            </form>
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: accLedger } = state.accLedger;
   return { user, accLedger };
}

const actionCreators = {
   getIndirectIncome: accLedgerActions.getIndirectIncome,
}

export default connect(mapStateToProps, actionCreators)(withRouter(EditIncome));