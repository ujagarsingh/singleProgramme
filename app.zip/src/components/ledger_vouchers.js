import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Nalvink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
class LedgerVouchers extends Component {

	state = {
		formIsHalfFilledOut: false,
	  }
	
	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
		  this.props.getAccLedgerEntry();
		}
	
		if (isEmptyObj(this.props.accLedger)) {
		  this.props.getAccLedger();
		}
	
		if (isEmptyObj(this.props.accGroup)) {
		  this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
		  this.props.getStudents();
		}
		// this.checkFlag();
	  }
	  
	render() {
		return (
			<div className="page-content">
				<Helmet>
					<title>Group Summary</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Group Summary</div>
				</div>
				<div className="card card-box sfpage-cover">
					<div className="card-body p-1 sfpage-body">
						<div className="acc-page page-ledger-vouchers">
							<div className="acc-page-head  container-fluid">
								<div className="sec-title">
									<div className="title-zone">Ledger : <strong>Alok 10nth</strong></div>
									<div className="info-zone">
										<div className="fy-detail"><strong>1-Apr-2020 to 1-Jul-2020</strong></div>
									</div>
								</div>
							</div>
							<div className="acc-page-body container-fluid">
								<table className="table table-sm">
									<thead>
										<tr className="lv-body-head">
											<th className="vch-date">Date</th>
											<th className="vch-name">Particulars</th>
											<th className="vch-type">Vch Type</th>
											<th className="vch-no">Vch No.</th>
											<th className="dr-amount">Debit</th>
											<th className="cr-amount">Credit</th>
										</tr>
									</thead>

									<tbody className="lv-body-area">
										<tr className="lv-detail-zone">
											<td className="vch-date">1-4-2020</td>
											<td className="vch-name">Admission Fees</td>
											<td className="vch-type">Journal</td>
											<td className="vch-no">1</td>
											<td className="dr-amount">6,000.00</td>
											<td className="cr-amount"></td>
										</tr>
										<tr className="lv-detail-zone">
											<td className="vch-date">2-4-2020</td>
											<td className="vch-name">Cash</td>
											<td className="vch-type">Receipt</td>
											<td className="vch-no">2</td>
											<td className="dr-amount"></td>
											<td className="cr-amount">6,000.00</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div className="acc-page-footer container-fluid">
								<div className="sec-foot">
									<div className="cl-blnc-zone">
										<div className="title-zone">Opening Balance : </div>
										<div className="amount-zone">
											<div className="dr-total">7,200.00</div>
											<div className="cr-total"></div>
										</div>
									</div>
									<div className="cl-blnc-zone">
										<div className="title-zone">Current Total : </div>
										<div className="amount-zone">
											<div className="dr-total"></div>
											<div className="cr-total">5,200.00</div>
										</div>
									</div>
									<div className="cl-blnc-zone">
										<div className="title-zone">Closing Balance : </div>
										<div className="amount-zone">
											<div className="dr-total"></div>
											<div className="cr-total">5,200.00</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	return {
	  user, students, accLedger, accGroup, accLedgerEntry,
	  filteredSchoolData, filteredClassesData
	};
  }
  
  const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
	
  }
  
  export default connect(mapStateToProps, actionCreators)(withRouter(LedgerVouchers));