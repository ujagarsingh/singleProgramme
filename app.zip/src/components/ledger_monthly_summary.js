import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';


class LedgerMonthlySummary extends Component {

	state = {
		formIsHalfFilledOut: false,
	  }

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
		  this.props.getAccLedgerEntry();
		}
	
		if (isEmptyObj(this.props.accLedger)) {
		  this.props.getAccLedger();
		}
	
		if (isEmptyObj(this.props.accGroup)) {
		  this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
		  this.props.getStudents();
		}
		// this.checkFlag();
	  }

	render() {
		return (
			<div className="page-content">
				<Helmet>
					<title>Group Summary</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Group Summary</div>
				</div>
				<div className="card card-box sfpage-cover">
					<div className="card-body p-1 sfpage-body">
						<div className="acc-page page-ledger-monthly-summary">
							<div className="acc-page-head  container-fluid">
								<div className="sec-title">
									<div className="title-zone">Particulars</div>
									<div className="info-zone">
										<table className="table table-bordered table-sm">
											<tr>
												<td colSpan="3">
													<div className="group-name">Alok 10nth</div>
													<div className="org-name">School Name</div>
													<div className="fy-detail">1-Apr-2020 to 1-Jul-2020</div>
												</td>
											</tr>
											<tr>
												<td colSpan="2">
													<div className="blnc-title">Transactions</div>
												</td>
												<td rowspan="2">
													<div className="blnc-cl-info">Closing Balance</div>
												</td>
											</tr>
											<tr>
												<td>
													<div className="dr-title">Debit</div>
												</td>
												<td>
													<div className="cr-title">Credit</div>
												</td>
											</tr>
										</table>
									</div>
								</div>
							</div>
							<div className="acc-page-body container-fluid">
								<div className="lms-detail-zone">
									<div className="lms-detail-head">
										<div className="head-name">April</div>
										<div className="head-amount">
											<div className="dr-amount">6,000.00</div>
											<div className="cr-amount">6,000.00</div>
											<div className="cl-balance"></div>
										</div>
									</div>
									<div className="lms-detail-head">
										<div className="head-name">May</div>
										<div className="head-amount">
											<div className="dr-amount"></div>
											<div className="cr-amount"></div>
											<div className="cl-balance"></div>
										</div>
									</div>
									<div className="lms-detail-head">
										<div className="head-name">June</div>
										<div className="head-amount">
											<div className="dr-amount">2,700.00</div>
											<div className="cr-amount"></div>
											<div className="cl-balance">2,700.00 Dr</div>
										</div>
									</div>
									<div className="lms-detail-head">
										<div className="head-name">July</div>
										<div className="head-amount">
											<div className="dr-amount"></div>
											<div className="cr-amount">1,500.00</div>
											<div className="cl-balance">1,200.00 Dr</div>
										</div>
									</div>

								</div>
							</div>
							<div className="acc-page-footer container-fluid">
								<div className="sec-foot">
									<div className="title-zone">Ground Total</div>
									<div className="amount-zone">
										<div className="dr-total">7,200.00</div>
										<div className="cr-total">5,200.00</div>
										<div className="cl-blnc-total">2,000.00 Dr</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	return {
	  user, students, accLedger, accGroup, accLedgerEntry,
	  filteredSchoolData, filteredClassesData
	};
  }
  
  const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
	
  }
  
  export default connect(mapStateToProps, actionCreators)(withRouter(LedgerMonthlySummary));