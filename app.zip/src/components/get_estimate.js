import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { Picky } from 'react-picky';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { classesAction, studentsAction, conveyanceAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
const GET_STUDENTS = `http://schools.rajpsp.com/api/students/read.php`;
const GET_STUDENT = `http://schools.rajpsp.com/api/students/read_one.php`;
const GET_CLASS_FEE = `http://schools.rajpsp.com/api/fee_amount/read_class_fee.php`;
//const GET_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/read.php`; 
//const CREATE_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/create.php`;
const UPDATE_STUDENT_URL = `http://schools.rajpsp.com/api/students/update.php`;
//const VERIFY_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/verify.php`; 
const GET_PRE_DEPOSIT_RECORD = `http://schools.rajpsp.com/api/fee_deposit/read_pre_deposit_months.php`;
const READ_CONVENCE = `http://schools.rajpsp.com/api/conveyance/read.php`;

class GetEstimate extends Component {
   state = {
      medium: '',
      depo_fee_students: [],
      all_classes: [],
      classes: [],
      conveyances: [],
      selected_class_id: '',
      students: [],
      selected_student_id: '',
      selected_student: null,
      selected_student_info: '',
      fee_date: '',
      pre_fee_deposit_arr: {},
      class_fee_arr: [],
      class_fee_Has: false,
      deposit_fee_arr: [],
      final_deposit_fee_arr: [],
      varified_deposit_fee_arr: [],
      monthly_fee_amo: 0, // from database
      convence_fee_amo: 0, // from database
      exam_fee_amo: 0, // from database
      reg_fee_amo: 0, // from database
      sports_fee_amo: 0, // from database
      total_amount: 0,
      total_discount: 0,
      ground_total: 0,
      total_monthly_amount: 0,
      total_convence_amount: 0,
      total_monthly_discount: 0,
      total_convence_discount: 0,
      monthly_discount: 0, // in percentage
      convence_discount: 0, // in percengage
      fee_amount: 0,
      current_depo_amount: 0,
      balance_amount: 0,
      current_date: '2019-10-20',
      fee_date: new Date(),
      monthly_will_deposit_months: [], // all months of getting fee 
      monthly_selected_deposit_months: [], // current months of fee deposit
      monthly_difference_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'], // not paymented months
      set_monthly_fee_amo: 0,
      //convence_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
      convence_will_deposit_months: [],
      convence_selected_deposit_months: [],
      convence_diffrence_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
      set_convence_fee_amo: 0,
      set_exam_fee_amo: 0,
      set_reg_fee_amo: 0,
      set_sports_fee_amo: 0,
      reg_fee: false,
      sports_fee: false,
      exam_fee: false,
      seat_type: '',
      description: '',
      formIsHalfFilledOut: false,
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      const _temp_arr = ['oneTime'];
      const _tempTarget = event.target.checked;
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      },
         () => {
            this.calcFee();
            if (isCheckbox && _tempTarget === true) {
               this.depositFeeRecord(fieldName, _temp_arr);
            } else {
               // this.depositFeeRecordChange(fieldName);
            }
         });
      if (fieldName === 'medium') {
         const _medium = event.target.value;
         const _classes = this.state.all_classes.filter((item, inx) => {
            if (item.medium === _medium) {
               return item
            }
         })
         this.setState({
            classes: _classes
         })
      }
   };
   checkHandler = (event, fieldName, id) => {
      let _final_deposit_fee_arr = null;
      let _id = id;
      if (fieldName === 'select_this') {
         _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
            if (_id === item.id) {
               item['isChecked'] = !item.isChecked;
               return item;
            }
            return item;
         })
         this.setState({
            final_deposit_fee_arr: _final_deposit_fee_arr
         })
      } else if (fieldName === 'select_all') {
         _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
            item['isChecked'] = (event.target.checked) ? true : false;
            return item;
         })
         this.setState({
            final_deposit_fee_arr: _final_deposit_fee_arr
         })
      }
   };
   monthlyDiscountHandlar(event) {
      const _setAmo = this.state.set_monthly_fee_amo;
      const _md = event.target.value;
      const _td = parseInt(_setAmo * (event.target.value / 100));
      const _ma = _setAmo - _td;
      this.setState({
         monthly_discount: _md,
         total_monthly_discount: _td,
         total_monthly_amount: _ma
      }, () => {
         this.calcFee();
         this.updateDiscount('monthly', _md)
      })
   }
   convenceDiscountHandlar(event) {
      const _setAmo = this.state.set_convence_fee_amo;
      const _md = event.target.value;
      const _td = parseInt(_setAmo * (event.target.value / 100));
      const _ma = _setAmo - _td;
      this.setState({
         convence_discount: _md,
         total_convence_discount: _td,
         total_convence_amount: _ma
      }, () => {
         this.calcFee();
         this.updateDiscount('convence', _md)
      })
   }

   updateDiscount = (_type, _rate) => {
      const _depositArr = this.state.deposit_fee_arr;
      const _deposit_fee_arr = _depositArr.map((value, index) => {
         if (value.fee_title === _type) {
            value.fee_discount = parseInt(value.fee_total * _rate / 100);
            value.fee_amount = value.fee_total - value.fee_discount;
         }
         return value;
      })
      this.setState({
         deposit_fee_arr: _deposit_fee_arr
      })


      //console.log(this.state.deposit_fee_arr)
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.conveyance)) {
         this.props.getConveyance();
      }
   }

   checkAuthentication(obj) {
      loadProgressBar();
      axios.post(VALIDATE_URL, obj)
         .then(res => {
            const getRes = res.data;
            // sessionStorage.setItem("user", getRes.data);
            console.log(getRes);
            if (getRes.data) {
               this.setState({
                  user: getRes.data,
                  group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
                  school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
                  user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
                  session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
               }, () => {
                  this.getClassesHandler();
                  this.getConvencesHandler();
               })
            }
         }).catch((error) => {
            this.props.history.push('/login.jsp');
         })
   }

   getClassesHandler() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id,
      }
      axios.post(GET_CLASSES, obj)
         .then(res => {
            const getRes = res.data;
            this.setState({
               classes: getRes,
               all_classes: getRes,
               errorMessages: getRes.message
            });
            ////console.log(this.state.classes);
         }).catch((error) => {
            // error
         })


   };
   getConvencesHandler() {
      axios.get(READ_CONVENCE)
         .then(res => {
            const conveyances = res.data;
            this.setState({
               conveyances: conveyances,
               errorMessages: res.data.message
            });
            //console.log(this.state.conveyance);
         }).catch((error) => {
            // error
         })

      //this.getUnvarifiedRecord();
   }
   /*getUnvarifiedRecord = () => {
      axios.get(GET_FEE_DEPOSIT)
         .then(res => {
            const deposited_arr = res.data;
            const _deposited_arr = deposited_arr.map((item) => {
               const _item = item;
               _item.isChecked = false;
               return _item
            })
            this.setState({
               final_deposit_fee_arr: _deposited_arr,
               errorMessages: res.data.message
            });
            ////console.log(this.state.classes);
         }).catch((error) => {
            // error
         })
   }*/
   feeDepositDate = (feeDate) => {
      this.setState({ fee_date: feeDate });
      //this.to.openCalendar();
   };
   monthlyFeeHandlaer = (value) => {
      console.count('onChange');
      this.setState({
         monthly_selected_deposit_months: value, //july, august
         set_monthly_fee_amo: (value.length * this.state.monthly_fee_amo),
         total_monthly_amount: (value.length * this.state.monthly_fee_amo)
      }, () => {
         this.calcFee();
         this.depositFeeRecord('monthly', value);
      });
   }
   convenceFeeHandlaer = (value) => {
      //console.count('onChange')
      this.setState({
         convence_selected_deposit_months: value,
         set_convence_fee_amo: (value.length * this.state.convence_fee_amo),
         total_convence_amount: (value.length * this.state.convence_fee_amo)
      }, () => {
         this.calcFee();
         this.depositFeeRecord('convence', value);
      });
   }
   selectStudentNameHandlar = (event) => {
      loadProgressBar();
      const student_id = JSON.parse(event.target.value).admission_number;
      this.setState({
         selected_student: JSON.parse(event.target.value).student_name,
         selected_student_id: JSON.parse(event.target.value).admission_number,
         seat_type: JSON.parse(event.target.value).free_seat,
         description: '',
         monthly_selected_deposit_months: [],
         convence_selected_deposit_months: [],
         total_amount: 0,
         total_convence_amount: 0,
         total_convence_discount: 0,
         total_discount: 0,
         total_monthly_amount: 0,
         total_monthly_discount: 0,
         set_monthly_fee_amo: 0,
         set_convence_fee_amo: 0,
         convence_fee_amo: 0
      },
         () => {
            axios.get(GET_PRE_DEPOSIT_RECORD + '?student_id=' + student_id)
               .then(res => {
                  const deposited_arr = res.data;
                  //var _deposited_monthly = this.state.monthly_will_deposit_months;// this.arrayDiffrence(this.state.monthly_will_deposit_months, deposited_arr.monthly);
                  //var _deposited_convence = this.arrayDiffrence(this.state.convence_will_deposit_months, deposited_arr.convence);
                  this.setState({
                     pre_fee_deposit_arr: deposited_arr,
                     // monthly_difference_months: _deposited_monthly,
                     //convence_diffrence_months: _deposited_convence,
                     errorMessages: deposited_arr.message
                  });
                  ////console.log(this.state.pre_fee_deposit_arr);
               }).catch((error) => {
                  // error
               });
            axios.get(GET_STUDENT + '?id=' + student_id)
               .then(res => {
                  const stu_reco = res.data;
                  var _conveyance_amo = 0;

                  //(res.data.convence_area !== '') ? (
                  this.state.conveyances.filter((item, index) => {
                     if (item.stoppage_name === stu_reco.convence_area) {
                        _conveyance_amo = parseInt(item.stoppage_amo);
                     }
                  })
                  //) : null;

                  this.setState({
                     selected_student_info: stu_reco,
                     convence_fee_amo: _conveyance_amo,
                     monthly_discount: stu_reco.monthly_discount,
                     convence_discount: stu_reco.convence_discount,
                     errorMessages: res.data.message
                  });
               }).catch((error) => {
                  // error
               })
         });
   };
   arrayDiffrence = (a1, a2) => {
      var a = [], diff = [];
      for (var i = 0; i < a1.length; i++) {
         a[a1[i]] = true;
      }
      for (var i = 0; i < a2.length; i++) {
         if (a[a2[i]]) {
            delete a[a2[i]];
         } else {
            a[a2[i]] = true;
         }
      }
      for (var k in a) {
         diff.push(k);
      }
      return diff;
   }
   /*
     depositFeeRecordChange = (title) => {
       let _temp_record = this.state.deposit_fee_arr.filter((value) => {
         return value.fee_title !== title;
       });
       this.setState({
         deposit_fee_arr: _temp_record
       }, () => {
         //console.log(this.state.deposit_fee_arr);
       })
     }*/
   formatDate = (date) => {
      var monthNames = [
         "January", "February", "March",
         "April", "May", "June", "July",
         "August", "September", "October",
         "November", "December"
      ];
      var day = date.getDate();
      var monthIndex = date.getMonth();
      var year = date.getFullYear();
      return day + ' ' + monthNames[monthIndex] + ' ' + year;
   }

   depositFeeRecord = (title, val) => {
      let _temp_record = this.state.deposit_fee_arr.filter((value, index) => {
         return value.fee_title !== title;
      });
      let _fee_amount = 0;
      if (title === 'monthly') {
         _fee_amount = this.state.monthly_fee_amo
      } if (title === 'convence') {
         _fee_amount = this.state.convence_fee_amo
      } if (title === 'reg_fee') {
         _fee_amount = this.state.reg_fee_amo
      } if (title === 'sports_fee') {
         _fee_amount = this.state.sports_fee_amo
      } if (title === 'exam_fee') {
         _fee_amount = this.state.exam_fee_amo
      }
      for (var x = 0; x < val.length; x++) {
         const deposit_fee_record = {
            student_id: this.state.selected_student_id,
            //student_name: this.state.selected_student,
            //student_class: this.state.student_class,
            fee_title: title, // registration, monthly, sports, advance...
            month_of_fee: val[x],
            fee_amount: _fee_amount,
            fee_discount: 0,
            fee_total: _fee_amount,
            //deposit_date: this.state.fee_date
            //discription: this.state.description,
         };
         _temp_record = _temp_record.concat(deposit_fee_record);
      }
      this.setState({
         deposit_fee_arr: _temp_record
      }, () => {
         //console.log(this.state.deposit_fee_arr);
      })
   }
   calcFee = () => {
      var _state = this.state;
      ////console.log(_state);
      var _total_fee = _state.set_monthly_fee_amo + _state.set_convence_fee_amo;
      var _balance_amo = (_state.current_depo_amount > 0) ? (_state.current_depo_amount - _state.total_amount) : 0;
      var _total_discount = _state.total_convence_discount + _state.total_monthly_discount;

      if (this.state.reg_fee) {
         _total_fee = _total_fee + _state.reg_fee_amo
      } if (this.state.sports_fee) {
         _total_fee = _total_fee + _state.sports_fee_amo
      } if (this.state.exam_fee) {
         _total_fee = _total_fee + _state.exam_fee_amo
      }

      this.setState({
         total_amount: _total_fee - _total_discount,
         total_discount: _total_discount,
         ground_total: _total_fee,
         balance_amount: _balance_amo
      }, () => {
         this.createMsz();
      })
   }
   createMsz = () => {
      const _state = this.state;
      const _ef = (_state.exam_fee) ? ', Exam Fee' : '';
      const _rf = (_state.reg_fee) ? ', Reg. Fee' : '';
      const _sf = (_state.sports_fee) ? ', Sport Fee' : '';
      const _cf = (_state.convence_selected_deposit_months.length > 0) ?
         (', Transport : ' + _state.convence_selected_deposit_months.join(', ')) : '';
      const _mf = (_state.monthly_selected_deposit_months.length > 0) ?
         ((_state.monthly_selected_deposit_months.length === 12) ?
            (', Monthly : Full Year') :
            (', Monthly : ' + _state.monthly_selected_deposit_months.join(', '))) : '';
      const _da = (_state.total_discount) ?
         (', Discount : ' + _state.total_discount +
            ', Ground Total : ' + _state.ground_total) : '';

      const _msz = _state.selected_student + ' of ' + _state.student_class + ' Deposited fee : ' +
         _mf + _cf + _sf + _rf + _ef +
         ', Amount : ' + _state.total_amount + _da;

      this.setState({
         description: _msz
      })
   }
   getSectedClassHandler = (event) => {
      loadProgressBar();
      const _selected_class_id = JSON.parse(event.target.value).id;
      const _student_class = JSON.parse(event.target.value).class_name;
      this.setState({
         selected_class_id: _selected_class_id,
         student_class: _student_class
      }, () => {
         const obj = {
            class_id: this.state.selected_class_id,
            medium: this.state.medium
         };

         axios.post(GET_STUDENTS, obj)
            .then(res => {
               this.setState({
                  students: res.data,
                  errorMessages: res.data.message
               });
               //console.log(this.state.students);
            }).catch((error) => {
               // error
            })
         axios.get(GET_CLASS_FEE + '?class_id=' + _selected_class_id)
            .then(res => {
               if (Array.isArray(res.data)) {
                  this.setState({
                     class_fee_arr: res.data,
                     class_fee_Has: true
                  }, () => {
                     this.classFeeUpdate();
                  });
                  //  //console.log(this.state);
               } else {
                  Alert.error('This Class Fee Structure Not Added Please Update it first using [ Setting > Pamnent ]', {
                     position: 'bottom-right',
                     effect: 'jelly',
                     timeout: 5000, offset: 40
                  });
                  this.setState({
                     class_fee_Has: false
                  })
               }
            }).catch((error) => {
               // error
            })
      });
   }
   getFeeTime = (elem) => {
      let fee_time = [];
      if (elem.collect_time_jul = 'yes') { fee_time.push('July') }
      if (elem.collect_time_aug = 'yes') { fee_time.push('August') }
      if (elem.collect_time_sep = 'yes') { fee_time.push('September') }
      if (elem.collect_time_oct = 'yes') { fee_time.push('October') }
      if (elem.collect_time_nov = 'yes') { fee_time.push('November') }
      if (elem.collect_time_dec = 'yes') { fee_time.push('December') }
      if (elem.collect_time_jan = 'yes') { fee_time.push('January') }
      if (elem.collect_time_feb = 'yes') { fee_time.push('Fabruary') }
      if (elem.collect_time_mar = 'yes') { fee_time.push('March') }
      if (elem.collect_time_apr = 'yes') { fee_time.push('April') }
      if (elem.collect_time_may = 'yes') { fee_time.push('May') }
      if (elem.collect_time_jun = 'yes') { fee_time.push('June') }
      return fee_time;
   }
   classFeeUpdate = () => {
      //const new_class_fee = this.state.class_fee_arr;
      if (Array.isArray(this.state.class_fee_arr)) {
         this.state.class_fee_arr.map((class_fee) => {
            if (class_fee.cat_name === 'Monthly') {
               const fee_time = this.getFeeTime(class_fee);//Object.values(class_fee);
               this.setState({ monthly_fee_amo: parseInt(class_fee.fee_amount), monthly_will_deposit_months: fee_time })
            } else if (class_fee.cat_name === 'Convence') {
               const fee_time = this.getFeeTime(class_fee);
               this.setState({ convence_fee_amo: parseInt(class_fee.fee_amount), convence_will_deposit_months: fee_time })
            } else if (class_fee.cat_name === 'Exam') {
               this.setState({ exam_fee_amo: parseInt(class_fee.fee_amount) })
            } else if (class_fee.cat_name === 'Registration') {
               this.setState({ reg_fee_amo: parseInt(class_fee.fee_amount) })
            } else if (class_fee.cat_name === 'Sports') {
               this.setState({ sports_fee_amo: parseInt(class_fee.fee_amount) })
            }
         })
      }

      //console.log(this.state);
   }
   getFeeHandler = (event) => {
      //console.log("fee handlar called");
   }
   submitHandler = e => {
      loadProgressBar();
      const _state = this.state;
      e.preventDefault();
      const obj = {
         ..._state.selected_student_info,
         convence_discount: _state.convence_discount,
         monthly_discount: _state.monthly_discount,
         description: _state.description,
      };
      const singleObj = { myObj: [obj] }
      //console.log(JSON.stringify(singleObj));
      axios.post(UPDATE_STUDENT_URL, singleObj)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes)
            Alert.success(getRes.message, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })
   }
   render() {
      const { medium, classes, class_fee_Has, selected_student, students, fee_date, monthly_difference_months,
         monthly_selected_deposit_months, monthly_discount, total_monthly_amount, total_monthly_discount, set_monthly_fee_amo,
         selected_student_info, convence_selected_deposit_months, convence_diffrence_months, convence_discount,
         total_convence_amount, total_convence_discount, set_convence_fee_amo, seat_type, pre_fee_deposit_arr,
         reg_fee, sports_fee, exam_fee, description, total_amount, total_discount, ground_total } = this.state;
      //console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Get Estimate</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

            <div className="page-bar d-flex">
               <div className="page-title">Fee Estimate</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <div className="form-group mr-2 mt-1">
                        <label className="control-label mr-1">Medium :</label>
                        <select className="form-control form-control-sm"
                           onChange={event => this.changeHandler(event, 'medium')}>
                           <option >Select ...</option>
                           <option value="English">English</option>
                           <option value="Hindi" >Hindi</option>
                        </select>
                     </div>
                     <div className="form-group mr-2 mt-1">
                        <label className="control-label mr-2">Class<span className="required"> * </span>
                        </label>
                        <select className="form-control form-control-sm"
                           disabled={medium === '' ? true : false}
                           onChange={this.getSectedClassHandler}>
                           <option value>Select...</option>
                           {classes.map((option, index) => {
                              return (
                                 <option key={index} value={JSON.stringify(option)}>{option.class_name}</option>
                              )
                           })}
                        </select>
                     </div>
                     {(class_fee_Has) ?
                        <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Student Name <span className="required"> * </span>
                           </label>
                           <select
                              disabled={(students.length > 0) ? false : true}
                              className="form-control form-control-sm" name="select"
                              //defaultValue={selected_student}
                              onChange={this.selectStudentNameHandlar}>
                              <option value>Select...</option>
                              {students.map((option, index) => {
                                 return (
                                    <option key={index} value={JSON.stringify(option)}>
                                       {option.student_name} [{option.admission_number}]</option>
                                 )
                              })}
                           </select>
                        </div>
                        : null}
                     <div className="form-group mt-1">
                        <label className="control-label mr-2">Collection Date</label>
                        <div className="input-group">
                           <DatePicker
                              disabled={true}
                              onChange={this.feeDepositDate}
                              value={fee_date}
                              showLeadingZeroes={true}
                              minDate={new Date()}
                           />
                        </div>
                     </div>
                  </div>
               </div></div>
            <form className="card card-box sfpage-cover" onSubmit={this.submitHandler}>
               <div className="card-body" >
                  <div className="table-scrollable">
                     <div className="col">
                        {class_fee_Has ?
                           <div className="form-horizontal" >
                              <div className="form-body">
                                 <div className="row">

                                    <div className="col-lg-6">
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Monthly </label>
                                          <div className="col-md-7">
                                             <div className="row">
                                                <Picky
                                                   className="col-9 pr-0"
                                                   value={monthly_selected_deposit_months}
                                                   options={monthly_difference_months}
                                                   onChange={this.monthlyFeeHandlaer}
                                                   open={false}
                                                   valueKey="id"
                                                   labelKey="name"
                                                   multiple={true}
                                                   includeSelectAll={true}
                                                   includeFilter={true}
                                                   dropdownHeight={200}
                                                />
                                                <div className="col-3 pl-0">
                                                   <button type="button" className="btn btn-block btn-primary"><i className="fas fa-check"></i></button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Discount in Monthly Fee</label>
                                          <div className="col-md-7">
                                             <div className="input-group mb-3">
                                                <input type="text" className="form-control form-control-sm"
                                                   disabled={(monthly_selected_deposit_months.length > 0) ? false : true}
                                                   value={monthly_discount}
                                                   maxLength="2" size="2"
                                                   onChange={event => this.monthlyDiscountHandlar(event)} />
                                                <div className="input-group-append">
                                                   <span className="input-group-text pt-1 pb-1">%</span>
                                                </div>
                                             </div>
                                             <small className="form-text text-muted">Please Input Discount in %</small>
                                             <div className="row">
                                                <div className="col pr-0">
                                                   <input disabled={true}
                                                      type="text" className="form-control form-control-sm"
                                                      value={total_monthly_amount} />
                                                </div>
                                                <div className="col pl-0">
                                                   <input disabled={true}
                                                      type="number" className="form-control form-control-sm"
                                                      value={total_monthly_discount} />
                                                </div>
                                                <div className="col">
                                                   <input disabled={true}
                                                      type="number" className="form-control form-control-sm"
                                                      value={set_monthly_fee_amo} />
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    {(selected_student_info.convence_area != "") ?
                                       <div className="col-lg-6">
                                          <div className="form-group row">
                                             <label className="control-label col-md-4">Transport </label>
                                             <div className="col-md-7">
                                                <div className="row">
                                                   <Picky
                                                      className="col-9 pr-0"
                                                      value={convence_selected_deposit_months}
                                                      options={convence_diffrence_months}
                                                      onChange={this.convenceFeeHandlaer}
                                                      open={false}
                                                      valueKey="id"
                                                      labelKey="name"
                                                      multiple={true}
                                                      includeSelectAll={true}
                                                      includeFilter={true}
                                                      dropdownHeight={200}
                                                   />
                                                   <div className="col-3 pl-0">
                                                      <button type="button" className="btn btn-block btn-primary"><i className="fas fa-check"></i></button>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="form-group row">
                                             <label className="control-label col-md-4">Discount in Cpnvence Fee</label>
                                             <div className="col-md-7">
                                                <div className="input-group mb-3">
                                                   <input type="text" className="form-control form-control-sm"
                                                      disabled={(convence_selected_deposit_months.length > 0) ? false : true}
                                                      value={convence_discount}
                                                      maxLength="2" size="2"
                                                      onChange={event => this.convenceDiscountHandlar(event)} />
                                                   <div className="input-group-append">
                                                      <span className="input-group-text  pt-1 pb-1">%</span>
                                                   </div>
                                                </div>
                                                <small className="form-text text-muted">Please Input Discount in %</small>
                                                <div className="row">
                                                   <div className="col pr-0">
                                                      <input disabled={true}
                                                         type="text" className="form-control form-control-sm"
                                                         value={total_convence_amount} />
                                                   </div>
                                                   <div className="col pl-0">
                                                      <input disabled={true}
                                                         type="number" className="form-control form-control-sm"
                                                         value={total_convence_discount} />
                                                   </div>
                                                   <div className="col">
                                                      <input disabled={true}
                                                         type="number" className="form-control form-control-sm"
                                                         value={set_convence_fee_amo} />
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       : null}
                                    <div className="d-block w-100"></div>
                                    <div className="col-sm-6">
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Other Fee</label>
                                          <div className="col-md-7 pt-2">
                                             {seat_type === '1' ? <input type="text"
                                                disabled={true} className="form-control form-control-sm" value="FREE SEART" />
                                                : null
                                             }
                                             {(pre_fee_deposit_arr.reg_fee !== 'oneTime' && seat_type === '0') ? (
                                                <div className="custom-control custom-control-inline custom-checkbox">
                                                   <input
                                                      checked={reg_fee}
                                                      onChange={event => this.changeHandler(event, 'reg_fee', true)}
                                                      type="checkbox" className="custom-control-input" id="reg_fee" />
                                                   <label className="custom-control-label" htmlFor="reg_fee">Registration</label>
                                                </div>
                                             ) : null}

                                             {(pre_fee_deposit_arr.sports_fee !== 'oneTime' && seat_type === '0') ? (
                                                <div className="custom-control custom-control-inline custom-checkbox">
                                                   <input
                                                      checked={sports_fee}
                                                      onChange={event => this.changeHandler(event, 'sports_fee', true)}
                                                      type="checkbox" className="custom-control-input" id="sports_fee" />
                                                   <label className="custom-control-label" htmlFor="sports_fee">Sport</label>
                                                </div>
                                             ) : null}
                                             {(pre_fee_deposit_arr.exam_fee !== 'oneTime' && seat_type === '0') ? (
                                                <div className="custom-control  custom-control-inline custom-checkbox">
                                                   <input
                                                      value={exam_fee}
                                                      onChange={event => this.changeHandler(event, 'exam_fee', true)}
                                                      type="checkbox" className="custom-control-input" id="exam_fee" />
                                                   <label className="custom-control-label" htmlFor="exam_fee">Exam</label>
                                                </div>
                                             ) : null}


                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <hr />
                                 <div className="row bg-primary pt-3 text-white">
                                    <div className="col-sm-6">
                                       <div className="form-group row">
                                          <label className="control-label col-md-12 text-left pb-2 pt-0">Payment summary
                    </label>
                                          <div className="col-md-12">
                                             <textarea
                                                value={description}
                                                onChange={event => this.changeHandler(event, 'description')}
                                                placeholder="payment details" className="form-control form-control-sm-textarea form-control-sm"
                                                rows={5} />
                                          </div>
                                       </div>
                                    </div>

                                    <div className="col-sm-6">
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Total Fee
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={total_amount}
                                                type="number" placeholder="enter amount" className="form-control form-control-sm input-md" /> </div>
                                       </div>
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Total Discount
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={total_discount}
                                                type="number" placeholder="enter amount" className="form-control form-control-sm input-md" /> </div>
                                       </div>
                                       <div className="form-group row">
                                          <label className="control-label col-md-4">Ground Total
                              </label>
                                          <div className="col-md-7">
                                             <input disabled={true}
                                                value={ground_total}
                                                type="text" placeholder="enter amount" className="form-control form-control-sm input-md" /> </div>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                           </div>
                           :
                           <div className="alert alert-dismissible alert-danger">
                              <strong>Note : </strong>
                              In this panel check any student's fee estimate and will be update only :
                              <ul className="ml-4">
                                 <li>Convence Months</li>
                                 <li>Convence Discount</li>
                                 <li>Monthly Fee Discount</li>
                              </ul>
                           </div>
                        }
                     </div>
                  </div>
               </div>
               <div className="card-footer d-flex">
                  <button type="submit" className="btn btn-primary mr-2 ml-auto">Submit</button>
                  <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
               </div>
            </form>
         </div >
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: classes } = state.classes;
   const { item: students } = state.students;
   const { item: conveyance } = state.conveyance;
   return { user, classes, students, conveyance };
}

const actionCreators = {
   getClasses: classesAction.getClasses,
   getStudents: studentsAction.getStudents,
   getConveyance: conveyanceAction.getConveyance,
}

export default connect(mapStateToProps, actionCreators)(withRouter(GetEstimate));