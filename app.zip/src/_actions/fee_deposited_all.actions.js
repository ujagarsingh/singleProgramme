import { feeDepositedAllConstants } from '../_constants';
import { feeDepositedAllService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeDepositedAllAction = {
    getFeeDepositedAll,
    create,
}; 

function getFeeDepositedAll() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeDepositedAllService.getFeeDepositedAll()
            .then(
                response => {
                    dispatch(success(response.data.fee_amo_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: feeDepositedAllConstants.FEE_COLLECTION_REQUEST } }
    function success(response) { return { type: feeDepositedAllConstants.FEE_COLLECTION_SUCCESS, response } }
    function failure(error) { return { type: feeDepositedAllConstants.FEE_COLLECTION_FAILURE, error } }
}
 
function create(obj) {
    return dispatch => {
        dispatch(request());

        feeDepositedAllService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: feeDepositedAllConstants.CREATE_FEE_REQUEST } }
    function success(response) { return { type: feeDepositedAllConstants.CREATE_FEE_SUCCESS, response } }
    function failure(error) { return { type: feeDepositedAllConstants.CREATE_FEE_FAILURE, error } }
}
 
