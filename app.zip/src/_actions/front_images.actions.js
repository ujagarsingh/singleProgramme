import { frontImagesConstants } from '../_constants';
import { frontImagesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const frontImagesActions = {
    getFrontImages,
    createFrontImages,
    update,
    delete : _delete
};

function getFrontImages() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontImagesService.getFrontImages()
            .then(
                response => {
                    dispatch(success(response.data.images_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontImagesConstants.IMAGES_REQUEST } }
    function success(response) { return { type: frontImagesConstants.IMAGES_SUCCESS, response } }
    function failure(error) { return { type: frontImagesConstants.IMAGES_FAILURE, error } }
}
 

function createFrontImages(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontImagesService.createFrontImages(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontImagesConstants.CREATE_IMAGES_REQUEST } }
    function success(response) { return { type: frontImagesConstants.CREATE_IMAGES_SUCCESS, response } }
    function failure(error) { return { type: frontImagesConstants.CREATE_IMAGES_FAILURE, error } }
}
 

function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontImagesService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontImagesConstants.UPDATE_IMAGES_REQUEST } }
    function success(response) { return { type: frontImagesConstants.UPDATE_IMAGES_SUCCESS, response } }
    function failure(error) { return { type: frontImagesConstants.UPDATE_IMAGES_FAILURE, error } }
}
 
 

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        frontImagesService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.id),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: frontImagesConstants.DELETE_IMAGES_REQUEST } }
    function success(response) { return { type: frontImagesConstants.DELETE_IMAGES_SUCCESS, response } }
    function failure(error) { return { type: frontImagesConstants.DELETE_IMAGES_FAILURE, error } }
}
 