import { singleStudentSubjectExamsMarksobtnConstants } from '../_constants';
import { singleStudentSubjectExamsMarksobtnService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const singleStudentSubjectExamsMarksobtnAction = {
    getSingleSSEM
};

function getSingleSSEM(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        singleStudentSubjectExamsMarksobtnService.getSingleSSEM(obj)
            .then(
                response => {
                    dispatch(success(response.data.single_ssem_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_REQUEST } }
    function success(response) { return { type: singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_SUCCESS, response } }
    function failure(error) { return { type: singleStudentSubjectExamsMarksobtnConstants.SINGLE_SSEM_FAILURE, error } }
}
 