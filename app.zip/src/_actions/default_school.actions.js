import { defaultSchoolConstants } from '../_constants';
import { defaultSchoolService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultSchoolActions = {
    getDefaultSchool
};

function getDefaultSchool() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultSchoolService.getDefaultSchool()
            .then(
                response => {
                    dispatch(success(response.data.school_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultSchoolConstants.SCHOOLS_REQUEST } }
    function success(response) { return { type: defaultSchoolConstants.SCHOOLS_SUCCESS, response } }
    function failure(error) { return { type: defaultSchoolConstants.SCHOOLS_FAILURE, error } }
}
 