import { defaultSliderConstants } from '../_constants';
import { defaultSliderService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultSliderActions = {
    getDefaultSlider
};

function getDefaultSlider() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultSliderService.getDefaultSlider()
            .then(
                response => {
                    dispatch(success(response.data.slider_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultSliderConstants.SLIDER_REQUEST } }
    function success(response) { return { type: defaultSliderConstants.SLIDER_SUCCESS, response } }
    function failure(error) { return { type: defaultSliderConstants.SLIDER_FAILURE, error } }
}
 