import { defaultGalleryConstants } from '../_constants';
import { defaultGalleryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultGalleryActions = {
    getDefaultGallery
};

function getDefaultGallery() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultGalleryService.getDefaultGallery()
            .then(
                response => {
                    dispatch(success(response.data.gallery_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultGalleryConstants.GALLERY_REQUEST } }
    function success(response) { return { type: defaultGalleryConstants.GALLERY_SUCCESS, response } }
    function failure(error) { return { type: defaultGalleryConstants.GALLERY_FAILURE, error } }
}
 