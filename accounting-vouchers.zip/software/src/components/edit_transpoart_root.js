import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_URL = `http://schools.rajpsp.com/api/conveyance/read_one.php`;
const UPDATE_URL = `http://schools.rajpsp.com/api/conveyance/update.php`;

class EditTranspoartRoot extends Component {
  state = {
    id: '',
    school_id: '',
    stoppage_name: '',
    stoppage_amo: '',
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };

  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const item = this.props.selected_item;
    // debugger
    this.setState({
      id: item.id,
      stoppage_name: item.stoppage_name,
      stoppage_amo: item.stoppage_amo,
      school_id: item.school_id,
    });
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getRootDetailsHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getRootDetailsHandler() {
  //   const { match } = this.props;
  //   loadProgressBar();
  //   // axios.get(READ_URL + `?id=` + match.params.id)
  //   //   .then(res => {
  //   //     const resData = res.data;
  //   //     this.setState({
  //   //       id: resData.id,
  //   //       stoppage_name: resData.stoppage_name,
  //   //       stoppage_amo: resData.stoppage_amo,
  //   //       errorMessages: res.data.message
  //   //     });
  //   //     //console.log(this.state.conveyance);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })
  // };
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {

    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }
    const form_obj = {
      id: this.state.id,
      stoppage_name: this.state.stoppage_name,
      stoppage_amo: this.state.stoppage_amo
    }
    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);

    // axios.post(UPDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  render() {
    const { formIsHalfFilledOut, stoppage_name, stoppage_amo, school_id } = this.state;
    const { user, schools, selected_item } = this.props;
    console.log(this.state);
    console.log(schools);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Transport Root</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <form className="card card-form card-edit" onSubmit={event => this.confirmBoxDelete(event)}>
          <div className="card-header">
            Edit Transpoart Root
          </div>
          <div className="card-body">
            {user && selected_item && schools && school_id &&
              <div className="row">
                {(user.user_category === "1") &&
                  <div className="col-sm-3">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        defaultValue={school_id}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Root Name
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text"
                        required={true}
                        placeholder="enter village name" className="form-control form-control-sm"
                        value={stoppage_name}
                        onChange={event => this.changeHandler(event, 'stoppage_name')}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Amount
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="number"
                        required={true}
                        placeholder="enter amount" className="form-control form-control-sm"
                        value={stoppage_amo}
                        onChange={event => this.changeHandler(event, 'stoppage_amo')}
                      />
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
          <div className="card-footer  text-right">
            <button type="submit" className="btn btn-primary mr-2">Update</button>
            {/* <NavLink to="/all_transpoart_root.jsp" className="btn btn-danger">Cancel</NavLink> */}
            <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
              Exit </button>
          </div>
        </form>
      </div>
    )
  }
}
export default withRouter(EditTranspoartRoot);