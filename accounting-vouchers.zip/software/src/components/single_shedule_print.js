import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
// import SingleShedule from './single_shedule';
import SingleSheduleIdCard from './single_shedule_id_card';
import SingleSheduleOfClass from './single_shedule_of_class';

class SingleShedulePrint extends Component {
   state = {
      // class_sedule_obj: {}
   }
   
   render() {
      const { shedule_obj, update_student, notes } = this.props;
      // console.log(this.props)
      return (
         <div className="row-print">
            {update_student.map((item, index) => {
               return (
                  <div className="col-sm-12-print print-mark print-page-break" key={index}>
                     <div className="single-id-card-print" >
                        <SingleSheduleIdCard
                           update_student={item}
                           key_index={index}
                           school_medium={shedule_obj.school_info.sch_medium}
                           school_logo={shedule_obj.school_info.sch_logo}
                           school_name={shedule_obj.school_info.sch_name}
                           school_address={shedule_obj.school_info.sch_address}
                           exam_name={shedule_obj.exam_name}
                           session_year_id={shedule_obj.school_info.session_year_id}
                           />
                        <SingleSheduleOfClass
                           key_index={index}
                           notes={notes}
                           shedule_obj={shedule_obj}
                        />
                     </div>
                  </div>
               )
            })}
         </div >
      )
   }
}
export default withRouter(SingleShedulePrint);