import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import axios from 'axios';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddClass from './add_class';
import EditClass from './edit_class';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/classes/read.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/classes/delete.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;

class AllClass extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    ptl_classes: [],
    sft_classes: [],
    selected_classes: [],
    group_id: '',
    user_category: '',
    session_year_id: '',
    createItem: false,
    editItem: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterClassesOnSchool(_sch_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: ''
    //   })
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   sessionStorage.setItem("medium", _medium);
    //   this.setState({
    //     [fieldName]: isCheckbox ? event.target.checked : event.target.value
    //   });
    // } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    // }
  };
  // filterClassesOnSchool(sch_id) {
  //   const _classes = this.props.classes.filter((item) => {
  //     if (item.school_id === sch_id) {
  //       return item
  //     }
  //   })
  //   this.setState({
  //     selected_classes: _classes
  //   })
  // }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_classes = this.props.classes;
      if (_all_classes && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _classes = this.props.classes;
    if (!isEmpty(_classes)) {
      const _sch_classes = _classes.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        selected_classes: _sch_classes,
      })
    }
  }

  // componentWillReceiveProps(nextProps) {
  //   // if (nextProps.classes) {
  //   //   this.setState({
  //   //     selected_classes: []
  //   //   },()=>{
  //   //     // this.filterClassesOnSchool(this.state.school_id);
  //   //   })
  //   // }
  // }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           // this.getPortalClassesHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }

  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getPortalClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     user_category: this.state.user_category,
  //     school_id: this.state.school_id
  //   }
  //   console.log(JSON.stringify(obj));
  //   axios.post(GET_PTL_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         ptl_classes: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       this.setState({
  //         sft_classes: classes,
  //         selected_classes: classes,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // };
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(event, del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  deleteHandlar = (event, id) => {
    event.preventDefault();
    // debugger
    alert('work in process....');
    // axios.post(DELETE_URL + '?id=' + id)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     const _classes = this.state.sft_classes.filter((item) => {
    //       return item.id !== id
    //     })
    //     this.setState({
    //       sft_classes: _classes
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }

  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateClasses(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.classes.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }

  render() {
    const { editItem, createItem, selected_school_index, selected_classes, 
      selected_item, medium_arr, medium, formIsHalfFilledOut } = this.state;
    const { schools, classes, user } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Software Class List</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Software Class List</div>
          {user && schools && classes &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div> */}
                <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    // showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                  // filterByClsHandler={this.filterByClsHandler}
                  />
              </div>
            </div>
          }
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {createItem ? <AddClass
              toggeleCreate={this.toggeleCreate} />
              : null}
            {editItem ?
              <>
                <EditClass
                  selected_item={selected_item}
                  schools={schools}
                  classes={classes}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                <div className="backdrop edit-mode"></div>
              </>
              : null}
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th> Seq. </th>
                    <th> Software Name</th>
                    <th> Portal Name </th>
                    <th> Medium </th>
                    <th> Section </th>
                    <th> Parent Class </th>
                    <th> Subject </th>
                    <th> No. </th>
                    <th> Action </th>
                  </tr>
                </thead>
                {selected_classes.length > 0 ?
                  <tbody>
                    {selected_classes.map((item, index) => {
                      return (
                        <tr key={index}>
                          <td>
                            {index + 1 + '.'}
                          </td>
                          <td>{item.seq_number}</td>
                          <td>{item.class_name}</td>
                          <td>{item.class_name_portal}</td>
                          <td>{item.medium}</td>
                          <td>{item.is_section}</td>
                          <td>{item.is_section === 'Yes' ? item.class_name_portal : null}</td>
                          <td></td>
                          <td>{item.roll_num_start} to {item.roll_num_end}</td>
                          <td className="d-flex">
                            {/* <NavLink to={`edit_class.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit
                          </NavLink> */}
                            <button className="btn btn-primary btn-sm mr-1"
                              type="button"
                              onClick={event => this.openEdit(event, item.id)}>Edit</button>
                            <button className="btn btn-danger btn-sm"
                              value={item.id}
                              type="button"
                              onClick={event => this.confirmBoxDelete(event, item.id)}>
                              Del
                          </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                  : null}
              </table>
            </div>
          </div>
          <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">
                Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">
                Add New
            </button>
            }
          </div>
        </div>
      </div>

    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const filteredSchoolData = state.filteredSchoolData;
  return { user, schools, classes, filteredSchoolData };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  updateClasses: classesAction.update,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllClass));