import React, { Component } from 'react';
import { withRouter } from 'react-router';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import ImageLoader from "../utility/ImageLoader/index";
import { connect } from 'react-redux';
import { isEmptyObj } from '../utility/utilities';
import { defaultGalleryActions, defaultImagesActions } from '../_actions';

// const GET_IMAGES = `http://schools.rajpsp.com/api/galleries/images/read.php`; 

class FrontIndexImageGallery extends Component {
   state = {
      galleries: [],
      all_images: [],
      display_images: [],
   }
   clickHandler = (event) => {
      const _id = event.target.value;
      if (_id === 'ALL') {
         this.setState({
            display_images: JSON.parse(JSON.stringify(this.state.all_images))
         })
      } else {
         this.activeOneGallery(_id);
      }
   };
   // filter current gallery images
   activeOneGallery(id) {
      const _gallery = this.state.all_images.filter((item, inx) => {
         if (item.gallery_id === id) {
            return item
         }
      })
      this.setState({
         display_images: _gallery
      })
   }
   componentDidMount() {
      if (isEmptyObj(this.props.gallery)) {
         this.props.getDefaultGallery();
      }
      if (isEmptyObj(this.props.galleryImages)) {
         this.props.getDefaultImages();
      }
 
      /*const _first_id = this.props.gallery[0].id;
      this.loadImagesHandler(_first_id)
*/
      // loadProgressBar();
      // axios.get(GET_GALLERIES)
      //    .then(res => {
      //       const getRes = res.data;
      //       this.setState({
      //          galleries: getRes,
      //          errorMessages: getRes.message
      //       }, () => {
      //          const _first_id = getRes[0].id;
      //          this.loadImagesHandler(_first_id);
      //       });
      //       //console.log(this.state.galleries);
      //    }).catch((error) => {
      //       // error
      //    })
   };
   // loadImagesHandler(first_id) {
   //    loadProgressBar();
   //    axios.get(GET_IMAGES)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             all_images: getRes,
   //             errorMessages: getRes.message
   //          }, () => {
   //             this.activeOneGallery(first_id);
   //          });
   //          //console.log(this.state.all_images);
   //       }).catch((error) => {
   //          // error
   //       })
   // };

   render() {
      const { galleryImages, gallery } = this.props;
      //console.log(this.state);
      return (
         <section className="gallery_sec sec_panel bg-info text-white">
            <div className="sec_inner">
               <div className="container">
                  {gallery &&
                     <div>
                        <div className="section_header event_header">
                           <h2>Image Gallery</h2>
                        </div>
                        <div>
                           <button className="btn btn-warning mr-1"
                              value="ALL"
                              onClick={event => this.clickHandler(event)}
                           >All</button>
                           {gallery.map((item, index) => {
                              return (
                                 <button
                                    key={index}
                                    value={item.id}
                                    onClick={event => this.clickHandler(event)}
                                    className="btn btn-warning mr-1">{item.title}</button>
                              )
                           })}
                        </div>
                     </div>
                  }
                  {galleryImages &&
                     <div className="row mt-3">
                        {galleryImages.map((item, index) => {
                           return (
                              <div key={index} className="col-sm-6 col-md-4 col-lg-3  mb-3">
                                 <div className="card">
                                    <div className="card-body p-0 h-auto card-image">
                                       <ImageLoader
                                          src={`${process.env.PUBLIC_URL}` + item.img_link}
                                          fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/no-image.png`}
                                       />
                                       <p className="card-text card-image-title p-2 text-white">{item.img_title}</p>
                                    </div>
                                 </div>
                              </div>
                           )
                        })}
                     </div>
                  }
               </div>
            </div>
         </section>
      )
   }
}

function mapStateToProps(state) {
   const { item: gallery } = state.defaultGallery;
   const { item: galleryImages } = state.defaultImages;
   return { gallery, galleryImages };
}

const actionCreators = {
   getDefaultGallery: defaultGalleryActions.getDefaultGallery,
   getDefaultImages: defaultImagesActions.getDefaultImages,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FrontIndexImageGallery));
