import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
// import ReactYoutubePlayer from "../utility/youtubePlayer";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, monthlyLessonAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_ALL_LESSONS = `http://schools.rajpsp.com/api/lessons/read.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/lessons/delete.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_URL = `http://schools.rajpsp.com/api/subject/read.php`;

class AllLesson extends Component {
  state = {
    les_months_arr: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    lessons_date_arr: [],
    lessons: [],
    // selected_lessons: [],
    medium: '',
    sft_classes: [],
    class_subject_arr: [],
    selected_class: '',
    selected_month: '',
    selected_les_date: '',
    selected_classes: [],
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_id: ''
    //   })
    // }
    // else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   sessionStorage.setItem("medium", _medium);
    // }
    // else 
    if (fieldName === 'selected_les_date') {
      const _less_date = event.target.value;
      if (!isEmpty(_less_date)) {
        this.setState({
          selected_les_date: _less_date,
        }, () => {
          this.filterLessonOnDate();
        })
      } else {
        this.setState({
          selected_lessons: this.state.all_lessons
        })
      }
    } else if (fieldName === 'selected_month') {
      const _select_month = parseInt(event.target.value) + 1;
      this.setState({
        selected_month: _select_month,
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  filterLessonOnDate() {
    const crnt_date = this.state.selected_les_date;
    const filteredLesson = this.state.all_lessons.filter((item) => {
      if (item.les_date === crnt_date) {
        return item;
      }
    })
    this.setState({
      selected_lessons: filteredLesson
    })
  }

  // filterClassesOnSchool(sch_id, group_id) {
  //   const _classes = this.props.classes.filter((item) => {
  //     if (item.group_id === group_id && item.school_id === sch_id) {
  //       return item
  //     }
  //   })
  //   this.setState({
  //     selected_classes: _classes,
  //     //selected_subjects: ''
  //   })
  // }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.monthlyLesson)) {
      this.props.getMonthlyLesson();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_monthlyLesson = this.props.monthlyLesson;
      const _all_classes = this.props.classes;
      if (_all_monthlyLesson && _filter && _all_classes) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    // debugger
    // const _filter = this.props.filteredSchoolData;
    const _all_monthlyLesson = this.props.monthlyLesson;
    if (!isEmpty(_all_monthlyLesson)) {
      this.filterByClsHandler()
    }
  }

  filterByClsHandler = () => {
    // const _fltr_school = this.props.filteredSchoolData;
    // const _fltr_class = this.props.filteredClassesData;
    const _all_monthlyLesson = this.props.monthlyLesson;
    if (_all_monthlyLesson) {
      this.setMonthlyLessonData(this.props.monthlyLesson)
    }
  }


  componentWillReceiveProps(nextProps) {
    // console.log(this.props); // prevProps
    // console.log(nextProps); // currentProps after updating the store
    if (nextProps.monthlyLesson) {
      const resData = nextProps.monthlyLesson;
      // console.log(resData.monthly_lesson)
      this.setMonthlyLessonData(resData)
    }
  }

  setMonthlyLessonData(resData) {
    const _all_lesson = resData.lesson_info;
    const _fltr_class = this.props.filteredClassesData;
    let _class_lession = [];

    if (_all_lesson && _fltr_class) {
      _class_lession = _all_lesson.filter((item) => {
        if (item.class_id === _fltr_class.slct_cls_id) {
          return item
        }
      })
    }
    this.setState({
      all_lessons: (resData.lesson_info) ? resData.lesson_info : [],
      selected_lessons: (_class_lession) ? _class_lession : [],
      lessons_date_arr: (resData.lesson_date) ? resData.lesson_date : [],
      class_subject_arr: (resData.class_subjects) ? resData.class_subjects : [],
    });
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getSubjectsHandler() {
  //   loadProgressBar();
  //   axios.get(READ_URL)
  //     .then(res => {
  //       const subjects = res.data;
  //       this.setState({
  //         subjects: subjects,
  //         errorMessages: subjects.message
  //       });
  //       //console.log(this.state.subjects);

  //     }).catch((error) => {
  //       // error
  //     })
  // };
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_URL, obj)
  //     .then(res => {
  //       const classes = res.data;
  //       if (this.state.user_category === "1") {
  //         this.setState({
  //           sft_classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       } else {
  //         this.setState({
  //           sft_classes: classes,
  //           selected_classes: classes,
  //           errorMessages: res.data.message
  //         });
  //       }
  //       //console.log(this.state.classes);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // };

  getLessonHandler() {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const obj = {
      class_id: _fltr_class.slct_cls_id,
      medium: _fltr_school.slct_medium,
      les_month: this.state.selected_month
    }

    console.log(JSON.stringify(obj));
    // debugger;
    this.props.getMonthlyLesson(obj);

    // debugger
    // loadProgressBar();
    // axios.post(GET_ALL_LESSONS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     if (getRes.resLessonData) {
    //       this.setState({
    //         lessons: getRes.resLessonData,
    //         selected_lessons: getRes.resLessonData,
    //         lessons_date_arr: getRes.resDateLesson,
    //         class_subject_arr: getRes.resClassSubject,
    //       });
    //     } else {
    //       this.setState({
    //         lessons: [],
    //         selected_lessons: [],
    //         lessons_date_arr: [],
    //       });

    //       Alert.error(getRes.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //     }
    //     ////console.log(this.state.classes);
    //   }).catch((error) => {
    //     // error
    //   })
  }
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(event, del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  deleteHandlar = (event, id) => {
    event.preventDefault();
    const _id = id;
    this.props.deleteMonthlyLesson({ id: _id });
    // axios.post(DELETE_URL + '?id=' + _id)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     const _lesson = this.state.selected_lessons.filter((item, index) => {
    //       return item.id !== _id
    //     })
    //     this.setState({
    //       selected_lessons: _lesson
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  getVideoIdByLink(link) {
    let videoId = "";
    videoId = (link).split('watch?v=', 2);
    return videoId[1];
  }
  getSubjectNameByid(_id) {
    const all_subjects = this.state.class_subject_arr;
    const crrent_sub = all_subjects.filter((item) => {
      if (item.id === _id) {
        return item;
      }
    });
    //const subject = crrent_sub[0].sub_name;
    return (!isEmptyObj(crrent_sub[0])) ? crrent_sub[0].sub_name : 'SUBJECT NAME ERROR';
  }

  render() {
    const { selected_month, lessons_date_arr, selected_lessons, les_months_arr, selected_les_date, formIsHalfFilledOut } = this.state;
    const { user, schools, classes, monthlyLesson } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Lessons</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">All Lessons</div>
          {user && schools && classes && monthlyLesson &&

            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Class : </label>
                  <select
                    // disabled={medium === '' ? true : false}
                    value={selected_class}
                    className="form-control form-control-sm " name="selected_class"
                    onChange={event => this.changeHandler(event, 'selected_class')}>
                    <option value="All">Select...</option>
                    {selected_classes.map((option, index) => {
                      return (<option key={index} value={option.id}>{option.class_name}</option>)
                    })}
                  </select>
                </div> */}

                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />

                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Month : </label>
                  <select
                    // disabled={medium === '' ? true : false}
                    value={selected_month - 1}
                    className="form-control form-control-sm " name="selected_month"
                    onChange={event => this.changeHandler(event, 'selected_month')}>
                    <option value="All">Select...</option>
                    {les_months_arr.map((option, index) => {
                      return (<option key={index} value={index}>{les_months_arr[index]}</option>)
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <button type="button"
                    onClick={event => this.getLessonHandler(event)}
                    className="btn btn-primary btn-sm mr-2">Go</button>
                </div>
                <div className="form-group mt-1">
                  <label className="control-label mr-2">Date : </label>
                  <select
                    // disabled={medium === '' ? true : false}
                    value={selected_les_date}
                    className="form-control form-control-sm " name="selected_les_date"
                    onChange={event => this.changeHandler(event, 'selected_les_date')}>
                    <option value="">Select...</option>
                    {lessons_date_arr.map((option, index) => {
                      return (<option key={index} value={option.les_date}>{option.les_date}</option>)
                    })}
                  </select>
                </div>
              </div>
            </div>
          }
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">

            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr>
                    <th />
                    <th>Lesson</th>
                    <th>Date</th>
                    <th>Subject</th>
                    <th>Title and Remark</th>
                    <th>Action</th>
                  </tr>
                </thead>
                {selected_lessons &&
                  <tbody>
                    {selected_lessons.map((item, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}</td>
                          <td>
                            <img src={`https://img.youtube.com/vi/${item.les_link}/default.jpg`} /></td>
                          <td width="200">
                            <strong>{item.les_date}</strong>
                            {/* <NavLink to={item.les_link} target="_self" className="btn btn-danger btn-sm mr-1">
                              <span className="la la-youtube mr-2"></span>
                              Video Link</NavLink> */}
                          </td>
                          <td>{this.getSubjectNameByid(item.les_sub_id)}</td>
                          <td>
                            <strong>{item.id}. {item.les_title}</strong>
                            <br />
                            {item.les_remark}
                          </td>
                          <td className="d-flex">
                            <NavLink to={`/lesson_faqs_reply.jsp/${item.id}`} className="btn btn-warning btn-sm mr-1">
                              Reply</NavLink>
                            <NavLink to={`/edit_lesson.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit</NavLink>
                            <button
                              type="button"
                              className="btn btn-danger btn-sm"
                              value={item.id}
                              onClick={event => this.confirmBoxDelete(event, item.id)}>
                              Del</button>
                          </td>
                        </tr>
                      )
                    })
                    }
                  </tbody>
                }
              </table>
            </div>
          </div>
          <div className="card-footer d-flex">
            <NavLink to="/add_lesson.jsp" className="btn btn-primary btn-sm">New Lesson</NavLink>
            <button type="submit"
              // disabled={ground_total > 0 ? false : true}
              className="btn btn-primary btn-sm mr-2 ml-auto">Submit</button>
            <NavLink to="/fees_collection.jsp" className="btn btn-danger  btn-sm">Cancel</NavLink>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: monthlyLesson } = state.monthlyLesson;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, classes, monthlyLesson,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getMonthlyLesson: monthlyLessonAction.getMonthlyLesson,
  deleteMonthlyLesson: monthlyLessonAction.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllLesson));