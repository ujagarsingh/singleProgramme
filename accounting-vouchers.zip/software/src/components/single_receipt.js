import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class SingleReceipt extends Component {
   state = {
      classes: [],
      final_deposit_fee_arr: [],
      id: "",
      sch_name: "",
      sch_reg_no: "",
      sch_recog_no: "",
      sch_contact_num: "",
      sch_mobile_num: "",
      sch_email: "",
      sch_address: "",
      sch_medium: "",
      sch_logo: "",
      sch_wel_mes_title: "",
      sch_wel_mes: '',
      formIsHalfFilledOut: false,
   }
   componentDidMount() {
      loadProgressBar();
      axios.get(GET_FEE_DEPOSIT)
         .then(res => {
            const deposited_arr = res.data;
            this.setState({
               final_deposit_fee_arr: deposited_arr,
               errorMessages: res.data.message
            });
            //console.log(this.state.final_deposit_fee_arr);
         }).catch((error) => {
            // error
         })

      axios.get(READ_URL)
         .then(res => {
            const getRes = res.data;
            this.setState({
               id: getRes.id,
               sch_name: getRes.sch_name,
               sch_reg_no: getRes.sch_reg_no,
               sch_recog_no: getRes.sch_recog_no,
               sch_contact_num: getRes.sch_contact_num,
               sch_mobile_num: getRes.sch_mobile_num,
               sch_email: getRes.sch_email,
               sch_address: getRes.sch_address,
               sch_medium: getRes.sch_medium,
               sch_logo: getRes.sch_logo,
               sch_wel_mes_title: getRes.sch_wel_mes_title,
               sch_wel_mes: getRes.sch_wel_mes,
               errorMessages: getRes.message
            });
         }).catch((error) => {
            // error
         })
   };
   printThisReceipt = () => {
      // window.print();
   }
   render() {
      const _state = this.state;
      //console.log(_state)
      return (
         <div className="page-content">
            <Helmet>
               <title>Single Receipt</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div className="col-sm-5">

               <h4 className="pb-2">
                  <span className="">#{invoice.id}</span>
                  <span className="pull-right"><i className="fa fa-calendar" /> {invoice.deposit_date}</span>
               </h4>
               <hr className="mb-2 mt-2" />
               <div className="row">
                  <div className="col-md-12">
                     <div className="text-center">
                        <address className="school_address">
                           <h3 className="m-0 p-0">
                              <b>{_state.sch_name}</b>
                           </h3>
                           <p className="text-muted">{_state.sch_address}</p>
                        </address>
                     </div>
                     <address>
                        <p className=""><span className="text-muted">To,</span> <b>{invoice.student_name}</b> <span className="text-muted">{invoice.address}</span> #<span>Class : {invoice.student_class}</span>
                        </p>
                        <hr className="m-0 p-0" />
                     </address>
                  </div>
                  <div className="col-md-12">
                     <div className="table-responsive m-t-40">
                        <table className="table table-hover table-bordered table-sm">
                           <thead>
                              <tr className="table-secondary">
                                 <th className="text-center">#</th>
                                 <th className="text-right">Invoice id</th>
                                 <th className="text-right">Fees Type</th>
                                 <th className="text-right">Month of fee</th>
                                 <th className="text-right">Amount</th>
                              </tr>
                           </thead>
                           <tbody>
                              {invoice.xsd.map((in_detail, index) => {
                                 return (
                                    <tr key={index}>
                                       <td className="text-center">{index + 1}</td>
                                       <td className="text-right">{in_detail.id}</td>
                                       <td className="text-right">{in_detail.fee_title}</td>
                                       <td className="text-right">{in_detail.month_of_fee}</td>
                                       <td className="text-right">{in_detail.fee_amount}</td>
                                    </tr>
                                 )
                              })}
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div className="col-md-12">
                     <h4 className="p-0 text-right"><b>Total :</b> {invoice.total_amount}</h4>
                     <hr className="d-flex" />
                  </div>
               </div>
            </div>
         </div >
      )
   }
}
export default withRouter(SingleReceipt);