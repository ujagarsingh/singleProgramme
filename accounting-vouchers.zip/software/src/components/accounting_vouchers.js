import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction, accManagerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class AccountingVouchers extends Component {
	state = {
		formIsHalfFilledOut: false,
		acc_data : {}
	}

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
			this.props.getAccLedgerEntry();
		}

		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}

		if (isEmptyObj(this.props.accGroup)) {
			this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		// this.checkFlag();
		this.showVoucherHander();
	}
	showVoucherHander = () => {
		const { match } = this.props;
		const _av_id = match.params.id;
		const _accLedgerEntry = this.props.accLedgerEntry;
		const _all_ledgers = this.props.all_ledgers;
		this.props.getVoucherEntryHandler({ "vchrid": _av_id, "ldr_data": _accLedgerEntry, "all_ledgers": _all_ledgers });
	}
	creditZoneHandler = (vchr_detail) => {
		//debugger
		const cr_detail = vchr_detail.credit;
		const _cr_detail = cr_detail.map((item, inx) => {
			return (
				<div className="av-detail-head" key={inx}>
					<div className="main-head">
						<div className="head-name"><span className="txt-normal">Dr </span> {item.ledger_name} </div>
						<div className="head-amount">
							<div className="dr-total"></div>
							<div className="cr-total">{item.tr_amount}.00</div>
						</div>
					</div>
					<div className="crnt-balance-head">
						<div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Dr</div>
					</div>
				</div>
			)
		})
		return _cr_detail;
	}
	debitZoneHandler = (vchr_detail) => {
		//debugger
		const dr_detail = vchr_detail.debit;
		return (
			<div className="av-detail-head">
				<div className="main-head">
					<div className="head-name"><span className="txt-normal">Cr </span> {dr_detail.ledger_name} </div>
					<div className="head-amount">
						<div className="dr-total">{dr_detail.tr_amount}.00</div>
						<div className="cr-total"></div>
					</div>
				</div>
				<div className="crnt-balance-head">
					<div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Cr</div>
				</div>
			</div>
		)
	}
	narrationHandler = (single_voucer) => {
		const sv = single_voucer;
		return (
			<div className="acc-page-footer av-page-footer container-fluid">
				<div className="sec-foot">
					<div className="narration-zone">
						<div className="title">Narration:</div>
						<textarea className="form-control" defaultValue={sv.narration}>

						</textarea>
					</div>
					<div className="amount-zone">
						<div className="dr-total">{sv.total_amo}.00</div>
						<div className="cr-total">{sv.total_amo}.00</div>
					</div>
				</div>
			</div>
		)
	}
	render() {
		const { single_voucer } = this.props;
		console.log(single_voucer);
		return (
			<div className="page-content">
				<Helmet>
					<title>Accounting Voucher</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Accounting Voucher</div>
				</div>
				{single_voucer &&
					<div className="card card-box sfpage-cover">
						<div className="card-body p-1 sfpage-body">
							<div className="acc-page page-accounting-vouchers">
								<div className="acc-page-head container-fluid">
									<div className="sec-title">
										<div className="title-zone">Particulars</div>
										<div className="info-zone">
											<div className="info-zone">
												<table className="table table-bordered table-sm">
													<tbody>
														<tr>
															<td>
																<div className="dr-title">Debit</div>
															</td>
															<td>
																<div className="cr-title">Credit</div>
															</td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<div className="acc-page-body container-fluid">
									{(single_voucer.vchr_type === "Journal") ?
										<div className="av-detail-zone">
											{this.debitZoneHandler(single_voucer)}
											{this.creditZoneHandler(single_voucer)}
										</div>
										:
										<div className="av-detail-zone">
											{this.creditZoneHandler(single_voucer)}
											{this.debitZoneHandler(single_voucer)}
										</div>
									}
								</div>
								{this.narrationHandler(single_voucer)}

							</div>
						</div>
					</div>
				}
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	const { all_ledgers } = state.accManager.item;
	const { single_voucer } = state.accManager.item;
	return {
		user, students, accLedger, accGroup, accLedgerEntry, single_voucer, all_ledgers,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
	getVoucherEntryHandler: accManagerActions.getVoucherEntryHandler,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AccountingVouchers));