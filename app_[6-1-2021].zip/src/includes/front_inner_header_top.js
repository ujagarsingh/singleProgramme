import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
//import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

import FrontInnerSlider from './front_inner_slider.js'

const READ_URL = `http://schools.rajpsp.com/api/group/read_one.php?id=1`;

class FrontInnerHeaderTop extends Component {
  state = {
    //id: "",
    user_name: "",
    //reg_no: "",
    mobile: "",
    email: "",
    //address: "",
    //logo: "",
    //wel_mes_title: "",
    //wel_mes: "",
  }
  componentDidMount() {
    loadProgressBar();
    axios.get(READ_URL)
      .then(res => {
        const getRes = res.data;
        this.setState({
          //id: getRes.id,
          user_name: getRes.user_name,
          //reg_no: getRes.reg_no,
          mobile: getRes.mobile,
          email: getRes.email,
          //address: getRes.address,
          //logo: getRes.logo,
          //wel_mes_title: getRes.wel_mes_title,
          //wel_mes: getRes.wel_mes
        });
      }).catch((error) => {
        // error
      })
  };

  render() {
    const { user_name, mobile, email } = this.state;
    //console.log(_state);
    return (
      <React.Fragment>
        <div className="header-top">
          <div className="container">
            <div className="row">
              <div className="col-sm-6 col-xs-12 header-top-left">
                <ul className="list-unstyled">
                  <li><i className="fa fa-phone top-icon" /> {mobile}</li>
                  <li><i className="fa fa-envelope top-icon" /> {email}</li>
                </ul>
              </div>
              <div className="col-sm-6 col-xs-12 header-top-right">
                <ul className="list-unstyled">
                  {/*<li><NavLink to="register.html"><i className="fa fa-user-plus top-icon" /> Sing up</NavLink></li>*/}
                  <li><NavLink to="login"><i className="fa fa-lock top-icon" />Login</NavLink></li>
                </ul>
              </div>
            </div>
          </div>
        </div>{/* Ends: .header-top */}
        <div className="header-body">
          <nav className="navbar edu-navbar">
            <div className="container">
              <div className="navbar-header">
                <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                  <span className="sr-only">Toggle navigation</span>
                  <span className="icon-bar" />
                  <span className="icon-bar" />
                  <span className="icon-bar" />
                </button>
                <NavLink to="Home" className="navbar-brand  data-sc">
                  <img alt="SmartPSP" src="/assets/images/logo.png" />
                  <span>{user_name}</span></NavLink>
              </div>
              <div className="collapse navbar-collapse edu-nav main-menu" id="bs-example-navbar-collapse-1">
                <ul className="nav navbar-nav pull-right">
                  <li><NavLink data-sc to="Contact">Contact</NavLink></li>
                </ul>
              </div>{/* /.navbar-collapse */}
            </div>{/* /.container */}
          </nav>
          <FrontInnerSlider />
        </div>
      </React.Fragment>
    )
  }
}
export default FrontInnerHeaderTop;