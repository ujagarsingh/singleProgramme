import { examSdulNotesConstants } from '../_constants';

export function examSdulNotes(state = {}, action) {
  switch (action.type) {
    case examSdulNotesConstants.EXAM_SDUL_NOTES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examSdulNotesConstants.EXAM_SDUL_NOTES_SUCCESS:
      return {
        item: action.response
      };
    case examSdulNotesConstants.EXAM_SDUL_NOTES_FAILURE:
      return {
        error: action.error
      };




    case examSdulNotesConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examSdulNotesConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case examSdulNotesConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case examSdulNotesConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examSdulNotesConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case examSdulNotesConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case examSdulNotesConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case examSdulNotesConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case examSdulNotesConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };


    default:
      return state
  }
}