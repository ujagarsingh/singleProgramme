import { accEntryRefConstants } from '../_constants';

export function accEntryRef(state = {}, action) {
  switch (action.type) {
    case accEntryRefConstants.READ_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefConstants.READ_ENTRY_REF_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accEntryRefConstants.READ_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };



    case accEntryRefConstants.UPDATE_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefConstants.UPDATE_ENTRY_REF_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accEntryRefConstants.UPDATE_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };


    case accEntryRefConstants.DELETE_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefConstants.DELETE_ENTRY_REF_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accEntryRefConstants.DELETE_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}