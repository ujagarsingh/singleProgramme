import { categoryWithFeeConstants } from '../_constants';

export function categoryWithFee(state = {}, action) {
  switch (action.type) {
    case categoryWithFeeConstants.CATEGORY_WITH_FEE_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case categoryWithFeeConstants.CATEGORY_WITH_FEE_SUCCESS:
      return {
        item: action.response
      };
    case categoryWithFeeConstants.CATEGORY_WITH_FEE_FAILURE:
      return {
        error: action.error
      };


    default:
      return state
  }
}