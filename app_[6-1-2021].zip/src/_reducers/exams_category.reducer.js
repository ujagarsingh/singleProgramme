import { examsCategoryConstants } from '../_constants';

export function examsCategory(state = {}, action) {
  switch (action.type) {
    case examsCategoryConstants.EXAMS_CATEGORY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case examsCategoryConstants.EXAMS_CATEGORY_SUCCESS:
      return {
        item: action.response
      };
    case examsCategoryConstants.EXAMS_CATEGORY_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}