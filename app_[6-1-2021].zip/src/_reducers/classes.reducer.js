import { classesConstants } from '../_constants';

export function classes(state = {}, action) {
  switch (action.type) {
    case classesConstants.CLASSES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classesConstants.CLASSES_SUCCESS:
      return {
        item: action.response
      };
    case classesConstants.CLASSES_FAILURE:
      return {
        error: action.error
      };



    case classesConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case classesConstants.CREATE_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case classesConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    case classesConstants.UPDATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case classesConstants.UPDATE_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case classesConstants.UPDATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    default:
      return state
  }
}