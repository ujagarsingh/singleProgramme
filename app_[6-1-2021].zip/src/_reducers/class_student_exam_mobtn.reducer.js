import { classStudentExamMObtnConstants } from '../_constants';

export function classStudentExamMobtn(state = {}, action) {
  switch (action.type) {
    case classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_SUCCESS:
      return {
        item: action.response
      };
    case classStudentExamMObtnConstants.CLASS_STUDENT_EXAM_MOBTN_FAILURE:
      return {
        error: action.error
      };
      
    default:
      return state
  }
}