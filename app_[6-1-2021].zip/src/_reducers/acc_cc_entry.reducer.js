import { accCCEntryConstants } from '../_constants';

export function accCCEntry(state = {}, action) {
  switch (action.type) {
    case accCCEntryConstants.ACC_CC_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accCCEntryConstants.ACC_CC_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accCCEntryConstants.ACC_CC_FAILURE:
      return {
        error: action.error
      };
   
    case accCCEntryConstants.ACC_CC_BYFOLIO_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accCCEntryConstants.ACC_CC_BYFOLIO_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accCCEntryConstants.ACC_CC_BYFOLIO_FAILURE:
      return {
        error: action.error
      };
   

    default:
      return state
  }
}