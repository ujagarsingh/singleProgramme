import { frontImagesConstants } from '../_constants';

export function frontImages(state = {}, action) {
  switch (action.type) {
    case frontImagesConstants.IMAGES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case frontImagesConstants.IMAGES_SUCCESS:
      return {
        loading: false,
        item: action.response
      };
    case frontImagesConstants.IMAGES_FAILURE:
      return {
        error: action.error
      };



    case frontImagesConstants.CREATE_IMAGES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontImagesConstants.CREATE_IMAGES_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case frontImagesConstants.CREATE_IMAGES_FAILURE:
      return {
        error: action.error
      };



    case frontImagesConstants.UPDATE_IMAGES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontImagesConstants.UPDATE_IMAGES_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case frontImagesConstants.UPDATE_IMAGES_FAILURE:
      return {
        error: action.error
      };



    case frontImagesConstants.DELETE_IMAGES_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case frontImagesConstants.DELETE_IMAGES_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case frontImagesConstants.DELETE_IMAGES_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}