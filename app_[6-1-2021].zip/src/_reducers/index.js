import { combineReducers } from 'redux';
import { authentication } from './authentication.reducer';
import { defaultArticle } from './default_article.reducer';
import { defaultProfessional } from './default_professional.reducer';
import { defaultGallery } from './default_gallery.reducer';
import { defaultImages } from './default_images.reducer';
import { defaultEvents } from './default_events.reducer';
import { defaultSlider } from './default_slider.reducer';
import { defaultGroup } from './default_group.reducer';
import { defaultSchool } from './default_school.reducer';
import { user } from './user.reducer';
import { group } from './group.reducer';
import { schools } from './schools.reducer';
import { dashCounter } from './dashCounter.reducer';
import { holiday } from './holiday.reducer';
import { classes } from './classes.reducer';
import { conveyance } from './conveyance.reducer';
import { students } from './students.reducer';
import { professional } from './professional.reducer';
import { feeDetailed } from './fee_detailed.reducer';
import { feeWithCategory } from './fee_with_category.reducer';
import { categoryWithFee } from './category_with_fee.reducer';
import { feeDepositedAll } from './fee_deposit_all.reducer';
import { feeDepositedCurrentStudent } from './fee_deposited_current_student.reducer';
import { paymentReceiver } from './payment_receivers.reducer';
import { incomeProvider } from './income_provider.reducer';
import { classExamSubject } from './class_exam_subject.reducer';
import { classStudentExamMobtn } from './class_student_exam_mobtn.reducer';
import { subjects } from './subjects.reducer';
import { exams } from './exams.reducer';
import { maxMarks } from './max_marks.reducer';
import { marksObtain } from './marks_obtain.reducer';
import { classStudentExamDetail } from './class_student_exam_detail.reducer';
import { examsType } from './exams_type.reducer';
import { examCategoryClassExam } from './exam_category_class_exam.reducer';
import { marksOfaClass } from './marks_of_aclass.reducer';
import { examsCategory } from './exams_category.reducer';
import { examSdulNotes } from './exam_sdul_notes.reducer';
import { examSdul } from './exam_sdul.reducer';
import { frontSlider } from './front_slider.reducer';
import { frontArticle } from './front_article.reducer';
import { frontGallery } from './front_gallery.reducer';
import { frontImages } from './front_images.reducer';
import { feeCategory } from './fee_category.reducer';
import { feeCategoryStructure } from './fee_category_structure.reducer';
import { feeStructure } from './fee_structure.reducer';
import { events } from './events.reducer';
import { monthlyLesson } from './monthly_lesson.reducer';
import { sessionYears } from './session_years.reducer';
import { portalClasses } from './portal_classes.reducer';
import { classWiseSubDetailsForShedule } from './classWise_subDetail_forSdul.reducer';
import { classWiseSubDetailsForAssign } from './classWise_subDetail_forAssign.reducer';
import { reducer as toastrReducer } from 'react-redux-toastr';
import { filteredSchoolData } from './filter_schools.reducer';
import { filteredClassesData } from './filter_classes.reducer';
import { singleClassCategoryExams } from './single_class_category_exams.reducer';
import { singleStudentSubjectExamsMarksobtn } from './single_student_subject_exams_marksobtn.reducer';
import { accGroup } from './acc_group.reducer';
import { accLedger } from './acc_ledger.reducer';
import { accVoucherEntry } from './acc_voucher_entry.reducer';
import { accGroupEntry } from './acc_group_entry.reducer';
import { accLedgerEntry } from './acc_ledger_entry.reducer';
import { accCCEntry } from './acc_cc_entry.reducer';
import { accManager } from './acc_manager.reducer';
import { accEntryRef } from './acc_entry_ref.reducer';
import { accountManager } from './account_manager.reducer';

const appReducer = combineReducers({
  accountManager,
  accEntryRef,
  accManager,
  accGroupEntry,
  accLedgerEntry,
  accCCEntry,
  accVoucherEntry,
  accGroup,
  accLedger,
  singleStudentSubjectExamsMarksobtn,
  singleClassCategoryExams,
  filteredClassesData,
  filteredSchoolData,
  toastr: toastrReducer,
  classWiseSubDetailsForAssign,
  classWiseSubDetailsForShedule,
  portalClasses,
  sessionYears,
  monthlyLesson,
  events,
  feeStructure,
  feeCategoryStructure,
  feeCategory,
  frontImages,
  frontGallery,
  frontArticle,
  frontSlider,
  examSdul,
  examSdulNotes,
  examsCategory,
  marksOfaClass,
  examCategoryClassExam,
  examsType,
  classStudentExamDetail,
  marksObtain,
  maxMarks,
  exams,
  subjects,
  classStudentExamMobtn,
  classExamSubject,
  incomeProvider,
  paymentReceiver,
  feeDepositedAll,
  feeDepositedCurrentStudent,
  categoryWithFee,
  feeWithCategory,
  feeDetailed,
  professional,
  students,
  conveyance,
  classes,
  authentication,
  user,
  group,
  defaultGroup,
  schools,
  defaultSchool,
  dashCounter,
  holiday,
  defaultArticle,
  defaultProfessional,
  defaultGallery,
  defaultImages,
  defaultEvents,
  defaultSlider
});

const rootReducer = (state, action) => {
  if (action.type === 'USERS_LOGOUT') {
    state = undefined
  }

  return appReducer(state, action)
}

export default rootReducer;
