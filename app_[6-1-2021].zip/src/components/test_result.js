import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class TestPaper extends Component {
	state = {
		selected_school_index: "",
	}
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	componentDidMount() {
		const token = sessionStorage.getItem('jwt');
		const obj = { "jwt": token };
		this.checkAuthentication(obj);
	}
	checkAuthentication(obj) {
		loadProgressBar();
		axios.post(VALIDATE_URL, obj)
			.then(res => {
				const getRes = res.data;
				// sessionStorage.setItem("user", getRes.data);
				console.log(getRes);
				if (getRes.data) {
					this.setState({
						user: getRes.data,
						group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
						school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
						user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
						session_year: (getRes.data.session_year) ? getRes.data.session_year : "",
					}, () => {
						// this.getSchoolHandler();
						// this.getExamsCategories();
						// this.getSheduleNotes();
					})
				}
			}).catch((error) => {
				this.props.history.push('/login.jsp');
			})
	}

	getSchoolHandler() {
		loadProgressBar();
		const obj = {
			group_id: this.state.group_id
		}
		axios.post(READ_SCHOOLS, obj)
			.then(res => {
				const getRes = res.data;
				this.setState({
					schools_arr: getRes,
					errorMessages: getRes.message
				});
				// console.log(this.state);
			}).catch((error) => {
				// error
			})
	}

	showInstruction(event) {
		event.preventDefault();

	}
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}

	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (
			<div className="page-content">
				<Helmet>
					<title>Test Result</title>
				</Helmet>
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				{user &&
					<>
						<div className="page-bar d-flex">
							<div className="page-title">All E-Test</div>
							<div className="form-inline ml-auto filter-panel">
								<span className="filter-closer">
									<button type="button" className="btn btn-danger filter-toggler-c">
										<i className="fa fa-times"></i>
									</button>
								</span>
								<div className="filter-con">
									<div className="filter-con">
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-warning btn-sm">Download Report <i className="fa fa-plus" /></NavLink>
										</div>
										<div className="form-group ml-2">
											<NavLink to="/test_attempt.jsp"
												className="btn btn-primary btn-sm">View Solutions <i className="fa fa-plus" /></NavLink>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="card card-box sfpage-cover">
							<div className="card-body sfpage-body">
								<div className="table-scrollable">
									<img className="thumbnail"
										alt="Test Result"
										src={`${process.env.PUBLIC_URL}/assets/images/dummy_rudult.png`} />
								</div>
							</div>
						</div>
					</>
				}
			</div>
		)
	}
}
export default withRouter(TestPaper);