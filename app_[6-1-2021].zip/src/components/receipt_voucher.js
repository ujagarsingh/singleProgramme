import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
// import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  accLedgerActions, classesAction, professionalAction,
  accGroupActions, accLedgerEntryActions, studentsAction, accManagerActions
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// import CommonFilters from '../utility/Filter/filter-schools';

class ReceiptVoucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    single_voucer: {}
  }

  componentDidMount() {
    if (isEmptyObj(this.props.accLedgerEntry)) {
      this.props.getAccLedgerEntry();
    }

    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }

    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }

    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }

    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      const _accGroup = this.props.accGroup;
      const _all_professional = this.props.professional;
      const _accLedgerEntry = this.props.accLedgerEntry;
      if (_all_student && _all_professional && _filter && _accGroup && _accLedgerEntry) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    // const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      // const _school_student = _all_student.filter((item) => {
      //   if (_filter.slct_school_id) {
      //     if (item.school_id === _filter.slct_school_id) {
      //       return item
      //     }
      //   } else {
      //     return item
      //   }
      // })
      this.setState({
        // display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    const _all_professional = this.props.professional;
    const _all_groups = this.props.accGroup;
    const _all_ledger = this.props.accLedger;
    const _all_accLedgerEntry = this.props.accLedgerEntry;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      if (_school_student.length > 0) {
        this.props.getACCManager({
          acc_group: _all_groups,
          acc_ledgers: _all_ledger,
          acc_entries: _all_accLedgerEntry,
          students: _all_student,
          professional: _all_professional,
        })
      }
    }
  }
  effectedLedgerHandler = (ldr_arr) => {
    const _all_ledger = this.props.all_ledgers;
    let efctd_cr_ldr = [];
    let efctd_dr_ldr = [];
    ldr_arr.forEach(el => {
      efctd_cr_ldr.push(..._all_ledger.filter(e => Number(e.under_group) === el))
    })
      efctd_dr_ldr.push(..._all_ledger.filter(e => Number(e.under_group) === 2))

    this.setState({
      effected_cr_ldr: efctd_cr_ldr,
      effected_dr_ldr: efctd_dr_ldr,
    })
  }
  render() {
    const { user, students, professional, schools } = this.props;
    const { single_voucer, effected_cr_ldr, effected_dr_ldr } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Accounting Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> Receipt Voucher</div>
        </div>
        {(user && students && professional && schools && single_voucer) &&
          <div className="card card-box sfpage-cover">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page page-receipt-voucher">
                {effected_cr_ldr &&
                  <div className="list-accunts">
                    <div className="list-acc-head">List of Ledger Accunts</div>
                    <div className="list-acc-body">
                      <ul>
                        {effected_cr_ldr.map((item, index) => {
                          return (
                            <li key={index}>{item.ledger_name}</li>
                          )
                        })}
                      </ul>
                    </div>
                    <div className="list-acc-footer">more...</div>
                  </div>
                }
                <div className="acc-page-head container-fluid">
                  <div className="sec-title">
                    <div className="title-zone">Particulars</div>
                    <div className="info-zone">
                      <div className="info-zone">
                        <table className="table table-bordered table-sm">
                          <tbody>
                            <tr>
                              <td>
                                <div className="dr-title">Debit</div>
                              </td>
                              <td>
                                <div className="cr-title">Credit</div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="acc-page-body container-fluid">
                  <div className="av-detail-zone">
                    <div className="av-detail-head">
                      <div className="main-head">
                        <div className="head-name d-flex">
                          <span className="txt-normal mr-2">Cr </span>
                          <input type="text"
                            className="form-control trans-input form-control-sm"
                            onClick={() => this.effectedLedgerHandler([10])}
                          />
                        </div>
                        <div className="head-amount">
                          <div className="dr-total">500.00</div>
                          <div className="cr-total"></div>
                        </div>
                      </div>
                      <div className="crnt-balance-head">
                        <div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Cr</div>
                      </div>
                    </div>

                    <div className="av-detail-head">
                      <div className="main-head">
                        <div className="head-name"><span className="txt-normal">Dr </span> Fees</div>
                        <div className="head-amount">
                          <div className="dr-total"></div>
                          <div className="cr-total">500.00</div>
                        </div>
                      </div>
                      <div className="crnt-balance-head">
                        <div className="bal-head"><span className="txt-normal">Cur Bal :</span> 10,000 Dr</div>
                      </div>
                    </div>
                  </div>

                </div>
                <div className="acc-page-footer av-page-footer container-fluid">
                  <div className="sec-foot">
                    <div className="narration-zone">
                      <div className="title">Narration:</div>
                      <textarea className="form-control" defaultValue={""}>

                      </textarea>
                    </div>
                    <div className="amount-zone">
                      <div className="dr-total">500.00</div>
                      <div className="cr-total">500.00</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: students } = state.students;
  const { item: accLedger } = state.accLedger;
  const { item: accGroup } = state.accGroup;
  const { item: schools } = state.schools;
  const { item: professional } = state.professional;
  const { item: accLedgerEntry } = state.accLedgerEntry;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { all_ledgers } = state.accManager.item;
  const { single_voucer } = state.accManager.item;
  return {
    user, students, accLedger, accGroup, accLedgerEntry, single_voucer, all_ledgers,
    schools, professional,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getStudents: studentsAction.getStudents,
  getAccLedger: accLedgerActions.getAccLedger,
  getClasses: classesAction.getClasses,
  getProfessional: professionalAction.getProfessional,
  getAccGroup: accGroupActions.getAccGroup,
  getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
  getVoucherEntryHandler: accManagerActions.getVoucherEntryHandler,
  getACCManager: accManagerActions.getACCManager,
}

export default connect(mapStateToProps, actionCreators)(withRouter(ReceiptVoucher));