import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
//import Alert from 'react-s-alert';
// import axios from 'axios';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { frontGalleryActions, schoolsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddGallery from './add_gallery';
import EditGallery from './edit_gallery';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_GALLERIES = `http://schools.rajpsp.com/api/galleries/gallery/read.php`;
// const DELETE_URL = `http://schools.rajpsp.com/api/galleries/gallery/delete.php`;

class AllGalleries extends Component {
  state = {
    galleries: [],
    selected_item: '',
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

    if (isEmptyObj(this.props.frontGallery)) {
      this.props.getFrontGallery();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getGalleriesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getGalleriesHandler() {
  //   loadProgressBar();
  //   axios.get(GET_GALLERIES)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         galleries: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //console.log(this.state.galleries);
  //     }).catch((error) => {
  //       // error
  //     })
  // };

  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteFrontGallery({ id: del_id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  updateHandlar = (obj) => {
    // console.log(JSON.stringify(obj));
    this.props.updateFrontGallery(obj);
  }

  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   debugger;
  //   axios.post(DELETE_URL + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _galleries = this.state.galleries.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         galleries: _galleries
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.frontGallery.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }
  render() {

    const { formIsHalfFilledOut, createItem, editItem, selected_item } = this.state;
    const { user, frontGallery, schools } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>All Gallery</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {/* <div className="page-bar d-flex">
          <div className="page-title">All Gallery</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mt-1">
                <NavLink to="/add_gallery.jsp" className="btn btn-primary btn-sm">
                  Add New <i className="fa fa-plus" />
                </NavLink>
              </div>
            </div>
          </div>
        </div> */}
        <div className="card card-box sfpage-cover">
          {frontGallery && schools && user &&
            <>
              <div className="card-body sfpage-body">
                {createItem ? <AddGallery
                  toggeleCreate={this.toggeleCreate} />
                  : null}
                {editItem ? <EditGallery
                  selected_item={selected_item}
                  schools={schools}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                  : null}

                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm">
                    <thead>
                      <tr>
                        <th />
                        <th> School </th>
                        <th> Gallery Title</th>
                        <th> Description </th>
                        <th> Status </th>
                        <th> Action </th>
                      </tr>
                    </thead>
                    <tbody>
                      {frontGallery.map((item, index) => {
                        return (
                          <tr key={index} >
                            <td>{index + 1}</td>
                            <td>{item.school_name}</td>
                            <td>{item.title}</td>
                            <td>{item.description}</td>
                            <td className="text-center"><span className={`badge badge-pill ` + (item.active === '1' ? ' badge-success' : ' badge-danger')} >
                              {item.active === '1' ? 'Active' : 'Not Active'}
                            </span></td>
                            <td className="d-flex">
                              {/* <NavLink to={`edit_gallery.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit
                          </NavLink> */}
                              <button className="btn btn-primary btn-sm mr-1"
                                value={item.id}
                                type="button"
                                onClick={event => this.openEdit(event, item.id)}>Edit</button>
                              <button className="btn btn-danger btn-sm"
                                value={item.id}
                                type="button"
                                onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>

                  </table>
                </div>
              </div>
              <div className="card-footer">
                {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-danger btn-sm ">
                    Cancel</button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-primary btn-sm">
                    Add New</button>
                }
              </div>
            </>
          }
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontGallery } = state.frontGallery;
  const { item: schools } = state.schools;
  return { user, frontGallery, schools };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getFrontGallery: frontGalleryActions.getFrontGallery,
  updateFrontGallery: frontGalleryActions.update,
  deleteFrontGallery: frontGalleryActions.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllGalleries));