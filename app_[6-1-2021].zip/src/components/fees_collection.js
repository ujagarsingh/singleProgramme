import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, feeDetailedCollectionAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/read_all.php`;
// const READ_URL = `http://schools.rajpsp.com/api/school/read.php`;

class FeesCollection extends Component {
  state = {
    feeDetailed: [],
    selected_deposit_fee_arr: [],
    display_student_arr: [],
    medium_arr: [],
    id: "",
    sch_name: "",
    sch_reg_no: "",
    sch_recog_no: "",
    sch_contact_num: "",
    sch_mobile_num: "",
    sch_email: "",
    sch_address: "",
    sch_medium: "",
    sch_logo: "",
    sch_wel_mes_title: "",
    sch_wel_mes: '',
    fee_type: ['all', 'monthly', 'convence', 'sports_fee', 'reg_fee', 'exam_fee'],
    time: ['today', 'monthly', 'yearly'],
    select_time: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    formIsHalfFilledOut: false,
    medium: '',
    fee_status: 'none',
    fee_time: 'none',
    fee_month: 'none',
    selected_fee_month: '',
    fee_type: 'none',
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.studentFilterHandler(_sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
    } else if (fieldName === 'fee_status') {
      const _status = event.target.value;
      sessionStorage.setItem("fee_status", _status);
      this.setState({
        fee_status: _status
      }, () => {
        // this.filterHandler()
      })
    } else if (fieldName === 'fee_month') {
      const _status = event.target.value;
      sessionStorage.setItem("fee_month", _status);
      this.setState({
        fee_month: _status
      }, () => {
        // this.filterHandler()
      })
    } else if (fieldName === 'fee_type') {
      const _status = event.target.value;
      sessionStorage.setItem("fee_type", _status);
      this.setState({
        fee_type: _status
      }, () => {
        // this.filterHandler()
      })
    } else if (fieldName === 'fee_time') {
      const _time = event.target.value;
      sessionStorage.setItem("fee_time", _time);
      if (_time === 'Selected Month') {
        this.setState({
          fee_time: _time
        })
      } else {
        this.setState({
          fee_time: _time
        }, () => {
          // this.filterHandler()
        })
      }
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    }
  };
  mediumHandler(_medium) {
    let _fee_array = this.state.selected_deposit_fee_arr;
    if (!isEmpty(_fee_array)) {
      const _students = _fee_array.filter((item, inx) => {
        if (item.medium === _medium) {
          return item
        }
      })
      this.setState({
        display_student_arr: _students,
        medium: _medium
      })
    }
  }
  studentFilterHandler(school_id) {
    let _fee_array = this.props.feeDetailed;
    if (!isEmpty(_fee_array)) {
      const _students = _fee_array.filter((item, inx) => {
        if (item.school_id === school_id) {
          return item
        }
      })
      this.setState({
        selected_deposit_fee_arr: _students,
        display_student_arr: JSON.parse(JSON.stringify(_students)),
      })
    }
  }
  statusFilter(_fee_array, _fee_status) {
    // debugger;
    let _filtered_array = [];
    _fee_array.filter((item, inx) => {
      const _length = item.abc.length;
      if (_fee_status === 'none') {
        _filtered_array.push(item);
      } else if (_length > 0) {
        if (_fee_status === 'Deposited') {
          _filtered_array.push(item)
        } else if (_fee_status === 'Verified') {
          const _vitem = item.abc.filter((vItem) => {
            if (vItem.verify == '1') {
              return vItem
            }
          })
          if (!isEmpty(_vitem)) {
            const newItem = { ...item }
            newItem['abc'] = _vitem;
            _filtered_array.push(newItem)
          }
        } else if (_fee_status === 'Unverified') {
          const _nitem = item.abc.filter((nItem) => {
            if (nItem.verify == '0') {
              return nItem
            }
          })
          if (!isEmpty(_nitem)) {
            const newItem = { ...item }
            newItem['abc'] = _nitem;
            _filtered_array.push(newItem)
          }
        }
      }
    })
    return _filtered_array;
  }
  timeFilter(_fee_array, _fee_status) {
    let _filtered_array = [];

    let today = new Date();
    let dd = String(today.getDate()).padStart(2, '0');
    let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    let yyyy = today.getFullYear();

    let _today = yyyy + '-' + mm + '-' + dd;

    _fee_array.filter((item, inx) => {
      if (_fee_status === 'none' || _fee_status === 'Selected Month') {
        _filtered_array.push(item);
      } else if (item.abc.length > 0) {
        if (_fee_status === 'Today') {
          const _vitem = item.abc.filter((vItem) => {
            // deposit_date: "2019-11-27"
            if (vItem.deposit_date === _today) {
              return vItem
            }
          })
          if (!isEmpty(_vitem)) {
            const newItem = { ...item }
            // console.log(_vitem);
            newItem['abc'] = _vitem;
            _filtered_array.push(newItem)
          }
        } else if (_fee_status === 'Current Month') {
          let _vitem = item.abc.filter((vItem) => {
            const _cmonth = vItem.deposit_date.split('-')[1];

            if (_cmonth == mm) {
              //console.log(vItem);
              return vItem
            }
          })
          if (!isEmpty(_vitem)) {
            //console.log(_vitem);
            const newItem = { ...item }
            //console.log(newItem);
            newItem['abc'] = (_vitem);
            //console.log(newItem);
            _filtered_array.push(newItem)
          }
        } else if (_fee_status === 'Last Month') {
          const _vitem = item.abc.filter((vItem) => {
            const _cmonth = vItem.deposit_date.split('-')[1]; // - 1;
            if (_cmonth == (parseInt(mm) - 1)) {
              return vItem
            }
          })
          if (!isEmpty(_vitem)) {
            const newItem = { ...item }
            newItem['abc'] = _vitem;
            _filtered_array.push(newItem)
          }
        }
      }
    })
    //  console.log(_filtered_array);
    return _filtered_array;
  }

  monthFilter(_fee_array, _month_no) {
    let _filtered_array = [];

    let mm = _month_no;

    _fee_array.filter((item) => {
      if (_month_no === 'none') {
        _filtered_array.push(item);
      } else if (item.abc.length > 0) {
        let _vitem = item.abc.filter((vItem) => {
          const _cmonth = vItem.deposit_date.split('-')[1];

          if (_cmonth == mm) {
            //console.log(vItem);
            return vItem
          }
        })
        if (!isEmpty(_vitem)) {
          //console.log(_vitem);
          const newItem = { ...item }
          //console.log(newItem);
          newItem['abc'] = (_vitem);
          //console.log(newItem);
          _filtered_array.push(newItem)
        }

      }
    })
    //  console.log(_filtered_array);
    return _filtered_array;
  }

  typeFilter(_fee_array, _fee_type) {
    let _filtered_array = [];

    let mm = _fee_type;

    const _newFA = _fee_array.filter((item) => {
      if (_fee_type === 'none') {
        _filtered_array.push(item);
      } else if (item.abc.length > 0) {

        let _vitem = [];
        item.abc.filter((vItem) => {

          if (!isEmpty(vItem.xsd)) {
            let _vItem_arr = [];
            if (_fee_type == "Convence") {
              _vItem_arr = vItem.xsd.filter((xItem) => {
                if (xItem.fee_title == "Convence") {
                  return xItem
                }
              })
            } else {
              _vItem_arr = vItem.xsd.filter((xItem) => {
                if (xItem.fee_title != "Convence") {
                  return xItem
                }
              })
            }


            if (!isEmpty(_vItem_arr)) {
              vItem = { ...vItem, xsd: _vItem_arr }
              _vitem.push(vItem);
            }
          }
        })

        if (!isEmpty(_vitem)) {
          //console.log(_vitem);
          const newItem = { ...item }
          //console.log(newItem);
          newItem['abc'] = (_vitem);
          //console.log(newItem);
          _filtered_array.push(newItem)
        }

      }
    })

    console.log(_newFA);
    // console.log(_filtered_array);
    return _filtered_array;
  }


  async filterHandler() {
    let _fee_status = this.state.fee_status;
    let _fee_time = this.state.fee_time;
    let _fee_month = this.state.fee_month;
    let _fee_type = this.state.fee_type;
    let _fee_array = this.state.selected_deposit_fee_arr;
    let _status_array = [];
    let _time_array = [];
    let _month_array = [];
    let _type_array = [];
    // console.log(JSON.stringify(_fee_array));

    _status_array = await this.statusFilter(_fee_array, _fee_status);
    _time_array = await this.timeFilter(_status_array, _fee_time);
    _month_array = await this.monthFilter(_time_array, _fee_month);
    _type_array = await this.typeFilter(_month_array, _fee_type);

    await this.responceToStateHandler(_type_array);

  }

  responceToStateHandler(fee_array) {
    // console.log(JSON.stringify(fee_array));
    this.setState({
      display_student_arr: fee_array
    })
  }


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.feeDetailed)) {
      this.props.getFeeDetailedCollection();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.feeDetailed;
      if (_all_student && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.feeDetailed;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student_arr: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      this.setState({
        display_student: _school_student
      })
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getFeeCollectionHander();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }
  // getFeeCollectionHander() {
  //   loadProgressBar();
  //   axios.get(GET_FEE_DEPOSIT)
  //     .then(res => {
  //       const resData = res.data;
  //       this.setState({
  //         feeDetailed: resData.record,
  //         errorMessages: resData.message
  //       });
  //       //console.log(this.props.feeDetailed);
  //     }).catch((error) => {
  //       // error
  //     })

  //   axios.get(READ_URL)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         id: getRes.id,
  //         sch_name: getRes.sch_name,
  //         sch_reg_no: getRes.sch_reg_no,
  //         sch_recog_no: getRes.sch_recog_no,
  //         sch_contact_num: getRes.sch_contact_num,
  //         sch_mobile_num: getRes.sch_mobile_num,
  //         sch_email: getRes.sch_email,
  //         sch_address: getRes.sch_address,
  //         sch_medium: getRes.sch_medium,
  //         sch_logo: getRes.sch_logo,
  //         sch_wel_mes_title: getRes.sch_wel_mes_title,
  //         sch_wel_mes: getRes.sch_wel_mes,
  //         errorMessages: getRes.message
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // };
  nuberInWords = (price) => {
    var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
      dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
      tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
      handle_tens = function (dgt, prevDgt) {
        return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
      },
      handle_utlc = function (dgt, nxtDgt, denom) {
        return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
      };

    var str = "",
      digitIdx = 0,
      digit = 0,
      nxtDigit = 0,
      words = [];
    if (price += "", isNaN(parseInt(price))) str = "";
    else if (parseInt(price) > 0 && price.length <= 10) {
      for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--) switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
        case 0:
          words.push(handle_utlc(digit, nxtDigit, ""));
          break;
        case 1:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 2:
          words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
          break;
        case 3:
          words.push(handle_utlc(digit, nxtDigit, "Thousand"));
          break;
        case 4:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 5:
          words.push(handle_utlc(digit, nxtDigit, "Lakh"));
          break;
        case 6:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 7:
          words.push(handle_utlc(digit, nxtDigit, "Crore"));
          break;
        case 8:
          words.push(handle_tens(digit, price[digitIdx + 1]));
          break;
        case 9:
          words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "")
      }
      str = words.reverse().join("")
    } else str = "";
    return str

  }

  printThisReceipt = () => {
    // window.print();
  }

  render() {
    const { formIsHalfFilledOut, medium_arr, display_student_arr, selected_school_index, medium, fee_status, fee_time, fee_month, fee_type } = this.state;
    const { user, schools, feeDetailed } = this.props;
    //  console.log(JSON.stringify(this.state.display_student_arr));
    // debugger
    return (
      <div className="page-content">
        <Helmet>
          <title>Fee Collection</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        {user && schools && feeDetailed &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">Fees Collection</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-link">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    showClassFilter={false}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                    filterByClsHandler={this.filterByClsHandler}
                  />
                  {/* <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div> */}
                  <div className="form-group mr-2 mt-1">
                    <label className="mr-1">Status :</label>
                    <select className="form-control form-control-sm mr-2"
                      // disabled={medium === '' ? true : false}
                      value={fee_status}
                      onChange={event => this.changeHandler(event, 'fee_status')}>
                      <option value='none'>Select ...</option>
                      <option value="Deposited">Deposited</option>
                      <option value="Verified">Verified</option>
                      <option value="Unverified">Unverified</option>
                    </select>
                  </div><div className="form-group mr-2 mt-1">
                    <label className="mr-1">Time :</label>
                    <select className="form-control form-control-sm mr-2"
                      // disabled={medium === '' ? true : false}
                      value={fee_time}
                      onChange={event => this.changeHandler(event, 'fee_time')}>
                      <option value='none'>Select ...</option>
                      <option value="Today">Today</option>
                      <option value="Current Month">Current Month</option>
                      <option value="Last Month">Last Month</option>
                      <option value="Selected Month">Selected Month</option>
                    </select>
                  </div><div className="form-group mr-2 mt-1">
                    <label className="mr-1">Month :</label>
                    <select className="form-control form-control-sm mr-2"
                      disabled={fee_time === 'Selected Month' ? false : true}
                      value={fee_month}
                      onChange={event => this.changeHandler(event, 'fee_month')}>
                      <option value='none'>Select ...</option>
                      <option value="01">January</option>
                      <option value="02">February</option>
                      <option value="03">March</option>
                      <option value="04">April</option>
                      <option value="05">May</option>
                      <option value="06">June</option>
                      <option value="07">July</option>
                      <option value="08">August</option>
                      <option value="09">September</option>
                      <option value="10">October</option>
                      <option value="11">November</option>
                      <option value="12">December</option>
                    </select>
                  </div>
                  <div className="form-group mt-1">
                    <label className="mr-1">Type</label>
                    <select className="form-control form-control-sm mr-1"
                      // disabled={medium === '' ? true : false}
                      value={fee_type}
                      onChange={event => this.changeHandler(event, 'fee_type')}>
                      <option>All</option>
                      <option>Normal</option>
                      <option>Convence</option>
                    </select>
                  </div>
                  <div className="form-group mt-1">
                    <button className="btn btn-primary btn-sm"
                      onClick={event => this.filterHandler(event)}>
                      Show</button>
                  </div>
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                <div className="table-scrollable">
                  <table className="table table-striped table-sm table-bordered table-sm">
                    <thead>
                      <tr>
                        <th className="center" width="60"> </th>
                        <th className="center" width="60"> </th>
                        <th className="center" width="100"> SR No.</th>
                        <th className="center" width=""> Student Name </th>
                        <th className="center" width="100"> Class</th>
                        <th className="center" width="100"> Status </th>
                        <th className="center" width="100"> Amount</th>
                        <th className="center" width="100"> Action</th>
                      </tr>
                    </thead>
                  </table>
                  {display_student_arr.map((invoice, index) => {
                    return (
                      <table key={index} className="table table-sm table-bordered 10">
                        <tbody>
                          <tr >
                            <td className="center" width="60"><input type="checkbox" /></td>
                            <td className="center" width="60">{index + 1}</td>
                            <td className="center" width="100">{invoice.admission_number}</td>
                            <td><strong>{invoice.student_name}</strong> S/o <br /> {invoice.father_name}</td>
                            <td className="center" width="100">{invoice.stu_class}</td>
                            <td className="center" width="100">P/C</td>
                            <td className="center" width="100">Rs. {invoice.total_amount}</td>
                            <td className="center" width="100">{(invoice.abc.length > 0) ? <button className="btn btn-primary btn-sm"><i className="fa fa-angle-right"></i></button> : null}</td>
                          </tr>
                          {(invoice.abc.length > 0) ?
                            <tr className=" d-none_temp">
                              <td colSpan="11" className="p-0">
                                <table className="table table-bordered table-sm m-0 23">
                                  <thead>
                                    <tr className="table-secondary">
                                      <th className="text-center" width="60">Id</th>
                                      <th className="text-center" width="150">Fee Amount</th>
                                      <th className="text-center" width="150">Total Amount</th>
                                      <th className="text-center" width="150">Balance Amount</th>
                                      <th className="text-center" width="150">Date</th>
                                      <th className="text-center">Description</th>
                                      <th className="text-center" width="100">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {invoice.abc.map((in_detail, index) => {
                                      return (
                                        <tr key={index} className="table-warning">
                                          <td colSpan="7" className="p-0">
                                            <table key={index} className="table table-sm table-bordered m-0">
                                              <tbody>
                                                <tr >
                                                  <td className="text-center" width="60">{in_detail.id}</td>
                                                  <td className="text-right" width="150">{in_detail.fee_amount}</td>
                                                  <td className="text-right" width="150">{in_detail.total_amount}</td>
                                                  <td className="text-right" width="150">{in_detail.balance_amount}</td>
                                                  <td className="text-right" width="150">{in_detail.deposit_date}</td>
                                                  <td className="text-left" >{in_detail.description}</td>
                                                  <td className="text-center" width="100"><button className="btn btn-primary btn-sm"><i className="fa fa-angle-right"></i></button></td>
                                                </tr>
                                                <tr>
                                                  <td colSpan="7" className="p-0">
                                                    <table key={index} className="table table-sm table-hover m-0">
                                                      <tbody>
                                                        <tr className="table-danger">
                                                          <th className="text-center">#</th>
                                                          <th className="text-right">Invoice id</th>
                                                          <th className="text-right">Fees Type</th>
                                                          <th className="text-right">Month of fee</th>
                                                          <th className="text-right">Amount</th>
                                                        </tr>
                                                        {(in_detail.xsd) &&
                                                          <>
                                                            {(in_detail.xsd.length > 0) ? in_detail.xsd.map((in_detail1, index) => {
                                                              return (
                                                                <tr key={index} className="table-info">
                                                                  <td className="text-center">{index + 1}</td>
                                                                  <td className="text-right">{in_detail1.id}</td>
                                                                  <td className="text-right">{in_detail1.fee_title}</td>
                                                                  <td className="text-right">{in_detail1.month_of_fee}</td>
                                                                  <td className="text-right">{in_detail1.fee_amount}</td>
                                                                </tr>
                                                              )
                                                            }) : null}
                                                          </>
                                                        }
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                            : null
                          }
                        </tbody>
                      </table>
                    )
                  })}
                </div>
              </div>
            </div>
          </>
        }
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: feeDetailed } = state.feeDetailed;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return { user, schools, feeDetailed, filteredSchoolData, filteredClassesData };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getFeeDetailedCollection: feeDetailedCollectionAction.getFeeDetailedCollection,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FeesCollection));