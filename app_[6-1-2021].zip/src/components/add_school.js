import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { Picky } from 'react-picky';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { schoolsAction, sessionYearsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const CREATE_URL = `http://schools.rajpsp.com/api/school/create.php`;

class AddSchool extends Component {
  state = {
    id: "",
    medium_opt: ['Hindi', 'English'],
    sch_name: "",
    session_year_id: "",
    sch_reg_no: "",
    sch_recog_no: "",
    sch_contact_num: "",
    sch_mobile_num: "",
    sch_email: "",
    sch_address: "",
    sch_medium: [],
    sch_wel_mes_title: "",
    sch_wel_mes: '',
    logo_data: "",
    admin_img_data: "",
    admin_sign_data: "",
    crop: { unit: "%", width: 30, aspect: 1 },
    final_size: { width: 400, height: 400 },
    signature_size: { width: 300, height: 100 },
    signature_crop: { unit: "%", width: 30, aspect: 3 / 1 },
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.sessionYears)) {
      this.props.getSessionYears();
    }
  }
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getSchoolHandler();
  //           // this.getClassesHandler();
  //           // this.getConvencesHandler();
  //           // this.getStudentRecords();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };
  setMediumHandler = (value) => {
    //console.count('onChange')
    this.setState({
      sch_medium: value
    })
  }
  // child (my_image.js) component to get image
  onCompleteLogo = (data) => {
    this.setState({
      logo_data: data
    })
  }
  // child (my_image.js) component to get image
  onCompleteAadminImage = (data) => {
    this.setState({
      admin_img_data: data
    })
  }
  // child (my_image.js) component to get image
  onCompleteAdminSignature = (data) => {
    this.setState({
      admin_sign_data: data
    })
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = () => {
    loadProgressBar();
    //e.preventDefault();
    const obj = {
      // group_id: this.state.group_id,
      sch_name: this.state.sch_name,
      sch_reg_no: this.state.sch_reg_no,
      sch_recog_no: this.state.sch_recog_no,
      sch_contact_num: this.state.sch_contact_num,
      sch_mobile_num: this.state.sch_mobile_num,
      sch_email: this.state.sch_email,
      sch_address: this.state.sch_address,
      sch_medium: this.state.sch_medium,
      logo_data: this.state.logo_data,
      admin_img_data: this.state.admin_img_data,
      admin_sign_data: this.state.admin_sign_data,
      session_year_id: this.state.session_year_id,
    }
    // console.log(JSON.stringify(obj))

    this.props.create(obj);

    // axios.post(CREATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       group_id: '',
    //       sch_name: '',
    //       sch_reg_no: '',
    //       sch_recog_no: '',
    //       sch_contact_num: '',
    //       sch_mobile_num: '',
    //       sch_email: '',
    //       sch_address: '',
    //       sch_medium: '',
    //       logo_data: '',
    //       admin_img_data: '',
    //       admin_sign_data: '',
    //       session_year_id: '',
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }

  render() {
    const { logo_data, admin_img_data, admin_sign_data, crop, final_size, signature_crop, 
      signature_size, sch_name, sch_address,
      sch_contact_num, sch_email, sch_medium, sch_mobile_num, sch_recog_no, sch_reg_no,
      medium_opt, formIsHalfFilledOut, session_year_id } = this.state;
    const { user, sessionYears } = this.props;
    //console.log(this.state)
    return (
      <div className="page-child">
        <Helmet>
          <title>School Biography</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            School Biography
          </div>
          {user && sessionYears &&
            <div className="card-body">
              <div className="row">
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Name
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_name" placeholder="school name"
                        className="form-control form-control-sm"
                        value={sch_name}
                        onChange={event => this.changeHandler(event, `sch_name`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Registratin Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_reg_no"
                        placeholder="" className="form-control form-control-sm"
                        value={sch_reg_no}
                        onChange={event => this.changeHandler(event, `sch_reg_no`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Recognition Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_recog_no"
                        placeholder="" className="form-control form-control-sm"
                        value={sch_recog_no}
                        onChange={event => this.changeHandler(event, `sch_recog_no`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Session Year
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='session_year_id'
                        value={session_year_id}
                        onChange={event => this.changeHandler(event, 'session_year_id')}>
                        <option value="">Select ...</option>
                        {sessionYears.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.ses_year}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Email Address</label>
                    <div className="form-input">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-envelope" /></span>
                        </div>
                        <input type="email" className="form-control form-control-sm"
                          name="sch_email" placeholder="Email Address"
                          value={sch_email}
                          onChange={event => this.changeHandler(event, `sch_email`)} /> </div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Landline Number
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_contact_num"
                        placeholder="Telephone" className="form-control form-control-sm"
                        value={sch_contact_num}
                        onChange={event => this.changeHandler(event, `sch_contact_num`)} /> </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Mobile No.
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_mobile_num"
                        placeholder="Mobile" className="form-control form-control-sm"
                        value={sch_mobile_num}
                        onChange={event => this.changeHandler(event, `sch_mobile_num`)} /> </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Medium
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <Picky
                        value={sch_medium}
                        options={medium_opt}
                        onChange={this.setMediumHandler}
                        open={false}
                        valueKey="id"
                        labelKey="name"
                        multiple={true}
                        includeSelectAll={true}
                        includeFilter={true}
                        dropdownHeight={200}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Address
                      <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="sch_mobile_num"
                        placeholder="address" className="form-control form-control-sm"
                        value={sch_address}
                        onChange={event => this.changeHandler(event, `sch_address`)} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">School Logo</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteLogo}
                        crop={crop}
                        final_size={final_size}
                      />
                      {logo_data !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={logo_data} />
                        : null}
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Admin Image</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteAadminImage}
                        crop={crop}
                        final_size={final_size}
                      />
                      {admin_img_data !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={admin_img_data} />
                        : null}
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Admin Signature</label>
                    <div className="form-input">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onCompleteAdminSignature}
                        crop={signature_crop}
                        final_size={signature_size}
                      />
                      {admin_sign_data !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={admin_sign_data} />
                        : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          }
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-secondary mr-2">Add New School</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form >
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: sessionYears } = state.sessionYears;
  return { user, sessionYears };
}

const actionCreators = {
  create: schoolsAction.create,
  getSessionYears: sessionYearsAction.getSessionYears,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddSchool));