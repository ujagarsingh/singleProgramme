import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_USER = `http://schools.rajpsp.com/api/users/read.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/users/delete.php`;
const USER_CATEGORY = `http://schools.rajpsp.com/api/users/read_category.php`;

class AllUsers extends Component {
   state = {
      users_arr: [],
      users_cat_arr: [],
      formIsHalfFilledOut: false,
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })
   };

   componentDidMount() {

   }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getAllUsersHandler();
   //                this.getUsersCategoryHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getAllUsersHandler() {
   //    loadProgressBar();
   //    const _user_cate = this.state.user_category;
   //    const obj = {
   //       user_category: _user_cate,
   //    }
   //    console.log(JSON.stringify(obj));
   //    axios.post(GET_USER, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          if (Array.isArray(getRes.data)) {
   //             this.setState({
   //                users_arr: getRes.data
   //             });
   //             if (getRes.message !== undefined) {
   //                Alert.error(getRes.message, {
   //                   position: 'bottom-right',
   //                   effect: 'jelly',
   //                   timeout: 5000, offset: 40
   //                });
   //             }
   //          }
   //       }).catch((error) => {
   //          // error
   //       })
   // };

   // getUsersCategoryHandler() {
   //    const _user_cate = this.state.user_category;
   //    const obj = {
   //       user_category: _user_cate,
   //    }
   //    loadProgressBar();
   //    axios.post(USER_CATEGORY, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             users_cat_arr: getRes
   //          });
   //          if (getRes.message !== undefined) {
   //             Alert.error(getRes.message, {
   //                position: 'bottom-right',
   //                effect: 'jelly',
   //                timeout: 5000, offset: 40
   //             });
   //          }
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      let del_id = id;
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.deleteHandlar(event, del_id);
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   deleteHandlar = (event, id) => {
      event.preventDefault();

      axios.post(DELETE_URL + '?id=' + id)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes)
            Alert.success(getRes.message, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
            Alert.error(getRes.error, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
            const _users_arr = this.state.users_arr.filter((item, index) => {
               return item.id !== id
            })
            this.setState({
               users_arr: _users_arr
            })
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })
   }
   render() {
      const { formIsHalfFilledOut, users_arr } = this.state;
      return (
         <div className="page-content">
            <Helmet>
               <title>All Users</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            {/* <div className="page-bar d-flex">
               <div className="page-title">All Users</div>
               <div className="form-inline ml-auto filter-panel">
                  <span className="filter-closer">
                     <button type="button" className="btn btn-danger filter-toggler-c">
                        <i className="fa fa-times"></i>
                     </button>
                  </span>
                  <div className="filter-con">
                     <div className="form-group mt-1">
                        <NavLink to="/add_user.jsp"
                           onClick={e => e.preventDefault()}
                           className="btn btn-primary btn-sm">
                           Add New <i className="fa fa-plus" />
                        </NavLink>
                     </div>
                  </div>
               </div>
            </div> */}
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  <div className="table-scrollable">
                     <table className="table table-striped table-bordered table-hover table-sm">
                        <thead>
                           <tr>
                              <th />
                              <th> User Name</th>
                              <th> User Category </th>
                              <th> User ID </th>
                              <th> Login ID </th>
                              <th> Medium </th>
                              <th> Is Active </th>
                              <th> Action </th>
                           </tr>
                        </thead>
                        {users_arr.length > 0 ?
                           <tbody>
                              {users_arr.map((item, index) => {
                                 return (
                                    <tr key={index} >
                                       <td>{index + 1}</td>
                                       <td>{item.user_name}</td>
                                       <td>{(item.user_category === '1') ? 'Supper Admin' :
                                          (item.user_category === '2') ? 'Admin' :
                                             (item.user_category === '3') ? 'Employee' :
                                                'Student'}</td>
                                       <td>{item.user_id}</td>
                                       <td>{item.login_id}</td>
                                       <td>{item.medium}</td>
                                       <td>{(item.is_active === '1') ?
                                          <span className="badge badge-pill badge-success">Yes</span>
                                          :
                                          <span className="badge badge-pill badge-danger">No</span>
                                       }</td>
                                       <td className="d-flex">
                                          <NavLink className="btn btn-primary btn-sm mr-1"
                                             to={`/edit_user.jsp/${item.id}`}>
                                             Edit</NavLink>
                                          <button className="btn btn-danger btn-sm"
                                             onClick={event => this.confirmBoxDelete(event, item.id)}>
                                             Del
                                          </button>
                                       </td>
                                    </tr>
                                 )
                              })}
                           </tbody>
                           : null}
                     </table>
                  </div>
               </div>
               <div className="card-footer">
                  <NavLink to="/add_user.jsp"
                     onClick={e => (e.preventDefault(), alert('on the way'))}
                     className="btn btn-primary btn-sm">
                     Add New <i className="fa fa-plus" />
                  </NavLink>
               </div>
            </div>
         </div>
      )
   }
}
export default withRouter(AllUsers);