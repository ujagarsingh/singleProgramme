import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import ReactYoutubePlayer from "../utility/youtubePlayer";
// import { HOST_URL } from '../includes/api-config';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const GET_ALL_LESSONS = `http://schools.rajpsp.com/api/lessons/read_of_one_class.php`;
// const READ_URL = `http://schools.rajpsp.com/api/subject/read.php`;

class StudentsLessonFAQs extends Component {
  state = {
    les_months_arr: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    school_id: '',
    current_video: "",
    current_date: new Date(),
    lessons_date_arr: [],
    selected_les_date_arr: [],
    selected_les_sub_id: "",
    lessons_subject_arr: [],
    lessons: [],
    selected_lessons: [],
    selected_month: '',
    selected_les_date: '',
    formIsHalfFilledOut: false,
    askNewQuestion: false,
    editQuestion: false
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'selected_les_date') {
      const _less_date = event.target.value;
      this.setState({
        selected_les_date: _less_date,
        selected_les_sub_id: "",
      }, () => this.filterLessonHandler())
    } else if (fieldName === 'selected_month') {
      const _select_month = parseInt(event.target.value) + 1;
      this.setState({
        selected_month: _select_month,
        selected_les_date: "",
        selected_les_sub_id: "",
      }, () => this.filterLessonHandler())
    } else if (fieldName === 'selected_les_sub_id') {
      const _select_sub_id = event.target.value;
      this.setState({
        selected_les_sub_id: _select_sub_id,
      }, () => this.filterLessonHandler())
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  filterLessonHandler() {
    const _month = parseInt(this.refs.selected_month.value) + 1;
    const _date = this.refs.selected_les_date.value;
    const _subject = this.refs.selected_les_sub_id.value;

    const filtered_date_arr = this.state.lessons_date_arr.filter((item) => {
      if (parseInt(item.les_month) === _month) {
        return item
      }
    })

    const filteredLesson_1 = this.state.lessons.filter((item) => {
      if (_month !== "") {
        if (parseInt(item.les_month) === _month) {
          return item;
        }
      } else {
        return item;
      }
    })
    // console.log(filteredLesson_1);
    const filteredLesson_2 = filteredLesson_1.filter((item) => {
      if (_date !== "") {
        if (item.les_date === _date) {
          return item;
        }
      } else {
        return item;
      }
    })

    // console.log(filteredLesson_2);
    const filteredLesson = filteredLesson_2.filter((item) => {
      if (_subject !== "") {
        if (item.les_sub_id === _subject) {
          return item;
        }
      } else {
        return item;
      }
    })
    // console.log(filteredLesson);
    const afterActiveLesson = filteredLesson.map((item, index) => {
      if (index === 0) {
        item = { ...item, temp_class: "active" }
      } else {
        item = { ...item, temp_class: "" }
      }
      return item
    })

    if (afterActiveLesson.length > 0) {
      this.setState({
        selected_lessons: afterActiveLesson,
        current_video: afterActiveLesson[0],
        selected_les_date_arr: filtered_date_arr
      })
    } else {
      Alert.error("Lesson Not Exist!!. Please Change Critearea of Filter....", {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
  }

  filterTodayLessonOnload() {
    const crnt_date = this.state.current_date;
    const crnt_month = crnt_date.getMonth() + 1;
    const today_date = (crnt_date.getFullYear() + "-"
      + ("0" + (crnt_date.getMonth() + 1)).slice(-2) + "-"
      + ("0" + crnt_date.getDate()).slice(-2));

    const filtered_date_arr = this.state.lessons_date_arr.filter((item) => {
      if (parseInt(item.les_month) === crnt_month) {
        return item
      }
    })

    const filteredLesson = this.state.lessons.filter((item) => {
      if (parseInt(item.les_month) === crnt_month && item.les_date === today_date) {
        return item;
      }
    })

    const afterActiveLesson = filteredLesson.map((item, index) => {
      if (index === 0) {
        item = { ...item, temp_class: "active" }
      } else {
        item = { ...item, temp_class: "" }
      }
      return item
    })

    if (afterActiveLesson.length > 0) {
      this.setState({
        selected_lessons: afterActiveLesson,
        current_video: afterActiveLesson[0],
        selected_les_date_arr: filtered_date_arr
      })
    } else {
      Alert.error("Today's Lesson Not Exist", {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
    this.setState({
      selected_month: crnt_month,
      selected_les_date: today_date,
    })
  }

  componentDidMount() {
    const token = sessionStorage.getItem('jwt');
    const obj = { "jwt": token };
    // this.checkAuthentication(obj);
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //           class_id: (getRes.data.class_id) ? getRes.data.class_id : "",
  //         }, () => {
  //           this.getLessonHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  getLessonHandler() {
    const obj = {
      sch_id: this.state.school_id,
      class_id: this.state.class_id,
    }
    // console.log(JSON.stringify(obj));
    // debugger
    loadProgressBar();
    axios.post(GET_ALL_LESSONS, obj)
      .then(res => {
        const getRes = res.data;
        if (getRes.resLessonData) {
          this.setState({
            lessons: getRes.resLessonData,
            lessons_date_arr: getRes.resDateLesson,
            selected_les_date_arr: getRes.resDateLesson,
            lessons_subject_arr: getRes.resClassSubject,
          }, () => { this.filterTodayLessonOnload() });
        } else {
          this.setState({
            lessons: [],
            selected_lessons: [],
            lessons_date_arr: [],
          });

          Alert.error(getRes.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  }


  getSubjectNameByid(_id) {
    const all_subjects = this.state.lessons_subject_arr;
    const crrent_sub = all_subjects.filter((item) => {
      if (item.id === _id) {
        return item;
      }
    });
    //const subject = crrent_sub[0].sub_name;
    return crrent_sub[0].sub_name
  }

  showVideoHandler(event, video_id) {
    event.preventDefault();
    const listoflession = this.state.selected_lessons;
    const currentVideo = listoflession.filter((item) => {
      if (item.id === video_id) {
        return item;
      }
    })
    const afterActiveLesson = listoflession.map((item) => {
      if (item.id === video_id) {
        item = { ...item, temp_class: "active" }
      } else {
        item = { ...item, temp_class: "" }
      }
      return item
    })
    this.setState({
      current_video: currentVideo[0],
      selected_lessons: afterActiveLesson
    })
  }
  newQuestionHandler(event) {
    event.preventDefault();
    this.setState({
      askNewQuestion: !this.state.askNewQuestion
    })
  }
  editQuestionHandler(event) {
    event.preventDefault();
    this.setState({
      editQuestion: !this.state.editQuestion
    })
  }

  render() {
    const { selected_month, selected_lessons, lessons_subject_arr, current_video,
      selected_les_date_arr, selected_les_sub_id, les_months_arr, selected_les_date,
      formIsHalfFilledOut, askNewQuestion, editQuestion } = this.state;
    console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Lessons</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">All Lessons</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Month : </label>
                <select
                  ref={"selected_month"}
                  disabled={selected_lessons === '' ? true : false}
                  value={selected_month - 1}
                  className="form-control form-control-sm " name="selected_month"
                  onChange={event => this.changeHandler(event, 'selected_month')}>
                  <option value="">All ...</option>
                  {les_months_arr.map((option, index) => {
                    return (<option key={index} value={index}>{les_months_arr[index]}</option>)
                  })}
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Date : </label>
                <select
                  ref={"selected_les_date"}
                  disabled={selected_lessons === '' ? true : false}
                  value={selected_les_date}
                  className="form-control form-control-sm " name="selected_les_date"
                  onChange={event => this.changeHandler(event, 'selected_les_date')}>
                  <option value="">All ...</option>
                  {selected_les_date_arr.map((option, index) => {
                    return (<option key={index} value={option.les_date}>{option.les_date}</option>)
                  })}
                </select>
              </div>
              <div className="form-group mt-1">
                <label className="control-label mr-2">Subject : </label>
                <select
                  ref={"selected_les_sub_id"}
                  disabled={selected_lessons === '' ? true : false}
                  value={selected_les_sub_id}
                  className="form-control form-control-sm " name="selected_les_sub_id"
                  onChange={event => this.changeHandler(event, 'selected_les_sub_id')}>
                  <option value="">All ...</option>
                  {lessons_subject_arr.map((option, index) => {
                    return (<option key={index} value={option.id}>{option.sub_name}</option>)
                  })}
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body p-0">
            <div className="st-lesson-panel">
               <div className="videoBook p-2">
                  {current_video ?
                    <div className="currentVideoSec">
                      <div className="card border-primary mb-3">
                        <ReactYoutubePlayer videoId={current_video.les_link} videoClass={"vp-XLargeThumb"} />
                        <div className="card-body">
                          <p className="card-title mb-1"><strong>{current_video.les_title}</strong></p>
                          <p className="text-muted mb-2">{current_video.les_remark}</p>
                        </div>
                      </div>
                    </div>
                    : <div>
                      <h2 className="display-4">Lesson Not Found of Current Date Please Change Criteria</h2>
                    </div>
                  }
                  <div className="videoListsec">
                    {selected_lessons.length > 0 ?
                      <div className="list-group">
                        {selected_lessons.map((item, index) => {
                          return (
                            <button key={index} onClick={event => this.showVideoHandler(event, item.id)}
                              className={`list-group-item list-group-item-action 
                          flex-column align-items-start p-1  ${item.temp_class}`}>
                              <div className="videoListView">
                                <div className="videoImage">
                                  <img src={`https://img.youtube.com/vi/${item.les_link}/default.jpg`} />
                                </div>
                                <div className="videoData">
                                  <div className="mb-1 videoListTitle">{item.les_title}</div>
                                  <div className="videoListDec">{item.les_remark}</div>
                                </div>
                              </div>
                            </button>
                          )
                        })}
                      </div>
                      : null}
                  </div>
                </div> 

              <div className="col-sm-8">
                <div className="st-faq-panel">
                  <div className="faq-section">
                    <div className="d-flex"><h5>All FAQs List</h5>
                      {!askNewQuestion &&
                        <button type="button" className="ml-auto btn btn-danger btn-sm"
                          onClick={event => this.newQuestionHandler(event)}>New Question</button>
                      }
                    </div>
                    {askNewQuestion &&
                      <div className="write-question p-2">
                        <textarea className="form-control" rows="5"
                          placeholder="Write Your Question Here....">
                        </textarea>
                        <div className="d-flex mt-2">
                          <button type="button" className="ml-auto btn btn-outline-danger btn-sm mr-4"
                            onClick={event => this.newQuestionHandler(event)}>Cancel</button>
                          <button className="btn btn-success btn-sm" >Save</button></div>
                      </div>
                    }
                  </div>
                  <hr />
                  {/*question Start */}
                  <div className="media">
                    <img className="mr-3 rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" />
                    <div className="media-body">
                      <div className="question-body">
                        {!editQuestion ?
                          <>
                            <p className="question-text mb-2">It is a long established fact that a reader will be distracted by the readable content of a page.</p>
                            <div className="d-flex"><span className="text-muted">- 2 hours ago</span>
                              <button className="ml-auto btn btn-outline-primary btn-sm"
                                onClick={event => this.editQuestionHandler(event)}
                              >Edit</button>
                            </div>
                          </>
                          :
                          <div className="write-question bg-light p-2 mb-2">
                            <textarea className="form-control" rows="3"
                              defaultValue="It is a long established fact that a reader will be distracted by the readable content of a page.">
                            </textarea>
                            <div className="d-flex mt-2 mb-1">
                              <button type="button" className="ml-auto btn btn-outline-danger btn-sm mr-4"
                                onClick={event => this.editQuestionHandler(event)}>Cancel</button>
                              <button className="btn btn-success btn-sm" >Save</button></div>
                          </div>
                        }
                      </div>
                      <div className="ans-body card-body bg-light p-2 mt-2">
                        <p className="ans-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      </div>
                      <div className="media mt-4">
                        <NavLink className="pr-3" to="/"><img className="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" /></NavLink>
                        <div className="media-body">
                          <div className="question-body">
                            <p className="question-text mb-2">letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
                            <div className="d-flex"><span>- 3 hours ago</span> <button className="ml-auto btn btn-outline-primary btn-sm">Edit</button></div>
                          </div>
                          <div className="ans-body card-body bg-light p-2 mt-2">
                            <p className="ans-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          </div>
                        </div>
                      </div>
                      <div className="media mt-3">
                        <NavLink className="pr-3" to="/">
                          <img className="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" /></NavLink>
                        <div className="media-body">
                          <div className="question-body">
                            <p className="question-text mb-2">the majority have suffered alteration in some form, by injected humour, or randomised words.</p>
                            <div className="d-flex"><span>- 4 hours ago</span><button className="ml-auto btn btn-outline-primary btn-sm">Edit</button></div>
                          </div>
                          <div className="ans-body card-body bg-light p-2 mt-2">
                            <p className="ans-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/*question end */}
                  {/*question Start */}
                  <div className="media mt-4">
                    <NavLink className="pr-3" to="/"><img className="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" /></NavLink>
                    <div className="media-body">
                      <div className="question-body">
                        <p className="question-text mb-2">letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
                        <div className="d-flex"><span>- 3 hours ago</span> <button className="ml-auto btn btn-outline-primary btn-sm">Edit</button></div>
                      </div>
                      <div className="ans-body card-body bg-light p-2 mt-2">
                        <p className="ans-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      </div>
                    </div>
                  </div>
                  {/*question end */}

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(StudentsLessonFAQs);


