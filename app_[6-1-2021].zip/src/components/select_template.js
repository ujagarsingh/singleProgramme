import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class SelectTemplate extends Component {
  render() {
    return (
      <div className="page-content">
         <Helmet>
          <title>Select Template</title>
        </Helmet>
        <div className="page-bar d-flex">
              <div className="page-title">Select Template</div>
            </div>
        <div className="row">
          <div className="col-lg-6 col-md-12 col-sm-12 col-12">
            <div className="card-box">

              <img alt="SmartPSP" className="img-responsive" src={`${process.env.PUBLIC_URL}/assets/images/admin/template/template1.jpg`}  />
              <div className="card-footer text-right">
                <div className="custom-control custom-control-inline custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="customSwitch1" defaultChecked />
                  <label className="custom-control-label" htmlFor="customSwitch1">Active</label>
                </div>
                <button type="submit" className="btn btn-primary mr-2 ml-auto">Preview</button>
               <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-12 col-sm-12 col-12">
            <div className="card-box">
              <div className="card-head">
                <header>Premium</header>
              </div>
              <img alt="SmartPSP" className="img-responsive" src={`${process.env.PUBLIC_URL}/assets/images/admin/template/template2.jpg`} />
              <div className="card-footer text-right">
                <div className="custom-control custom-control-inline custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="customSwitch2" defaultChecked />
                  <label className="custom-control-label" htmlFor="customSwitch2">Active</label>
                </div>
                <button type="submit" className="btn btn-primary mr-2 ml-auto">Preview</button>
               <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
              </div>
            </div>
          </div>
        </div>
        {/* add content here */}
      </div>
    )
  }
}
export default withRouter(SelectTemplate);