import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { schoolsAction, frontGalleryActions, frontImagesActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const GET_GALLERIES = `http://schools.rajpsp.com/api/galleries/gallery/read.php`;
// const CREATE_GALLERY = `http://schools.rajpsp.com/api/galleries/images/create.php`;

class AddImage extends Component {
  state = ({
    title: "",
    isActive: true,
    formIsHalfFilledOut: false,
    gallery_index: '',
    gallery_id: '',
    gallery_img: "",
    crop: {
      unit: "%",
      width: 50,
      aspect: 16 / 9
    },
    final_size: {
      width: 800,
      height: 450
    }
  })
  // child (my_image.js) component to get image
  onComplete = (data) => {
    this.setState({
      gallery_img: data
    })
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else if ([fieldName] == "gallery_id") {
      const _id = this.props.frontGallery[event.target.value].id;
      this.setState({
        [fieldName]: _id,
        gallery_index: event.target.value,
        formIsHalfFilledOut: true
      })
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  componentDidMount() {
    if (isEmptyObj(this.props.frontGallery)) {
      this.props.getFrontGallery();
    }
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

  }
  // loadProgressBar();
  // axios.get(GET_GALLERIES)
  //   .then(res => {
  //     const getRes = res.data;
  //     this.setState({
  //       galleries: getRes,
  //       errorMessages: getRes.message
  //     });
  //     //console.log(this.state.galleries);
  //   }).catch((error) => {
  //     // error
  //   })
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    loadProgressBar();
    //e.preventDefault();
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }
    const form_obj = {
      title: this.state.title,
      gallery_id: this.state.gallery_id,
      isActive: this.state.isActive,
      gallery_img: this.state.gallery_img
    }
    const obj = { ...form_obj, ...default_obj }
    // console.log(JSON.stringify(obj));
    this.props.createFrontImages(obj);
    // axios.post(CREATE_GALLERY, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       medium: '',
    //       title: '',
    //       gallery_img: '',
    //       gallery_id: '',
    //       isActive: true,
    //       formIsHalfFilledOut: false
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.frontImages) {
      this.setState({
        medium: '',
        title: '',
        gallery_img: '',
        gallery_id: '',
        isActive: true,
        formIsHalfFilledOut: false
      })
    }
  }

  render() {
    const { isActive, gallery_index, selected_school_index, formIsHalfFilledOut, title, gallery_img, crop, final_size } = this.state;
    const { user, frontGallery, schools, frontImages } = this.props;
    console.log(this.state);
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Image(s)</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Add Gallery</div>
        </div>
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Image
          </div>
          <div className="card-body">
            {user && frontGallery && schools &&
              <div className="row">
                {(user.user_category === "1") &&
                  <div className="col-sm-2">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }
                <div className="col-sm-4">
                  <div className="form-group row">
                    <label className="control-label col-3">Image
                      </label>
                    <div className="form-input col-9">
                      <MyImage
                        //callbackFromParent={this.myCallback}
                        cropComplete={this.onComplete}
                        crop={crop}
                        final_size={final_size}
                      />
                      {gallery_img !== '' ?
                        <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + gallery_img} />
                        : null}
                    </div>
                  </div>
                </div>
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="control-label">Image Title
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="title" placeholder="Gallery Title"
                        className="form-control form-control-sm"
                        autoComplete="off"
                        //required
                        value={title}
                        onChange={event => this.changeHandler(event, 'title')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Gallery Title
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        value={gallery_index}
                        onChange={event => this.changeHandler(event, 'gallery_id')}>
                        <option >Select ...</option>
                        {frontGallery.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.title}</option>
                          )
                        })}

                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-2a">
                  <div className="form-group">
                    <label className="control-label">Is Active
                      </label>
                    <div className="form-input">
                      <div className="custom-control custom-checkbox mt-2">
                        <input type="checkbox" className="custom-control-input" id="customCheck2"
                          onChange={event => this.changeHandler(event, 'isActive', true)}
                          checked={isActive} />
                        <label className="custom-control-label" htmlFor="customCheck2">
                          {isActive ? 'Yes' : 'No'}
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-secondary mr-2">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontGallery } = state.frontGallery;
  const { item: frontImages } = state.frontImages;
  const { item: schools } = state.schools;
  return { user, schools, frontGallery, frontImages };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getFrontGallery: frontGalleryActions.getFrontGallery,
  createFrontImages: frontImagesActions.createFrontImages,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddImage));