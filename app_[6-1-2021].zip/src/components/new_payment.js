import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import DatePicker from 'react-date-picker';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { professionalAction, accGroupActions, accLedgerEntryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

class NewPayment extends Component {
  state = {
    schools_arr: [],
    school_id: '',
    expenses_type_id: '',
    selected_school_index: '',
    medium_arr: [],
    transaction_date: new Date(),
    emp_id: '',
    receiver_name: '',
    dr_amo: '',
    description: '',
    professional: [],
    other_receiver: false,
    formIsHalfFilledOut: false,
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  componentDidMount() {
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
  }
 

  paymentDateHandlar = (_date) => {
    this.setState({ transaction_date: _date });
  };
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value })
  };
  selectReceiverCat = (event) => {
    if (event.target.value === "other") {
      this.setState({
        other_receiver: true,
      })
    } else {
      this.setState({
        other_receiver: false,
        emp_id: JSON.parse(event.target.value).id,
        receiver_name: JSON.parse(event.target.value).emp_name
      })
    }
  }
  submitHandler = e => {
    //e.preventDefault();
    const _state = this.state;
    const obj = {
      action : 'indirect_expenses',
      transaction_date: _state.transaction_date,
      party_id: _state.emp_id,
      expenses_id: _state.expenses_type_id,
      party_name: _state.receiver_name,
      dr_amo: _state.dr_amo,
      description: _state.description,
    }
    console.log(JSON.stringify(obj));
    this.props.createIncomeExpenditure(obj)
    // axios.post(CREATE_PAYMENT, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes);
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       transaction_date: new Date(),
    //       emp_id: '',
    //       receiver_name: '',
    //       dr_amo: '',
    //       description: '',
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  expensesCategoryHandler = (event) => {
    this.setState({
      other_receiver: (event.target.value === "other") ? true : false,
    })
  }

  render() {
    const { formIsHalfFilledOut, transaction_date, other_receiver,
      receiver_name, dr_amo, description } = this.state;
    const { accGroup, user, professional } = this.props;
    console.log(this.state)
    return (
      <div className="page-child">
        <Helmet>
          <title>New Payment</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            New Payment
          </div>
          {user && professional &&
            <div className="card-body" >
              <div className="row" >
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Date
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <DatePicker
                        onChange={this.paymentDateHandlar}
                        value={transaction_date}
                        showLeadingZeroes={true}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Type
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        onChange={event => this.expensesCategoryHandler(event)}>
                        <option value={'salary'}>Salary</option>
                        <option value={'other'}>Other</option>
                      </select>
                    </div>
                  </div>
                </div>
                {other_receiver ?
                  <div className="col-sm-2">
                    {accGroup &&
                      <div className="form-group">
                        <label className="control-label">Expenses Type
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'expenses_type_id')}>
                            <option>Select...</option>
                            {accGroup.map((item, index) => {
                              return (
                                <option key={index} value={item.id}>{item.expenses_type}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                    }
                  </div>
                  : null}

                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Receiver Name
                        <span className="required"> * </span>
                    </label>
                    {other_receiver ?
                      <div className="form-input">
                        <input type="text" name="receiver_name"
                          value={receiver_name}
                          onChange={event => this.changeHandler(event, 'receiver_name')}
                          placeholder="Receiver Name" className="form-control form-control-sm" />
                      </div>
                      :
                      <div className="form-input">
                        <select
                          className="form-control form-control-sm" name="select"
                          //value={receiver_name}
                          onChange={this.selectReceiverCat}>
                          <option value>Select...</option>
                          {professional.map((option, index) => {
                            return (
                              <option key={index} value={JSON.stringify(option)}>{option.emp_name}</option>
                            )
                          })}
                        </select>
                      </div>
                    }
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Amount
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="number" name="dr_amo"
                        placeholder="Amount in INR"
                        value={dr_amo}
                        onChange={event => this.changeHandler(event, 'dr_amo')}
                        className="form-control form-control-sm" />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Payment Details
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="description"
                        placeholder="description"
                        value={description}
                        onChange={event => this.changeHandler(event, 'description')}
                        className="form-control form-control-sm" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          }
          <div className="card-footer">
            <div className="form-actions  text-right">
              <button type="submit" className="btn btn-secondary mr-2">Submit</button>
              <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
                Cancel
            </button>
            </div>
          </div>
        </form>
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: professional } = state.professional;
  const { item: accGroup } = state.accGroup;
  // const { item: incomeExpenditure } = state.incomeExpenditure;
  return { user, professional, accGroup};
}

const actionCreators = {
  getProfessional: professionalAction.getProfessional,
  getAccGroup: accGroupActions.getAccGroup,
  // createIncomeExpenditure: accLedgerEntryActions.createIncomeExpenditure,
}

export default connect(mapStateToProps, actionCreators)(withRouter(NewPayment));