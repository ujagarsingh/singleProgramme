import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Picky } from 'react-picky';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import SingleShedule from './single_shedule';
import { connect } from 'react-redux';
import {
   schoolsAction, examSdulNotesAction, examSdulAction,
   examsCategoryAction, classWiseSubDetailsAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
// const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class CreateExamShedule extends Component {
   state = {
      innings_sub: [
         { inning_name: "FIRST INNING", subject: "" }
      ],
      showInningsData: false,
      showSheduleData: false,
      showNotesData: false,
      shedule_obj: {
         classes_shedule: [],
         school_info: {},
         shedule_note: [],
         identity_card_note: [],
         innings: [
            { inning_name: "I", inning_time: "9:00 AM to 12:15 PM" },
            { inning_name: "II", inning_time: "12:45 PM to 4:00 PM" }
         ],
         exam_name: '',
         classes: [],
         updated_subjects: [],
      },
      notes: [],
      selected_subject_temp: '',
      final_shedule: '',
      subjects: [],
      shedule_date: "",
      schools: [],
      school_name: '',
      medium: '',
      medium_arr: [],
      exams: [],
      selected_exams: [],
      current_inning_inx: '',
      inn_name: '',
      inn_time: '',
      exam_name: '',
      current_exam_inx: '',
      exam_id: '',
      formIsHalfFilledOut: false,
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      // if (fieldName === 'school') {
      //    const _inx = event.target.value;
      //    const _shedule_obj = this.state.shedule_obj;
      //    const _school_info = (!isEmpty(_inx)) ? this.props.schools[_inx] : '';
      //    const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      //    const _sch_name = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_name : '';
      //    const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      //    sessionStorage.setItem("school_id", _sch_id);
      //    this.filterExamsCategoriesHandler(_sch_id);

      //    _shedule_obj['school_info'] = _school_info;
      //    _shedule_obj['updated_subjects'] = [];
      //    _shedule_obj['classes'] = [];

      //    this.setState({
      //       school_id: _sch_id,
      //       school_name: _sch_name,
      //       medium_arr: _medium,
      //       medium: (_medium.length === 1 ? _medium[0] : ''),
      //       selected_school_index: _inx,
      //       exam_name: '',
      //       current_exam_inx: '',
      //       exam_id: '',
      //       shedule_obj: _shedule_obj,
      //    })
      // } else 
      if (fieldName === 'current_exam') {
         const _examIdx = event.target.value;
         const _shedule_obj = this.state.shedule_obj;
         if (_examIdx !== '') {
            const _exam_id = this.state.selected_exams[_examIdx].id;
            const _exam_name = this.state.selected_exams[_examIdx].cat_name;
            _shedule_obj['exam_name'] = _exam_name;
            this.setState({
               exam_name: _exam_name,
               current_exam_inx: _examIdx,
               exam_id: _exam_id,
               shedule_obj: _shedule_obj
            }, () => { this.getClassWiseSubject() })

         } else {
            this.setState({
               exam_name: '',
               current_exam_inx: '',
               exam_id: ''
            })
         }
      } else if (fieldName === 'innings') {
         const _examIdx = event.target.value;
         this.setState({
            current_inning_inx: _examIdx
         })
      } else if (fieldName === 'show_inning') {
         this.setState({
            showInningsData: !this.state.showInningsData
         })
      } else if (fieldName === 'show_shedule') {
         this.setState({
            showSheduleData: !this.state.showSheduleData
         })
      } else if (fieldName === 'select_subject') {
         const _subjectIdx = event.target.value;
         const _class_inx = event.target.getAttribute('class_data');
         const _inning_inx = event.target.closest(".data_row").getAttribute('data_row');
         const _date_inx = event.target.closest(".data_date_row").getAttribute('data_date_row');
         // this.dataUpdatedSubjectsHndlar(_date_inx, _inning_inx, _class_inx, _subjectIdx);
         // this.updateSheduleForShow();
      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
            formIsHalfFilledOut: true
         });
      }
   }
   dataUpdatedSubjectsHndlar(date_inx, inning_inx, class_inx, inning_sub) {
      const _shedule_obj = this.state.shedule_obj;
      const _updated_subject = _shedule_obj.updated_subjects;
      const final_innings = _updated_subject.map((date_item, d_inx) => {
         // console.log(_updated_subject);
         if (parseInt(date_inx) === d_inx) {
            const new_date_item = date_item.innings.map((inn_item, i_idx) => {
               // console.log(inn_item);
               if (parseInt(inning_inx) === i_idx) {
                  const new_inn_item = inn_item.class_subject.map((class_item, c_idx) => {
                     // console.log(class_item);
                     if (parseInt(class_inx) === c_idx) {
                        class_item['selected_sub'] = inning_sub;
                        class_item['selected_sub_inx'] = c_idx;
                        return class_item;
                     } else {
                        return class_item;
                     }
                  })
                  return { ...inn_item, class_subject: new_inn_item };
               } else {
                  return inn_item;
               }
            })
            return { ...date_item, innings: new_date_item };
         } else {
            return date_item;
         }
      })
      // console.log(final_innings);
      _shedule_obj.updated_subjects = final_innings;
      this.setState({
         updated_subjects: _shedule_obj
      })
   }
   dataUpdatedSubjectsOnClassHndlar(date_inx, inning_inx, class_inx, inning_sub) {
      const _shedule_obj = this.state.shedule_obj;
      const _classes_shedule = _shedule_obj.classes_shedule;
      // console.log(_classes_shedule);
      // debugger
      const final_innings = _classes_shedule.map((class_item, d_inx) => {
         if (parseInt(class_inx) === d_inx) {
            const new_date_item = class_item.innings_arr.map((inn_item, i_idx) => {
               // console.log(inn_item);
               /* {x_exam_subject : 
                     {
                        exam_date: Fri Mar 06 2020 00:00:00 GMT+0530 (India Standard Time) {}
                        innings: (2) [{…}, {…}]
                     }
                  }*/
               // debugger
               if (parseInt(date_inx) === i_idx) {
                  const new_inn_item = inn_item.x_exam_subject.innings.map((child_inn, c_idx) => {
                     //console.log(child_inn);
                     if (parseInt(inning_inx) === c_idx) {
                        child_inn = { ...child_inn, selected_sub: inning_sub };
                        return child_inn;
                     } else {
                        return child_inn;
                     }
                  })
                  const inning_item_q =
                  {
                     exam_date: inn_item.x_exam_subject.exam_date,
                     innings: new_inn_item
                  }

                  inn_item = { ...inn_item, x_exam_subject: inning_item_q };
                  // console.log(inn_item)

                  //debugger
                  return inn_item;
               } else {
                  return inn_item;
               }

            })
            return { ...class_item, innings_arr: new_date_item };
         } else {
            return class_item;
         }
      })
      // console.log(final_innings);
      _shedule_obj.classes_shedule = final_innings;
      this.setState({
         shedule_obj: _shedule_obj
      })
   }
   filterExamsCategoriesHandler() {
      const _filter = this.props.filteredSchoolData;
      let _school_id = _filter.slct_school_id;
      const _exams_cate = this.props.examsCategory.filter((item) => {
         if (_school_id === item.school_id) {
            return item;
         }
      })
      this.setState({
         selected_exams: _exams_cate
      })
   }

   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.examSdulNotes)) {
         this.props.getExamSdulNotes();
      }
      if (isEmptyObj(this.props.examsCategory)) {
         this.props.getExamsCategory();
      }
      if (isEmptyObj(this.props.examSdul)) {
         this.props.getExamSdul();
      }

      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         const _all_exams = this.props.exams;
         if (_all_exams && _filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   componentWillReceiveProps(nextProps) {
      if (nextProps.classWiseSubDetailsForShedule) {
         const subDetails = nextProps.classWiseSubDetailsForShedule;
         this.setState({
            subDetails: subDetails
         }, () => {
            this.getClassObj();
            this.addNewRow();
         })
      } else if (nextProps.exams) {
         setTimeout(() => {
            this.filterBySchoolHandler()
         }, 100);
      }
   }


   filterBySchoolHandler = () => {
     // const _filter = this.props.filteredSchoolData;

      this.filterShedulesOnSchool();
      this.filterExamsCategoriesHandler();
      // this.filterByClsHandler()
   }
   filterShedulesOnSchool(){

   }

   //  filterByClsHandler = () => {
   //    const _fltr_school = this.props.filteredSchoolData;
   //    const _fltr_class = this.props.filteredClassesData;

   //  }

   // checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //             }, () => {
   //                this.getSchoolHandler();
   //                this.getExamsCategories();
   //                this.getSheduleNotes();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }

   // getSheduleNotes() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //       exam_id: this.state.exam_name,
   //    }
   //    // console.log(JSON.stringify(obj));
   //    // debugger;
   //    axios.post(READ_SDUL_NOTE, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          let _notes = [];
   //          getRes.forEach((item) => {
   //             _notes.push({ "note": item.notes })
   //          })
   //          this.setState({
   //             notes: _notes,
   //             // updated_subjects: [...this.state.updated_subjects, getRes],
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   getClassWiseSubject() {
      loadProgressBar();
      const obj = {
         // group_id: this.state.group_id,
         school_id: this.props.filteredSchoolData.slct_school_id,
         // user_category: this.state.user_category,
         // session_year_id: this.state.session_year_id,
         exam_name: this.state.exam_name,
      }
      // console.log(JSON.stringify(obj));
      this.props.getSujectDetailsForSdul(obj);

      // axios.post(READ_SUBJECTS, obj)
      //    .then(res => {
      //       const getRes = res.data;
      //       this.setState({
      //          subjects: getRes,
      //          // updated_subjects: [...this.state.updated_subjects, getRes],
      //          errorMessages: getRes.message
      //       }, () => {
      //          this.getClassObj();
      //          this.addNewRow();
      //       })
      //       // console.log(this.state);
      //    }).catch((error) => {
      //       // error
      //    })
   }

   // getExamsCategories() {
   //    loadProgressBar();
   //    axios.get(READ_EXAM_CATE)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             exams: getRes,
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   addItemToState = (e) => {
      e.preventDefault();
      this.props.addTodo({
         text: this.refs.addtodo.value
      })
      this.refs.addtodo.value = ''
   };

   getClassObj() {
      const _exam_subject = this.state.subDetails;
      const _shedule_obj = this.state.shedule_obj;
      let _new_class_arr = [];
      // debugger;
      _exam_subject.innings[0].class_subject.forEach((item) => {
         _new_class_arr = [..._new_class_arr, { 'id': item.id, 'class_name': item.class_name }]
      })
      // console.log(_new_class_arr);
      _shedule_obj['classes'] = _new_class_arr;
      _shedule_obj['classes_shedule'] = _new_class_arr;
      _shedule_obj['classes_shedule'].forEach((item) => {
         item['innings_arr'] = []
      })
      this.setState({
         shedule_obj: _shedule_obj
      })
   }
   addInnings(ev) {
      // debugger
      ev.preventDefault();
      const _exam_subject = this.state.subjects;
      const _update = [...this.state.updated_subjects, _exam_subject];

      this.setState({
         updated_subjects: _update
      })
   }
   addNewRow() {
      // ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const _innings = _shedule_obj.innings;
      const _exam_subject = this.state.subDetails;
      let count_innings = []
      for (let x = 0; x < _innings.length; x++) {
         const new_exam_subject = JSON.parse(JSON.stringify(_exam_subject.innings[0]));
         new_exam_subject['inning'] = _innings[x].inning_name;
         new_exam_subject['inning_time'] = _innings[x].inning_time;
         count_innings.push(new_exam_subject);
      }
      const n_exam_subject = {
         exam_date: "",
         holiday: false,
         reason: "",
         innings: count_innings
      }
      const newInning = {
         x_exam_subject: {
            exam_date: "",
            innings: _innings
         }
      }
      _shedule_obj.updated_subjects = [..._shedule_obj.updated_subjects, n_exam_subject]
      _shedule_obj.classes_shedule.forEach((item) => {
         item.innings_arr.push(newInning)
      })

      this.setState({
         shedule_obj: _shedule_obj
      })
   }
   removeRow(ev, inx) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const classes_shedule = _shedule_obj.classes_shedule;
      if (update_subjects.length > 1) {
         const _update_subjects = update_subjects.filter((item, index) => {
            if (index != inx) {
               return item
            }
         })
         const _classes_shedule = classes_shedule.map((item) => {
            const _inning_arr = item.innings_arr.filter((inn_item, indx) => {
               if (indx != inx) {
                  return inn_item
               }
            })
            return item = { ...item, innings_arr: _inning_arr }
         })
         _shedule_obj.updated_subjects = _update_subjects;
         _shedule_obj.classes_shedule = _classes_shedule;
         this.setState({
            updated_subjects: _shedule_obj
         })
      } else {
         Alert.warning("This is Last Inning.!!", {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
         });
      }
   }

   dayTypeHandler(ev, inx) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === inx) {
            return item = {
               ...item,
               holiday: !item.holiday
            }
         } else {
            return item;
         }
      })
      _shedule_obj.updated_subjects = _update_subjects
      this.setState({
         updated_subjects: _shedule_obj
      })
   }

   formatAMPM(date) {
      // const hours = date.getHours();
      // const minutes = date.getMinutes();
      let hours = parseInt(date.split(":")[0]);
      let minutes = parseInt(date.split(":")[1]);
      let ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0' + minutes : minutes;
      let strTime = hours + ':' + minutes + ' ' + ampm;
      return strTime;
   }
   addInningHandler(ev) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const inn_name = this.state.inn_name;
      const inn_time = this.state.inn_time;
      const inn_subject = "";
      const newInning = { inning_name: inn_name, inning_time: inn_time, inn_subject: inn_subject }
      _shedule_obj.innings.push(newInning);
      this.setState({
         //innings: [...this.state.innings, newInning],
         inn_name: "",
         inn_time: "",
         shedule_obj: { ...this.state.shedule_obj, updated_subjects: [] },
      }, () => {
         // this.updatedSubjectsHndlar();
         this.addNewRow();
      })
   }
   removeEnning(ev) {
      ev.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  const inx = parseInt(this.state.current_inning_inx);
                  const _shedule_obj = this.state.shedule_obj;
                  const updateInnings = _shedule_obj.innings.filter((item, idx) => {
                     if (idx != inx) {
                        return item
                     }
                  })
                  _shedule_obj.innings = updateInnings;
                  _shedule_obj.updated_subjects = [];

                  this.setState({
                     current_inning_inx: '',
                     shedule_obj: _shedule_obj
                  }, () => {
                     this.addNewRow();
                  })
               }
            },
            {
               label: 'No',
            }
         ]
      });

   }

   getSubjectSlectionGroup(inn_item) {
      const _inn_item = inn_item;
      // debugger
      let final_subject =
         <table>
            <tbody>
               <tr>
                  {_inn_item.class_subject.map((item_e, idex) => {
                     return (this.getSubjectSlection(item_e, idex))
                  })}
               </tr>
            </tbody>
         </table>
      return final_subject;
   }
   classWiseSubjectHandlaer = (value) => {
      // console.count('onChange');
      const _this = window.event.target;
      const _date_elem = _this.closest('.date_indx');
      const _inning_elem = _this.closest('.inning_indx');
      const _class_elem = _this.closest('.class_idex');
      const _date_index = _date_elem.getAttribute('date_indx');
      const _inning_indx = _inning_elem.getAttribute('inning_indx');
      const _class_idex = _class_elem.getAttribute('class_idex');
      this.dataUpdatedSubjectsHndlar(_date_index, _inning_indx, _class_idex, value); // for all class
      this.dataUpdatedSubjectsOnClassHndlar(_date_index, _inning_indx, _class_idex, value); // for single class
      this.updateSheduleForShow();
   }
   getSubjectSlection(_obj, inx) {
      const _class_id = _obj.id;
      const _obj_inx = inx;
      const _ref_id = _obj_inx + '_' + _class_id;
      const subjects = _obj.subject_arr;
      const _selected_sub = _obj.selected_sub;
      const _all_subject = [];
      subjects.forEach((item) => {
         if (item.child && item.child.length > 0) {
            item.child.map((item_s) => {
               _all_subject.push(item.sub_name + ' (' + item_s.sub_name + ")")
            })
         } else {
            _all_subject.push(item.sub_name)
         }
      })
      // console.log(_all_subject);
      // debugger
      return (
         <td key={inx} class_idex={inx} className="class_idex p-0">
            <div className="d-flex">
               <Picky
                  value={_selected_sub}
                  options={_all_subject}
                  onChange={this.classWiseSubjectHandlaer}
                  open={false}
                  valueKey={"id_" + inx}
                  labelKey={"name" + inx}
                  multiple={true}
                  includeSelectAll={false}
                  includeFilter={false}
                  dropdownHeight={200}
               />
               <button type="button"
                  className="btn btn-primary btn-sm">
                  <i className="fas fa-check"></i>
               </button>
            </div>
            {/* <select class_data={inx} className="form-control form-control-sm"
                     // value={selected_sub_inx}
                     onChange={event => this.changeHandler(event, 'select_subject')}>
                     <option value="">...</option>
                     {subjects.map((item, index) => {
                        // console.log(item);
                        return (
                           (item.child && item.child.length > 0) ?
                              <optgroup key={index} label={item.sub_name}>
                                 {item.child.map((item_s, idx) => {
                                    return <option key={idx} value={item.sub_name + ' (' + item_s.sub_name + ")"}>
                                       {item.sub_name + ' (' + item_s.sub_name + ")"}
                                    </option>
                                 })}
                              </optgroup>
                              :
                              <option key={index} value={item.sub_name}>{item.sub_name}</option>
                        )
                     })}
                  </select>
            */}
         </td>
      )
   }
   holidayHandler(ev, index) {
      ev.preventDefault();
      const _shedule_obj = this.state.shedule_obj;
      const holiText = ev.target.value.toUpperCase();
      const update_subjects = _shedule_obj.updated_subjects;
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === index) {
            return item = {
               ...item,
               reason: holiText
            }
         } else {
            return item;
         }
      })
      _shedule_obj.updated_subjects = _update_subjects;

      this.setState({
         shedule_obj: _shedule_obj
      })
   }

   examDateHandler = (feeDate, index) => {
      const _shedule_obj = this.state.shedule_obj;
      const update_subjects = _shedule_obj.updated_subjects;
      const classes_shedule = _shedule_obj.classes_shedule;
      const _classes_shedule = classes_shedule.map((item, idx) => {
         const _innings_arr = item.innings_arr.map((class_item, inex) => {
            if (inex === index) {
               class_item.x_exam_subject.exam_date = feeDate;
               return class_item;
            }
            else {
               return class_item
            }
         })
         return item = { ...item, innings_arr: _innings_arr }
      })
      const _update_subjects = update_subjects.map((item, idx) => {
         if (idx === index) {
            return item = { ...item, exam_date: feeDate }
         } else {
            return item;
         }
      })
      // const _shedule_obj = this.state.shedule_obj;
      // _shedule_obj.updated_subjects = [..._shedule_obj.updated_subjects, _update_subjects]
      _shedule_obj.updated_subjects = _update_subjects;
      _shedule_obj.classes_shedule = _classes_shedule;
      this.setState({
         shedule_date: feeDate,
         shedule_obj: { ...this.state.shedule_obj, updated_subjects: _update_subjects }
      })
   };
   confirmBoxDelete = (event, id) => {
      event.preventDefault();
      let del_id = id;
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to delete this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.deleteHandlar(del_id);
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   updateSheduleForShow() {
      const _shedule_obj = this.state.shedule_obj;

      const final_obj = _shedule_obj.updated_subjects.filter((item, inx) => {
         if (!isEmpty(item.exam_date)) {
            const final_inn = item.innings.map((inn_item) => {

               const final_class = inn_item.class_subject.map((class_item) => {
                  class_item = { ...class_item, subject_arr: [] };
                  return class_item;
               })

               inn_item = { ...inn_item, class_subject: final_class };
               return inn_item;
            })

            item = { ...item, innings: final_inn }
            return item;
         }
      })
      const _final_shedule = { ..._shedule_obj, updated_subjects: final_obj };
      this.setState({
         final_shedule: _final_shedule
      })
   }
   saveInDatabase(ev) {
      ev.preventDefault();
      loadProgressBar();
      const obj = {
         // group_id: this.state.group_id,
         school_id: this.state.school_id,
         medium: this.state.medium,
         // user_category: this.state.user_category,
         // ses_year: this.state.session_year_id,
         exam_id: this.state.exam_id,
         shedule: JSON.stringify(this.state.final_shedule),
      }
      console.log(JSON.stringify(obj));
      this.props.createSdul(obj);
      // axios.post(CREATE_SEDUL, obj)
      //    .then(res => {
      //       const getRes = res.data;
      //       if (!isEmpty(getRes.message)) {
      //          Alert.success(getRes.message, {
      //             position: 'bottom-right',
      //             effect: 'jelly',
      //             timeout: 5000, offset: 40
      //          });
      //       }
      //       // console.log(this.state);
      //    }).catch((error) => {
      //       // error
      //    })
   }

   getConvertedDay(str) {
      var currnt_date = new Date(str);
      let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      // var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      // return months[this.getMonth()];
      return days[currnt_date.getDay()].toUpperCase();
   }

   render() {
      const { final_shedule, notes, showSheduleData, showInningsData, shedule_obj, selected_exams,
         selected_school_index, school_name, medium_arr, current_exam_inx,
         current_inning_inx, inn_name, inn_time, medium, formIsHalfFilledOut } = this.state;
      const { user, schools, examSdulNotes, examSdul, examsCategory } = this.props;
      // console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Create Exam Schedule</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            {user && schools && examSdulNotes && examSdul && examsCategory &&
               <>
                  <div className="page-bar d-flex">
                     <div className="page-title">Create Exam Schedule</div>
                     <div className="form-inline ml-auto filter-panel">
                        <span className="filter-closer">
                           <button type="button" className="btn btn-danger filter-toggler-c">
                              <i className="fa fa-times"></i>
                           </button>
                        </span>
                        <div className="filter-con">
                           {/* {(user.user_category === "1") ?
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    value={selected_school_index}
                                    onChange={event => this.changeHandler(event, 'school')}>
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                              : null}
                           <div className="form-group mr-2 mt-1">
                              <label className="control-label mr-2">Medium :</label>
                              <select className="form-control form-control-sm"
                                 required
                                 ref='medium'
                                 disabled={medium_arr.length > 1 ? false : true}
                                 value={medium}
                                 onChange={event => this.changeHandler(event, 'medium')}>
                                 <option value="">Select ...</option>
                                 {medium_arr.map((item, index) => {
                                    return (
                                       <option key={index} value={item}>{item}</option>
                                    )
                                 })}
                              </select>
                           </div>
                            */}
                           <CommonFilters
                              showSchoolFilter={true}
                              showMediumFilter={false}
                              showClassFilter={false}
                              filterBySchoolHandler={this.filterBySchoolHandler}
                           // filterByClsHandler={this.filterByClsHandler}
                           />
                           <div className="form-group mt-1">
                              <label className="mr-2">Exam:</label>
                              <select
                                 value={current_exam_inx}
                                 // disabled={school_name === '' ? true : false}
                                 className="form-control form-control-sm" name="current_exam"
                                 onChange={event => this.changeHandler(event, 'current_exam')} >
                                 <option value="">Select...</option>
                                 {selected_exams.map((option, index) => {
                                    return (<option key={index} value={index}>{option.cat_name}</option>)
                                 })}
                              </select>
                           </div>
                        </div>
                     </div></div>
                  <div className="card card-box sfpage-cover">
                     <div className="card-body sfpage-body">
                        {showInningsData ?
                           <div className="bg-light d-flex mb-1">
                              <div className="form-inline">
                                 <div className="form-group p-1">
                                    <div className="input-group">
                                       <select className="form-control form-control-sm"
                                          ref="innList"
                                          onChange={event => this.changeHandler(event, 'innings')}>
                                          <option value="">Select ...</option>
                                          {shedule_obj.innings.map((item, index) => {
                                             return (
                                                <option key={index} value={index}>{item.inning_name} [{item.inning_time}]</option>
                                             )
                                          })}
                                       </select>
                                       <button type="button" className="btn btn-danger btn-sm"
                                          disabled={current_inning_inx !== "" ? false : true}
                                          onClick={event => this.removeEnning(event)}>
                                          Delete
                                 </button>
                                    </div>
                                 </div>
                              </div>
                              <form className="form-inline ml-auto" onSubmit={event => this.addInningHandler(event)}>
                                 <div className="form-group mt-1">
                                    <label className="p-2">Inning Name</label>
                                    <div className="input-group">
                                       <input type="text"
                                          value={inn_name}
                                          onChange={event => this.changeHandler(event, 'inn_name')}
                                          className="form-control form-control-sm" />
                                    </div>
                                 </div>
                                 <div className="form-group mt-1">
                                    <label className="p-2" >Time</label>
                                    <div className="input-group">
                                       <div className="input-group-prepend">
                                          <div className="input-group-text"><i className="fa fa-clock"></i></div>
                                       </div>
                                       <input type="text"
                                          value={inn_time}
                                          onChange={event => this.changeHandler(event, 'inn_time')}
                                          className="form-control form-control-sm" />
                                    </div>
                                 </div>
                                 <div className="form-group mr-1">
                                    <button type="submit"
                                       disabled={(inn_name !== "" && inn_time !== "") ? false : true}
                                       className="btn btn-primary btn-sm ml-2">Add Inning</button>
                                 </div>
                              </form>

                           </div>
                           : null}
                        <div className="table-scrollable">
                           <table className="table table-striped table-bordered table-hover table-sm" id="timeSchedule">
                              <thead className="bg-light text-secondary">
                                 <tr>
                                    <th className="w-auto"></th>
                                    <th className="w-date">Date</th>
                                    <th className="w-inning text-center">Innings</th>
                                    {shedule_obj.classes.map((item, index) => {
                                       return <th key={index}>{item.class_name}</th>
                                    })}
                                 </tr>
                              </thead>
                              {shedule_obj.updated_subjects.length > 0 ?
                                 <tbody>
                                    {shedule_obj.updated_subjects.map((inn_item, day_inx) => {
                                       return (
                                          <tr date_indx={day_inx} key={day_inx} className={(inn_item.holiday === false) ? 'date_indx data_date_row' : 'table-warning date_indx data_date_row'}>
                                             <td className="w-auto">{day_inx + 1}.</td>
                                             <td className="w-date data_date">
                                                {/* <input type="text" className="form-control form-control-sm" /> */}
                                                <DatePicker
                                                   onChange={event => this.examDateHandler(event, day_inx)}
                                                   value={inn_item.exam_date}
                                                   showLeadingZeroes={true}
                                                // minDate={shedule_date}
                                                />

                                                <div className="d-flex mt-1">
                                                   {inn_item.exam_date ?
                                                      <div className="mt-1">{this.getConvertedDay(inn_item.exam_date)}</div>
                                                      : null}
                                                   {/* <div onClick={event => this.dayTypeHandler(event, day_inx)}
                                                className="custom-control custom-switch mt-1">
                                                <input type="checkbox"
                                                   defaultChecked={!inn_item.holiday}
                                                   className="custom-control-input" id={`customSwitch` + day_inx} />
                                                <label className="custom-control-label" htmlFor={`customSwitch` + day_inx}>
                                                   {(inn_item.holiday === false) ? 'Working' : 'Holiday'}
                                                </label>
                                             </div> */}
                                                   <div className="btn-group ml-auto">
                                                      <button type="button" onClick={event => this.removeRow(event, day_inx)}
                                                         className="btn btn-outline-danger btn-sm"><i className="fa fa-minus"></i>
                                                      </button>
                                                      <button type="button" onClick={event => this.addNewRow(event)}
                                                         className="btn btn-outline-success btn-sm"><i className="fa fa-plus"></i>
                                                      </button>
                                                   </div>
                                                </div>
                                             </td>
                                             {!isEmpty(inn_item.exam_date) ?
                                                (<td colSpan="13" className="w-auto p-0">
                                                   {!inn_item.holiday ?
                                                      <table>
                                                         <tbody>
                                                            {inn_item.innings.map((item_in, innx) => {
                                                               return (
                                                                  <tr inning_indx={innx} className="inning_indx data_row" key={innx}>
                                                                     <td className="w-inning text-center data_inning_name">{item_in.inning}</td>
                                                                     <td colSpan="12" className="p-0">
                                                                        {this.getSubjectSlectionGroup(item_in)}
                                                                     </td>
                                                                  </tr>
                                                               )
                                                            })}
                                                         </tbody>
                                                      </table>
                                                      : <div className="m-3">
                                                         <input type="text" className="form-control" placeholder="Holiday Reason"
                                                            value={inn_item.reason}
                                                            onChange={event => this.holidayHandler(event, day_inx)}
                                                         />
                                                      </div>
                                                   }
                                                </td>)
                                                : null}
                                          </tr>
                                       )
                                    })}
                                 </tbody>
                                 : null}
                           </table>
                           {showSheduleData ?
                              <SingleShedule
                                 shedule_obj={final_shedule}
                                 notes={notes}
                              />
                              : null
                           }
                        </div>
                     </div>
                     <div className="card-footer d-flex p-2">
                        <button type="button" className="btn btn-warning"
                           onClick={event => this.changeHandler(event, 'show_inning')}>
                           {showInningsData ? "Hide Innings" : "Show Innings"}
                        </button>
                        <button type="button" className="btn btn-warning ml-2"
                           disabled={isEmpty(final_shedule)}
                           onClick={event => this.changeHandler(event, 'show_shedule')}>
                           {showSheduleData ? "Hide Shedule" : "Show Shedule"}
                        </button>
                        <button type="button" className="btn btn-primary ml-auto"
                           onClick={event => this.saveInDatabase(event)}>
                           Save</button>
                     </div>
                  </div >
               </>
            }
         </div >
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: examSdulNotes } = state.examSdulNotes;
   const { item: examSdul } = state.examSdul;
   const { item: examsCategory } = state.examsCategory;
   const { item: classWiseSubDetailsForShedule } = state.classWiseSubDetailsForShedule;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, examSdulNotes, examSdul, examsCategory, classWiseSubDetailsForShedule,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
   getExamsCategory: examsCategoryAction.getExamsCategory,
   getSujectDetailsForSdul: classWiseSubDetailsAction.getSujectDetailsForSdul,
   getExamSdul: examSdulAction.getExamSdul,
   createSdul: examSdulAction.create,

}

export default connect(mapStateToProps, actionCreators)(withRouter(CreateExamShedule));