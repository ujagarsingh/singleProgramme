import { classWiseSubDetailsForAssignConstants } from '../_constants';
import { classWiseSubjectForAssignService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classWiseSubDetailsForAssignAction = {
    getSujectDetailsForAssign, 
};

function getSujectDetailsForAssign() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classWiseSubjectForAssignService.getSujectDetailsForAssign()
            .then(
                response => {
                    dispatch(success(response.data.classes_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_REQUEST } }
    function success(response) { return { type: classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: classWiseSubDetailsForAssignConstants.SUBJECT_DETAILS_FAILURE, error } }
}
 