import React, { Component } from 'react';
//import { Fabric } from 'office-ui-fabric-react/lib/Fabric';
//import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import XLSX from 'xlsx';
//import { make_cols } from './MakeColumns';
import { SheetJSFT } from './types';

class ExcelReader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      file_name: "Choose File",
      file: {},
      data: [],
      cols: [],
      isFile: false
    }
    this.handleFile = this.handleFile.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    const files = e.target.files;
    if (files && files[0]) this.setState({ file: files[0], isFile: true, file_name : files[0].name });
    // debugger
  };

  handleFile() {
    /* Boilerplate to set up FileReader */
    const reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;

    reader.onload = (e) => {
      /* Parse data */
      const bstr = e.target.result;
      const wb = XLSX.read(bstr, { type: rABS ? 'binary' : 'array', bookVBA: true });
      /* Get first worksheet */
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      /* Convert array of arrays */
      const data = XLSX.utils.sheet_to_json(ws);
      /* Update state */
      this.setState({
        data: data,
        /*cols: make_cols(ws['!ref'])*/
      }, () => {
        ////console.log(JSON.stringify(this.state.data, this.xyzFun, 2));
        this.props.studentObjHandler(this.state.data);
      });
    };

    if (rABS) {
      reader.readAsBinaryString(this.state.file);
    } else {
      reader.readAsArrayBuffer(this.state.file);
    };
  }

  xyzFun = (a, b) => {
    if (a === "dob") {
      return b.replace(/(..).(..).(....)/, "$3-$1-$2");
      //return "abc"+b;
    }
    return b;
  }

  render() {
    const { isFile, file_name } = this.state;
    //console.log(this.state);
    return (
      <div className="form-group  m-0">
        <div className="input-group m-0">
          <div className="custom-file">
            <input type="file" className="custom-file-input" id="file" accept={SheetJSFT} onChange={this.handleChange} />
    <label className="custom-file-label" htmlFor="file">{file_name}</label>
          </div>
          <div className="input-group-append p-0">
            <button type='button'
              disabled={!isFile}
              className="btn btn-primary btn-sm"
              onClick={this.handleFile}>
              Process File
              </button>
          </div>
        </div>
      </div>
    )
  }
}

export default ExcelReader;