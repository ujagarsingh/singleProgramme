// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const subjectsService = {
    getSubjects,
    create,
    delete : _delete
};

function getSubjects() {
    loadProgressBar();
    const url = USER_URL + 'subject/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'subject/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'subject/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}