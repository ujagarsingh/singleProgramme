import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';

class DashboardFooter extends Component {
  render() {
    return (
      <div className="page-footer">
        <div className="page-footer-inner"> 2019 © Smart School Managment Software by
        <a href="mailto:ujagar.singh.meena@gmail.com" target="_top">SSM</a>
        </div>
        <div className="sc-to-top">
          <i className="icon-arrow-up" />
        </div>
      </div>
    )
  }
}
export default DashboardFooter;