import { marksObtainConstants } from '../_constants';

export function marksObtain(state = {}, action) {
  switch (action.type) {
    case marksObtainConstants.MARKS_OBTAIN_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case marksObtainConstants.MARKS_OBTAIN_SUCCESS:
      return {
        item: action.response,
      };
    case marksObtainConstants.MARKS_OBTAIN_FAILURE:
      return {
        error: action.error
      };

 
    case marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_SUCCESS:
      return {
        item: action.response,
      };
    case marksObtainConstants.CREATE_MULTIPLE_MARKS_OBTAIN_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}