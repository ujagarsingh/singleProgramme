import { monthlyLessonConstants } from '../_constants';

export function monthlyLesson(state = {}, action) {
  switch (action.type) {
    case monthlyLessonConstants.LESSON_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case monthlyLessonConstants.LESSON_SUCCESS:
      return {
        item: action.response
      };
    case monthlyLessonConstants.LESSON_FAILURE:
      return {
        error: action.error
      };

 
    case monthlyLessonConstants.CREATE_LESSON_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case monthlyLessonConstants.CREATE_LESSON_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case monthlyLessonConstants.CREATE_LESSON_FAILURE:
      return {
        ...state,
        error: action.error
      };
 

    case monthlyLessonConstants.UPDATE_LESSON_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case monthlyLessonConstants.UPDATE_LESSON_SUCCESS:

      const lesson_info = state.item.lesson_info.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      const updated_arr = {...state.item, lesson_info : lesson_info}
      // console.log(updated_arr);
      return {
        item: updated_arr,
        loading: false,
      };

      case monthlyLessonConstants.UPDATE_LESSON_FAILURE:
      return {
        ...state,
        error: action.error
      };
 

    case monthlyLessonConstants.DELETE_LESSON_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case monthlyLessonConstants.DELETE_LESSON_SUCCESS:

      const rest_lessons = state.item.lesson_info.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      })
      const updated_obj = {...state.item, lesson_info : rest_lessons}
      // console.log(updated_obj);
      return {
        item: updated_obj,
        loading: false,
      };

      case monthlyLessonConstants.DELETE_LESSON_FAILURE:
      return {
        ...state,
        error: action.error
      };


    default:
      return state
  }
}