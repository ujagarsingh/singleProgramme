import { defaultImagesConstants } from '../_constants';

export function defaultImages(state = {}, action) {
  switch (action.type) {
    case defaultImagesConstants.IMAGES_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultImagesConstants.IMAGES_SUCCESS:
      return {
        item: action.response
      };
    case defaultImagesConstants.IMAGES_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}