import { sessionYearsConstants } from '../_constants';

export function sessionYears(state = {}, action) {
  switch (action.type) {
    case sessionYearsConstants.SESSION_YEAR_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case sessionYearsConstants.SESSION_YEAR_SUCCESS:
      return {
        item: action.response
      };
    case sessionYearsConstants.SESSION_YEAR_FAILURE:
      return {
        error: action.error
      };




    // case sessionYearsConstants.CREATE_REQUEST:
    //   return {
    //     ...state,
    //     loading: true,
    //     //items : action.users
    //   };
    // case sessionYearsConstants.CREATE_SUCCESS:
    //   const new_arr = (action.response) ?
    //     [action.response, ...state.item] :
    //     [...state.item];
    //   return {
    //     item: new_arr,
    //     loading: false,
    //   };
    // case sessionYearsConstants.CREATE_FAILURE:
    //   return {
    //     ...state,
    //     error: action.error
    //   };



    default:
      return state
  }
}