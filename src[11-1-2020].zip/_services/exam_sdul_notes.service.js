// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const examSdulNotesService = {
    getExamSdulNotes,
    create,
    update,
    delete: _delete
};

function getExamSdulNotes() {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul_notes/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul_notes/create.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul_notes/update.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul_notes/delete.php';
    return Axios.post(url, { ...authHeader(), ...obj }).then()
}
