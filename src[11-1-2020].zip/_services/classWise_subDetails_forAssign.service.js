// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const classWiseSubjectForAssignService = {
    getSujectDetailsForAssign,
};

function getSujectDetailsForAssign() {
    loadProgressBar();
    const url = USER_URL + 'subject/read_assignable_subject_n_class.php';
    return Axios.post(url,  authHeader() ).then()
}

