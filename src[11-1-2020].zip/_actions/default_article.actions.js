import { defaultArticleConstants } from '../_constants';
import { defaultArticleService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultArticleActions = {
    getDefaultArticle
};

function getDefaultArticle() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultArticleService.getDefaultArticle()
            .then(
                response => {
                    dispatch(success(response.data.article_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request(obj) { return { type: defaultArticleConstants.ARTICLE_REQUEST, obj } }
    function success(response) { return { type: defaultArticleConstants.ARTICLE_SUCCESS, response } }
    function failure(error) { return { type: defaultArticleConstants.ARTICLE_FAILURE, error } }
}
 