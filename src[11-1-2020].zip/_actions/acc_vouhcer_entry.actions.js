import { accVoucherEntryConstants } from '../_constants';
import { accVoucherEntry } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accVoucherEntryActions = {
    getAccVoucherEntry,
    createAccVoucherEntry,
    createAccSalaryVoucherEntry,
    update,
    delete : _delete
};

function getAccVoucherEntry() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherEntry.getAccVoucherEntry()
            .then(
                response => {
                    dispatch(success(response.data.entry_detail_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accVoucherEntryConstants.VOUCHER_ENTRY_REQUEST } }
    function success(response) { return { type: accVoucherEntryConstants.VOUCHER_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accVoucherEntryConstants.VOUCHER_ENTRY_FAILURE, error } }
}
 

function createAccVoucherEntry(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherEntry.createAccVoucherEntry(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_REQUEST } }
    function success(response) { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_FAILURE, error } }
}

function createAccSalaryVoucherEntry(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherEntry.createAccSalaryVoucherEntry(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_REQUEST } }
    function success(response) { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherEntry.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_REQUEST } }
    function success(response) { return { type: accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accVoucherEntry.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_REQUEST } }
    function success(response) { return { type: accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_SUCCESS, response } }
    function failure(error) { return { type: accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_FAILURE, error } }
}
