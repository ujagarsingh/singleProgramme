import { examSdulNotesConstants } from '../_constants';
import { examSdulNotesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examSdulNotesAction = {
    getExamSdulNotes,
    create,
    update,
    delete : _delete
};

function getExamSdulNotes() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulNotesService.getExamSdulNotes()
            .then(
                response => {
                    dispatch(success(response.data.innings_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulNotesConstants.EXAM_SDUL_NOTES_REQUEST } }
    function success(response) { return { type: examSdulNotesConstants.EXAM_SDUL_NOTES_SUCCESS, response } }
    function failure(error) { return { type: examSdulNotesConstants.EXAM_SDUL_NOTES_FAILURE, error } }
}

function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulNotesService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulNotesConstants.CREATE_REQUEST } }
    function success(response) { return { type: examSdulNotesConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: examSdulNotesConstants.CREATE_FAILURE, error } }
}

function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulNotesService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulNotesConstants.UPDATE_REQUEST } }
    function success(response) { return { type: examSdulNotesConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: examSdulNotesConstants.UPDATE_FAILURE, error } }
}

function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examSdulNotesService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                        );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examSdulNotesConstants.DELETE_REQUEST } }
    function success(response) { return { type: examSdulNotesConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: examSdulNotesConstants.DELETE_FAILURE, error } }
}
