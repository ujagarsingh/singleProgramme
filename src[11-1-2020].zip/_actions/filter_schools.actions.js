import { filterConstants } from '../_constants';
// import { classesService } from '../_services';
// import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const filterSchoolsActions = {
    filterSchools,
    filterClasses
};

function filterSchools(obj) {
    return dispatch => {
        dispatch(request(obj));
    };
    function request() { return { type: filterConstants.FILTER_SCHOOLS_REQUEST, obj } }
}

function filterClasses(obj) {
    return dispatch => {
        dispatch(request(obj));
    };
    function request() { return { type: filterConstants.FILTER_CLASSES_REQUEST, obj } }
}
