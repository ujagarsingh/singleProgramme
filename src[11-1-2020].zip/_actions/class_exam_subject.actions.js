import { classExamSubjectConstants } from '../_constants';
import { classExamSubjectService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const classExamSubjectAction = {
    getClassExamSubject
};

function getClassExamSubject() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        classExamSubjectService.getClassExamSubject()
            .then(
                response => {
                    dispatch(success(response.data.class_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: classExamSubjectConstants.CLASS_EXAM_SUBJECT_REQUEST } }
    function success(response) { return { type: classExamSubjectConstants.CLASS_EXAM_SUBJECT_SUCCESS, response } }
    function failure(error) { return { type: classExamSubjectConstants.CLASS_EXAM_SUBJECT_FAILURE, error } }
}
 