import { accountLedgerSummaryMonthConstants } from '../_constants';
import { accountLedgerSummaryMonthService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accountLedgerSummaryMonthActions = {
    getLedgerSummaryofMonthHandler,
};

function getLedgerSummaryofMonthHandler(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accountLedgerSummaryMonthService.getLedgerSummaryofMonthHandler(obj)
            .then(
                response => {
                    dispatch(success(response.data.ledger_summary_of_month));
                },
                error => {
                    // console.log(error);
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request( ) { return { type: accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_REQUEST } }
    function success(response) { return { type: accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_SUCCESS, response } }
    function failure(error) { return { type: accountLedgerSummaryMonthConstants.ACC_LDR_SUMMARY_OF_MONTH_FAILURE, error } }
}