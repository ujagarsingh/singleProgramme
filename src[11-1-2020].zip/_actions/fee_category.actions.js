import { feeCategoryConstants } from '../_constants';
import { feeCategoryService } from '../_services';
import { toastr } from 'react-redux-toastr'; 
// import { history } from '../_helpers';

export const feeCategoryAction = {
    getFeeCategory,
    create,
    update,
    delete : _delete
};

function getFeeCategory() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeCategoryService.getFeeCategory()
            .then(
                response => {
                    dispatch(
                        success(response.data.fee_cat_arr),
                        toastr.success('Success', response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeCategoryConstants.FEE_CATEGORY_REQUEST } }
    function success(response) { return { type: feeCategoryConstants.FEE_CATEGORY_SUCCESS, response } }
    function failure(error) { return { type: feeCategoryConstants.FEE_CATEGORY_FAILURE, error } }
}


function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeCategoryService.create(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.new_item),
                        toastr.success(response.data.message)
                    );
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeCategoryConstants.CREATE_REQUEST } }
    function success(response) { return { type: feeCategoryConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: feeCategoryConstants.CREATE_FAILURE, error } }
}


function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeCategoryService.update(obj)
            .then(
                response => {
                    dispatch(success(
                        response.data.new_item),
                        toastr.success(response.data.message)
                    );

                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeCategoryConstants.UPDATE_REQUEST } }
    function success(response) { return { type: feeCategoryConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: feeCategoryConstants.UPDATE_FAILURE, error } }
}


function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeCategoryService.delete(obj)
            .then(
                response => {
                    dispatch(
                        success(response.data.id),
                        toastr.success(response.data.message)
                    );

                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeCategoryConstants.DELETE_REQUEST } }
    function success(response) { return { type: feeCategoryConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: feeCategoryConstants.DELETE_FAILURE, error } }
}

