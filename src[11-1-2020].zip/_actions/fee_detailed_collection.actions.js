import { feeDetailedCollectionConstants } from '../_constants';
import { feeDetailedCollectionService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeDetailedCollectionAction = {
    getFeeDetailedCollection
};

function getFeeDetailedCollection() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeDetailedCollectionService.getFeeDetailedCollection()
            .then(
                response => {
                    dispatch(success(response.data.fee_amo_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: feeDetailedCollectionConstants.FEE_COLLECTION_REQUEST } }
    function success(response) { return { type: feeDetailedCollectionConstants.FEE_COLLECTION_SUCCESS, response } }
    function failure(error) { return { type: feeDetailedCollectionConstants.FEE_COLLECTION_FAILURE, error } }
}
 