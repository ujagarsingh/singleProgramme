import React, { Component } from 'react';
import {  withRouter } from 'react-router';
//import { NavLink } from 'react-router-dom';
import FrontIndexPage from "./front_index_page";
import { Helmet } from "react-helmet";
class NotFound extends Component {
  render() {
    return (
      <div className="page-content">
         <Helmet>
          <title>Visit Site</title>
        </Helmet>
        <div className="page-bar d-flex">
              <div className="page-title">Front Page</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body">
            <div className="table-scrollable">
              <div className="col">
                <FrontIndexPage />
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(NotFound);