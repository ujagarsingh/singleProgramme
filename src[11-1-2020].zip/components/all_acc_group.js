import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accGroupActions, schoolsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddAccGroup from './add_acc_group';
import EditAccGroup from './edit_acc_group';

class AllAccGroup extends Component {
  state = {
    selected_item: '',
    createItem: false,
    editItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
  }



  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteAccGroup({ id: del_id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  updateHandlar = (obj) => {
    // console.log(JSON.stringify(obj));
    this.props.updateAccGroup(obj);
  }

  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.accGroup.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }
  render() {

    const { formIsHalfFilledOut, createItem, editItem, selected_item } = this.state;
    const { user, accGroup, schools } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>All Collections</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="card card-box sfpage-cover">
          {schools && user &&
            <>
              <div className="card-body sfpage-body">
                {createItem ? <AddAccGroup
                  accGroup={accGroup}
                  toggeleCreate={this.toggeleCreate} />
                  : null}
                {editItem ? <EditAccGroup
                  selected_item={selected_item}
                  accGroup={accGroup}
                  schools={schools}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                  : null}

                <div className="table-scrollable">
                  {accGroup &&
                    <table className="table table-striped table-bordered table-hover table-sm">
                      <thead>
                        <tr>
                          <th />
                          <th>Institution</th>
                          <th>Group Name</th>
                          <th>Group Type</th>
                          <th>Opning Balance</th>
                          <th>Current Balance</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {accGroup.map((item, index) => {
                          return (
                            <tr key={index} >
                              <td>{index + 1}</td>
                              <td>{item.school_name}</td>
                              <td>{item.group_name}</td>
                              <td>{(item.group_type === "P") ? "Primary" : "Secondary"}</td>
                              <td>{item.op_balance_type} {item.op_balance}</td>
                              <td>{item.crnt_balance_type} {item.crnt_balance}</td>
                              <td className="d-flex">
                                {(item.group_type === "P") ? null :
                                  <>
                                    <button className="btn btn-primary btn-sm mr-1"
                                      value={item.id}
                                      type="button"
                                      onClick={event => this.openEdit(event, item.id)}>Edit</button>
                                    <button className="btn btn-danger btn-sm"
                                      value={item.id}
                                      type="button"
                                      onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                                  </>
                                }
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>

                    </table>
                  }
                </div>
              </div>
              <div className="card-footer d-flex">
                {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-danger btn-sm ">
                    Cancel</button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-primary btn-sm">
                    Add New</button>
                }
                <span className="p-2 ml-auto text-danger">Primary = 'Default', Secondary = "Institution Wise"</span>
              </div>
            </>
          }
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: accGroup } = state.accGroup;
  const { item: schools } = state.schools;
  return { user, accGroup, schools };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getAccGroup: accGroupActions.getAccGroup,
  updateAccGroup: accGroupActions.update,
  deleteAccGroup: accGroupActions.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllAccGroup));