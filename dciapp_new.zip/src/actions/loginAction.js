import axios from 'axios';

const loginProcessInitiated = () => ({ type: 'LOGIN_PROCESS_STARTED' });

const loginProcessSuccess = (token) => ({ type: 'LOGIN_PROCESS_SUCCESS', payload: { ...token } });

const loginProcessFailed = (err) => ({ type: 'LOGIN_PROCESS_FAILED', payload: { ...err } });

const LOGIN_URL = `http://www.ujagarsingh.com/demo/login/api/login.php`;

// export { loginProcessInitiated, loginProcessSuccess, loginProcessFailed };
const loginActionCreator = (data) => (dispatch, getState) => {
  dispatch(loginProcessInitiated());

  axios.post(LOGIN_URL, { data }).then((res) => {
    dispatch(loginProcessSuccess(res.data.sucess.data));
  }).catch((err) => {
    dispatch(loginProcessFailed(err));
  });
};

export default loginActionCreator;
