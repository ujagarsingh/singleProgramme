import axios from 'axios';

const dashboardProcessInitiated = () => ({ type: 'DASHBOARD_PROCESS_STARTED' });

const dashboardProcessSuccess = (token) => ({ type: 'DASHBOARD_PROCESS_SUCCESS', payload: { ...token } });

const dashboardProcessFailed = (err) => ({ type: 'DASHBOARD_PROCESS_FAILED', payload: { ...err } });

// export { dashboardProcessInitiated, dashboardProcessSuccess, dashboardProcessFailed };
const dashboardActionCreator = (data) => (dispatch, getState) => {
  dispatch(dashboardProcessInitiated());

//   axios.post('http://localhost:3000/dashboard', { data }).then((res) => {
//     dispatch(dashboardProcessSuccess(res.data.sucess.data));
//   }).catch((err) => {
//     dispatch(dashboardProcessFailed(err));
//   });
  console.log("heyaction");
  dispatch(dashboardProcessSuccess(
    [
      {
      name: 'anirudh',
      address: 'jaipur',
      phone: 134560,
      gender: 'male',
      },
      {
        name: 'john',
        address: 'jaipur',
        phone: 13456,
        gender: 'male',
      }
    ]
  ));
};

export default dashboardActionCreator;
