import React from 'react';
import {
  BrowserRouter,
  Route,
  Switch,
  Redirect,
} from 'react-router-dom';
//import logo from './logo.svg';
import './App.css';
import Login from './components/login';
import Register from './components/register';
import Dashboard from './components/dashboard';
import SetPassword from './components/setPassword';

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/login" name="login" render={(props) => <Login {...props} />} />
        <Route exact path="/register" name="register" render={(props) => <Register {...props} />} />
        <Route exact path="/dashboard" name="dashboard" render={(props) => <Dashboard {...props} />} />
        <Route exact path="/setpassword" name="setpassword" render={(props) => <SetPassword {...props} />} />
        <Redirect from="/" to="/login" />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
