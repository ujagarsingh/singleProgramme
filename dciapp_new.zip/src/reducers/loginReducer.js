const initialState = {
  loading: false,
  data: null,
  error: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case 'LOGIN_PROCESS_STARTED':
      return {
        ...state,
        loading: true,
      };
    case 'LOGIN_PROCESS_SUCCESS':
      return {
        ...state,
        data: action.payload,
      };
    case 'LOGIN_PROCESS_FAILED':
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};
