import { combineReducers } from 'redux';
import login from './loginReducer';
import dashboard from './dashboardReducer';

const rootReducer = combineReducers({
  login,
  dashboard,
});

export default rootReducer;
