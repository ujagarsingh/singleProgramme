import React from 'react';
import { connect } from 'react-redux';
import dashboardActionCreator from '../actions/dashboardAction';

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    };
    this.props.dispatch(dashboardActionCreator());
  }

  // componentDidMount() {
  //   this.props.dispatch(dashboardActionCreator());
  // }

  render() {
    const testData = [{
      name: 'anirudh',
      address: 'jaipur',
      phone: 134569,
      gender: 'male',
    },
    {
      name: 'john',
      address: 'jaipur',
      phone: 13456,
      gender: 'male',
    }];
    console.log(this.props.data.dashboard);
    let tableData = null;
    return (
      <table>
        <th>Name</th>
        <th>Address</th>
        <th>Phone</th>
        <th>Gender</th>
        <th>Action</th>
        {
          this.props.data.dashboard.data !== null ? (Object.keys(this.props.data.dashboard.data).map((key) => {
            tableData += `<tr>
              <td>${this.props.data.dashboard.data[key].name}</td>
              <td>${this.props.data.dashboard.data[key].address}</td>
              <td>${this.props.data.dashboard.data[key].phone}</td>
              <td>${this.props.data.dashboard.data[key].gender}</td>
            </tr>`;
          })) : (null)
        }
        {tableData}
      </table>
    );
  }
}

const mapStateToProps = (state) => ({ data: state });

export default connect(mapStateToProps)(Dashboard);
