import React from 'react';
import {NavLink} from 'react-router-dom';
import '../styles/style.css';
import logo from '../images/logo.png';

class SetPassword extends React.Component {
  constructor(props) {
    super(props);
    this.textInput = React.createRef();
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(e) {
    e.preventDefault();
    this.textInput.current.focus();
  }
  render() {
    return(
      <React.Fragment>
        <NavLink to="/" className="backtohome">Back to Home</NavLink>
        <NavLink to="/mailto:" className="mail-right">info@dciecosystem.com</NavLink>
        <img src={logo} className="logo" />
        <div className="wrapper-form">
          <h2>Password Set</h2>
          <span>Email confirmed please set your password</span>
          <hr />
          <div className="form-section">
            <form onSubmit={this.handleSubmit}>
              <div className="row">
                <div className="col-sm-12">
                  <label>Passowrd*</label>
                  <input type="text" placeholder="" ref={this.textInput}/>
                  <p>Enter your pasword </p>
                </div>
                <div className="col-sm-12">
                  <label>Confirm Password*</label>
                  <input type="text" placeholder=""/>
                  <p>Enter your passowrd again</p>
                </div>
                <div className="col-sm-12">
                  <input type="submit" value="Submit"/>
                </div>
              </div>
            </form>
          </div>
        </div>
        {/* <!--<p className="before-us">If you have registered with us before, please <a href="#">click here</a> for Login</p>--> */}
        <p class="copyright">2019 © DCI Ecosystem. All Rights Reserved.</p>
      </React.Fragment>  
    );
  }
}
export default SetPassword;
