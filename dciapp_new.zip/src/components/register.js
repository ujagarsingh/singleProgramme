import React from 'react';
import {NavLink} from 'react-router-dom';
import axios from 'axios';
import DocumentMeta from 'react-document-meta';
import '../styles/style.css';
import logo from '../images/logo.png';
import captcha from '../images/captcha.jpg';

const CREATE_USER = `http://www.ujagarsingh.com/demo/login/api/create_user.php`;

//const VALIDATE_TOKEN = `http://www.ujagarsingh.com/demo/login/api/validate_token.php`;

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      firstname: '',
      lastname: '',
      email: '',
      password: '',
      err: '',
    };
    this.changeFirstName = this.changeFirstName.bind(this);
    this.changeLastName = this.changeLastName.bind(this);
    this.changeEmail = this.changeEmail.bind(this);
    this.changePassword = this.changePassword.bind(this);
    this.register = this.register.bind(this);
  }

  changeFirstName(e) {
    console.log(e.target.value);
    this.setState({ firstname: e.target.value });
  }

  changeLastName(e) {
    console.log(e.target.value);
    this.setState({ lastname: e.target.value });
  }

  changeEmail(e) {
    console.log(e.target.value);
    this.setState({ email: e.target.value });
  }
  changePassword(e) {
    console.log(e.target.value);
    this.setState({ password: e.target.value });
  }

  register(e) {
    e.preventDefault();
    const {email, firstname, lastname, password} = this.state;
    const obj = { firstname, lastname, email, password };
    console.log(JSON.stringify(obj));
    axios.post(CREATE_USER, obj)
    .then((res) => {
      this.props.history.push('/login');
    }).catch((err) => {
      this.setState({ err });
    });
  }

  render() {
    const meta = {
      title: 'DCIecosystem',
      description: 'I am a description, and I can create multiple tags',
     // canonical: 'http://example.com/path/to/page',
      meta: {
        charset: 'utf-8',
        name: {
          keywords: 'react,meta,document,html,tags',
        },
      },
    };
    return (
      <DocumentMeta {...meta}>
        <NavLink to="/" className="backtohome">Back to Home</NavLink>
        <NavLink to="mailto:" className="mail-right">info@dciecosystem.com</NavLink>
        <img alt="" src={logo} className="logo" />
        <div className="wrapper-form">
          <h2>Sign Up</h2>
          <span>Us your email for Registration</span>
          <hr />
          <div className="form-section">
            <form onSubmit={this.register}>
              <div className="row">
                <div className="col-sm-6">
                  <label>First Name*</label>
                  <input type="text" onChange={this.changeFirstName} placeholder="" />
                  <p>Enter your first name </p>
                </div>
                <div className="col-sm-6">
                  <label>Last Name*</label>
                  <input type="text" onChange={this.changeLastName} placeholder="" />
                  <p>Enter your last name </p>
                </div>
                <div className="col-sm-12">
                  <label>Your Email ID*</label>
                  <input type="email" onChange={this.changeEmail} placeholder="" />
                  <p>Enter your Email ID </p>
                </div>
                <div className="col-sm-12">
                  <label>Your Password*</label>
                  <input type="password" onChange={this.changePassword} placeholder="" />
                  <p>Enter your Password </p>
                </div>
                <div className="col-sm-7">
                  <label>Captcha*</label>
                  <img src={captcha} alt="" />
                </div>
                <div className="col-sm-5">
                  <input type="submit" value="Submit" />
                </div>
              </div>
            </form>
          </div>
        </div>
        <p className="before-us">
        If you have registered with us before, please <NavLink to="/login"> click here </NavLink> for Login
        </p>
        <p className="copyright">2019 © DCI Ecosystem. All Rights Reserved.</p>
      </DocumentMeta>
    );
  }
}

export default Register;
