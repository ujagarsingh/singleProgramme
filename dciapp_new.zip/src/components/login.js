/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';
import { connect } from 'react-redux';
import '../styles/style.css';
import axios from 'axios';
import DocumentMeta from 'react-document-meta';
import {NavLink} from 'react-router-dom';
import logo from '../images/logo.png';
import loginActionCreator from '../actions/loginAction';
const LOGIN_URL = `http://www.ujagarsingh.com/demo/login/api/login.php`;

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.login = this.login.bind(this);
    this.changeEmail = this.changeEmail.bind(this);
    this.changePassword = this.changePassword.bind(this);
    this.state = {
      email: '',
      password: '',
      err: '',
    };
  }

  changeEmail(e) {
    this.setState({ email: e.target.value });
  }

  changePassword(e) {
    this.setState({ password: e.target.value });
  }

  login(e) {
    e.preventDefault();
    const { email, password } = this.state;
    /*axios.post(LOGIN_URL, { email, password }).then((res) => {
      console.log(res);
      localStorage.token = res.jwt;
      this.props.history.push('/');
    }).catch((err) => {
      this.setState({ err: 'Invalid email or password' });
    });*/
    this.props.dispatch(loginActionCreator({ email, password }));
  }

  render() {
    console.log(this.props.data);
    const meta = {
      title: 'DCIecosystem',
      description: 'I am a description, and I can create multiple tags',
      //canonical: 'http://example.com/path/to/page',
      meta: {
        charset: 'utf-8',
        name: {
          keywords: 'react,meta,document,html,tags',
        },
      },
    };
    const { err } = this.state;

    return (
      <DocumentMeta {...meta}>
        <NavLink to="/" className="backtohome">Back to Home</NavLink>
        <NavLink to="/mailto:" className="mail-right">info@dciecosystem.com</NavLink>
        <img alt="" src={logo} className="logo" />
        {err ? (<div className="alert alert-danger" role="alert">{err}</div>)
          : (null)}
        <div className="wrapper-form">
          <h2>Login</h2>
          <span>Log in to your account</span>
          <hr />
          <div className="form-section">
            <form onSubmit={this.login}>
              <div className="row">
                <div className="col-sm-12">
                  <label>Your Email</label>
                  <input type="email" onChange={this.changeEmail} placeholder="Enter your email id" />
                </div>
                <div className="col-sm-12">
                  <label>Password</label>
                  <input type="password" onChange={this.changePassword} placeholder="Enter your Passowrd" />
                </div>
                <div className="col-sm-12">
                  <input type="submit" className="mgtop25" value="Submit" />
                  <NavLink to="/setpassword" className="forgot-password">Forgot Password</NavLink>
                </div>
              </div>
            </form>
          </div>
        </div>
        <p className="before-us">
            Haven’t any account? , please  <NavLink to="/register"> click here </NavLink> for Sign up
        </p>
        <p className="copyright">2019 © DCI Ecosystem. All Rights Reserved.</p>
      </DocumentMeta>
    );
  }
}
const mapStateToProps = (state) => ({ data: state });

export default connect(mapStateToProps)(Login);
