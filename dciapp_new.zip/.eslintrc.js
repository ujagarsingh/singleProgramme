module.exports={
    "extends" : [
        "airbnb",
        "react-app"], 
    "rules": {
        "react/jsx-filename-extension": [1, { "extensions": [".js", ".jsx"] }],
        "react/jsx-props-no-spreading": "off",
        "jsx-a11y/anchor-is-valid": 0,
        }   
   }