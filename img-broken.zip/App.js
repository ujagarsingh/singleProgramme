import React from 'react';
import logo from './logo.svg';
import './App.css';
import ImageLoader from "./ImageLoader/index";

function App() {
  return (
    <div className="App">
      <header className="App-header">
	  {/* <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
</a>*/}
     <div className="try">
     <ImageLoader
      src={'../assets/image.jpg'}
      fallbackSrc= {`https://via.placeholder.com/150x150?text=Image+Not+Available`}
     />
     </div>
     <hr/>
     <div className="try">
     <ImageLoader
      src={'../assets/image.png'}
      fallbackSrc= {`https://via.placeholder.com/150x150?text=Image+Not+Available`}
     />
     </div>
     <div className="try">
     <ImageLoader
      src={'../assets/image1.png'}
      fallbackSrc= {`https://via.placeholder.com/150x150?text=Image+Not+Available`}
     />
     </div>
     <div className="try">
     <ImageLoader
      src={'../assets/image2.png'}
      fallbackSrc= {`https://via.placeholder.com/150x150?text=Image+Not+Available`}
     />
     </div>
      </header>
    </div>
  );
}

export default App;
