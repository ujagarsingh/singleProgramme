import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import ImageLoader from "../utility/ImageLoader/index";

class FrontIndexHeaderTop extends Component {
  render() {
    const { group } = this.props;
    const { mobile, logo, org_name, email } = group;
    return (
      <React.Fragment>
        <div className="header-top">
          <div className="container">
            <div className="d-flex flex-row">
              <div className="header-top-left">
                <ul className="list-unstyled">
                  <li><i className="fa fa-phone top-icon" /> {mobile}</li>
                  <li><i className="fa fa-envelope top-icon" /> {email}</li>
                </ul>
              </div>
              <div className="header-top-right ml-auto">
                <ul className="list-unstyled">
                  {/*<li><NavLink to="register.html"><i className="fa fa-user-plus top-icon" /> Sing up</NavLink></li>*/}
                  <li><NavLink to="/login.jsp"><i className="fa fa-lock top-icon" />Login</NavLink></li>
                </ul>
              </div>
            </div>
          </div>
        </div>{/* Ends: .header-top */}
        <div className="header-body">
          <nav className="navbar edu-navbar">
            <div className="container">
              <div className="navbar-header">
                {/*<button type="button"
                  className="navbar-toggle collapsed"
                  data-toggle="collapse"
                  data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                  <span className="sr-only">Toggle navigation</span>
                  <span className="icon-bar" />
                  <span className="icon-bar" />
                  <span className="icon-bar" />
                </button>*/}
                <NavLink to="/Home.jsp" className="navbar-brand  data-sc">
                  <ImageLoader
                    src={`${process.env.PUBLIC_URL}` + logo}
                    fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/logo.png`}
                  />
                  <span className="aflatoon">{org_name}</span></NavLink>
              </div>
              <div className="collapse navbar-collapse_ edu-nav main-menu">
                <ul className="nav navbar-nav pull-right">
                  <li><NavLink data-sc to="/">Contact</NavLink></li>
                </ul>
              </div>{/* /.navbar-collapse */}
            </div>{/* /.container */}
          </nav>
        </div>
      </React.Fragment>
    )
  }
}
export default FrontIndexHeaderTop;