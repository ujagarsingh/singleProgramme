import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import { loadProgressBar } from 'axios-progress-bar';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { groupActions } from '../_actions';
import { isEmptyObj } from '../utility/utilities';

import EditGroup from './edit_group_info';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/group/read_one.php`;

class GroupInfo extends Component {
  state = {
    editItem: false
  }
  componentDidMount() {
    if (isEmptyObj(this.props.group)) {
      this.props.getGroup();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getGroupInfoHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }


  // getGroupInfoHandler() {
  //   loadProgressBar();
  //   const group_id = this.state.group_id;

  //   axios.post(READ_URL + `?id=` + group_id)
  //     .then(res => {
  //       const getRes = res.data;
  //       console.log(getRes);
  //       this.setState({
  //         id: getRes.id,
  //         name: getRes.name,
  //         reg_no: getRes.reg_no,
  //         mobile: getRes.mobile,
  //         email: getRes.email,
  //         address: getRes.address,
  //         logo: getRes.logo,
  //         admin_img: getRes.admin_img,
  //         wel_mes_title: getRes.wel_mes_title,
  //         wel_mes: getRes.wel_mes,
  //         session_year_id: getRes.session_year_id
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateFeeStructure(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
    })
  }
  openEdit = (event) => {
    event.preventDefault();

    this.setState({
      editItem: true,
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false
    })
  }


  render() {
    const { logo, admin_img, editItem } = this.state
    const { group, user } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>Group Info</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title">Group Info</div>
        </div>
        {group && user &&
          <>
            {editItem ?
              <>
                <EditGroup
                  // selected_item={selected_item}
                  group={group}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                {/* <div className="backdrop edit-mode"></div> */}
              </>
              :
              <div className="card card-box sfpage-cover">
                <div className="card-body sfpage-body">
                  <div className="table-scrollable">
                    <div className="form-horizontal">
                      <div className="col-sm-12">
                        <div className="form-body">
                          <div className="row">
                            <div className="col-sm-7">
                              <div className="form-group row">
                                <label className="control-label col-md-4">Admin Name
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.user_name}</h6>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Group Name
                          </label>
                                <div className="col-md-8">
                                  <h5 className="p-1">{group.org_name}</h5>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Registration Number
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.reg_no}</h6>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Mobile
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.mobile}</h6>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Email
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.email}</h6>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Head Office Address
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.address}</h6>
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-4">Current Session Year
                          </label>
                                <div className="col-md-8">
                                  <h6 className="p-1">{group.session_year_id}</h6>
                                </div>
                              </div>
                            </div>
                            <div className="col-sm-4 ml-auto">
                              <div className="form-group row">
                                <label className="control-label col-md-6">School Logo</label>
                                <div className="col-md-6">
                                  {logo !== '' ?
                                    <img alt="OSM" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + group.logo} />
                                    : null}
                                </div>
                              </div>
                              <div className="form-group row">
                                <label className="control-label col-md-6">Admin Image</label>
                                <div className="col-md-6">
                                  {admin_img !== '' ?
                                    <img alt="OSM" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + group.admin_img} />
                                    : null}
                                </div>
                              </div>
                            </div>
                          </div>
                          <hr />
                          <div className="form-group row">
                            <label className="control-label col-md-2">Welcome Message Title
                      </label>
                            <div className="col-md-10">
                              <h6 className="mt-2">{group.wel_mes_title}</h6>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="control-label col-md-2">Welcome Message
                      </label>
                            <div className="col-md-10">
                              <p>{group.wel_mes}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-footer text-right">
                  {/* <NavLink to="/edit_group_info.jsp" className="btn btn-primary btn-sm mr-2">Edit</NavLink> */}
                  <button className="btn btn-primary btn-sm mr-1"
                    type="button"
                    onClick={event => this.openEdit(event)}>Edit</button>
                  <NavLink to="dashboard.jsp" className="btn btn-danger  btn-sm">Back</NavLink>
                </div>
              </div>
            }
          </>
        }
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: group } = state.group;
  return { user, group };
}

const actionCreators = {
  getGroup: groupActions.getGroup,
}

export default connect(mapStateToProps, actionCreators)(withRouter(GroupInfo));