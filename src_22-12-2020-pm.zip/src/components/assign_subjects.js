import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { professionalAction, classWiseSubDetailsForAssignAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_PROFESSIONAL = `http://schools.rajpsp.com/api/professional/read_one.php`;
const READ_URL = `http://schools.rajpsp.com/api/subject/read_assignable_subject_n_class.php`;
const ASSIGN_SUBJECT = `http://schools.rajpsp.com/api/professional/assign_subject.php`;
// const READ_ALL_STAFF_IDS = `http://schools.rajpsp.com/api/professional/read_all_staff_ids.php`;

class AssignSubjects extends Component {
   state = {
      current_id: '',
      prev_id: '',
      next_id: '',
      is_prev: false,
      is_next: false,
      all_staffs_ids: [],
      formIsHalfFilledOut: false,
   }
   isEmpty(val) {
      return (val === undefined || val == null || val.length <= 0) ? true : false;
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      if (fieldName === 'sub_checkbox') {
         const _class_id = event.target.id.split('_')[1];
         const _sub_id = event.target.id.split('_')[2];
         const _filtered_class = this.state.filtered_classes;
         const updated_sub = _filtered_class.map((item) => {
            if (item.id === _class_id) {
               item.subject_arr.map((subItem) => {
                  if (subItem.id === _sub_id) {
                     subItem.is_assigned = !subItem.is_assigned
                  }
                  return subItem;
               })
            }
            return item;
         })
         this.setState({
            filtered_classes: updated_sub,
            formIsHalfFilledOut: true
         })

      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value
         })
      }
   };

   componentDidMount() {
      if (isEmptyObj(this.props.professional)) {
         this.props.getProfessional();
      }
      if (isEmptyObj(this.props.classWiseSubDetailsForAssign)) {
         this.props.getSujectDetailsForAssign();
      }
      this.checkFlag();
   }

   checkFlag() {
      setTimeout(() => {
         const _all_prof = this.props.professional;
         const _all_subjects = this.props.classWiseSubDetailsForAssign;
         if (_all_prof && _all_subjects) {
            this.checkAuthentication();
         } else {
            this.checkFlag()
         }
      }, 100);
   }
   checkAuthentication() {
      loadProgressBar();
      const { match } = this.props;
      const current_id = match.params.id;

      this.setState({
         current_id: current_id,
      }, () => {
         this.getProffRecords();
         this.getAllStaffIdsHandler()
      })
   }

   getAllStaffIdsHandler() {
      const _professional = this.props.professional;
      const school_id = this.props.user.school_id;
      let all_Ids = [];
      _professional.map((item) => {
         if (item.school_id === school_id) {
            all_Ids = [...all_Ids, { s_id: item.id, emp_name: item.emp_name }]
         }
      })

      this.setState({
         all_staffs_ids: all_Ids
      }, () => {
         this.setStaffItsHandler()
      })

   }
   getProffRecords() {
      const staff_id = this.state.current_id;
      const _professional = this.props.professional;
      // debugger
      const _proff = _professional.filter((item, index) => {
         if (item.id === staff_id) {
            return item
         }
      })

      this.setState({
         proff: _proff[0]
      }, () => this.updateAssingnSubectWithExistingRecord());

   }

   // checkAuthentication(obj) {
   //    const { params } = this.props.match;
   //    const com_id = params.id.split('_');
   //    const _school_id = com_id[0];
   //    const _prof_id = com_id[1];

   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          // sessionStorage.setItem("user", getRes.data);
   //          console.log(getRes);
   //          if (getRes.data) {
   //             this.setState({
   //                user: getRes.data,
   //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //                // school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //                school_id: _school_id,
   //                current_id: _prof_id,
   //             }, () => {
   //                this.getClassesWiseSubjectHandler();
   //                this.getAllStaffIdsHandler();
   //             })
   //          }
   //       }).catch((error) => {
   //          this.props.history.push('/login.jsp');
   //       })
   // }
   // getAllStaffIdsHandler() {
   //    const obj = {
   //       group_id: this.state.group_id,
   //       session_year_id: this.state.session_year_id,
   //       user_category: this.state.user_category,
   //       school_id: this.state.school_id
   //    }

   //    // console.log(JSON.stringify(obj));
   //    // debugger
   //    axios.post(READ_ALL_STAFF_IDS, obj)
   //       .then(res => {
   //          const resData = res.data;
   //          // console.log(resData);
   //          this.setState({
   //             all_staffs_ids: resData,
   //             errorMessages: resData.message
   //          }, () => {
   //             this.setStaffItsHandler()
   //          });
   //       }).catch((error) => {
   //          // error
   //       });
   // }
   // getProffRecords() {
   //    const staff_id = this.state.current_id;
   //    //const { match } = this.props;
   //    loadProgressBar();
   //    axios.get(GET_PROFESSIONAL + '?id=' + staff_id)
   //       .then(res => {
   //          const getRes = res.data;
   //          if (getRes.message !== undefined) {
   //             Alert.error(getRes.message, {
   //                position: 'bottom-right',
   //                effect: 'jelly',
   //                timeout: 5000, offset: 40
   //             });
   //          }
   //          this.setState({
   //             proff: getRes,
   //             errorMessages: res.data.message
   //          }, () => this.updateAssingnSubectWithExistingRecord());
   //          //console.log(proff);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   setStaffItsHandler() {
      debugger
      const _current_id = this.state.current_id;
      const _staff_ids = this.state.all_staffs_ids;
      let _prev_id = '';
      let _next_id = '';
      let _is_prev = false;
      let _is_next = false;
      let _chnage_state = false;
      for (let i = 0; i < _staff_ids.length; i++) {

         if (_current_id === _staff_ids[i].s_id && (i >= 0 && i < _staff_ids.length)) {

            if (i === 0) {
               _prev_id = _staff_ids[_staff_ids.length - 1].s_id;
            } else {
               _prev_id = _staff_ids[i - 1].s_id;
            }

            if (i === _staff_ids.length - 1) {
               _next_id = _staff_ids[0].s_id;
            } else {
               _next_id = _staff_ids[i + 1].s_id;
            }


            _chnage_state = true;
            if (i == 0) {
               _is_prev = true;
            } else if (i == _staff_ids.length - 1) {
               _is_next = true;
            }
            break;
         }
      }

      if (_chnage_state) {
         this.setState({
            prev_id: _prev_id,
            next_id: _next_id,
            is_prev: _is_prev,
            is_next: _is_next
         })
      }
   }
   getClassesWiseSubjectHandler() {
      loadProgressBar();
      const obj = {
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id,
      }
      axios.post(READ_URL, obj)
         .then(res => {
            const getRes = res.data;
            if (getRes.responceData) {
               this.setState({
                  classes_with_subject: getRes.responceData,
               }, () => this.getProffRecords());
            } else {
               Alert.error(getRes.message, {
                  position: 'bottom-right',
                  effect: 'jelly',
                  timeout: 5000,
               });
            }
            ////console.log(this.state.classes);
         }).catch((error) => {
            // error
         })
   }
   updateAssingnSubectWithExistingRecord() {
      debugger;
      const _get_subject = this.state.proff.subject_ids;
      const _all_subject = this.props.classWiseSubDetailsForAssign;

      const set_default_obj = _all_subject.map((item) => {
         const _new_subject_arr = item.subject_arr.map((sub_item) => {
            sub_item = { ...sub_item, is_assigned: false }
            return sub_item;
         })
         item = { ...item, subject_arr: _new_subject_arr }
         return item;
      });

      if (!this.isEmpty(_get_subject)) {
         const _assigned_subject = JSON.parse(_get_subject);
         const final_filtered_obj = set_default_obj.map((item) => {
            const _new_subject_arr = item.subject_arr.map((sub_item) => {
               if (_assigned_subject.includes(sub_item.id)) {
                  sub_item = { ...sub_item, is_assigned: true }
               }
               return sub_item;
            })
            item = { ...item, subject_arr: _new_subject_arr }
            return item;
         });
         this.setState({ filtered_classes: final_filtered_obj })
      } else {
         this.setState({ filtered_classes: set_default_obj })
      }
   }

   createSubDomHandler(item, inx) {
      return (
         <div key={inx} className="custom-control custom-checkbox m-1">
            <input type="checkbox" className="custom-control-input"
               onChange={event => this.changeHandler(event, 'sub_checkbox', true)}
               id={`subjectId_` + item.class_id + `_` + item.id}
               checked={item.is_assigned} />
            <label className="custom-control-label" htmlFor={`subjectId_` + item.class_id + `_` + item.id}>
               {item.sub_name}
            </label>
         </div>
      )
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler(event);
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler() {
      loadProgressBar();
      const update_subject = this.state.filtered_classes;
      let all_subject_ids = [];
      const final_obj = update_subject.map((item) => {
         let selected_sub_ids = [];
         item.subject_arr.map((sub_item) => {
            if (sub_item.is_assigned) {
               selected_sub_ids.push(sub_item.id);
               all_subject_ids.push(sub_item.id);
            }
         });
         item = { id: item.id, sub_ids: selected_sub_ids }
         return item;
      })

      const obj = {
         final_obj: JSON.stringify(final_obj),
         subject_ids: JSON.stringify(all_subject_ids),
         prof_id: this.state.current_id,
         school_id: this.state.school_id,
         session_year_id: this.state.session_year_id,
      };

      // console.log(JSON.stringify(obj));
      // debugger
      axios.post(ASSIGN_SUBJECT, obj)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes)
            Alert.success(getRes.message, {
               position: 'bottom-right',
               effect: 'jelly',
               timeout: 5000, offset: 40
            });
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })
   }
   // setStaffItsHandler() {
   //    const _current_id = this.state.current_id;
   //    const _staff_ids = this.state.all_staffs_ids;
   //    let _prev_id = '';
   //    let _next_id = '';
   //    let _is_prev = false;
   //    let _is_next = false;
   //    let _chnage_state = false;
   //    for (let i = 0; i < _staff_ids.length; i++) {

   //       if (_current_id === _staff_ids[i].s_id && (i >= 0 && i < _staff_ids.length)) {

   //          if (i === 0) {
   //             _prev_id = _staff_ids[_staff_ids.length - 1].s_id;
   //          } else {
   //             _prev_id = _staff_ids[i - 1].s_id;
   //          }

   //          if (i === _staff_ids.length - 1) {
   //             _next_id = _staff_ids[0].s_id;
   //          } else {
   //             _next_id = _staff_ids[i + 1].s_id;
   //          }

   //          _chnage_state = true;
   //          if (i == 0) {
   //             _is_prev = true;
   //          } else if (i == _staff_ids.length - 1) {
   //             _is_next = true;
   //          }
   //          break;
   //       }
   //    }

   //    if (_chnage_state) {
   //       this.setState({
   //          prev_id: _prev_id,
   //          next_id: _next_id,
   //          is_prev: _is_prev,
   //          is_next: _is_next
   //       })
   //    }
   // }
   getPrevStaffRecord(e, _id) {
      e.preventDefault();
      this.setState({
         current_id: _id
      }, () => {
         this.getProffRecords();
         this.setStaffItsHandler();
         this.changeUrlHandler();
      })
   }
   changeUrlHandler() {
      const page_id = this.state.current_id;
      this.props.history.push(`/assign_subjects.jsp/${page_id}`);
   }
   render() {
      const { filtered_classes, proff, prev_id, next_id, is_prev, is_next, formIsHalfFilledOut } = this.state;
      const { user, professional, classWiseSubDetailsForAssign } = this.props;
      return (
         <div className="page-content">
            <Helmet>
               <title>All Subject</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            {user && professional && classWiseSubDetailsForAssign &&
               <>
                  {filtered_classes &&
                     <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
                        <div className="p-2 well bg-light">
                           {proff && <h6>
                              {proff.emp_name} S/o <span className="text-muted"> {proff.emp_f_name}</span>
                           </h6>
                           }</div>
                        <div className="card-body sfpage-body">
                           <div className="table-scrollable">
                              <table className="table table-striped table-sm table-bordered table-hover table-sm">
                                 <thead>
                                    <tr>
                                       <th>Sr.No.</th>
                                       <th>Class Name</th>
                                       <th>Subjects of Class</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    {filtered_classes.map((item, index) => {
                                       return (
                                          <tr key={index}>
                                             <td>{index + 1}</td>
                                             <td>{item.class_name}</td>
                                             <td>
                                                <div className="form-inline as-checkbox">
                                                   {item.subject_arr.map((sub_item, inx) => {
                                                      return (
                                                         this.createSubDomHandler(sub_item, inx)
                                                      )
                                                   })}
                                                </div>
                                             </td>
                                          </tr>
                                       )
                                    })}
                                 </tbody>
                              </table>
                           </div>
                        </div>
                        <div className="card-footer d-flex">
                           <button type="button"
                              onClick={event => this.getPrevStaffRecord(event, prev_id)}
                              disabled={is_prev}
                              className="btn btn-primary text-white">
                              <i className="fa fa-angle-left"></i>
                           </button>
                           <button type="button"
                              onClick={event => this.getPrevStaffRecord(event, next_id)}
                              disabled={is_next}
                              className="btn btn-primary ml-3 text-white">
                              <i className="fa fa-angle-right"></i>
                           </button>

                           <button type="submit" className="btn btn-primary btn-sm ml-auto mr-2 ">Submit</button>
                           <NavLink to="/all_professionals.jsp" className="btn btn-danger">All Professionals</NavLink>
                        </div>
                     </form>
                  }
               </>
            }
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: professional } = state.professional;
   const { item: classWiseSubDetailsForAssign } = state.classWiseSubDetailsForAssign;
   return { user, professional, classWiseSubDetailsForAssign };
}

const actionCreators = {
   getProfessional: professionalAction.getProfessional,
   getSujectDetailsForAssign: classWiseSubDetailsForAssignAction.getSujectDetailsForAssign,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AssignSubjects));
