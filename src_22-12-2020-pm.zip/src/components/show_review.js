import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class ShowReview extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Show Review</title>
        </Helmet>

        <div className="page-bar d-flex">
          <div className="page-title">Show Review</div>
        </div>
        <div className="row">
          <div className="col-md-12 col-sm-12">
            <div className="card card-box sfpage-cover">

              <div className="card-body sfpage-body">
                <form action="#" id="form_sample_1" className="form-horizontal">
                  <div className="form-body">
                    <div className="form-group row">
                      <label className="control-label col-md-3">Name
                    </label>
                      <div className="col-md-5">
                        <input type="text" name="auther" placeholder className="form-control form-control-sm" /> </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-3">Designation
                    </label>
                      <div className="col-md-5">
                        <input type="text" name="auther" placeholder className="form-control form-control-sm" /> </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-3">Star
                    </label>
                      <div className="col-md-5">
                        <select className="form-control form-control-sm" name="department">
                          <option value>Select...</option>
                          <option value="Category 1">1</option>
                          <option value="Category 2">2</option>
                          <option value="Category 3">3</option>
                          <option value="Category 3">4</option>
                          <option value="Category 3">5</option>
                        </select>
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-3">Message
                    </label>
                      <div className="col-md-5">
                        <textarea name="details" placeholder="Message" className="form-control-textarea form-control" rows={5} defaultValue={""} />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-3">Reviewer Image
                    </label>
                      <div className="compose-editor">
                        <input type="file" className="default" multiple />
                      </div>
                    </div>
                    <div className="form-actions  text-right">
                      <div className="row">
                        <div className="offset-md-3 col-md-9">
                          <button type="submit" className="btn btn-primary mr-2">Submit</button>
                          <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(ShowReview);