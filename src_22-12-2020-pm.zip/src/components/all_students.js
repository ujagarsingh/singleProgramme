import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
//import { Picky } from 'react-picky';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, conveyanceAction, studentsAction } from '../_actions';
import ImageLoader from "../utility/ImageLoader/index";
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_CLASS_STUDENT = `http://schools.rajpsp.com/api/students/read.php`;
// const READ_CONV_URL = `http://schools.rajpsp.com/api/conveyance/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
const UPDATE_STUDENT_URL = `http://schools.rajpsp.com/api/students/update.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;

class AllStudents extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    students: [],
    selected_student: [],
    conveyance: [],
    classes: [],
    selected_classes: [],
    selected_year: '',
    selected_class_id: '',
    selected_class_inx: '',
    class_section: [],
    //ptl_classes: [],
    seatType: ['free', 'paid'],
    display_student: [],
    display_student_with_checked: [],
    update_student: [],
    convence_months_arr: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    medium_arr: [],
    medium: '',
    basicInfo: true,
    selectAllStudentCheck: false,
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   alert(1)
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   sessionStorage.setItem("medium", _medium);
    //   this.filterStudentOnDemand();
    //   this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     selected_class_inx: '',
    //     medium: '',
    //   })
    // } else if (fieldName === 'selected_class') {
    //   const _inx = event.target.value;
    //   const class_id = (!isEmpty(_inx)) ? this.state.selected_classes[_inx].id : '';
    //   sessionStorage.setItem("class_id", class_id);
    //   this.filterStudentOnDemand();
    //   this.setState({
    //     selected_class_id: class_id,
    //     selected_class_inx: _inx,
    //   });
    // } else if (fieldName === 'medium') {
    //   const _medium = event.target.value;
    //   sessionStorage.setItem("medium", _medium);
    //   this.mediumHandler(_medium);
    //   this.filterStudentOnDemand();
    //   this.setState({
    //     [fieldName]: isCheckbox ? event.target.checked : event.target.value,
    //   });
    // } else {
    // }

    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value
    });
  };
  mediumHandler(_medium) {
    const _classes = this.props.selected_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      selected_class_inx: ''
    })
  }
  checkHandler = (event, fieldName, value) => {
    let _display_student = null;
    let _current_select = JSON.parse(value).admission_number;
    if (fieldName === 'select_this') {
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['checked'] = !checked_student.checked;
          return checked_student;
        }
        return checked_student;
      })
      this.setState({
        update_student: _display_student
      })
    } else if (fieldName === 'select_all') {
      _display_student = this.state.display_student.map((checked_student) => {
        checked_student['checked'] = (event.target.checked) ? true : false;
        return checked_student;
      })
      this.setState({
        update_student: _display_student
      })
    } else if (fieldName === 'student_type') {
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['free_seat'] = checked_student.free_seat === "0" ? "1" : "0";
          return checked_student;
        }
        return checked_student;
      })
    } else if (fieldName === 'rte_stationary') {
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['rte_stationary'] = checked_student.rte_stationary === "0" ? "1" : "0";
          return checked_student;
        }
        return checked_student;
      })
    } else if (fieldName === 'stopage_palace') {
      //let _stopage_area = (!event.target.value === '') ?
      // this.props.conveyance[event.target.value].stoppage_name : '';
      let _stopage_area = event.target.value;
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['convence_area'] = _stopage_area;
          checked_student['convence_months'] = this.props.convence_months_arr;
          return checked_student;
        }
        return checked_student;
      })
    } else if (fieldName === 'convence_months') {
      let _convence_month = event;
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['convence_months'] = _convence_month;
          return checked_student;
        }
        return checked_student;
      })
    } else if (fieldName === 'software_class') {
      let _name = event.target.value;
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['software_class'] = _name;
          return checked_student;
        }
        return checked_student;
      })
    } else if (fieldName === 'roll_number') {
      let _roll_number = event.target.value;
      _display_student = this.state.display_student.map((checked_student) => {
        if (_current_select === checked_student.admission_number) {
          checked_student['roll_number'] = _roll_number;
          return checked_student;
        }
        return checked_student;
      })
    }
    let _update_student = _display_student.filter((checked_student) => {
      return checked_student['checked'] === true
    })
    this.setState({
      display_student: _display_student,
      update_student: _update_student
    }, () => {
      //console.log(_display_student);
      //console.log(this.props.update_student);
    })
  };
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item, inx) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes
    })
  }
  filterStudentOnDemand() {
    let _students = this.props.students;
    let school_id = "";
    // debugger;
    if (this.props.user.user_category === "1") {
      school_id = (this.refs.school.value !== '') ? this.props.schools[this.refs.school.value].id : null;
    } else {
      school_id = this.props.user.school_id;
    }
    const medium = (this.refs.medium.value !== '') ? this.refs.medium.value : null;
    const class_name = (this.refs.classinx.value !== '') ? this.state.selected_classes[this.refs.classinx.value].class_name_portal : null;

    setTimeout(() => {
      //console.log('school_id ' + school_id + ' medium ' + medium + ' class_name ' + class_name);
      // debugger
      if (!isEmpty(school_id)) {
        _students = _students.filter((item) => {
          if (item.school_id === school_id) {
            return item
          }
        })
      }
      if (!isEmpty(medium)) {
        _students = _students.filter((item) => {
          if (item.medium === medium) {
            return item
          }
        })
      }
      if (!isEmpty(class_name)) {
        _students = _students.filter((item) => {
          if (item.stu_class === class_name) {
            return item
          }
        })
      }
      const updated_students = _students.map((student) => {
        const xyz = { ...student };
        xyz['convence_months'] = student.convence_months;
        xyz['checked'] = false;
        return xyz;
      })
      // console.log(_students);
      this.setState({
        display_student: updated_students,
        display_student_with_checked: updated_students
      })
    }, 300);

  }


  generateNumberHandlar(ev) {
    ev.preventDefault();
    //display_student
    const _class_obj = this.props.selected_classes[this.props.selected_class];
    let _start_rollNo = parseInt(_class_obj.roll_num_end);
    let _end_rollNo = parseInt(_class_obj.roll_num_start);
    //let _class_portal = _class_obj.class_name_portal;

    const _display_student = this.state.display_student.filter((student, index) => {
      if (student.roll_number === '') {
        student.roll_number = _start_rollNo + index;
      }
      return student;
    })
    this.setState({
      display_student: _display_student,
      //display_student_with_checked: _students
    })
  }

  // getStudentRecords() {
  //   const obj = {
  //     group_id: this.props.group_id,
  //     session_year_id: this.props.session_year_id,
  //     user_category: this.props.user_category,
  //     school_id: this.props.school_id
  //   }

  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_STUDENT, obj)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.length > 0) {
  //         this.setState({
  //           students: resData,
  //           errorMessages: resData.message
  //         }, () => {
  //           const _students = resData.map((student) => {
  //             const xyz = { ...student };
  //             //xyz['convence_months'] = student.convence_months.length > 1 ? student.convence_months.split(",") : student.convence_months;
  //             xyz['convence_months'] = student.convence_months;
  //             xyz['checked'] = false;
  //             return xyz;
  //           })
  //           const _classes = this.props.classes.filter((item, index) => {
  //             /*if (item.is_section === 'No' && item.class_name_portal === class_name) {
  //               return item;
  //             }*/
  //           })
  //           if (this.props.user.user_category === "1") {
  //             this.setState({
  //               student: _students,
  //               class_section: _classes,
  //               display_student_with_checked: _students
  //             })
  //           } else if (this.props.user.user_category === "2") {
  //             this.setState({
  //               student: _students,
  //               display_student: _students,
  //               class_section: _classes,
  //               display_student_with_checked: _students
  //             })

  //           }
  //         });
  //       }
  //       //console.log('DATABASE STUDENT :', this.props.students);
  //       //console.log('DISPLAY STUDENT :', this.state.display_student);
  //     }).catch((error) => {
  //       // error
  //     });
  // }


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.conveyance)) {
      this.props.getConveyance();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      if (_all_student && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      this.setState({
        display_student: _school_student
      })
    }
  }

  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.filteredSchoolData) {
  //     this.filterBySchoolHandler()
  //   }
  // }


  // filteredStrudent(resData) {

  //   const _students = resData.map((student) => {
  //     const xyz = { ...student };
  //     //xyz['convence_months'] = student.convence_months.length > 1 ? student.convence_months.split(",") : student.convence_months;
  //     xyz['convence_months'] = student.convence_months;
  //     xyz['checked'] = false;
  //     return xyz;
  //   })
  //   const _classes = this.props.classes.filter((item, index) => {
  //     /*if (item.is_section === 'No' && item.class_name_portal === class_name) {
  //       return item;
  //     }*/
  //   })
  //   if (this.props.user.user_category === "1") {
  //     this.setState({
  //       student: _students,
  //       class_section: _classes,
  //       display_student_with_checked: _students
  //     })
  //   } else if (this.props.user.user_category === "2") {
  //     this.setState({
  //       student: _students,
  //       display_student: _students,
  //       class_section: _classes,
  //       display_student_with_checked: _students
  //     })

  //   }
  // }

  // filterClasses(classes){
  //   if (this.props.user.user_category === "1") {
  //     this.setState({
  //       class_section: classes,
  //     });
  //   } else {
  //     this.setState({
  //       selected_classes: classes,
  //       class_section: classes,
  //     });
  //   }
  // }
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getSchoolHandler();
  //           // this.getClassesHandler();
  //          // this.getConvencesHandler();
  //          // this.getStudentRecords();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getConvencesHandler() {
  //   axios.get(READ_CONV_URL)
  //     .then(res => {

  //       const conveyance = res.data;
  //       this.setState({
  //         conveyance: conveyance,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.props.conveyance);
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj1 = {
  //     group_id: this.props.group_id,
  //     school_id: this.props.school_id,
  //     user_category: this.props.user_category,
  //     session_year_id: this.props.session_year_id,
  //   }
  //   axios.post(READ_CLASS_URL, obj1)
  //     .then(res => {
  //       const classes = res.data;
  //       if (this.props.user_category === "1") {
  //         this.setState({
  //           classes: classes,
  //           class_section: classes,
  //           errorMessages: res.data.message
  //         });
  //       } else {
  //         this.setState({
  //           classes: classes,
  //           selected_classes: classes,
  //           class_section: classes,
  //           errorMessages: res.data.message
  //         });
  //       }
  //       //console.log(this.props.classes);
  //     }).then(res => {
  //       //const _class_id = this.props.classes[0].id;
  //       //this.getStudentRecords(_class_id);
  //     })
  //     .catch((error) => {
  //       // error
  //     });
  // }
  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.props.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.props.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  confirmBoxSubmitOne = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.singleUpdateHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  singleUpdateHandler = (admission_number) => {
    //e.preventDefault();
    let obj = this.state.display_student.filter((checked_student) => {
      return checked_student['admission_number'] === admission_number
    })
    const singleObj = { myObj: obj };
    //console.log(JSON.stringify(singleObj));
    loadProgressBar();
    axios.post(UPDATE_STUDENT_URL, singleObj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          // update_student: [],
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.updateHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  updateHandler = () => {
    const obj = { myObj: this.props.update_student };
    //console.log(JSON.stringify(obj));
    //e.preventDefault();
    loadProgressBar();
    axios.post(UPDATE_STUDENT_URL, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes);
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          // update_student: [],
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }
  render() {
    const { display_student, class_section } = this.state;
    const { user, classes, schools, conveyance, students, filteredSchoolData } = this.props;
    // console.log(display_student);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Student</title>
        </Helmet>
        {(user && classes && schools && conveyance && students) &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">All Student</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  {/* 
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Class :</label>
                    <select
                      ref='classinx'
                      value={selected_class_inx}
                      className="form-control form-control-sm" name="selected_class"
                      onChange={event => this.changeHandler(event, 'selected_class')} >
                      <option value="">Select ...</option>
                      {selected_classes.map((option, index) => {
                        return (<option key={index} value={index}>{option.class_name}</option>)
                      })}
                    </select>
                  </div> */}
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                    filterByClsHandler={this.filterByClsHandler}
                  />
                  <div className="form-group mt-1">
                    <NavLink to="/add_student.jsp" className="btn btn-primary btn-sm">
                      Add New <i className="fa fa-plus" />
                    </NavLink>
                  </div>
                </div>
              </div>
            </div>

            <div className="card card-box sfpage-cover">
              <div className="card-body p-1 sfpage-body">
                {display_student &&
                  <div className="table-scrollable">
                    <table className="table-responsive table table-striped table-bordered table-hover table-sm m-0">
                      <thead>
                        <tr>
                          <th />
                          <th>
                            <div className="custom-control custom-checkbox">
                              <input type="checkbox"
                                id="select_all" className="custom-control-input"
                                onChange={event => this.checkHandler(event, 'select_all', true)} />
                              <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                            </div>
                          </th>
                          <th />
                          <th>Enr. No.</th>
                          <th>Student & Father's Name</th>
                          <th>Class</th>
                          <th>Roll Number</th>
                          <th>Seat Type</th>
                          <th>Stationary</th>
                          {conveyance.length > 0 ?
                            <th>Convence Area</th>
                            : null}
                          {class_section.length > 0 ?
                            <th>Class in Study</th>
                            : null}
                          {/*<th>Convence Month</th>*/}
                          <th>Action</th>
                        </tr>
                      </thead>
                      {display_student.length > 0 ?
                        <tbody>
                          {display_student.map((item, index) => {
                            return (
                              <tr className={(item.free_seat === '0') ? 'odd gradeX' : 'odd gradeX table-warning'} key={index}>
                                <td>
                                  {index + 1}.
                          </td>
                                <td>
                                  <div className="custom-control custom-control-inline custom-checkbox">
                                    <input type="checkbox"
                                      checked={item.checked}
                                      id={`check_` + index} name="customRadio" className="custom-control-input"
                                      onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
                                    <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                                  </div>
                                </td>
                                <td className="profile-pic">
                                  <NavLink className="" to={`edit_student.jsp/${item.s_id}`}>

                                    {!isEmpty(item.student_image) ?
																			<ImageLoader
																			src={`${process.env.PUBLIC_URL}` + item.student_image} 
																			alt={item.student_name}
																			className="img-circle user-img-circle"
																			fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/dp.jpg`}
																			/>
																		: (item.gender === 'Boy' ?
																			<img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
																			:
																			<img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                                    }
                                    
                                    {/* {!isEmpty(item.student_image) ?
                                      < img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
                                      : (item.gender === 'Boy' ?
                                        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                        :
                                        <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                                    } */}
                                  </NavLink>
                                </td>
                                <td>{item.admission_number}</td>
                                <td><NavLink className="" to={`student_profile.jsp/${item.s_id}`}>
                                  {item.student_name}
                                </NavLink>
                                  <br /> S/o  {item.father_name}</td>
                                <td>{item.stu_class}
                                </td>
                                <td>
                                  <input type="text"
                                    className="form-control form-control-sm"
                                    value={item.roll_number}
                                    onChange={event => this.checkHandler(event, `roll_number`, JSON.stringify(item))} />
                                </td>
                                <td>
                                  <div className="custom-control custom-checkbox">
                                    <input type="checkbox" className="custom-control-input" id={`switch_` + index}
                                      checked={(item.free_seat === '1' ? true : false)}
                                      onChange={event => this.checkHandler(event, `student_type`, JSON.stringify(item))} />
                                    <label className={'custom-control-label label label-sm ' + ((item.free_seat === '0') ? 'label-info' :
                                      'label-danger')} htmlFor={`switch_` + index}>
                                      {(item.free_seat === '0') ? 'Paid' : 'Free'}</label>
                                  </div>
                                </td>
                                <td>
                                  {item.is_rte_student === 'YES' ?
                                    <div className="custom-control custom-checkbox">
                                      <input type="checkbox" className="custom-control-input" id={`stationary_` + index}
                                        checked={(item.rte_stationary === '1' ? true : false)}
                                        onChange={event => this.checkHandler(event, `rte_stationary`, JSON.stringify(item))} />
                                      <label className={"custom-control-label label label-sm " + ((item.rte_stationary === '0') ? 'label-warning' :
                                        'label-sucess')} htmlFor={`stationary_` + index}>
                                        {(item.rte_stationary === '0') ? 'Pending' : 'Done'}</label>
                                    </div>
                                    : null}
                                </td>
                                {conveyance.length > 0 ?
                                  <td>
                                    <select className="form-control form-control-sm"
                                      value={item.convence_area}
                                      onChange={event => this.checkHandler(event, `stopage_palace`, JSON.stringify(item))} >
                                      <option value=''>Select...</option>
                                      {conveyance.map((option, index1) => {
                                        return (
                                          <option key={index1}
                                            value={option.stoppage_name}>
                                            {option.stoppage_name} [{option.stoppage_amo}]</option>
                                        )
                                      })}
                                    </select>
                                  </td>
                                  : null}
                                {class_section.length > 0 ?
                                  <td>
                                    <select className="form-control form-control-sm"
                                      value={item.software_class}
                                      onChange={event => this.checkHandler(event, 'software_class', JSON.stringify(item))}>
                                      <option value>Select...</option>
                                      {class_section.map((option, index) => {
                                        return (
                                          <option key={index} >{option.class_name}</option>
                                        )
                                      })}
                                    </select>
                                  </td>
                                  : null}
                                {/*<td width="250">
                          <div className="row">
                            <Picky
                              disabled={(item.convence_area === '' ? true : false)}
                              className="col-9 pr-0"
                              value={item.convence_months}
                              options={convence_months_arr}
                              onChange={event => this.checkHandler(event, `convence_months`, JSON.stringify(item))}
                              open={false}
                              valueKey="id"
                              labelKey="name"
                              multiple={true}
                              includeSelectAll={true}
                              includeFilter={true}
                              dropdownHeight={200}
                            />
                            <div className="col-3 pl-0">
                              <button type="button" className="btn btn-block btn-primary btn-sm"><i className="fas fa-check"></i></button>
                            </div>
                          </div>
                          </td>*/}
                                <td className="">
                                  <div className="d-flex">
                                    <NavLink to={`/student_profile.jsp/${item.se_id}`} className="btn btn-danger btn-sm mr-1">
                                      View
                            </NavLink>
                                    <NavLink to={`/edit_student.jsp/${item.se_id}`} className="btn btn-primary btn-sm mr-1">
                                      Edit
                            </NavLink>
                                    <button type="button" className="btn btn-secondary btn-sm"
                                      onClick={event => this.confirmBoxSubmitOne(event, item.s_id)}>
                                      Update
                            </button>
                                  </div>
                                </td>
                              </tr>
                            )
                          })}

                        </tbody>
                        : null}
                    </table>
                  </div>
                }
              </div>
              <div className="card-footer text-right">
                <button type="button"
                  onClick={event => this.confirmBoxSubmit(event)}
                  className="btn btn-primary mr-2">Update</button>
                <button type="button" className="btn btn-secondary"
                  onClick={event => this.generateNumberHandlar(event)}>
                  Generate  Roll Number</button>
              </div>
            </div>
          </>}
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const { item: conveyance } = state.conveyance;
  const { item: students } = state.students;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, classes, schools, conveyance, students,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getConveyance: conveyanceAction.getConveyance,
  getStudents: studentsAction.getStudents,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllStudents));