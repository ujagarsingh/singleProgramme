import React, { Component } from 'react';
import { withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
  accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction,
  schoolsAction, classesAction, accManagerActions
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


import CommonFilters from '../utility/Filter/filter-schools';
import { NavLink } from 'react-router-dom';

class BalanceSheet extends Component {

  state = {
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.accLedgerEntry)) {
      this.props.getAccLedgerEntry();
    }
    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }
    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      const _accGroup = this.props.accGroup;
      const _accLedgerEntry = this.props.accLedgerEntry;
      if (_all_student && _filter && _accGroup && _accLedgerEntry) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    const _all_groups = this.props.accGroup;
    const _all_ledger = this.props.accLedger;
    const _all_accLedgerEntry = this.props.accLedgerEntry;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      if (_school_student.length > 0) {
        this.setState({
          display_student: _school_student
        }, () =>
          //this.getFinalDataHandler() 
          this.props.getACCManager({
            acc_group: _all_groups,
            acc_ledgers: _all_ledger,
            acc_entries: _all_accLedgerEntry,
            students: _all_student,
          })
        )
      }
    }
  }

  getGroupwiseDetail = (group_title, group_id) => {
    const _blanceData = this.props.accManager.group_balance;
    if (!isEmptyObj(_blanceData)) {
      const _crnt_grp = _blanceData.filter((item) => {
        if (item.id === group_id) {
          return item
        }
      });
      const g_total = _crnt_grp[0].cl_blnc;
      let parent_row =
        <NavLink to={`group_summary.jsp/${'2'}/${_crnt_grp[0].id}`} className="link-without-color">
          <div className="bs-detail-head">
            <div className="head-name">{group_title}</div>
            <div className="head-amount">{(g_total === 0) ? '' : g_total}</div>
          </div>
        </NavLink>;
      let child_rows = _crnt_grp[0].sub_group.map((item, index) => {
        const sub_total = item.cl_blnc;
        return (
          <NavLink key={index} to={`group_summary.jsp/${'3'}/${item.id}/${_crnt_grp[0].id}`} className="link-without-color">
            <div className="bs-detail-sub-head" >
              <div className="sub-head-name">{item.group_name}</div>
              <div className="sub-head-amount">{(sub_total === 0) ? '' : sub_total}</div>
            </div>
          </NavLink>
        )
      });
      const abc = <div className="bs-detail-zone">{parent_row} {child_rows}</div>;
      return abc;
    }
  }
  getPandLDetail = (group_title, group_id) => {
    const _blanceData = this.props.accManager.group_balance;
    if (!isEmptyObj(_blanceData)) {
      const _crnt_grp = _blanceData.filter((item) => {
        if (item.id === group_id) {
          return item
        }
      });
      const g_total = _crnt_grp[0].cl_blnc;
      let parent_row =
        <NavLink to={`profit_n_loss.jsp`} className="link-without-color">
          <div className="bs-detail-head">
            <div className="head-name">{group_title}</div>
            <div className="head-amount">{(g_total === 0) ? '' : g_total}</div>
          </div>
        </NavLink>;
      let child_rows = <>
        <div className="bs-detail-sub-head">
          <div className="sub-head-name">Opening Balance</div>
          <div className="sub-head-amount"></div>
        </div>
        <div className="bs-detail-sub-head">
          <div className="sub-head-name">Current Period</div>
          <div className="sub-head-amount">{(g_total === 0) ? '' : g_total}</div>
        </div>
      </>;
      const abc = <div className="bs-detail-zone">{parent_row} {child_rows}</div>;
      return abc;
    }
  }

  render() {
    const { user, students, schools, filteredSchoolData, accManager } = this.props;
    // console.log(this.props)
    return (
      <div className="page-content">
        <Helmet>
          <title>Balance Sheet</title>
        </Helmet>
        {(user && students && schools) &&
          <div className="page-bar d-flex">
            <div className="page-title">Balance Sheet</div>
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />
              </div>
            </div>
          </div>
        }
        { accManager && 
          <div className="card card-box sfpage-cover">
            <div className="card-body p-1 sfpage-body">
              <div className="acc-page acc-midline page-balance-sheet">
                <div className="acc-page-head container-fluid ">
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="sec-title">
                        <div className="title-zone">Liabilities</div>
                        <div className="info-zone">
                          <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                          <div className="fy-detail">as at 1-Jul-2020</div>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="sec-title">
                        <div className="title-zone">Assets</div>
                        <div className="info-zone">
                          <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                          <div className="fy-detail">as at 1-Jul-2020</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="acc-page-body container-fluid ">
                  <div className="row">
                    <div className="col-sm-6">
                      {this.getGroupwiseDetail('Capital Account', "5")}
                      <div className="bs-detail-zone">
                        <div className="bs-detail-head">
                          <div className="head-name">Loans (Liability)</div>
                          <div className="head-amount"></div>
                        </div>
                        <div className="bs-detail-sub-head"></div>
                      </div>
                      {this.getGroupwiseDetail('Current Liabilities', "4")}
                      {this.getPandLDetail('Excess of income over expenditure (P&L)', "1001")}
                      {/* <div className="bs-detail-zone">
                        <div className="bs-detail-head">
                          <div className="head-name">Excess of income over expenditure (P&L)</div>
                          <div className="head-amount">9,450.00</div>
                        </div>
                        <div className="bs-detail-sub-head">
                          <div className="sub-head-name">Opening Balance</div>
                          <div className="sub-head-amount">6,750.00</div>
                        </div>
                        <div className="bs-detail-sub-head">
                          <div className="sub-head-name">Current Period</div>
                          <div className="sub-head-amount">2,700.00</div>
                        </div>
                      </div> */}
                    </div>

                    <div className="col-sm-6">
                      {this.getGroupwiseDetail('Current Assets', "3")}
                    </div>
                  </div>
                </div>
                <div className="acc-page-footer container-fluid ">
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="sec-foot">
                        <div className="title-zone">Total</div>
                        <div className="amount-zone">9,450.00</div>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="sec-foot">
                        <div className="title-zone">Total</div>
                        <div className="amount-zone">9,450.00</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        }
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  const { item: accLedger } = state.accLedger;
  const { item: accGroup } = state.accGroup;
  const { item: accLedgerEntry } = state.accLedgerEntry;
  const { item: accManager } = state.accManager;
  return {
    user, students, accLedger, accGroup, accLedgerEntry, schools, accManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getStudents: studentsAction.getStudents,
  getAccLedger: accLedgerActions.getAccLedger,
  getAccGroup: accGroupActions.getAccGroup,
  getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
  getACCManager: accManagerActions.getACCManager,

}

export default connect(mapStateToProps, actionCreators)(withRouter(BalanceSheet));
