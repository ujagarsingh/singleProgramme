import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
//import { Picky } from 'react-picky';
//import DatePicker from 'react-date-picker';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_PTL_CLASSES = `http://schools.rajpsp.com/api/classes/read_portal_classes.php`;
// const READ_CLASS = `http://schools.rajpsp.com/api/classes/read_one.php`;
// const UPDATE_CLASS = `http://schools.rajpsp.com/api/classes/update.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SESSION_YEAR = `http://schools.rajpsp.com/api/session_year_id/read.php`;

class EditClass extends Component {
  state = {
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    session_year_arr: [],
    ptl_classes: [],
    classes: [],
    id: '',
    medium: '',
    seq_number: '',
    class_name: '',
    is_section: '',
    class_name_portal: '',
    roll_num_start: '',
    roll_num_end: '',
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      this.schoolFilterHandler();
    } else if (fieldName === 'session_year_id') {
      const _inx = event.target.value;
      const _session_year = (!isEmpty(_inx)) ? this.state.session_year_arr[_inx].ses_year : '';
      this.setState({
        session_year_id: _session_year
      })
    } else if (fieldName === 'medium') {
      this.classFilterByMediumHandler();
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  schoolFilterHandler() {
    const _inx = this.refs.school.value;
    const _sch_id = (!isEmpty(_inx)) ? this.state.schools[_inx].id : '';
    const _medium = (!isEmpty(_inx)) ? this.state.schools[_inx].sch_medium : [];
    sessionStorage.setItem("school_id", _sch_id);
    //this.getPortalClassesHandler();
    this.setState({
      school_id: _sch_id,
      medium_arr: _medium,
      medium: (_medium.length === 1 ? _medium[0] : ''),
      selected_school_index: _inx,
      selected_class_inx: ''
    }, () => { this.classFilterByMediumHandler() })
  }
  classFilterByMediumHandler() {
    const _medium = this.refs.medium.value;
    const _classes = this.state.ptl_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      }
    })
    this.setState({
      classes: _classes
    })
  }
  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = this.props.selected_item;
    // console.log(obj);
    // debugger;

    this.setState({
      id: obj.id,
      medium: obj.medium,
      school_id: obj.school_id,
      class_name: obj.class_name,
      seq_number: obj.seq_number,
      is_section: obj.is_section,
      class_name_portal: obj.class_name_portal,
      roll_num_start: obj.roll_num_start,
      roll_num_end: obj.roll_num_end,
      // session_year_id: obj.session_year_id,
    })
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getSessionYearHandler();
  //           this.getEditableClassHandlar();
  //           this.getPortalClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getSessionYearHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SESSION_YEAR, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         session_year_arr: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  // getPortalClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   axios.post(GET_PTL_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         ptl_classes: getRes,
  //         errorMessages: getRes.message
  //       }, () => { this.classFilterByMediumHandler() });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })

  // };
  // getEditableClassHandlar() {
  //   const { match } = this.props;
  //   axios.get(READ_CLASS + `?id=` + match.params.id)
  //     .then(res => {
  //       let getRes = res.data;
  //       let _school_inx = '';
  //       this.state.schools.forEach((item, inx) => {
  //         if (item.id === getRes.school_id) {
  //           _school_inx = inx;
  //         }
  //       });
  //       let _session_inx = '';
  //       this.state.session_year_arr.forEach((item, inx) => {
  //         if (item.ses_year === getRes.session_year_id) {
  //           _session_inx = inx;
  //         }
  //       });
  //       // let _portal_class_inx = '';
  //       // this.state.ptl_classes.forEach((item, inx) => {
  //       //   if (item.stu_class === getRes.stu_class) {
  //       //     _portal_class_inx = inx;
  //       //   }
  //       // });
  //       this.setState({
  //         id: getRes.id,
  //         medium: getRes.medium,
  //         selected_school_index: _school_inx,
  //         session_year_inx: _session_inx,
  //         school_id: getRes.school_id,
  //         class_name: getRes.class_name,
  //         seq_number: getRes.seq_number,
  //         is_section: getRes.is_section,
  //         class_name_portal: getRes.class_name_portal,
  //         roll_num_start: getRes.roll_num_start,
  //         roll_num_end: getRes.roll_num_end,
  //         //session_year_id: getRes.session_year_id,
  //         errorMessages: getRes.message,
  //       }, () => { this.schoolFilterHandler() });
  //       //console.log(this.state);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    const _state = this.state;
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.refs.school.value }
    }

    const form_obj = {
      id: _state.id,
      medium: _state.medium,
      is_section: _state.is_section,
      class_name: _state.class_name,
      seq_number: _state.seq_number,
      class_name_portal: _state.class_name_portal,
      roll_num_start: _state.roll_num_start,
      roll_num_end: _state.roll_num_end
    };

    const obj = { ...form_obj, ...default_obj }
    console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj);
    
    // debugger
    // axios.post(UPDATE_CLASS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }

  render() {
    const { class_name, medium, is_section,
      selected_school_index, seq_number, medium_arr, school_id,
      class_name_portal, roll_num_start, roll_num_end, formIsHalfFilledOut } = this.state;
    const { user, schools, classes, selected_item } = this.props;
    console.log(this.props);
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Class</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && selected_item && classes &&
          <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">
              Edit Class
          </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="control-label">Schools :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        disabled={true}
                        value={school_id}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                {/* <div className="form-group">
                <label className="control-label">Session Year :</label>
                <div className="form-input">
                  <select className="form-control form-control-sm"
                  required
                    ref='session_year_id'
                    value={session_year_inx}
                    onChange={event => this.changeHandler(event, 'session_year_id')}>
                    <option value="">Select ...</option>
                    {session_year_arr.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.ses_year}</option>
                        )
                      })}
                      </select>
                      </div>
                    </div> */}
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label">Medium :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='medium'
                        disabled={medium_arr.length > 1 ? false : true}
                        value={medium}
                        onChange={event => this.changeHandler(event, 'medium')}>
                        <option value="">Select ...</option>
                        {medium_arr.map((item, index) => {
                          return (
                            <option key={index} value={item}>{item}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label">Class Name (Portal)
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm" name="select"
                        value={class_name_portal}
                        disabled={true}
                        onChange={event => this.changeHandler(event, 'class_name_portal')}>
                        <option value>Select...</option>
                        {classes.map((option, index) => {
                          return (
                            <option key={index}>{option.class_name_portal}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label">Class Name (Software)
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="class_name"
                        placeholder="enter course name"
                        value={class_name}
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'class_name')}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label">Sequence Number
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select name="seq_number"
                        required
                        value={seq_number}
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'seq_number')}
                      >
                        <option>select ...</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label">Section
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        value={is_section}
                        onChange={event => this.changeHandler(event, 'is_section')}>
                        <option value>Select...</option>
                        <option value="Yes">Yes = Have Sction</option>
                        <option value="No">No = Not have Sction</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label"> Number Start
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="number"
                        placeholder=" Number Start"
                        value={roll_num_start}
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'roll_num_start')} />
                    </div>
                  </div>
                </div>
                <div className="col-md-2">
                  <div className="form-group">
                    <label className="control-label"> Number End
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="number"
                        placeholder=" Number End"
                        value={roll_num_end}
                        className="form-control form-control-sm"
                        onChange={event => this.changeHandler(event, 'roll_num_end')} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer text-right">
              <div className="form-actions  text-right">
                <button type="submit" className="btn btn-sm btn-primary mr-2">Update</button>
                {/* <NavLink to="/all_class.jsp" className="btn btn-danger">All Class</NavLink> */}
                <button onClick={event => this.props.closeEdit(event)} className="btn btn-sm btn-warning">
                  Exit </button>
              </div>
            </div>
          </form >
        }
      </div >
    )
  }
}
export default withRouter(EditClass);
