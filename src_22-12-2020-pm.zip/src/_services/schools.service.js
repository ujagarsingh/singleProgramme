// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const schoolsService = {
    getSchools,
    create,
    update
};

function getSchools() {
    loadProgressBar();
    const url = USER_URL + 'school/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'school/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'school/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
