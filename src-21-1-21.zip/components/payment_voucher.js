import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import DatePicker from 'react-date-picker';

import VoucherBody from '../includes/voucher_body';
import * as accMethod from '../utility/accounts';
import { NavLink } from 'react-router-dom';

class ReceiptVoucher extends Component {
  state = {
    formIsHalfFilledOut: false,
    cursor: 0,
    filter_data: [],
    credit_ledgers: [],
    debit_ledgers: [],
    current_ldr: '',
    voucher_type: 'Payment',
    first_vchr_type: 'CR',
    voucher_obj: {
      "child": [
        { "ldr_ref_id": "", "tr_amount": "", "tr_type": "CR", "ledger_name": "" }
      ]
    },
    vchr_date: new Date(),

    // voucher_obj: {
    //   "vch_no": "3163", "child": [
    //     { "ldr_ref_id": "5_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Fee Discount" },
    //     { "ldr_ref_id": "1_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Profit & Loss A/c" },
    //     { "ldr_ref_id": "6_LDR_4", "tr_amount": "45", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Teaching Staff Salary" },
    //     { "ldr_ref_id": "9_LDR_4", "tr_amount": "545", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Exam Fee" },
    //     { "ldr_ref_id": "14_LDR_4", "tr_amount": "54", "tr_type": "CR", "under_grp_id": "2", "under_grp_type": "P", "ledger_name": "Registration Fee" },
    //     { "ldr_ref_id": "49_STU_4", "tr_amount": "743", "tr_type": "DR", "under_grp_id": "10", "under_grp_type": "P", "ledger_name": "AASHISH MEENA S/o RAMBABU MEENA [141/Fourth]" }],
    //   "cr_total_amo": 743, "dr_total_amo": 743, "narration": "AASHISH MEENA S/o RAMBABU MEENA Total Due is Rs. 743.", "vchr_type": "Journal"
    // },
  }


  componentDidMount() {

  }
  componentWillUnmount(){
    // alert('unmounting 45')
    // document.removeEventListener('keydown', this, false)
    window.document.removeEventListener('keydown', (e) => {})
  }

  submitDataHandler = (obj) => {
    this.setState({
      voucher_obj: { "child": [{ "ldr_ref_id": "", "tr_amount": "", "tr_type": "CR", "ledger_name": "" }] },
      lockInputs: false,
      narration: ''
    }, () => {
      console.log(obj);
      accMethod.focusFirstHandler();
    })

  }

  render() {
    const { user, accountManager } = this.props;
    const { voucher_obj, voucher_type, vchr_date, first_vchr_type } = this.state;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Payment Voucher</title>
        </Helmet>
        <div className="page-bar d-flex">
          <div className="page-title"> Payment Voucher</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con inline-box">
              <div className="form-group mr-2 mt-2">
                <ul className="nav d-flex mr-4">
                  <li className="nav-item mr-1">
                    <NavLink
                      to="/receipt_voucher.jsp"
                      className="btn btn-outline-secondary btn-sm">Receipt</NavLink>
                  </li>
                  <li className="nav-item mr-1">
                    <NavLink
                      to="/payment_voucher.jsp"
                      className="btn btn-outline-secondary btn-sm">Payment</NavLink>
                  </li>
                  <li className="nav-item mr-1">
                    <NavLink
                      to="/payment_voucher.jsp"
                      className="btn btn-outline-secondary btn-sm">Journal</NavLink>
                  </li>
                  <li className="nav-item mr-1">
                    <NavLink
                      to="/payment_voucher.jsp"
                      className="btn btn-outline-secondary btn-sm">Contra</NavLink>
                  </li>
                </ul>
              </div>
              <div className="form-group mt-1">
                <DatePicker
                  onChange={this.examStartDate}
                  value={vchr_date}
                  showLeadingZeroes={true}
                //minDate={new Date()}
                />
              </div>
            </div>
          </div>
        </div>
        {user && voucher_obj && accountManager &&
          <div className="card card-box sfpage-cover light-trans">
            <div className="card-body p-1 sfpage-body">
              <VoucherBody
                all_ledgers={accountManager['all_ledgers']}
                voucher_type={voucher_type}
                voucher_obj={voucher_obj}
                first_vchr_type={first_vchr_type}
                submitDataHandler={this.submitDataHandler}
              />
            </div>
          </div>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accountManager } = state.accountManager;
  return {
    user, accountManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
}

export default connect(mapStateToProps, actionCreators)(withRouter(ReceiptVoucher));