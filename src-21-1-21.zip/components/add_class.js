import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, portalClassesAction, sessionYearsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_PTL_CLASSES = `http://schools.rajpsp.com/api/classes/read_portal_classes.php`;
// const GET_SOFTWARE_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
// const CREATE_CLASS = `http://schools.rajpsp.com/api/classes/create.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SESSION_YEAR = `http://schools.rajpsp.com/api/session_year_id/read.php`;

class AddClass extends Component {
  state = {
    schools: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    sessionYears: [],
    ptl_classes: [],
    ptl_classes_medium: [],
    sft_classes: [],
    sft_classes_medium: [],
    session_year_inx: "",
    class_name: '',
    class_name_portal: '',
    seq_number: '',
    is_section: 'No',
    roll_num_start: '',
    medium: '',
    roll_num_end: '',
    formIsHalfFilledOut: false,
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      // sessionStorage.setItem("school_id", _sch_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      }, () => {
        // this.getPortalClassesHandler();
      })
    } else if (fieldName === 'session_years') {
      const _inx = event.target.value;
      const _session_year = (!isEmpty(_inx)) ? this.props.sessionYears[_inx].id : '';
      this.setState({
        session_year_id: _session_year,
        session_year_inx: _inx
      })
    } else if (fieldName === 'medium') {
      this.classFilterByMediumHandler();
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  }; 


  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getPortalClasses();
    }
    if (isEmptyObj(this.props.sessionYears)) {
      this.props.getSessionYears();
    }
    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_classes = this.props.classes;
      if (_all_classes && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _classes = this.props.portalClasses;
    if (!isEmpty(_classes)) {
      const _sch_classes = _classes.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        ptl_classes: _sch_classes,
      })
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           // this.getSchoolHandler();
  //           this.getSoftwareClassesHandler();
  //           this.getSessionYearHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }
  // getSessionYearHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SESSION_YEAR, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         sessionYears: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  classFilterByMediumHandler() {
    const _medium = this.refs.medium.value;
    const _ptl_classes = this.state.ptl_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      } else { return false }
    })
    const _sft_classes = this.state.sft_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      } else { return false }
    })
    this.setState({
      ptl_classes_medium: _ptl_classes,
      sft_classes_medium: _sft_classes
    })
  }
  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getPortalClassesHandler() {
  //   const obj = {
  //     school_id: this.state.school_id,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   this.props.getPortalClasses(obj)
  //   // axios.post(GET_PTL_CLASSES, obj)
  //   //   .then(res => {
  //   //     const getRes = res.data;
  //   //     this.setState({
  //   //       ptl_classes: getRes,
  //   //       errorMessages: getRes.message
  //   //     }, () => { this.classFilterByMediumHandler() });
  //   //     ////console.log(this.state.classes);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })
  // };
  // getSoftwareClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   axios.post(GET_SOFTWARE_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         sft_classes: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }

  componentWillReceiveProps(nextProps) {
    if (nextProps.portalClasses) {
      const _portalClasses = nextProps.portalClasses;
      const _school_id = this.state.school_id;
      const _filtered_classes = _portalClasses.filter((item) => {
        if (item.school_id === _school_id) {
          return item
        }
      })

      this.setState({
        ptl_classes_medium: _filtered_classes
      });
    }
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Create this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler() {
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      medium: this.state.medium,
      class_name: this.state.class_name,
      seq_number: this.state.seq_number,
      is_section: this.state.is_section,
      class_name_portal: this.state.class_name_portal,
      roll_num_start: this.state.roll_num_start,
      roll_num_end: this.state.roll_num_end
    };
    console.log(JSON.stringify(obj));
    this.props.create(obj);
    // axios.post(CREATE_CLASS, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  render() {
    const { session_year_inx, seq_number, medium_arr, selected_school_index,
      medium, is_section, ptl_classes_medium, formIsHalfFilledOut, ptl_classes } = this.state;
    const { user, schools, sessionYears, portalClasses } = this.props;
    console.log(this.state);
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Class</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        {user && schools && sessionYears &&
          <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
            <div className="card-header">
              <div className="page-title">Add Class</div>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Session Year :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='session_years'
                        value={session_year_inx}
                        onChange={event => this.changeHandler(event, 'session_years')}>
                        <option value="">Select ...</option>
                        {sessionYears.map((item, index) => {
                          return (
                            <option key={index} value={item.id}>{item.ses_year}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                      <label className="control-label">Schools :</label>
                      <div className="form-input">
                        <select className="form-control form-control-sm"
                          required
                          ref='school'
                          value={selected_school_index}
                          onChange={event => this.changeHandler(event, 'school')}>
                          <option value="">Select ...</option>
                          {schools.map((item, index) => {
                            return (
                              <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                            )
                          })}
                        </select>
                      </div>
                    </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Medium :</label>
                    <div className="form-input">
                      <select className="form-control form-control-sm"
                        required
                        ref='medium'
                        disabled={medium_arr.length > 1 ? false : true}
                        value={medium}
                        onChange={event => this.changeHandler(event, 'medium')}>
                        <option value="">Select ...</option>
                        {medium_arr.map((item, index) => {
                          return (
                            <option key={index} value={item}>{item}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                </div>
                {portalClasses && ptl_classes &&
                  <>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label">Class Name (Portal)
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'class_name_portal')}>
                            <option value>Select...</option>
                            {ptl_classes_medium.map((option, index) => {
                              return (
                                <option key={index}>{option.stu_class}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label">Class Name (Software)
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <input type="text" name="class_name"
                            placeholder="enter class name"
                            className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'class_name')}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label">Sequence Number
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select name="seq_number"
                            required
                            value={seq_number}
                            className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'seq_number')}
                          >
                            <option>select ...</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label">Section
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <select className="form-control form-control-sm"
                            value={is_section}
                            onChange={event => this.changeHandler(event, 'is_section')}>
                            <option value>Select...</option>
                            <option value="Yes">Yes = Have Sction</option>
                            <option value="No">No = Not have Sction</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label"> Number Start
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <input type="text" name="csuration"
                            placeholder=" Number Start"
                            className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'roll_num_start')} />
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-2">
                      <div className="form-group">
                        <label className="control-label"> Number End
                        <span className="required"> * </span>
                        </label>
                        <div className="form-input">
                          <input type="text" name="csuration"
                            placeholder=" Number Start"
                            className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'roll_num_end')} />
                        </div>
                      </div>
                    </div>
                  </>
                }
              </div>
            </div>
            <div className="card-footer text-right">
              <button type="submit" className="btn btn-primary mr-2">Submit</button>
              {/* <NavLink to="/all_class.jsp" className="btn btn-danger">All Class</NavLink> */}
              <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
                Cancel
            </button>
            </div>
          </form>
        }
      </div >
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: sessionYears } = state.sessionYears;
  const { item: portalClasses } = state.portalClasses;
  const filteredSchoolData = state.filteredSchoolData;
  return { user, schools, sessionYears, portalClasses, filteredSchoolData };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getSessionYears: sessionYearsAction.getSessionYears,
  getPortalClasses: portalClassesAction.getPortalClasses,
  create: classesAction.create,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddClass));