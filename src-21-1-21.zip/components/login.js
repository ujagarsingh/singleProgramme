import React, { Component } from 'react';
import { connect } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { authenticActions } from '../_actions';

class Login extends Component {
  constructor(props) {
    super(props);
    // set initial state
    this.state = {
      user_type: '2',
      login_id: '12345678',
      customer_id: '3142480',
      mobile: '9828784536',
      school_id: '4',
      stu_sr_no: '2',
      password: '1234',
      loginById: false,
      isresendActive: true,
    }
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value
    });
  };

  loginByIdHandler(event) {
    event.preventDefault();
    this.setState({
      loginById: true
    })
  }
  loginByDetailHandler(event) {
    event.preventDefault();
    this.setState({
      loginById: false
    })
  }

  componentDidMount() {
    sessionStorage.clear();
  }

  submitHandler = (event) => {
    event.preventDefault();
    let obj = "";
    if (this.state.loginById) {
      obj = {
        login_by: "login_id",
        user_type: this.state.user_type,
        login_id: this.state.login_id,
        password: this.state.password,
      };
    } else {
      if (this.state.user_type === "1") {
        // super admin
        obj = {
          login_by: "login_detail",
          user_type: this.state.user_type,
          customer_id: this.state.customer_id,
          mobile: this.state.mobile,
          password: this.state.password,
        };
      } else if (this.state.user_type === "2") {
        // admin
        obj = {
          login_by: "login_detail",
          user_type: this.state.user_type,
          mobile: this.state.mobile,
          password: this.state.password,
        };
      } else if (this.state.user_type === "3") {
        // employee
        obj = {
          login_by: "login_detail",
          user_type: this.state.user_type,
          mobile: this.state.mobile,
          password: this.state.password,
        };
      } else if (this.state.user_type === "4") {
        // student
        obj = {
          login_by: "login_detail",
          user_type: this.state.user_type,
          mobile: this.state.mobile,
          school_id: this.state.school_id,
          stu_sr_no: this.state.stu_sr_no,
          password: this.state.password,
        };
      };
    }

    console.log(JSON.stringify(obj));
    this.props.login(obj);
    
  }


  render() {
    const { user_type, loginById, customer_id, login_id, mobile, school_id, stu_sr_no, password } = this.state;
   //  console.log(this.state);
    return (
      <div className="login-page-bg h-100 w-100">
        <Helmet>
          <title>Login</title>
        </Helmet>
        <div className="login-box-cover h-100 w-100">
          <div className="login-box  bg-lightGray">
            <form className="login-form  bg-primary" onSubmit={this.submitHandler}>
              <span className="login-logo">
                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/logo-2.png`} />
              </span>
              <span className="login-title pt-2 pb-2">Login</span>
              <div className="form-group mt-1">
                <label className="control-label text-white mb-0">User Type</label>
                <div className="form-group mt-0">
                  <div className="input-group m-0">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i className="fa fa-user"></i></span>
                    </div>
                    <select
                      required
                      autoFocus
                      name="user_type"
                      className="form-control form-control-sm"
                      value={user_type}
                      onChange={event => this.changeHandler(event, 'user_type')} >
                      <option value="">.....</option>
                      <option value="1">Super Admin</option>
                      <option value="2">Admin</option>
                      <option value="3">Professional</option>
                      <option value="4">Student</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="btn-group d-flex">
                <button type="button"
                  className={`d-block btn-sm btn ` + (loginById ? "btn-dark" : "btn-light")}
                  onClick={event => this.loginByIdHandler(event)}>
                  Login Id</button>
                <button type="button"
                  className={`d-block btn-sm btn ` + (loginById ? "btn-light" : "btn-dark")}
                  onClick={event => this.loginByDetailHandler(event)}>
                  Login Detail</button>
              </div>
              {loginById ?

                <div className="bg-dark bg-trans-30 p-3" >

                  <div className="form-group mt-1">
                    <label className="control-label text-white mb-0">Login ID</label>
                    <div className="form-group mt-0">
                      <div className="input-group m-0">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-user"></i></span>
                        </div>
                        <input type="number"
                          required
                          className="form-control form-control-sm"
                          value={login_id}
                          onChange={event => this.changeHandler(event, 'login_id')}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mt-1">
                    <label className="control-label text-white mb-0">Password</label>
                    <div className="form-group mt-0">
                      <div className="input-group m-0">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-user"></i></span>
                        </div>
                        <input type="number"
                          required
                          className="form-control form-control-sm"
                          value={password}
                          onChange={event => this.changeHandler(event, 'password')}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                :
                <div className="bg-dark bg-trans-30 p-3" >
                  {(user_type === "1") ?
                    <div className="form-group mt-1">
                      <label className="control-label text-white mb-0">Customer Id</label>
                      <div className="form-group mt-0">
                        <div className="input-group m-0">
                          <div className="input-group-prepend">
                            <span className="input-group-text"><i className="fa fa-user"></i></span>
                          </div>
                          <input type="number"
                            required
                            className="form-control form-control-sm"
                            value={customer_id}
                            onChange={event => this.changeHandler(event, 'customer_id')}
                          />
                        </div>
                      </div>
                    </div>
                    : null}
                  {user_type === "4" ?
                    <>
                      <div className="form-group mt-1">
                        <label className="control-label text-white mb-0">School Id</label>
                        <div className="form-group mt-0">
                          <div className="input-group m-0">
                            <div className="input-group-prepend">
                              <span className="input-group-text"><i className="fa fa-user"></i></span>
                            </div>
                            <input type="number"
                              required
                              className="form-control form-control-sm"
                              value={school_id}
                              onChange={event => this.changeHandler(event, 'school_id')}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="form-group mt-1">
                        <label className="control-label text-white mb-0">Sr No.</label>
                        <div className="form-group mt-0">
                          <div className="input-group m-0">
                            <div className="input-group-prepend">
                              <span className="input-group-text"><i className="fa fa-user"></i></span>
                            </div>
                            <input type="number"
                              required
                              className="form-control form-control-sm"
                              value={stu_sr_no}
                              onChange={event => this.changeHandler(event, 'stu_sr_no')}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                    : null}
                  <div className="form-group mt-1">
                    <label className="control-label text-white mb-0">Registered Mobile</label>
                    <div className="form-group mt-0">
                      <div className="input-group m-0">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-user"></i></span>
                        </div>
                        <input type="number"
                          required
                          className="form-control form-control-sm"
                          value={mobile}
                          onChange={event => this.changeHandler(event, 'mobile')}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mt-1">
                    <label className="control-label text-white mb-0">Password</label>
                    <div className="form-group mt-0">
                      <div className="input-group m-0">
                        <div className="input-group-prepend">
                          <span className="input-group-text"><i className="fa fa-user"></i></span>
                        </div>
                        <input type="number"
                          required
                          className="form-control form-control-sm"
                          value={password}
                          onChange={event => this.changeHandler(event, 'password')}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              }
              <div className="mt-3">
                <div className="form-group d-flex">
                  <NavLink to="/Home.jsp" className="btn btn-danger mr-auto">
                    Back</NavLink>
                  <button
                    type="submit"
                    className="btn btn-primary btn-sm">Login</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    )
  }
}


function mapState(state) {
  const { loggingIn } = state.authentication;
  return { loggingIn };
}

const actionCreators = {
  login: authenticActions.login,
  logout: authenticActions.logout
};

export default connect(mapState, actionCreators)(withRouter(Login));

