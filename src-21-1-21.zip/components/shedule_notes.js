import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import axios from 'axios';
import { connect } from 'react-redux';
import { schoolsAction, examSdulNotesAction, examsCategoryAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import EditSheduleNotes from './edit_shedule_notes';
import CommonFilters from '../utility/Filter/filter-schools';
// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_SHEDULES_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const DELETE_SHEDULES_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/delete.php`;

class AllGalleries extends Component {
  state = {
    shedules_arr: [],
    selected_school_index: "",
    schools: [],
    shedule_notes_arr: [],
    display_notes_arr: [],
    medium_arr: [],
    medium: "",
    current_exam_inx: "",
    school_name: "",
    exams: [],
    selected_exams: [],
    editItem: false,
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    // if (fieldName === 'school') {
    //   const _inx = event.target.value;
    //   const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
    //   const _sch_name = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_name : '';
    //   const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
    //   sessionStorage.setItem("school_id", _sch_id);
    //   this.filterExamsCategoriesHandler(_sch_id);
    //   this.setState({
    //     school_id: _sch_id,
    //     school_name: _sch_name,
    //     medium_arr: _medium,
    //     medium: (_medium.length === 1 ? _medium[0] : ''),
    //     selected_school_index: _inx,
    //     exam_name: '',
    //     current_exam_inx: '',
    //     exam_id: '',
    //     formIsHalfFilledOut: true
    //   })
    // } else 
    if (fieldName === 'current_exam') {
      const _examIdx = event.target.value;
      if (_examIdx !== '') {
        const _exam_id = this.state.selected_exams[_examIdx].id;
        const _exam_name = this.state.selected_exams[_examIdx].cat_name;
        this.setState({
          exam_name: _exam_name,
          current_exam_inx: _examIdx,
          exam_id: _exam_id,
          formIsHalfFilledOut: true
        }, () => {
          // this.filterExamsHandler()
          alert('on the way!!!!')
        })
      } else {
        this.setState({
          exam_name: '',
          current_exam_inx: '',
          exam_id: '',
          formIsHalfFilledOut: true
        })
      }
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value.toUpperCase(),
        formIsHalfFilledOut: true
      });
    }
  }
  filterExamsHandler() {
    const _fltr_school = this.props.filteredSchoolData.slct_school_id;
    const _slct_ct_name = this.state.exam_name;
    const _sdul_note = this.props.examSdulNotes.filter((item) => {
      if (item.school_id === _fltr_school && item.exam_name === _slct_ct_name) {
        return item;
      }
    })
    this.setState({
      display_notes_arr: _sdul_note
    })


  }
  filterExamsCategoriesHandler() {
    const _fltr_school = this.props.filteredSchoolData.slct_school_id;
    const _exams_cate = this.props.examsCategory.filter((item) => {
      if (item.school_id === _fltr_school) {
        return item;
      }
    })

    const _sdul_note = this.props.examSdulNotes.filter((item) => {
      if (item.school_id === _fltr_school) {
        return item;
      }
    })

    this.setState({
      selected_exams: _exams_cate,
      display_notes_arr: _sdul_note
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.examSdulNotes)) {
      this.props.getExamSdulNotes();
    }
    if (isEmptyObj(this.props.examsCategory)) {
      this.props.getExamsCategory();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_examSdulNotes = this.props.examSdulNotes;
      const _examsCategory = this.props.examsCategory;
      if (_all_examSdulNotes && _filter && _examsCategory) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    // const _filter = this.props.filteredSchoolData;
    // const _all_examSdulNotes = this.props.examSdulNotes;
    // if (!isEmpty(_all_examSdulNotes)) {
    //   const _school_examSdulNotes = _all_examSdulNotes.filter((item) => {
    //     if (_filter.slct_school_id) {
    //       if (item.school_id === _filter.slct_school_id) {
    //         return item
    //       }
    //     } else {
    //       return item
    //     }
    //   })
    //   this.setState({
    //     display_examSdulNotes: _school_examSdulNotes,
    //   }, () => this.filterByClsHandler())
    // }
    this.setState({
      exam_name: '',
      current_exam_inx: '',
      exam_id: '',
    }, () => {
      this.filterExamsCategoriesHandler()
    })
  }

  // filterByClsHandler = () => {
  //   const _fltr_school = this.props.filteredSchoolData;
  //   const _fltr_class = this.props.filteredClassesData;
  //   const _all_examSdulNotes = this.props.examSdulNotes;
  //   if (_all_examSdulNotes) {
  //     const _school_examSdulNotes = _all_examSdulNotes.filter((item) => {
  //       if (!isEmpty(_fltr_class.slct_cls_name)) {
  //         if (item.school_id === _fltr_school.slct_school_id &&
  //           item.stu_class === _fltr_class.slct_cls_name) {
  //           return item
  //         }
  //       } else {
  //         if (item.school_id === _fltr_school.slct_school_id) {
  //           return item
  //         }
  //       }
  //     })
  //     this.setState({
  //       display_examSdulNotes: _school_examSdulNotes
  //     })
  //   }
  // }


  componentWillReceiveProps(nextProps) {
    if (nextProps.examSdulNotes) {
      this.setState({
        display_notes_arr: []
      }, () => {
        this.filterExamsCategoriesHandler();
      })
    }
  }

  // checkAuthentication(obj) {
  //    loadProgressBar();
  //    axios.post(VALIDATE_URL, obj)
  //       .then(res => {
  //          const getRes = res.data;
  //          // sessionStorage.setItem("user", getRes.data);
  //          console.log(getRes);
  //          if (getRes.data) {
  //             this.setState({
  //                user: getRes.data,
  //                group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //                school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //                user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //                session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //             }, () => {
  //                this.getSchoolHandler();
  //                this.getExamsCategories();
  //                this.getSheduleNotesHandler();
  //             })
  //          }
  //       }).catch((error) => {
  //          this.props.history.push('/login.jsp');
  //       })
  // }

  // getExamsCategories() {
  //    loadProgressBar();
  //    axios.get(READ_EXAM_CATE)
  //       .then(res => {
  //          const getRes = res.data;
  //          this.setState({
  //             exams: getRes,
  //             errorMessages: getRes.message
  //          })
  //          // console.log(this.state);
  //       }).catch((error) => {
  //          // error
  //       })
  // }

  // getSchoolHandler() {
  //    loadProgressBar();
  //    const obj = {
  //       group_id: this.state.group_id
  //    }
  //    axios.post(READ_SCHOOLS, obj)
  //       .then(res => {
  //          const getRes = res.data;
  //          this.setState({
  //             schools: getRes,
  //             errorMessages: getRes.message
  //          });
  //          // console.log(this.state);
  //       }).catch((error) => {
  //          // error
  //       })
  // }
  // getSheduleNotesHandler() {
  //    loadProgressBar();
  //    const obj = {
  //       group_id: this.state.group_id,
  //       school_id: this.state.school_id,
  //       user_category: this.state.user_category,
  //       session_year_id: this.state.session_year_id
  //    }
  //    console.log(JSON.stringify(obj));

  //    axios.post(READ_SHEDULES_NOTE, obj)
  //       .then(res => {
  //          const getRes = res.data;
  //          this.setState({
  //             shedule_notes_arr: getRes,
  //             display_notes_arr: getRes,
  //             errorMessages: getRes.message
  //          });
  //          // console.log(this.state);
  //       }).catch((error) => {
  //          // error
  //       })
  // }
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteExamSdulNotes({ id: id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   // debugger;
  //   axios.post(DELETE_SHEDULES_NOTE + '?id=' + id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _galleries = this.state.display_notes_arr.filter((item, index) => {
  //         return item.id !== id
  //       })
  //       this.setState({
  //         display_notes_arr: _galleries
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }

  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateExamSdulNotes(obj);
  }

  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }

  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.examSdulNotes.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    const _schools_sduls = this.props.examSdulNotes.filter((item) => {
      if (item.school_id === this.state.school_id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0],
      display_notes_arr: _schools_sduls
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }


  render() {
    const { selected_item, display_notes_arr,
      selected_exams, editItem, current_exam_inx, formIsHalfFilledOut } = this.state;
    const { user, schools, examSdulNotes, examsCategory } = this.props;
    //  console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Notes</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">All Notes</div>
          {user && schools && examSdulNotes && examsCategory &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div> */}
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  // showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                // filterByClsHandler={this.filterByClsHandler}
                />

                <div className="form-group mt-1 d-none">
                  <label className="mr-2">Exam:</label>
                  <select
                    value={current_exam_inx}
                    disabled={true}
                    className="form-control form-control-sm" name="current_exam"
                    onChange={event => this.changeHandler(event, 'current_exam')} >
                    <option value="">Select...</option>
                    {selected_exams.map((option, index) => {
                      return (<option key={index} value={index}>{option.cat_name}</option>)
                    })}
                  </select>
                </div>
              </div>
            </div>
          }
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {editItem ?
              <>
                <EditSheduleNotes
                  selected_item={selected_item}
                  schools={schools}
                  SchoolExamSdulNotes={display_notes_arr}
                  user={user}
                  updateHandlar={this.updateHandlar}
                  openEdit={this.openEdit}
                  closeEdit={this.closeEdit}
                />
                <div className="backdrop edit-mode"></div>
              </>
              : null}
            <div className="table-scrollable">
              <table className="table table-striped table-bordered table-hover table-sm">
                <thead>
                  <tr className="text-center">
                    <th />
                    <th> School Name </th>
                    <th> Medium</th>
                    <th> Session Year </th>
                    <th> Exam Name </th>
                    <th> Notes </th>
                    <th> Action </th>
                  </tr>
                </thead>
                {examSdulNotes &&
                  <tbody>
                    {display_notes_arr.map((item, index) => {
                      return (
                        <tr key={index} >
                          <td>{index + 1}</td>
                          <td>{item.school_name}</td>
                          <td>{item.medium}</td>
                          <td>{item.ses_year}</td>
                          <td>{/*item.exam_name*/}</td>
                          <td><span className="d-flex">
                            <i className="fas fa-check mt-1 mr-2"></i>
                            {item.notes}</span>
                          </td>
                          <td className="d-flex">
                            {/* <NavLink to={`edit_shedule_notes.jsp/${item.id}`} 
                            className="btn btn-primary btn-sm mr-1">
                              Edit</NavLink> */}
                            <button className="btn btn-primary btn-sm mr-1"
                              type="button"
                              onClick={event => this.openEdit(event, item.id)}>Edit</button>
                            <button className="btn btn-danger btn-sm"
                              value={item.id}
                              onClick={event => this.confirmBoxDelete(event, item.id)}>Del</button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                }
              </table>
            </div>
          </div>
          <div className="card-footer">
            <NavLink to="/add_shedule_notes.jsp"
              className="btn btn-primary btn-sm">Add New
                  </NavLink>
          </div>
        </div>
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: examsCategory } = state.examsCategory;
  const { item: examSdulNotes } = state.examSdulNotes;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, examSdulNotes, examsCategory,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
  updateExamSdulNotes: examSdulNotesAction.update,
  deleteExamSdulNotes: examSdulNotesAction.delete,
  getExamsCategory: examsCategoryAction.getExamsCategory,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllGalleries));
