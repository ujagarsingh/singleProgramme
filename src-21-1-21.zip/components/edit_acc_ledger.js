import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";

class EditAccLedger extends Component {
   state = ({
      id: "",
      ledger_name: "",
      selected_item: "",
      formIsHalfFilledOut: false,
   })
   changeHandler = (event, fieldName, isCheckbox) => {
      var someProperty = { ...this.state.selected_item }
      someProperty[fieldName] = isCheckbox ? event.target.checked : event.target.value;

      this.setState({
         selected_item: someProperty,
         formIsHalfFilledOut: true
      })

   };
   componentDidMount() {
      this.setState({
         selected_item: this.props.selected_item
      })
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

   submitHandler = e => {
      loadProgressBar();

      //e.preventDefault();
      let default_obj = '';
      if (this.props.user.user_category === "1") {
         default_obj = { school_id: this.refs.school.value }
      }
      const form_obj = {
         id: this.state.selected_item.id,// this.state.id,
         ledger_name: this.state.selected_item.ledger_name, // this.state.title,
         acc_group_id: this.state.selected_item.acc_group_id, // this.state.title,
         crnt_balance: this.state.selected_item.crnt_balance, // this.state.title,
         crnt_balance_type: this.state.selected_item.crnt_balance_type, // this.state.title,
         op_balance: this.state.selected_item.op_balance, // this.state.title,
         op_balance_type: this.state.selected_item.op_balance_type, // this.state.title,
         school_id: this.state.selected_item.school_id, // this.state.title,
      }
      const obj = { ...form_obj, ...default_obj }
      // console.log(JSON.stringify(obj));

      this.props.updateHandlar(obj);
   }
   render() {
      const { formIsHalfFilledOut, selected_item } = this.state;
      const { schools, user, accGroup } = this.props;
      // console.log(this.props);
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Ledger Name</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  Edit Ledger Name
               </div>
               <div className="card-body">
                  {selected_item && schools && user &&
                     <div className="row" key={selected_item.id}>
                        {(user.user_category === "1") &&
                           <div className="col-sm-2">
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    value={selected_item.school_id}
                                    onChange={event => this.changeHandler(event, 'school')}
                                 >
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        }
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">Ledger Name
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" placeholder="Ledger Name"
                                    className="form-control form-control-sm"
                                    required
                                    onChange={event => this.changeHandler(event, 'ledger_name')}
                                    value={selected_item.ledger_name}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Under </label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    value={selected_item.acc_group_id}
                                    onChange={event => this.changeHandler(event, 'acc_group_id')}
                                 >
                                    <option value="">Select ...</option>
                                    {accGroup.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.group_name}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Opening Balance</label>
                              <div className="form-input">
                                 <input type="number" ref="op_balance" placeholder="Opening Balance"
                                    className="form-control form-control-sm"
                                    value={selected_item.op_balance}
                                    onChange={event => this.changeHandler(event, 'op_balance')} />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">
                           <div className="form-group">
                              <label className="control-label">Balance Type</label>
                              <div className="form-input">
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='op_balance_type'
                                    defaultValue={selected_item.op_balance_type}
                                    onChange={event => this.changeHandler(event, 'op_balance_type')}>
                                    <option value="">Select...</option>
                                    <option value="CR">CR</option>
                                    <option value="DR">DR</option>
                                 </select>
                              </div>
                           </div>
                        </div>

                     </div>
                  }
               </div>
               <div className="card-footer d-flex">
                  <span className="text-danger p-2">CR : Liability, DR : Assets</span>
                  <button type="submit" className="btn btn-primary mr-2 ml-auto">Submit</button>
                  {/* <NavLink to="/all_galleries.jsp" className="btn btn-danger">Cancel</NavLink> */}
                  <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                     Exit </button>
               </div>
            </form>
         </div>
      )
   }
}

export default withRouter(EditAccLedger);