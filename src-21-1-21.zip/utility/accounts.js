

export {
  focusFirstHandler,
  srollListItemHandler,
  getSumOfBalanceHandler,
  filterDataHandler,
  effectedLedgerHandler,
  wrongSpellingONHandler,
  wrongSpellingOFFHandler
};

function focusFirstHandler() {
  const allinput = Array.prototype.slice.call(document.querySelector('.sfpage-body').querySelectorAll("textarea, input, select, button"));
  if (allinput.length > 1) {
    (allinput[1]).focus();
    (allinput[1]).select();
  }
}

function srollListItemHandler(key) {
  debugger;
  const _div = document.querySelector('#ldrList');
  const _elem = _div.querySelector('.active');
  const _elh = _elem.clientHeight;
  const _dlh = _div.clientHeight + 80;

  let rect = _elem.getBoundingClientRect();
  let elementTop; //x and y
  var scrollTop = document.documentElement.scrollTop ?
    document.documentElement.scrollTop : document.body.scrollTop;
  elementTop = rect.top + scrollTop;
  // console.log(elementTop)

  if ((key === "up" || key === "left") && elementTop < 110) {
    _div.scrollBy(0, -_elh);
  } else if ((key === "down" || key === "right") && elementTop > _dlh) {
    _div.scrollBy(0, _elh);
  }
}

function getSumOfBalanceHandler(state_voucher) {
  //debugger
  let sv = state_voucher;// JSON.parse(JSON.stringify(this.state.voucher));
  let total_cr = 0;
  let total_dr = 0;
  sv.child.forEach(elem => {
    if ((elem.tr_type).toUpperCase() === "CR") {
      total_cr += Number(elem.tr_amount);
    } else {
      total_dr += Number(elem.tr_amount);
    }
  });
  return { total_cr: total_cr, total_dr: total_dr };
}

function filterDataHandler(ldr_list, value) {
  debugger

  let val_txt = value.toUpperCase();
  let filter_data = ldr_list.filter((elem) => {
    const _elem = elem.ledger_name.toUpperCase();
    if (!_elem.includes(val_txt)) {
      return false
    }
    return elem
  })
  // console.log(filter_data);
  if (filter_data.length === 0) {
    alert('Wrong Spelling!!!');
    val_txt = '';
    // filter_data = [{'ledger_name' :"Ledgers Missmatched!"}]
    // wrongSpellingONHandler();
  }
  const obj = { filter_data, val_txt }
  return obj
}

function effectedLedgerHandler(vchr_type, all_ledgers) {
  // debugger
  let ldr_debit = [];
  let ldr_credit = [];

  switch (vchr_type) {
    case "Payment":
      // code
      ldr_credit = [11];
      ldr_debit = [12];
      break;
    case "Receipt":
      // code
      ldr_credit = [12];
      ldr_debit = [10];
      break;
    default:
      // code
      ldr_credit = [1, 2];
      ldr_debit = [10];
  }
  // const { all_ledgers } = this.props.accountManager;
  let efctd_cr_ldr = [];
  let efctd_dr_ldr = [];

  ldr_credit.forEach(el => {
    efctd_cr_ldr = [...efctd_cr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
  })

  ldr_debit.forEach(el => {
    efctd_dr_ldr = [...efctd_dr_ldr, ...all_ledgers.filter(e => Number(e.under_group) === el)]
  });
  const obj = {
    credit_ledgers: efctd_cr_ldr,
    debit_ledgers: efctd_dr_ldr,
    all_ledgers: all_ledgers
  };
  return obj;
}

function wrongSpellingONHandler() {
  const _wrongBox = document.querySelector('#wrongSpelling')
  _wrongBox.classList.add('show');
  // _wrongBox.querySelector('button').focus();
}
function wrongSpellingOFFHandler() {
  document.querySelector('#wrongSpelling').classList.remove('show');
}