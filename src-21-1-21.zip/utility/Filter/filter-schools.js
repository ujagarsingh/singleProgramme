import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { schoolsAction, classesAction, filterSchoolsActions } from '../../_actions';
import { isEmptyObj, isEmpty } from '../../utility/utilities';

/*
<CommonFilters
  showSchoolFilter={true}
  showMediumFilter={false}
  showClassFilter={true}
  filterBySchoolHandler={this.filterBySchoolHandler}
  filterByClsHandler={this.filterByClsHandler}
/>*/

class CommonFilters extends Component {
  state = {
    slct_school_index: '',
    slct_cls_index: '',
    school_classes: []
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const obj = {
        schools: this.props.schools,
        classes: this.props.classes,
        index: _inx,
      }

      this.props.filterSchools(obj);

    } else if (fieldName === 'selected_class') {
      const _inx = event.target.value;
      const obj = {
        index: _inx,
        classes: this.props.filteredSchoolData.school_classes,
      }
      this.props.filterClasses(obj);
    } else if (fieldName === 'medium') {
      // const _medium = event.target.value;
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    }
  };

  mediumHandler(_medium) {
    const _classes = this.props.selected_classes.filter((item, inx) => {
      if (item.medium === _medium) {
        return item
      }
    })
    this.setState({
      selected_classes: _classes,
      selected_class_inx: ''
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }

    const _user = this.props.user;
    if (_user.user_category === "2" || _user.user_category === "3") {
      this.checkFlag();
    }
  }

  checkFlag() {
    setTimeout(() => {
      const schools = this.props.schools;
      const classes = this.props.classes;
      if (classes && schools) {
        this.setDefaultValues();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  setDefaultValues() {
    const obj = {
      schools: this.props.schools,
      classes: this.props.classes,
      index: "0" // _inx,
    }
    const _fltr_school = this.props.filteredSchoolData.slct_school_id;
    const _fltr_class = this.props.filteredClassesData.slct_cls_id;

    if (!isEmpty(_fltr_class) && this.props.showClassFilter) {
      this.props.filterByClsHandler();
    } else if (!isEmpty(_fltr_school)) {
      this.props.filterBySchoolHandler();
    } else {
      this.props.filterSchools(obj);
    }
  }

  componentWillReceiveProps(nextProps) {

    if ((nextProps.filteredSchoolData.slct_school_index !== this.state.slct_school_index)
      && this.props.showSchoolFilter) {
      this.props.filterBySchoolHandler();
      this.setState({
        slct_school_index: nextProps.filteredSchoolData.slct_school_index
      }, () => {
        if (this.props.user.user_category === "1") {
          const obj = {
            index: '',
            classes: this.props.filteredSchoolData.school_classes,
          }
          this.props.filterClasses(obj);
        }
      })
    }
    if ((nextProps.filteredClassesData.slct_cls_index !== this.state.slct_cls_index)
      && this.props.showClassFilter) {
      this.props.filterByClsHandler();
      this.setState({
        slct_cls_index: nextProps.filteredClassesData.slct_cls_index
      })
    }
  }

  render() {
    const { user, classes, schools,
      filteredSchoolData,
      filteredClassesData,
      showSchoolFilter,
      showMediumFilter,
      showClassFilter } = this.props;
    // console.log(this.props);
    return (
      <>
        {(user && classes && schools && filteredSchoolData && filteredClassesData) &&
          <>
            {/* {showSchoolFilter && */}
            {showSchoolFilter && (user.user_category === "1") &&
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Schools :</label>
                <select className="form-control form-control-sm"
                  required
                  ref='school'
                  value={filteredSchoolData.slct_school_index}
                  onChange={event => this.changeHandler(event, 'school')}>
                  <option value="">Select ...</option>
                  {schools.map((item, index) => {
                    return (
                      <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                    )
                  })}
                </select>
              </div>
            }
            {showMediumFilter &&
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Medium :</label>
                <select className="form-control form-control-sm"
                  required
                  ref='medium'
                  disabled={filteredSchoolData.school_mediums > 1 ? false : true}
                  value={filteredSchoolData.slct_medium}
                  onChange={event => this.changeHandler(event, 'medium')}>
                  <option value="">Select ...</option>
                  {filteredSchoolData.school_mediums.map((item, index) => {
                    return (
                      <option key={index} value={item}>{item}</option>
                    )
                  })}
                </select>
              </div>
            }
            {showClassFilter &&
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-2">Class :</label>
                <select
                  ref='classinx'
                  value={filteredClassesData.slct_cls_index}
                  // disabled={filteredSchoolData.school_classes.length >= 1 ? false : true}
                  className="form-control form-control-sm" name="selected_class"
                  onChange={event => this.changeHandler(event, 'selected_class')} >
                  <option value="">Select ...</option>
                  {filteredSchoolData.school_classes.map((option, index) => {
                    return (<option key={index} value={index}>{option.class_name}</option>)
                  })}
                </select>
              </div>
            }
          </>
        }
      </>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, classes, schools, filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  filterSchools: filterSchoolsActions.filterSchools,
  filterClasses: filterSchoolsActions.filterClasses,
}

export default connect(mapStateToProps, actionCreators)(withRouter(CommonFilters));