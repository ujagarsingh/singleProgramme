import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { withRouter } from 'react-router';
import Menus from '../utility/menus';
import ImageLoader from "../utility/ImageLoader/index";

class DashboardSidebar extends Component {
  state = {
    user_name: '',
    user_category: '',
    user_id: '',
    user_img: '',
    menus: '',
    siderbar_height: ''
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  componentDidMount() {
    let _import_menu = JSON.parse(JSON.stringify(Menus.type));
    let _menus = {};
    const { user } = this.props;
    if (user) {
      let _user_category = user.user_category;
      if (_user_category === '1') {
        // Super Admin
        _menus = _import_menu[0]
      } else if (_user_category === '2') {
        // Admin
        _menus = _import_menu[1]
      } else if (_user_category === '3') {
        // Staff
        _menus = _import_menu[2]
      } else if (_user_category === '4') {
        // Staff
        _menus = _import_menu[3]
      } else {
        _menus = _import_menu[4]
      }
    }
    this.setState({
      menus: _menus,
      user: user
    })
    setTimeout(() => {
      this.sidebarFunction();

      setTimeout(() => {
        var win_width = window.outerWidth;
        var win_height = window.outerHeight;
        var sidebar_elm = document.getElementsByClassName("navbar-fixed-top");
        if (win_width <= 768) {
          this.setState({
            siderbar_height: win_height - sidebar_elm[0].clientHeight
          })
        }
      }, 100);
    }, 100);
  }

  sidebarFunction() {
    var toggler = document.getElementsByClassName("nav-toggle");
    var sidebar_btn_t = document.getElementsByClassName("sidebar-toggler");
    var sidebar_btn_c = document.getElementsByClassName("sidebar-closer");
    var filter_btn_t = document.getElementsByClassName("filter-toggler");
    var filter_btn_c = document.getElementsByClassName("filter-closer");
    for (let i = 0; i < toggler.length; i++) {
      toggler[i].addEventListener("click", function (event) {
        event.preventDefault();
        if (this.classList.contains('active')) {
          if (this.classList.contains('nav-toggle')) {
            this.classList.remove('active');
            this.nextElementSibling.classList.remove('active');
            this.parentElement.classList.remove('active');
            var _activeLinks = Array.prototype.slice.call(this.nextElementSibling.getElementsByClassName("active"));
            _activeLinks.forEach(function (item, index) {
              item.classList.remove('active');
            })
          }
          var _arrow = Array.prototype.slice.call(this.getElementsByClassName('arrow'));
          if (_arrow.length > 0) {
            _arrow.forEach(function (item, index) {
              item.classList.remove('open');
            })
          }
        } else {
          var _activeSibling = Array.prototype.slice.call(this.parentElement.parentElement.getElementsByClassName("active"));
          if (_activeSibling.length > 0) {
            _activeSibling.forEach(function (item, index) {
              item.classList.remove('active');
            });
          }
          /*
                    var _activePreSibling = Array.prototype.slice.call(this.parentElement.parentElement.parentElement.getElementsByClassName("active"));
                    if (_activePreSibling.length > 0) {
                      _activePreSibling.forEach(function (item, index) {
                        item.classList.remove('active');
                      });
                    }*/
          if (this.classList.contains('nav-toggle')) {
            this.classList.add('active');
            this.nextElementSibling.classList.add('active');
            this.parentElement.classList.add('active');

            var _arrow1 = Array.prototype.slice.call(this.getElementsByClassName('arrow'));
            if (_arrow1.length > 0) {
              _arrow1.forEach(function (item, index) {
                item.classList.add('open');
              })
            }
          }
        }
      });
    }
    if (!this.isEmpty(sidebar_btn_t) && !this.isEmpty(sidebar_btn_c)) {
      sidebar_btn_c[0].addEventListener("click", function (event) {
        event.preventDefault();
        sidebar_btn_t[1].click();
      });
    }
    if (!this.isEmpty(filter_btn_c) && !this.isEmpty(filter_btn_t)) {
      filter_btn_c[0].addEventListener("click", function (event) {
        event.preventDefault();
        filter_btn_t[0].click();
      });
    }
  }
  render() {
    // const { user } = this.props;
    const { user_img, user, menus, siderbar_height } = this.state;
    //console.log(this.state);
    return (
      <div className="sidebar-container">
        <span className="sidebar-closer">
          <button type="button" className="btn btn-danger sidebar-toggler-c">
            <i className="fa fa-times"></i>
          </button>
        </span>
        {user &&
          <div className="sidemenu-container" style={{ "height": siderbar_height }}>
            <div className="left-sidemenu">
              {menus !== '' ?
                <ul className="sidemenu">
                  <li className="sidebar-user-panel">
                    <div className="user-panel d-flex">
                      <div className="pull-left image">
                        <ImageLoader
                          src={`${process.env.PUBLIC_URL}` + user_img}
                          alt={user.user_name}
                          className="img-circle user-img-circle"
                          fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/dp.jpg`}
                        />
                      </div>
                      <div className="pull-left info">
                        <p>{user.user_name}</p>
                        <NavLink to="#" exact><i className="fa fa-circle user-online" /><span className="txtOnline">
                          {menus.name}</span></NavLink>
                      </div>
                    </div>
                  </li>
                  {menus.children.map((item_1, inx) => {
                    return (
                      <li key={inx} className="nav-item">
                        <NavLink to={item_1.param ? (item_1.link + `/` + user.id) : (item_1.link)}
                          className={item_1.children.length > 0 ? 'nav-link nav-toggle' : 'nav-link nav-page'} exact>
                          <i className={item_1.icon}></i>
                          <span className="title">{item_1.name}</span>
                          {item_1.children.length > 0 ? (
                            <span className="arrow" />
                          ) : null}
                        </NavLink>
                        {item_1.children.length > 0 ? (
                          <ul className="sub-menu">
                            {item_1.children.map((item_2, idx) => {
                              return (<li key={idx} className="nav-item">
                                <NavLink to={item_2.link}
                                  className={item_2.children.length > 0 ? 'nav-link nav-toggle' : 'nav-link nav-page'} exact>
                                  <i className={item_2.icon}></i>
                                  <span className="title">{item_2.name}</span>
                                  {item_2.children.length > 0 ? (
                                    <span className="arrow" />
                                  ) : null}
                                </NavLink>
                                {item_2.children.length > 0 ? (
                                  <ul className="sub-menu">
                                    {item_2.children.map((item_3, iex) => {
                                      return (
                                        <li key={iex} className="nav-item">
                                          <NavLink to={item_3.link}
                                            className={item_3.children.length > 0 ? 'nav-link nav-toggle' : 'nav-link nav-page'} exact>
                                            <i className={item_3.icon}></i>
                                            <span className="title">{item_3.name}</span>
                                            {item_3.children.length > 0 ? (
                                              <span className="arrow" />
                                            ) : null}
                                          </NavLink>
                                          {item_3.children.length > 0 ? (
                                            <ul className="sub-menu">
                                              {item_3.children.map((item_4, iex) => {
                                                return (
                                                  <li key={iex} className="nav-item">
                                                    <NavLink to={item_4.link}
                                                      className={item_4.children.length > 0 ? 'nav-link nav-toggle' : 'nav-link nav-page'} exact>
                                                      <i className={item_4.icon}></i>
                                                      <span className="title">{item_4.name}</span>
                                                      {item_4.children.length > 0 ? (
                                                        <span className="arrow" />
                                                      ) : null}
                                                    </NavLink>
                                                  </li>
                                                )
                                              })}
                                            </ul>
                                          )
                                            : null}
                                        </li>
                                      )
                                    })}
                                  </ul>
                                )
                                  : null}
                              </li>)
                            })}
                          </ul>
                        )
                          : null}
                      </li>
                    )
                  })}
                </ul>
                : null}
            </div>
          </div>
        }
      </div>
    )
  }
}

export default withRouter(DashboardSidebar);