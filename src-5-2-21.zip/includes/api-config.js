let backendHost = 'www.golihoja.com';
let folderPath = 'www.golihoja.com/public';
//let backendHost = '%PUBLIC_URL%';
//let folderPath = '%PUBLIC_URL%//public';

/*const hostname = window && window.location && window.location.hostname;

if (hostname === 'www.golihoja.com') {
  backendHost = 'www.golihoja.com';
  folderPath = 'www.golihoja.com/public';
} else {
  backendHost = process.env.REACT_APP_BACKEND_HOST || '%PUBLIC_URL%';
  folderPath = '%PUBLIC_URL%//public';
}
*/
export const HOST_URL = { backendHost, folderPath };