import React, { Component } from 'react';
import { withRouter } from 'react-router';

class Voucher extends Component {
    state = {
        voucher_obj: [],
        _all_dr: [],
        _all_cr: [],
        _total_dr: 0,
        _total_cr: 0,
    }
    componentDidMount() {
        // this.setState({
        //     voucher_obj: this.props.vchr_obj
        // }, () => {
        //     this.showVoucherEntries();
        // });
    }
    showVoucherEntries(voucher_detail) {
        let _all_dr = [];
        let _all_cr = [];
        let _total_dr = 0;
        let _total_cr = 0;

        voucher_detail.map((vItem) => {
            if (vItem.tr_type === 'DR') {
                _all_dr = [..._all_dr, vItem];
                _total_dr += Number(vItem.tr_amount);
            } else {
                _all_cr = [..._all_cr, vItem];
                _total_cr += Number(vItem.tr_amount);
            }
        });

        let vchr_table = <table className="table table-sm table-light table-voucher m-0">
            <thead>
                <tr className="table-danger">
                    <th></th>
                    <th className="text-center">Debit</th>
                    <th className="text-center">Credit</th>
                </tr>
            </thead>
            <tfoot className="bg-light">
                <tr>
                    <th className="text-right">TOTAL</th>
                    <th className="text-right">{_total_dr}/-</th>
                    <th className="text-right">{_total_cr}/-</th>
                </tr>
            </tfoot>
            <tbody>
                {_all_dr.map((dr_item, dr_inx) => {
                    return (
                        <tr key={dr_inx}>
                            <td>
                                <span className="ml-0"> {dr_item.ledger_folio} <b>Ujagar Singh s/o Shri Birdi Chand Meena </b> [ Class : 10nth ] DR </span>
                            </td>
                            <td className="text-right">{dr_item.tr_amount}/-</td>
                            <td className="text-right"></td>
                        </tr>
                    )
                })}
                {_all_cr.map((cr_item, cr_inx) => {
                    return (
                        <tr key={cr_inx}>
                            <td>
                                <span className="ml-4"><i>To,</i> {cr_item.ledger_folio}</span>
                            </td>
                            <td className="text-right"></td>
                            <td className="text-right">{cr_item.tr_amount}/-</td>
                        </tr>
                    )
                })}
                <tr>
                    <td>
                        <div className="">
                            <p className="m-0"><b>Naretion : </b> <br /> this is the area of Naretion..</p>
                        </div>
                    </td>
                    <td className="text-right"></td>
                    <td className="text-right"></td>
                </tr>

            </tbody>
        </table>;

        return vchr_table;
    }
    render() {
        const { voucher_detail } = this.props;
        return (

            <div className="voucher-detail">
                {voucher_detail &&
                    this.showVoucherEntries(voucher_detail)
                }
            </div>

        )
    }
}
export default withRouter(Voucher);