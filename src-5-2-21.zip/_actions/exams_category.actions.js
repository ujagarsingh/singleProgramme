import { examsCategoryConstants } from '../_constants';
import { examsCategoryService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const examsCategoryAction = {
    getExamsCategory
};

function getExamsCategory() { 
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        examsCategoryService.getExamsCategory()
            .then(
                response => {
                    dispatch(success(response.data.exam_category_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: examsCategoryConstants.EXAMS_CATEGORY_REQUEST } }
    function success(response) { return { type: examsCategoryConstants.EXAMS_CATEGORY_SUCCESS, response } }
    function failure(error) { return { type: examsCategoryConstants.EXAMS_CATEGORY_FAILURE, error } }
}
