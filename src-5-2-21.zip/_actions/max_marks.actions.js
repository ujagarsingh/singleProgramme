import { maxMarksConstants } from '../_constants';
import { maxMarksService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const maxMarksAction = {
    getMaxMarks
};

function getMaxMarks() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        maxMarksService.getMaxMarks()
            .then(
                response => {
                    dispatch(success(response.data.max_marks_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: maxMarksConstants.MAX_MARKS_REQUEST } }
    function success(response) { return { type: maxMarksConstants.MAX_MARKS_SUCCESS, response } }
    function failure(error) { return { type: maxMarksConstants.MAX_MARKS_FAILURE, error } }
}
