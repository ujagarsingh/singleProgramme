import { feeStructureConstants } from '../_constants';
import { feeStructureService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const feeStructureAction = {
    getFeeStructure,
    create,
    update,
    delete : _delete
};

function getFeeStructure() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeStructureService.getFeeStructure()
            .then(
                response => {
                    dispatch(success(response.data.fee_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeStructureConstants.FEE_STRUCTURE_REQUEST } }
    function success(response) { return { type: feeStructureConstants.FEE_STRUCTURE_SUCCESS, response } }
    function failure(error) { return { type: feeStructureConstants.FEE_STRUCTURE_FAILURE, error } }
}



function create(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeStructureService.create(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item), toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeStructureConstants.CREATE_REQUEST } }
    function success(response) { return { type: feeStructureConstants.CREATE_SUCCESS, response } }
    function failure(error) { return { type: feeStructureConstants.CREATE_FAILURE, error } }
}



function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeStructureService.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item), toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeStructureConstants.UPDATE_REQUEST } }
    function success(response) { return { type: feeStructureConstants.UPDATE_SUCCESS, response } }
    function failure(error) { return { type: feeStructureConstants.UPDATE_FAILURE, error } }
}



function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        feeStructureService.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.id), 
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: feeStructureConstants.DELETE_REQUEST } }
    function success(response) { return { type: feeStructureConstants.DELETE_SUCCESS, response } }
    function failure(error) { return { type: feeStructureConstants.DELETE_FAILURE, error } }
}

