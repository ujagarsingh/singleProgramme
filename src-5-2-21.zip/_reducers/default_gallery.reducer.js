import { defaultGalleryConstants } from '../_constants';

export function defaultGallery(state = {}, action) {
  switch (action.type) {
    case defaultGalleryConstants.GALLERY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultGalleryConstants.GALLERY_SUCCESS:
      return {
        item: action.response
      };
    case defaultGalleryConstants.GALLERY_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}