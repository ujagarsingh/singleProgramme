import { subjectsConstants } from '../_constants';

export function subjects(state = {}, action) {
  switch (action.type) {
    case subjectsConstants.SUBJECTS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case subjectsConstants.SUBJECTS_SUCCESS:
      return {
        item: action.response
      };
    case subjectsConstants.SUBJECTS_FAILURE:
      return {
        error: action.error
      };


    case subjectsConstants.CREATE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case subjectsConstants.CREATE_SUCCESS:
      const new_arr = [...action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case subjectsConstants.CREATE_FAILURE:
      return {
        ...state,
        error: action.error
      };



    case subjectsConstants.DELETE_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case subjectsConstants.DELETE_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case subjectsConstants.DELETE_FAILURE:
      return {
        ...state,
        error: action.error
      };




    default:
      return state
  }
}