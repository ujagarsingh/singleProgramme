import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
//import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { professionalAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_URL = `http://schools.rajpsp.com/api/professional/read.php`;
const CREATE_USER = `http://schools.rajpsp.com/api/users/create.php`; 
const USER_CATEGORY = `http://schools.rajpsp.com/api/users/read_category.php`;

class AddUser extends Component {
   state = {
      professionals: [],
      user_name: '',
      user_id: '',
      login_id: '',
      medium: '',
      user_category: '', // check whick category of admin 'supper or admin' user in medie selection
      current_user_category: 3,
      is_active: false,
      users_cat_arr: [],
      formIsHalfFilledOut: false,
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })
      if (fieldName === 'is_active') {
         this.setState({
            is_active: !this.state.is_active
         })
      }
      if (fieldName === 'user_id') {
         let _user_name = null;
         let _user_mobile = null;
         let _user_id = event.target.value;
         this.state.professionals.filter((item) => {
            if (_user_id === item.id) {
               _user_name = item.emp_name;
               _user_mobile = item.emp_mob;
            }
         })
         this.setState({
            user_name: _user_name,
            login_id: _user_mobile
         })
      }
   };

   componentDidMount() {
      if (isEmptyObj(this.props.professional)) {
        this.props.getProfessional();
      }
   }

   checkAuthentication(obj) {
      loadProgressBar();
      axios.post(VALIDATE_URL, obj)
         .then(res => {
            const getRes = res.data;
            // sessionStorage.setItem("user", getRes.data);
            console.log(getRes);
            if (getRes.data) {
               this.setState({
                  user: getRes.data,
                  group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
                  school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
                  user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
                  session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
               }, () => {
                  this.getEmployeeHandler();
                  this.getUsersCategoryHandler();
               })
            }
         }).catch((error) => {
            this.props.history.push('/login.jsp');
         })
   }

   getUsersCategoryHandler() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id
      }
      axios.post(USER_CATEGORY, obj)
         .then(res => {
            const getRes = res.data;
            this.setState({
               users_cat_arr: getRes
            });
            if (getRes.message !== undefined) {
               Alert.error(getRes.message, {
                  position: 'bottom-right',
                  effect: 'jelly',
                  timeout: 5000, offset: 40
               });
            }
            //console.log(this.state.users_arr);
         }).catch((error) => {
            // error
         })

   };
   getEmployeeHandler() {
      loadProgressBar();
      const obj = {
         group_id: this.state.group_id,
         school_id: this.state.school_id,
         user_category: this.state.user_category,
         session_year_id: this.state.session_year_id
      }
      axios.post(READ_URL, obj)
         .then(res => {
            const professionals = res.data;
            this.setState({
               professionals: professionals,
               errorMessages: professionals.message
            });
            //console.log(this.state.professionals);
         }).catch((error) => {
            // error
         })
   }
   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Submit this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler(event);
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };
   submitHandler = e => {
      e.preventDefault();
      loadProgressBar();
      const obj = {
         is_active: this.state.is_active,
         user_name: this.state.user_name,
         current_user_category: this.state.current_user_category,
         user_id: this.state.user_id,
         login_id: this.state.login_id,
         medium: this.state.medium,
      }
      //console.log(JSON.stringify(obj));
      axios.post(CREATE_USER, obj)
         .then(res => {
            const getRes = res.data;
            //console.log(getRes)
            if (getRes.message !== undefined) {
               Alert.success(getRes.message, {
                  position: 'bottom-right',
                  effect: 'jelly',
                  timeout: 5000, offset: 40
               });
            }
            if (getRes.error !== undefined) {
               Alert.error(getRes.error, {
                  position: 'bottom-right',
                  effect: 'jelly',
                  timeout: 5000, offset: 40
               });
            }
            if (getRes.message !== undefined) {
               this.setState({
                  is_active: false,
                  user_name: '',
                  user_id: '',
               });
            }
         }).catch((error) => {
            //this.setState({ errorMessages: error });
         })

   };
   render() {
      const { formIsHalfFilledOut, user_id, user_name, professionals, current_user_category, user_category,
         users_cat_arr, login_id, medium, is_active } = this.state;
      console.log(this.state);
      return (
         <div className="page-content">
            <Helmet>
               <title>Add User</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

            <div className="page-bar d-flex">
               <div className="page-title">Add User</div>
            </div>
            <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-body">
                  <div className="form-horizontal">
                     <div className="form-body">
                        {professionals.length > 0 ?
                           <div className="form-group row mb-1">
                              <label className="control-label col-md-3">User Name
                          <span className="required"> * </span>
                              </label>
                              <div className="col-md-5">
                                 <span className="d-flex">
                                    <input
                                       required
                                       value={user_name}
                                       type="text" placeholder="User Name"
                                       className="form-control form-control-sm"
                                       onChange={event => this.changeHandler(event, 'user_name')}
                                    />
                                    <select
                                       value={user_id}
                                       className="form-control form-control-sm"
                                       onChange={event => this.changeHandler(event, 'user_id')}>
                                       <option >select...</option>
                                       {professionals.map((item, index) => {
                                          return (
                                             <option key={index} value={item.id}>
                                                {item.emp_name}
                                             &nbsp;&nbsp;&nbsp; S/o &nbsp;&nbsp;&nbsp;
                                                {item.emp_f_name}</option>
                                          )
                                       })}
                                    </select>
                                 </span>
                                 <small id="emailHelp" className="form-text text-muted">
                                    User Name for Show in Admin Panel.</small>
                              </div>
                           </div>
                           : null}
                        <div className="form-group row mb-1">
                           <label className="control-label col-md-3">User Category
                          <span className="required"> * </span>
                           </label>
                           <div className="col-md-5">
                              <select
                                 required
                                 value={current_user_category}
                                 className="form-control form-control-sm"
                                 onChange={event => this.changeHandler(event, 'current_user_category')}>
                                 <option >select...</option>
                                 {users_cat_arr.map((item, index) => {
                                    return (
                                       <option key={index} value={item.user_cate_id}>{item.user_cate_name}</option>
                                    )
                                 })}
                              </select>
                              <small id="emailHelp" className="form-text text-muted">
                                 Set Priority of any User this is reflect in Marksheet Column.</small>
                           </div>
                        </div>
                        <div className="form-group row mb-1">
                           <label className="control-label col-md-3">Login Id
                          <span className="required"> * </span>
                           </label>
                           <div className="col-md-5">
                              <input
                                 required
                                 value={login_id}
                                 type="number" placeholder="User Name"
                                 className="form-control form-control-sm"
                                 onChange={event => this.changeHandler(event, 'login_id')}
                              />
                              <small id="emailHelp" className="form-text text-muted">
                                 Only 10 Digit Mobile Number.</small>
                           </div>
                        </div>
                        {user_category === "1" ?
                           <div className="form-group row mb-1">
                              <label className="control-label col-md-3">Medium
                                          <span className="required"> * </span>
                              </label>
                              <div className="col-md-5">
                                 <select className="form-control form-control-sm"
                                    required
                                    value={medium}
                                    onChange={event => this.changeHandler(event, 'medium')}>
                                    <option >Select ...</option>
                                    <option value="English">English</option>
                                    <option value="Hindi" >Hindi</option>
                                 </select>
                                 <small id="emailHelp" className="form-text text-muted">
                                    User only work on selected Medium's School Data.</small>
                              </div>
                           </div>
                           : null}
                        <div className="form-group row mb-1">
                           <label className="control-label col-md-3 pt-0">Is Active
                                       </label>
                           <div className="col-md-5">
                              <div className="custom-control custom-checkbox">
                                 <input
                                    checked={is_active}
                                    onChange={event => this.changeHandler(event, 'is_active')}
                                    type="checkbox" className="custom-control-input" id="is_active" />
                                 <label className="custom-control-label" htmlFor="is_active">Yes</label>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-primary  mr-2">Add User</button>
                  <NavLink to="/all_users.jsp" className="btn btn-danger">Back</NavLink>
               </div>
            </form>
         </div>
      )
   }
}

function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: professional } = state.professional;
   return { user, professional };
 }
 
 const actionCreators = {
   getProfessional: professionalAction.getProfessional,
 }
 
 export default connect(mapStateToProps, actionCreators)(withRouter(AddUser));