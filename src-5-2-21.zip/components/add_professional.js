import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import DatePicker from 'react-date-picker';
import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import MyImage from '../utility/my_image';
import { connect } from 'react-redux';
import { classesAction} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`; 
const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;  
const CREATE_PROFESSIONAL = `http://schools.rajpsp.com/api/professional/create.php`;

class AddProfessional extends Component {
  state = {
    classes: [],
    prof_name: '',
    prof_father_name: '',
    dob: '',
    gender: '',
    address: '',
    mobile: '',
    email: '',
    edu_n_cirtificate: '',
    profile_image: '',
    doj: '',
    designation: '',
    class_teacher: '',
    selected_class_id: '',
    responsibility: '',
    formIsHalfFilledOut: false,
    imageData: "",
    crop: {
      unit: "%",
      width: 30,
      aspect: 1
    },
    final_size: {
      width: 400,
      height: 400
    }
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
  }

  checkAuthentication(obj) {
    loadProgressBar();
    axios.post(VALIDATE_URL, obj)
      .then(res => {
        const getRes = res.data;
        // sessionStorage.setItem("user", getRes.data);
        console.log(getRes);
        if (getRes.data) {
          this.setState({
            user: getRes.data,
            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
          }, () => {
            this.getClassesHandler();
          })
        }
      }).catch((error) => {
        this.props.history.push('/login.jsp');
      })
  }

  getClassesHandler() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
    }
    console.log(JSON.stringify(obj));
    debugger;
    axios.post(GET_CLASSES, obj)
      .then(res => {
        const classes = res.data;
        this.setState({
          classes: classes,
          errorMessages: res.data.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  };

  getSectedClassHandler = (event) => {
    this.setState({
      selected_class_id: JSON.parse(event.target.value).id,
      class_teacher: JSON.parse(event.target.value).class_name
    })
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
  };

  getDOB = (_date) => {
    this.setState({ dob: _date });
    //this.to.openCalendar();
  };
  getDOJ = (_date) => {
    this.setState({ doj: _date });
    //this.to.openCalendar();
  };
  submitHandler = e => {
    e.preventDefault();
    loadProgressBar();
    const obj = {
      prof_name: this.state.prof_name,
      prof_father_name: this.state.prof_father_name,
      dob: this.state.dob,
      gender: this.state.gender,
      address: this.state.address,
      mobile: this.state.mobile,
      email: this.state.email,
      edu_n_cirtificate: this.state.edu_n_cirtificate,
      profile_image: 'image.jpg',
      doj: this.state.doj,
      designation: this.state.designation,
      class_teacher: this.state.class_teacher,
      selected_class_id: this.state.selected_class_id,
      responsibility: this.state.responsibility,
    }
    axios.post(CREATE_PROFESSIONAL, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
      }).catch((error) => {
      })
  }
  render() {
    const { dob, doj, classes, crop, final_size, imageData, formIsHalfFilledOut } = this.state;
    //console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Add Professional</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Add Professional</div>
        </div>

        <form className="card card-box sfpage-cover" onSubmit={this.submitHandler}>
          <div className="card-body">
            <div className="table-scrollable">
              <div className="col-sm-12">
                <div className="form-body form-horizontal">
                  <div className="row">
                    <div className="col-md-6" >
                      <div className="form-group row">
                        <label className="control-label col-md-4">Name
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <input type="text" name="prof_name"
                            placeholder="enter name" className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'prof_name')} />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Father's Name
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <input type="text" name="prof_father_name"
                            placeholder="enter father name" className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'prof_father_name')} />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Gender
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <select className="form-control form-control-sm" name="gender"
                            onChange={event => this.changeHandler(event, 'gender')}>
                            <option value>Select...</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                          </select>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Address
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <textarea name="address" placeholder="address"
                            className="form-control-textarea form-control" rows={5} defaultValue={""}
                            onChange={event => this.changeHandler(event, 'address')}></textarea>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Birth Date
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <DatePicker
                            onChange={this.getDOB}
                            value={dob}
                            showLeadingZeroes={true}
                          //minDate={new Date()}
                          />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Mobile No.
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <input name="mobile" type="number" placeholder="mobile number"
                            className="form-control form-control-sm"
                            onChange={event => this.changeHandler(event, 'mobile')} /> </div>
                      </div>
                    </div>
                    <div className="col-md-6" >
                      <div className="form-group row">
                        <label className="control-label col-md-4">Email</label>
                        <div className="col-md-8">
                          <div className="input-group">
                            <div className="input-group-prepend">
                              <span className="input-group-text"><i className="fa fa-envelope" /></span>
                            </div>
                            <input type="email" className="form-control form-control-sm"
                              name="email" placeholder="Email Address"
                              onChange={event => this.changeHandler(event, 'email')} /> </div>
                        </div>
                      </div>

                      <div className="form-group row">
                        <label className="control-label col-md-4">Education & Cirtificate
                    </label>
                        <div className="col-md-8">
                          <textarea name="edu_n_cirtificate" className="form-control-textarea form-control"
                            placeholder="Education & Cirtificate" rows={5} defaultValue={""}
                            onChange={event => this.changeHandler(event, 'edu_n_cirtificate')}></textarea>
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Profile Picture
                    </label>
                        <div className="col-md-5">
                          <MyImage
                            //callbackFromParent={this.myCallback}
                            cropComplete={this.onComplete}
                            crop={crop}
                            final_size={final_size}
                          />
                          {imageData !== '' ?
                            <img alt="SmartPSP" className="img-thumbnail" src={`${process.env.PUBLIC_URL}` + imageData} />
                            : null}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <header>Office Use Only </header>
                <div className="form-body form-horizontal">
                  <div className="row">
                    <div className="col-md-6" >
                      <div className="form-group row">
                        <label className="control-label col-md-4">Joining Date
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <DatePicker
                            onChange={this.getDOJ}
                            value={doj}
                            showLeadingZeroes={true}
                          //minDate={new Date()}
                          />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="control-label col-md-4">Designation
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <select className="form-control form-control-sm" name="designation"
                            onChange={event => this.changeHandler(event, 'designation')}>
                            <option value>Select...</option>
                            <option value="Principal">Principal</option>
                            <option value="Vise Principal">Vise Principal</option>
                            <option value="Teacher">Teacher</option>
                            <option value="PTI">PTI</option>
                            <option value="Librarian">Librarian</option>
                            <option value="Office Boy">Office Boy</option>
                            <option value="Peon">Peon</option>
                            <option value="Sweeper">Sweeper</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6" >
                      <div className="form-group row">
                        <label className="control-label col-md-4">Class Teacher
                      <span className="required"> * </span>
                        </label>
                        <div className="col-md-8">
                          <select className="form-control form-control-sm" name="select"
                            onChange={this.getSectedClassHandler}>
                            <option value>Select...</option>
                            {classes.map((option, index) => {
                              return (
                                <option key={index} value={JSON.stringify(option)}>{option.class_name}</option>
                              )
                            })}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-group row">
                    <label className="control-label col-md-2">Responsibility
                    </label>
                    <div className="col-md-10">
                      <textarea name="responsibility" className="form-control-textarea form-control"
                        placeholder="Responsibility" rows={5} defaultValue={""}
                        onChange={event => this.changeHandler(event, 'responsibility')}></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer text-right">
            <button type="submit" className="btn btn-primary mr-2">Submit</button>
            <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
          </div>
        </form>
      </div>

    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: classes } = state.classes;
  return { user, schools, classes };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddProfessional));