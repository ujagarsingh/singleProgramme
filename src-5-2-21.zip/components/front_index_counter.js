import React, { Component } from 'react';
import {  withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
//import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class FrontIndexCounter extends Component {
   render() {
      return (
         <section className="counter-area">
            <div className="container">
               <div className="row">
                  <div className="col-sm-5 col-sm-offset-0 counters">
                     <div className="row">
                        <div className="col-sm-6 counters-item">
                           <div className="section counter-box">
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/counter-icon-01.png`}  />
                              <div className="project-count counter">7096</div>
                              <span>active students</span>
                           </div>
                        </div>
                        <div className="col-sm-6 counters-item">
                           <div className="section counter-box">
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/counter-icon-02.png`}  />
                              <div className="project-count counter">508</div>
                              <span>online courses</span>
                           </div>
                        </div>
                        <div className="col-sm-6 counters-item">
                           <div className="section counter-box">
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/counter-icon-03.png`}  />
                              <div className="project-count counter">167</div>
                              <span>Year of history</span>
                           </div>
                        </div>
                        <div className="col-sm-6 counters-item">
                           <div className="section counter-box">
                              <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/counter-icon-04.png`}  />
                              <div className="project-count counter">70</div>
                              <span>active students</span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="col-sm-5 col-sm-offset-0 counter-text-bottom ml-auto">
                     <div className="counter-text-box">
                        <div className="counter-text">
                           <div className="row">
                              <div className="col-sm-12 section-header-box">
                                 <div className="section-header">
                                    <h2>Get Started Today</h2>
                                 </div>{/* ends: .section-header */}
                              </div>
                           </div>
                           <p>Lorem ipsums dolors sit amet consectetur adipiselo elit sed do eiused tempor the incididunt ut labore et.</p>
                        </div>
                        <div className="counter-btn">
                           <NavLink to="/">Purchase Theme</NavLink>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      )
   }
}
export default withRouter(FrontIndexCounter);