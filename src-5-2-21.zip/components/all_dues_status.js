import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, classesAction, accVoucherEntryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
import Voucher from '../includes/voucher';

class AllDuesStatus extends Component {
	state = {
		selected_dues_entry: [],
		formIsHalfFilledOut: false,
	}
	changeHandler = (event, fieldName, isCheckbox) => {
		this.setState({
			[fieldName]: isCheckbox ? event.target.checked : event.target.value,
			formIsHalfFilledOut: true
		})
	};

	componentDidMount() {
		if (isEmptyObj(this.props.accVoucherEntry)) {
			this.props.getAccVoucherEntry();
		}
		if (isEmptyObj(this.props.schools)) {
			this.props.getSchools();
		}
		if (isEmptyObj(this.props.classes)) {
			this.props.getClasses();
		}
		this.checkFlag();
	}


	checkFlag() {
		setTimeout(() => {
			const _filter = this.props.filteredSchoolData;
			const _all_dues_Entries = this.props.accVoucherEntry;

			if (_all_dues_Entries && _filter) {
				this.filterBySchoolHandler();
			} else {
				this.checkFlag()
			}
		}, 100);
	}

	filterBySchoolHandler = () => {
		const _filter = this.props.filteredSchoolData;
		const _all_dues_Entries = this.props.accVoucherEntry;
		if (!isEmpty(_all_dues_Entries)) {
			const _school_subjects = _all_dues_Entries.filter((item) => {
				if (_filter.slct_school_id) {
					if (item.school_id === _filter.slct_school_id) {
						return item
					}
				} else {
					return item
				}
			})
			this.setState({
				selected_dues_entry: _school_subjects,
			}, () => this.filterByClsHandler())
		}
	}

	filterByClsHandler = () => {

	}

	componentWillReceiveProps(nextProps) {
		if (nextProps.accVoucherEntry) {
			this.setState({
				accVoucherEntry: nextProps.accVoucherEntry
			}, () => { this.filterBySchoolHandler(); })
		}
	}

	confirmBoxDelete = (event, id) => {
		event.preventDefault();
		let del_id = id;
		confirmAlert({
			title: 'stay one moment!',
			message: 'Are you sure do you want to delete this.',
			buttons: [
				{
					label: 'Yes',
					onClick: () => {
						this.props.deleteHandlar({ id: del_id });
					}
				},
				{
					label: 'No',
				}
			]
		});
	};
	// deleteHandlar = (event, id) => {
	//   event.preventDefault();
	//   axios.post(DELETE_URL + '?id=' + id)
	//     .then(res => {
	//       const getRes = res.data;
	//       //console.log(getRes)
	//       Alert.success(getRes.message, {
	//         position: 'bottom-right',
	//         effect: 'jelly',
	//         timeout: 5000, offset: 40
	//       });
	//       const _slider_arr = this.state.slider_arr.filter((item, index) => {
	//         return item.id !== id
	//       })
	//       this.setState({
	//         slider_arr: _slider_arr
	//       })
	//     }).catch((error) => {
	//       //this.setState({ errorMessages: error });
	//     })
	// }
	showDetailsOfEntry(ev, id) {
		ev.preventDefault();
		const _newACCVoucherEntry = this.state.selected_dues_entry.map((item) => {
			if (item.id === id) {
				item.isShow = !item.isShow
			} else {
				item.isShow = false
			}
			return item
		})
		this.setState({
			selected_dues_entry: _newACCVoucherEntry
		})
	};

	render() {
		const { formIsHalfFilledOut, selected_dues_entry } = this.state;
		const { user, schools, classes } = this.props;
		console.log(this.state)
		return (
			<div className="page-content">
				<Helmet>
					<title>All Dues Status</title>
				</Helmet>
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				<div className="page-bar d-flex">
					<div className="page-title">All Dues Status</div>
					{user && schools && classes && selected_dues_entry &&
						<div className="form-inline ml-auto filter-panel">
							<span className="filter-closer">
								<button type="button" className="btn btn-danger filter-toggler-c">
									<i className="fa fa-times"></i>
								</button>
							</span>
							<div className="filter-con">

								<CommonFilters
									showSchoolFilter={true}
									showMediumFilter={false}
									showClassFilter={true}
									filterBySchoolHandler={this.filterBySchoolHandler}
									filterByClsHandler={this.filterByClsHandler}
								/>

							</div>
						</div>
					}
				</div>
				{selected_dues_entry && user &&
					<div className="card card-box sfpage-cover">
						<div className="card-body sfpage-body">
							<div className="table-scrollable">
								<table className="table table-striped table-bordered table-hover table-sm">
									<thead>
										<tr>
											<th />
											<th> Receipt No. </th>
											<th> Trans. Date </th>
											<th> Description</th>
											<th> School Name </th>
											<th> Action </th>
										</tr>
									</thead>
									<tbody>
										{selected_dues_entry.map((item, index) => {
											return (
												<React.Fragment key={index} >
													<tr>
														<td>{index + 1}</td>
														<td>{item.id}</td>
														<td>{item.tr_date}</td>
														<td>{item.description}</td>
														<td><b>{item.school_id}</b> {item.school_name}</td>
														<td className="d-flex">
															<button className="btn btn-warning btn-sm mr-1"
																type="button"
																value={item.id}
																onClick={event => this.showDetailsOfEntry(event, item.id)}>
																{(item.isShow) ? "Hide" : "Show"}
															</button>
															<NavLink to={`/alter_entry.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
																Alter
                            </NavLink>
															<button className="btn btn-danger btn-sm"
																type="button"
																value={item.id}
															// onClick={event => this.confirmBoxDelete(event, item.id)}
															>Del</button>
														</td>
													</tr>
													{(item.isShow) &&
														<tr>
															<td></td>
															<td colSpan="4" className="p-0">
																{<Voucher
																	voucher_detail={item.vouchers} />}
															</td>
															<td></td>
														</tr>
													}
												</React.Fragment>
											)
										})}
									</tbody>
								</table>
							</div>
						</div>
						{/* <div className="card-footer">
            {createItem ?
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-danger btn-sm ">Cancel
            </button>
              :
              <button onClick={event => this.toggeleCreate(event)}
                className="btn btn-primary btn-sm">Add New
            </button>
            }
          </div> */}
					</div>
				}
			</div>
		)
	}
}

function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: schools } = state.schools;
	const { item: classes } = state.classes;
	const { item: accVoucherEntry } = state.accVoucherEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	return {
		user, accVoucherEntry, schools, classes,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getAccVoucherEntry: accVoucherEntryActions.getAccVoucherEntry,
	getSchools: schoolsAction.getSchools,
	getClasses: classesAction.getClasses,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllDuesStatus));