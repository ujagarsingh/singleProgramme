import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import FeeField from './fee_field';
import { connect } from 'react-redux';
import { classesAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

const GET_FEE_CATEGORY = `http://schools.rajpsp.com/api/fee_category/fee_category_structure.php`;
const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
const GET_STUDENTS = `http://schools.rajpsp.com/api/students/read.php`;
const GET_STUDENT = `http://schools.rajpsp.com/api/students/read_one.php`;
const GET_CLASS_FEE = `http://schools.rajpsp.com/api/fee_amount/read_class_fee.php`;
const GET_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/read.php`;
const CREATE_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/create.php`;
const VERIFY_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/verify.php`;
const GET_PRE_DEPOSIT_RECORD = `http://schools.rajpsp.com/api/fee_deposit/read_pre_deposit_months.php`;
const READ_CONVENCE = `http://schools.rajpsp.com/api/conveyance/read.php`;

class GetFees extends Component {
  state = {
    medium: '',
    depo_fee_students: [],
    all_classes: [],
    classes: [],
    conveyances: [],
    selected_class_id: '',
    students: [],
    selected_student_id: '',
    selected_student: '',
    selected_student_info: '',
    fee_date: '',
    pre_fee_deposit_arr: {},
    fee_category: [],
    temp_fee_record: [],
    class_fee_arr: [],
    class_fee_Has: false,
    select_student_has: false,
    deposit_fee_arr: [],
    final_deposit_fee_arr: [],
    varified_deposit_fee_arr: [],
    monthly_fee_amo: 0, // from database
    convence_fee_amo: 0, // from database
    exam_fee_amo: 0, // from database
    reg_fee_amo: 0, // from database
    sports_fee_amo: 0, // from database
    total_amount: 0,
    total_discount: 0,
    ground_total: 0,
    total_monthly_amount: 0,
    total_convence_amount: 0,
    total_monthly_discount: 0,
    total_convence_discount: 0,
    monthly_discount: 0, // in percentage
    convence_discount: 0, // in percengage
    fee_amount: 0,
    current_depo_amount: 0,
    balance_amount: 0,
    current_date: '2019-10-20',
    fee_date: new Date(),
    monthly_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'], // all months of getting fee 
    monthly_selected_deposit_months: [], // current months of fee deposit
    monthly_difference_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'], // not paymented months
    set_monthly_fee_amo: 0,
    //convence_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    convence_will_deposit_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    convence_selected_deposit_months: [],
    convence_diffrence_months: ['July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'],
    set_convence_fee_amo: 0,
    set_exam_fee_amo: 0,
    set_reg_fee_amo: 0,
    set_sports_fee_amo: 0,
    reg_fee: false,
    sports_fee: false,
    exam_fee: false,
    seat_type: '',
    description: '',
    formIsHalfFilledOut: false,
  }
  commonFeeHandler = (obj) => {
    //console.log(obj);
    let _discount = ((obj.name === 'Monthly') ? this.state.selected_student_info.monthly_discount :
      (obj.name === 'Convence') ? this.state.selected_student_info.convence_discount : null);
    let _name = obj.name;
    let _length = obj.values.length;
    let _values = obj.values.toString();

    const _temp_fee_cat = this.state.temp_fee_record.map((item) => {
      const _amo = item.fee_amount;
      const _item = item;
      if (item.cat_name === _name) {
        _item.curn_depo_mts = _values;
        _item.curn_depo_amo = _length * _amo;
        _item.discount = _length * _amo * (_discount / 100);
      }
      return _item;
    })

    this.setState({
      temp_fee_record: _temp_fee_cat
    }, () => {
      this.calcFee();
    })
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value });
    if (fieldName === 'medium') {
      const _medium = event.target.value;
      const _classes = this.state.all_classes.filter((item, inx) => {
        if (item.medium === _medium) {
          return item
        }
      })
      this.setState({
        classes: _classes,
        formIsHalfFilledOut: true
      })
    }
  };
  checkHandler = (event, fieldName, id) => {
    let _final_deposit_fee_arr = null;
    let _id = id;
    if (fieldName === 'select_this') {
      _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
        if (_id === item.id) {
          item['isChecked'] = !item.isChecked;
          return item;
        }
        return item;
      })
      this.setState({
        final_deposit_fee_arr: _final_deposit_fee_arr,
        formIsHalfFilledOut: true
      })
    } else if (fieldName === 'select_all') {
      _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
        item['isChecked'] = (event.target.checked) ? true : false;
        return item;
      })
      this.setState({
        final_deposit_fee_arr: _final_deposit_fee_arr,
        formIsHalfFilledOut: true
      })
    }
  };

  componentDidMount() {
    loadProgressBar();
    const obj = {
      group_id: this.state.group_id,
      school_id: this.state.school_id,
      user_category: this.state.user_category,
      session_year_id: this.state.session_year_id,
    }
    axios.post(GET_CLASSES, obj)
      .then(res => {
        const getRes = res.data;
        this.setState({
          classes: getRes,
          all_classes: getRes,
          errorMessages: getRes.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
    loadProgressBar();
    axios.get(READ_CONVENCE)
      .then(res => {
        const conveyances = res.data;
        this.setState({
          conveyances: conveyances,
          errorMessages: res.data.message
        });
      }).catch((error) => {
        // error
      })

    this.getUnvarifiedRecord();
  };
  getUnvarifiedRecord = () => {
    loadProgressBar();
    axios.get(GET_FEE_DEPOSIT)
      .then(res => {
        const deposited_arr = res.data;
        const _deposited_arr = deposited_arr.map((item) => {
          const _item = item;
          _item.isChecked = false;
          return _item
        })
        this.setState({
          final_deposit_fee_arr: _deposited_arr,
          errorMessages: res.data.message
        });
        ////console.log(this.state.classes);
      }).catch((error) => {
        // error
      })
  }
  feeDepositDate = (feeDate) => {
    this.setState({ fee_date: feeDate });
    //this.to.openCalendar();
  };

  selectStudentNameHandlar = (event) => {
    event.preventDefault();
    const student_id = JSON.parse(event.target.value).admission_number;
    this.setState({
      selected_student: JSON.parse(event.target.value).student_name,
      selected_student_id: JSON.parse(event.target.value).admission_number,
      seat_type: JSON.parse(event.target.value).free_seat,
      description: '',
      pre_fee_deposit_arr: {},
      total_amount: 0,
      total_convence_amount: 0,
      total_convence_discount: 0,
      total_discount: 0,
      total_monthly_amount: 0,
      total_monthly_discount: 0,
      set_monthly_fee_amo: 0,
      set_convence_fee_amo: 0,
      convence_fee_amo: 0,
      temp_fee_record: this.state.fee_category
    },
      () => {
        this.updateRecored_0(student_id);
        this.updateRecored_1(student_id);
      });
  };
  updateRecored_0(student_id) {
    loadProgressBar();
    axios.get(GET_PRE_DEPOSIT_RECORD + '?student_id=' + student_id)
      .then(res => {
        const deposited_arr_ = res.data;
        if (deposited_arr_.message === '') {
          this.setState({
            pre_fee_deposit_arr: deposited_arr_
          }, () => {
            this.updatePreFeeRecord();
          });
        } else {
          Alert.error(deposited_arr_.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
          this.updatePreFeeRecord();
        }
      }).catch((error) => {
        // error
      });
  }
  updatePreFeeRecord() {
    const _temp_fee_record = this.state.temp_fee_record;
    const _deposited_arrX = this.state.pre_fee_deposit_arr;
    const _record = _temp_fee_record.map((item_) => {
      item_.paid_depo_mts = '';
      item_.rest_mts = '';
      const _key = item_.cat_name.toLowerCase();
      if (_deposited_arrX[_key] !== undefined) {
        const _value = _deposited_arrX[_key].toString();
        item_.paid_depo_mts = _value;
        item_.rest_mts = this.getOption(_key);
      } else {
        item_.rest_mts = this.getOption(_key);
      }
      return item_
    })

    this.setState({
      pre_fee_deposit_arr: _record
    })
  }
  updateRecored_1(student_id) {
    loadProgressBar();
    axios.get(GET_STUDENT + '?id=' + student_id)
      .then(res => {
        const stu_reco = res.data;
        if (stu_reco.message === undefined) {
          var _conveyance_amo = 0;
          this.state.conveyances.filter((item, index) => {
            if (item.stoppage_name === stu_reco.convence_area) {
              _conveyance_amo = parseInt(item.stoppage_amo);
            }
          })

          this.setState({
            selected_student_info: stu_reco,
            convence_fee_amo: _conveyance_amo,
            errorMessages: res.data.message,
            select_student_has: true
          });
        } else {
          Alert.warning(stu_reco.message, {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
          });
        }
      }).catch((error) => {
        // error
      })
  }
  arrayDiffrence = (a1, a2) => {
    var a = [], diff = [];
    for (var i = 0; i < a1.length; i++) {
      a[a1[i]] = true;
    }
    for (var i = 0; i < a2.length; i++) {
      if (a[a2[i]]) {
        delete a[a2[i]];
      } else {
        a[a2[i]] = true;
      }
    }
    for (var k in a) {
      diff.push(k);
    }
    return diff;
  }
  formatDate = (date) => {
    var monthNames = [
      "January", "February", "March",
      "April", "May", "June", "July",
      "August", "September", "October",
      "November", "December"
    ];
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    return day + ' ' + monthNames[monthIndex] + ' ' + year;
  }
  calcFee = () => {
    var { temp_fee_record } = this.state;
    console.log(temp_fee_record);
    let _total_fee = 0;
    let _total_discount = 0;
    let _balance_amo = 0;
    temp_fee_record.map((item) => {
      _total_fee = _total_fee + ((item.curn_depo_amo > 0) ? parseInt(item.curn_depo_amo) : 0);
      _total_discount = _total_discount + ((item.discount > 0) ? parseInt(item.discount) : 0);
      _balance_amo = _total_fee - _total_discount;
    })
    this.setState({
      total_amount: _total_fee - _total_discount,
      total_discount: _total_discount,
      ground_total: _total_fee,
      balance_amount: _balance_amo
    }, () => {
      this.createMsz();
    })

  }
  createMsz = () => {
    const _statef = this.state;
    const _ef = (_statef.exam_fee) ? ', Exam Fee' : '';
    const _rf = (_statef.reg_fee) ? ', Reg. Fee' : '';
    const _sf = (_statef.sports_fee) ? ', Sport Fee' : '';
    const _cf = (_statef.convence_selected_deposit_months.length > 0) ?
      ((_statef.convence_selected_deposit_months.length === 12) ?
        (', Monthly : Full Year') :
        (', Transport : ' + _statef.convence_selected_deposit_months.join(', '))) : '';
    const _mf = (_statef.monthly_selected_deposit_months.length > 0) ?
      ((_statef.monthly_selected_deposit_months.length === 12) ?
        (', Monthly : Full Year') :
        (', Monthly : ' + _statef.monthly_selected_deposit_months.join(', '))) : '';
    const _da = (_statef.total_discount) ?
      (', Discount : ' + _statef.total_discount +
        ', Ground Total : ' + _statef.ground_total) : '';

    const _msz = _statef.selected_student + ' of ' + _statef.student_class + ' Deposited fee : ' +
      _mf + _cf + _sf + _rf + _ef +
      ', Amount : ' + _statef.total_amount + _da

    this.setState({
      description: _msz
    })
  }
  getSectedClassHandler = (event) => {
    loadProgressBar();
    this.setState({
      selected_class_id: JSON.parse(event.target.value).id,
      student_class: JSON.parse(event.target.value).class_name
    }, () => {
      const obj = {
        class_id: this.state.selected_class_id,
        medium: this.state.medium
      };

      axios.post(GET_STUDENTS, obj)
        .then(res => {
          this.setState({
            students: res.data,
            errorMessages: res.data.message
          });
          //console.log(this.state.students);
        }).catch((error) => {
          // error
        })
      axios.get(GET_CLASS_FEE + '?class_id=' + this.state.selected_class_id)
        .then(res => {
          if (Array.isArray(res.data)) {
            this.setState({
              class_fee_arr: res.data,
              class_fee_Has: true
            });
            //  //console.log(this.state);
          } else {
            Alert.warning('This Class Fee Structure Not Added Please Update it first using [ Setting > Pamnent ]', {
              position: 'bottom-right',
              effect: 'jelly',
              timeout: 5000, offset: 40
            });
            this.setState({
              class_fee_Has: false
            })
          }
          //console.log(this.state);
        }).catch((error) => {
          // error
        })

      loadProgressBar();
      // console.log(JSON.stringify(obj));
      axios.post(GET_FEE_CATEGORY, obj)
        .then(res => {
          const fee_category = res.data;
          this.setState({
            fee_category: fee_category
          });
        }).catch((error) => {
          // error
        })
    });
  }
  getFeeTime = (elem) => {
    let fee_time = [];
    if (elem.collect_time_jul = 'yes') { fee_time.push('July') }
    if (elem.collect_time_aug = 'yes') { fee_time.push('August') }
    if (elem.collect_time_sep = 'yes') { fee_time.push('September') }
    if (elem.collect_time_oct = 'yes') { fee_time.push('October') }
    if (elem.collect_time_nov = 'yes') { fee_time.push('November') }
    if (elem.collect_time_dec = 'yes') { fee_time.push('December') }
    if (elem.collect_time_jan = 'yes') { fee_time.push('January') }
    if (elem.collect_time_feb = 'yes') { fee_time.push('Fabruary') }
    if (elem.collect_time_mar = 'yes') { fee_time.push('March') }
    if (elem.collect_time_apr = 'yes') { fee_time.push('April') }
    if (elem.collect_time_may = 'yes') { fee_time.push('May') }
    if (elem.collect_time_jun = 'yes') { fee_time.push('June') }
    return fee_time;
  }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Add this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    loadProgressBar();
    const _statef = this.state;
    const obj = {
      fee_data: _statef.deposit_fee_arr,
      total_amount: _statef.total_amount,
      fee_amount: _statef.ground_total,
      balance_amount: _statef.balance_amount,
      student_name: _statef.selected_student,
      student_class: _statef.student_class,
      deposit_date: _statef.fee_date,
      description: _statef.description,
      discount: _statef.total_discount
    };
    //console.log(JSON.stringify(obj));
    axios.post(CREATE_FEE_DEPOSIT, obj)
      .then(res => {
        const getRes = res.data;
        //console.log(getRes)
        this.getUnvarifiedRecord();
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        this.setState({
          deposit_fee_arr: [],
          monthly_selected_deposit_months: [],
          convence_selected_deposit_months: [],
          reg_fee: false,
          sports_fee: false,
          exam_fee: false,
          selected_student: '',
          description: '',
          total_amount: 0,
          fee_amount: 0,
          balance_amount: 0,
          pre_fee_deposit_arr: {}
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })

  }
  confirmBoxVarify = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Varify this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.varifyHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  varifyHandler = () => {
    loadProgressBar();
    const _myobj = this.state.final_deposit_fee_arr.filter((item) => {
      if (item.isChecked === true) {
        return item['id'] === item.id;
      }
    })
    if (_myobj.length > 0) {
      const myobj = { obj: _myobj };
      axios.post(VERIFY_FEE_DEPOSIT, myobj)
        .then(res => {
          const getRes = res.data;
          //console.log(getRes)
          this.setState({
            final_deposit_fee_arr: []
          }, () => {
            this.getUnvarifiedRecord()
          })
        }).catch((error) => {
          //this.setState({ errorMessages: error });
        })
    } else {
      Alert.warning('Please select at least one detail.', {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
  }

  getOption(category) {
    //console.log(category);
    let all_month = [];
    let paid_month = [];
    let _result = [];
    let _cat_type = '';
    let _cat_name = '';
    this.state.temp_fee_record.map((item) => {
      _cat_name = item.cat_name.toLowerCase();
      if (_cat_name === category) {
        all_month = item.collect_time.split(',');
        paid_month = item.paid_depo_mts.split(',');
        _cat_type = item.cat_type;
      }
    });

    if (_cat_type === "multiple") {
      _result = this.arrayDiffrence(all_month, paid_month);
      return _result;
    } else {
      return ['Yes'];
    }

  }
  render() {
    const { medium, classes, class_fee_Has, students, fee_date, monthly_discount, convence_discount, total_convence_amount,
      total_monthly_amount, total_monthly_discount, set_monthly_fee_amo, total_convence_discount, set_convence_fee_amo,
      description, total_amount, total_discount, ground_total, final_deposit_fee_arr, class_fee_arr, temp_fee_record,
      select_student_has } = this.state;
    console.log(this.state.pre_fee_deposit_arr);
    //console.log(this.state.fee_category);
    return (
      <div className="page-content">
        <Helmet>
          <title>Get Fee</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Get Fees</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-1">Medium :</label>
                <select className="form-control form-control-sm"
                  onChange={event => this.changeHandler(event, 'medium')}>
                  <option >Select ...</option>
                  <option value="English">English</option>
                  <option value="Hindi" >Hindi</option>
                </select>
              </div>
              <div className="form-group mr-2 mt-1">
                <label className="control-label mr-1">Class<span className="required"> * </span>
                </label>
                <select className="form-control form-control-sm" name="select"
                  disabled={medium === '' ? true : false}
                  onChange={this.getSectedClassHandler}>
                  <option value>Select...</option>
                  {classes.map((option, index) => {
                    return (
                      <option key={index} value={JSON.stringify(option)}>{option.class_name}</option>
                    )
                  })}
                </select>
              </div>
              {(class_fee_Has) ?
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-1">Student Name <span className="required"> * </span>
                  </label>
                  <select
                    disabled={(students.length > 0) ? false : true}
                    className="form-control form-control-sm" name="select"
                    //defaultValue={selected_student}
                    onChange={this.selectStudentNameHandlar}>
                    <option value>Select...</option>
                    {students.map((option, index) => {
                      return (
                        <option key={index} value={JSON.stringify(option)}>{option.student_name}</option>
                      )
                    })}
                  </select>
                </div>
                : null}
              <div className="form-group mt-1">
                <label className="control-label mr-1">Date
                    </label>
                <div className="input-group bg-white">
                  <DatePicker
                    onChange={this.feeDepositDate}
                    value={fee_date}
                    showLeadingZeroes={true}
                    minDate={new Date()}
                  />
                </div>
              </div>
            </div></div>
        </div>
        <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-body" >
            <div className="table-scrollable">
              <div className="col-sm-12">
                {class_fee_Has ?
                  <div className="form-horizontal">
                    {select_student_has ?
                      <div className="form-body">
                        <div className="row">
                          {temp_fee_record.map((item, inx) => {
                            return (
                              <FeeField
                                key={inx}
                                name={item.cat_name}
                                value={23}
                                options={item.rest_mts}
                                singleFeeHandler={this.commonFeeHandler}
                              />
                            )
                          })}
                        </div>
                        <div className="row">
                          <div className="col-lg-6">
                            <div className="form-group row">
                              <label className="control-label col-md-5">Discount in Monthly Fee</label>
                              <div className="col-md-7">
                                <div className="input-group mb-3">
                                  <input type="text" className="form-control form-control-sm"
                                    disabled={true}
                                    value={monthly_discount}
                                    maxLength="2" size="2"
                                    onChange={event => this.monthlyDiscountHandlar(event)} />
                                  <div className="input-group-append">
                                    <span className="input-group-text pt-1 pb-1 ">%</span>
                                  </div>
                                </div>
                                <div className="row">
                                  <div className="col pr-0">
                                    <input disabled={true}
                                      disabled={true}
                                      type="text" className="form-control form-control-sm"
                                      value={total_monthly_amount} />
                                  </div>
                                  <div className="col pl-0">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={total_monthly_discount} />
                                  </div>
                                  <div className="col">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={set_monthly_fee_amo} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-6">
                            <div className="form-group row">
                              <label className="control-label col-md-5">Discount in Convence Fee</label>
                              <div className="col-md-7">
                                <div className="input-group mb-3">
                                  <input type="text" className="form-control form-control-sm"
                                    disabled={true}
                                    value={convence_discount}
                                    maxLength="2" size="2"
                                    onChange={event => this.convenceDiscountHandlar(event)} />
                                  <div className="input-group-append">
                                    <span className="input-group-text pt-1 pb-1 ">%</span>
                                  </div>
                                </div>
                                <div className="row">
                                  <div className="col pr-0">
                                    <input disabled={true}
                                      type="text" className="form-control form-control-sm"
                                      value={total_convence_amount} />
                                  </div>
                                  <div className="col pl-0">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={total_convence_discount} />
                                  </div>
                                  <div className="col">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={set_convence_fee_amo} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="d-block w-100"></div>
                        </div>
                        <hr />
                        <div className="row">
                          <div className="col-md-6">
                            <div className="form-group row">
                              <label className="control-label col-md-12 text-left pb-2 pt-0">Payment Details
                    </label>
                              <div className="col-md-12">
                                <textarea
                                  value={description}
                                  onChange={event => this.changeHandler(event, 'description')}
                                  placeholder="payment details" className="form-control form-control-sm-textarea form-control-sm"
                                  rows={5} />
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="form-group row">
                              <label className="control-label col-md-5">Total Fee
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={total_amount}
                                  type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-5">Total Discount
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={total_discount}
                                  type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-5">Ground Total
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={ground_total}
                                  type="text" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>

                          </div>
                        </div>

                      </div>
                      : null}
                  </div>
                  : null}
                <div className="card card-box h-auto">
                  <div className="table-responsive">
                    <table className="table table-striped table-bordered table-hover table-sm m-0">
                      <thead>
                        <tr>
                          <th className="center">
                            <div className="custom-control custom-checkbox">
                              <input type="checkbox"
                                id="select_all" className="custom-control-input"
                                onChange={event => this.checkHandler(event, 'select_all', true)} />
                              <label className="custom-control-label" htmlFor="select_all">All</label>
                            </div>
                          </th>
                          <th className="center"> Student Name </th>
                          <th className="center"> Class </th>
                          <th className="center"> Deposite Date </th>
                          <th className="center"> Total amount</th>
                          <th className="center"> Disount</th>
                          <th className="center"> Total</th>
                          {/*<th className="center"> Balance</th>*/}
                          <th className="center"> Description</th>
                          <th className="center"> Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.isArray(final_deposit_fee_arr) ? (
                          final_deposit_fee_arr.map((value, index) => {
                            return (
                              <tr key={index}  >
                                <td className="center">
                                  <div className="custom-control custom-control-inline custom-checkbox">
                                    <input type="checkbox"
                                      checked={value.isChecked}
                                      id={`check_` + index} className="custom-control-input"
                                      onChange={event => this.checkHandler(event, 'select_this', value.id)} />
                                    <label className="custom-control-label" htmlFor={`check_` + index}>{value.id}</label>
                                  </div>
                                </td>
                                <td className="center">{value.student_name}</td>
                                <td className="center">{value.student_class}</td>
                                <td className="center">{value.deposit_date}</td>
                                <td className="center">{value.total_amount}</td>
                                <td className="center">{value.discount}</td>
                                <td className="center">{value.fee_amount}</td>
                                {/*<td className="center">{value.balance_amount}</td>*/}
                                <td className="left">{value.description}</td>
                                <td className="center">
                                  {/*<NavLink to="edit_professional" className="btn btn-primary btn-sm">
                                  Edit
                          </NavLink>*/}
                                  <button className="btn btn-danger btn-sm"

                                  >
                                    Del
                                      </button>
                                </td>
                                {/*
                               <tr >
                                 <td colSpan="3"></td>
                                 <td colSpan="6" className="p-0">
                                   <table className="table table-condensed m-0">
                                     <thead>
                                       <tr>
                                         <th className="center p-0"> ID No.</th>
                                         <th className="center p-0"> Fee Title </th>
                                         <th className="center p-0"> Deposit Amount</th>
                                         <th className="center p-0"> Month of fee </th>
                                       </tr>
                                     </thead>
                                     <tbody>
                                       {value.xsd.map((value1, index1) => {
                                         return (
                                           <tr className="" key={index1}>
                                             <td className="center p-0">{index1 + 1}</td>
                                             <td className="center p-0">{value1.fee_title}</td>
                                             <td className="center p-0">{value1.fee_amount}</td>
                                             <td className="center p-0">{value1.month_of_fee}</td>
                                           </tr>
                                         )
                                       })}
                                     </tbody>
                                   </table>
                                 </td>
                               </tr>
                                     */}
                              </tr>
                            )
                          })
                        ) : null}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer d-flex">
            <button type="button" disabled={true} className="btn btn-primary mr-2">Message</button>
            <button type="button" className="btn btn-success mr-2"
              onClick={event => this.confirmBoxVarify(event)}
            >Varify</button>

            <button type="submit"
              disabled={ground_total > 0 ? false : true}
              className="btn btn-primary mr-2 ml-auto">Submit</button>
            <NavLink to="/fees_collection.jsp" className="btn btn-danger">Cancel</NavLink>
          </div>
        </form>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: classes } = state.classes;
  return { user, classes };
}

const actionCreators = {
  getClasses: classesAction.getClasses,
}

export default connect(mapStateToProps, actionCreators)(withRouter(GetFees));