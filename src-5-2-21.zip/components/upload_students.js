import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import axios from 'axios';
import Alert from 'react-s-alert';
import CSVReader from 'react-csv-reader'
import { Helmet } from "react-helmet";
import { ExportCSV } from '../utility/Export_CSV/ExportCSV';
import { connect } from 'react-redux';
import { schoolsAction, studentsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';


// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const SAVEIN_DATABASE = `http://schools.rajpsp.com/api/uploads/save_in_database.php`;
// const INSERT_NEW_RECORDS = `http://schools.rajpsp.com/api/uploads/insert_new_records.php`;
const CREATE_STUDENT_URL = `http://schools.rajpsp.com/api/students/create.php`;
// const UPLOAD_STUDENTS = `http://schools.rajpsp.com/api/uploads/upload_student.php`;
// const READ_CLASS_STUDENT = `http://schools.rajpsp.com/api/students/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;   

const handleForce = (data, fileInfo) => console.dir(data, fileInfo);
const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
};

class UploadStudents extends Component {
  state = {
    schools: [],
    students: [],
    user_id: 1,
    filtered_students: [],
    dis_continue_students: [],
    updated_students: [],
    new_students: [],
    old_student_Obj: [],
    dup_students: [],
    isDuplicate: false,
    // firstStage: false,
    // secondStage: false,
    student_Obj: [],
    medium_arr: [],
    medium: '',
    formIsHalfFilledOut: false,
    is_school_select: false,
    dummy_stu_data: [],
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (isCheckbox) {
      const _value = event.target.checked;
      const _fieldName = fieldName.split('_');
      const _chkFlag = _fieldName[0];
      const _chkId = _fieldName[1];
      const _chkType = _fieldName[2];
      let _data_array = [];
      let _data_obj = '';
      if (_chkType === "NEWSTU") {
        _data_array = this.state.new_students;
        _data_obj = 'new_students';
      } else if (_chkType === "DUPSTU") {
        _data_array = this.state.dup_students;
        _data_obj = 'dup_students';
      } else if (_chkType === "UPDATESTU") {
        _data_array = this.state.updated_students;
        _data_obj = 'updated_students';
      } else if (_chkType === "DISCONTI") {
        _data_array = this.state.dis_continue_students;
        _data_obj = 'dis_continue_students';
      }
      this.updateStudentData(_data_array, _data_obj, _chkId, _value);
    } else if (fieldName === 'school') {
      const _inx = event.target.value;
      if (_inx !== '') {
        const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
        const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
        sessionStorage.setItem("school_id", _sch_id);
        this.setState({
          school_id: _sch_id,
          medium_arr: _medium,
          medium: (_medium.length === 1 ? _medium[0] : ''),
          selected_school_index: _inx,
          is_school_select: true
        }, () => {
          this.filterStudentsOfSchool(_sch_id);
        })
      } else {
        this.setState({
          is_school_select: false
        })
      }
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.mediumHandler(_medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };

  updateStudentData(data_array, data_obj, _chkId, _value) {
    let _student_data = [];
    if (_chkId === "all") {
      _student_data = data_array.map((item) => {
        item = { ...item, 'is_checked': _value };
        return item
      })
    } else {
      _student_data = data_array.map((item, index) => {
        if (parseInt(_chkId) === index) {
          item = { ...item, "is_checked": _value };
        }
        return item
      })
    }

    this.setState({
      [data_obj]: _student_data
    })
  }
  createDummyStudentCsv() {
    let item = [{
      s_id: '',
      student_name: '',
      father_name: '',
      mother_name: '',
      stu_class: '',
      medium: '',
      admission_number: '',
      caste: '',
      gender: '',
      dob: '',
      is_rte_student: ''
    }];

    this.setState({
      dummy_stu_data: item
    })
  }
  filterStudentsOfSchool(sch_id) {
    const _students = this.props.students;
    const _filtered_students = _students.filter((item) => {
      if (item.school_id === sch_id) {
        return item
      }
    })
    this.setState({
      filtered_students: _filtered_students
    }, () => {
      const dup_students = this.duplicateStudent(_filtered_students);
      this.setState({ dup_students })
    });
  }
  matchStudent(data_1, data_2) {
    // getting data_1 to whitch is not meet in data_2;

    // console.log(JSON.stringify(data_1));
    // console.log(JSON.stringify(data_2));
    // debugger

    const _obj = data_1.filter((online_item) => {
      let flag = 1;
      const _on_val = online_item.admission_number;
      data_2.forEach((sofware_item) => {
        const _off_val = sofware_item.admission_number;
        if (_on_val == _off_val) {
          flag = 0
        }
      })
      if (flag === 1) {
        return online_item
      }
    })
    return _obj
  }
  duplicateStudent(filtered) {
    let _ids1 = [];
    let _ids2 = [];
    filtered.map((item) => {
      const ct_no = item['admission_number']
      if (_ids1.includes(ct_no)) {
        _ids2.push(ct_no);
      } else {
        _ids1.push(ct_no);
      }
    })
    // debugger
    const dup_student = filtered.filter((item, inx) => {
      const ct_no = item['admission_number']
      if (_ids2.includes(ct_no)) {
        return item
      }
    })
    if (dup_student.length > 0) {
      this.setState({ isDuplicate: true })
    }
    return dup_student;
  }
  matchUpdatedStudent(data_1, data_2) {
    const _obj = data_1.filter((online_item) => {
      let flag = false;
      let _sofware_item = {};
      let _online_item = {};
      data_2.forEach((sofware_item) => {
        if (online_item.admission_number == sofware_item.admission_number) {
          if (
            online_item.student_name !== sofware_item.student_name ||
            online_item.father_name !== sofware_item.father_name ||
            online_item.mother_name !== sofware_item.mother_name ||
            online_item.stu_class !== sofware_item.stu_class ||
            online_item.caste !== sofware_item.caste ||
            online_item.gender !== sofware_item.gender
          ) {
            flag = true;
            _sofware_item = sofware_item;
            _online_item = online_item;
          }
        }
      })
      if (flag) {
        console.log('SoftWare Item --------- > ', _sofware_item)
        console.log('Online Item --------- > ', _online_item)
        // debugger;
        return online_item
      }
    })
    return _obj
  }

  dateInWords(stu_dob) {
    // debugger
    let d = new Date(stu_dob);
    let monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    let new_date = d.getDate() + "-" + monthNames[d.getMonth()] + "-" + d.getFullYear();;
    return new_date;
  }

  studentObjHandler = (new_obj) => {
    // debugger
    this.setState({
      dis_continue_students: [],
      new_students: [],
      updated_students: [],
      dup_students: [],
    }, () => {
      const filtered = this.state.filtered_students;
      const dis_continue_students = this.matchStudent(filtered, new_obj);
      const new_students = this.matchStudent(new_obj, filtered);
      const updated_students = this.matchUpdatedStudent(new_obj, filtered);
      const dup_students = this.duplicateStudent(filtered);
      const dis_cont_stud = dis_continue_students.filter((item) => {
        if (item.dis_continue === '0') {
          return item;
        }
      })
      this.setState({
        dis_continue_students: dis_cont_stud,
        new_students: new_students,
        updated_students: updated_students,
        dup_students: dup_students,
        excel_student: new_obj,
        // firstStage: true
      })
    })
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    this.createDummyStudentCsv();
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getStudentRecords();
  //           this.createDummyStudentCsv();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.state.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       ////console.log(this.state.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getStudentRecords() {
  //   const obj = {
  //     group_id: this.state.group_id,
  //     session_year_id: this.state.session_year_id,
  //     user_category: this.state.user_category,
  //     school_id: this.state.school_id
  //   }
  //   // console.log(JSON.stringify(obj));
  //   axios.post(READ_CLASS_STUDENT, obj)
  //     .then(res => {
  //       const resData = res.data;
  //       if (resData.length > 0) {
  //         this.setState({
  //           students: resData,
  //           errorMessages: resData.message
  //         });
  //       }
  //     }).catch((error) => {
  //       // error
  //     });
  // }
  // uploadStudentHandler = e => {
  //   loadProgressBar();
  //   e.preventDefault();
  //   const group_id = this.state.group_id;
  //   const school_id = this.state.school_id;
  //   const user_id = this.state.user_id;
  //   const session_year_id = this.state.session_year_id;
  //   const excel_student = this.state.excel_student;
  //   const obj = {
  //     group_id, school_id, session_year_id, user_id, excel_student: excel_student
  //   }
  //   console.log(JSON.stringify(obj))
  //   debugger
  //   axios.post(UPLOAD_STUDENTS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       console.log(getRes)
  //       debugger
  //       this.setState({
  //         dis_continue_students: getRes.tc_student,
  //         new_students: getRes.new_student,
  //         updated_students: getRes.modify_student,
  //         secondStage: true
  //       })
  //       if (getRes.message) {
  //         Alert.success(getRes.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //       }
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }

  generateMatchedStudentTable(students, title, flag) {
    // debugger
    return (
      <div>
        <h6 className={"d-flex p-1 text-white " +
          ((flag === "NEWSTU") ? 'bg-success' :
            ((flag === "DUPSTU") ? 'bg-warning' :
              ((flag === "UPDATESTU") ? 'bg-info' : 'bg-danger')))}>
          <span className="p-2">{title}</span>
          <button
            type="button"
            className="ml-auto btn btn-secondary btn-sm"
            value={flag}
            onClick={event => this.handalShowHide(event)}
          >Hide</button>
        </h6>
        <div>
          <div className="table-responsive">
            <table className="table table-striped table-bordered table-hover text-nowrap table-sm">
              <thead>
                <tr>
                  <th>
                    <div className="custom-control custom-checkbox" >
                      <input type="checkbox" className="custom-control-input" id={`chk_all_${flag}`}
                        onChange={event => this.changeHandler(event, `chk_all_${flag}`, true)}
                      />
                      <label className="custom-control-label" htmlFor={`chk_all_${flag}`}>
                        All</label>
                    </div>
                  </th>
                  <th>STUDENT NAME</th>
                  <th>FATHER NAME</th>
                  <th>MOTHER NAME</th>
                  <th>DOB</th>
                  <th>GENDER</th>
                  <th>SOCIAL CATEGORY</th>
                  <th>ENROL NO.</th>
                  <th>CLASS</th>
                </tr>
              </thead>
              <tbody>
                {students.map((value, index) => {
                  return (
                    <tr key={index}>
                      <td>
                        <div className="custom-control custom-checkbox" >
                          <input type="checkbox" className="custom-control-input"
                            checked={value.is_checked}
                            id={`chkI_${index}_${flag}`}
                            onChange={event => this.changeHandler(event, `chkI_${index}_${flag}`, true)}
                          />
                          <label className="custom-control-label" htmlFor={`chkI_${index}_${flag}`}>
                            {index + 1}.</label>
                        </div>
                      </td>
                      <td>{value.student_name}</td>
                      <td>{value.father_name}</td>
                      <td>{value.mother_name}</td>
                      <td>{value.dob}</td>
                      <td>{value.gender}</td>
                      <td>{value.caste}</td>
                      <td>{value.admission_number}</td>
                      <td>{value.stu_class}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }

  handalShowHide = (e) => {
    e.preventDefault();
    const _table = e.target.parentElement.nextSibling;
    const _table_class = e.target.parentElement.nextSibling.classList;
    if (_table_class.length === 0) {
      _table.className = 'd-none';
      e.target.innerText = "Show";
    } else {
      _table.className = "";
      e.target.innerText = "Hide";
    }
  }

  // confirmBoxSubmit = (event) => {
  //   event.preventDefault();
  //   confirmAlert({
  //     title: 'stay one moment!',
  //     message: 'Are you sure do you want to Update this.',
  //     buttons: [
  //       {
  //         label: 'Yes',
  //         onClick: () => {
  //           this.saveOnDatabaseStudentHandler();
  //         }
  //       },
  //       {
  //         label: 'No',
  //       }
  //     ]
  //   });
  // };

  // saveOnDatabaseStudentHandler() {
  //   const group_id = this.state.group_id;
  //   const school_id = this.state.school_id;
  //   const user_id = this.state.user_id;
  //   const session_year_id = this.state.session_year_id;
  //   const obj = {
  //     group_id, school_id, session_year_id, user_id,
  //   }
  //   console.log(JSON.stringify(obj))
  //   debugger
  //   axios.post(SAVEIN_DATABASE, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       // debugger
  //       if (getRes.message) {
  //         Alert.success(getRes.message, {
  //           position: 'bottom-right',
  //           effect: 'jelly',
  //           timeout: 5000, offset: 40
  //         });
  //       }
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }
  refreshHandler() {
    this.setState({
      // firstStage: false,
      // secondStage: false,
      dup_students: [],
      dis_continue_students: [],
      new_students: [],
      selected_school_index: '',
      updated_students: [],
      upload_student_data: ''
    })
  }
  addNewRecords(ev, studdents) {
    ev.preventDefault();
    let group_id = this.state.group_id;
    let school_id = this.state.school_id;
    let session_year_id = this.state.session_year_id;
    const new_students = studdents;
    const obj = new_students.map((item) => {
      if (item.is_checked) {
        return item;
      }
    })
    if (obj.length > 0) {
      const final_obj = { 'myObj': obj, group_id, school_id, session_year_id };
      console.log(JSON.stringify(final_obj));
      debugger
      axios.post(CREATE_STUDENT_URL, final_obj)
        .then(res => {
          const getRes = res.data;
          //console.log(getRes)
          // debugger
          if (getRes.message) {
            Alert.success(getRes.message, {
              position: 'bottom-right',
              effect: 'jelly',
              timeout: 5000, offset: 40
            });
          }
        }).catch((error) => {
          //this.setState({ errorMessages: error });
        })
    } else {
      Alert.success("Please Select Students First", {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
  }
  papaparseOptions = {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    transformHeader: header =>
      header
        .toLowerCase()
        .replace(/\W/g, '_')
  }
  handleForce(data) {
    debugger
    console.log(data)

  }
  handleDarkSideForce(data) {
    debugger
    console.log(data)

  }
  render() {
    const {
      formIsHalfFilledOut, dup_students, dis_continue_students, new_students, is_school_select,
      selected_school_index, updated_students, medium_arr, medium, dummy_stu_data
    } = this.state;
    const { user, schools, students } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content" >
        <Helmet>
          <title>Upload Student Data</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Upload Student Data</div>
        </div>
        {user && schools && students &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="card-box">
                  {dup_students.length > 0 ?
                    this.generateMatchedStudentTable(dup_students, 'Duplicate Enrollment No. [Update From: (Student > All Record) Panel]', 'DUPSTU')
                    : null}
                  {new_students.length > 0 ?
                    this.generateMatchedStudentTable(new_students, 'New Student', 'NEWSTU')
                    : null}
                  {new_students.length > 0 ?
                    <button className="btn btn-success mb-4 ml-2"
                      onClick={event => { this.addNewRecords(event, new_students) }}>Add New Record</button>
                    : null}
                  {updated_students.length > 0 ?
                    this.generateMatchedStudentTable(updated_students, 'New Student with Duplicate Enrollment No. ', 'UPDATESTU')
                    : null}
                  {updated_students.length > 0 ?
                    <button className="btn btn-primary mb-4  ml-2"
                      onClick={event => { this.addNewRecords(event, updated_students) }}>Add New Record</button>
                    : null}
                  {/* {dis_continue_students.length > 0 ?
                    this.generateMatchedStudentTable(dis_continue_students, 'Now Dis Continued Student', 'DISCONTI')
                    : null} */}
                  {/* {dis_continue_students.warning > 0 ?
                    <button className="btn btn-primary mb-4" onClick={event => { this.disContinueRecords(event) }}>Dis Continue Record</button>
                    : null} */}
                </div>
              </div>
            </div>


            <div className="card-footer">
              <div className="row text-center mb-1">
                <div className="col">
                  <span className="badge badge-pill badge-primary">Stap 1</span>
                </div>
                <div className="col">
                  <span className="badge badge-pill badge-primary">Stap 2</span>
                </div>
                <div className="col">
                  <span className="badge badge-pill badge-primary">Stap 3</span>
                </div>
              </div>
              <div className="form-body">
                <div className="form-inline">
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Schools :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='school'
                      value={selected_school_index}
                      onChange={event => this.changeHandler(event, 'school')}>
                      <option value="">Select ...</option>
                      {schools.map((item, index) => {
                        return (
                          <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group mr-2 mt-1">
                    <label className="control-label mr-2">Medium :</label>
                    <select className="form-control form-control-sm"
                      required
                      ref='medium'
                      disabled={medium_arr.length > 1 ? false : true}
                      value={medium}
                      onChange={event => this.changeHandler(event, 'medium')}>
                      <option value="">Select ...</option>
                      {medium_arr.map((item, index) => {
                        return (
                          <option key={index} value={item}>{item}</option>
                        )
                      })}
                    </select>
                  </div>
                  <div className="form-group  ml-auto">
                    {/* <ExcelReader studentObjHandler={this.studentObjHandler} /> */}

                    <CSVReader
                      cssClass="csv-reader-input"
                      // label="Select CSV with secret Death Star statistics"
                      onFileLoaded={this.studentObjHandler}
                      onError={this.handleDarkSideForce}
                      parserOptions={papaparseOptions}
                      inputId="ObiWan"
                      inputStyle={{ color: 'red' }}
                    />
                  </div>
                </div>
                {is_school_select ?
                  <div className="mt-1 d-flex">
                    <ExportCSV
                      csvData={dummy_stu_data}
                      fileName={'upload_student_data'} />

                    {/* 
                <button type="button"
                  className="btn btn-secondary ml-auto mr-1"
                  disabled={(dis_continue_students.length > 0 ||
                    new_students.length > 0 || updated_students.length > 0 && !secondStage) ? false : true}
                  onClick={event => this.uploadStudentHandler(event)}>
                  Upload
                </button>
                <button type="button"
                  className="btn btn-success mr-1"
                  disabled={!secondStage}
                  onClick={event => this.confirmBoxSubmit(event)}>
                  Save
                </button> */}

                    <button type="button" className="btn btn-danger ml-auto"
                      onClick={event => this.refreshHandler(event)}>
                      Refresh</button>
                  </div>
                  : null}
              </div>
            </div>
          </div>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  return { user, schools, students };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getStudents: studentsAction.getStudents,
}

export default connect(mapStateToProps, actionCreators)(withRouter(UploadStudents));