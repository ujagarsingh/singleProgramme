import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accEntryRefActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class AllaccENtryRefs extends Component {
  state = {
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.accEntryRefs)) {
      this.props.readAccEntryRef();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const all_entryRef = this.props.accEntryRefs;
      if (all_entryRef && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const all_entryRef = this.props.accEntryRefs;
    if (!isEmpty(all_entryRef)) {
      const _sch_entryRefs = all_entryRef.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_entry_refs: _sch_entryRefs,
      })
    }
  }


  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  deleteHandlar(del_id) {
    const obj = { id: del_id }
    this.props.deleteAccEntryRef(obj);
  }
  render() {
    const { formIsHalfFilledOut, display_entry_refs } = this.state;
    const { user, accEntryRefs } = this.props;
    //console.log(_state);
    return (
      <div className="page-content">
        <Helmet>
          <title>All Entry Ref(s)</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">All Entry Ref(s)</div>
          <div className="form-inline ml-auto filter-panel">
            <span className="filter-closer">
              <button type="button" className="btn btn-danger filter-toggler-c">
                <i className="fa fa-times"></i>
              </button>
            </span>
            <div className="filter-con">
              <CommonFilters
                showSchoolFilter={true}
                showMediumFilter={false}
                // showClassFilter={true}
                filterBySchoolHandler={this.filterBySchoolHandler}
              // filterByClsHandler={this.filterByClsHandler}
              />
            </div>
          </div>
        </div>
        {user && accEntryRefs &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">

              <div className="table-scrollable">
                <table className="table table-striped table-bordered table-hover table-sm">
                  <thead>
                    <tr>
                      <th />
                      <th>ID</th>
                      <th>School ID</th>
                      <th>Entry Date</th>
                      <th>Entry Month</th>
                      <th>Entry Type</th>
                      <th>Session Year</th>
                      <th> Action </th>
                    </tr>
                  </thead>
                  {display_entry_refs &&
                    <tbody>
                      {display_entry_refs.map((item, index) => {
                        return (
                          <tr key={index} >
                            <td>{index + 1}</td>
                            <td className="left">{item.id}</td>
                            <td className="left">{item.sch_name}</td>
                            <td className="left">{item.entry_date}</td>
                            <td className="left">{item.entry_month}</td>
                            <td className="left">{item.entry_type}</td>
                            <td className="left">{item.session_year_id}</td>
                            <td className="d-flex">
                              {/* <NavLink to={`/edit_.jsp / ${item.id}`} className="btn btn-primary btn-sm mr-1">
                                                Edit</NavLink> */}
                              <button className="btn btn-primary btn-sm mr-1"
                                disabled={true}
                                type="button">
                                Edit
                                  </button>

                              <button className="btn btn-danger btn-sm"
                                value={item.id}
                                onClick={event => this.confirmBoxDelete(event, item.id)}>
                                Del</button>
                            </td>
                          </tr>
                        )
                      })
                      }
                    </tbody>
                  }
                </table>
              </div>
            </div>
          </div>
        }
        <div className="card-footer d-flex">
          <NavLink to={`/create_monthly_dues.jsp`}
            className="btn btn-primary btn-sm mr-1 ml-auto">
            Create Monthly Due</NavLink>
          <NavLink to={`/create_salary.jsp`}
            className="btn btn-primary btn-sm mr-1">
            Create Salary</NavLink>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: accEntryRefs } = state.accEntryRefs;
  return { user, accEntryRefs, filteredSchoolData, filteredClassesData };
}

const actionCreators = {
  readAccEntryRef: accEntryRefActions.readAccEntryRef,
  updateAccEntryRef: accEntryRefActions.update,
  deleteAccEntryRef: accEntryRefActions.delete,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllaccENtryRefs));