import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, feeDepositedAllAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/read.php`;
// const CREATE_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/create.php`;
// const GET_PRE_DEPOSIT_RECORD = `http://schools.rajpsp.com/api/fee_deposit/read_pre_deposit_months.php`;
// const READ_URL = `http://schools.rajpsp.com/api/school/read.php`;  

class FeesReceipt extends Component {
  state = {
    classes: [],
    final_deposit_fee_arr: [],
    id: "",
    sch_name: "",
    sch_reg_no: "",
    sch_recog_no: "",
    sch_contact_num: "",
    sch_mobile_num: "",
    sch_email: "",
    sch_address: "",
    sch_medium: "",
    sch_logo: "",
    sch_wel_mes_title: "",
    sch_wel_mes: '',
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.feeDepositedAll)) {
      this.props.getFeeDepositedAll();
    }
  }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getFeeDepositHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getFeeDepositHandler() {
  //   loadProgressBar();
  //   axios.get(GET_FEE_DEPOSIT)
  //     .then(res => {
  //       const deposited_arr = res.data;
  //       this.setState({
  //         final_deposit_fee_arr: deposited_arr,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.final_deposit_fee_arr);
  //     }).catch((error) => {
  //       // error
  //     })


  // };

  // getSchoolHandler() {
  //   axios.get(READ_URL)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         id: getRes.id,
  //         sch_name: getRes.sch_name,
  //         sch_reg_no: getRes.sch_reg_no,
  //         sch_recog_no: getRes.sch_recog_no,
  //         sch_contact_num: getRes.sch_contact_num,
  //         sch_mobile_num: getRes.sch_mobile_num,
  //         sch_email: getRes.sch_email,
  //         sch_address: getRes.sch_address,
  //         sch_medium: getRes.sch_medium,
  //         sch_logo: getRes.sch_logo,
  //         sch_wel_mes_title: getRes.sch_wel_mes_title,
  //         sch_wel_mes: getRes.sch_wel_mes,
  //         errorMessages: getRes.message
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  nuberInWords = (price) => {
    var sglDigit = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"],
      dblDigit = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"],
      tensPlace = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"],
      handle_tens = function (dgt, prevDgt) {
        return 0 === dgt ? "" : " " + (1 === dgt ? dblDigit[prevDgt] : tensPlace[dgt])
      },
      handle_utlc = function (dgt, nxtDgt, denom) {
        return (0 !== dgt && 1 !== nxtDgt ? " " + sglDigit[dgt] : "") + (0 !== nxtDgt || dgt > 0 ? " " + denom : "")
      };

    var str = "",
      digitIdx = 0,
      digit = 0,
      nxtDigit = 0,
      words = [];
    if (price += "", isNaN(parseInt(price))) str = "";
    else if (parseInt(price) > 0 && price.length <= 10) {
      for (digitIdx = price.length - 1; digitIdx >= 0; digitIdx--)
        switch (digit = price[digitIdx] - 0, nxtDigit = digitIdx > 0 ? price[digitIdx - 1] - 0 : 0, price.length - digitIdx - 1) {
          case 0:
            words.push(handle_utlc(digit, nxtDigit, ""));
            break;
          case 1:
            words.push(handle_tens(digit, price[digitIdx + 1]));
            break;
          case 2:
            words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] && 0 !== price[digitIdx + 2] ? " and" : "") : "");
            break;
          case 3:
            words.push(handle_utlc(digit, nxtDigit, "Thousand"));
            break;
          case 4:
            words.push(handle_tens(digit, price[digitIdx + 1]));
            break;
          case 5:
            words.push(handle_utlc(digit, nxtDigit, "Lakh"));
            break;
          case 6:
            words.push(handle_tens(digit, price[digitIdx + 1]));
            break;
          case 7:
            words.push(handle_utlc(digit, nxtDigit, "Crore"));
            break;
          case 8:
            words.push(handle_tens(digit, price[digitIdx + 1]));
            break;
          case 9:
            words.push(0 !== digit ? " " + sglDigit[digit] + " Hundred" + (0 !== price[digitIdx + 1] || 0 !== price[digitIdx + 2] ? " and" : " Crore") : "");
            break;
          default:
          // this is default case.
        }
      str = words.reverse().join("")
    } else str = "";
    return str

  }

  printThisReceipt = () => {
    // window.print();
  }
  render() {
    const { formIsHalfFilledOut,  sch_name, sch_address } = this.state;
    const { user, schools, feeDepositedAll } = this.props;
    //console.log(_state)
    return (
      <div className="page-content">
        <Helmet>
          <title>Fee Receipt</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
          <div className="page-title">Student Invoice</div>
        </div>
        <div className="card card-box sfpage-cover">
          <div className="card-body sfpage-body">
            {feeDepositedAll &&
              <div className="table-scrollable">
                {feeDepositedAll.map((invoice, index) => {
                  return (
                    <div className="card-body" key={index}>
                      <div className="row">
                        <div className="col-sm-5 pr-3">

                          <h5 className="pb-2 d-flex">
                            <span className="mr-auto">#{invoice.id}</span>
                            <span className="ml-auto"><i className="fa fa-calendar" /> {invoice.deposit_date}</span>
                          </h5>
                          <hr className="mb-2 mt-2" />
                          <div className="row">
                            <div className="col-md-12">
                              <div className="text-center">
                                <address className="school_address">
                                  <h3 className="m-0 p-0">
                                    <b>{sch_name}</b>
                                  </h3>
                                  <p className="text-muted">{sch_address}</p>
                                </address>
                              </div>
                              <address>
                                <p className="d-flex"><span className="text-muted">To,</span>
                                  <b>{invoice.student_name}</b> <span className="text-muted">{invoice.address}</span>
                                  <span className="ml-auto">Class : {invoice.student_class}</span>
                                </p>
                              </address>
                            </div>
                            <div className="col-md-12">
                              <div className="table-responsive m-t-40">
                                <table className="table table-hover table-bordered table-sm">
                                  <thead>
                                    <tr className="table-secondary">
                                      <th className="text-center">#</th>
                                      <th className="text-right">Invoice id</th>
                                      <th className="text-right">Fees Type</th>
                                      <th className="text-right">Month of fee</th>
                                      <th className="text-right">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {invoice.xsd.map((in_detail, index) => {
                                      return (
                                        <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-right">{in_detail.id}</td>
                                          <td className="text-right">{in_detail.fee_title}</td>
                                          <td className="text-right">{in_detail.month_of_fee}</td>
                                          <td className="text-right">{in_detail.fee_amount}</td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            <div className="col-md-12">
                              <h6 className="p-0 d-flex">
                                <i>{this.nuberInWords(invoice.total_amount)}</i>
                                <span className="ml-auto"><b>Total :</b> {invoice.total_amount}</span>
                              </h6>
                            </div>
                          </div>
                        </div>
                        <div className="col-sm-7 pl-3">
                          <h5 className="pb-2 d-flex">
                            <span className="mr-auto"><b className="mr-3">INVOICE</b> #{invoice.id}</span>
                            <span className="ml-auto"><b>Invoice Date :</b> <i className="fa fa-calendar" /> {invoice.deposit_date}</span>
                          </h5>
                          <hr className="mb-2 mt-2" />
                          <div className="row">
                            <div className="col-md-12">
                              <div className="text-center">
                                <address className="school_address">
                                  <h3 className="m-0 p-0">
                                    <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/invoice_logo.png`} className="logo-default" />
                                    <b>{sch_name}</b>
                                  </h3>
                                  <p className="text-muted">{sch_address}</p>
                                </address>
                              </div>
                              <address>
                                <p className="d-flex mb-1 pb-1"><span className="text-muted">To,</span>
                                  <b>{invoice.student_name}</b> <span className="text-muted">{invoice.address}</span>
                                  <span className="ml-auto">Class : {invoice.student_class}</span>
                                </p>
                              </address>
                            </div>
                            <div className="col-md-12">
                              <div className="table-responsive m-t-40">
                                <table className="table table-hover table-bordered table-sm">
                                  <thead>
                                    <tr className="table-secondary">
                                      <th className="text-center">#</th>
                                      <th className="text-right">Invoice id</th>
                                      <th className="text-right">Fees Type</th>
                                      <th className="text-right">Month of Fee</th>
                                      <th className="text-right">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {invoice.xsd.map((in_detail, index) => {
                                      return (
                                        <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="text-right">{in_detail.id}</td>
                                          <td className="text-right">{in_detail.fee_title}</td>
                                          <td className="text-right">{in_detail.month_of_fee}</td>
                                          <td className="text-right">{in_detail.fee_amount}</td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            <div className="col-md-12">
                              <h6 className="p-0 d-flex">
                                <i>{this.nuberInWords(invoice.total_amount)} only.</i>
                                <span className="ml-auto"><b>Total :</b> Rs. {invoice.total_amount}</span>
                              </h6>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                }
                )}
              </div>
            }
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: feeDepositedAll } = state.feeDepositedAll;
  return { user, schools, feeDepositedAll };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getFeeDepositedAll: feeDepositedAllAction.getFeeDepositedAll,
}

export default connect(mapStateToProps, actionCreators)(withRouter(FeesReceipt));
