import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert';
import Alert from 'react-s-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, professionalAction, accVoucherEntryActions, accLedgerActions } from '../_actions';
import DatePicker from 'react-date-picker';
import ImageLoader from "../utility/ImageLoader/index";
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class CreateSalary extends Component {
  state = {
    fee_months_arr: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    due_date: new Date(),
    professional: [],
    filtered_prof: [],
    selected_month: '',
    update_prof: [],
    schools_arr: [],
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    medium: '',
    used_ledger_arr: [],
    effected_ledger: '',
    effected_ledger_inx: '',
    formIsHalfFilledOut: false,
  }

  changeHandler = (event, fieldName, indexValue) => {
    // debugger
    if (fieldName === 'monthSalary') {
      const salary = event.target.value;
      let prop = this.state.filtered_prof;
      const new_prof = prop.map((item, idx) => {
        if (idx === indexValue) {
          item.salary = salary;
          item.narration = this.state.fee_months_arr[this.state.selected_month] + " month salary is [ " + salary + " ] Rs.";
        }
        return item
      })
      this.setState({
        filtered_prof: new_prof
      })
    }
    else if (fieldName === 'narration') {
      const narration = event.target.value;
      let prop = this.state.filtered_prof;
      const new_prof = prop.map((item, idx) => {
        if (idx === indexValue) {
          item.narration = narration
        }
        return item
      })
      this.setState({
        filtered_prof: new_prof
      })
    }
    else if (fieldName === 'slct_ledger') {
      const inx_val = event.target.value;
      let ledgers = this.state.used_ledger_arr;
      const effected_ldr = ledgers.filter((item, idx) => {
        if (idx === Number(inx_val)) {
          return item
        }
      })
      this.setState({
        effected_ledger: effected_ldr,
        effected_ledger_inx: inx_val
      }, () => {
        this.setEffectedLedgerWithProfHandler();
      })
    }
    else if (fieldName === 'selected_month') {
      const _select_month = !isEmpty(event.target.value) ? (parseInt(event.target.value) + 1) : '';
      this.setState({
        selected_month: _select_month,
      }, () => {
        this.getEffectedLedgerHandler();
      })
    }
    else {
      this.setState({
        [fieldName]: indexValue ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      });
    }
  };

  checkHandler = (event, fieldName, value) => {
    debugger;
    let _display_prof = null;
    if (fieldName === 'select_this') {
      let _current_select = JSON.parse(value).s_id;
      _display_prof = this.state.filtered_prof.map((checked_prof) => {
        if (_current_select === checked_prof.s_id) {
          if (checked_prof['salary'] && checked_prof['salary'] > 0) {
            checked_prof['is_checked'] = (event.target.checked) ? true : false;
          } else {
            checked_prof['is_checked'] = false;
          }
        }
        return checked_prof;
      })
    } else if (fieldName === 'select_all') {
      _display_prof = this.state.filtered_prof.map((checked_prof) => {
        if (checked_prof['salary'] && checked_prof['salary'] > 0) {
          checked_prof['is_checked'] = (event.target.checked) ? true : false;
        } else {
          checked_prof['is_checked'] = false;
        }
        return checked_prof;
      })
    }
    let _update_prof = _display_prof.filter((checked_prof) => {
      return checked_prof['is_checked'] === true
    })
    this.setState({
      filtered_prof: _display_prof,
      selected_prof: _update_prof,
    }, () => { this.generateFeeDueObjectHandler() })
  };

  setEffectedLedgerWithProfHandler() {
    const _efl = this.state.effected_ledger;
    const _flp = this.state.filtered_prof;
    const new_flp = _flp.map(e => e = { ...e, effected_ledger: _efl })
    this.setState({
      filtered_prof : new_flp
    })
  }

  getEffectedLedgerHandler() {
    const _ldr = this.props.accLedger;
    const _ldr_list = _ldr.filter(e => e.under_group === "1" && e.ledger_type === "S" && e.group_type === "P");
    this.setState({
      used_ledger_arr: _ldr_list
    })
  }

  generateFeeDueObjectHandler() {
    const _selected_prof = this.state.selected_prof;
    const updated_proff = _selected_prof.map((item) => {
      const _item = {
        "id": item.id,
        "s_id": item.s_id,
        "emp_name": item.emp_name,
        "emp_f_name": item.emp_f_name,
        "class_teacher": item.class_teacher,
        "address": item.address,
        "gender": item.gender,
        "salary": item.salary,
        "is_checked": item.is_checked,
        "narration": item.narration,
        "effected_ledger": item.effected_ledger,
        /*
          "profile_image": item.profile_image,
          "aadhar_no" : item.aadhar_no,
          "appoint_date" : item.appoint_date,
          "caste" : item.caste,
          "class_sub_ids" : item.class_sub_ids,
          "dob" : item.dob,
          "edu_qulifi" : item.edu_qulifi,
          "emp_crnt_designation" : item.emp_crnt_designation,
          "emp_cur_sub" : item.emp_cur_sub,
          "emp_mob" : item.emp_mob,
          "emp_type" : item.emp_type,
          "group_id" : item.group_id,
          "is_rtet_qlifid" : item.is_rtet_qlifid,
          "medium" : item.medium,
          "pacific_ability" : item.pacific_ability,
          "responsibility" : item.responsibility,
          "salary" : item.salary,
          "school_id" : item.school_id,
          "sec_roll_no" : item.sec_roll_no,
          "sec_year" : item.sec_year,
          "show_home" : item.show_home,
          "subject_ids" : item.subject_ids,*/
      }
      return _item
    });

    const _due_obj = {
      action: 'journal_month_salary_entry',
      due_entry_obj: updated_proff,
      transaction_date: this.state.due_date,
      entry_month: this.state.selected_month,
    }
    this.setState({
      dueDetailsEntryObj: _due_obj
    });

  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_proffessional = this.props.professional;
      if (_all_proffessional && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_proffessional = this.props.professional;

    if (!isEmpty(_all_proffessional)) {
      const _school_proffessional = _all_proffessional.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item = {
              ...item,
              "salary": "",
              "is_checked": false,
              "narration": "",
            }
          }
        }
      })

      this.setState({
        filtered_prof: _school_proffessional
      })
    }
  }
  /*
  action: "journal_due_entry"
  due_entry_obj: (7) [{…}, {…}, {…}, {…}, {…}, {…}, {…}]
  entry_month: 4
  transaction_date:
  */

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Update these.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.createHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  createHandler = () => {
    const _obj = this.state.dueDetailsEntryObj;

    if (!isEmptyObj(_obj)) {
      // console.log(JSON.stringify(_obj));
      this.props.createAccSalaryVoucherEntry(_obj);
    } else {
      Alert.error('Please Select Professional(s), Date and Month of Salary !!', {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
  }

  render() {
    const { filtered_prof, due_date, formIsHalfFilledOut, effected_ledger_inx,
      selected_month, fee_months_arr, used_ledger_arr } = this.state;
    const { user, schools, professional, accLedger } = this.props;
    console.log(this.state);
    return (
      <div className="page-content" >
        <Helmet>
          <title>Professional List</title>
        </Helmet> <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && professional && filtered_prof && accLedger &&
          <div className="page-bar d-flex">
            <div className="page-title">Professional List</div>
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={false}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Month : </label>
                  <select
                    // disabled={!isEmpty(filteredClassesData.slct_cls_id) ? false : true}
                    value={selected_month - 1}
                    className="form-control form-control-sm " name="selected_month"
                    onChange={event => this.changeHandler(event, 'selected_month')}>
                    <option value="">Select...</option>
                    {fee_months_arr.map((opt, index) => {
                      return (<option key={index} value={index}>{opt}</option>)
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Effected Ledger : </label>
                  <select
                    // disabled={!isEmpty(filteredClassesData.slct_cls_id) ? false : true}
                    value={effected_ledger_inx}
                    disabled={(!isEmpty(selected_month)) ? false : true}
                    className="form-control form-control-sm " name="slct_ledger"
                    onChange={event => this.changeHandler(event, 'slct_ledger')}>
                    <option value="">Select...</option>
                    {used_ledger_arr.map((opt, index) => {
                      return (<option key={index} value={index}>{opt.ledger_name}</option>)
                    })}
                  </select>
                </div>
              </div>
            </div>
          </div>
        }
        {user && schools && professional && filtered_prof &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">
              <div className="form-inline">
                <div className="form-group ml-auto mb-2">
                  <label className="control-label mr-2">Select Date<span className="required"> * </span>
                  </label>
                  <div className="form-input">
                    <DatePicker
                      onChange={this.startDateHandler}
                      value={due_date}
                      showLeadingZeroes={true}
                      maxDate={new Date()}
                    />
                  </div>
                </div>
              </div>
              {filtered_prof.length > 0 ?
                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm m-0">
                    <thead>
                      <tr>
                        <th />
                        <th>
                          <div className="custom-control custom-checkbox">
                            <input type="checkbox"
                              disabled={(!isEmpty(effected_ledger_inx)) ? false : true}
                              id="select_all" className="custom-control-input"
                              onChange={event => this.checkHandler(event, 'select_all', true)} />
                            <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                          </div>
                        </th>
                        <th></th>
                        <th>General Information</th>
                        <th>Class Teacher</th>
                        <th>Month Salary</th>
                        <th>Remark/ Narration</th>
                      </tr>
                    </thead>
                    {filtered_prof.length > 0 ?
                      <tbody>
                        {filtered_prof.map((item, index) => {
                          return (
                            <tr key={index}>
                              <td>{index + 1}</td>
                              <td className="text-center">
                                <div className="custom-control custom-control-inline custom-checkbox">
                                  <input type="checkbox"
                                    checked={item.is_checked}
                                    disabled={(!isEmpty(effected_ledger_inx)) ? false : true}
                                    id={`check_` + index} name="customRadio" className="custom-control-input"
                                    onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
                                  <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                                </div>
                              </td>
                              <td className="profile-pic">
                                <NavLink to={`/edit_professional.jsp/${item.id}`} className="">
                                  {!isEmpty(item.profile_image) ?
                                    <ImageLoader
                                      src={`${process.env.PUBLIC_URL}` + item.profile_image}
                                      alt={item.emp_name}
                                      className="img-circle user-img-circle"
                                      fallbackSrc={`${process.env.PUBLIC_URL}/assets/images/dp.jpg`}
                                    />
                                    // < img src={`${process.env.PUBLIC_URL}` + item.profile_image} alt={item.emp_name} />
                                    : (item.gender === 'Male' ?
                                      <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} />
                                      :
                                      <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_female.jpg`} />)
                                  }
                                </NavLink>
                              </td>
                              <td><NavLink to={`professional_profile.jsp/${item.id}`} className="">
                                {item.emp_name}
                              </NavLink> S/o <br />
                                {item.emp_f_name}<br />
                                {item.address}
                              </td>
                              <td>{item.class_teacher}</td>
                              <td><input type="number"
                                disabled={(!isEmpty(effected_ledger_inx)) ? false : true}
                                onChange={event => this.changeHandler(event, 'monthSalary', index)}
                                value={item.salary}
                                onKeyDown={e => (e.which === 69 || e.which === 190) && e.preventDefault()}
                                className="form-control form-control-sm" /></td>
                              <td><textarea
                                value={item.narration}
                                disabled={(!isEmpty(effected_ledger_inx)) ? false : true}
                                onChange={event => this.changeHandler(event, 'narration', index)}
                                className="form-control form-control-sm">
                              </textarea></td>
                            </tr>
                          )
                        })
                        }
                      </tbody>
                      : null}
                  </table>
                </div>
                : null}
            </div>
            <div className="card-footer text-right">
              <button type="button"
                onClick={event => this.confirmBoxSubmit(event)}
                className="btn btn-primary btn-sm mr-2">Create</button>
            </div>
          </div>
        }
      </div >
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: professional } = state.professional;
  const { item: accLedger } = state.accLedger;
  const filteredSchoolData = state.filteredSchoolData;
  return { user, schools, professional, filteredSchoolData, accLedger };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getProfessional: professionalAction.getProfessional,
  createAccSalaryVoucherEntry: accVoucherEntryActions.createAccSalaryVoucherEntry,
  getAccLedger: accLedgerActions.getAccLedger,
}

export default connect(mapStateToProps, actionCreators)(withRouter(CreateSalary));
