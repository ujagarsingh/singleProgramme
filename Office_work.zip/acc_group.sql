-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 04:59 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_group`
--

CREATE TABLE `acc_group` (
  `id` int(10) NOT NULL,
  `parent_id` int(5) DEFAULT NULL COMMENT 'Parent Group Id',
  `group_code` int(4) NOT NULL,
  `school_id` int(5) DEFAULT NULL,
  `group_name` varchar(50) DEFAULT NULL,
  `group_type` varchar(1) NOT NULL DEFAULT 'S' COMMENT 'PreDefine > P, UserDefine > S',
  `op_balance` int(15) DEFAULT NULL COMMENT 'Opening Balance',
  `op_balance_type` varchar(2) DEFAULT NULL COMMENT 'CR/DR',
  `crnt_balance` int(15) DEFAULT NULL COMMENT 'Current Balance',
  `crnt_balance_type` varchar(2) DEFAULT NULL COMMENT 'CR/DR',
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `acc_group`
--

INSERT INTO `acc_group` (`id`, `parent_id`, `group_code`, `school_id`, `group_name`, `group_type`, `op_balance`, `op_balance_type`, `crnt_balance`, `crnt_balance_type`, `server_date_time`) VALUES
(1, NULL, 1001, NULL, 'Indirect Expenses', 'P', 0, '', 0, NULL, '2020-09-15 22:26:56'),
(2, NULL, 1002, NULL, 'Indirect Income', 'P', 0, '', 0, NULL, '2020-09-16 01:13:33'),
(3, NULL, 1003, NULL, 'Sundry Debtors', 'P', 0, '', 0, NULL, '2020-09-15 22:26:56'),
(4, NULL, 1004, NULL, 'Sundry Creditors', 'P', 0, '', 0, NULL, '2020-09-15 22:45:18'),
(5, NULL, 1005, NULL, 'Cash in Hand', 'P', 0, '', 0, NULL, '2020-09-16 01:43:33'),
(6, NULL, 1006, NULL, 'Bank Accounts', 'P', 0, '', 0, NULL, '2020-09-16 01:43:33'),
(7, NULL, 1007, NULL, 'Salary', 'P', 25000, '', 25000, NULL, '2020-09-19 02:20:27'),
(25, 1, 1001, 4, 'Fuel Expenses', 'S', 0, NULL, 0, NULL, '2020-09-19 10:46:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_group`
--
ALTER TABLE `acc_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `acc_group_ibfk_2` (`parent_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_group`
--
ALTER TABLE `acc_group`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_group`
--
ALTER TABLE `acc_group`
  ADD CONSTRAINT `acc_group_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school_info` (`id`),
  ADD CONSTRAINT `acc_group_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `acc_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
