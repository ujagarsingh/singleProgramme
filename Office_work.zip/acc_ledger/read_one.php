<?php
// http://localhost/schooloffice/api/acc_ledger/read_one.php?id=2
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
// include database and object files
include_once '../database.php';
include_once '../objects/acc_ledger.php';

// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccLedger($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
 
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      $stmt = $Item->readOne();
      $num = $stmt->rowCount();

      // check if more than 0 record found
      if ($num > 0) {
		$ledger_info = array();
        while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
            extract($row);
         
            
            $ledger_info['id'] = $row['id'];  
            $ledger_info['school_id'] = $row['school_id'];  
			$ledger_info['acc_group_id'] = $row['acc_group_id'];
			$ledger_info['group_code'] = $row['group_code'];
			$ledger_info['group_name'] = $row['group_name'];    
            $ledger_info['school_name'] = $row['sch_name'];  
            $ledger_info['ledger_name'] = $row['ledger_name'];  
            $ledger_info['ledger_type'] = $row['ledger_type'];  
			$ledger_info['op_balance'] = $row['op_balance'];  
			$ledger_info['op_balance_type'] = $row['op_balance_type'];  
            $ledger_info['crnt_balance'] = $row['crnt_balance'];  
            $ledger_info['crnt_balance_type'] = $row['crnt_balance_type'];  
			$ledger_info['server_date_time'] = $row['server_date_time'];  
            
         }
         // echo json_encode($ledger_info);
		 http_response_code(200); 
		 echo json_encode(array(
			 "message" => "Access granted.",
			 "income_arr" => $ledger_info
		 ));
      }
		/* get data end */
		
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}


?>