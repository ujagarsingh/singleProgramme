import { defaultProfessionalConstants } from '../_constants';
import { defaultProfessionalService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultProfessionalActions = {
    getDefaultProfessional
};

function getDefaultProfessional() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultProfessionalService.getDefaultProfessional()
            .then(
                response => {
                    dispatch(success(response.data.prof_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: defaultProfessionalConstants.PROFESSIONAL_REQUEST } }
    function success(response) { return { type: defaultProfessionalConstants.PROFESSIONAL_SUCCESS, response } }
    function failure(error) { return { type: defaultProfessionalConstants.PROFESSIONAL_FAILURE, error } }
}
 