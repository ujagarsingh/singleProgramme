// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const examCategoryClassExamService = {
    getExamCategoryClassExam
};

function getExamCategoryClassExam() {
    loadProgressBar();
    // const url = USER_URL + 'exam/fee_category_structure.php';
    // const url = USER_URL + 'fee_category/fee_category_structure.php';
    const url = USER_URL + 'exam/exam_category_class_exam.php';
    return Axios.post(url, authHeader()).then()
}
