// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const examSdulService = {
    getExamSdul,
    create,
    delete : _delete
};

function getExamSdul() {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'exam_sdul/delete.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
