// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const groupService = {
    getGroup
};

function getGroup() {
    loadProgressBar();
    const url = USER_URL + 'group/read_one.php';
    return Axios.post(url, authHeader()).then()
}
