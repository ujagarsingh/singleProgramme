import React, { Component } from "react";

class ReportLeaderboard extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <div className="card-body">
														<h5 className="card-title">Leaderboard</h5>
														<ul className="list-unstyled">
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Rahul Sharma</h5>
																	<p>Marks 45/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Sandeep Gupta</h5>
																	<p>Marks 75/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Prashant Khandelwal</h5>
																	<p>Marks 87/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Manohar Lal Rana</h5>
																	<p>Marks 63/100</p>
																</div>
															</li>
															<li className="media">
																<img className="mr-3 rounded-circle"
																	src="https://placeimg.com/50/50/people" alt="Generic placeholder" />
																<div className="media-body">
																	<h5 className="mt-0 mb-1">Kamal Kishore</h5>
																	<p>Marks 30/100</p>
																</div>
															</li>
														</ul>
													</div>
																												   
    );
  }
}

export default ReportLeaderboard;
