import React, { Component } from "react";

class AnsweredPanel extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <div className="answered-panel">
            <div className="title-test">Test Title Here...</div>
            <div className="list-queation">
                <button type="button" className="btn btn-answered">1</button>
                <button type="button" className="btn btn-active">2</button>
                <button type="button" className="btn btn-review-later">3</button>
                <button type="button" className="btn btn-ans-rev-leter">4</button>
                <button type="button" className="btn btn-not-answered ">5</button>
                <button type="button" className="btn btn-not-visited">6</button>
                <button type="button" className="btn btn-not-visited">7</button>
                <button type="button" className="btn btn-not-visited">8</button>
                <button type="button" className="btn btn-not-visited">9</button>
                <button type="button" className="btn btn-not-visited">10</button>
                <button type="button" className="btn btn-not-visited">11</button>
                <button type="button" className="btn btn-not-visited">12</button>
                <button type="button" className="btn btn-not-visited">13</button>
                <button type="button" className="btn btn-not-visited">14</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
                <button type="button" className="btn btn-not-visited">15</button>
            </div>
        </div>
								   
    );
  }
}

export default AnsweredPanel;
