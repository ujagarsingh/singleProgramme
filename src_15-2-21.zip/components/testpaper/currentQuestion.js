import React, { Component } from "react";

class CurrentQuestion extends Component {
  constructor() {
    super();

  };

    
  componentDidMount(){
  }

  render() {
    return (
     <div className="card-body  p-0">
        <div className="d-flex question-info p-2 mb-1">
            <h5 className="card-title ml-2 m-0">Question 1</h5>
            <div className="ml-auto d-flex">
                <div className="question-time d-flex p-2">
                    <label className="label-header">
                        Time :</label>
                    <div className="show-time">
                        25:10</div>
                </div>
                <div className="obtain-marks d-flex  p-2">
                    <label className="label-header">
                        Marks:</label>
                    <div className="get-marks text-success"> +20</div>
                    <div className="loss-marks text-danger"> -10</div>
                </div>
            </div>
        </div>
        <div className="p-3">
            <div className="question-text">What Is the full name of CORONA-19?</div>
            <div className="form-group answer-options">
                <div className="custom-control custom-radio">
                    <input type="radio" id="ansRadio1" name="ansRadio" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="ansRadio1">Answer Option One</label>
                </div>
                <div className="custom-control custom-radio">
                    <input type="radio" id="ansRadio2" name="ansRadio" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="ansRadio2">Answer Option Two</label>
                </div>
                <div className="custom-control custom-radio">
                    <input type="radio" id="ansRadio3" name="ansRadio" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="ansRadio3">Answer Option Three</label>
                </div>
                <div className="custom-control custom-radio">
                    <input type="radio" id="ansRadio4" name="ansRadio" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="ansRadio4">Answer Option Four</label>
                </div>
                <div className="custom-control custom-radio">
                    <input type="radio" id="ansRadio4" name="ansRadio" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="ansRadio4">Answer Option Five</label>
                </div>
            </div>
        </div>
    </div>
        
    );
  }
}

export default CurrentQuestion;
