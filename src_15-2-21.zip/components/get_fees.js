import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';
import FeeField from './fee_field';
import { connect } from 'react-redux';
import {
  studentsAction, schoolsAction, conveyanceAction, classesAction,
  feeCategoryStructureAction, feeDepositedAllAction,
  feeWithCategoryAction, feeDepositedCurrentStudentAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_FEE_CATEGORY = `http://schools.rajpsp.com/api/fee_category/fee_category_structure.php`;
// const GET_CLASSES = `http://schools.rajpsp.com/api/classes/read.php`;
// const GET_STUDENTS = `http://schools.rajpsp.com/api/students/read.php`;
// const GET_STUDENTS_BY_CLASS = `http://schools.rajpsp.com/api/students/read_students_by_class.php`;
// const GET_STUDENT = `http://schools.rajpsp.com/api/students/read_one.php`;
// const GET_CLASS_FEE = `http://schools.rajpsp.com/api/fee_amount/read_class_fee.php`; 
// const GET_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/read.php`;
// const CREATE_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/create.php`;
const VERIFY_FEE_DEPOSIT = `http://schools.rajpsp.com/api/fee_deposit/verify.php`;
// const GET_PRE_DEPOSIT_RECORD = `http://schools.rajpsp.com/api/fee_deposit/read_pre_deposit_months.php`;
// const READ_CONVENCE = `http://schools.rajpsp.com/api/conveyance/read.php`;
const DELETE_URL = `http://schools.rajpsp.com/api/fee_deposit/delete.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;

class GetFees extends Component {
  state = {
    school_id: '',
    selected_school_index: '',
    medium_arr: [],
    medium: '',
    depo_fee_students: [],
    deposit_fee_arr: [],
    classes: [],
    selected_classes: [],
    conveyances: [],
    selected_class_id: '',
    selected_class_inx: '',
    class_students: [],
    selected_student_id: '',
    selected_student: '',
    selected_student_info: '',
    pre_fee_deposit_arr: {},
    fee_category: [],
    temp_fee_record: [],
    class_fee_arr: [],
    class_fee_Has: false,
    isUpdate: false,
    final_deposit_fee_arr: [],
    varified_deposit_fee_arr: [],
    monthly_fee_amo: 0, // from database
    convence_fee_amo: 0, // from database
    exam_fee_amo: 0, // from database
    reg_fee_amo: 0, // from database
    sports_fee_amo: 0, // from database
    total_amount: 0,
    total_discount: 0,
    ground_total: 0,
    total_monthly_amount: 0,
    total_convence_amount: 0,
    total_monthly_discount: 0,
    total_convence_discount: 0,
    monthly_discount: 0, // in percentage
    convence_discount: 0, // in percengage
    fee_amount: 0,
    current_depo_amount: 0,
    balance_amount: 0,
    current_date: '2019-10-20',
    fee_date: new Date(),
    set_monthly_fee_amo: 0,
    set_convence_fee_amo: 0,
    set_exam_fee_amo: 0,
    set_reg_fee_amo: 0,
    set_sports_fee_amo: 0,
    reg_fee: false,
    sports_fee: false,
    exam_fee: false,
    seat_type: '',
    description: '',
    formIsHalfFilledOut: false,
  }
  commonFeeHandler = (obj) => {
    debugger;
    let _discount = ((obj.name === 'Monthly') ? this.state.selected_student_info.monthly_discount :
      (obj.name === 'Convence') ? this.state.selected_student_info.convence_discount : null);
    let _name = obj.name;
    let _length = obj.values.length;
    let _values = obj.values.toString();
    const _temp_fee_cat = this.state.temp_fee_record.map((item) => {
      const _amo = item.fee_amount;
      const _item = item;
      if (item.cat_name === _name) {
        _item.curn_depo_mts = _values;
        _item.curn_depo_amo = _length * _amo;
        _item.discount = (_discount) ? (_length * _amo * (_discount / 100)) : 0;
      }
      return _item;
    })
    //    console.log(JSON.stringify(_temp_fee_cat))
    this.setState({
      temp_fee_record: _temp_fee_cat
    }, () => {
      this.calcFee();
      this.depositFeeRecord(); // for submit fee_array_records
    })
  }

  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      // this.getUnvarifiedRecord();
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: '',
      })
    } else if (fieldName === 'selected_class') {
      const _class_inx = event.target.value;
      const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
      sessionStorage.setItem("class_name_portal", _class_name);
      this.getSectedClassHandler(_class_inx);
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      //this.filterClassesOnSchool(_medium);
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      });
    }
  };
  filterClassesOnSchool(sch_id, group_id) {
    const _classes = this.props.classes.filter((item) => {
      if (item.group_id === group_id && item.school_id === sch_id) {
        return item
      }
      return false
    })
    this.setState({
      selected_classes: _classes,
      selected_class_inx: 'All'
    })
  }

  checkHandler = (event, fieldName, id) => {
    let _final_deposit_fee_arr = null;
    let _id = id;
    if (fieldName === 'select_this') {
      _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
        if (_id === item.id) {
          item['isChecked'] = !item.isChecked;
          return item;
        }
        return item;
      })
      this.setState({
        final_deposit_fee_arr: _final_deposit_fee_arr
      })
    } else if (fieldName === 'select_all') {
      _final_deposit_fee_arr = this.state.final_deposit_fee_arr.map((item) => {
        item['isChecked'] = (event.target.checked) ? true : false;
        return item;
      })
      this.setState({
        final_deposit_fee_arr: _final_deposit_fee_arr
      })
    }
  };

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }

    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.conveyance)) {
      this.props.getConveyance();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    if (isEmptyObj(this.props.feeWithCategory)) {
      this.props.getFeeWithCategory();
    }
    if (isEmptyObj(this.props.feeDepositedAll)) {
      this.props.getFeeDepositedAll();
    }

    // this.filterClasses(this.props.classes)
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.feeDetailed;
      const _feeWithCategory = this.props.feeWithCategory;
      if (_all_student && _filter && _feeWithCategory) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  // const deposited_arr = this.props.feeDepositedAll;
  // const _deposited_arr = deposited_arr.map((item) => {
  //   item = { ...item, isChecked: false };
  //   //_item.isChecked = false;
  //   return item
  // })
  // this.setState({
  //   final_deposit_fee_arr: _deposited_arr
  // });

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.feeDepositedAll;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        final_deposit_fee_arr: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.feeDepositedAll;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      this.setState({
        final_deposit_fee_arr: _school_student,
        class_students: []
      }, () => {
        this.getSectedClassHandler()
      })
    }
  }


  componentWillReceiveProps(nextProps) {
    //  debugger;
    if (nextProps.feeDepositedCurrentStudent) {
      const resData = nextProps.feeDepositedCurrentStudent;
      // console.log(resData);
      this.setState({
        pre_fee_deposit_arr: resData
      }, () => {
        this.updatePreFeeRecord();
      })
    }

  }

  // filterClasses(getRes) {
  //   this.setState({
  //     selected_classes: getRes
  //   });
  // }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getSchoolHandler();
  //           this.getConvenceHandler();
  //           this.getClassesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getSchoolHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.props.user.group_id
  //   }
  //   axios.post(READ_SCHOOLS, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         schools: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //// console.log(this.props.classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getClassesHandler() {
  //   loadProgressBar();
  //   const obj = {
  //     group_id: this.props.user.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // console.log(JSON.stringify(obj));
  //   // debugger
  //   axios.post(GET_CLASSES, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       this.setState({
  //         selected_classes: getRes,
  //         classes: getRes,
  //         errorMessages: getRes.message
  //       });
  //       //// console.log(this.state.selected_classes);
  //     }).catch((error) => {
  //       // error
  //     })
  // }
  // getConvenceHandler() {
  //   loadProgressBar();
  //   axios.get(READ_CONVENCE)
  //     .then(res => {
  //       const conveyances = res.data;
  //       this.setState({
  //         conveyances: conveyances,
  //         errorMessages: res.data.message
  //       });
  //     }).catch((error) => {
  //       // error
  //     })
  //   this.getUnvarifiedRecord();
  // };

  // getUnvarifiedRecord = () => {
  //   const deposited_arr = this.props.feeDepositedAll;
  //   const _deposited_arr = deposited_arr.map((item) => {
  //     item = { ...item, isChecked: false };
  //     //_item.isChecked = false;
  //     return item
  //   })
  //   this.setState({
  //     final_deposit_fee_arr: _deposited_arr
  //   });

  //   // loadProgressBar();
  //   // axios.get(GET_FEE_DEPOSIT)
  //   //   .then(res => {
  //   //     const deposited_arr = res.data;
  //   //     const _deposited_arr = deposited_arr.map((item) => {
  //   //       const _item = item;
  //   //       _item.isChecked = false;
  //   //       return _item
  //   //     })
  //   //     this.setState({
  //   //       final_deposit_fee_arr: _deposited_arr,
  //   //       errorMessages: res.data.message
  //   //     });
  //   //     // console.log(this.state.selected_classes);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })
  // }

  feeDepositDate = (feeDate) => {
    this.setState({ fee_date: feeDate });
    //this.to.openCalendar();
  };

  selectStudentNameHandlar = (event) => {
    debugger
    event.preventDefault();
    const student_id = JSON.parse(event.target.value).se_id;
    this.setState({
      selected_student: JSON.parse(event.target.value).student_name,
      selected_student_id: JSON.parse(event.target.value).se_id,
      seat_type: JSON.parse(event.target.value).free_seat,
      description: '',
      pre_fee_deposit_arr: {},
      isUpdate: false,
      temp_fee_record: this.props.feeCategoryStructure,
      total_amount: 0,
      total_discount: 0,
      ground_total: 0,
      monthly_discount: 0,
      total_monthly_amount: 0,
      total_monthly_discount: 0,
      set_monthly_fee_amo: 0,
      convence_discount: 0,
      total_convence_amount: 0,
      total_convence_discount: 0,
      set_convence_fee_amo: 0
    },
      () => {
        console.log(this.state);
        this.updateRecored_0(student_id);
        this.updateRecored_1(student_id);
      });
  };
  updateRecored_0(_id) {
    // loadProgressBar();
    const obj = {
      student_id: _id
      // student_id: "472"
    }
    console.log(JSON.stringify(obj));

    this.props.getFeeDepositedCurrentStudent(obj);

    // axios.get(GET_PRE_DEPOSIT_RECORD + '?student_id=' + student_id)
    //   .then(res => {
    //     const _deposited_arr = res.data;
    //     if (_deposited_arr.message === '') {
    //       this.setState({
    //         pre_fee_deposit_arr: _deposited_arr
    //       }, () => {
    //         this.updatePreFeeRecord();
    //       });
    //     } else {
    //       Alert.error(_deposited_arr.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //       this.updatePreFeeRecord();
    //     }
    //   }).catch((error) => {
    //     // error
    //   });
  }
  updatePreFeeRecord() {
    // debugger
    const _temp_fee_record = this.state.temp_fee_record;
    const _deposited_arrX = this.state.pre_fee_deposit_arr;
    const _record = _temp_fee_record.map((item_) => {
      item_.paid_depo_mts = '';
      item_.rest_mts = '';
      //const _key = item_.cat_name.toLowerCase();
      const _key = item_.cat_name.toLowerCase();
      if (_deposited_arrX[_key] !== undefined && _deposited_arrX[_key] !== null) {
        const _value = _deposited_arrX[_key].toString();
        item_.paid_depo_mts = _value;
        item_.rest_mts = this.getOption(_key);
      } else {
        item_.rest_mts = this.getOption(_key);
      }
      return item_
    })

    this.setState({
      pre_fee_deposit_arr: _record
    })
  }
  updateRecored_1(_id) {
    debugger
    const stu_reco = this.props.students.filter((item) => {
      if (item.se_id === _id) {
        return item
      }
    })
    // debugger
    // console.log(stu_reco)
    if (stu_reco) {
      var _conveyance_amo = 0;
      this.props.conveyance.filter((item) => {
        if (item.stoppage_name === stu_reco.convence_area) {
          _conveyance_amo = parseInt(item.stoppage_amo);
        }
      })

      this.setState({
        selected_student_info: stu_reco,
        convence_fee_amo: _conveyance_amo
      });
    }

    // axios.get(GET_STUDENT + '?id=' + student_id)
    //   .then(res => {
    //     debugger;
    //     const stu_reco = res.data;
    //     if (stu_reco.message === undefined) {
    //       var _conveyance_amo = 0;
    //       this.state.conveyances.filter((item, index) => {
    //         if (item.stoppage_name === stu_reco.convence_area) {
    //           _conveyance_amo = parseInt(item.stoppage_amo);
    //         }
    //       })

    //       this.setState({
    //         selected_student_info: stu_reco,
    //         convence_fee_amo: _conveyance_amo,
    //         errorMessages: res.data.message,
    //       });
    //     } else {
    //       Alert.warning(stu_reco.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //     }
    //   }).catch((error) => {
    //     // error
    //   })
  }
  arrayDiffrence = (a1, a2) => {
    var a = [], diff = [];
    for (var i = 0; i < a1.length; i++) {
      a[a1[i]] = true;
    }
    for (var x = 0; x < a2.length; x++) {
      if (a[a2[x]]) {
        delete a[a2[x]];
      } else {
        a[a2[x]] = true;
      }
    }
    for (var k in a) {
      diff.push(k);
    }
    return diff;
  }
  formatDate = (date) => {
    var monthNames = [
      "January", "February", "March",
      "April", "May", "June", "July",
      "August", "September", "October",
      "November", "December"
    ];
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    return day + ' ' + monthNames[monthIndex] + ' ' + year;
  }
  calcFee = () => {
    var { temp_fee_record } = this.state;
    console.log(temp_fee_record);
    let _total_fee = 0;
    let _total_discount = 0;

    let _monthly_discount = this.state.selected_student_info.monthly_discount;
    let _total_monthly_amount = 0;
    let _total_monthly_discount = 0;
    let _set_monthly_fee_amo = 0;

    let _convence_discount = this.state.selected_student_info.convence_discount;
    let _total_convence_amount = 0;
    let _total_convence_discount = 0;
    let _set_convence_fee_amo = 0;

    temp_fee_record.map((item) => {
      const _feeamo = ((item.curn_depo_amo > 0) ? parseInt(item.curn_depo_amo) : 0);
      const _discount = ((item.discount > 0) ? parseInt(item.discount) : 0);
      _total_fee = _total_fee + _feeamo;
      _total_discount = _total_discount + _discount;
      if (item.cat_name === 'Monthly') {
        _total_monthly_amount = _feeamo - _discount;
        _total_monthly_discount = _discount;
        _set_monthly_fee_amo = _feeamo;
      } else if (item.cat_name === 'Convence') {
        _total_convence_amount = _feeamo - _discount;
        _total_convence_discount = _discount;
        _set_convence_fee_amo = _feeamo;
      }
    })
    this.setState({
      total_amount: _total_fee - _total_discount,
      total_discount: _total_discount,
      ground_total: _total_fee,
      monthly_discount: _monthly_discount,
      total_monthly_amount: _total_monthly_amount,
      total_monthly_discount: _total_monthly_discount,
      set_monthly_fee_amo: _set_monthly_fee_amo,
      convence_discount: _convence_discount,
      total_convence_amount: _total_convence_amount,
      total_convence_discount: _total_convence_discount,
      set_convence_fee_amo: _set_convence_fee_amo

    }, () => {
      this.createMsz();
    })

  }
  createMsz = () => {
    let { temp_fee_record, selected_student, selected_class } = this.state;
    let _msz = '';
    let _total = 0;
    temp_fee_record.map((item, index) => {
      if (item.curn_depo_amo !== '') {
        const _this_msz = ((index === 0) ? '' : ', ') +
          item.cat_name + ' of ' +
          item.curn_depo_mts + ' = ' +
          item.curn_depo_amo + '/-';
        _msz = _msz + _this_msz;
        _total = _total + item.curn_depo_amo;
      }
    })
    // console.log(this.state);
    // debugger

    this.setState({
      description: selected_student + ' of ' + selected_class +
        ', ____ deposit amount is: ' + _msz + ' and GTotal Rs.= ' + _total + '/-'
    })
  }
  getSectedClassHandler = () => {
    // const _class_idx = parseInt(_class_inx);
    // let _school_id = this.state.school_id;
    // let _selected_class_id = this.state.selected_classes[_class_idx].id;
    // let _selected_class = this.state.selected_classes[_class_idx].class_name_portal;

    const _school_id = this.props.filteredSchoolData.slct_school_id;
    const _slct_cls = this.props.filteredClassesData;
    this.setState({
      selected_class_id: _slct_cls.slct_cls_id,
      selected_class: _slct_cls.slct_cls_name,
      selected_class_inx: _slct_cls.slct_cls_index,
    }, () => {
      // debugger;
      const _class_student = this.props.students.filter((item) => {
        if (item.school_id === _school_id &&
          item.stu_class === _slct_cls.slct_cls_name) {
          return item
        }
      })
      const _class_feeWithCategory = this.props.feeWithCategory.filter((item) => {
        if (item.class_id === _slct_cls.slct_cls_id) {
          return item
        }
      })

      // console.log(_class_student);
      // console.log(_class_feeWithCategory);

      this.setState({
        class_fee_Has: (_class_feeWithCategory.length > 0) ? true : false,
        class_fee_arr: _class_feeWithCategory,
        // fee_category: _class_categoryWithFee,
        class_students: _class_student
      });
      const obj = {
        class_id: _slct_cls.slct_cls_id
      }
      // console.log(JSON.stringify(obj));
      // debugger;
      this.props.getFeeCategoryStructure(obj);

      // const obj = {
      //   class_id: _selected_class_id,
      //   group_id: this.props.user.group_id,
      //   school_id: this.state.school_id,
      //   user_category: this.state.user_category,
      //   session_year_id: this.state.session_year_id,
      // };
      // console.log(JSON.stringify(obj))
      // // debugger

      // axios.post(GET_STUDENTS_BY_CLASS, obj)
      //   .then(res => {
      //     this.setState({
      //       students: res.data.records
      //     })
      //     if (!res.data.records.length > 0) {
      //       Alert.error(res.data.message, {
      //         position: 'bottom-right',
      //         effect: 'jelly',
      //         timeout: 5000, offset: 40
      //       });
      //     }
      //     // console.log(this.state.students);
      //   }).catch((error) => {
      //     // error
      //   })



      // axios.get(GET_CLASS_FEE + '?class_id=' + _selected_class_id)
      //   .then(res => {
      //     if (Array.isArray(res.data)) {
      //       this.setState({
      //         class_fee_arr: res.data,
      //         class_fee_Has: true
      //       });
      //       // console.log(this.state);
      //     } else {
      //       Alert.warning('This Class Fee Structure Not Added Please Update it first using [ Setting > Pamnent ]', {
      //         position: 'bottom-right',
      //         effect: 'jelly',
      //         timeout: 5000, offset: 40
      //       });
      //       this.setState({
      //         class_fee_Has: false
      //       })
      //     }
      //     // console.log(this.state);
      //   }).catch((error) => {
      //     // error
      //   })

      // loadProgressBar();
      // console.log(JSON.stringify(obj));
      // axios.post(GET_FEE_CATEGORY, obj)
      //   .then(res => {
      //     const fee_category = res.data;
      //     this.setState({
      //       fee_category: fee_category
      //     });
      //   }).catch((error) => {
      //     // error
      //   })
    });
  }
  getFeeTime = (elem) => {
    let fee_time = [];
    if (elem.collect_time_jul = 'yes') { fee_time.push('July') }
    if (elem.collect_time_aug = 'yes') { fee_time.push('August') }
    if (elem.collect_time_sep = 'yes') { fee_time.push('September') }
    if (elem.collect_time_oct = 'yes') { fee_time.push('October') }
    if (elem.collect_time_nov = 'yes') { fee_time.push('November') }
    if (elem.collect_time_dec = 'yes') { fee_time.push('December') }
    if (elem.collect_time_jan = 'yes') { fee_time.push('January') }
    if (elem.collect_time_feb = 'yes') { fee_time.push('Fabruary') }
    if (elem.collect_time_mar = 'yes') { fee_time.push('March') }
    if (elem.collect_time_apr = 'yes') { fee_time.push('April') }
    if (elem.collect_time_may = 'yes') { fee_time.push('May') }
    if (elem.collect_time_jun = 'yes') { fee_time.push('June') }
    return fee_time;
  }
  depositFeeRecord = () => {
    debugger
    let _temp_record = [];
    let student_id = this.state.selected_student_id;
    this.state.temp_fee_record.map((item) => {
      const val = item.curn_depo_mts.split(',');
      for (var x = 0; x < val.length; x++) {
        const _dist_amo = parseInt(item.discount / val.length);
        const _depo_amo = parseInt(item.curn_depo_amo / val.length);
        if (_depo_amo > 0) {
          const deposit_fee_record = {
            student_id: student_id,
            fee_title: item.cat_name, // registration, monthly, sports, advance...
            month_of_fee: val[x],
            fee_amount: _depo_amo - _dist_amo,
            fee_discount: _dist_amo,
            fee_total: _depo_amo,
          };
          _temp_record = _temp_record.concat(deposit_fee_record);
        }
      }
    });
    this.setState({
      deposit_fee_arr: _temp_record
    }, () => {
      // console.log(this.state.deposit_fee_arr);
    })
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Add this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler() {
    loadProgressBar();
    const { deposit_fee_arr, total_amount, ground_total, selected_student, selected_class,
      fee_date, description, total_discount } = this.state;
    debugger;
    const obj = {
      fee_data: deposit_fee_arr,
      total_amount: total_amount,
      fee_amount: ground_total,
      student_name: selected_student,
      student_class: selected_class,
      deposit_date: fee_date,
      description: description,
      discount: total_discount
    };
    console.log(JSON.stringify(obj));

    this.props.createFeeRecord(obj);

    // debugger
    // axios.post(CREATE_FEE_DEPOSIT, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     // console.log(getRes)
    //     this.getUnvarifiedRecord();
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       selected_student: '',
    //       description: '',
    //       pre_fee_deposit_arr: {},
    //       isUpdate: false,
    //       temp_fee_record: this.props.feeCategoryStructure,
    //       total_amount: 0,
    //       total_discount: 0,
    //       ground_total: 0,
    //       monthly_discount: 0,
    //       total_monthly_amount: 0,
    //       total_monthly_discount: 0,
    //       set_monthly_fee_amo: 0,
    //       convence_discount: 0,
    //       total_convence_amount: 0,
    //       total_convence_discount: 0,
    //       set_convence_fee_amo: 0,
    //       selected_student_info: ''
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  confirmBoxVarify = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Varify this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.varifyHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  varifyHandler = () => {
    loadProgressBar();
    const _myobj = this.state.final_deposit_fee_arr.filter((item) => {
      if (item.isChecked === true) {
        return item['id'] === item.id;
      }
    })
    if (_myobj.length > 0) {
      const myobj = { obj: _myobj };
      axios.post(VERIFY_FEE_DEPOSIT, myobj)
        .then(res => {
          const getRes = res.data;
          // console.log(getRes)
          this.setState({
            final_deposit_fee_arr: []
          }, () => {
            // this.getUnvarifiedRecord()
          })
        }).catch((error) => {
          //this.setState({ errorMessages: error });
        })
    } else {
      Alert.warning('Please select at least one detail.', {
        position: 'bottom-right',
        effect: 'jelly',
        timeout: 5000, offset: 40
      });
    }
  }
  filter_array(test_array) {
    var index = -1,
      arr_length = test_array ? test_array.length : 0,
      resIndex = -1,
      result = [];
    while (++index < arr_length) {
      var value = test_array[index];
      if (value) {
        result[++resIndex] = value;
      }
    }
    return result;
  }

  getOption(category) {
    // console.log(category);
    let all_month = [];
    let paid_month = [];
    let _result = [];
    let _cat_type = '';
    let _cat_name = '';
    this.state.temp_fee_record.map((item) => {
      _cat_name = item.cat_name.toLowerCase();
      if (_cat_name === category) {
        all_month = item.collect_time.split(',');
        paid_month = this.filter_array(item.paid_depo_mts.split(','));
        _cat_type = item.cat_type;
      }
    });

    if (_cat_type === "multiple") {
      _result = this.arrayDiffrence(all_month, paid_month);
      return this.filter_array(_result);
    } else {
      if (paid_month.length > 0) {
        return [];
      } else {
        return ['Yes'];
      }
    }

  }
  goNext(e) {
    e.preventDefault();
    this.setState({
      isUpdate: true
    })
  }
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    let del_id = id;
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.deleteHandlar(event, del_id);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  deleteHandlar = (event, id) => {
    event.preventDefault();
    const _id = id;

    axios.get(DELETE_URL + '?id=' + _id)
      .then(res => {
        const getRes = res.data;
        // console.log(getRes)
        Alert.success(getRes.message, {
          position: 'bottom-right',
          effect: 'jelly',
          timeout: 5000, offset: 40
        });
        const _final_deposit_fee_arr = this.state.final_deposit_fee_arr.filter((item, index) => {
          return item.id !== _id
        })
        this.setState({
          final_deposit_fee_arr: _final_deposit_fee_arr,
          selected_student_info: ''
        })
      }).catch((error) => {
        //this.setState({ errorMessages: error });
      })
  }


  goBack = (event) => {
    event.preventDefault();
    this.setState({
      isUpdate: false
    })
  }

  render() {
    const { class_fee_Has, class_students, fee_date, monthly_discount, convence_discount, total_convence_amount,
      total_monthly_amount, total_monthly_discount, set_monthly_fee_amo, total_convence_discount, set_convence_fee_amo, description,
      total_amount, total_discount, ground_total, final_deposit_fee_arr, isUpdate, temp_fee_record,
      selected_student_info, formIsHalfFilledOut } = this.state;
    const { user, schools, students, conveyance, classes, feeDepositedAll } = this.props;
    // console.log(this.state);
    return (
      <div className="page-content">
        <Helmet>
          <title>Get Fee</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Get Fees</div>
          {user && schools && classes && conveyance && feeDepositedAll && students &&
            <div className="form-inline ml-auto filter-panel">
              <span className="filter-closer">
                <button type="button" className="btn btn-danger filter-toggler-c">
                  <i className="fa fa-times"></i>
                </button>
              </span>
              <div className="filter-con">
                <CommonFilters
                  showSchoolFilter={true}
                  showMediumFilter={false}
                  showClassFilter={true}
                  filterBySchoolHandler={this.filterBySchoolHandler}
                  filterByClsHandler={this.filterByClsHandler}
                />
                {/* <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Schools :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='school'
                    value={selected_school_index}
                    onChange={event => this.changeHandler(event, 'school')}>
                    <option value="">Select ...</option>
                    {schools.map((item, index) => {
                      return (
                        <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-2">Medium :</label>
                  <select className="form-control form-control-sm"
                    required
                    ref='medium'
                    disabled={medium_arr.length > 1 ? false : true}
                    value={medium}
                    onChange={event => this.changeHandler(event, 'medium')}>
                    <option value="">Select ...</option>
                    {medium_arr.map((item, index) => {
                      return (
                        <option key={index} value={item}>{item}</option>
                      )
                    })}
                  </select>
                </div>
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-1">Class<span className="required"> * </span>
                  </label>
                  <select
                    disabled={medium === '' ? true : false}
                    value={selected_class_inx}
                    className="form-control form-control-sm" name="selected_class"
                    onChange={event => this.changeHandler(event, 'selected_class')}>
                    <option value="All">Select...</option>
                    {selected_classes.map((option, index) => {
                      return (
                        <option key={index} value={index}>{option.class_name}</option>
                      )
                    })}
                  </select>
                </div> */}
                <div className="form-group mr-2 mt-1">
                  <label className="control-label mr-1">Student Name <span className="required"> * </span>
                  </label>
                  <select
                    disabled={(class_students.length > 0 && (class_fee_Has)) ? false : true}
                    className="form-control form-control-sm" name="select"
                    //defaultValue={selected_student}
                    onChange={this.selectStudentNameHandlar}>
                    <option value>Select...</option>
                    {class_students.map((option, index) => {
                      return (
                        <option key={index} value={JSON.stringify(option)}>{option.student_name}</option>
                      )
                    })}
                  </select>
                  {isUpdate ?
                    <button type="button"
                      onClick={event => this.goBack(event)}
                      className="btn btn-sm btn-danger">Cancel</button>
                    :
                    <button
                      className={`btn btn-sm btn-primary`}
                      disabled={!isEmpty(selected_student_info) ? false : true}
                      onClick={event => this.goNext(event)}>
                      Go
                </button>
                  }
                </div>
              </div>
            </div>
          }
        </div>
        <form className="card card-box sfpage-cover" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-body sfpage-body">
            <div className="d-flex">
              <div className="form-group ml-auto d-flex">
                <label className="control-label mr-1">Date</label>
                <div className="input-group bg-white">
                  <DatePicker
                    onChange={this.feeDepositDate}
                    value={fee_date}
                    showLeadingZeroes={true}
                    minDate={new Date()}
                  />
                </div>
              </div>
            </div>
            <div className="table-scrollable">
              <div className="col">
                {class_fee_Has ?
                  <div className="form-horizontal">
                    {isUpdate ?
                      <div className="form-body">
                        <div className="row">
                          {temp_fee_record.map((item, inx) => {
                            return (
                              <FeeField
                                key={inx}
                                name={item.cat_name}
                                value={23}
                                options={item.rest_mts}
                                singleFeeHandler={this.commonFeeHandler}
                              />)
                          })}
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group row  mb-1">
                              <label className="control-label col-md-4">Discount in Monthly Fee</label>
                              <div className="col-md-8">
                                <div className="input-group mb-1">
                                  <input type="text" className="form-control form-control-sm"
                                    disabled={true}
                                    defaultValue={monthly_discount}
                                    maxLength="2" size="2"
                                    onChange={event => this.monthlyDiscountHandlar(event)} />
                                  <div className="input-group-append">
                                    <span className="input-group-text pt-1 pb-1 ">%</span>
                                  </div>
                                </div>
                                <div className="row">
                                  <div className="col pr-0">
                                    <input disabled={true}
                                      disabled={true}
                                      type="text" className="form-control form-control-sm"
                                      value={total_monthly_amount} />
                                  </div>
                                  <div className="col pl-0">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={total_monthly_discount} />
                                  </div>
                                  <div className="col">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={set_monthly_fee_amo} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group row mb-1">
                              <label className="control-label col-md-4">Discount in Convence Fee</label>
                              <div className="col-md-8">
                                <div className="input-group mb-1">
                                  <input type="text" className="form-control form-control-sm"
                                    disabled={true}
                                    defaultValue={convence_discount}
                                    maxLength="2" size="2"
                                    onChange={event => this.convenceDiscountHandlar(event)} />
                                  <div className="input-group-append">
                                    <span className="input-group-text pt-1 pb-1 ">%</span>
                                  </div>
                                </div>
                                <div className="row">
                                  <div className="col pr-0">
                                    <input disabled={true}
                                      type="text" className="form-control form-control-sm"
                                      value={total_convence_amount} />
                                  </div>
                                  <div className="col pl-0">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={total_convence_discount} />
                                  </div>
                                  <div className="col">
                                    <input disabled={true}
                                      type="number" className="form-control form-control-sm"
                                      value={set_convence_fee_amo} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="d-block w-100"></div>
                        </div>
                        <hr />
                        <div className="row">
                          <div className="col-md-6">
                            <div className="form-group row">
                              <label className="control-label col-md-12 text-left pb-2 pt-0">Payment Details
                    </label>
                              <div className="col-md-12">
                                <textarea
                                  value={description}
                                  onChange={event => this.changeHandler(event, 'description')}
                                  placeholder="payment details" className="form-control form-control-sm-textarea form-control-sm"
                                  rows={5} />
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="form-group row">
                              <label className="control-label col-md-5">Total Fee
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={total_amount}
                                  type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-5">Total Discount
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={total_discount}
                                  type="number" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>
                            <div className="form-group row">
                              <label className="control-label col-md-5">Ground Total
                              </label>
                              <div className="col-md-7">
                                <input disabled={true}
                                  value={ground_total}
                                  type="text" placeholder="enter amount" className="form-control form-control-sm" /> </div>
                            </div>

                          </div>
                        </div>

                      </div>
                      : null}
                  </div>
                  : null}
                <div className="card card-box h-auto">
                  <div className="table-responsive">
                    <table className="table table-striped table-bordered table-hover table-sm m-0">
                      <thead>
                        <tr>
                          <th className="center">
                            <div className="custom-control custom-checkbox">
                              <input type="checkbox"
                                id="select_all" className="custom-control-input"
                                onChange={event => this.checkHandler(event, 'select_all', true)} />
                              <label className="custom-control-label" htmlFor="select_all">All</label>
                            </div>
                          </th>
                          <th className="center"> Student Name </th>
                          <th className="center"> Class </th>
                          <th className="center"> Deposite Date </th>
                          <th className="center"> Total amount</th>
                          <th className="center"> Disount</th>
                          <th className="center"> Total</th>
                          {/*<th className="center"> Balance</th>*/}
                          <th className="center"> Description</th>
                          <th className="center"> Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.isArray(final_deposit_fee_arr) ? (
                          final_deposit_fee_arr.map((value, index) => {
                            return (
                              <tr key={index}  >
                                <td className="center">
                                  <div className="custom-control custom-control-inline custom-checkbox">
                                    <input type="checkbox"
                                      checked={value.isChecked}
                                      id={`check_` + index} className="custom-control-input"
                                      onChange={event => this.checkHandler(event, 'select_this', value.id)} />
                                    <label className="custom-control-label" htmlFor={`check_` + index}>{value.id}</label>
                                  </div>
                                </td>
                                <td className="center">{value.student_name}</td>
                                <td className="center">{value.selected_class}</td>
                                <td className="center">{value.deposit_date}</td>
                                <td className="center">{value.total_amount}</td>
                                <td className="center">{value.discount}</td>
                                <td className="center">{value.fee_amount}</td>
                                {/*<td className="center">{value.balance_amount}</td>*/}
                                <td className="left">{value.description}</td>
                                <td className="center">
                                  {/*<NavLink to="edit_professional" className="btn btn-primary btn-sm">
                                  Edit
                          </NavLink>*/}
                                  <button className="btn btn-danger btn-sm"
                                    onClick={event => this.confirmBoxDelete(event, value.id)}>
                                    Del
                                  </button>
                                </td>
                                {/*
                               <tr >
                                 <td colSpan="3"></td>
                                 <td colSpan="6" className="p-0">
                                   <table className="table table-condensed m-0">
                                     <thead>
                                       <tr>
                                         <th className="center p-0"> ID No.</th>
                                         <th className="center p-0"> Fee Title </th>
                                         <th className="center p-0"> Deposit Amount</th>
                                         <th className="center p-0"> Month of fee </th>
                                       </tr>
                                     </thead>
                                     <tbody>
                                       {value.xsd.map((value1, index1) => {
                                         return (
                                           <tr className="" key={index1}>
                                             <td className="center p-0">{index1 + 1}</td>
                                             <td className="center p-0">{value1.fee_title}</td>
                                             <td className="center p-0">{value1.fee_amount}</td>
                                             <td className="center p-0">{value1.month_of_fee}</td>
                                           </tr>
                                         )
                                       })}
                                     </tbody>
                                   </table>
                                 </td>
                               </tr>
                                     */}
                              </tr>
                            )
                          })
                        ) : null}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer d-flex">
            <button type="button" disabled={true} className="btn btn-primary mr-2">Message</button>
            <button type="button" className="btn btn-success mr-2"
              onClick={event => this.confirmBoxVarify(event)}>
              Varify
                </button>

            <button type="submit"
              disabled={ground_total > 0 ? false : true}
              className="btn btn-primary mr-2 ml-auto">Submit</button>

            {(isUpdate === true) &&
              <button type="button"
                onClick={event => this.goBack(event)}
                className="btn btn-danger mr-2">Cancel</button>
            }
            {/* <NavLink to="/fees_collection.jsp" className="btn btn-danger">Cancel</NavLink> */}
          </div>
        </form>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: schools } = state.schools;
  const { item: feeWithCategory } = state.feeWithCategory;
  const { item: conveyance } = state.conveyance;
  const { item: classes } = state.classes;
  const { item: students } = state.students;
  const { item: feeDepositedCurrentStudent } = state.feeDepositedCurrentStudent;
  const { item: feeCategoryStructure } = state.feeCategoryStructure;
  const { item: feeDepositedAll } = state.feeDepositedAll;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  return {
    user, schools, conveyance, feeCategoryStructure, classes, students,
    feeWithCategory, feeDepositedCurrentStudent, feeDepositedAll,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getConveyance: conveyanceAction.getConveyance,
  getClasses: classesAction.getClasses,
  getStudents: studentsAction.getStudents,
  getFeeDepositedAll: feeDepositedAllAction.getFeeDepositedAll,
  createFeeRecord: feeDepositedAllAction.create,
  getFeeWithCategory: feeWithCategoryAction.getFeeWithCategory,
  getFeeCategoryStructure: feeCategoryStructureAction.getFeeCategoryStructure,
  getFeeDepositedCurrentStudent: feeDepositedCurrentStudentAction.getFeeDepositedCurrentStudent,

}

export default connect(mapStateToProps, actionCreators)(withRouter(GetFees));