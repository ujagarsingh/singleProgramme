import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";

class EditAccGroup extends Component {
	state = ({
		id: "",
		group_name: "",
		formIsHalfFilledOut: false,
	})
	changeHandler = (event, fieldName, isCheckbox) => {
		this.setState({
			[fieldName]: isCheckbox ? event.target.checked : event.target.value,
			formIsHalfFilledOut: true
		})

	};
	componentDidMount() {
		this.setState({
			selected_item: this.props.selected_item
		})
	}
	confirmBoxSubmit = (event) => {
		event.preventDefault();
		confirmAlert({
			title: 'stay one moment!',
			message: 'Are you sure do you want to Update this.',
			buttons: [
				{
					label: 'Yes',
					onClick: () => {
						this.submitHandler();
					}
				},
				{
					label: 'No',
				}
			]
		});
	};

	submitHandler = e => {
		loadProgressBar();

		//e.preventDefault();
		let default_obj = '';
		if (this.props.user.user_category === "1") {
			default_obj = { school_id: this.refs.school.value }
		}
		const form_obj = {
			id: this.props.selected_item.id,// this.state.id,
			group_name: this.refs.group_name.value, // this.state.title,
			parent_id: this.refs.parent_id.value,
			op_balance: this.refs.op_balance.value,
			op_balance_type: this.refs.op_balance_type.value,
		}
		const obj = { ...form_obj, ...default_obj }
		console.log(JSON.stringify(obj));

		this.props.updateHandlar(obj);
	}
	render() {
		const { formIsHalfFilledOut } = this.state;
		const { selected_item, schools, accGroup, user } = this.props;
		console.log(this.props);
		return (
			<div className="page-content">
				<Helmet>
					<title>Edit Account Group</title>
				</Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				<Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
				<form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
					<div className="card-header">
						Edit Account Group
               </div>
					<div className="card-body">
						{selected_item && schools && user && accGroup &&
							<div className="row" key={selected_item.id}>
								{(user.user_category === "1") &&
									<div className="col-sm-2">
										<div className="form-group mr-2 mt-1">
											<label className="control-label mr-2">Schools :</label>
											<select className="form-control form-control-sm"
												required
												ref='school'
												// defaultValue={this.getSchoolIndexHandlar(selected_item.school_id)}
												defaultValue={selected_item.school_id}
											// onChange={event => this.changeHandler(event, 'school')}
											>
												<option value="">Select ...</option>
												{schools.map((item, index) => {
													return (
														<option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
													)
												})}
											</select>
										</div>
									</div>
								}

								<div className="col-sm-4">
									<div className="form-group">
										<label className="control-label">Group Name
                        <span className="required"> * </span>
										</label>
										<div className="form-input">
											<input type="text" placeholder="Group Name"
												className="form-control form-control-sm"
												required
												ref="group_name"
												defaultValue={selected_item.group_name}
											/>
										</div>
									</div>
								</div>
								<div className="col-sm-2">
									<div className="form-group">
										<label className="control-label">Under </label>
										<div className="form-input">
											<select className="form-control form-control-sm"
												required
												ref='parent_id'
												defaultValue={selected_item.parent_id}
												onChange={event => this.changeHandler(event, 'parent_id')}>
												<option value="">Select ...</option>
												{accGroup.map((item, index) => {
													return (
														<React.Fragment key={index}>
															{(item.group_type === "P") ?
																<option key={index} value={item.id}>{item.group_name}</option>
																: null
															}
														</React.Fragment>
													)
												})}
											</select>
										</div>
									</div>
								</div>
								<div className="col-sm-2">
									<div className="form-group">
										<label className="control-label">Opening Balance</label>
										<div className="form-input">
											<input type="number" ref="op_balance" placeholder="Opening Balance"
												className="form-control form-control-sm"
												defaultValue={selected_item.op_balance}
												onChange={event => this.changeHandler(event, 'op_balance')} />
										</div>
									</div>
								</div>
								<div className="col-sm-2">
									<div className="form-group">
										<label className="control-label">Balance Type</label>
										<div className="form-input">
											<select className="form-control form-control-sm"
												required
												ref='op_balance_type'
												defaultValue={selected_item.op_balance_type}
												onChange={event => this.changeHandler(event, 'op_balance_type')}>
												<option value="CR">CR</option>
												<option value="DR">DR</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						}
					</div>
					<div className="card-footer d-flex">
						<span className="text-danger p-2">CR : Liability, DR : Assets</span>
						<button type="submit" className="btn btn-primary  mr-2 ml-auto">Submit</button>
						{/* <NavLink to="/all_galleries.jsp" className="btn btn-danger">Cancel</NavLink> */}
						<button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
							Exit </button>
					</div>
				</form>
			</div>
		)
	}
}

export default withRouter(EditAccGroup);