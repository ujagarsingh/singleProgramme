import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
// import { NavLink } from 'react-router-dom';
// import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import axios from 'axios';
// import { connect } from 'react-redux';
// import { schoolsAction, feeCategoryAction } from '../_actions';
// import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// // by class meeium with amount
// const READ_FEE_CWA = `http://schools.rajpsp.com/api/fee_category/read_one_by_cwa.php`;
// const UPDATE_FEE_STRUCTURE = `http://schools.rajpsp.com/api/fee_amount/update.php`;
// const CLASSES_BY_MEDIUM = `http://schools.rajpsp.com/api/classes/read.php`;

class FeeFeeDetails extends Component {
  state = {
    medium: '',
    fee_category: [],
    fee_amounts: [],
    classes: [],
    class_id: '',
    formIsHalfFilledOut: false,
  }
  changeHandler = (event, fieldName, isCheckbox) => {
    this.setState({
      [fieldName]: isCheckbox ? event.target.checked : event.target.value,
      formIsHalfFilledOut: true
    })
    if (fieldName === 'medium') {
      // const _medium = event.target.value;
      this.getClassesByMedium();
    }
    if (fieldName === 'class_id') {
      const _class_id = event.target.value;
      this.setState({
        class_id: _class_id
      })
    }
  }
  changeDyHandler = (event, fieldName, isCheckbox) => {
    //this.setState({ [fieldName]: isCheckbox ? event.target.checked : event.target.value })
    const _field = fieldName;
    const _value = event.target.value;
    const _fee_category = this.state.fee_category.map((item) => {
      if (item.cat_name === _field) {
        item.fee_amount = _value;
      }
      return item
    })
    this.setState({
      fee_category: _fee_category
    })
  }

  // componentDidMount() {
  //   if (isEmptyObj(this.props.schools)) {
  //     this.props.getSchools();
  //   }
  //   if (isEmptyObj(this.props.classes)) {
  //     this.props.getClasses();
  //   }
  // }

  componentDidMount() {
    this.setValueHandler();
  }

  setValueHandler() {
    const obj = { ...this.props.selected_item };
    const props_obj = { ...this.props.selected_item };

    let obj1 = Object.assign({}, obj); // {...obj}; // JSON.parse(JSON.stringify(obj));

    delete obj["class_id"];
    delete obj["school_id"];
    delete obj["school_name"];
    delete obj["class_name"];
    delete obj["medium"];

    //console.log(obj);    console.log(obj1);    debugger;
    const obj2 = {
      class_id: obj1["class_id"],
      class_name: obj1["class_name"],
      school_id: obj1["school_id"]
    }


    let result = Object.keys(obj).map((key) => {
      const item = {
        "cat_name": key,
        "fee_amount": (obj[key] ? obj[key] : ""),
        "fee_category_id": this.getFeeCategoryId(key),
        "cat_diff": this.getFeeTypeDiff(key),
        ...obj2
      }
      return item;
    });

    // console.log(result);
    // debugger;

    this.setState({
      fee_category: result,
      props_class_obj: props_obj,
      class_id: props_obj.class_id,
      school_id: props_obj.school_id,
      medium: props_obj.medium
    })
  }

  getFeeCategoryId(key) {
    const _feeCategory = this.props.feeCategory;
    let _feeCategory_id = "";
    _feeCategory.filter((item) => {
      if (item.cat_name.toLowerCase() === key.toLowerCase()) {
        _feeCategory_id = item.id;
      }
    })
    return _feeCategory_id;
  }
  getFeeTypeDiff(key) {
    const _feeCategory = this.props.feeCategory;
    let _feeCategory_type = "";
    _feeCategory.filter((item) => {
      if (item.cat_name.toLowerCase() === key.toLowerCase()) {
        _feeCategory_type = item.cat_diff;
      }
    })
    return _feeCategory_type;
  }
  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getOneByOneFeeRecord();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getOneByOneFeeRecord() {
  //   loadProgressBar();
  //   const { match } = this.props;
  //   const _id = match.params.id;
  //   const _id_split = _id.split('-');
  //   const obj = {
  //     class_id: _id_split[0],
  //     medium: _id_split[1]
  //   }
  //   // axios.post(READ_FEE_CWA, obj)
  //   //   .then(res => {
  //   //     const resData = res.data;
  //   //     if (resData.message) {
  //   //       Alert.success(resData.message, {
  //   //         position: 'bottom-right',
  //   //         effect: 'jelly',
  //   //         timeout: 5000, offset: 40
  //   //       });
  //   //     } else {
  //   //       this.setState({
  //   //         fee_category: resData,
  //   //         class_id: _id_split[0],
  //   //         medium: _id_split[1]
  //   //       }, () => {
  //   //         this.getClassesByMedium();
  //   //       });
  //   //     }
  //   //     //console.log(this.state.fee_category);
  //   //   }).catch((error) => {
  //   //     // error
  //   //   })

  // }
  // getClassesByMedium() {
  //   const obj = {
  //     group_id: this.state.group_id,
  //     school_id: this.state.school_id,
  //     user_category: this.state.user_category,
  //     session_year_id: this.state.session_year_id,
  //   }
  //   // axios.post(CLASSES_BY_MEDIUM, obj)
  //   //   .then(res => {
  //   //     const getRes = res.data;
  //   //     //console.log(getRes)
  //   //     if (getRes.message) {
  //   //       Alert.success(getRes.message, {
  //   //         position: 'bottom-right',
  //   //         effect: 'jelly',
  //   //         timeout: 5000, offset: 40
  //   //       });
  //   //     } else {
  //   //       this.setState({
  //   //         classes: getRes
  //   //       })
  //   //     }
  //   //   }).catch((error) => {
  //   //     //this.setState({ errorMessages: error });
  //   //   })
  // }

  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to Create this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler(event);
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };
  submitHandler = e => {
    //e.preventDefault();
    let fee_amount_array = [];
    this.state.fee_category.map((item) => {
      fee_amount_array.push({
        'fee_title': item.cat_name,
        'fee_amount': item.fee_amount,
        'fee_category_id': item.fee_category_id
      });
      return true;
    })
    const obj = {
      medium: this.state.medium,
      school_id: this.state.school_id,
      class_id: this.state.class_id,
      fee_amount_array: fee_amount_array
    };

    // console.log(this.props);
    // console.log(this.state);
    // console.log(JSON.stringify(obj));

    this.props.updateHandlar(obj)

    // axios.post(UPDATE_FEE_STRUCTURE, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     //console.log(getRes)
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })

  }
  render() {
    const { fee_category, formIsHalfFilledOut } = this.state;
    const { user, schools, feeCategory, selected_item } = this.props;
    // console.log(fee_category)
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Fee Details</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Edit Fee Details
          </div>
          <div className="card-body">
            {user && schools && feeCategory && selected_item && fee_category &&
              <div className="form-body form-horizontal">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="form-group row">
                      <label className="control-label col-md-3">School
                      </label>
                      <div className="col-md-7">
                        <input type="text" disabled={true} defaultValue={selected_item.school_name}
                          className="form-control form-control-sm" />
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group row">
                      <label className="control-label col-md-3">Class Name</label>
                      <div className="col-md-7">
                        <input type="text" disabled={true} defaultValue={selected_item.class_name}
                          className="form-control form-control-sm" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="row">
                  {fee_category.map((item, index) => {
                    if (item.cat_diff !== "Different" && item.fee_amount !== "") {
                    return (
                        <div key={index} className="col-sm-3">
                          <div className="form-group row">
                            <label className="control-label col-md-6">{item.cat_name}
                              <span className="required"> * </span>
                            </label>
                            <div className="col-md-6">
                              <input type="number"
                                value={item.fee_amount}
                                // disabled={item.fee_amount === "" ? true : false}
                                className="form-control form-control-sm"
                                onChange={event => this.changeDyHandler(event, `${item.cat_name}`)}
                              />
                            </div>
                          </div>
                        </div>
                      )
                    }
                  })}
                </div>
              </div>
            }
          </div>
          <div className="card-footer d-flex">
            <span className="text-danger p-2 mr-auto">
              <strong>Note :</strong> Update only already Created Fee Amount!
            </span>
            <button type="submit" className="btn btn-primary mr-2">Submit</button>
            {/* <NavLink to="/all_fee_structure.jsp" className="btn btn-danger">Cancel</NavLink> */}
            <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
            Exit </button>
          </div>
        </form>
      </div>
    )
  }
}

export default withRouter(FeeFeeDetails);