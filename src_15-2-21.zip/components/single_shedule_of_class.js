import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
// import { confirmAlert } from 'react-confirm-alert';
// import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class SingleSheduleOfClass extends Component {
   state = {
      class_shedule_1: [],
      class_shedule_2: [],
   }
   isEmpty(val) {
      return (val === undefined || val == null || val.length <= 0) ? true : false;
   }
   componentDidMount() {
      loadProgressBar();
      let class_shedule_1 = [];
      let class_shedule_2 = [];

      const { shedule_obj } = this.props;
      for (let x = 0; x < shedule_obj.class_shedule.length; x++) {
         if (x < shedule_obj.class_shedule.length / 2) {
            class_shedule_1.push(shedule_obj.class_shedule[x]);
         } else {
            class_shedule_2.push(shedule_obj.class_shedule[x]);
         }
      }
      this.setState({
         class_shedule_1: class_shedule_1,
         class_shedule_2: class_shedule_2,
      })

   };
   printThisReceipt = () => {
      // window.print();
   }
   convertDate(str) {
      var date = new Date(str),
         mnth = ("0" + (date.getMonth() + 1)).slice(-2),
         day = ("0" + date.getDate()).slice(-2);
      return [day, mnth, date.getFullYear()].join("-");
   }

   getConvertedDay(str) {
      var currnt_date = new Date(str);
      let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      // var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      // return months[this.getMonth()];
      return days[currnt_date.getDay()].toUpperCase();
   }
   render() {
      const { class_shedule_1, class_shedule_2 } = this.state;
      const { key_index, notes } = this.props;
      return (
         <div className="shedule-table" key={key_index}>
            <h6 className="mt-2">Exam Shedule :</h6>
            <div className="container-tbl">
               <div className="row m-0">
                  {class_shedule_1.length > 0 ?
                     <div className="col p-0 m-0">
                        <table className="table text-center table-bordered table-hover table-sm m-0 border-right">
                           <thead className="bg-light text-secondary">
                              <tr>
                                 <th>Date</th>
                                 <th>Subject</th>
                                 <th>Time</th>
                              </tr>
                           </thead>
                           <tbody>
                              {class_shedule_1.map((item, index) => {
                                 return (
                                    <tr key={index}>
                                       <td>{this.convertDate(item.exam_date)}
                                          - ( {this.getConvertedDay(item.exam_date)} )</td>
                                       <td>
                                          {item.exam_subject.map((item, index) => (
                                             <span key={index}>
                                                {(index > 0) ? <br /> : null}
                                                <b>{item}</b>
                                             </span>
                                          ))}
                                       </td>
                                       <td>{item.inning_time}</td>
                                    </tr>
                                 )
                              })
                              }
                           </tbody>
                        </table>
                     </div>
                     : null}
                  {class_shedule_2.length > 0 ?
                     <div className="col m-0 p-0">
                        <table className="table text-center table-bordered table-hover table-sm m-0">
                           <thead className="bg-light text-secondary">
                              <tr>
                                 <th>Date</th>
                                 <th>Subject</th>
                                 <th>Time</th>
                              </tr>
                           </thead>
                           <tbody>
                              {class_shedule_2.map((item, index) => {
                                 return (
                                    <tr key={index}>
                                       <td>{this.convertDate(item.exam_date)}
                                          - ( {this.getConvertedDay(item.exam_date)} )</td>
                                       <td>
                                          {item.exam_subject.map((item, index) => (
                                             <span key={index}>
                                                {(index > 0) ? <br /> : null}
                                                <b key={index}>{item}</b>
                                             </span>
                                          ))}
                                       </td>
                                       <td>{item.inning_time}</td>
                                    </tr>
                                 )
                              })
                              }
                           </tbody>
                        </table>
                     </div>
                     : null}
               </div>
            </div>

            <div className="d-flex">
               <div className="w-100">
                  <div className="row">
                     <div className="col-10">
                        <h6 className="mt-2">Notes : </h6>
                        <ol className="list-inline mb-0">
                           {notes.map((item, inx) => {
                              return <li className="list-inline-item ml-3" key={inx}><b>({inx + 1}).</b>   {' ' + item.note}</li>
                           })}
                        </ol>
                     </div>
                     <div className="col-2">
                        <span className="d-flex justify-content-end text-center flex-column h-100">
                           <b>EXAM INCH.</b>
                        </span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      )
   }
}
export default withRouter(SingleSheduleOfClass);