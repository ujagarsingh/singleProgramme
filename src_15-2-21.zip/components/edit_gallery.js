import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { loadProgressBar } from 'axios-progress-bar';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";

class EditGallery extends Component {
   state = ({
      id: "",
      medium: "",
      title: "",
      description: "",
      active: true,
      selected_item: '',
      formIsHalfFilledOut: false,
   })
   changeHandler = (event, fieldName, isCheckbox) => {
      this.setState({
         [fieldName]: isCheckbox ? event.target.checked : event.target.value,
         formIsHalfFilledOut: true
      })

   };
   componentDidMount() {
      this.setState({
         selected_item: this.props.selected_item
      })
   }
 

   confirmBoxSubmit = (event) => {
      event.preventDefault();
      confirmAlert({
         title: 'stay one moment!',
         message: 'Are you sure do you want to Update this.',
         buttons: [
            {
               label: 'Yes',
               onClick: () => {
                  this.submitHandler();
               }
            },
            {
               label: 'No',
            }
         ]
      });
   };

   submitHandler = e => {
      loadProgressBar();

      //e.preventDefault();
      let default_obj = '';
      if (this.props.user.user_category === "1") {
         default_obj = { school_id: this.refs.school.value }
      }
      const form_obj = {
         id: this.props.selected_item.id,// this.state.id,
         title: this.refs.title.value, // this.state.title,
         description: this.refs.description.value, // this.state.description,
         active: (this.refs.active.checked) ? "1" : "0" // this.state.active
      }
      const obj = { ...form_obj, ...default_obj }
      // console.log(JSON.stringify(obj));

      this.props.updateHandlar(obj);

   }
   render() {
      const { formIsHalfFilledOut } = this.state;
      const { selected_item, schools, user } = this.props;
      // console.log(this.props);
      return (
         <div className="page-content">
            <Helmet>
               <title>Edit Gallery</title>
            </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <form className="card card-form card-edit" onSubmit={event => this.confirmBoxSubmit(event)}>
               <div className="card-header">
                  Edit Gallery
               </div>
               <div className="card-body">
                  {selected_item && schools && user &&
                     <div className="row" key={selected_item.id}>
                        {(user.user_category === "1") &&
                           <div className="col-sm-2">
                              <div className="form-group mr-2 mt-1">
                                 <label className="control-label mr-2">Schools :</label>
                                 <select className="form-control form-control-sm"
                                    required
                                    ref='school'
                                    // defaultValue={this.getSchoolIndexHandlar(selected_item.school_id)}
                                    defaultValue={selected_item.school_id}
                                 // onChange={event => this.changeHandler(event, 'school')}
                                 >
                                    <option value="">Select ...</option>
                                    {schools.map((item, index) => {
                                       return (
                                          <option key={index} value={item.id}>{item.sch_name}, {item.sch_medium}</option>
                                       )
                                    })}
                                 </select>
                              </div>
                           </div>
                        }
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">Gallery Title
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" placeholder="Gallery Title"
                                    className="form-control form-control-sm"
                                    required
                                    ref="title"
                                    defaultValue={selected_item.title}
                                 // onChange={event => this.changeHandler(event, 'title')} 
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-4">
                           <div className="form-group">
                              <label className="control-label">About Gallery
                        <span className="required"> * </span>
                              </label>
                              <div className="form-input">
                                 <input type="text" placeholder="About This Galary"
                                    className="form-control form-control-sm"
                                    required
                                    ref="description"
                                    defaultValue={selected_item.description}
                                 // onChange={event => this.changeHandler(event, 'description')}
                                 />
                              </div>
                           </div>
                        </div>
                        <div className="col-sm-2">

                           <div className="form-group">
                              <label className="control-label"></label>
                              <div className="form-input">
                                 <div className="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" className="custom-control-input" id="customCheck2"
                                       ref="active"
                                       // onChange={event => this.changeHandler(event, 'active', true)}
                                       defaultChecked={(selected_item.active === '1') ? true : false}
                                    />
                                    <label className="custom-control-label" htmlFor="customCheck2">
                                       {/* {(selected_item.active === '1') ? 'Yes' : 'No'} */}
                                       Is Active
                                    </label>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  }
               </div>
               <div className="card-footer text-right">
                  <button type="submit" className="btn btn-primary mr-2">Submit</button>
                  {/* <NavLink to="/all_galleries.jsp" className="btn btn-danger">Cancel</NavLink> */}
                  <button onClick={event => this.props.closeEdit(event)} className="btn btn-warning">
                     Exit </button>
               </div>
            </form>
         </div>
      )
   }
}

export default withRouter(EditGallery);