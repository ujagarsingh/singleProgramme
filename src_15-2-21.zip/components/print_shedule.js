import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import Alert from 'react-s-alert';
import { Helmet } from "react-helmet";
import SingleShedulePrint from './single_shedule_print';
import { connect } from 'react-redux';
import {
   schoolsAction, classesAction, examsCategoryAction, examSdulNotesAction,
   examSdulAction, studentsAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
// const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
// const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`; 
// const READ_SHEDULE = `http://schools.rajpsp.com/api/exam_sdul/read.php`;
// const READ_CLASS_URL = `http://schools.rajpsp.com/api/classes/read.php`; 
// const GET_STUDENTS_BY_CLASS = `http://schools.rajpsp.com/api/students/read_students_by_class.php`;

class PrintShedules extends Component {
   state = {
      schools: [],
      shedule_arr: [],
      selected_sch_shedule: [],
      medium_arr: [],
      update_student: [],
      printable_record: [],
      class_shedule: {},
      exams: [],
      notes: [],
      classes: [],
      selected_classes: [],
      selected_class_inx: '',
      selected_shedule_inx: '',
      selected_class_id: "",
      seleced_shedule: '',
      class_shedule_obj: {},
      final_shedule: {},
      group_id: '',
      school_id: '',
      user_category: '',
      session_year_id: '',
      formIsHalfFilledOut: false,
      showSheduleData: false,
      record_generted: false,
      check_all: false
   }
   changeHandler = (event, fieldName, isCheckbox) => {
      // if (fieldName === 'school') {
      //    const _inx = event.target.value;
      //    if (_inx) {
      //       const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      //       const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      //       sessionStorage.setItem("school_id", _sch_id);
      //       this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      //       this.filterSchoolOnSchool(_sch_id);
      //       this.filterSheduleOnSchool(_sch_id);
      //       this.setState({
      //          school_id: _sch_id,
      //          medium_arr: _medium,
      //          medium: (_medium.length === 1 ? _medium[0] : ''),
      //          selected_school_index: _inx,
      //          selected_class_inx: '',
      //          //updated_students: { 'student': [{ 'exams': [] }] },
      //          printable_record: [],
      //          update_student: [],
      //          check_all: false,
      //          record_generted: false,
      //          showSheduleData: false,
      //       })
      //    } else {
      //       this.setState({
      //          school_id: '',
      //          medium_arr: [],
      //          medium: '',
      //          selected_school_index: '',
      //          selected_class_inx: '',
      //          //updated_students: { 'student': [{ 'exams': [] }] },
      //          printable_record: [],
      //          update_student: [],
      //          check_all: false,
      //          record_generted: false,
      //          showSheduleData: false,
      //       })
      //    }
      // } else if (fieldName === 'selected_class') {
      //    const _class_inx = event.target.value;
      //    if (_class_inx !== "") {
      //       const _class_name = this.state.selected_classes[_class_inx].class_name_portal;
      //       const _class_id = this.state.selected_classes[_class_inx].id;
      //       sessionStorage.setItem("class_name_portal", _class_name);
      //       this.setState({
      //          class_name: _class_name,
      //          selected_class_id: _class_id,
      //          selected_class_inx: _class_inx,
      //          selected_shedule_inx: "",
      //          showSheduleData: false,
      //          record_generted: false,
      //          check_all: false
      //       }, () => {
      //          this.getStudentsofaClassHandler(_class_name);
      //       });
      //    } else {
      //       this.setState({
      //          class_name: "",
      //          selected_class_id: "",
      //          selected_class_inx: "",
      //          update_student: "",
      //          selected_shedule_inx: "",
      //          showSheduleData: false,
      //          record_generted: false,
      //          check_all: false
      //       })
      //    }
      // } else 
      
      if (fieldName === 'selecte_shedule') {
         const _inx = event.target.value;
         const _seleced_shedule = this.state.shedule_arr[_inx];
         if (_inx) {
            this.setState({
               selected_shedule_inx: _inx,
               seleced_shedule: _seleced_shedule,
            }, () => {
               this.generateSheduleObjOfClass()
            });
         } else {
            this.setState({
               selected_shedule_inx: '',
               seleced_shedule: [],
            })
         }
      } else if (fieldName === 'medium') {
         const _medium = event.target.value;
         sessionStorage.setItem("medium", _medium);
         //this.filterClassesOnSchool(_medium);
      } else {
         this.setState({
            [fieldName]: isCheckbox ? event.target.checked : event.target.value,
            formIsHalfFilledOut: true
         });
      }
   };
   checkHandler = (event, fieldName, value) => {
      // debugger
      event.preventDefault();
      let _updated_student = this.state.update_student;
      let _chackVal = null;
      if (_updated_student.length > 0) {
         let new_updated_student = [];

         if (fieldName === 'select_this') {
            // debugger
            new_updated_student = _updated_student.map((item) => {
               if (value === item.se_id) {
                  item.checked = !item.checked;
               }
               return item;
            })
            // this.setState({
            //    // check_all: false,
            // })

         } else if (fieldName === 'select_all') {
            new_updated_student = _updated_student.map((item) => {
               item.checked = !this.state.check_all;
               return item;
            })
            this.setState({
               check_all: !this.state.check_all,
            })
         }

         const _printable_record = this.state.update_student.filter((item) => {
            if (item.checked) {
               return item
            }
         })

         setTimeout(() => {
            this.setState({
               updated_student: new_updated_student,
               printable_record: _printable_record
            })
         }, 200);
      }
   };

   generateSheduleObjOfClass() {
      const _fltr_class = this.props.filteredClassesData;
      // const _fltr_school = this.props.filteredSchoolData;
      
      const { seleced_shedule } = this.state;
      
      // console.log(_fltr_class);
      // console.log(_fltr_school);
      // console.log(seleced_shedule);
      // debugger
      const new_array = [];

      const _class_shedule = seleced_shedule.shedule.classes_shedule.filter((item) => {
         if (item.id === _fltr_class.slct_cls_id) {
            return item
         }
      })
      _class_shedule[0].innings_arr.forEach((item) => {
         const _date = item.x_exam_subject.exam_date;
         item.x_exam_subject.innings.forEach((inn_item) => {
            if (inn_item.selected_sub) {
               const obj = {
                  exam_date: _date,
                  exam_subject: inn_item.selected_sub,
                  inning_time: inn_item.inning_time
               }
               new_array.push(obj)
            }
         });
      })

      const new_obj = {
         class_shedule: new_array,
         school_info: seleced_shedule.shedule.school_info,
         shedule_note: seleced_shedule.shedule.shedule_note,
         identity_card_note: seleced_shedule.shedule.identity_card_note,
         innings: seleced_shedule.shedule.innings,
         notes: seleced_shedule.shedule.notes,
         instructions: seleced_shedule.shedule.instructions,
         exam_name: seleced_shedule.shedule.exam_name
      }
      //const final_shedule = {...seleced_shedule, shedule : new_obj}
      this.setState({
         class_shedule_obj: new_obj
      })
   }
   // generateAllRecordForPrint() {
   //    const _stu_record = this.state.update_student;
   //    this.setState({
   //       printable_record: _stu_record,
   //       record_generted: true
   //    })
   // }
   // showSingleHandler(ev, id) {
   //    // debugger
   //    ev.preventDefault();
   //    const _all_record = this.state.update_student;
   //    const _get_record = _all_record.filter((item, index) => {
   //       if (item.id === id) {
   //          return item
   //       }
   //    })
   //    this.setState({
   //       printable_record: _get_record,
   //       record_generted: true
   //       //showSheduleData: !this.state.showSheduleData
   //    })
   // }

   // filterClassesOnSchool(sch_id, group_id) {
   //    const _classes = this.props.classes.filter((item) => {
   //       if (item.group_id === group_id && item.school_id === sch_id) {
   //          return item
   //       }
   //    })
   //    this.setState({
   //       selected_classes: _classes,
   //       selected_class_inx: 'All'
   //    })
   // }

   // filterSchoolOnSchool(sch_id) {
   //    const _school = this.props.schools.filter((item) => {
   //       if (item.id === sch_id) {
   //          return item
   //       }
   //    })

   //    this.setState({
   //       sch_name: _school[0].sch_name,
   //       sch_address: _school[0].sch_address
   //    })
   // }

   filterSheduleOnSchool(sch_id) {
      const final_arr = this.props.examSdul.map((item) => {
         // let shedule_data = JSON.parse(item.shedule); // admin and supper admin

         let shedule_data = item.shedule;
         item['shedule'] = shedule_data;
         return item
      })
      const _shedules = final_arr.filter((item) => {
         if (item.school_id === sch_id) {
            return item
         }
      })

      this.setState({
         shedule_arr: [..._shedules],// final_arr,
         selected_sch_shedule: _shedules
      })
   }
   componentDidMount() {
      if (isEmptyObj(this.props.schools)) {
         this.props.getSchools();
      }
      if (isEmptyObj(this.props.classes)) {
         this.props.getClasses();
      }
      if (isEmptyObj(this.props.examsCategory)) {
         this.props.getExamsCategory();
      }
      if (isEmptyObj(this.props.examSdulNotes)) {
         this.props.getExamSdulNotes();
      }
      if (isEmptyObj(this.props.examSdul)) {
         this.props.getExamSdul();
      }
      if (isEmptyObj(this.props.students)) {
         this.props.getStudents();
      }
      this.checkFlag();
   }


   checkFlag() {
      setTimeout(() => {
         const _filter = this.props.filteredSchoolData;
         const _examSdul = this.props.examSdul;
         if (_examSdul && _filter) {
            this.filterBySchoolHandler();
         } else {
            this.checkFlag()
         }
      }, 100);
   }

   filterBySchoolHandler = () => {
      const _filter = this.props.filteredSchoolData;
      // const _all_student = this.props.students;
      // if (!isEmpty(_all_student)) {
      //    const _school_student = _all_student.filter((item) => {
      //       if (_filter.slct_school_id) {
      //          if (item.school_id === _filter.slct_school_id) {
      //             return item
      //          }
      //       } else {
      //          return item
      //       }
      //    })
      //    this.setState({
      //       display_student: _school_student,
      //    }, () => this.filterByClsHandler())
      // }

      this.setState({
         printable_record: [],
         update_student: [],
         check_all: false,
         record_generted: false,
         showSheduleData: false
      }, () => {
         this.filterSheduleOnSchool(_filter.slct_school_id);
         this.filterByClsHandler();
      })
   }

   filterByClsHandler = () => {
      const _fltr_class = this.props.filteredClassesData;
      // const _fltr_school = this.props.filteredSchoolData;
      // const _all_student = this.props.students;
      // if (_all_student) {
      //    const _school_student = _all_student.filter((item) => {
      //       if (!isEmpty(_fltr_class.slct_cls_name)) {
      //          if (item.school_id === _fltr_school.slct_school_id &&
      //             item.stu_class === _fltr_class.slct_cls_name) {
      //             return item
      //          }
      //       } else {
      //          if (item.school_id === _fltr_school.slct_school_id) {
      //             return item
      //          }
      //       }
      //    })
      //    this.setState({
      //       display_student: _school_student
      //    })
      // }
      // debugger
      this.setState({
         selected_shedule_inx: "",
         showSheduleData: false,
         record_generted: false,
         check_all: false
      }, () => {
         this.getStudentsofaClassHandler(_fltr_class.slct_cls_name);
      });
   }


   //  checkAuthentication(obj) {
   //    loadProgressBar();
   //    axios.post(VALIDATE_URL, obj)
   //      .then(res => {
   //        const getRes = res.data;
   //        // sessionStorage.setItem("user", getRes.data);
   //        console.log(getRes);
   //        if (getRes.data) {
   //          this.setState({
   //            user: getRes.data,
   //            group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
   //            school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
   //            user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
   //            session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
   //          }, () => {
   //             this.getSchoolHandler();
   //             this.getExamShedules();
   //             this.getExamsCategories();
   //             this.getClassesHandler();
   //             this.getSheduleNotes();
   //          })
   //        }
   //      }).catch((error) => {
   //        this.props.history.push('/login.jsp');
   //      })
   //  }

   // getSheduleNotes() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //       exam_id: this.state.exam_name,
   //    }
   //    // console.log(JSON.stringify(obj));
   //    // debugger;
   //    axios.post(READ_SDUL_NOTE, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          let _notes = [];
   //          getRes.forEach((item) => {
   //             _notes.push({ "note": item.notes })
   //          })
   //          this.setState({
   //             notes: _notes,
   //             // updated_subjects: [...this.state.updated_subjects, getRes],
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   getStudentsofaClassHandler(class_id) {
      const _fltr_school = this.props.filteredSchoolData;
      const school_id = _fltr_school.slct_school_id;
      const _students = this.props.students;
      const class_student = _students.filter(item => {
         if (item.stu_class === class_id && item.school_id === school_id) {
            return item
         }
      })

      const updated_student = class_student.map(item => {
         item = { ...item, checked: false }
         return item
      })
      this.setState({
         update_student: updated_student,
      });


      // loadProgressBar();
      // const obj = {
      //    group_id: this.state.group_id,
      //    school_id: this.state.school_id,
      //    class_id: this.state.selected_class_id,
      //    session_year_id: this.state.session_year_id,
      // }
      // console.log(JSON.stringify(obj))
      // // debugger
      // axios.post(GET_STUDENTS_BY_CLASS, obj)
      //    .then(res => {
      //       const resData = res.data.records;
      //       if (resData.length > 0) {
      //          const _resData = resData.map(item => {
      //             item = { ...item, checked: false }
      //             return item
      //          })
      //          this.setState({
      //             update_student: _resData,
      //             errorMessages: resData.message
      //          });
      //       } else {
      //          Alert.error(res.data.message, {
      //             position: 'bottom-right',
      //             effect: 'jelly',
      //             timeout: 5000, offset: 40
      //          });
      //       }
      //    }).then(res => {
      //    })
      //    .catch((error) => {
      //       // error
      //    });
   }
   // getClassesHandler() {
   //    // read all existing class
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id,
   //    }
   //    axios.post(READ_CLASS_URL, obj)
   //       .then(res => {
   //          const resData = res.data;
   //          const _classes = resData.filter((item, index) => {
   //             if (item.is_section !== 'Yes') {
   //                return item;
   //             }
   //          })
   //          this.setState({
   //             classes: _classes,
   //             errorMessages: resData.message
   //          });
   //          //console.log(this.state.classes);
   //       }).then(res => {
   //       })
   //       .catch((error) => {
   //          // error
   //       });
   // }
   // getExamsCategories() {
   //    loadProgressBar();
   //    axios.get(READ_EXAM_CATE)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             exams: getRes,
   //             errorMessages: getRes.message
   //          })
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // getExamShedules() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id,
   //       school_id: this.state.school_id,
   //       user_category: this.state.user_category,
   //       session_year_id: this.state.session_year_id
   //    }
   //    console.log(JSON.stringify(obj));
   //    axios.post(READ_SHEDULE, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          if (!isEmpty(getRes.message)) {
   //             Alert.success(getRes.message, {
   //                position: 'bottom-right',
   //                effect: 'jelly',
   //                timeout: 5000, offset: 40
   //             });
   //          } else {
   //             this.setJsonToSheduleObject(getRes.db_data);
   //          }
   //       }).catch((error) => {
   //          // error
   //       })
   // }
   // setJsonToSheduleObject(data) {
   //    const final_arr = data.map((item) => {
   //       let shedule_data = JSON.parse(item.shedule);
   //       item['shedule'] = shedule_data;
   //       return item
   //    })
   //    this.setState({
   //       shedule_arr: final_arr
   //    })
   // }

   // getSchoolHandler() {
   //    loadProgressBar();
   //    const obj = {
   //       group_id: this.state.group_id
   //    }
   //    axios.post(READ_SCHOOLS, obj)
   //       .then(res => {
   //          const getRes = res.data;
   //          this.setState({
   //             schools: getRes,
   //             errorMessages: getRes.message
   //          });
   //          // console.log(this.state);
   //       }).catch((error) => {
   //          // error
   //       })
   // }

   getExamCatNameHandler(exam_id) {
      const _exams = this.props.examsCategory;
      const _selected_obj = _exams.filter((item) => {
         if (item.id === exam_id) {
            return item
         }
      })
      if (!isEmpty(_selected_obj[0])) {
         return _selected_obj[0].cat_name;
      } else {
         return false;
      }
   }
   viewSheduleHandler(ev, sdul_id) {
      ev.preventDefault();
      const _shedule_arr = this.state.shedule_arr;
      const selected_data = _shedule_arr.filter((item) => {
         if (item.id === sdul_id) {
            return item
         }
      })
      this.setState({
         final_shedule: selected_data[0].shedule,
         showSheduleData: true
      })
   }
   printHandler(e) {
      window.print()
      var divToPrint = document.getElementsByClassName('page-wrapper');
      divToPrint[0].classList.remove('print');
      this.setState({
         generate_report_card: false,
         update_reportCard_data: false,
      });
   }
   showReportCard() {
      //debugger
      if (this.state.printable_record.length === 0) {
         Alert.error("Plese Select Records First using Checkbox.!!", {
            position: 'bottom-right',
            effect: 'jelly',
            timeout: 5000, offset: 40
         });
      } else {
         // show Report Card
         var divToPrint = document.getElementsByClassName('page-wrapper');
         if (!this.state.showSheduleData) {
            divToPrint[0].classList.add('print');
         } else {
            divToPrint[0].classList.remove('print');
         }
         this.setState({
            showSheduleData: !this.state.showSheduleData
         })
      }
   }
   // hideSheduleHandler(ev){
   //    ev.preventDefault();
   //    this.setState({
   //       showSheduleData: !this.state.showSheduleData
   //    })
   // }
   render() {
      const { update_student, selected_sch_shedule, showSheduleData, class_shedule_obj,
         notes, selected_shedule_inx, printable_record, 
         flag_filter_class, formIsHalfFilledOut } = this.state;
      const { user, schools, classes, examsCategory, examSdulNotes, examSdul, students ,filteredClassesData } = this.props;
      console.log(this.state);
      return (
         <div id="printarea_1" className="page-content">
            <Helmet>
               <title>Exam Schedule</title>
            </Helmet>
            <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
            <div id="printarea" className="page-bar d-flex">
               <div className="page-title">Print Class wise Shedule</div>
               {user && schools && classes && examsCategory && examSdulNotes && examSdul && students &&
                  <div className="form-inline ml-auto filter-panel">
                     <span className="filter-closer">
                        <button type="button" className="btn btn-danger filter-toggler-c">
                           <i className="fa fa-times"></i>
                        </button>
                     </span>
                     <div className="filter-con">
                        {/* <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Schools :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='school'
                              value={selected_school_index}
                              onChange={event => this.changeHandler(event, 'school')}>
                              <option value="">Select ...</option>
                              {schools.map((item, index) => {
                                 return (
                                    <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                                 )
                              })}
                           </select>
                        </div>
                        <div className="form-group mr-2 mt-1">
                           <label className="control-label mr-2">Medium :</label>
                           <select className="form-control form-control-sm"
                              required
                              ref='medium'
                              disabled={medium_arr.length > 1 ? false : true}
                              value={medium}
                              onChange={event => this.changeHandler(event, 'medium')}>
                              <option value="">Select ...</option>
                              {medium_arr.map((item, index) => {
                                 return (
                                    <option key={index} value={item}>{item}</option>
                                 )
                              })}
                           </select>
                        </div>
                        {selected_classes.length > 0 ?
                           <div className="form-group mr-2 mt-1">
                              <label className="mr-2">Class:</label>
                              <select
                                 value={selected_class_inx}
                                 disabled={(medium === '' || selected_sch_shedule.length === 0) ? true : false}
                                 className="form-control form-control-sm" name="selected_class"
                                 onChange={event => this.changeHandler(event, 'selected_class')} >
                                 <option value="">Select...</option>
                                 {selected_classes.map((option, index) => {
                                    return (<option key={index} value={index}>{option.class_name}</option>)
                                 })}
                              </select>
                           </div>
                           : null} */}
                        <CommonFilters
                           showSchoolFilter={true}
                           showMediumFilter={false}
                           showClassFilter={true}
                           filterBySchoolHandler={this.filterBySchoolHandler}
                           filterByClsHandler={this.filterByClsHandler}
                        />

                        {(selected_sch_shedule.length > 0) ?
                           <div className="form-group mr-2 mt-1">
                              <label className="mr-2">Shedule:</label>
                              <select
                                 value={selected_shedule_inx}
                                 disabled={(filteredClassesData.slct_cls_id === '') ? true : false}
                                 className="form-control form-control-sm" name="selecte_shedule"
                                 onChange={event => this.changeHandler(event, 'selecte_shedule')} >
                                 <option value="">Select...</option>
                                 {selected_sch_shedule.map((option, index) => {
                                    return (<option key={index} value={index}>
                                       {index + 1}.
                                       {option.shedule.school_info.sch_name} _
                                 [ {this.getExamCatNameHandler(option.exam_id)} ]
                                    </option>)
                                 })}
                              </select>
                           </div>
                           : null}
                        <div className="form-group mt-1">

                           {/* <button className={"btn  btn-sm btn-secondary mr-2"}
                           disabled={(selected_class_inx !== "" && selected_shedule_inx !== "") ? false : true}
                           onClick={event => this.generateAllRecordForPrint(event)}>
                           Generate All
                        </button> */}
                           {(printable_record.length > 0 && !isEmpty(selected_shedule_inx)) ?
                              <button className={"btn  btn-sm btn-primary"}
                                 disabled={(printable_record.length > 0) ? false : true}
                                 onClick={event => this.showReportCard(event)}>
                                 {!showSheduleData ? "Show Time Shedule" : "Hide Time Shedule"}
                              </button>
                              :
                              null
                           }
                        </div>
                     </div>
                  </div>
               }
            </div>
            <div className="card card-box sfpage-cover">
               <div className="card-body sfpage-body">
                  <div className="table-scrollable">
                     {!showSheduleData ?
                        <table className="table table-striped table-bordered table-hover table-sm">
                           <thead className="text-center">
                              <tr>
                                 <th />
                                 <th>
                                    <div className="custom-control custom-checkbox">
                                       <input type="checkbox"
                                          checked={((printable_record.length > 0) &&
                                             (printable_record.length === update_student.length)) ? true : false}
                                          id="select_all" className="custom-control-input"
                                          onChange={event => this.checkHandler(event, 'select_all', true)} />
                                       <label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
                                    </div>
                                 </th>
                                 <th>Image</th>
                                 <th>Ern. No.</th>
                                 <th>Student Name and Father's Name  </th>
                                 <th>Class</th>
                                 <th>Roll No.</th>
                                 {/* <th>Action </th> */}
                              </tr>
                           </thead>
                           {update_student.length > 0 ?
                              <tbody>
                                 {update_student.map((item, index) => {
                                    return (
                                       <tr key={index} >
                                          <td>{index + 1}</td>
                                          <td className="text-center">
                                             <div className="custom-control custom-control-inline custom-checkbox m-0">
                                                <input type="checkbox"
                                                   checked={item.checked}
                                                   id={`check_` + index} name="customRadio" className="custom-control-input"
                                                   onChange={event => this.checkHandler(event, `select_this`, item.se_id)} />
                                                <label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
                                             </div>
                                          </td>
                                          <td className="text-center profile-pic">
                                             {item.student_image !== '' ?
                                                < img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
                                                : (item.gender === 'Boy' ?
                                                   <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
                                                   :
                                                   <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
                                             }

                                          </td>
                                          <td>{item.admission_number}</td>
                                          <td>
                                             {item.student_name}
                                             <br /> S/o  {item.father_name}</td>
                                          <td>{item.stu_class}</td>
                                          <td>{item.roll_number}</td>
                                          {/* <td>
                                             <div className="d-flex justify-content-center">
                                                <button className="btn btn-secondary mr-2 btn-sm"
                                                   value={item.id}
                                                   disabled={(selected_class_inx !== "" && selected_shedule_inx !== "") ? false : true}
                                                   onClick={event => this.showSingleHandler(event, item.id)}>
                                                   Generate
                                             </button>

                                                <button className={"btn  btn-sm btn-primary"}
                                                   disabled={record_generted ? false : true}
                                                   onClick={event => this.showReportCard(event)}>
                                                   Show
                                                </button>
                                             </div>
                                          </td> */}
                                       </tr>
                                    )
                                 })
                                 }
                              </tbody>
                              : null}
                        </table>
                        :
                        <React.Fragment>
                           <SingleShedulePrint
                              update_student={printable_record}
                              notes={notes}
                              shedule_obj={class_shedule_obj}
                           />
                        </React.Fragment>
                     }
                  </div>
               </div>
               {/* <div className="card-footer text-right">
                  <button className={"btn btn-sm mr-2 " + (!showSheduleData ? "btn-primary" : "btn-primary")}
                     disabled={(printable_record.length > 0) ? false : true}
                     onClick={event => this.showReportCard(event)}>
                     {!showSheduleData ? "Show Time Shedule" : "Hide Time Shedule"}
                  </button>
               </div> */}
            </div>
         </div>
      )
   }
}
function mapStateToProps(state) {
   const { item: user } = state.authentication;
   const { item: schools } = state.schools;
   const { item: classes } = state.classes;
   const { item: examsCategory } = state.examsCategory;
   const { item: examSdulNotes } = state.examSdulNotes;
   const { item: examSdul } = state.examSdul;
   const { item: students } = state.students;
   const filteredSchoolData = state.filteredSchoolData;
   const filteredClassesData = state.filteredClassesData;
   return {
      user, schools, classes, examsCategory, examSdulNotes, examSdul, students,
      filteredSchoolData, filteredClassesData
   };
}

const actionCreators = {
   getSchools: schoolsAction.getSchools,
   getClasses: classesAction.getClasses,
   getExamsCategory: examsCategoryAction.getExamsCategory,
   getExamSdulNotes: examSdulNotesAction.getExamSdulNotes,
   getStudents: studentsAction.getStudents,
   getExamSdul: examSdulAction.getExamSdul,
}

export default connect(mapStateToProps, actionCreators)(withRouter(PrintShedules));