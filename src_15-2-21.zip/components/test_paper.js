import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import QuizSummay from './testpaper/quizSummay';
import CurrentQuestion from './testpaper/currentQuestion';
import PaperTimer from './testpaper/paperTimer';
import AnsweredPanel from './testpaper/answeredPanel';
import ResultSummary from './testpaper/resultSummary';

class TestPaper extends Component {
	state = {
		selected_school_index: "",
		showResult: false,
		user:"ujagar",
		current_id : 1,
 current_ques_time : 100000, // in milisecond
 test_time : 500000, // in milisecond
 test_title : "",
 test_id : "",
 timer_pause : false, 
 total_marks_obtain : "", 
 total_negative_marks : "", 
  markeDType: [
    { mrk_id: 1, mrk_type: "Answered", counter : 0 },
    { mrk_id: 2, mrk_type: "Not Answered", counter : 4 },
    { mrk_id: 1, mrk_type: "Review Later", counter : 0 },
    { mrk_id: 3, mrk_type: "Not Visited", counter : 0 },
    { mrk_id: 4, mrk_type: "Answred and Revie Later", counter : 0 }
  ],
  quiz: [
    {
      id: 1,
      detail: {
        question: "Which one is correct team name in NBA?",
        options: [
          { id: 1, opt: "New York Bulls" },
          { id: 2, opt: "Los Angeles Kings" },
          { id: 3, opt: "Golden State Warriros" },
          { id: 4, opt: "Huston Rocket" }
        ],
        answer: "2",
        markAS: "3"
      }
    },
    {
      id: 2,
      detail: {
        question: "5 + 7 = ?",
        options: [
          { id: 1, opt: "10" },
          { id: 2, opt: "11" },
          { id: 3, opt: "12" },
          { id: 4, opt: "13" }
        ],
        answer: "2",
        markAS: "3"
      }
    },
    {
      id: 3,
      detail: {
        question: "12 - 8 = ?",
        options: [
          { id: 1, opt: "1" },
          { id: 2, opt: "2" },
          { id: 3, opt: "3" },
          { id: 4, opt: "4" },
          { id: 5, opt: "20" }
        ],
        answer: "2",
        markAS: ""
      }
    },
    {
      id: 4,
      detail: {
        question: "What is the capital of Maharashtra?",
        options: [
          { "id": 1, "opt": "Mumbai" },
          { "id": 2, "opt": "Nagpur" },
          { "id": 3, "opt": "Pune" },
          { "id": 4, "opt": "Amaravati" }
        ],
        answer: "2",
        markAS: ""
      }
    }
  ]

	}
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	componentDidMount() {
		 
	}

	showInstruction(event) {
		event.preventDefault();

	}
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}
	submitTest(event) {
		event.preventDefault();
		this.setState({
			showResult: !this.state.showResult
		})
	}

	 
	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium, showResult,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (

			<div>
				<div className="paper-headr-sec d-flex mb-3 justify-content-between">
					<div className="institute-title">JyotiSSS</div>
					<PaperTimer/>
					<div className="action-full">
						<button className="btn btn-outline-primary btn-sm">Full Screen</button>
					</div>
				</div>
				<div className="card-paper d-flex">
					{!showResult ?
						<>
							<div className="card left-test-panel border-primary">
								<div className="card-header"><strong className="mr-2">Test :</strong>Test Title Here...</div>
								<CurrentQuestion/>
								<div className="card-footer">
									<div className="d-flex">
										<button className="btn btn-primary btn-sm">Review Later &amp; Next</button>
										<button className="btn btn-outline-danger btn-sm ml-2">Reset</button>
										<button className="btn btn-success btn-sm ml-auto">Save &amp; Next</button>
									</div>
								</div>
							</div>
							<div className="paper-info right-test-panel">
								<div className="inst-panel bg-primary">
									<div className="student-data d-flex justify-content-center">
										<img classname="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" />
										<div className="user_name">Ujagar Singh Meena</div>
									</div>
								</div>
								<AnsweredPanel/>
								<div className="inst-info-panel">
									<QuizSummay/>
									<button
										type="button"
										onClick={event => this.prevStep(event)}
										className="btn btn-default btn-block">Review instruction</button>
								</div>
								<div className="button-group">
									<button
										type="button"
										className="btn btn-primary btn-lg btn-block"
										onClick={event => this.submitTest(event)}
									>Submit Test</button>
								</div>
							</div>
						</>
						:
						<ResultSummary/>

					}
				</div>
			</div>
		)
	}
}
export default withRouter(TestPaper);