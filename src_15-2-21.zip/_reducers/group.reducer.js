import { groupConstants } from '../_constants';

export function group(state = {}, action) {
  switch (action.type) {
    case groupConstants.GROUP_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case groupConstants.GROUP_SUCCESS:
      return {
        item: action.response
      };
    case groupConstants.GROUP_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}