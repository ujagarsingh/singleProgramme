import { accEntryRefsConstants } from '../_constants';

export function accEntryRefs(state = {}, action) {
  switch (action.type) {
    case accEntryRefsConstants.READ_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefsConstants.READ_ENTRY_REF_SUCCESS:
      // const new_arr = [action.response, ...state.item];
      return {
        item: action.response,
        loading: false,
      };
    case accEntryRefsConstants.READ_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };



    case accEntryRefsConstants.UPDATE_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefsConstants.UPDATE_ENTRY_REF_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accEntryRefsConstants.UPDATE_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };


    case accEntryRefsConstants.DELETE_ENTRY_REF_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryRefsConstants.DELETE_ENTRY_REF_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accEntryRefsConstants.DELETE_ENTRY_REF_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}