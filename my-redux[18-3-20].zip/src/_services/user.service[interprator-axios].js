// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
// const USER_URL = "http://www.ujagarsingh.com/demo/login/api/";
const USER_URL = "http://www.rajpsp.com/api/";
export const userService = {
    login,
    logout,
    register,
    getAll,
    getById,
    update,
    delete: _delete
};

function login(username, password) {

    const url = USER_URL + 'login.php';

    const obj = { email: username, password: password }
    debugger
    return Axios.post(url, obj)
        .then()
        .catch(error => {
            console.log(error)
        })
        .then(user => {
            console.log(user)
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('user', JSON.stringify(user));

            return user;
        });

}

function logout() {
    // // debugger;
    // remove user from local storage to log user out
    localStorage.removeItem('user');
}

function getAll() {
    const url = USER_URL + 'read.php';
    const user = authHeader();
    // // debugger;
    return Axios.get(url).then();
}

function getById(id) {

    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
     debugger;
    return fetch(`/users/${id}`, requestOptions).then();
}


function PostData(type, userData) {

}

function register(user) {
    const url = USER_URL + 'create_user.php';

    // debugger
    return Axios.post(url, user).then();

}

function update(user) {
    const requestOptions = {
        method: 'PUT',
        headers: { ...authHeader(), 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    };
    // // debugger;
    return fetch(`/users/${user.id}`, requestOptions).then();;
}

// prefixed function name with underscore because delete is a reserved word in javascript
function _delete(id) {
    const requestOptions = {
        method: 'DELETE',
        headers: authHeader()
    };
    // // debugger;
    return fetch(`/users/${id}`, requestOptions).then();
}

function handleResponse(response) {
    console.log(response);
    debugger;
    //const data = text && JSON.parse(text);
    if (!response.statusText === 'OK') {
        if (response.status === 401) {
            // auto logout if 401 response returned from api
            logout();
            window.location.reload(true);
        }

        const error = (response.data && response.data.message) || response.statusText;
        return Promise.reject(error);
    }
    debugger;
    return response.data;
}
/*
Axios.interceptors.request.use(request=>{
    debugger
    console.log(request);
    return request;
}, error =>{
    console.log(error);
    return Promise.reject(error)
})
Axios.interceptors.response.use(response=>{
    debugger
    console.log(response);
    return response;
}, error =>{
    console.log(error);
    return Promise.reject(error)
})*/