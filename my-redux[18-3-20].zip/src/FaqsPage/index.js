import React, { Component } from 'react';  
import faqs  from "./faqs"
// const FaqsPage = ({  classes }) => {  
class FaqsPage extends React.Component {  
  state = {
    faqs : faqs,
    inx : 0
  }
     
    generateHtml2(itemArr){
      
      return (itemArr.map((item, index)=>{
        let _aflatoon = index + Math.floor(1000 + Math.random() * 9000);
        return (
            <div key={index} className="card">
              <div className="card-heading" id={"heading_"+_aflatoon} role="tab">
                  <h4 className="card-title mb-0">
                      <a className="d-flex collapsed" role="button" data-toggle="collapse" 
                      data-parent="#accordion" 
                      href={"#collapse_"+_aflatoon} aria-expanded="false" aria-controls={"collapse_"+_aflatoon}>
                        {item.title }  {}
                        <i className="ml-auto las la-plus"></i>
                      </a>
                  </h4>
              </div>
              <div className="card-collapse collapse" id={"collapse_"+_aflatoon} role="tabcard" aria-labelledby={"heading_"+_aflatoon}>
                <div className="card-body pxlr-faq-body">
                  <ol>
                      <li>
                      {item.body}
                      </li>
                  </ol>
                  {(item.child.length > 0) ? this.generateHtml2(item.child) : null }
                </div> 
              </div>
            </div>
          )
        }))
    }
  render(){
    const {faqs} = this.state;
    return (  
      <div>  
        <div>
  {/* Hero */}
  <div className="ui-hero hero-sm bg-dark-gray hero-svg-layer-4">
    <div className="container">
      <h1 className="heading">
        FAQs
      </h1>
      <p className="paragraph">
        HTML CSS FAQ / Nice Accordion
      </p>
    </div>{/* .container */}
  </div>{/* .hero */}
  {/* Main Wrapper */}
  <div className="main" role="main">
    {/*  Section */}
    <div className="section contact-section">
      <div className="container">
        <div className="pxlr-club-faq">
          <div className="faq-card-group" id="accordion" role="tablist" aria-multiselectable="true">
            {this.generateHtml2(faqs)}
          </div>
        </div>
      </div>{/* .container */}
    </div>{/* .section */}
    {/* Footer */}
    <footer className="ui-footer bg-gray">
      <div className="container pt-6 pb-6">
        <div className="row">
          <div className="col-md-4 col-sm-6 footer-about footer-col
                      center-on-sm">
            <img src="assets/img/logo/shala-darpan-logo-white.png" data-uhd alt="Applif - Online School Managment" />
            <p className="mt-1">
              Lorem ipsum dolor sit amet, consectetur
              adipisicing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna aliqua.
              Donec elementum ligula eu sapien consequat
              eleifend.
            </p>
          </div>
          <div className="col-md-2 col-xs-6 footer-col">
            {/*<h6 className="heading footer-heading">Quick Nav</h6>
                  <ul className="footer-nav">
                      <li>
                          <a href="demo-mobile-app-1.html">Mobile App 1</a>
                      </li>
                      <li>
                          <a href="demo-mobile-app-2.html">Mobile App 2</a>
                      </li>
                      <li>
                          <a href="demo-saas.html">Mobile Saas</a>
                      </li>
                      <li>
                          <a href="index.html">Web App</a>
                      </li>
                      <li>
                          <a href="index.html#demos">More Demos</a>
                      </li>
                  </ul>*/}
          </div>
          <div className="col-md-2 col-xs-6 footer-col">
            {/*<h6 className="heading footer-heading">Other Pages</h6>
                  <ul className="footer-nav">
                      <li>
                          <a href="page-api-docs.html">API Docs</a>
                      </li>
                      <li>
                          <a href="page-pricing.html">Pricing Page</a>
                      </li>
                      <li>
                          <a href="page-contact.html">Contact page</a>
                      </li>
                      <li>
                          <a href="page-blog-grid.html">Blog Grid</a>
                      </li>
                      <li>
                          <a href="page-coming-soon.html">Comig Soon</a>
                      </li>
                      <li>
                          <a href="page-404.html">404 Error</a>
                      </li>
                  </ul>*/}
          </div>
          <div className="col-md-4 col-sm-6 footer-col center-on-sm">
            <h6 className="heading footer-heading">Newsletter</h6>
            {/* Form */}
            <form autoComplete="on" id="sign-up-form" name="sign-up-form">
              <div className="form-group">
                <div className="input-group">
                  {/* Email Input */}
                  <input autoComplete="email" className="input
                                      form-control" data-validation="required" data-validation-error-msg="Please
                                      enter your email" name="email" placeholder="Email" />
                  <div className="input-group-append">
                    {/* Submit Button */}
                    <button className="btn
                                          ui-gradient-green">Subscribe
                      <span className="las
                                              la-paper-plane" /></button>
                  </div>
                </div>
              </div>
            </form>
            <div>
              <a className="btn ui-gradient-blue btn-circle
                              shadow-md">
                <span className="la la-facebook" />
              </a>
              <a className="btn ui-gradient-peach btn-circle
                              shadow-md">
                <span className="la la-instagram" />
              </a>
              <a className="btn ui-gradient-green btn-circle
                              shadow-md">
                <span className="la la-twitter" />
              </a>
              <a className="btn ui-gradient-purple btn-circle
                              shadow-md">
                <span className="la la-pinterest" />
              </a>
            </div>
          </div>
        </div>{/* .row */}
      </div>{/* .container */}
      {/* Footer Copyright */}
      <div className="footer-copyright bg-dark-gray">
        <div className="container">
          <div className="row">
            {/* Copyright */}
            <div className="col-sm-6 center-on-sm">
              <p>
                © 2017 <a href="http://codeytech.com" target="_blank" title="Codeytech">Codeytech</a>
              </p>
            </div>
            {/* Social Icons */}
            <div className="col-sm-6 text-right">
              <ul className="footer-nav">
                <li>
                  <a href="#">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#">
                    Terms &amp; Conditions
                  </a>
                </li>
                <li>
                  <a href="#">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>{/* .container */}
      </div>{/* .footer-copyright */}
    </footer>{/* .ui-footer */}
  </div>{/* .main */}
</div>

      </div>
    );  
    };  
  };  
  
export default FaqsPage 