import React, { Component } from 'react';  
import { Route } from 'react-router-dom';  
  
const LoginLayout = ({ children }) => (                         
    <div class="d-flex h-100" style={{"height":"100vh"}}>
        <div class="m-auto">
          <div class="jumbotron">
            {children}
          </div>
        </div>
    </div>
  );  
  
  const LoginLayoutRoute = ({component: Component, ...rest}) => {  
    return (  
      <Route {...rest} render={matchProps => (  
        <LoginLayout>  
            <Component {...matchProps} />  
        </LoginLayout>  
      )} />  
    )  
  };  
  
export default LoginLayoutRoute; 