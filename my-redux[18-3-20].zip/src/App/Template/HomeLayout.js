import React, { Component } from 'react';  
import { Route } from 'react-router-dom';  
  
const HomeLayout = ({ children }) => (                         
    <div>  
      <nav className="navbar navbar-fixed-top transparent_ navbar-dark bg-dark-gray">
    <div className="container">
      {/* Navbar Logo */}
      <a className="ui-variable-logo navbar-brand" href="index.html" title="RajPSP - Online School Managment">
        {/* Default Logo */}
        <img className="logo-default" src="assets/img/logo/shala-darpan-logo-white.png" alt="RajPSP - Online School Managment" data-uhd />
        {/* Transparent Logo */}
        <img className="logo-transparent" src="assets/img/logo/shala-darpan-logo-white.png" alt="RajPSP - Online School Managment" data-uhd />
      </a>{/* .navbar-brand */}
      {/* Navbar Navigation */}
      <div className="ui-navigation navbar-center">
        <ul className="nav navbar-nav">
          {/* Nav Item */}
          <li>
            <a href="#" data-scrollto="features">Features</a>
          </li>
          {/* Nav Item */}
          <li>
            <a href="#" data-scrollto="modules-of-online-school-managment">Modules</a>
          </li>
          {/* Nav Item */}
          <li>
            <a href="#" data-scrollto="used-technology">Used Technology</a>
          </li>
          {/* Nav Item */}
          <li>
            <a href="#" data-scrollto="pricing">Pricing</a>
          </li>
          <li>
            <a href="/faqs" >Faq</a>
          </li>
          {/* Nav Item */}
          <li className="active">
            <a href="contact.html">Contact</a>
          </li>
        </ul>{/*.navbar-nav */}
      </div>{/*.ui-navigation */}
      {/* Navbar Button */}
      <a href="/login" className="btn btn-sm ui-gradient-peach pull-right">Login</a>
	  <a href="/register" className="btn btn-sm ui-gradient-peach pull-right">Registration</a>
      {/* Navbar Toggle */}
      <a href="#" className="ui-mobile-nav-toggle pull-right" />
    </div>{/* .container */}
  </nav> {/* nav */}
      {children}                                       
  </div>
  );  
  
  const HomeLayoutRoute = ({component: Component, ...rest}) => {  
    return (  
      <Route {...rest} render={matchProps => (  
        <HomeLayout>  
            <Component {...matchProps} />  
        </HomeLayout>  
      )} />  
    )  
  };  
  
export default HomeLayoutRoute; 