import React, { Component } from 'react';  
import { Route } from 'react-router-dom';  
  
const HomeInnerLayout = ({ children }) => (                         
    <div>  
      <nav className="navbar navbar-fixed-top transparent_ navbar-dark bg-dark-gray">
    <div className="container">
      <a className="ui-variable-logo navbar-brand" href="index.html" title="RajPSP - Online School Managment">
        <img className="logo-default" src="assets/img/logo/shala-darpan-logo-white.png" alt="RajPSP - Online School Managment" data-uhd />
        <img className="logo-transparent" src="assets/img/logo/shala-darpan-logo-white.png" alt="RajPSP - Online School Managment" data-uhd />
      </a>
      <div className="ui-navigation navbar-center">
        <ul className="nav navbar-nav">
          <li>
            <a href="#" data-scrollto="features">Features</a>
          </li>
          <li>
            <a href="#" data-scrollto="modules-of-online-school-managment">Modules</a>
          </li>
          <li>
            <a href="#" data-scrollto="used-technology">Used Technology</a>
          </li>
          <li>
            <a href="#" data-scrollto="pricing">Pricing</a>
          </li>
          <li>
            <a href="/faqs" >Faqs</a>
          </li>
          <li className="active">
            <a href="contact.html">Contact</a>
          </li>
        </ul>
      </div>
      <a href="/login" className="btn btn-sm ui-gradient-peach pull-right">Login</a>
	    <a href="/register" className="btn btn-sm ui-gradient-peach pull-right">Registration</a>
      <a href="#" className="ui-mobile-nav-toggle pull-right" />
    </div>
  </nav> 
      {children}                                       
  </div>
  );  
  
  const HomeInnerLayoutRoute = ({component: Component, ...rest}) => {  
    return (  
      <Route {...rest} render={matchProps => (  
        <HomeInnerLayout>  
            <Component {...matchProps} />  
        </HomeInnerLayout>  
      )} />  
    )  
  };  
  
export default HomeInnerLayoutRoute; 