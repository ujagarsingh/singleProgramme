import React, { Component } from 'react';  
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';  
import { connect } from 'react-redux';

import { history } from '../_helpers';
import { alertActions } from '../_actions';
import { PrivateRoute } from '../_components';
import  HomePage  from '../HomePage/index';
import  FaqsPage  from '../FaqsPage/index';
import  DashboardPage  from '../DashboardPage/index';
import  LoginPage  from '../LoginPage/index';
import  RegisterPage  from '../RegisterPage/index';
  
/** Layouts **/  
import LoginLayoutRoute from "./Template/LoginLayout";  
import DashboardLayoutRoute from "./Template/DashboardLayout";  
import HomeLayoutRoute from "./Template/HomeLayout";  
import HomeInnerLayoutRoute from "./Template/HomeInnerLayout";  
  
/** Components **/  
// import UserPage from './Template/UserPage';  
// import LoginPage from './LoginPage'  


class App extends React.Component {
    constructor(props) {
        super(props);
		history.listen((location, action) => {
			// // debugger
            // clear alert on location change
            this.props.clearAlerts();
        });
    }

    render() {

        const { alert } = this.props;
        return (
            <>
                {alert.message &&
                    <div className={`alert ${alert.type}`}>{alert.message}</div>
                }
                <Router history={history}>
                    <Switch>
                       
                        <Route exact path="/">  
                            <Redirect to="/home" />  
                        </Route>  
                        <HomeLayoutRoute path="/home" component={HomePage} />  
                        <HomeInnerLayoutRoute path="/faqs" component={FaqsPage} />  
                        <LoginLayoutRoute path="/login" component={LoginPage} />  
                        <LoginLayoutRoute path="/register" component={RegisterPage} />  
                        <DashboardLayoutRoute path="/dashboard" component={DashboardPage} />  
                        <PrivateRoute path="/dashboard" component={DashboardPage} />
                        <Redirect from="*" to="/" />
                    </Switch>
                </Router>
            </>
        );
    }
}

function mapState(state) {
	// // debugger
    const { alert } = state;
    return { alert };
}

const actionCreators = {
	clearAlerts: alertActions.clear
};

export default connect(mapState, actionCreators)(App);

  