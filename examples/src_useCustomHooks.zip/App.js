import React from 'react';
import ScreenComponent from './ScreenComponent';
import useCounter from './useCounter';

export default function App() {
  const [counter, increment, decrement, reset] = useCounter(0)
  return (
    <div className="App border">
      <h1> Custom Hook Example</h1>
      <h2>{counter}</h2>
      <div>
        <button onClick={increment}>Increment</button>
        <button onClick={decrement}>Decrement</button>
        <button onClick={reset}>Reset</button>
      </div>
      <ScreenComponent />
    </div>
  );
}
