import React from 'react'
import useScreen from './useScreen'

export default function ScreenComponent() {
  const screenSize = useScreen();
  return (
    <div>
      <h1> ScreenComponent</h1>
      <h2> We are in { screenSize } Screen</h2>
    </div>
  )
}
