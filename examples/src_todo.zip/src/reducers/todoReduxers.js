const initialData = {
  list: []
}
export const todoReducers = (state = initialData, action) => {
  switch (action.type) {
    case value:

      break;
    default:
      return state;
  }

}