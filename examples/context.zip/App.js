import React, { useState } from 'react';
import './App.css';

import Component1 from './components/component1';
import { ContextProvider } from './context/context';

function App() {
  const [user, setUser] = useState('ujagar singh meena');
  return (
    <ContextProvider value={{text : user}}>
      <div className="App">
        <Component1 setUser={setUser}></Component1>
      </div>
    </ContextProvider>
  );
}

export default App;
