import React from 'react';

import { ContextConsumer } from '../context/context';

const Component1 = ({ text, setUser }) => {
  return <ContextConsumer>
    {(value) => {
        return <div>{value.text}</div>
      }}
  </ContextConsumer>
}

export default Component1;