import React from 'react';

import Component1 from './component1';

const Component2 = () => {
  return (
    <Component1> </Component1>
  )

}

export default Component2;