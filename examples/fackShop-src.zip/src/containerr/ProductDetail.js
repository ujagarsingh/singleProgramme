import Axios from 'axios'
import React, { useEffect, } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams, } from 'react-router-dom'
import { removeSelectedProduct, selectedProduct } from '../redux/actions/productActions';

function ProductDetail() {
  const product = useSelector(state => state.product)
  const { id, title, price, image, description, category } = product;
  const { productId } = useParams();
  const dispatch = useDispatch()

  useEffect(() => {
    if (productId && productId !== '') fetchProduct();
    return(()=>{
      dispatch(removeSelectedProduct())
    })
  }, [productId]);

  const fetchProduct = async () => {
    const product = await Axios
      .get(`https://fakestoreapi.com/products/${productId}`)
      .catch((error) => {
        console.log('Error', error)
      })
    dispatch(selectedProduct(product.data))
  }

  return (
    <div className='ui grid main container'>
      {(Object.keys(product).length === 0) ? (
        <div>...Loading</div>
      ) : (
        <div className='ui placeholder segment'>
          <div className='ui two column stackable center aligned grid'>
            <div className='ui vertical divider'>AND</div>
            <div className='middle aligned row'>
              <div className='column lp'>
                <img src={image} className='ui fluid image' alt={title} />
              </div>
              <div className='column rp'>
                <h1>{title}</h1>
                <h2>
                  <div className='ui teal tag label'>$ {price}</div>
                </h2>
                <h3 className='ui brown block header'>{category}</h3>
                <p>{description}</p>
                <div className='ui vertical animated button red large' tabIndex="0">
                  <div className='hidden content'>
                    <i className='shop icon'></i>
                  </div>
                  <div className='visible content'>Add to Cart</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ProductDetail
