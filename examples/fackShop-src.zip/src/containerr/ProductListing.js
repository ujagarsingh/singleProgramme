import React, { useEffect } from 'react'
import Axios from 'axios'
import ProductComponent from './ProductComponent';
import { useDispatch } from 'react-redux';
import { setProducts, fetchProducts } from '../redux/actions/productActions';

function ProductListing() {
  // const products = useSelector((state) => state.allProducts.products);
  const dispatch = useDispatch()

  // const fetchProducts = async () => {
  //   const response = await Axios
  //     .get('https://fakestoreapi.com/products')
  //     .catch((error) => {
  //       console.log('error', error)
  //     });
  //   dispatch(setProducts(response.data))
  // }

  useEffect(() => {
    dispatch(fetchProducts())
  }, []);

  // console.log("Products", products)
  return (
    <div className='ui main grid'>
      <ProductComponent></ProductComponent>
    </div>
  )
}

export default ProductListing
