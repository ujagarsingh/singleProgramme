import FakeAPI from "../../apis/fackStoreApi"
import { ActionTypes } from "../constants/action-types"

export const fetchProducts = () => {
  return async function (dispatch, getState) {
    const response = await FakeAPI.get("/products");
    dispatch({ type: ActionTypes.FETCH_PRODUCTS, payload: response.data })
  }
}

export const setProducts = (products) => {
  return {
    type: ActionTypes.SET_PRODUCTS,
    payload: products
  }
}

export const selectedProduct = (product) => {
  return {
    type: ActionTypes.SELECTED_PRODUCTS,
    payload: product
  }
}

export const removeSelectedProduct = () => {
  return {
    type: ActionTypes.REMOVE_SELECTED_PRODUCTS,
  }
}