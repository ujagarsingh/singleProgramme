import React from 'react';
import { BrowserRouter as Router, Route, Switch, NavLink } from 'react-router-dom'
import AccountComponent from './pages/AccountComponent';
import Cards from './pages/CardComponent';
import Home from './pages/HomeComponent';
import ProtectedRoute from './ProtectedRoutes';
import useAuth from './useAuth';


const App = () => {
  const [isAuth, login, logout] = useAuth(false);
  return (
    <div className="ui container">
      <h2> Protected route tutorial</h2>
      <Router>
        <ul>
          <li> <NavLink exact to="/">Home Page</NavLink></li>
          <li> <NavLink to="/accounts">Account Page</NavLink></li>
          <li> <NavLink to="/cards">Cards Page</NavLink></li>
        </ul>
        
        {isAuth ? (
        <><div>You Are Logged In!</div><button onClick={logout}>Logout</button></>
        ) : (
        <><div>You Are Logged Out!</div><button onClick={login}>LogIn</button></>
        )}

        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/cards" component={Cards} />
          <ProtectedRoute path="/accounts" component={AccountComponent} auth={isAuth} />
        </Switch>
      </Router>
    </div>
  )
}

export default App;
