import React from 'react';

const Home = () => {
  return (
    <div className="ui container center">
      <div className="home-profile">
        <div className="ui message info">
          <h3>You are now on Home page</h3>
        </div>
      </div>
    </div>
  )
}

export default Home;