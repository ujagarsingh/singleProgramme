import React from 'react';

const Cards = () => {
  return (
    <div className="ui container center">
      <div className="home-profile">
        <div className="ui message info">
          <h3>This is your protected Route.</h3>
        </div>
      </div>
    </div>
  )
}

export default Cards;