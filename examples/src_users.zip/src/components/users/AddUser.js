import React, { useState } from 'react'
import { useHistory } from 'react-router-dom'
import Axios from 'axios';

export default function AddUser() {
  const history = useHistory();
  const [user, setUser] = useState({
    "name": '',
    "username": '',
    "email": '',
    "phone": '',
    "website": '',
  });

  const { name, username, email, phone, website } = user;
  const onChangeHandler = (ev) => {
    setUser({ ...user, [ev.target.name]: ev.target.value })
  }

  const onSubmitHandler = async (ev) => {
    ev.preventDefault();
    await Axios.post('http://localhost:3003/users', user);
    history.push('/')

  }
  return (
    <div className="container">
      <h3>Add User</h3>
      <div className="py-4">
        <form className="col-6 m-auto" onSubmit={ev => onSubmitHandler(ev)}>
          <div className="form-group mt-2">
            <input type="text" name="name" placeholder="Enter Name"
              value={name}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="username" placeholder="Enter UserName"
              value={username}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="email" name="email" placeholder="Enter Email"
              value={email}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="phone" placeholder="Enter Phone"
              value={phone}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="website" placeholder="Enter Website"
              value={website}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <button className="btn btn-secondary ml-auto">Add New User</button>
          </div>
        </form>
      </div>
    </div>
  )
}
