import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router'
import Axios from 'axios'
import { NavLink } from 'react-router-dom';

export default function User() {
  const { id } = useParams();
  const [user, setUser] = useState({
    "name": '',
    "username": '',
    "email": '',
    "phone": '',
    "website": '',
  })

  useEffect(() => {
    loadUser()
  }, [])

  const loadUser = async () => {
    const result = await Axios.get(`http://localhost:3003/users/${id}`)
    setUser((preUser) => preUser = result.data)
  }

  return (
    <div className="container">
      <h3>View User</h3>
      <div className="my-4">
        <NavLink className="btn btn-outline-primary" to="/">Back to Home</NavLink>
        <ul className="list-group">
          <li className="list-group-item">
            <span style={{ "width": "200px", "display": "inline-block" }}>Name :</span>
            <strong>{user.name}</strong>
          </li>
          <li className="list-group-item">
            <span style={{ "width": "200px", "display": "inline-block" }}>User Name :</span>
            <strong>{user.username}</strong>
          </li>
          <li className="list-group-item">
            <span style={{ "width": "200px", "display": "inline-block" }}>Email :</span>
            <strong>{user.email}</strong>
          </li>
          <li className="list-group-item">
            <span style={{ "width": "200px", "display": "inline-block" }}>Phone :</span>
            <strong>{user.phone}</strong>
          </li>
          <li className="list-group-item">
            <span style={{ "width": "200px", "display": "inline-block" }}>Website :</span>
            <strong>{user.website}</strong>
          </li>
        </ul>
      </div>
    </div>
  )
}
