import React, { useEffect, useState } from 'react'
import { NavLink, useHistory, useParams } from 'react-router-dom'
import Axios from 'axios';

export default function EditUser() {
  const history = useHistory();
  const { id } = useParams();
  const [user, setUser] = useState({
    "name": '',
    "username": '',
    "email": '',
    "phone": '',
    "website": '',
  });

  const { name, username, email, phone, website } = user;
  const onChangeHandler = (ev) => {
    setUser({ ...user, [ev.target.name]: ev.target.value })
  }

  const onSubmitHandler = async (ev) => {
    ev.preventDefault();
    await Axios.put(`http://localhost:3003/users/${id}`, user);
    history.push('/')
  }

  useEffect( () => {
    getUser();
  }, [])

  const getUser = async () => {
    const currentUser = await Axios.get(`http://localhost:3003/users/${id}`);
    setUser((preUser) => preUser = currentUser.data)
  }
  return (
    <div className="container">
      <h3>Edit [ {user.name} ] User</h3>
      <div className="py-4">
      <NavLink className="btn btn-outline-primary" to="/">Back to Home</NavLink>
        <form className="col-6 m-auto" onSubmit={ev => onSubmitHandler(ev)}>
          <div className="form-group mt-2">
            <input type="text" name="name" placeholder="Enter Name"
              value={name}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="username" placeholder="Enter UserName"
              value={username}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="email" name="email" placeholder="Enter Email"
              value={email}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="phone" placeholder="Enter Phone"
              value={phone}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <input type="text" name="website" placeholder="Enter Website"
              value={website}
              onChange={ev => onChangeHandler(ev)}
              className="form-control form-control-lg" />
          </div>
          <div className="form-group mt-2">
            <button className="btn btn-warning ml-auto">Update User</button>
          </div>
        </form>
      </div>
    </div>
  )
}
