import React from 'react'

export default function Contact() {
  return (
    <div className="container">
      <div className="py-4">
        <h3>Contact</h3>
      </div>
    </div>
  )
}
