import React, { useState, useEffect } from 'react'
import Axios from 'axios'
import { NavLink } from 'react-router-dom';

export default function Home() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await Axios.get('http://localhost:3003/users');
    setUsers((preResult) => preResult = result.data.reverse())
  }

  const deleteUserHandler = async (id) => {
    await Axios.delete(`http://localhost:3003/users/${id}`);
    loadUsers();
  }

  return (
    <div className="container">
      <div className="py-4">
        <h3>Home</h3>
        <table class="table table-hover border shadow">
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">User Name</th>
              <th scope="col">Email</th>
              <th scope="col">Email</th>
              <th scope="col">Actopm</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => {
              return (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{user.name}</td>
                  <td>{user.username}</td>
                  <td>{user.email}</td>
                  <td>
                    <NavLink className="btn btn-info" to={`/user/${user.id}`}>View</NavLink>
                    <NavLink className="btn btn-outline-primary mx-1" to={`/users/edituser/${user.id}`}>Edit</NavLink>
                    <button className="btn btn-danger" onClick={() => deleteUserHandler(user.id)}>Delete</button>
                  </td>
                </tr>
              )
            })}

          </tbody>
        </table>
      </div>
    </div>
  )
}
