import React from 'react'

export default function NotFound() {
  return (
    <div className="container">
      <div className="py-4">
        <h3>Not Found</h3>
      </div>
    </div>
  )
}
