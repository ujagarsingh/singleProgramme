import FakeAPI from "../../apis/fackStoreApi"
import { ActionTypes } from "../constants/action-types"

export const fetchProducts = () => {
  return async function (dispatch) {
    const response = await FakeAPI.get("/products");
    dispatch({ type: ActionTypes.FETCH_PRODUCTS, payload: response.data })
  }
}

export const setProducts = (products) => {
  return {
    type: ActionTypes.SET_PRODUCTS,
    payload: products
  }
}

export const selectedProduct = (product) => {
  return {
    type: ActionTypes.SELECTED_PRODUCTS,
    payload: product
  }
}
export const fetchSelectedProduct = (productId) => {
  return async (dispatch) => {
    const responce = await FakeAPI.get(`products/${productId}`)
    dispatch({type: ActionTypes.FETCH_SELECTED_PRODUCTS, payload : responce.data})
  }
}

export const removeSelectedProduct = () => {
  return {
    type: ActionTypes.REMOVE_SELECTED_PRODUCTS,
  }
}