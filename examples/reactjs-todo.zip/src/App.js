import React from 'react'
import Todo from './components/Todo'

const App = () => {
  return (
    <div>
      <Todo/>
    </div>
  )
}

export default App
