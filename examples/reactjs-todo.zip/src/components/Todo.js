import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addTodo, deleteTodo, removeTodos } from '../_actions';

const Todo = () => {
  const [inputData, setInputData] = useState('')
  const dispatch = useDispatch();
  const list = useSelector(state => state.list)

  const submitHandler = (e) => {
    e.preventDefault();
    dispatch(addTodo(inputData));
    setInputData('')
  }
  const deleteHandler = (e, id) => {
    e.preventDefault();
    dispatch(deleteTodo(id))
  }
  const clearAllHandler = (e) => {
    e.preventDefault();
    dispatch(removeTodos())
  }
  return (
    <div className="main-div">
      <div className="child-div">
        <figure>
          <figcaption>Add Your List Here</figcaption>
        </figure>
        <form className="addItems" onSubmit={e => submitHandler(e)}>
          <input type="text" placeholder="Add Items...."
            value={inputData}
            onChange={(e) => setInputData(e.target.value)} />
          <button
            className="add-button"
            onClick={(event) => submitHandler(event)}
            title="Submit Item"
            type="submit">
            <i className="fa fa-plus"></i>
          </button>
        </form>
        <div className="showItems">
          {list.map((item) => {
            return (
              <div key={item.id} className="eachItem">
                <span>{item.data}</span>
                <button
                  className="add-button"
                  title="Delete Item"
                  onClick={(event) => deleteHandler(event, item.id)}
                  type="button">
                  <i className="fa fa-trash-o"></i>
                </button>
              </div>
            )
          })}
        </div>
        <div className="finalAction">
          <button
            onClick={e => clearAllHandler(e)}
            className="btn btn-danger"
            type="button">Delete All</button>
        </div>
      </div>
    </div >
  )
}

export default Todo
