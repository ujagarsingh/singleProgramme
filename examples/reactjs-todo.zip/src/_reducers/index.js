import { combineReducers } from 'redux';
import todoReducers from './todoReduxers'

const rootReducer = combineReducers({
  todoReducers
})

export default rootReducer;