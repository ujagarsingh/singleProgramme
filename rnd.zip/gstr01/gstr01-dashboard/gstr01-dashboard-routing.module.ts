import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Gstr01DashboardComponent } from './gstr01-dashboard.component';

const routes: Routes = [{
  path : "",
  component : Gstr01DashboardComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Gstr01DashboardRoutingModule { }
