import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01DashboardRoutingModule } from './gstr01-dashboard-routing.module';
import { Gstr01DashboardComponent } from './gstr01-dashboard.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01DashboardComponent],
  imports: [
  	LanguageModule,
    GSTSharedModule,
    CommonModule,
    Gstr01DashboardRoutingModule
  ]
})
export class Gstr01DashboardModule { }
