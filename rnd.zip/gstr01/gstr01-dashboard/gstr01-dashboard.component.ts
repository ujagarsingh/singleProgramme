import { Component, OnInit } from '@angular/core';
declare var SagGridMP;

@Component({
  selector: 'app-gstr01-dashboard',
  templateUrl: './gstr01-dashboard.component.html',
  styleUrls: ['./gstr01-dashboard.component.scss']
})
export class Gstr01DashboardComponent implements OnInit {
  DashbordListGridObject : object;
  clientListGridObject1 : object;
  dropdownCofigJson = {
    selectedData : {
      formName          : 'gstr1',
    },
    showHideDropdown :  {
      showGetClientBtn  : false,
      month       : false,
      year        : true,
      period      : false,
      returnType  : false,
      clientList  : true,  
      gstnList    : true
    },
    enableDisableDropdown :{
      month       : false,
      year        : false,
      period      : false,
      returnType  : false,
    },
  }
  constructor() { }
  clientListColumn =[{
    'colType': 'checkBox',
     width : '50px',
     field: 'checkBox',
     'text-align' : 'center',
    },
    {
    header : 'S.No',
    field : 'sno',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Particulars',
    field : 'particulars',
    filter : true,
    width : '150px',
    'text-align' : 'left',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'April',
    field : 'april',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'May',
    field : 'may',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'June',
    field : 'june',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'July',
    field : 'july',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'August',
    field : 'august',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'September',
    field : 'september',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'October',
    field : 'october',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'November',
    field : 'november',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'December',
    field : 'december',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'January',
    field : 'january',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Febuary',
    field : 'febuary',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'March',
    field : 'march',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Total',
    field : 'total',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
]
  ngOnInit() {
    let sourceDiv = document.getElementById("gstrDashbordSummaryListGrid");
    this.DashbordListGridObject = this.designGrid(this.clientListColumn,[],sourceDiv);

     // gstrDashbordRateWiseListGrid
   let sourceDiv1 = document.getElementById("gstrDashbordRateWiseListGrid");
   this.clientListGridObject1 = this.designGrid(this.DashboardListColumn,[],sourceDiv1);
  }

  DashboardListColumn =[{
    'colType': 'checkBox',
     width : '50px',
     field: 'checkBox',
     'text-align' : 'center',
    },
    {
    header : 'S.No',
    field : 'sno',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Month',
    field : 'month',
    filter : true,
    width : '150px',
    'text-align' : 'left',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : '3%',
    field : '3%',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Total',
    field : 'total',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  ]


  designGrid(column ,row,gridSourceDiv){
    let gridData = {
      columnDef: column,
      rowDef: row,
      callBack :{
        "onRowClick":function(){
          
        }
      }
    };
   return SagGridMP(gridSourceDiv, gridData, true, true);
  }
}
