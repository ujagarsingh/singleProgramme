import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as sagCommonGstConstant from '../../gstCommonConstant';
import { share } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class Gstr01CommonService {
  gstReturnBaseUrl: string;
  gstBaseUrl: string;
  constructor(private http: HttpClient) {
    this.gstBaseUrl = sagCommonGstConstant.sagGstCommonConstant.gstReturnBaseUrl;
    this.gstReturnBaseUrl = sagCommonGstConstant.sagGstCommonConstant.gstReturnBaseUrl;

  }

  public _getAllSummary(data: any) {
    return this.http.post(`${this.gstReturnBaseUrl}/${data.formType}/invoiceSummary?yearId=${data.yearId}
    &monthId=${data.monthId}&mClientId=${data.mClientId}
    &gstnCid=${data.gstnCid}&sectionName=${data.sectionName}`, null);
  }

  public _getAllInvoiceDetails(data: any) {
    return this.http.post(`${this.gstReturnBaseUrl}/${data.formType}/invoiceSummaryDetails?yearId=${data.yearId}
    &monthId=${data.monthId}&mClientId=${data.mClientId}
    &gstnCid=${data.gstnCid}&sectionName=${data.sectionName}`, null);
  }

  public updateGstr1Summary(obj){
    //{"mClientId":92,"gstnCid":"2718","yearId":"4","monthId":"3"};
    return this.http.post(`${this.gstReturnBaseUrl}/updateGstr1Summary`, obj);
  }

  public _getGstr1SummaryCompareWithPortal(data: any) {
    return this.http.get(`${this.gstReturnBaseUrl}/${data.formType}/gstnSummeryDetails?mClientId=${data.mClientId}
    &yearId=${data.yearId}&monthId=${data.monthId}
    &gstnId=${data.gstnId}&periodName=${data.periodName}`);
  }

  public _getGstr1SummaryCompareWithPortalGstn(data: any) {
    return this.http.get(`${this.gstReturnBaseUrl}/${data.formType}/gstnSummeryDetailsGstnWise?mClientId=${data.mClientId}
    &yearId=${data.yearId}&monthId=${data.monthId}
    &gstnId=${data.gstnId}&periodName=${data.periodName}`);
  }

  public _getGstr1SummaryCompareWithPortalState(data: any) {
    return this.http.get(`${this.gstReturnBaseUrl}/${data.formType}/gstnSummeryDetailsStateWise?mClientId=${data.mClientId}
    &yearId=${data.yearId}&monthId=${data.monthId}
    &gstnId=${data.gstnId}&periodName=${data.periodName}`);
  }
  public getGstr1AllSummary(data) {
    return this.http.post(`${this.gstReturnBaseUrl}/getGstr1AllSummary`, data);
  }


  public ___getReturnStatusFromPortal(data: any) {

    return this.http.get(`${this.gstReturnBaseUrl}/getGstr1Status?returnPrd=${data.returnPrd}
    &gstnNo=${data.gstnNo}&mClientId=${data.mClientId}
    &yearId=${data.yearId}&gstnId=${data.gstnId}&monthId=${data.monthId}`);
  }

  public __getTurnoverAndReturnStatusData(data: any) {
    return this.http.get(`${this.gstReturnBaseUrl}/getTurnoverAndReturnStatusData?mClientId=${data.mClientId}
    &gstnId=${data.gstnId}&formType=${data.formType}
    &module=${data.module}&yearId=${data.yearId}`);
  }
  public getportalInsertedInfo(data: any) {
    return this.http.get(`${this.gstReturnBaseUrl}/getportalInsertedInfo?mClientId=${data.mClientId}
    &gstnId=${data.gstnId}&formType=${data.formType}`);
  }

  saveCurrentStatusInDB(json) {
    return this.http.post(`${this.gstReturnBaseUrl}/saveCurrentStatusInDB`, json);
  }

}
