import { Injectable } from '@angular/core';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import { ShareService } from 'genmaster/src/master/services/share.service';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

declare const $;
declare var SagGridMP;
declare function success(m)
declare function alerts(m)

@Injectable({
  providedIn: 'root'
})
export class PerviewService {

  constructor(private shareService: ShareService) { }
  summData: any;
  gstr1SumData: any;
  b2bLimitReached: any;
  summaryTime: any;
  sumryData: any;
  expadat: any;
  atadat: any;
  txpdat: any;
  txpadat: any;
  attdat: any;
  hsndat: any;
  pdfdoc: any;
  formData: any;
  allSumm: any;
  user: any;
  approval_dt: any;
  due_date: any;
  evc_chk: any;
  turnOverData: any;
  b2bdat: any;
  b2badat: any;
  cdnadat: any;
  cdnrdat: any;
  cdnurdat: any;
  cdnuradat: any;
  b2cladat: any;
  b2cldat: any;
  b2csadat: any;
  b2csdat: any;
  nildat: any;

  main_page_gstin;
  fil_stat;
  rtn_prd;
  finyr;
  retprd;
  bus_name;
  trade_name: string;
  gt: string;
  cur_gt: string;
  pdfb2b: any;
  pdfb2cl: any;
  pdfcdnr: any;
  pdfcdnur: any;
  pdfexp: any;
  pdfb2ba: any;
  pdfb2cla: any;
  pdfcdnra: any;
  pdfcdnura: any;
  pdfexpa: any;
  pdfb2csa: any;
  pdfata: any;
  pdftxpda: any;
  pdfhsn: any;
  pdftxpd: any;
  pdfat: any;
  pdfnil: any;
  pdfb2cs: any;
  docdat: any;

  getJSONAndGenratePdf(data: Object) {
    this.allSumm = data;
    this.summData = data['gstr1Summary'];
    if (this.summData.status === 1) {
      this.gstr1SumData = this.summData.data;
      this.b2bLimitReached = this.summData.data.b2bLimitReached;
      this.summaryTime = this.summData.data.time;
      this.sumryData = this.gstr1SumData.sec_sum;
      for (var i = 0; i < this.sumryData.length; i++) {
        if (this.sumryData[i].sec_nm == 'B2B') {
          this.pdfb2b = this.b2bdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'B2BA') {
          this.pdfb2ba = this.b2badat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'CDNRA') {
          this.pdfcdnra = this.cdnadat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'CDNR') {
          this.pdfcdnr = this.cdnrdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'CDNUR') {
          this.pdfcdnur = this.cdnurdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'CDNURA') {
          this.pdfcdnura = this.cdnuradat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'B2CLA') {
          this.pdfb2cla = this.b2cladat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'B2CL') {
          this.pdfb2cl = this.b2cldat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'B2CSA') {
          this.pdfb2csa = this.b2csadat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'B2CS') {
          this.pdfb2cs = this.b2csdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'NIL') {
          this.pdfnil = this.nildat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'EXP') {
          this.pdfexp = this.expadat = this.sumryData[i];
        }
        /*
         * else if
         * (this.sumryData[i].sec_nm ==
         * 'EXPWP') { this.expwdat =
         * this.sumryData[i]; }
         */
        else if (this.sumryData[i].sec_nm == 'EXPA') {
          this.pdfexpa = this.expadat = this.sumryData[i];
        }
        /*
         * else if
         * (this.sumryData[i].sec_nm ==
         * 'EXPWPA') {
         * this.expawdat =
         * this.sumryData[i]; }
         */
        else if (this.sumryData[i].sec_nm == 'ATA') {
          this.pdfata = this.atadat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'TXPD') {
          this.pdftxpd = this.txpdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'TXPDA') {
          this.pdftxpda = this.txpadat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'AT') {
          this.pdfat = this.attdat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'HSN') {
          this.pdfhsn = this.hsndat = this.sumryData[i];
        } else if (this.sumryData[i].sec_nm == 'DOC_ISSUE') {
          this.pdfdoc = this.docdat = this.sumryData[i];
        }
      }
    }
    if (this.gstr1SumData == undefined) {

      alerts("No Data found For Preview");
      return;
    }
    this.formData = this.allSumm.gstr1FormDetails;
    if (this.formData.status == 1) {
      var formDetails = this.formData.data;
      this.user = formDetails.user;
      // this.gstin =
      // formDetails.gstin;
      this.main_page_gstin = formDetails.gstin;
      this.fil_stat = formDetails.status
      this.approval_dt = formDetails.apprv_dt;
      // if(moment(this.approval_dt,'DD/MM/YYYY').isBefore(moment('01/07/2017','DD/MM/YYYY'))){
      // this.approval_dt='01/07/2017';
      // }
      this.retprd = formDetails.fm;
      // this.business_name =
      // formDetails.ln;
      this.bus_name = formDetails.ln;
      this.finyr = formDetails.fy;
      this.due_date = formDetails.due_dt;
      this.evc_chk = formDetails.evc_chk;
      this.trade_name = formDetails.tn;
    }
    this.turnOverData = this.allSumm.gstr1TurnOver;
    if (this.turnOverData.status == 1) {
      this.gt = this.turnOverData.data.gt;
      this.cur_gt = this.turnOverData.data.cur_gt;
    }
    this.genratepdf();
  }


  genratepdf() {
    var status = this.fil_stat;
    var pdfname = 'GSTR1_' + this.main_page_gstin + '_'
      + this.shareService.getData("rtnPreiod");
    this.shareService.removeData("rtnPreiod");
    var text = "DRAFT";
    if (status === 'FRZ' || status === 'FIL') {
      var text = "FINAL"
    }
    var dd = {
      pageSize: 'A4',
      pageOrientation: 'landscape',
      pageMargin: [40, 60, 40, 60],
      watermark: {
        text: text,
        color: 'black',
        opacity: 0.3,
        bold: true,
        italics: false,
        fontSize: 300
      },
      content: [
        {
          text: 'Form GSTR-1',
          style: 'header'
        },
        {
          text: '[See rule (59(1)]',
          style: 'rule'
        },

        {
          text: 'Details of outward supplies of goods or services',
          style: 'center'
        },
        {
          style: 'retprd',
          table: {
            widths: ['30%', 'auto'],
            body: [['Year', this.finyr],
            ['Month', this.retprd],

            ]
          }
        },
        {
          style: 'tableExample',
          table: {
            widths: ['65%', 'auto'],
            body: [
              [
                '1. GSTIN',
                this.main_page_gstin
                || '-'],
              [
                '2(a). Legal name of the registered person',
                this.bus_name || '-'],
              [
                '2(b). Trade name, if any',
                this.trade_name || '-'],
              [
                '3(a). Aggregate Turnover in the preceding Financial Year',
                this.gt || '-'],
              [
                '3(b). Aggregate Turnover - April to June, 2017 ',
                this.cur_gt || '-'],]
          }
        },
        {
          text: '4A, 4B, 4C, 6B, 6C - B2B Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfb2b.ttl_rec,
              this.pdfb2b.ttl_val,
              this.pdfb2b.ttl_tax,
              this.pdfb2b.ttl_igst,
              this.pdfb2b.ttl_cgst,
              this.pdfb2b.ttl_sgst,
              this.pdfb2b.ttl_cess]]
          }
        },
        {
          text: '5A, 5B - B2C (Large) Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Cess'],
              [this.pdfb2cl.ttl_rec,
              this.pdfb2cl.ttl_val,
              this.pdfb2cl.ttl_tax,
              this.pdfb2cl.ttl_igst,
              this.pdfb2cl.ttl_cess]]
          }
        },
        {
          text: '9B - Credit / Debit Notes (Registered)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfcdnr.ttl_rec,
              this.pdfcdnr.ttl_val,
              this.pdfcdnr.ttl_tax,
              this.pdfcdnr.ttl_igst,
              this.pdfcdnr.ttl_cgst,
              this.pdfcdnr.ttl_sgst,
              this.pdfcdnr.ttl_cess]]
          }
        },
        {
          text: '9B - Credit / Debit Notes (Unregistered)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Cess'],
              [this.pdfcdnur.ttl_rec,
              this.pdfcdnur.ttl_val,
              this.pdfcdnur.ttl_tax,
              this.pdfcdnur.ttl_igst,
              this.pdfcdnur.ttl_cess]]
          }
        },
        {
          text: '6A - Exports Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax'],
              [this.pdfexp.ttl_rec,
              this.pdfexp.ttl_val,
              this.pdfexp.ttl_tax,
              this.pdfexp.ttl_igst]]
          }
        },
        {
          text: '7 - B2C (Others)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfb2cs.ttl_rec,
              this.pdfb2cs.ttl_val,
              this.pdfb2cs.ttl_tax,
              this.pdfb2cs.ttl_igst,
              this.pdfb2cs.ttl_cgst,
              this.pdfb2cs.ttl_sgst,
              this.pdfb2cs.ttl_cess]]
          }
        },
        {
          text: '8 - Nil rated, exempted and non GST outward supplies',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Nil amount',
                'Total Exempted amount',
                'Total Non-GST Amount'],
              [
                this.pdfnil.ttl_rec,
                this.pdfnil.ttl_nilsup_amt,
                this.pdfnil.ttl_expt_amt,
                this.pdfnil.ttl_ngsup_amt]]
          }
        },
        {
          text: '11A(1), 11A(2) - Tax Liability (Advances Received)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfat.ttl_rec,
              this.pdfat.ttl_val,
              this.pdfat.ttl_tax,
              this.pdfat.ttl_igst,
              this.pdfat.ttl_cgst,
              this.pdfat.ttl_sgst,
              this.pdfat.ttl_cess]]
          }
        },
        {
          text: '11B(1), 11B(2) - Adjustment of Advances',
          pageBreak: 'before',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdftxpd.ttl_rec,
              this.pdftxpd.ttl_val,
              this.pdftxpd.ttl_tax,
              this.pdftxpd.ttl_igst,
              this.pdftxpd.ttl_cgst,
              this.pdftxpd.ttl_sgst,
              this.pdftxpd.ttl_cess]]
          }
        },
        {
          text: '12 - HSN-wise summary of outward supplies',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfhsn.ttl_rec,
              this.pdfhsn.ttl_val,
              this.pdfhsn.ttl_tax,
              this.pdfhsn.ttl_igst,
              this.pdfhsn.ttl_cgst,
              this.pdfhsn.ttl_sgst,
              this.pdfhsn.ttl_cess]]
          }
        },
        {
          text: '13 - Documents Issued',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Documents Issued',
                'Documents Cancelled',
                'Net issued Documents'],
              [
                this.docdat.ttl_rec,
                this.docdat.ttl_doc_issued,
                this.docdat.ttl_doc_cancelled,
                this.docdat.net_doc_issued]]
          }
        },
        {
          text: '9A - Amended B2B Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfb2ba.ttl_rec,
              this.pdfb2ba.ttl_val,
              this.pdfb2ba.ttl_tax,
              this.pdfb2ba.ttl_igst,
              this.pdfb2ba.ttl_cgst,
              this.pdfb2ba.ttl_sgst,
              this.pdfb2ba.ttl_cess]]
          }
        },
        {
          text: '9A - Amended B2C (Large) Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Cess'],
              [this.pdfb2cla.ttl_rec,
              this.pdfb2cla.ttl_val,
              this.pdfb2cla.ttl_tax,
              this.pdfb2cla.ttl_igst,
              this.pdfb2cla.ttl_cess]]
          }
        },
        {
          text: '9C - Amended Credit/Debit Notes (Registered)',
          pageBreak: 'before',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfcdnra.ttl_rec,
              this.pdfcdnra.ttl_val,
              this.pdfcdnra.ttl_tax,
              this.pdfcdnra.ttl_igst,
              this.pdfcdnra.ttl_cgst,
              this.pdfcdnra.ttl_sgst,
              this.pdfcdnra.ttl_cess]]
          }
        },
        {
          text: '9C - Amended Credit/Debit Notes (Unregistered)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Cess'],
              [this.pdfcdnura.ttl_rec,
              this.pdfcdnura.ttl_val,
              this.pdfcdnura.ttl_tax,
              this.pdfcdnura.ttl_igst,
              this.pdfcdnura.ttl_cess]]
          }
        },
        {
          text: '9A - Amended Exports Invoices',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax'],
              [this.pdfexpa.ttl_rec,
              this.pdfexpa.ttl_val,
              this.pdfexpa.ttl_tax,
              this.pdfexpa.ttl_igst]]
          }
        },
        {
          text: '10 - Amended B2C(Others)',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfb2csa.ttl_rec,
              this.pdfb2csa.ttl_val,
              this.pdfb2csa.ttl_tax,
              this.pdfb2csa.ttl_igst,
              this.pdfb2csa.ttl_cgst,
              this.pdfb2csa.ttl_sgst,
              this.pdfb2csa.ttl_cess]]
          }
        },
        {
          text: '11A - Amended Tax Liability (Advance Received)',
          pageBreak: 'before',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdfata.ttl_rec,
              this.pdfata.ttl_val,
              this.pdfata.ttl_tax,
              this.pdfata.ttl_igst,
              this.pdfata.ttl_cgst,
              this.pdfata.ttl_sgst,
              this.pdfata.ttl_cess]]
          }
        },
        {
          text: '11B - Amendment of Adjustment of Advances',
          style: 'subheader'
        },

        {
          style: 'tableExample',
          table: {
            body: [
              [
                'No. of Records',
                'Total Invoice value',
                'Total Taxable value',
                'Total Integrated Tax',
                'Total Central Tax',
                'Total State/UT  Tax',
                'Total Cess'],
              [this.pdftxpda.ttl_rec,
              this.pdftxpda.ttl_val,
              this.pdftxpda.ttl_tax,
              this.pdftxpda.ttl_igst,
              this.pdftxpda.ttl_cgst,
              this.pdftxpda.ttl_sgst,
              this.pdftxpda.ttl_cess]]
          }
        }],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          margin: [300, 0, 0, 10]
        },
        subheader: {
          fontSize: 16,
          bold: true,
          margin: [0, 10, 0, 5]
        },
        tableExample: {
          margin: [0, 5, 0, 15]
        },
        retprd: {
          margin: [470, 0, 0, 10]
        },
        center: {
          margin: [220, 0, 0, 10]
        },
        tableHeader: {
          bold: true,
          fontSize: 13,
          color: 'black'
        },
        rule: {
          margin: [315, 0, 0, 10]
        }
      }

    }
    try {
      pdfMake.createPdf(dd).download(pdfname, this.shareService.getData('year')['yearId'], this.shareService.getData('month')['monthId'], this.shareService.getData('selectedClient')['gstnNo'], 'GSTR1', this.shareService.getData('selectedClient')["mclientId"], this.shareService.getData('selectedClient')["gstnCid"]);
      if (this.summData && this.summData.data && this.summData.data.ret_period) {
        let msg = 'GSTR1 ' + " PREVIEW FOR Period " + this.summData.data.ret_period + " Downloaded successfully..!";
        success(msg);
      } else {
        let msg = 'GSTR1 ' + " PREVIEW Downloaded successfully..!";
      }
    } catch (error) {
      console.log("Error while generated pdf using ",
        error);
      alerts("Error while Downloading Preview PDF");
    }

  }

}
