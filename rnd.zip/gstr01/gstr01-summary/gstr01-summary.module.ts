import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01SummaryRoutingModule } from './gstr01-summary-routing.module';
import { Gstr01SummaryComponent } from './gstr01-summary.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01SummaryComponent],
  imports: [
  	LanguageModule,
    ReactiveComponentLoaderModule.forRoot(),
    GSTSharedModule,
    CommonModule,
    Gstr01SummaryRoutingModule
  ]
})
export class Gstr01SummaryModule { }
