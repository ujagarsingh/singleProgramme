import { Component, OnInit } from '@angular/core';
import { Gstr01CommonService } from '../gstr01-common.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Gstr01FillformService } from '../gstr01-fillform/gstr01-fillform.service';
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
declare var SagGridMP;
declare function alerts(message)
declare function success(message)
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-gstr01-summary',
  templateUrl: './gstr01-summary.component.html',
  styleUrls: ['./gstr01-summary.component.scss']
})
export class Gstr01SummaryComponent implements OnInit {

  /**
   * Dropdown Config Json initilize...
   */
  dropdownCofigJson = {
    selectedData: {
      formName: 'gstr1',
    },
    AllForAllPeriod : true,
    showPeriod : ["Monthly","Quarterly","Yearly"],
    showHideDropdown: {
      showGetClientBtn: false,
      month: true,
      year: true,
      period: true,
      returnType: false,
      clientList: true,
      gstnList: true
    },
    enableDisableDropdown: {
      month: false,
      year: false,
      period: false,
      returnType: false,
    },
  }

  /**
   *  Data Object Define...
   */
  dashbordListGridObject: object;
  clientListGridObject: object;
  summaryStateListGridObject: object;
  gridDataObject: object;
  frezColumn: any;
  merzColumn: any;
  columnConditions: any;
  statewiseData: any;
  showView: any = "All";
  gstnFilter: any = "All";
  gstwiseData: Object;
  secSummaryData: any;
  filterDataObj: any;
  gstwiseCurrntShowList: any;
  filterGsntwiseObj: any;
  filterStateWiseDataObj: any;
  /**
   *  Initilizations Sections... 
   */
  constructor(private gridexport: GridExportService,
    private eventEmitterService: EventEmitterService,
    private commonService: Gstr01CommonService, private shareService: ShareService, private fillformService: Gstr01FillformService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
  }

  selectedClient: any;
  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();

    this.__addGrid('summary');
  }

  __selectedTab: any;

  commonDropDownDataChange() {
    if (this.__selectedTab == 'summary')
      this.__addGrid('summary');
    else if (this.__selectedTab == 'gstwise')
      this.__addGrid('gstwise');
    else if (this.__selectedTab == 'statewise')
      this.__addGrid('statewise');
  }

  /**
   * 
   * @param type 
   */
  __addGrid(type: any) {
    this.__selectedTab = type;
    var obj = {              //Change After dynamically Dropdown implementatios...
      formType: 'GSTR1',
      mClientId: this.shareService.getData("selectedClient")["mClientId"],
      yearId: this.shareService.getData("year")["yearId"],
      monthId: this.shareService.getData("month")["monthId"],
      gstnId: this.shareService.getData("selectedClient")["gstnCid"],
      periodName: this.shareService.getData("period")["periodName"].substr(0, 1).toUpperCase() == 'A' ? 'Y' : this.shareService.getData("period")["periodName"].substr(0, 1).toUpperCase()
    };

    if (type == 'summary') {
      this.frezColumn = { "sno": "left", "sectionName": "left", "from": "left" };
      this.columnConditions = "sectionName";
      this.merzColumn = ["sno","sectionName"];

      this.commonService._getGstr1SummaryCompareWithPortal(obj).subscribe(
        (data: any) => {
          if (data != null) {
            this.secSummaryData = data;
            this.filterDataObj = null;
            data = this.removeBlankData(data);
            this.dashbordListGridObject = this.designGrid(this.summaryColumns, data);
          }
        });
    } else if (type == 'gstwise') {
      this.frezColumn = { "sno": "left", "reciverName": "left", "reciverGstnNo": "left", "sectionName": "left" };
      this.columnConditions = "reciverGstnNo";
      this.merzColumn = ["sno", "reciverName", "reciverGstnNo", "sectionName"];
      this.commonService._getGstr1SummaryCompareWithPortalGstn(obj).subscribe(
        data => {
          if (data != null) {
            this.gstwiseData = data;
            this.filterGsntwiseObj = this.gstwiseCurrntShowList = null;
            this.dashbordListGridObject = this.designGrid(this.gstnColumns, data);
          }
        });
    }
    else if (type == 'statewise') {
      this.frezColumn = { "sno": "left", "statName": "left", "from": "left" };
      this.columnConditions = "statName";
      this.merzColumn = ["sno", "statName"];
      this.commonService._getGstr1SummaryCompareWithPortalState(obj).subscribe(
        data => {
          if (data != null) {
            this.statewiseData = data;
            this.filterStateWiseDataObj = null;
            this.dashbordListGridObject = this.designGrid(this.stateColumns, data);
          }
        });
    } else {
      alert('Sorry ! Invalid Type...!');
    }
  }//End Of __addGrid method..

  designGrid(column: any, row: any) {
    //Color Definations..
    var rowDataCopy = row;
    var colorCode = [];
    var portalInvIndex = [];
    var diffIndex = [];
    for (var i = 0; i < rowDataCopy.length; i++) {
      rowDataCopy[i]["sno"] = i + 1;
      if (rowDataCopy[i]["from"].toLowerCase() == "portal") {
        portalInvIndex.push(i);
      } else if (rowDataCopy[i]["from"].toLowerCase() == "difference") {
        diffIndex.push(i);
      }
    }
    var portalColorCode = { index: portalInvIndex, colorCode: "#d8d8f7" };
    var diffColorCode = { index: diffIndex, colorCode: "#f7b8b8" };
    colorCode.push(portalColorCode);
    colorCode.push(diffColorCode);


    let gridData = {
      columnDef: column,
      rowDef: row,
      menu: {
        fontFamily: true,
        fontSize: true,
        underline: true,
        left: true,
        center: true,
        right: true,
        selectionType: true,
        columnResizable: true
      },
      selection: "row",
      clientSidePagging: true,
      recordPerPage: 68,
      recordNo: true,
      disableAllSearch: true,
      totalNoOfRecord_hide: true,
      frezzManager: this.frezColumn,
      conditionMerzemanager: {
        conditionColumn: this.columnConditions,
        mrzeColumnList: this.merzColumn
      },
      gridExportService: this.gridexport,
      callBack: {
        "onRowClick": function () {
        }
      },
      mutliColorInRow: colorCode
    };
    let sourceDiv = document.getElementById("gstrSummaryListGrid");
    return SagGridMP(sourceDiv, gridData, true, true);
  }

  /**
   *  For Summary DashBoard Data Columns
   */
  summaryColumns = [
    {
      header: 'S.No',
      field: 'sno',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Section',
      field: 'sectionName',
      filter: true,
      width: '150px',
      'text-align': 'center'
    },
    {
      header: 'From',
      field: 'from',
      filter: true,
      width: '130px',
      'text-align': 'center',
      'styles': { 'font-weight': 'bold' }
    },
    {
      header: 'Total Record Count',
      field: 'recCount',
      filter: true,
      width: '180px',
      'text-align': 'center'
    },
    {
      header: 'Total Taxable Value',
      field: 'totTaxableVal',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total IGST',
      field: 'totIgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total CGST',
      field: 'totCgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total SGST',
      field: 'totSgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total Cess',
      field: 'totCess',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total Invoice Value',
      field: 'totalVal',
      filter: true,
      width: '180px',
      'text-align': 'center'
    }
  ];

  /**
   *  For GSTN Summary Wise Columns 
   */
  gstnColumns = [
    {
      header: 'S.No',
      field: 'sno',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: "Name",
      field: "reciverName",
      filter: true,
      width: '150px',
      'text-align': 'center'
    },
    {
      header: "GSTN No",
      field: "reciverGstnNo",
      filter: true,
      width: '150px',
      'text-align': 'center'
    },
    {
      header: 'From',
      field: 'from',
      filter: true,
      width: '130px',
      'text-align': 'center',
      'styles': { 'font-weight': 'bold' }
    },
    {
      header: 'Section Name',
      field: 'sectionName',
      filter: true,
      width: '150px',
      'text-align': 'center'
    },
    {
      header: 'Record Count',
      field: 'totalRecord',
      filter: true,
      width: '180px',
      'text-align': 'center'
    },
    {
      header: 'Total Taxable Value',
      field: 'totalTax',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total IGST',
      field: 'totalIgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total CGST',
      field: 'totalCgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total SGST',
      field: 'totalSgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total CESS',
      field: 'totalCess',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total Invoice Value',
      field: 'totalInvoice',
      filter: true,
      width: '180px',
      'text-align': 'center'
    }
  ];

  /**
   * For State Summary Wise Columns 
   */
  stateColumns = [
    {
      header: 'S.No',
      field: 'sno',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: "State Name",
      field: "statName",
      filter: true,
      width: '150px',
      'text-align': 'center'
    },
    {
      header: 'From',
      field: 'from',
      filter: true,
      width: '131px',
      'text-align': 'center',
      'styles': { 'font-weight': 'bold' }
    },
    {
      header: 'Supply Type',
      field: 'supplyType',
      filter: true,
      width: '150px',
      'text-align': 'center',
      'styles': { 'font-weight': 'bold' }
    },
    {
      header: 'Taxable Value',
      field: 'taxableValue',
      filter: true,
      width: '180px',
      'text-align': 'center'
    },
    {
      header: 'Total IGST',
      field: 'totalIgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total CGST',
      field: 'totalCgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total SGST',
      field: 'totalSgst',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total CESS',
      field: 'totalCess',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: 'Total Tax',
      field: 'totalTax',
      filter: true,
      width: '130px',
      'text-align': 'center'
    },
    {
      header: "Total Invoice",
      field: "totalInvoice",
      filter: true,
      width: '180px',
      'text-align': 'center'
    }
  ];

  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'gstnOnlineModule',
    selector: 'app-gstn-online-login'
  };

  popupData: any;
  openGstnPop() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient) {
      this.popupData = {
        formInfo: {
          selectedClient: selectedClient,
          formName: 'GSTR1'
        }
      }
      this.location = this.importlocation;
      this.eventEmitterService.loadCaptchePopup();
    } else {
      alerts("Select A Client")
    }
  }

  loggedInChange = (data) => {
    if (data != "close") {
      let obj = {
        "mClientId": this.shareService.getData("selectedClient")["mClientId"],
        "gstnCid": this.shareService.getData("selectedClient")["gstnCid"],
        "yearId": this.shareService.getData("year")["yearId"],
        "monthId": this.shareService.getData("month")["monthId"]
      };
      this.commonService.updateGstr1Summary(obj).subscribe(data => {
        if (data && data["status"] == 1) {
          success(data['msg']);
        } else {
          alerts(data["msg"])
        }
        this.__addGrid(this.__selectedTab);
      });
    }
  }

  //This function for remove data of section which have no data at software and portal
  removeBlankData(rowData) {
    var filterList = [];
    for (var k = 0; k < rowData.length; k++) {
      var row = rowData[k];
      if (!row.hasOwnProperty("recCount") && row.from == "Software") {
        if ((rowData[k + 1] && !rowData[k + 1].hasOwnProperty("recCount")) || (rowData[k + 1].hasOwnProperty("recCount") && parseInt(rowData[k + 1].recCount) == 0)) {
          k += 2;
        } else {
          filterList.push(row);
        }
      } else {
        filterList.push(row);
      }
    }
    return filterList;
  }

  showViewChange() {
    if (this.__selectedTab == 'summary') {
      if (!this.filterDataObj)//Its only Set One Time Its Reset When Month Change
        this.filterDataObj = filterSecData(this.removeBlankData(this.secSummaryData));

      if (this.showView == 'All') {
        this.secSummaryData = this.removeBlankData(this.secSummaryData);
        this.designGrid(this.summaryColumns, this.secSummaryData);
      } else if (this.showView == 'Match') {
        this.designGrid(this.summaryColumns, this.filterDataObj.match);
      } else if (this.showView == 'Mismatch') {
        this.designGrid(this.summaryColumns, this.filterDataObj.mismatch);
      }
    } else if (this.__selectedTab == 'gstwise') {
      var filterGstnwiseDataObj = filterGstnwise(this.gstwiseCurrntShowList ? this.gstwiseCurrntShowList : this.gstwiseData);

      if (this.showView == 'All') {
        this.designGrid(this.gstnColumns, this.gstwiseCurrntShowList ? this.gstwiseCurrntShowList : this.gstwiseData);
      } else if (this.showView == 'Match') {
        this.designGrid(this.gstnColumns, filterGstnwiseDataObj.match);
      } else if (this.showView == 'Mismatch') {
        this.designGrid(this.gstnColumns, filterGstnwiseDataObj.mismatch);
      }
    } else if (this.__selectedTab == 'statewise') {
      if (!this.filterStateWiseDataObj)//Its only Set One Time Its Reset When Month Change
        this.filterStateWiseDataObj = filterStateWiseData(this.statewiseData);

      if (this.showView == 'All') {
        this.designGrid(this.stateColumns, this.statewiseData);
      } else if (this.showView == 'Match') {
        this.designGrid(this.stateColumns, this.filterStateWiseDataObj.match);
      } else if (this.showView == 'Mismatch') {
        this.designGrid(this.stateColumns, this.filterStateWiseDataObj.mismatch);
      }
    }

    //Local Function For Filter sec summary Data
    function filterSecData(data) {
      var misMatchKey = {};
      var misMatch = [];
      var matchKey = {};
      var match = [];
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.recCount) {
          var recCount = parseInt(temp.recCount);
          if (temp.from && temp.from.toLowerCase() == 'difference') {
            if (recCount >= 1 || recCount < 0) {//Mismatch Rec More then 0 
              if (temp.sectionName != '<b>Total</b>')
                misMatchKey[temp.sectionName] = "";
            } else if (recCount == 0) {//if zero then Amount Check
              if (temp.sectionName != '<b>Total</b>') {
                if (parseFloat(temp.totalVal) == 0 && parseFloat(temp.totCess) == 0 &&
                  parseFloat(temp.totCgst) == 0 && parseFloat(temp.totIgst) == 0 &&
                  parseFloat(temp.totSgst) == 0 && parseFloat(temp.totTaxableVal) == 0) {
                  matchKey[temp.sectionName] = "";
                } else
                  misMatchKey[temp.sectionName] = "";
              }
            }
          }
        } else if (temp.sectionName != '<b>Total</b>')
          misMatchKey[temp.sectionName] = "";
      }
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.from && misMatchKey.hasOwnProperty(temp.sectionName)) {
          misMatch.push(temp);
        } else if (temp.from && matchKey.hasOwnProperty(temp.sectionName)) {
          match.push(temp);
        }
      }

      return {
        match: match,
        mismatch: misMatch,
      };
    }
    //Local Function For Filter gstnwise summary Data
    function filterGstnwise(data) {
      var misMatchKey = {};
      var misMatch = [];
      var matchKey = {};
      var match = [];
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.totalRecord) {
          var recCount = parseInt(temp.totalRecord);
          if (temp.from && temp.from.toLowerCase() == 'difference') {
            if (recCount >= 1) {//Mismatch Rec More then 0 
              if (temp.reciverGstnNo != '<b>Total</b>')
                misMatchKey[temp.reciverGstnNo + "_" + temp.sectionName] = "";
            } else if (recCount == 0) {//if zero then Amount Check
              if (temp.reciverGstnNo != '<b>Total</b>') {
                if (parseFloat(temp.totalInvoice) == 0 && parseFloat(temp.totalCess) == 0 &&
                  parseFloat(temp.totalCgst) == 0 && parseFloat(temp.totalIgst) == 0 &&
                  parseFloat(temp.totalSgst) == 0 && parseFloat(temp.totalTax) == 0) {
                  matchKey[temp.reciverGstnNo + "_" + temp.sectionName] = "";
                } else
                  misMatchKey[temp.reciverGstnNo + "_" + temp.sectionName] = "";
              }
            }
          }
        } else if (temp.reciverGstnNo != '<b>Total</b>')
          misMatchKey[temp.reciverGstnNo + "_" + temp.sectionName] = "";
      }
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.from && misMatchKey.hasOwnProperty(temp.reciverGstnNo + "_" + temp.sectionName)) {
          misMatch.push(temp);
        } else if (temp.from && matchKey.hasOwnProperty(temp.reciverGstnNo + "_" + temp.sectionName)) {
          match.push(temp);
        }
      }
      return {
        match: match,
        mismatch: misMatch,
      };
    }
    //Local Function For Filter statewise summary Data
    function filterStateWiseData(data) {
      var misMatchKey = {};
      var misMatch = [];
      var matchKey = {};
      var match = [];
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.from.toLowerCase() == "difference" && temp.stateName != "<b>Total</b>") {
					/*if((temp.totalInvoice && temp.totalIgst &&  temp.totalCgst &&  temp.totalSgst && temp.totalCess && temp.totalTax)
						&& (parseFloat(temp.totalInvoice) == 0 && parseFloat(temp.totalIgst) == 0 &&  parseFloat(temp.totalCgst) == 0 
								&&  parseFloat(temp.totalSgst) == 0 && parseFloat(temp.totalCess) == 0 && parseFloat(temp.totalTax) == 0)){
						matchKey[temp.stateName]="";
					}else{
						misMatchKey[temp.stateName]="";
					}*/


          if ((this.isUndefinedNull(temp.totalInvoice) && parseFloat(temp.totalInvoice) == 0) && (this.isUndefinedNull(temp.totalCess) && parseFloat(temp.totalCess) == 0)
            && (this.isUndefinedNull(temp.totalTax) && parseFloat(temp.totalTax) == 0) && (this.isUndefinedNull(temp.totalIgst) || (this.isUndefinedNull(temp.totalCgst) && this.isUndefinedNull(temp.totalSgst)))
            && (parseFloat(temp.totalIgst) == 0 || (parseFloat(temp.totalCgst) == 0 && parseFloat(temp.totalSgst) == 0))) {
            matchKey[temp.stateName] = "";
          } else {
            misMatchKey[temp.stateName] = "";
          }
        }
      }
      for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        if (temp.stateName && misMatchKey.hasOwnProperty(temp.stateName)) {
          misMatch.push(temp);
        } else if (temp.stateName && matchKey.hasOwnProperty(temp.stateName)) {
          match.push(temp);
        }
      }
      return {
        match: match,
        mismatch: misMatch,
      };
    }
  }
  isUndefinedNull(obj) {
    if (obj != null && obj != undefined)
      return true;
    else
      return false;
  }


  /**
	 * This Function Called Filter Combo
	 * */
  gstnSummaryFilterChange() {
    if (!this.filterGsntwiseObj)
      this.filterGsntwiseObj = getSecObj(this.gstwiseData);


    if (this.gstnFilter == "All") {
      this.gstwiseCurrntShowList = this.gstwiseData;
    } else if (this.gstnFilter == "B2B") {
      this.gstwiseCurrntShowList = this.filterGsntwiseObj.b2b;
    } else if (this.gstnFilter == "Credit Debit Notes Registered Users") {
      this.gstwiseCurrntShowList = this.filterGsntwiseObj.cdnr;
    } else if (this.gstnFilter == "B2B Amend") {
      this.gstwiseCurrntShowList = this.filterGsntwiseObj.b2ba;
    } else if (this.gstnFilter == "Credit Debit Notes Amendments Registered Users") {
      this.gstwiseCurrntShowList = this.filterGsntwiseObj.cdnra;
    }
    this.showViewChange();
    //addGridOfGstnWise(this.gstwiseCurrntShowList);

    function getSecObj(list) {
      var b2b = [];
      var b2ba = [];
      var cdnr = [];
      var cdnra = [];

      for (var i = 0; i < list.length; i++) {
        if (list[i].sectionName && list[i].sectionName.toLowerCase() == "b2b") {
          b2b.push(list[i]);
        } else if (list[i].sectionName && list[i].sectionName.toLowerCase() == "credit debit notes registered users") {
          cdnr.push(list[i]);
        } else if (list[i].sectionName && list[i].sectionName.toLowerCase() == "b2b amend") {
          b2ba.push(list[i]);
        } else if (list[i].sectionName && list[i].sectionName.toLowerCase() == "credit debit notes amendments  registered users") {
          cdnra.push(list[i]);
        }
      }
      return {
        b2b: b2b,
        b2ba: b2ba,
        cdnr: cdnr,
        cdnra: cdnra
      };
    }
  }

}
