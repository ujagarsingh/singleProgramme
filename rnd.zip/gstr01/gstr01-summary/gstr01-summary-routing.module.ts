import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Gstr01SummaryComponent } from './gstr01-summary.component';

const routes: Routes = [{
  path : "",
  component : Gstr01SummaryComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Gstr01SummaryRoutingModule { }
