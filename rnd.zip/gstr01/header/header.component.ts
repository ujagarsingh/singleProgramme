import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShareService } from 'genmaster/src/master/services/share.service';
declare function alerts(m);
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() selectedTab : any;
  
  constructor(private router : Router,private route: ActivatedRoute,private shareSerivce: ShareService ) {
    
   }

  ngOnInit() {
  }
  
  Gstr01FormTabClick( url : string){
    if(url == 'gst/return/GSTR1/client')
      this.router.navigate([url]);
    else if(url!= 'gst/return/GSTR1/client' && this.shareSerivce.getData("selectedClient"))
      this.router.navigate([url]);
    else
      alerts("select a client");
  }
}
