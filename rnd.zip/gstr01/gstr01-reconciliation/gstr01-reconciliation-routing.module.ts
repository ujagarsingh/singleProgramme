import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Gstr01ReconciliationComponent } from './gstr01-reconciliation.component';

const routes: Routes = [{
  path : "",
  component : Gstr01ReconciliationComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Gstr01ReconciliationRoutingModule { }
