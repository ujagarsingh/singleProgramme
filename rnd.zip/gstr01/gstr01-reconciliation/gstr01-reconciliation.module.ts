import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01ReconciliationRoutingModule } from './gstr01-reconciliation-routing.module';
import { Gstr01ReconciliationComponent } from './gstr01-reconciliation.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01ReconciliationComponent],
  imports: [
  	LanguageModule,
    GSTSharedModule,
    CommonModule,
    Gstr01ReconciliationRoutingModule
  ]
})
export class Gstr01ReconciliationModule { }
