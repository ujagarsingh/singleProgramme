import { Component, OnInit } from '@angular/core';
declare var SagGridMP;

@Component({
  selector: 'app-gstr01-reconciliation',
  templateUrl: './gstr01-reconciliation.component.html',
  styleUrls: ['./gstr01-reconciliation.component.scss']
})
export class Gstr01ReconciliationComponent implements OnInit {
  ReconcilationListGridObject : object;
  dropdownCofigJson = {
    selectedData : {
      formName          : 'gstr1',
    },
    showHideDropdown :  {
      showGetClientBtn  : false,
      month       : false,
      year        : true,
      period      : false,
      returnType  : false,
      clientList  : true,  
      gstnList    : true
    },
    enableDisableDropdown :{
      month       : false,
      year        : false,
      period      : false,
      returnType  : false,
    },
  }
  constructor() { }
  ReconcilationListColumn =[{
    'colType': 'checkBox',
     width : '50px',
     field: 'checkBox',
     'text-align' : 'center',
},
{
header : 'S.No',
field : 'sno',
filter : true,
width : '110px',
'text-align' : 'right',
'editable': true,
'total': true,
'total-text': '',
search : true
},
{
  header : 'Type',
  field : 'type',
  filter : true,
  width : '180px',
  'text-align' : 'left',
  'editable': true,
  'total': true,
  'total-text': '',
  search : true
  },
  {
    header : 'Invoice Value',
    field : 'invoicevalue',
    filter : true,
    width : '150px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'Taxable Value',
    field : 'taxablevalue',
    filter : true,
    width : '150px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
  {
    header : 'IGST',
    field : 'status',
    filter : true,
    width : '130px',
    'text-align' : 'right',
    'editable': true,
    'total': true,
    'total-text': '',
    search : true
    },
{
  header : 'CGST',
  field : 'cgst',
  filter : true,
  width : '130px',
  'text-align' : 'right',
  'editable': true,
  'total': true,
  'total-text': '',
  search : true
  },
{
  header : 'SGST',
  field : 'sgst',
  filter : true,
  width : '130px',
  'text-align' : 'right',
  'editable': true,
  'total': true,
  'total-text': '',
  search : true
  },
{
  header : 'Cess',
  field : 'cess',
  filter : true,
  width : '130px',
  'text-align' : 'right',
  'editable': true,
  'total': true,
  'total-text': '',
  search : true
  },
{
  header : 'Total Tax',
  field : 'totaltax',
  filter : true,
  width : '130px',
  'text-align' : 'right',
  'editable': true,
  'total': true,
  'total-text': '',
  search : true
  },
  
]
  ngOnInit() {
    let sourceDiv = document.getElementById("gstr01ReconciliationListGrid");
    this.ReconcilationListGridObject = this.designGrid(this.ReconcilationListColumn,[],sourceDiv);
  }
  designGrid(column ,row,gridSourceDiv){
    let gridData = {
      columnDef: column,
      rowDef: row,
      callBack :{
        "onRowClick":function(){
          
        }
      }
    };
   return SagGridMP(gridSourceDiv, gridData, true, true);
  }
  commonDropDownDataChange(data) {}
  
}
