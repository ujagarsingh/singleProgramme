import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gstr01-receiver',
  templateUrl: './gstr01-receiver.component.html',
  styleUrls: ['./gstr01-receiver.component.scss']
})
export class Gstr01ReceiverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
