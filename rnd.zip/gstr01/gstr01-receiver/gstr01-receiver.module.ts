import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01ReceiverRoutingModule } from './gstr01-receiver-routing.module';
import { Gstr01ReceiverComponent } from './gstr01-receiver.component';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01ReceiverComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    Gstr01ReceiverRoutingModule
  ]
})
export class Gstr01ReceiverModule { }
