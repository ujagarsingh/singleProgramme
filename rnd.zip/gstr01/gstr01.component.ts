import { Component, OnInit } from '@angular/core';
import { NavigationEnd, NavigationStart, Router, ActivatedRoute, Event, NavigationError } from '@angular/router';
import { ShareService } from 'node_modules/genmaster/src/master/services/share.service';
import { Subscription } from 'rxjs';

@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-gstr01',
  templateUrl: './gstr01.component.html',
  styleUrls: ['./gstr01.component.scss']
})
export class Gstr01Component implements OnInit {
  subscription : Subscription;
  selectedTab : String;
  constructor(private router: Router, private activeRoute: ActivatedRoute, private share: ShareService, private shareService: ShareService) {
    this.shareService.setData("selectedSellerType","R");
    this.subscription = this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        this.share.startLoader();
      }

      if (event instanceof NavigationEnd) {
        this.share.stopLoader();
        console.log(event);
        if (event.urlAfterRedirects === "/gst/return/GSTR1") {
          this.selectedTab = "tab1";
          this.router.navigate(["gst/return/GSTR1/client"]);
        }else if(event.urlAfterRedirects == "/gst/return/GSTR1/client"){
          this.selectedTab = "tab1";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/dashboard") ){
          this.selectedTab = "tab2";
        }else if(event.urlAfterRedirects.startsWith('/gst/return/GSTR1/fillform')){
          this.selectedTab = "tab3";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/receiver")){
          this.selectedTab = "tab4";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/summary") ){
          this.selectedTab = "tab5";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/reconciliation") ){
          this.selectedTab = "tab6";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/sms") ){
          this.selectedTab = "tab7";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/email") ){
          this.selectedTab = "tab8";
        }else if(event.urlAfterRedirects.startsWith("/gst/return/GSTR1/configuration") ){
          this.selectedTab = "tab9";
        }
      }

      if (event instanceof NavigationError) {
        console.log(event.error);
      }
    });
  }


  ngOnInit() {
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
