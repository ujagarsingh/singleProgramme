import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01RoutingModule } from './gstr01-routing.module';
import { Gstr01Component } from './gstr01.component';
import { HeaderComponent } from './header/header.component';
import { GSTSharedModule } from '../../shared/shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01Component, HeaderComponent],
  imports: [
  	LanguageModule,
    GSTSharedModule,
    CommonModule,
    Gstr01RoutingModule
  ],
  bootstrap : [Gstr01Component]
})
export class Gstr01Module { }
