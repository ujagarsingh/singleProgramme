import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AtadjComponent } from './atadj.component';
import { AtadjAddComponent } from './atadj-add/atadj-add.component';

const routes: Routes = [
  {
    path : "",
    component : AtadjComponent
  },
  {
    path : "amv",
    component : AtadjAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AtadjRoutingModule { }
