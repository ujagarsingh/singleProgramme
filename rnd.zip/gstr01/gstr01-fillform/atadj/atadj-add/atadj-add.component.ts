import { Component, OnInit, OnDestroy } from '@angular/core';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { Subscription } from 'rxjs';
import { FormControl } from '@angular/forms';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Location } from '@angular/common';
import { ComponentLocation } from '@wishtack/reactive-component-loader';

declare var SagGridMP;
declare var $;
declare function alerts(n);
declare function success(n);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-atadj-add',
  templateUrl: './atadj-add.component.html',
  styleUrls: ['./atadj-add.component.scss']
})
export class AtadjAddComponent implements OnInit {

  selectedDiff: any = null;
  commonFormGroup: any;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [{ "key": "", "val": "-Select-" }];
  itemArr = [{ "key": "", "val": "-Select-" }];
  formType = "GSTR1";
  commonDropRes: any = {};
  commonDropReq = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category"], "docTypeParams": "R" };
  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };
  selectedClient: any;
  constructor(private shareService: ShareService, private eventEmitterService: EventEmitterService, private configurationService: ConfigurationsService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    this.selectedClient = this.shareService.getData("selectedClient");
    this.manageDateObject();
  }

  ngOnInit() {
    this.getPaymentData();
    if (!this.selectedClient)
      this.fillformService.exit();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.overrideValidation();
    this.getCommonDropdownListOnLoad(this.commonDropReq, this.formType);
    this.manageObservables();
  }

  overrideValidation() {
    this.commonFormGroup.addControl("spId", new FormControl(null));
  }

  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.splyTypeOvserver = this.commonFormGroup.get("splytypeId").valueChanges.subscribe(data => {
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.enableColumn("invitemIrt") : this.gridDynamicObj.disableColumn("invitemIrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.enableColumn("invitemIamt") : this.gridDynamicObj.disableColumn("invitemIamt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemCrt") : this.gridDynamicObj.enableColumn("invitemCrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemCamt") : this.gridDynamicObj.enableColumn("invitemCamt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemSrt") : this.gridDynamicObj.enableColumn("invitemSrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemSamt") : this.gridDynamicObj.enableColumn("invitemSamt");
    });

    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableGrid();
        } else {
          this.gridDynamicObj.enableGrid();
        }
      }
    });

    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });

  }

  supplyTypeCode: any;
  sellerChange() {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("spId").value, "spId");
    for (const obj of this.commonDropRes.supplyType) {
      if (obj.supplyCode == "INTRA" && this.selectedClient.stateId === data.stateId) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytypeId: obj.supplyId })
      } else if (obj.supplyCode == "INTER" && this.selectedClient.stateId != data.stateId) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytypeId: obj.supplyId })
      }
    }
    this.commonFormGroup.patchValue({ spId: data.spId, stateId: data.stateId, });

  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts("invoice No already exist In this financial Year");
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }

  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          //this.getInvTypeAndRevChrgsList();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo == null)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
          if (this.selectedInvoice) {
            this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
            this.shareService.removeData("selectedInvoice");
          } else {
            this.addGrid(this.gridRowData);
            this.gridDynamicObj.disableGrid();
          }
        }
      });
  }

  differentialChange() {
    var arr = this.gridDynamicObj.getGridData();
    for (let index = 0; index < arr.length; index++) {
      const obj = arr[index];
      this.fillformService.commonMethods(this, index, obj);
    }
  }

  saveTxpd() {
    var items = this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, "none", this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      var obj = this.commonFormGroup.value;
      obj["items"] = items;
      this.fillformService.saveInvoice(obj, 'txpd').subscribe(data => {
        if (data["httpStatus"] == 200) {
          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
          success("Invoices Deleted Successfully");
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }

  }


  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;
  manageDateObject() {
    var obj = this.returnService.manageDateObjects(false);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }

  configuredData: any;
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      if (data["data"]) {
        this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfTxpd");
        this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
          if (res["httpStatus"] == 200) {
            this.commonDropRes = res["data"];
            this.setGridDropdownOnLoad();
          }
          this.getSellerList();
        });
      }
    });
  }

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue({ sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'txpd')["secId"], });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
  }
  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];
  selectedInvoice: any;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    formGroup.patchValue({
      invtypeId: selectedInvoice.invTypeId,
      invId: selectedInvoice.invId,
      spId: selectedInvoice.spId,
      stateId: selectedInvoice.stateId,
      invTxval: selectedInvoice.inv_txval,
      invVal: selectedInvoice.inv_val,
      invDt: selectedInvoice.org_invoice_date,
      invNo: selectedInvoice.org_invoice_no,
      invRchrg: selectedInvoice.invRchrg,
      invRchrgyn: selectedInvoice.invRchrgyn,
    });
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridRowData = data["data"];
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
          obj.item = null;

        });
        this.addGrid(this.gridRowData);
        this.sellerChange();
      }
    });
  }



  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'sellerModule',
    selector: 'app-return-seller-form'
  };

  openSellerModal() {
    this.location = this.importlocation;
    $("#sellerModal").modal("show");
  }


  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  popupDataSingle: {};
  popupData: any = {};
  singleMode: boolean = false;
  paymentData: Array<Object>;

  getPaymentData() {
    this.fillformService.getDataThrowPostMethod("paymentData", {}).subscribe(response => {
      this.paymentData = response['data']
      console.log('Data', response)
    })
  }

  singleModeO() {
    this.commonFormGroup.get("gstpaymentId").patchValue(1);
    let obj = Object.assign({}, this.commonDropRes)
    obj.payment = this.paymentData
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }

  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  addGrid(data) {

    var gridData = {
      columnDef: this.fillformService.getColumns("txpd", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("atadj_add_grid"), gridData, true, true);
  }
  ngOnDestroy() {
    if (this.splyTypeOvserver)
      this.splyTypeOvserver.unsubscribe();
    if (this.commonObserver)
      this.commonObserver.unsubscribe();
    if (this.rchargeObserver)
      this.rchargeObserver.unsubscribe();
  }
}
