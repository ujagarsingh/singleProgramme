import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AtadjRoutingModule } from './atadj-routing.module';
import { AtadjComponent } from './atadj.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { AtadjAddComponent } from './atadj-add/atadj-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [AtadjComponent, AtadjAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,
    AtadjRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    CalendarModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class AtadjModule { }
