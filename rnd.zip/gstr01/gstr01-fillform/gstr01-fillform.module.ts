import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Gstr01FillformRoutingModule } from './gstr01-fillform-routing.module';
import { Gstr01FillformComponent } from './gstr01-fillform.component';
import { SubHeaderComponent } from './sub-header/sub-header.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01FillformComponent, SubHeaderComponent ],
  imports: [
  	LanguageModule,
    SharedModule,
    CommonModule,
    GSTSharedModule,
    Gstr01FillformRoutingModule
  ]
})
export class Gstr01FillformModule { }
