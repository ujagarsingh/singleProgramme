import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { masterCommonConstant } from 'genmaster/src/master/constant/masterCommonConstant';
import { map } from 'rxjs/operators';
import { ValidationService } from 'genmaster/src/master/services/validation.service';
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';
declare var SagInputText;
declare var SagSelectBox;
declare var SagAutoCompleteBox;
declare var SagGridMP;

declare function success(m);
declare function alerts(m);
@Injectable({
	providedIn: 'root'
})

export class Gstr01FillformService {
	public roundOffBy = 2;
	returnUrl: any;
	masterBaseUrl: any;
	selectedData: any;
	constructor(private router: Router, private gridExportService: GridExportService, private fb: FormBuilder, private shareService: ShareService, private http: HttpClient) {
		const url = shareService.getData("currentUrl");
		this.returnUrl = masterCommonConstant.gstReturnBaseUrl;
		this.masterBaseUrl = masterCommonConstant.masterBaseUrl;

	}
	// ------------------------commonComponentMethods-------------------------------
	exit() {
		this.router.navigate(["/gst/return/GSTR1/"]);
	}


	commonSummaryGrid(data, gridId, self) {
		var column = [{ header: "S.No.", field: "sno", "editable": false, width: "50px", "align": "center" },
		{ header: "Section", field: "sectionName", filter: true, width: "270px", "editable": false, "text-align": "left" },
		{ header: "Total No Of Record", field: "invoiceCount", filter: true, width: "150px", "editable": false, "align": "right", "total": true, "total-text": "" },
		{ header: "Total Taxable Value", field: "totalTaxable", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total IGST", field: "igstAmtTotal", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total CGST", field: "cgstAmtTotal", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total SGST", field: "sgstAmtTotal", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total CESS", field: "cessAmtTotal", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total Invoice Value", field: "total", filter: true, width: "150px", "editable": false, "text-align": "right", "total": true, "total-text": "", "columnType": "numeric" }];
		var gridData = {
			columnDef: column,
			disableAllSearch: true,
			rowDef: data ? data : [],
			gridExportService: this.gridExportService,
			sheatDetails: { sheatName: `GSTR1_summary_List`, title: `GSTR1_summary_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_Summary` },
			callBack: {
				'onRowDbleClick': function () {
					self.onRowDbleClickSummary();
				}
			}
		};
		let sourceDiv = document.getElementById(gridId);
		return SagGridMP(sourceDiv, gridData, true, true);
	}


	commonDetailGrid(data, gridId, self) {
		let hide = false;
		if (this.shareService.getData("currentUrl")) {
			let selectedSectionArr = this.shareService.getData("currentUrl").split("/");
			let sectionName = selectedSectionArr[selectedSectionArr.length - 1]
			let validateSectionArr = ["b2cl", "b2cla", "exp", "expa"];
			validateSectionArr.forEach(element => {
				if (element == sectionName) {
					hide = true;
				}
			});
		}
		var column = [{ "colType": "checkBox", width: "50px", field: "checkBox", "text-align": "center" },
		{ header: "S.No.", field: "sno", width: "50px", "editable": false, "text-align": "center", },
		{ header: "Name", field: "usr_name", filter: true, width: "290px", "text-align": "left", "editable": false, "sort": true, },
		{ header: "GST No.", field: "gst_no", hidden: hide, filter: true, width: "130px", "text-align": "center", "editable": false, },
		{ header: "New Added In", field: "period", filter: true, width: "130px", "text-align": "center", "editable": false, },
		{ header: "Original Invoice No.", field: "org_invoice_no", filter: true, width: "170px", "editable": false, "text-align": "center", },
		{ header: "Original Invoice Date", field: "org_invoice_date", filter: true, width: "170px", "editable": false, "text-align": "center", },
		{ header: "Revised Invoice No.", field: "revised_invno", filter: true, width: "170px", "text-align": "left", "editable": false, },
		{ header: "Revised Invoice Date", field: "revised_invdt", filter: true, width: "170px", "editable": false, "text-align": "center", },
		{ header: "Taxable Value", field: "inv_txval", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "IGST", field: "igst", filter: true, width: "130px", "text-align": "right", "editable": true, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "CGST", field: "cgst", filter: true, width: "130px", "text-align": "right", "editable": true, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "SGST", field: "sgst", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "CESS", field: "cess", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Total Tax", field: "totalTax", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Invoice Value", field: "inv_val", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric" },
		{ header: "Uploaded By", field: "uploadBy", filter: true, width: "100px", "text-align": "center", "editable": false, },
		{ header: "Approved By", field: "approvedBy", filter: true, width: "100px", "text-align": "center", "editable": false, },
		{ header: "Counter Party Status", field: "cflag", filter: true, width: "180px", "text-align": "center", "editable": false, },
		{ header: "Return Filled By CP", field: "cfs", filter: true, width: "150px", "text-align": "center", "editable": false, },
		{ header: "Action", field: "action", filter: true, width: "145px", "editable": false, },
		{ header: "Earlier Period", field: "erp", filter: true, width: "120px", "editable": false, },
		{ header: "flag", field: "actionFlag", filter: true, width: "100px", display: "none" }];
		var gridData = {
			columnDef: column,
			disableAllSearch: true,
			rowDef: data ? data : [],
			gridExportService: this.gridExportService,
			sheatDetails: { sheatName: `GSTR1_Detail_List`, title: `GSTR1_Detail_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_Detail` },
			callBack: {
				'onRowClick': function () {
					self.onRowSelect();
				},
				'onRowDbleClick': function () {
					self.onRowDbleClickDetail();
				}
			}
		};
		let sourceDiv = document.getElementById(gridId);
		return SagGridMP(sourceDiv, gridData, true, true);
	}

	commonDetailComponentGrid(gridData, gridId, self) {
		gridData['callBack'] = {
			'onRowClick': function () {
				self.onRowSelect();
			},
			'onRowDbleClick': function () {
				self.onRowDbleClickDetail();
			}
		}
		gridData["gridExportService"] = this.gridExportService;
		let sourceDiv = document.getElementById(gridId);
		return SagGridMP(sourceDiv, gridData, true, true);
	}

	commonAmendmentAsPerReturnGrid(data, gridId, self) {
		var columns = [{ "colType": "checkBox", width: "50px", field: "checkBox", "text-align": "center" },
		{ header: "S.No.", field: "sno", width: "50px", "editable": false, "text-align": "center" },
		{ header: "POS", field: "stateName", filter: true, width: "130px", "text-align": "left", "editable": false },
		{ header: "Taxable Value", field: "TaxAmount", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Rate", field: "rate", filter: true, width: "130px", "editable": false, "text-align": "center" },
		{ header: "Differential(%)", field: "apptaxrt", width: "100px", "text-align": "center", "editable": false },
		{ header: "IGST Amount", field: "Iamt", filter: true, width: "150px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "CGST Amount", field: "Camt", filter: true, width: "150px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "SGST Amount", field: "Samt", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "CESS", field: "csrt", filter: true, width: "130px", "text-align": "center", "editable": false, "columnType": "numeric", },
		{ header: "CESS Amount", field: "cessNetAmt", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Total Tax", field: "totalTax", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Total Value", field: "totalValue", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", }]
		var gridData = {
			columnDef: columns,
			disableAllSearch: true,
			rowDef: data ? data : [],
			gridExportService: this.gridExportService,
			sheatDetails: { sheatName: `GSTR1_Amendment_List`, title: `GSTR1_Amendment_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_Amendment` },
			callBack: {
				'onRowClick': function () {
					self.onAsPerReturnRowSelect();
				},
				"onRowDbleClick": function () {
					self.openEntryModePopup();
				}
			}
		};
		let sourceDiv = document.getElementById(gridId);
		return SagGridMP(sourceDiv, gridData, true, true);

	}

	commonAsPerReturnGrid(data, gridId, self) {
		var columns = [{ "colType": "checkBox", width: "50px", field: "checkBox", "text-align": "center" },
		{ header: "S.No.", field: "sno", width: "50px", "editable": false, "text-align": "center" },
		{ header: "POS", field: "pos", filter: true, width: "130px", "text-align": "left", "editable": false },
		{ header: "Taxable Value", field: "taxableValue", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Rate", field: "commonRate", filter: true, width: "130px", "editable": false, "text-align": "center" },
		{ header: "Differential(%)", field: "invitemApptaxrt", width: "100px", "text-align": "center", "editable": false },
		{ header: "IGST Amount", field: "igst", filter: true, width: "150px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "CGST Amount", field: "cgst", filter: true, width: "150px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "SGST Amount", field: "sgst", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "CESS", field: "csrt", filter: true, width: "130px", "text-align": "center", "editable": false, "columnType": "numeric", },
		{ header: "CESS Amount", field: "Cess", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Operator Name", field: "operateor", filter: true, width: "200px", "text-align": "left", "editable": false },
		{ header: "Total Tax", field: "totelTax", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", },
		{ header: "Total Value", field: "invoiceValue", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", "columnType": "numeric", }]
		var gridData = {
			columnDef: columns,
			disableAllSearch: true,
			rowDef: data ? data : [],
			gridExportService: this.gridExportService,
			sheatDetails: { sheatName: `GSTR1_Return_List`, title: `GSTR1_Return_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_Return` },
			callBack: {
				'onRowClick': function () {
					self.onAsPerReturnRowSelect();
				},
				"onRowDbleClick": function () {
					self.openEntryModePopup();
				}
			}
		};
		let sourceDiv = document.getElementById(gridId);
		return SagGridMP(sourceDiv, gridData, true, true);
	}

	//-----------------------------------------------------------------------------

	//-------------------------------------------common api start-----------------------------

	public getInvTypeAndRevChrgsList() {
		return this.http.get(`${this.returnUrl}/getInvTypeAndRevChrgsList/GSTR1`);
	}
	/*****Anshu*******/
	public getInvTypeAndRevChrgsList2() {
		return this.http.get(`${this.returnUrl}/getInvTypeAndRevChrgsList/GSTR2A`);
	}

	public checkInvoiceNo(invNo, mclientId, yearId, invDt) {
		return this.http.get(`${this.returnUrl}/checkInvoiceNo?mClientId=${mclientId}&invNo=${invNo}&yearId=${yearId}&invoiceDate=${invDt}`);
	}

	public checkNoteNo(invNo, mclientId, yearId) {
		return this.http.get(`${this.returnUrl}/checkNoteNo?mClientId=${mclientId}&ntNum=${invNo}&yearId=${yearId}&invoiceDate=${null}`);
	}

	public saveInvoice(data, sectionName) {
		if (data && data.txnInvitemData) {
			data.txnInvitemData.forEach(element => {
				element.mstHsnitem = {
					"hsnitemid": element.hsnitemId && element.hsnitemId!='' ? Number(element.hsnitemId) : null
				}
				delete element.hsnitemId;
			});
			data.invFiling = null;
			return this.http.post(`${this.returnUrl}/saveInvoice/GSTR1/${sectionName}?mClientId=${this.shareService.getData("selectedClient")["mClientId"]}&gstnCid=${this.shareService.getData("selectedClient")["gstnCid"]}&yearId=${this.shareService.getData("year")["yearId"]}&monthId=${this.shareService.getData("month")["monthId"]}`, data);
		}
	}

	public appendOrOverrideBtocSData(data) {
		return this.http.post(`${this.returnUrl}/appendOrOverrideBtocSData`, data);
	}
	public getDataThrowGetMethod(subURL) {
		return this.http.get(`${this.returnUrl}/${subURL}`);
	}

	public getDataThrowPostMethod(subURL, reqJson) {
		return this.http.post(`${this.returnUrl}/${subURL}`, reqJson);
	}

	public getPortCode() {
		return this.http.get(`${this.masterBaseUrl}/portno/getAllRecord`)
	}

	//-----------------------------------------------------------------------------

	getSelectedValue(array, key, value) {
		for (const object of array) {
			if (object[key] && object[key] == value) {
				return object;
			}
		}
	}

	getColumns(section, showHideData) {
		if (section == "exp" || section == "expa") { //invitemIrt
			return [
				{ header: "S.No.", field: "sno", width: "50px", "editable": false, "text-align": "center", },
				{ header: "Category", hidden: !showHideData["Category"], field: "catId", width: "100px", "text-align": "center", "editable": true, "filter": true, component: "selectCategory" },
				{ header: "HSN/SAC", hidden: !showHideData["HSN/SAC"], field: "hsnitemId", width: "100px", "editable": true, "filter": true, "text-align": "center", component: "selectHsnSac" },
				{ header: "hsnItemId", hidden: true, field: "itemId", width: "100px", "editable": true, "filter": true, "text-align": "center", },
				{ header: "Item", hidden: !showHideData["Item"], field: "HsnDesc", width: "180px", "editable": true, "filter": true, "text-align": "left", component: "selectItem" },
				{ header: "Quantity", hidden: !showHideData["Quantity"], field: "invitemQty", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "inputQuantity" },
				{ header: "UQC", hidden: !showHideData["UQC"], field: "msrmntId", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "selectUqc" },
				{ header: "Per Piece Rate", hidden: !showHideData["Per Piece Rate"], field: "invitemRate", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "inputPerPieceRate" },
				{ header: "Taxable Value", headerClass: "required", field: "invitemTaxamt", width: "130px", "editable": true, "filter": true, "total": true, "text-align": "right", "total-text": "", component: "inputTaxableValue", columnType: "numeric" },
				{ header: "IGST Rate", headerClass: "required", field: "rate", width: "100px", "text-align": "center", "editable": true, component: "rate", },
				{ header: "Differential(%)", hidden: true, field: "invitemApptaxrt", width: "100px", "text-align": "center", "editable": true },
				{ header: "IGST Rate", hidden: true, field: "invitemIrt", width: "100px", "text-align": "center", "editable": true, "filter": true, component: "rate" },
				{ header: "IGST Amount", field: "invitemIamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", columnType: "numeric", component: "igstAmt", },
				{ header: "CGST Rate", hidden: true, field: "invitemCrt", width: "110px", "text-align": "center", "editable": true, "filter": true },
				{ header: "CGST Amount", hidden: true, field: "invitemCamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", component: "cgstAmt", columnType: "numeric" },
				{ header: "SGST Rate", hidden: true, field: "invitemSrt", width: "100px", "text-align": "center", "editable": true, "filter": true },
				{ header: "SGST Amount", hidden: true, field: "invitemSamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", component: "sgstAmt", columnType: "numeric" },
				{ header: "Cess Rate", hidden: true, field: "invitemCsrt", width: "100px", "text-align": "center", "editable": true, "filter": true, component: "csRt" },
				{ header: "Cess Amount", hidden: true, field: "invitemCsamt", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "csAmt", columnType: "numeric" },
				{ header: "Total Tax", field: "invitemTotltax", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "totalTax", columnType: "numeric" },
				{ header: "Total", field: "invitemTotlval", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "total", columnType: "numeric" }
			];
		} else {
			return [
				{ header: "S.No.", field: "sno", width: "50px", "editable": false, "text-align": "center", },
				{ header: "Category", hidden: !showHideData["Category"], field: "catId", width: "100px", "text-align": "center", "editable": true, "filter": true, component: "selectCategory" },
				{ header: "HSN/SAC", hidden: !showHideData["HSN/SAC"], field: "hsnitemId", width: "100px", "editable": true, "filter": true, "text-align": "center", component: "selectHsnSac" },
				{ header: "hsnItemId", hidden: true, field: "itemId", width: "100px", "editable": true, "filter": true, "text-align": "center", },
				{ header: "Item", hidden: !showHideData["Item"], field: "HsnDesc", width: "180px", "editable": true, "filter": true, "text-align": "left", component: "selectItem" },
				{ header: "Quantity", hidden: !showHideData["Quantity"], field: "invitemQty", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "inputQuantity" },
				{ header: "UQC", hidden: !showHideData["UQC"], field: "msrmntId", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "selectUqc" },
				{ header: "Per Piece Rate", hidden: !showHideData["Per Piece Rate"], field: "invitemRate", width: "130px", "editable": true, "filter": true, "text-align": "left", component: "inputPerPieceRate" },
				{ header: "Taxable Value", headerClass: "required", field: "invitemTaxamt", width: "130px", "editable": true, "filter": true, "total": true, "text-align": "right", "total-text": "", component: "inputTaxableValue", columnType: "numeric" },
				{ header: "Rate", headerClass: "required", field: "rate", width: "100px", "text-align": "center", "editable": true, component: "rate", },
				{ header: "Differential(%)", hidden: true, field: "invitemApptaxrt", width: "100px", "text-align": "center", "editable": true },
				{ header: "IGST Rate", hidden: true, field: "invitemIrt", width: "100px", "text-align": "center", "editable": true, "filter": true },
				{ header: "IGST Amount", field: "invitemIamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", columnType: "numeric", component: "igstAmt", },
				{ header: "CGST Rate", hidden: true, field: "invitemCrt", width: "110px", "text-align": "center", "editable": true, "filter": true },
				{ header: "CGST Amount", field: "invitemCamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", component: "cgstAmt", columnType: "numeric" },
				{ header: "SGST Rate", hidden: true, field: "invitemSrt", width: "100px", "text-align": "center", "editable": true, "filter": true },
				{ header: "SGST Amount", field: "invitemSamt", width: "130px", "editable": true, "filter": true, "text-align": "right", "total": true, "total-text": "", component: "sgstAmt", columnType: "numeric" },
				{ header: "Cess Rate", hidden: !showHideData["Cess Description"], field: "invitemCsrt", width: "100px", "text-align": "center", "editable": true, "filter": true, component: "csRt" },
				{ header: "Cess Amount", hidden: !showHideData["Cess Description"], field: "invitemCsamt", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "csAmt", columnType: "numeric" },
				{ header: "Total Tax", field: "invitemTotltax", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "totalTax", columnType: "numeric" },
				{ header: "Total", field: "invitemTotlval", width: "130px", "editable": true, "text-align": "right", "total": true, "filter": true, "total-text": "", component: "total", columnType: "numeric" }
			];
		}
	}

	getParticularAndSectionData(configuredData, gstrConf) {
		var response = {};
		if (configuredData && configuredData.length > 0) {
			for (var i = 0; i < configuredData.length; i++) {
				var obj = configuredData[i];
				response[obj.gstrconfParticular] = obj[gstrConf];
			}
		}
		return response;
	}

	getFromGroup() {
		//  this.fb.group({
		// 	"invId": [null],
		// 	"invType": [null],
		// 	"spId": [null, Validators.required],
		// 	"invUnregnm": [null],
		// 	"mclientId": [this.shareService.getData("selectedClient")["mClientId"]],
		// 	"gstnCid": [this.shareService.getData("selectedClient")["gstnCid"]],
		// 	"sectionId": [null, Validators.required],
		// 	"invNo": [null, Validators.required], //max 16
		// 	"invDt": [null, Validators.required],
		// 	"invSbnum": [null], //3-7
		// 	"invSbdt": [null],
		// 	"invSbpcode": [null],
		// 	"pbcodeId": [null],
		// 	"exptypeId": [null],
		// 	"gstnId": [null],
		// 	"invEconyn": [null],
		// 	"ecomGstnid": [null],
		// 	"invtypeId": [null],
		// 	"splytypeId": [null],
		// 	"gstpaymentId": [null],
		// 	"invTxval": [0],
		// 	"invVal": [0],
		// 	"invRchrgyn": ["N"],
		// 	"invRchrg": [null],
		// 	"invTotlitcavl": [null],
		// 	"invTotlitccp": [null],
		// 	"invDocno": [null],
		// 	"invDocdt": [null],
		// 	"stateId": [null, Validators.required],
		// 	"stateOid": [null],
		// 	"notetypeId": [null],
		// 	"notersnId": [null],
		// 	"invNtnum": [null],
		// 	"invNtdt": [null],
		// 	"invCfs": [null],
		// 	"invPrsyn": [null],
		// 	"invPaidyn": [null],
		// 	"invUploadyn": [null],
		// 	"invUploaddt": [null],
		// 	"invApprovalyn": [null],
		// 	"invApprovaldt": [null],
		// 	"invAmended": [null],
		// 	"invAmenddt": [null],
		// 	"invTime": [null],
		// 	"monthId": [this.shareService.getData("month")["monthId"]],
		// 	"monthOid": [null],
		// 	"qtyId": [null],
		// 	"yearId": [this.shareService.getData("year")["yearId"]],
		// 	"yearOid": [null],
		// 	"invPassed": [null],
		// 	"invStatus": [null],
		// 	"invRefinvid": [null],
		// 	"invOrigntnum": [null],
		// 	"invOrigntdt": [null],
		// 	"invOriginvno": [null],
		// 	"invOriginvdt": [null],
		// 	"invGstnrefno": [null],
		// 	"invGstntxnid": [null],
		// 	"gstnOid": [null],
		// 	"invChksum": [null],
		// 	"invIsmatch": [null],
		// 	"invIsimport": [null],
		// 	"invCprtn": [null],
		// 	"invCflag": [null],
		// 	"invFlag": [null],
		// 	"invUpdby": [null],
		// 	"invRegime": [null],
		// 	"invDstatus": [null],
		// 	"invMusrid": [null],
		// 	"invAdjamt": [null],
		// 	"invBal": [null],
		// 	"invFiling": [null],
		// 	"amdeId": [null],
		// 	"invItcflag": [null],
		// 	"yearCid": [null],
		// 	"monthCid": [null],
		// 	"itcrsnId": [null],
		// 	"invPinvno": [null],
		// 	"invVchno": [null],
		// 	"invVchdt": [null],
		// 	"invNum": [null],
		// 	"invCusrid": [null],
		// 	"sagclientId": [null],
		// 	"flag": [null]
		// });

		return this.fb.group({
			"invId": [null],
			//'differential': [null],
			"invType": null,
			"sp": this.fb.group({
				"spId": [null, Validators.required],
			}),
			"invUnregnm": [null],
			"mclientId": [this.shareService.getData("selectedClient")["mClientId"]],
			"gstnC": this.fb.group({
				"gstnId": [this.shareService.getData("selectedClient")["gstnCid"]],
			}),
			//"section" : null,
			"section": this.fb.group({
				"sectionId": [null, Validators.required],
			}),

			"invNo": [null, [ValidationService.invoiceNoValidator, Validators.required]], //max 16
			"invDt": [null, Validators.required],
			"invSbnum": [null], //3-7
			"invSbdt": [null],
			"invSbpcode": [null],

			"pbcode": this.fb.group({
				"pbcodeId": [null],
			}),

			//  "pbcode": [null],

			// "exptype":[null],

			"exptype": this.fb.group({
				"exptypeId": [null],
			}),

			// "gstn":[null],
			"gstn": this.fb.group({
				"gstnId": [null],
			}),
			"invEconyn": [null],
			// "ecomgstn":[null],

			"ecomgstn": this.fb.group({
				"gstnId": [null],
			}),
			// "invtype":[null],
			"invtype": this.fb.group({
				"invtypeId": [null],
			}),
			// "splytype":[null],
			"splytype": this.fb.group({
				"splytypeId": [null],
			}),
			// "gstpayment":[null],

			"gstpayment": this.fb.group({
				"gstpaymentId": [null],
			}),

			"invTxval": [0],
			"invVal": [0],
			"invRchrgyn": ["N"],
			"invRchrg": [null],
			"invTotlitcavl": [null],
			"invTotlitccp": [null],
			"invDocno": [null],
			"invDocdt": [null],

			// "state":[null],

			"state": this.fb.group({
				"stateId": [null, Validators.required],
			}),

			// "stateO":[null],

			"stateO": this.fb.group({
				"stateId": [null],
			}),

			// "notetype":[null],

			"notetype": this.fb.group({
				"notetypeId": [null],
			}),

			// "notersn":[null],

			"notersn": this.fb.group({
				"notersnId": [null],
			}),
			"invNtnum": [null],
			"invNtdt": [null],
			"invCfs": [null],
			"invPrsyn": [null],
			"invPaidyn": [null],
			"invUploadyn": [null],
			"invUploaddt": [null],
			"invApprovalyn": [null],
			"invApprovaldt": [null],
			"invAmended": [null],
			"invAmenddt": [null],
			"invTime": [null],

			// "month":[null],

			"month": this.fb.group({
				"monthId": [this.shareService.getData("month")["monthId"]],
			}),

			// "montho":[null],

			"montho": this.fb.group({
				"monthId": [null],
			}),

			// "qty":null,

			"qty": this.fb.group({
				"qtyId": [null],
			}),

			// "year":[null],

			"year": this.fb.group({
				"yearId": [this.shareService.getData("year")["yearId"]],
			}),

			// "yearo":[null],

			"yearo": this.fb.group({
				"yearId": [null],
			}),

			"invPassed": [null],
			"invStatus": [null],
			"invRefinvid": [null],
			"invOrigntnum": [null],
			"invOrigntdt": [null],
			"invOriginvno": [null],
			"invOriginvdt": [null],
			"invGstnrefno": [null],
			"invGstntxnid": [null],
			// "gstno":[null],

			"gstno": this.fb.group({
				"gstnId": [null],
			}),
			"invChksum": [null],
			"invIsmatch": [null],
			"invIsimport": [null],
			"invCprtn": [null],
			"invCflag": [null],
			"invFlag": [null],
			"invUpdby": [null],
			"invRegime": [null],
			"invDstatus": [null],
			"invMusrid": [null],
			"invAdjamt": [null],
			"invBal": [null],
			"invFiling": [null],
			"amdeId": [null],
			"invItcflag": [null],

			// "yearC":[null],

			"yearC": this.fb.group({
				"yearId": [null],
			}),

			// "monthC":[null],

			"monthC": this.fb.group({
				"monthId": [null],
			}),

			// "itcrsn":[null],

			"itcrsn": this.fb.group({
				"itcrsnId": [null],
			}),
			"invPinvno": [null],
			"invVchno": [null],
			"invVchdt": [null],
			"invNum": [null],
			"invCusrid": [null],
			"sagclientId": [null],
			"flag": [null],
			"invsec7act": ['N'],
			"invrfndelg": ['N']
		});
	}
	getSingleTypeFromGroup() {
		return this.fb.group({
			"invitemApptaxrt": [null],  //differential
			"invitemIrt": [null],      // IGST Rate
			"invitemIamt": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],		//IGST amount
			"invitemCamt": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],		//CGST amount
			"invitemSamt": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],		//SGST amount
			"invitemCsrt": [null],		//Cess Rate
			"invitemCsamt": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],		//Cess Amount
			"invitemTotlval": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],	//Total value
			"invitemTaxamt": [null, {
				validators: [ValidationService.decimalNumberValidator]
			}],	//Taxable Amount
		});
	}
	addInvoice(activeRoute) {
		let selectedClient = this.shareService.getData("selectedClient");
		//[disabled]="!selectedClient || returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed'" [routerLink]="['../amv']"
		if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
		} else {
			this.router.navigate(['amv'], { relativeTo: activeRoute });
		}
	}

	modifyInvoice(gridDynamicObj, activeRoute, url, type) {
		let selectedClient = this.shareService.getData("selectedClient");
		//[disabled]="!selectedClient || returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed'" [routerLink]="['../amv']"
		if (type == "modify") {
			if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
				return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
			}
		}
		var selectedRow = gridDynamicObj.getSeletedRowData();
		if (selectedRow) {
			selectedRow.amvType = type;
			this.shareService.setData("selectedInvoice", selectedRow);
			this.router.navigate([url], { relativeTo: activeRoute });
		} else {
			alerts("Select An Invoice To modify or view");
		}
	}

	addRow(gridDynamicObj) {
		gridDynamicObj.addRow(gridDynamicObj.sagGridObj.AllRowIndex.length, {
			"sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
			"rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
			"invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
		})
		gridDynamicObj.disableCell(gridDynamicObj.sagGridObj.AllRowIndex.length - 1, 'rate');
	}

	preventAlphabets(evt, ele) {
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (ele.value.includes('.')) {
			var arr = ele.value.split('.');
			if (arr[1].length > this.roundOffBy - 1)
				return false;
		}
		if (charCode == 46 && ele.value.split('.').length > 1)
			return false;
		if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
			return false;
		return true;
	}

	//--------------------common grid methods----------------------------
	enableDisableGridCell(index, gridObj) {
		let obj = gridObj.getRowData(index);
		obj["invitemTaxamt"] != null && !isNaN(obj["invitemTaxamt"]) ? gridObj.enableCell(index, "rate") : gridObj.disableCell(index, "rate");
	}

	fillInvoiceValueAndTxableValue(self) {
		var array = self.gridDynamicObj.getGridData();
		var total = 0, totaltaxableVal = 0;
		for (let i = 0; i < array.length; i++) {
			const obj = array[i];
			if (obj["invitemTotlval"] && !isNaN(obj["invitemTotlval"]))
				total += parseFloat(obj["invitemTotlval"]);
			if (obj["invitemTaxamt"] && !isNaN(obj["invitemTaxamt"]))
				totaltaxableVal += parseFloat(obj["invitemTaxamt"]);
		}
		self.commonFormGroup.patchValue({ invTxval: Number(totaltaxableVal.toFixed(self.fillformService.roundOffBy)), invVal: Number(total.toFixed(self.fillformService.roundOffBy)) });
	}

	fillDataAccordingSupplyType(type, obj, selectedInvType, roundOffBy) {
		selectedInvType = selectedInvType ? selectedInvType : {};
		let withoutPaymentCond = selectedInvType.invtypeCode != "SEWOP" && selectedInvType.invtypeCode != "WOPAY" && selectedInvType.invtypeCode != "EXPWOP";
		if (obj && obj.invitemTaxamt >= 0 && obj.rate && !isNaN(obj["rate"]) && !isNaN(obj["invitemTaxamt"])) {
			obj["invitemCsrt"] = obj.invitemCsrt != null && !isNaN(obj.invitemCsrt) ? parseFloat(obj.invitemCsrt) : null;
			if (obj["invitemCsrt"] != null) {
				obj["invitemCsamt"] = parseFloat(((parseFloat(obj.invitemTaxamt) * parseFloat(obj.invitemCsrt) / 100) * (obj.invitemApptaxrt ? parseInt(obj.invitemApptaxrt) / 100 : 1)).toFixed(roundOffBy));
			}
			var totaltax = withoutPaymentCond ? parseFloat(((parseFloat(obj.invitemTaxamt) * parseFloat(obj.rate) / 100) * (obj.invitemApptaxrt ? parseInt(obj.invitemApptaxrt) / 100 : 1)).toFixed(roundOffBy)) + (obj["invitemCsamt"] != null ? obj["invitemCsamt"] : 0) : 0;
			if (!selectedInvType || withoutPaymentCond)
				obj["invitemTotltax"] = totaltax;

			var total = parseFloat((totaltax + parseFloat(obj.invitemTaxamt)).toFixed(roundOffBy))
			obj["invitemTotlval"] = total;

			if (type == "INTER" && (!selectedInvType || withoutPaymentCond)) {
				obj["invitemCrt"] = null; obj["invitemSrt"] = null;
				obj["invitemCamt"] = null; obj["invitemSamt"] = null;
				obj["invitemIrt"] = parseFloat(obj["rate"]);
				obj["invitemIamt"] = parseFloat(((parseFloat(obj.invitemTaxamt) * parseFloat(obj.rate) / 100) * (obj.invitemApptaxrt ? parseInt(obj.invitemApptaxrt) / 100 : 1)).toFixed(roundOffBy));
			} else if (!selectedInvType || (selectedInvType.invtypeCode != "SEWOP" && selectedInvType.invtypeCode != "SEWP"
				&& selectedInvType.invtypeCode != "WOPAY" && selectedInvType.invtypeCode != "EXPWP" && selectedInvType.invtypeCode != "EXPWOP")) {
				obj["invitemIrt"] = null;
				obj["invitemIamt"] = null;
				var rt = parseFloat(obj["rate"]) / 2;
				var val = parseFloat(((parseFloat(obj.invitemTaxamt) * parseFloat(obj.rate) / 200) * (obj.invitemApptaxrt ? parseInt(obj.invitemApptaxrt) / 100 : 1)).toFixed(roundOffBy));
				obj["invitemCrt"] = rt; obj["invitemSrt"] = rt;
				obj["invitemCamt"] = val; obj["invitemSamt"] = val;
			}
			if (selectedInvType.invtypeCode == "SEWOP" || selectedInvType.invtypeCode == "WOPAY" || selectedInvType.invtypeCode == "EXPWOP") {
				obj["invitemIrt"] = parseFloat(obj["rate"]);
			}

		}
		return obj;
	}

	commonMethods(self, index, params) {
		params.invitemApptaxrt = self.selectedDiff && !isNaN(self.selectedDiff) ? self.selectedDiff : null;
		if (self.callFillDataAccordingSupplyTypeMethod) {
			this.fillDataAccordingSupplyType(self.supplyTypeCode, params, self.selectedInvoiceType, self.fillformService.roundOffBy);
		}
	    self.gridDynamicObj.updateRow(index, params);
		//if (self.gridDynamicObj.getGridData().length - 1 == index)
		self.fillformService.fillInvoiceValueAndTxableValue(self);
		self.fillformService.enableDisableGridCell(index, self.gridDynamicObj);
	}

	hsnCodeAndItem: any;
	selectedHsnOrSacListGrid: any;
	selectedDescriptionGrid: any;
	selectedhsnCodeGrid: any;
	getSelectedHsnSacGrid(id) {
		this.selectedHsnOrSacListGrid = [];
		this.selectedDescriptionGrid = [];
		this.selectedhsnCodeGrid = [];
		for (let obj of this.hsnCodeAndItem) {
			if (obj.catId == id) {
				this.selectedHsnOrSacListGrid.push(obj)
				this.selectedDescriptionGrid.push(obj.description)
				this.selectedhsnCodeGrid.push(obj.hsnCode)
			}
		}
	}

	/**
	 * this is common method for all gstr01 fillform component which return the component 
	 * @param self : this 
	 */

	getGridComponent(self) {
		let selectCategory = new SagSelectBox(self.categoryArr, function (ele, params) {
			ele.onchange = function () {
				//alert(ele.value)
				self.hsnCodeList = [{ "key": "", "val": "-Select-" }];
				self.hsnDesList = [{ "key": "", "val": "-Select-" }];
				for (let i = 0; i < self.completeHsnList.length; i++) {
					let obj = self.completeHsnList[i];
					if (obj.catId == ele.value) {
						self.hsnDesList.push({ "key": obj.hsnItemId, "val": obj.description } );
						self.hsnCodeList.push({ "key": obj.hsnItemId, "val": obj.hsnCode } );
					}
				}
				selectHsnSac.setOption(self.hsnCodeList);
				selectItem.setOption(self.hsnDesList);
			}
		});

		let rate = new SagSelectBox(self.rateArr, function (ele, params) {
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					if (!isNaN(ele.value)) {
						params.rowValue.rate = ele.value;
						self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);
					}
				}
			}
		});

		let selectHsnSac = new SagSelectBox(self.hsnCodeList, function (ele, prm) {
			ele.onchange = function () {
				prm.rowValue.hsnitemId = ele.value == '' ? null : ele.value;
				prm.rowValue.HsnDesc = ele.value == '' ? null : ele.value;
				self.gridDynamicObj.updateRow(prm.rowIndex, prm.rowValue);
			}
		})

		let selectItem = new SagSelectBox(self.hsnDesList, function (ele, prm) {
			ele.onchange = function () {
				prm.rowValue.hsnitemId = ele.value == '' ? null : ele.value;
				prm.rowValue.HsnDesc = ele.value == '' ? null : ele.value;
				self.gridDynamicObj.updateRow(prm.rowIndex, prm.rowValue);
			}
		})

		let selectUqc = new SagSelectBox(self.uqcArr, function (ele, params) {
			ele.onchange = function () {
			}
		});

		let inputQuantity = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					if (params.rowValue.invitemRate && !isNaN(params.rowValue.invitemRate))
						params.rowValue.invitemTaxamt = (parseFloat(ele.value ? ele.value : 0) * parseFloat(params.rowValue.invitemRate));

					params.rowValue.invitemQty = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);
				}
			}
		});

		let igstAmt = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemIamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
				}
			}
		});

		let cgstAmt = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemCamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
				}
			}
		});

		let sgstAmt = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemSamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
				}
			}
		});

		let csAmt = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemCsamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
				}
			}
		});

		let csRt = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				return self.fillformService.preventAlphabets(evt, ele);
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					if (!isNaN(ele.value)) {
						params.rowValue.invitemCsrt = ele.value;
						self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);
					}
				}
			}
		});

		let totalTax = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				return self.fillformService.preventAlphabets(evt, ele);
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemTotltax = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "totalTax", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
				}
			}
		});

		let total = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				return self.fillformService.preventAlphabets(evt, ele);
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemTaxamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.calculateTotalTaxAndValue(self.gridDynamicObj, params.rowValue, params.rowIndex, "total", self.fillformService.roundOffBy);
					self.fillformService.fillInvoiceValueAndTxableValue(self);
					//self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);
				}
			}
		});

		/**
		 * component on per piece rate*/
		let inputPerPieceRate = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					if (params.rowValue.invitemQty && !isNaN(params.rowValue.invitemQty))
						params.rowValue.invitemTaxamt = (parseFloat(ele.value ? ele.value : 0) * parseFloat(params.rowValue.invitemQty));

					params.rowValue.invitemRate = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);
				}
			}
		});

		/**
		 * component on taxable value*/
		let inputTaxableValue = new SagInputText({}, function (ele, params) {
			ele.onkeypress = function (evt) {
				if (self.fillformService.commonValidation(self)) {
					return self.fillformService.preventAlphabets(evt, ele);
				}
				return false;
			}
			ele.onchange = function () {
				if (self.fillformService.commonValidation(self)) {
					params.rowValue.invitemTaxamt = ele.value != "" && !isNaN(ele.value) ? parseFloat(ele.value) : null;
					self.fillformService.commonMethods(self, params.rowIndex, params.rowValue);					
			        self.gridDynamicObj.focusCell(params.rowIndex, "rate");
				}
			}
		});

		let components = {
			"selectCategory": selectCategory,
			"selectHsnSac": selectHsnSac,
			"selectItem": selectItem,
			"selectUqc": selectUqc,
			"rate": rate,
			"inputQuantity": inputQuantity,
			"inputPerPieceRate": inputPerPieceRate,
			"inputTaxableValue": inputTaxableValue,
			"igstAmt": igstAmt,
			"cgstAmt": cgstAmt,
			"sgstAmt": sgstAmt,
			"csAmt": csAmt,
			"csRt": csRt,
			"totalTax": totalTax,
			"total": total
		};
		return components;
	}

	calculateTotalTaxAndValue(gridObject, rowData, rowIndex, changesIn, roundOffBy) {
		var totalTax = 0;
		if (changesIn === "total") {

		} else if (changesIn === "totalTax") {
			rowData.invitemTotlval = rowData.invitemTotltax + (rowData.invitemTaxamt != null && !isNaN(rowData.invitemTaxamt) ? rowData.invitemTaxamt : 0);
		} else {
			if (rowData.invitemIamt != null && !isNaN(rowData.invitemIamt)) {
				totalTax = Number((parseFloat(rowData.invitemIamt) + totalTax).toFixed(roundOffBy));
			}
			if (rowData.invitemCamt != null && !isNaN(rowData.invitemCamt)) {
				totalTax = Number((parseFloat(rowData.invitemCamt) + totalTax).toFixed(roundOffBy));
			}
			if (rowData.invitemSamt != null && !isNaN(rowData.invitemSamt)) {
				totalTax = Number((parseFloat(rowData.invitemSamt) + totalTax).toFixed(roundOffBy));
			}
			if (rowData.invitemCsamt != null && !isNaN(rowData.invitemCsamt)) {
				totalTax = Number((parseFloat(rowData.invitemCsamt) + totalTax).toFixed(roundOffBy));
			}
			rowData.invitemTotltax = totalTax;
			rowData.invitemTotlval = Number((rowData.invitemTotltax + (rowData.invitemTaxamt != null && !isNaN(rowData.invitemTaxamt) ?
				parseFloat(rowData.invitemTaxamt) : 0)).toFixed(roundOffBy));
		}
		gridObject.updateRow(rowIndex, rowData);
	}

	removeUnwantedKeysFromGridData(items) {
		var unwantedKeys = ["sno", "HsnCode", "HsnDesc", "groupName", "createdOn", "sag_G_Index", "rate", "txnInvitemData", "lastUpdatedOn"];
		for (const obj of items) {
			for (const key of unwantedKeys) {
				if (obj.hasOwnProperty(key))
					delete obj[key];
			}
		}
		return items;
	}

	commonMethodForGridSelectBox(array, keyName, valueName, addPrecents) {
		var res = [];
		for (let i = 0; i < array.length; i++) {
			if (i == 0)
				res.push({ "key": "", "val": "-Select-" });

			let value = array[i];
			let obj = { "key": value[keyName], "val": value[valueName] + (addPrecents == true ? "%" : "") };
			res.push(obj);
		}
		return res;
	}



	//validation methods -------------------------------------------------
	commonValidation(self) {
		if (self.commonFormGroup.status != "VALID") {
			alerts("Required Fields Are Missing");
			return false;
		}
		return true;
	}

	validateGridData(gridItems, selectedInvoiceType, supplyTypeCode) {
		if (gridItems.length > 0) {
			for (var i = 0; i < gridItems.length; i++) {
				let obj = gridItems[i];
				if ((obj["invitemTaxamt"] == null) || (obj["invitemTotlval"] == null)) {
					alerts("Fill item Details Properly");
					return;
				}
				if (selectedInvoiceType && (selectedInvoiceType["invtypeCode"] == "SEWOP" || selectedInvoiceType["invtypeCode"] == "EXPWOP") && (obj["invitemIamt"] != null || obj["invitemCamt"] != null ||
					obj["invitemSamt"] != null || obj["invitemCsamt"] != null || obj["invitemCrt"] != null ||
					obj["invitemSrt"] != null || obj["invitemCsrt"] != null || obj["invitemCsrt"] != null)) {
					alerts("Data Is Not Proper According To Invoice Type")
					return;
				} else if (selectedInvoiceType && (selectedInvoiceType["invtypeCode"] == "SEWP" || selectedInvoiceType["invtypeCode"] == "EXPWP") && (obj["invitemCamt"] != null ||
					obj["invitemSamt"] != null || obj["invitemCsamt"] != null || obj["invitemCrt"] != null ||
					obj["invitemSrt"] != null || obj["invitemCsrt"] != null)) {
					alerts("Data Is Not Proper According To Invoice Type");
					return;
				} else if (!selectedInvoiceType) {
					alerts("Invoice Type Is A Required Field");
					return;
				}

				if (supplyTypeCode && supplyTypeCode == "INTER" && (
					obj["invitemCamt"] != null || obj["invitemSamt"] != null || obj["invitemCrt"] != null || obj["invitemSrt"] != null)) {
					alerts("Data Is Not Proper According To Seller Type");
					return;
				} else if (supplyTypeCode && supplyTypeCode == "INTRA" && (obj["invitemIamt"] != null)) {
					alerts("Data Is Not Proper According To Seller Type");
					return;
				} else if (!supplyTypeCode) {
					alerts("supply Type Is A Required Field");
					return;
				}
			}
		} else {
			alerts("Invoice Item can't be Null");
			return;
		}
		return true;
	}


	invoiceTypeChange(commonFormGroup, selectedInvoiceType, gridDynamicObj, supplyTypeCode, selectedInvoice, selectedDiff, callFillDataAccordingSupplyTypeMethod) {
		if (selectedInvoiceType.invtypeCode == "SEWOP" || selectedInvoiceType.invtypeCode == "EXPWOP") {
			this.updateFieldsAccordingSEWOP(gridDynamicObj);
		} else if (selectedInvoiceType.invtypeCode == "SEWP" || selectedInvoiceType.invtypeCode == "EXPWP") {
			this.updateFieldsAccordingSEWP(gridDynamicObj, supplyTypeCode);
		} else {
			this.enableDisableGridColumn(gridDynamicObj, supplyTypeCode);
		}
		if (selectedInvoice && selectedInvoice.amvType == "view") {
			commonFormGroup.disable();
			gridDynamicObj.disableAllRow();
		}
		if (callFillDataAccordingSupplyTypeMethod)
			this.updateGrid(gridDynamicObj, selectedDiff, supplyTypeCode, selectedInvoiceType, commonFormGroup);
	}


	updateGrid(gridDynamicObj, selectedDiff, supplyTypeCode, selectedInvoiceType, commonFormGroup) {
		var arr = gridDynamicObj.getGridData();
		var invTotal = 0.0;
		var invTotalTax = 0.0;
		for (var i = 0; i < arr.length; i++) {
			let obj = arr[i];
			if (obj.invitemTaxamt && !isNaN(obj["invitemTaxamt"])) {
				obj.invitemApptaxrt = selectedDiff;
				this.fillDataAccordingSupplyType(supplyTypeCode, obj, selectedInvoiceType, this.roundOffBy);
				invTotal += parseFloat(obj["invitemTotlval"] != null && !isNaN(obj["invitemTotlval"]) ? obj["invitemTotlval"] : 0);
				invTotalTax += (obj["invitemTotltax"] != null && !isNaN(obj["invitemTotltax"]) ? obj["invitemTotltax"] : 0);
				gridDynamicObj.updateRow(i, obj);
			}
		}
		commonFormGroup.patchValue({ invTxval: Number(invTotalTax.toFixed(this.roundOffBy)), invVal: Number(invTotal.toFixed(this.roundOffBy)) });
	}

	enableDisableGridColumn(gridDynamicObj, supplyTypeCode) {
		if (supplyTypeCode) {
			supplyTypeCode == "INTER" ? gridDynamicObj.enableColumn("invitemIrt") : gridDynamicObj.disableColumn("invitemIrt");
			supplyTypeCode == "INTER" ? gridDynamicObj.enableColumn("invitemIamt") : gridDynamicObj.disableColumn("invitemIamt");
			supplyTypeCode == "INTER" ? gridDynamicObj.disableColumn("invitemCrt") : gridDynamicObj.enableColumn("invitemCrt");
			supplyTypeCode == "INTER" ? gridDynamicObj.disableColumn("invitemCamt") : gridDynamicObj.enableColumn("invitemCamt");
			supplyTypeCode == "INTER" ? gridDynamicObj.disableColumn("invitemSrt") : gridDynamicObj.enableColumn("invitemSrt");
			supplyTypeCode == "INTER" ? gridDynamicObj.disableColumn("invitemSamt") : gridDynamicObj.enableColumn("invitemSamt");
			gridDynamicObj.enableColumn("invitemCsamt");
			gridDynamicObj.enableColumn("invitemCsrt");
			gridDynamicObj.enableColumn("invitemTotltax");
		}
	}

	updateFieldsAccordingSEWP(gridDynamicObj, supplyTypeCode) {
		if (supplyTypeCode == "INTER") {
			gridDynamicObj.enableColumn("invitemIrt");
			gridDynamicObj.enableColumn("invitemIamt");
		} else {
			gridDynamicObj.disableColumn("invitemIrt");
			gridDynamicObj.disableColumn("invitemIamt");
		}
		gridDynamicObj.disableColumn("invitemCrt");
		gridDynamicObj.disableColumn("invitemCamt");
		gridDynamicObj.disableColumn("invitemSrt");
		gridDynamicObj.disableColumn("invitemSamt");
		gridDynamicObj.enableColumn("invitemCsrt");
		gridDynamicObj.enableColumn("invitemCsamt");
		gridDynamicObj.enableColumn("invitemTotltax");
		var arr = gridDynamicObj.getGridData();
		for (var i = 0; i < arr.length; i++) {
			let obj = arr[i];
			if (supplyTypeCode != "INTER") {
				obj["invitemIrt"] = null;
				obj["invitemIamt"] = null;
			}
			obj["invitemCrt"] = null;
			obj["invitemCamt"] = null;
			obj["invitemSrt"] = null;
			obj["invitemSamt"] = null;
			obj["invitemCsrt"] = null;
			obj["invitemCsamt"] = null;
			obj["invitemTotltax"] = null;
			gridDynamicObj.updateRow(i, obj);
		}
	}

	updateFieldsAccordingSEWOP(gridDynamicObj) {
		gridDynamicObj.disableColumn("invitemIrt");
		gridDynamicObj.disableColumn("invitemIamt");
		gridDynamicObj.disableColumn("invitemCrt");
		gridDynamicObj.disableColumn("invitemCamt");
		gridDynamicObj.disableColumn("invitemSrt");
		gridDynamicObj.disableColumn("invitemSamt");
		gridDynamicObj.disableColumn("invitemCsrt");
		gridDynamicObj.disableColumn("invitemCsamt");
		gridDynamicObj.disableColumn("invitemTotltax");
		var arr = gridDynamicObj.getGridData();
		for (var i = 0; i < arr.length; i++) {
			let obj = arr[i];
			obj["invitemIrt"] = null;
			obj["invitemIamt"] = null;
			obj["invitemCrt"] = null;
			obj["invitemCamt"] = null;
			obj["invitemSrt"] = null;
			obj["invitemSamt"] = null;
			obj["invitemCsrt"] = null;
			obj["invitemCsamt"] = null;
			obj["invitemTotltax"] = null;
			gridDynamicObj.updateRow(i, obj);
		}
	}
}
