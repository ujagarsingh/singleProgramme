import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UploadApprovedStatusComponent } from 'src/gst/return/common-component/upload-approved-status/upload-approved-status.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [ UploadApprovedStatusComponent],
  imports: [
  	LanguageModule,
    GSTSharedModule,
    CommonModule
  ],exports : [GSTSharedModule,UploadApprovedStatusComponent]
})
export class Gstr01FillformSharedModule { }
