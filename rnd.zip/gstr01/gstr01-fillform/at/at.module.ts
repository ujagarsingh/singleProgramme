import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AtRoutingModule } from './at-routing.module';
import { AtComponent } from './at.component';

import { AtAddComponent } from './at-add/at-add.component';

import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [AtComponent, AtAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,GSTSharedModule,
    SharedModule, Gstr01FillformSharedModule,
    AtRoutingModule,
    GSTSharedModule,
    CalendarModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class AtModule { }
