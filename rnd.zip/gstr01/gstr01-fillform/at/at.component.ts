import { Component, OnInit, OnDestroy } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Subscription } from 'rxjs';
import { RetrunService } from '../../../../return/retrun.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AnxCommonServiceService } from '../../../../return/anx-one/anx-common-service.service';
declare function alerts(n);
declare function success(n);
declare const $;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  templateUrl: './at.component.html',
  styleUrls: ['./at.component.scss']
})
export class AtComponent implements OnInit {
  location: ComponentLocation;
  importInputData: {};

  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }

  EntryModeLocation: ComponentLocation = {
    moduleId: 'entryModeModule',
    selector: 'app-entry-mode'
  }

  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }
  clientStateName: any;

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }
  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }
  popupData: any;
  gridId: any = "gstrone_fillform_at";
  data_type: string = "asPerReturn";
  sourceDiv: any;
  gridData: any;
  gridDynamicObj: any;
  selectedClient: any;
  sub: Subscription;

  constructor(private commonReturnService: AnxCommonServiceService, private eventEmitter: EventEmitterService, public router: Router, public activeRoute: ActivatedRoute,
    private returnService: RetrunService, private fillformService: Gstr01FillformService, private shareService: ShareService) {
    shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.clientStateName = this.selectedClient.stateName;
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this.clientStateName = this.selectedClient.stateName;
      this.changeData();
    });
  }

  ngOnInit() {
    this.findEntryModeOpen = false;
    if (!this.selectedClient)
      this.fillformService.exit();
    this.changeData();
  }

  asPerReturnSub: Subscription;
  invoiceSub: Subscription;
  changeData() {
    this.selectedInvoice = undefined;
    if (this.data_type === "invoiceWise") {
      this.popupData = { "popupData": { case: "normal", formtype: "GSTR1", sectionCode: 'at', show: false, gridObj: this.gridDynamicObj } };
      this.findEntryModeOpen = false;
      let obj = {
        formType: 'GSTR1',
        yearId: this.shareService.getData("year")["yearId"],
        monthId: this.shareService.getData("month")["monthId"],
        mClientId: this.shareService.getData("selectedClient")["mClientId"],
        gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
        sectionName: "at"
      };

      this.invoiceSub = this.returnService._getAllInvoiceDetails(obj).subscribe(data => {
        if (data["httpStatus"] == 200) {
          this.gridDynamicObj = this.fillformService.commonDetailGrid(data["data"], this.gridId, this);
        }
      });
    } else {
      let obj =
      {  // reqData for Dummy purpose, change according requirements..
        'year': this.shareService.getData("year")["yearId"],
        'month': this.shareService.getData("month")["monthId"],
        'quarter': null,
        'clientId': this.shareService.getData("selectedClient")["mClientId"],
        'ledgerFlag': null,
        'gstnCid': this.shareService.getData("selectedClient")["gstnCid"],
        'gstnWiseOptionsGstr1': null,
        'periodCode': null,
        'fromDate': null,
        'toDate': null,
        'sectionName': 'at',
        'reversalFlag': null,
        'formType': 'GSTR1', //this.this.selectedDropDownDetails.formType
        'mClientId': this.shareService.getData("selectedClient")["mClientId"]
      }

      this.asPerReturnSub = this.commonReturnService._getSummaryDetails(obj).subscribe(data => {
        if (data["data"]) {
          this.gridDynamicObj = this.fillformService.commonAsPerReturnGrid(data["data"], this.gridId, this);
          if (this.findEntryModeOpen) {
            this.eventEmitter.loadEntryModePopup(this.gridDynamicObj);
          }
        }
      });

    }
  }

  selectedInvoice: any;
  onRowSelect() {
    if (this.findEntryModeOpen && this.data_type === "asPerReturn") {
      this.openEntryModePopup();
    } else {
      this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
    }
  }

  findEntryModeOpen: boolean = false;
  openEntryModePopup() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    this.findEntryModeOpen = true;
    let selectedInvoice = this.gridDynamicObj.getSeletedRowData();
    if (selectedInvoice)
      this.shareService.setData("selectedInvoiceEntryMode", selectedInvoice);
    else
      this.shareService.removeData("selectedInvoiceEntryMode");
    this.popupData = { "popupData": { case: "normal", formtype: "GSTR1", sectionCode: 'at', show: true, gridObj: this.gridDynamicObj } };
    this.location = this.EntryModeLocation;
    this.eventEmitter.loadEntryModePopup(this.gridDynamicObj);
  }

  onKeywordsChange = (data) => {
    if (data == "back")
      this.findEntryModeOpen = false;
    this.changeData();
  }

  deleteSelectedInvoice() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    let checkedInvoices = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    let invIds = [];
    if (checkedInvoices.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {
        checkedInvoices.forEach(element => { invIds.push(element.invId); });
        this.fillformService.getDataThrowPostMethod(`GSTR1/at/deleteData`, invIds).subscribe(data => {
          if (data["httpStatus"] == 200) {
            success("Invoices Deleted Successfully");
            this.changeData();
          }
        });
      }
    } else {
      alerts("Please Select at least an Invoice to Delete");
    }
  }

  //grid callbacks start
  onRowDbleClickDetail() {
    this.fillformService.modifyInvoice(this.gridDynamicObj, this.activeRoute, 'amv', 'modify')
  }
  //grid callbacks end

  appendOrOverrideBtocSData(type) {
    let data = {
      queryType: type,
      clientId: this.selectedClient.mClientId,
      monthId: this.shareService.getData("month")["monthId"],
      yearId: this.shareService.getData("year")["yearId"]
    };
    this.fillformService.appendOrOverrideBtocSData(data).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.changeData();
        $("#append_modal").modal("hide");
        success(data["message"])
      }
    });
  }

  ngOnDestroy(): void {
    if (this.asPerReturnSub) this.asPerReturnSub.unsubscribe();
    if (this.invoiceSub) this.invoiceSub.unsubscribe();
    if (this.sub) this.sub.unsubscribe();
    this.shareService.removeData("selectedInvoiceEntryMode");
  }

}
