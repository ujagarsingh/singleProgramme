import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AtComponent } from './at.component';
import { AtAddComponent } from './at-add/at-add.component';

const routes: Routes = [
  {
    path : "",
    component : AtComponent
  },
  {
    path : "amv",
    component : AtAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AtRoutingModule { }
