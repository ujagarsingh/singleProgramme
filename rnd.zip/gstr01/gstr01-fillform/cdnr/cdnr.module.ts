import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CdnrRoutingModule } from './cdnr-routing.module';
import { CdnrComponent } from './cdnr.component';
import { CdnrAddComponent } from './cdnr-add/cdnr-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from 'src/gst/models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [CdnrComponent, CdnrAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    SingleModeModule,
    CalendarModule,
    CdnrRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class CdnrModule { }
