declare var SagGridMP;
import { Component, OnInit } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Subscription } from 'rxjs';
import { RetrunService } from 'src/gst/return/retrun.service';
import { ActivatedRoute } from '@angular/router';
declare function success (message)
declare function alerts (message)
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-cdnr',
  templateUrl: './cdnr.component.html',
  styleUrls: ['./cdnr.component.scss']
})
export class CdnrComponent implements OnInit {
  gridData: any;

  location: ComponentLocation;
  importInputData: {};

  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }

  itemDetailLocation: ComponentLocation = {
    moduleId: 'itemDetailModule',
    selector: 'app-item-detail'
  }

  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }

  loadItemDetailModule() {
    this.location = this.itemDetailLocation;
    this.eventEmitter.loadImportForm();
  }

  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }

  commonDropDownDataChange(data) {

  }
  gridDynamicObj: any;


  getClientList() {
    let response = [];
    this.gridData = {
      // columnDef: this.fillformService.getColumns("cdnr"),
      rowDef: response
    };

    let sourceDiv = document.getElementById("gstrone_fillform_cdnr");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);

  }
  selectedClient: any;
  sub : Subscription;
  constructor(private eventEmitter: EventEmitterService, private returnService : RetrunService, 
    private shareService: ShareService, private fillformService: Gstr01FillformService,
    public activeRoute: ActivatedRoute) {
    shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this.getSummaryData();
    });
  }
  selectedInnerTab : any = "tab1";
  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();

    
    this.getSummaryData();
  }

  deleteSelectedInvoice() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    var checkedInvoices = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    var invIds = [];
    let deletedIndex = [];
    if (checkedInvoices.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {
      checkedInvoices.forEach(element => { invIds.push(element.invId); deletedIndex.push(element.sag_G_Index); });
      this.fillformService.getDataThrowPostMethod(`GSTR1/cdnr/deleteData`, invIds).subscribe(data => {
        if (data["httpStatus"] == 200) {
          success("Invoices Deleted Successfully");
          this.getInvoiceDetails();
          if (deletedIndex.length > 0) {
            this.gridDynamicObj.deleteMultipleRow(deletedIndex);
          }
        } else {
          alerts("Invoice Id could not be found!");
        }
      });
    }
    } else {
      alerts("Please Select at least an Invoice to Delete");
    }
  }
  compData: any;
  getInvoiceDetails() {
    this.selectedInnerTab = 'tab2';
    var obj = {
      formType: 'GSTR1',
      yearId: this.shareService.getData("year")["yearId"],
      monthId: this.shareService.getData("month")["monthId"],
      mClientId: this.shareService.getData("selectedClient")["mClientId"],
      gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
      sectionName: 'cdnr'
    };

    // this.summarySub = this.returnService._getAllInvoiceDetails(obj).subscribe(data => {
    //   if (data["httpStatus"] == 200) {
    //     this.gridDynamicObj = this.fillformService.commonDetailGrid(data["data"], "gstrone_fillform_cdnr",this);
    //   }
    // });
    this.compData = {
      sectionCode: 'cdnr',
      formType: 'GSTR1',
      obj: obj
    }
  }
  selectedInvoice : any;
  onRowSelect(){
    this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
  }

  summarySub: Subscription;
  detailSub : Subscription;
  getSummaryData() {
    this.selectedInnerTab = 'tab1';
    var obj = {
      formType: 'GSTR1',
      yearId: this.shareService.getData("year")["yearId"],
      monthId: this.shareService.getData("month")["monthId"],
      mClientId: this.shareService.getData("selectedClient")["mClientId"],
      gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
      sectionName: "cdnr"
    };

    this.detailSub = this.returnService._getAllSummary(obj).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridDynamicObj = this.fillformService.commonSummaryGrid(data["data"], "gstrone_fillform_cdnr",this);
      }
    });
  }

//grid callbacks start
onRowDbleClickSummary(){
  this.getInvoiceDetails();
}

onRowDbleClickDetail(){
  this.fillformService.modifyInvoice(this.gridDynamicObj,this.activeRoute,'amv','modify')
}
//grid callbacks end
  gridOutput: any;
  detailComp($event) {
    this.gridOutput = $event;
    let gridData = this.gridOutput.gridData;
    this.gridDynamicObj = this.fillformService.commonDetailComponentGrid(gridData, "gstrone_fillform_cdnr", this);
  }

  ngOnDestroy() {
    if(this.sub)
    this.sub.unsubscribe();
  
    if(this.summarySub)
      this.summarySub.unsubscribe();
    
    if(this.detailSub)
      this.detailSub.unsubscribe();
  }

}
