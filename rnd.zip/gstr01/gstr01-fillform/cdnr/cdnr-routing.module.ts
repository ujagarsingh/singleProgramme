import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CdnrComponent } from './cdnr.component';
import { CdnrAddComponent } from './cdnr-add/cdnr-add.component';

const routes: Routes = [
  {
    path : "",
    component : CdnrComponent
  },
  {
    path: "amv",
    component: CdnrAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CdnrRoutingModule { }
