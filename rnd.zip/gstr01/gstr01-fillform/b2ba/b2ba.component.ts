import { Component, OnInit } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { Subscription } from 'rxjs';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Router, ActivatedRoute } from '@angular/router';

declare var SagGridMP;
declare function alerts(n);
declare function success(n);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2ba',
  templateUrl: './b2ba.component.html',
  styleUrls: ['./b2ba.component.scss']
})
export class B2baComponent implements OnInit {
  gridDynamicObj: any;

  location: ComponentLocation;
  importInputData: {};

  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }
  itemDetailLocation: ComponentLocation = {
    moduleId: 'itemDetailModule',
    selector: 'app-item-detail'
  }

  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }

  loadItemDetailModule() {
    this.location = this.itemDetailLocation;
    this.eventEmitter.loadImportForm();
  }

  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }


  selectedClient: any;
  sub: Subscription;
  constructor(private eventEmitter: EventEmitterService,
    private returnService: RetrunService,
    public shareService: ShareService, public fillformService: Gstr01FillformService,
    public router: Router, public activeRoute: ActivatedRoute) {
    shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this.getSummaryData();
    });
  }

  getInvoiceDetails() {
    this.selectedInnerTab = 'tab2';
    var obj = {
      formType: 'GSTR1',
      yearId: this.shareService.getData("year")["yearId"],
      monthId: this.shareService.getData("month")["monthId"],
      mClientId: this.shareService.getData("selectedClient")["mClientId"],
      gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
      sectionName: 'b2ba'
    };

    this.summarySub = this.returnService._getAllInvoiceDetails(obj).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridDynamicObj = this.fillformService.commonDetailGrid(data["data"], "gstrone_b2ba_fillform", this);
      }
    });
  }

  selectedInvoice: any;
  onRowSelect() {
    this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
  }

  selectedInnerTab: any = "tab1";
  summarySub: Subscription;
  detailSub: Subscription;
  getSummaryData() {
    this.selectedInnerTab = 'tab1';
    var obj = {
      formType: 'GSTR1',
      yearId: this.shareService.getData("year")["yearId"],
      monthId: this.shareService.getData("month")["monthId"],
      mClientId: this.shareService.getData("selectedClient")["mClientId"],
      gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
      sectionName: "b2ba"
    };

    this.detailSub = this.returnService._getAllSummary(obj).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridDynamicObj = this.fillformService.commonSummaryGrid(data["data"], "gstrone_b2ba_fillform", this);
      }
    });
  }

  //grid callbacks start
  onRowDbleClickSummary() {
    this.getInvoiceDetails();
  }

  onRowDbleClickDetail() {
    this.fillformService.modifyInvoice(this.gridDynamicObj, this.activeRoute, 'amv', 'modify')
  }
  //grid callbacks end

  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.getSummaryData();
  }

  deleteSelectedInvoice() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    let checkedInvoices = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    let invIds = [];
    if (checkedInvoices.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {
        checkedInvoices.forEach(element => { invIds.push(element.invId); });
        this.fillformService.getDataThrowPostMethod(`GSTR1/b2ba/deleteData`, invIds).subscribe(data => {
          if (data["httpStatus"] == 200) {
            success("Invoices Deleted Successfully");
            this.getInvoiceDetails();
          }
        });
      }
    } else {
      alerts("Please Select at least an Invoice to Delete");
    }
  }

  ngOnDestroy() {
    if (this.sub)
      this.sub.unsubscribe();

    if (this.summarySub)
      this.summarySub.unsubscribe();
  }



}
