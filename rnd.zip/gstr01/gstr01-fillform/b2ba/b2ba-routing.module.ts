import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2baComponent } from './b2ba.component';
import { B2baAddComponent } from './b2ba-add/b2ba-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2baComponent
  },
  {
    path: 'amv',
    component: B2baAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2baRoutingModule { }
