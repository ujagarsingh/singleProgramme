import { Component, OnInit } from '@angular/core';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Subscription } from 'rxjs';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
declare var SagGridMP;
declare function alerts(message);
declare function success(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2ba-add',
  templateUrl: './b2ba-add.component.html',
  styleUrls: ['./b2ba-add.component.scss']
})
export class B2baAddComponent implements OnInit {
  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'searchInvoiceModule',
    selector: 'app-search-invoice'
  };
  selectedDiff: any = null;
  commonFormGroup: any;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [
    { "key": "", "val": "-Select-" },
  ];
  itemArr = [
    { "key": "", "val": "-Select-" },
  ];
  formType = "GSTR1";
  commonDropRes: any = {};

  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };

  
  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, HsnDesc: null,hsnitemId : null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];

  selectedClient: any;
  revChangeList: any;

  gridData: any;
  gridSelectedRowData: any = {};

  constructor(private configurationService: ConfigurationsService, private eventEmitterService: EventEmitterService, public shareService: ShareService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.revChangeList = [{ label: "Yes", value: 'Y' }, { label: "No", value: 'N' }];
    this.manageDateObject();
  }



  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;

  manageDateObject() {
    var obj = this.returnService.manageDateObjects(true);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }

  popupData: any;

  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    if (!this.selectedInvoice)
      this.openSearchPopup();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.getCommonDropdownListOnLoad(this.formType);
    this.manageObservables();

  }

  openSearchPopup() {
    this.location = this.importlocation;
    this.popupData = {
      'popupData': {
        'formName': "GSTR1",
        'sectionCode': "b2b",
        'showYear': true,
        'showMonth': true,
        'showSeller': true,
        'showGstNo': true,
        'showInvoice': true,
        'sellerType': "Receiver",
        'showInvNo': true,
      }
    };
    this.eventEmitterService.loadSearchInvoicePopup();
  }

  flag = false;
  onKeywordsChange = (data) => {
    this.flag = true;
    if (data && data.invId)
      this.manageSelectedInvoice(data, this.commonFormGroup);
    // this.selectedDiff = data.apptaxrt ? Number(data.apptaxrt) : null;
    // this.commonFormGroup.patchValue({
    //   spId: this.returnService.getSelectedObject(this.sellerList,data.SpId, "spId")['spId'],
    //   invRefinvid: data.Id,
    //   invNo: data.OrignalInvoiceNo,
    //   invOriginvno: data.OrignalInvoiceNo,
    //   invOriginvdt: data.OrignalInvoiceDate,
    //   invDt: data.OrignalInvoiceDate,
    //   invVal: data.InvoiceValue,
    //   invTxval: data.TaxableValue,
    //   invtypeId: data.invtypeCode
    // });
    this.commonFormGroup.get('invOriginvno').disable();
    this.commonFormGroup.get('invOriginvdt').disable();
    // this.getInvoiceItemList();
  }
  callFillDataAccordingSupplyTypeMethod: boolean = true;
  // getInvoiceItemList() {
  //   this.returnService.getInvoiceItemList(this.commonFormGroup.get("invRefinvid").value).subscribe(data => {
  //     if (data["httpStatus"] == 200) {
  //       console.log(data["data"]);
  //       for (var i = 0; i < data["data"].length; i++) {
  //         let obj = data["data"][i];
  //         obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
  //       }
  //       this.addGrid(data["data"]);
  //     } else
  //       this.addGrid([]);
  //     this.callFillDataAccordingSupplyTypeMethod = false;
  //     this.sellerChange();
  //     this.invoiceTypeChange();
  //     this.callFillDataAccordingSupplyTypeMethod = true;
  //   });
  // }



  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
     

    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });

    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });
  }


  configuredData: any;
  getCommonDropdownListOnLoad(formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfB2bAmend");
      var requstobj = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category"], "docTypeParams": "R" };
      this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
        if (res["httpStatus"] == 200) {
          this.commonDropRes = res["data"];
          this.setGridDropdownOnLoad();
        }
        this.getSellerList();
      });
    });

  }
  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          this.getHSNSummary();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo != null)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
        }
      });
  }

  hsnCodeList: any;
  hsnDesList : any;
  completeHsnList : any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.getInvTypeAndRevChrgsList();
      })
  }

  selectedInvoice: any;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (this.flag) {
          data["data"]["invRefinvid"] = data["data"]["invId"];
          data["data"]["invId"] = null;
          this.flag = false;
        }
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitem_apptaxrt"];
        delete data["data"]["txnInvitemData"];
        data["data"]["montho"]["monthId"] = data["data"]["month"]["monthId"];
        data["data"]["yearo"]["yearId"] = data["data"]["year"]["yearId"];
        data["data"]["stateO"]["stateId"] = data["data"]["state"]["stateId"];
        data["data"]["invOriginvno"] = data["data"]["invNo"];
        data["data"]["invOriginvdt"] = data["data"]["invDt"];
        formGroup.setValue(data["data"]);
        formGroup.patchValue({
          section : {sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2ba')["secId"]},
          year : { yearId: this.shareService.getData("year")["yearId"] } ,
          month : {monthId: this.shareService.getData("month")["monthId"]}
        })
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        this.callFillDataAccordingSupplyTypeMethod = false;
        this.sellerChange('pos');
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }


  differentialChange() {
    this.onFormGroupChangeFireGridEvent();
  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts("invoice No already exist In this financial Year");
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }

  revChangePerList: any;
  invoiceTypeList: any = [];
  getInvTypeAndRevChrgsList() {
    this.fillformService.getInvTypeAndRevChrgsList().subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (data["data"] && data["data"]["invTypes"]) {
          let secId = this.fillformService.getSelectedValue(this.commonDropRes.sec, "secCode", 'b2b')["secId"];
          for (const obj of data["data"]["invTypes"]) {
            if (obj["sectionId"] == secId)
              this.invoiceTypeList.push(obj);
          }
        }
        if (data["data"] && data["data"]["revCharges"])
          this.revChangePerList = data["data"]["revCharges"];
      }
      if (this.selectedInvoice) {
        this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
        this.shareService.removeData("selectedInvoice");
        if (this.selectedInvoice.amvType == "view") {
          this.commonFormGroup.disable();
          this.gridDynamicObj.disableAllRow();
        }
      } else {
        this.addGrid(this.gridRowData);
        this.gridDynamicObj.disableAllRow();
      }
    });
  }

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue({
      section: {sectionId : this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2ba')["secId"]},
    });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
    // this.addGrid(this.gridRowData);
    // this.gridDynamicObj.disableAllRow();
  }

  addGrid(data) {
    var gridData = {
      columnDef: this.fillformService.getColumns("b2b", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("gstrone_b2ba_Add"), gridData, true, true);
  }

  enabledisableAllRowCell(index, gridObj) {
    let obj = gridObj.getRowData(index);
    obj["invitemTaxamt"] != null && !isNaN(obj["invitemTaxamt"]) && parseFloat(obj["invitemTaxamt"]) != 0 ? gridObj.enableCell(index, "rate") : gridObj.disableCell(index, "rate");
  }

  onFormGroupChangeFireGridEvent() {
    let arr = this.gridDynamicObj.getGridData();
    if (arr.length > 0) {
      for (let index = 0; index < arr.length; index++) {
        const obj = arr[index];
        this.fillformService.commonMethods(this, index, obj);
      }
    }
  }


  supplyTypeCode: any;
  sellerChange(type) {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("sp").value["spId"], "spId");
    let fullState = this.commonFormGroup.get("state").value["stateId"] ? this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateId', this.commonFormGroup.get("state").value["stateId"]) :
      this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', data.gstnNo.substr(0, 2));
    for (const obj of this.commonDropRes.supplyType) {
      if (obj.supplyCode == "INTRA" && this.selectedClient.gstNo.substr(0, 2) === fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: {splytypeId : obj.supplyId} })
      } else if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: {splytypeId : obj.supplyId} })
      }
    }
    if (data){
      if(type == "seller"){
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: (data.stateId != null && data.stateId != 0) ? data.stateId : fullState.stateId } });
      }else{
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: fullState.stateId  } });
      }
    }
    this.onFormGroupChangeFireGridEvent();
    this.invoiceTypeChange();
  }

  selectedInvoiceType: any;
  invoiceTypeChange() {
    var data = this.returnService.getSelectedObject(this.invoiceTypeList, this.commonFormGroup.get("invtype").value["invtypeId"], "invtypeCode");
    if (!data)
      data = this.returnService.getSelectedObject(this.invoiceTypeList, this.commonFormGroup.get("invtype").value["invtypeId"], "invtypeId");
    this.selectedInvoiceType = data;
    this.commonFormGroup.patchValue({ invtype : {invtypeId: data.invtypeId }});
    this.fillformService.invoiceTypeChange(this.commonFormGroup, this.selectedInvoiceType, this.gridDynamicObj, this.supplyTypeCode, this.selectedInvoice, this.selectedDiff, this.callFillDataAccordingSupplyTypeMethod);
  }


  saveB2Ba() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    if (!this.commonFormGroup.get("sp").value["spId"]) {
      alert("Receiver not Selected");
    }
    var items = this.singleMode ? [this.amtFormGroupData] : this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      var obj = this.commonFormGroup.getRawValue();
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      this.fillformService.saveInvoice(obj, 'b2ba').subscribe(data => {
        if (data["httpStatus"] == 200) {
          success(data["message"]);
          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null, invId: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }
  }

  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  singleMode: boolean = false;
  singleModeO() {
    let obj = Object.assign({}, this.commonDropRes)
    obj.invType = this.invoiceTypeList
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }

  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  ngOnDestroy() {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    this.commonObserver.unsubscribe();
    this.rchargeObserver.unsubscribe();
  }
}
