import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HsnRoutingModule } from './hsn-routing.module';
import { HsnComponent } from './hsn.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { HsnAddComponent } from './hsn-add/hsn-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [HsnComponent, HsnAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,
    HsnRoutingModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    AutoCompleteModule
  ]
})
export class HsnModule { }
