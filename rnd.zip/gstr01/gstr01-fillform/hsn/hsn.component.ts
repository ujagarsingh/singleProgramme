import { Component, OnInit } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { FormBuilder } from '@angular/forms';
import * as _ from "lodash";
import { Router, ActivatedRoute } from '@angular/router';
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';

declare function success(m);
declare function alerts(m);

declare var SagGridMP;
declare var SagInputText;
declare var SagSelectBox;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  templateUrl: './hsn.component.html',
  styleUrls: ['./hsn.component.scss']
})
export class HsnComponent implements OnInit {
  dropdownCofigJson = {
    selectedData: {
      formName: 'anx1',
    },
    showHideDropdown: {
      month: true,
      showGetClientBtn: false,
      year: true,
      period: false,
      returnType: false,
      clientList: true,
      gstnList: true
    },
    enableDisableDropdown: {
      month: false,
      year: false,
      period: true,
      returnType: true,
    },
  };
  selectedClient: any;
  sub: any;
  gridData: any;
  gridDynamicObj: any;
  colData: any = [
    {
      header: "checkbox",
      field: "checkbox",
      "editable": false,
      width: "40px",
      "text-align": "center",
      "colType": "checkBox"

    },
    {
      header: "S.No.",
      field: "sno",
      width: "50px",
      "text-align": "center",
      search: true,
      "editable": false
    },
    {
      header: "Category",
      field: "catId",
      filter: true,
      width: "120px",
      "editable": false,
      "text-align": "center",
      search: true,
      component: "category"
    },

    {
      header: "HSN/SAC Code",
      field: "hsnsmryClientHsnCode",
      filter: true,
      width: "150px",
      "editable": false,
      "text-align": "center",
      search: true

    },
    {
      header: "Description",
      field: "hsnsmryClientHsnDesc",
      filter: true,
      width: "130px",
      "text-align": "center",
      "editable": false,
      search: true

    },
    {
      header: "UQC",
      field: "msrmntId",
      filter: true,
      width: "130px",
      "text-align": "center",
      "editable": false,
      search: true,
      component: "UQC"
    },
    {
      header: "Quantity",
      field: "hsnsmryQty",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      columnType: "numeric"

    },
    {
      header: "Taxable Value",
      field: "hsnsmryTaxval",
      filter: true,
      width: "130px",
      "text-align": "right",
      search: true,
      "editable": false,
      "total": true,
      columnType: "numeric"
    },
    {
      header: "IGST",
      field: "hsnsmryIamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      columnType: "numeric"
    },
    {
      header: "CGST",
      field: "hsnsmryCamt",
      filter: true,
      "editable": false,
      width: "130px",
      "text-align": "right",
      search: true,
      "total": true,
      columnType: "numeric"

    },
    {
      header: "SGST",
      field: "hsnsmrySamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      columnType: "numeric"
    },
    {
      header: "CESS",
      field: "hsnsmryCsamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      columnType: "numeric"
    },
    {
      header: "Total Tax",
      field: "hsnsmryTotltax",
      filter: true,
      width: "130px",
      "text-align": "right",
      search: true,
      "editable": false,
      "total": true,
      columnType: "numeric"
    },
    {
      header: "Total",
      field: "hsnsmryTotlval",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      columnType: "numeric"
    }

  ];
  responseData: any;
  natureType: any;
  detailDataList: any;
  hsnSmryId: any;
  isEnabled: boolean;
  rowObj: any;
  uqcList = [{
    key: null,
    val: "--Select--"
  }];


  constructor(
    private eventEmitter: EventEmitterService,
    private commonService: Gstr01FillformService,
    private shareService: ShareService,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private gridExportService: GridExportService,
  ) {
    this.shareService.newEvent();
    this.isEnabled = true;
  }

  commonDropDownDataChange(data) {
  }

  location: ComponentLocation;
  importInputData: {};
  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }

  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }

  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }

  ////////////////////////////////////////// HSN WORK STARTS ///////////////////////////////////////

  ngOnInit() {
    this.getUQC();
    setTimeout(()=> {this._getAllDataList()}, 100);
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this._getAllDataList()
    });

  }

  getUQC() {
    this.commonService.getDataThrowGetMethod(`getUQC?type=measurement&status=`).subscribe(
      (response: any) => {
        for (let obj of response) {
          let uqcObject = { key: obj['label'], val: obj['value'] }
          this.uqcList.push(uqcObject);
        }
      })
  }

  _getAllDataList() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");
    this.commonService.getDataThrowGetMethod(`getCommonInvoiceData?mclientId=${selectedClient.mClientId}&yearId=${selectedYear.yearId}&monthId=${selectedMonth.monthId}&gstnCid=${selectedClient.gstnCid}&sectionCode=hsn`).subscribe(
      response => {
        if (response['data']) {
          this.responseData = response['data']['hsn'];
          this.detailDataList = response['data']['hsn'];
        } else {
          this.detailDataList = [];
          alerts('No data found.');
        }
        this.getClientList(this.detailDataList);
      }
    );
  }

  deleteMultiRow() {
    let checkedArray = [];
    let checkedData = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    if (checkedData.length > 0) {
      for (let obj of checkedData) {
        let id = obj.hsnsmryId
        checkedArray.push(id);
      }
    }
    if (checkedArray.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {

        this.commonService.getDataThrowPostMethod(`GSTR1/hsn/deleteData`, checkedArray).subscribe(
          response => {
            if (response['data'] == true && response['httpStatus'] == 200) {
              this._getAllDataList();
              success(response['message']);
            }
          })
      }
    } else {
      alerts("Please select at least one checkbox!!")
    }

  }

  getClientList(data) {
    let self = this;

    let Catarr = [
      { "key": null, "val": "--Select--" },
      { "key": 1, "val": "G" },
      { "key": 2, "val": "S" }
    ];

    let category = new SagSelectBox(Catarr, function (ele, prm) {
      ele.onchange = function () {
      }
    })
    let UQC = new SagSelectBox(this.uqcList, function (ele, prm) {
      ele.onchange = function () {
      }
    })

    let component = {
      "category": category,
      "UQC": UQC,
    }
    let response = data;
    this.gridData = {
      columnDef: this.colData,
      rowDef: response,
      components: component,
      gridExportService: this.gridExportService,
      callBack: {
        "onRowClick": function () {
          self.onRowSelectFn();
        },
        "onRowDbleClick": function () {
          self.dblClickModify();
        }
      }

    };

    let sourceDiv = document.getElementById("gstrone_fillform_hsn");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);
    console.log(this.gridDynamicObj.getGridData());
    this.gridDynamicObj.disableColumn("catId")
    this.gridDynamicObj.disableColumn("msrmntId")
  }

  onRowSelectFn() {
    this.rowObj = this.gridDynamicObj.getSeletedRowData();
    this.hsnSmryId = this.rowObj.hsnsmryId;
    this.isEnabled = false;
  }

  dblClickModify() {
    var obj = this.gridDynamicObj.getSeletedRowData();
    this.modifyData(obj.hsnSmryId, obj);

  }

  addViewModifyButtonClick(modeFlag) {
    let selectedClient = this.shareService.getData("selectedClient");
    //[disabled]="!selectedClient || returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed'" [routerLink]="['../amv']"
    if ((selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') && (modeFlag == 'add' || modeFlag == 'modify')) {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    } else {
      if (modeFlag == 'add')
        this.router.navigate(['amv'], { relativeTo: this.route });

      else if (modeFlag == 'modify')
        this.modifyData(this.hsnSmryId, this.rowObj);

      else if (modeFlag == 'view')
        this.showData(this.hsnSmryId, this.rowObj);
    }

  }

  modifyData(id, obj) {
    // let Nid = "hsn-sacupdate";
    let Nid = "amv";
    this.shareService.setData("id", id);
    this.shareService.setData("obj", obj);
    this.shareService.setData("kind", "update");
    this.router.navigate([Nid], { relativeTo: this.route });
    this.rowObj = {};
  }

  showData(id: any, obj) {
    // let Nid = "hsn-sacview";
    let Nid = "amv";
    this.shareService.setData("id", id);
    this.shareService.setData("obj", obj);
    this.shareService.setData("kind", "view");
    this.router.navigate([Nid], { relativeTo: this.route });
    this.rowObj = {};
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
