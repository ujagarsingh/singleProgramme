import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from 'genmaster/src/master/services/validation.service';
import * as _ from "lodash";
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';

declare function success(m);
declare function alerts(m);

declare var SagGridMP;
declare var SagInputText;
declare var SagSelectBox;
declare var SagAutoCompleteBox;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-hsn-add',
  templateUrl: './hsn-add.component.html',
  styleUrls: ['./hsn-add.component.scss']
})
export class HsnAddComponent implements OnInit {
  gridData: any;
  gridDynamicObj: any;
  gridSelectedRowData: any = {};
  colData: any = [
    // {
    //   header: "checkbox",
    //   field: "checkbox",
    //   "editable": false,
    //   width: "40px",
    //   "text-align": "center",
    //   "ng-dblclick": "dblClickModify()",
    //   "ng-click": "selectGridRow()",
    //   "colType": "checkBox"

    // },
    {
      header: "S.No.",
      field: "sno",
      width: "50px",
      "text-align": "center",
      search: true,
      "editable": false
    },
    {
      header: "Category",
      field: "catId",
      filter: true,
      width: "120px",
      "editable": false,
      "text-align": "center",
      search: true,
      component: "category",
      headerClass:"required"
    },

    {
      header: "HSN/SAC Code",
      field: "hsnsmryClientHsnCode",
      filter: true,
      width: "150px",
      "editable": false,
      "text-align": "center",
      search: true,
      component: "HSN",
      headerClass: "required"

    },
    {
      header: "Description",
      field: "hsnsmryClientHsnDesc",
      filter: true,
      width: "130px",
      "text-align": "center",
      "editable": false,
      search: true,
      component: "desc"

    },
    {
      header: "hsnID",
      field: "hsnitemId",
      filter: true,
      width: "130px",
      "text-align": "center",
      "editable": false,
      search: true,
      hidden: true

    },
    {
      header: "UQC",
      field: "msrmntId",
      filter: true,
      width: "130px",
      "text-align": "center",
      "editable": false,
      search: true,
      component: "UQC",
      headerClass:"required"

    },
    {
      header: "Quantity",
      field: "hsnsmryQty",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      component: "quantity",
      headerClass:"required"
    },
    {
      header: "Taxable Value",
      field: "hsnsmryTaxval",
      filter: true,
      width: "130px",
      "text-align": "right",
      search: true,
      "editable": false,
      "total": true,
      "total-text": "",
      component: "taxVal",
      headerClass:"required"
    },
    {
      header: "IGST",
      field: "hsnsmryIamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      "total-text": "",
      component: "igst"

    },
    {
      header: "CGST",
      field: "hsnsmryCamt",
      filter: true,
      "editable": false,
      width: "130px",
      "text-align": "right",
      search: true,
      "total": true,
      "total-text": "",
      component: "cgst"

    },
    {
      header: "SGST",
      field: "hsnsmrySamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      "total-text": "",
      component: "sgst"

    },
    {
      header: "CESS",
      field: "hsnsmryCsamt",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      "total-text": "",
      component: "cess"

    },
    {
      header: "Total Tax",
      field: "hsnsmryTotltax",
      filter: true,
      width: "130px",
      "text-align": "right",
      search: true,
      "editable": false,
      "total": true,
      "total-text": "",

    },
    {
      header: "Total",
      field: "hsnsmryTotlval",
      filter: true,
      width: "130px",
      "text-align": "right",
      "editable": false,
      search: true,
      "total": true,
      "total-text": "",

    }

  ];
  NewRowObj = {
    "hsnsmryId": "",
    "hsnsmrySrno": "",
    "mclientId": "",
    "gstnCid": "",
    "formtypeId": "",
    "monthId": "",
    "yearId": "",
    "catId": null,
    "hsnitemId": "",
    "msrmntId": null,
    "hsnsmryQty": "",
    "hsnsmryTaxval": "",
    "hsnsmryIamt": "",
    "hsnsmrySamt": "",
    "hsnsmryCamt": "",
    "hsnsmryCsamt": "",
    "hsnsmryTotltax": "",
    "hsnsmryTotlval": "",
    "hsnsmryUploadyn": "",
    "hsnsmryUploaddt": "",
    "hsnsmryApprovalyn": "",
    "hsnsmryApprovaldt": "",
    "hsnsmryClientHsnCode": "",
    "hsnsmryClientHsnDesc": "",
    "sagclientId": 1,
    "flag": 0,
    "createdOn": "",
    "lastUpdatedOn": "",
    "hsnsmryTmphsnsmryid": "",
    "hsnsmrySessionid": ""
  }
  updateEnabled: boolean;
  viewEnabled: boolean;
  addEnabled: boolean;
  entryMode: boolean = false;
  uqcList = []
  hsnCodeAndItem: any
  selectedClient: any;
  sub: any;
  clientStateName: any;
  deleteRowIndex: any;
  selectedHsnOrSacList: any[];
  selectedDescriptionList: any[];
  selectedhsnCodeList: any[];
  selectedHsnOrSacListGrid: any[];
  selectedhsnCode: any = [];
  selectedDescription: any = [];
  selectedhsnCodeGrid: any = [];
  selectedDescriptionGrid: any = [];

  constructor(
    private commonService: Gstr01FillformService,
    private shareService: ShareService,
    private fb: FormBuilder,
    private router: Router,
    private location: Location,
    private route: ActivatedRoute,
    private gridExportService: GridExportService,
  ) {

    this.updateEnabled = false;
    this.viewEnabled = false;
    this.addEnabled = false;
  }

  entryForm: FormGroup = this.fb.group({
    hsnsmryId: [''],
    hsnsmrySrno: [''],
    mclientId: [''],
    gstnCid: [''],
    formtypeId: [''],
    monthId: [''],
    yearId: [''],
    catId: [null, Validators.required],
    hsnitemId: [''],
    msrmntId: [null, Validators.required],
    hsnsmryQty: ['', {
      validators: [ValidationService.onlydigitsValidator]
    }],
    hsnsmryTaxval: ['', {
      validators: [Validators.required, ValidationService.decimalNumberValidator]
    }],
    hsnsmryIamt: ['', {
      validators: [ValidationService.decimalNumberValidator]
    }],
    hsnsmrySamt: ['', {
      validators: [ValidationService.decimalNumberValidator]
    }],
    hsnsmryCamt: ['', {
      validators: [ValidationService.decimalNumberValidator]
    }],
    hsnsmryCsamt: ['', {
      validators: [ValidationService.decimalNumberValidator]
    }],
    hsnsmryTotltax: [{ value: '', disabled: true }],
    hsnsmryTotlval: [{ value: '', disabled: true }],
    hsnsmryUploadyn: [''],
    hsnsmryUploaddt: [''],
    hsnsmryApprovalyn: [''],
    hsnsmryApprovaldt: [''],
    hsnsmryClientHsnCode: ['', {
      validators: [Validators.required, ValidationService.hsnValidator]
    }],
    hsnsmryClientHsnDesc: ['', {
      validators: [ValidationService.alphaValidator]
    }],
    sagclientId: [1],
    flag: [0],
    createdOn: [''],
    lastUpdatedOn: [''],
    hsnsmryTmphsnsmryid: [''],
    hsnsmrySessionid: ['']
  })

  get f() { return this.entryForm.controls; }

  saveFormToGrid() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");
    this.entryForm.get("gstnCid").patchValue(selectedClient.gstnCid)
    this.entryForm.get("mclientId").patchValue(selectedClient.mClientId)
    this.entryForm.get("monthId").patchValue(selectedMonth.monthId)
    this.entryForm.get("yearId").patchValue(selectedYear.yearId)
    let rowArray = this.gridDynamicObj.getGridData();
    for (let obj of rowArray) {
      if (
        obj.catId == "" ||
        obj.catId == null &&
        obj.msrmntId == "" ||
        obj.msrmntId == null &&
        obj.hsnsmryQty == "" ||
        obj.hsnsmryQty == null &&
        obj.hsnsmryTaxval == "" ||
        obj.hsnsmryTaxval == null &&
        obj.hsnsmryIamt == "" ||
        obj.hsnsmryIamt == null &&
        obj.hsnsmrySamt == "" ||
        obj.hsnsmrySamt == null &&
        obj.hsnsmryCamt == "" ||
        obj.hsnsmryCamt == null &&
        obj.hsnsmryCsamt == "" ||
        obj.hsnsmryCsamt == null &&
        obj.hsnsmryTotltax == "" ||
        obj.hsnsmryTotltax == null &&
        obj.hsnsmryTotlval == "" ||
        obj.hsnsmryTotlval == null &&
        obj.hsnsmryClientHsnCode == "" ||
        obj.hsnsmryClientHsnCode == null &&
        obj.hsnsmryClientHsnDesc == "" ||
        obj.hsnsmryClientHsnDesc == null
      ) {
        rowArray = this.gridDynamicObj.deleteRow(obj.sag_G_Index);
        if (rowArray == undefined || rowArray == null) {
          rowArray = [];
        }
      }
    }
    rowArray.push(this.entryForm.getRawValue())

    this.getClientList(rowArray);
    this.entryForm.reset({
      "sagclientId": 1,
      "flag": 0,
    })
  }

  addEnabledGrid() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");
    let object = { ...this.NewRowObj };
    object.gstnCid = selectedClient.gstnCid
    object.mclientId = selectedClient.mClientId
    object.monthId = selectedMonth.monthId
    object.yearId = selectedYear.yearId
    object.sagclientId = 1
    object.flag = 0
    let rowArray = []
    rowArray.push(object)
    this.getClientList(rowArray);
  }

  switchRouting() {
    let self = this
    let kind = this.shareService.getData("kind")
    this.route.data.subscribe(data => {
      switch (kind) {
        case 'update': {
          self.getUpdateData();
          self.updateEnabled = true;
          this.shareService.removeData("kind");
          break;
        }
        case 'view': {
          self.getViewData();
          self.viewEnabled = true;
          this.shareService.removeData("kind");
          break;
        }
        default: {
          console.log("no routing selected");
          self.addEnabled = true;
          this.addEnabledGrid();
        }
      }
    })
  }

  getViewData() {
    let rowArray = []
    rowArray.push(this.shareService.getData("obj"));
    this.getClientList(rowArray);
    this.gridDynamicObj.disableAllRow();
  }

  getUpdateData() {
    let rowArray = []
    rowArray.push(this.shareService.getData("obj"));
    this.getClientList(rowArray);
  }

  getUQC() {
    this.uqcList = [{
      key: null,
      val: "--Select--"
    }];
    this.commonService.getDataThrowGetMethod(`getUQC?type=measurement&status=`).subscribe(
      (response: any) => {

        for (let obj of response) {
          let uqcObject = { key: obj['label'], val: obj['value'] }
          this.uqcList.push(uqcObject);
        }
        this.getHSNSummary();
        this.switchRouting();
      })
  }

  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.commonService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.hsnCodeAndItem = response;
      })
  }

  getSelectedHsnSac() {
    let id = this.entryForm.get("catId").value
    this.selectedHsnOrSacList = [];
    this.selectedDescription = [];
    this.selectedhsnCode = [];
    for (let obj of this.hsnCodeAndItem) {
      if (obj.catId == id) {
        this.selectedHsnOrSacList.push(obj)
        this.selectedDescription.push(obj.description)
        this.selectedhsnCode.push(obj.hsnCode)
      }
    }
  }

  getSelectedHsnSacGrid(id) {
    this.selectedHsnOrSacListGrid = [];
    this.selectedDescriptionGrid = [];
    this.selectedhsnCodeGrid = [];
    for (let obj of this.hsnCodeAndItem) {
      if (obj.catId == id) {
        this.selectedHsnOrSacListGrid.push(obj)
        this.selectedDescriptionGrid.push(obj.description)
        this.selectedhsnCodeGrid.push(obj.hsnCode)
      }
    }
  }

  getSelectedHsnSacList() {
    let hsncode = this.entryForm.get("hsnsmryClientHsnCode").value;
    let hsnDesc = this.entryForm.get("hsnsmryClientHsnDesc").value;
    // this.selectedhsnCodeList = this.selectedhsnCode.filter(s => s.includes(hsncode));
    // this.selectedDescriptionList = this.selectedDescription.filter(s => s.includes(hsnDesc));
    for (let obj of this.hsnCodeAndItem) {
      if (obj.hsnCode == hsncode) {
        this.entryForm.get("hsnsmryClientHsnDesc").patchValue(obj.description)
        this.entryForm.get("hsnitemId").patchValue(obj.hsnItemId)
        break;
      }
      if (obj.description == hsnDesc) {
        this.entryForm.get("hsnsmryClientHsnCode").patchValue(obj.hsnCode)
        this.entryForm.get("hsnitemId").patchValue(obj.hsnItemId)
        break;
      }
    }

  }

  addGridRow() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");
    let newObject = { ...this.NewRowObj };
    newObject.gstnCid = selectedClient.gstnCid
    newObject.mclientId = selectedClient.mClientId
    newObject.monthId = selectedMonth.monthId
    newObject.yearId = selectedYear.yearId
    newObject.sagclientId = 1
    newObject.flag = 0
    let rowArray = this.gridDynamicObj.getGridData();
    rowArray.push(newObject)
    this.getClientList(rowArray);
  }

  deleteGridRow() {
    if (this.deleteRowIndex < 0) {
      alerts("Please select the row you want to delete!!")
    }
    this.gridDynamicObj.deleteRow(this.deleteRowIndex);
    this.deleteRowIndex = -1;
  }

  totalCalcOfTaxTtl() {
    let taxValue = this.entryForm.get("hsnsmryTaxval").value
    let IGST = this.entryForm.get("hsnsmryIamt").value
    let CGST = this.entryForm.get("hsnsmryCamt").value
    let SGST = this.entryForm.get("hsnsmrySamt").value
    let cess = this.entryForm.get("hsnsmryCsamt").value
    let totalTax = Number(IGST) + Number(CGST) + Number(SGST) + Number(cess)
    let total = Number(taxValue) + Number(IGST) + Number(CGST) + Number(SGST) + Number(cess)

    if (!isNaN(totalTax)) {
      this.entryForm.get("hsnsmryTotltax").patchValue(totalTax)
    }
    if (!isNaN(total)) {
      this.entryForm.get("hsnsmryTotlval").patchValue(total)
    }
  }

  saveHsnListData() {
    let rowArray = this.gridDynamicObj.getGridData();

    let valFlag = true;
    for (let obj of rowArray) {
      if (obj.catId == "" || obj.msrmntId == "" || obj.hsnsmryTotlval == "" || obj.hsnsmryQty == "" || obj.hsnsmryTaxval == ""
        || obj.catId == null || obj.msrmntId == null || obj.hsnsmryTotlval == null || obj.hsnsmryQty == null
        || obj.hsnsmryTaxval == null || obj.hsnsmryClientHsnCode == null ||
        obj.hsnsmryClientHsnCode == "") {
        valFlag = false;
        alerts("Please fill the Required Details first !!");
        return
      }
      let hsnCode = obj.hsnsmryClientHsnCode.length
      let hsnitem = obj.hsnsmryClientHsnDesc.length
      if (hsnCode == 4 || hsnCode == 6 || hsnCode == 8) {
        valFlag = true;
      } else {
        valFlag = false;
        alerts("HSN/SAC code must be 4, 6, 8 Digits only!!");
        return
      }

      if (hsnitem < 31) {
        valFlag = true;
      } else {
        valFlag = false;
        alerts("Item length should not be more than 30!!");
        return
      }
    }

    let saveDataList = rowArray;

    let newItems = [];
    for (let obj of saveDataList) {
      let newObj = {
        "hsnsmryId": obj.hsnsmryId ? obj.hsnsmryId: null,
        "hsnsmrySrno": obj.hsnsmrySrno,
        mclientId: obj.mclientId,
        gstnC: { gstnId: parseInt(obj.gstnCid) },
        formType: { formtypeId: obj.formtypeId ? obj.formtypeId : 1 },
        month: { monthId: obj.monthId },
        year: { yearId: obj.yearId },
        mstCat: {"catId": parseInt(obj.catId)},
        mstHsnItem: { "hsnitemId": obj.hsnitemId ? parseInt(obj.hsnitemId): null},
        mstMsrmnt:{ "msrmntId": parseInt(obj.msrmntId)},
        "hsnsmryQty": parseFloat(obj.hsnsmryQty),
        "hsnsmryTaxval": parseFloat(obj.hsnsmryTaxval),
        "hsnsmryIamt": parseFloat(obj.hsnsmryIamt),
        "hsnsmrySamt": parseFloat(obj.hsnsmrySamt),
        "hsnsmryCamt": parseFloat(obj.hsnsmryCamt),
        "hsnsmryCsamt": parseFloat(obj.hsnsmryCsamt),
        "hsnsmryTotltax": parseFloat(obj.hsnsmryTotltax),
        "hsnsmryTotlval": parseFloat(obj.hsnsmryTotlval),
        "hsnsmryUploadyn": obj.hsnsmryUploadyn,
        "hsnsmryUploaddt": obj.hsnsmryUploaddt,
        "hsnsmryApprovalyn": obj.hsnsmryApprovalyn,
        "hsnsmryApprovaldt": obj.hsnsmryApprovaldt,
        "hsnsmryClientHsnCode": obj.hsnsmryClientHsnCode,
        "hsnsmryClientHsnDesc": obj.hsnsmryClientHsnDesc,
        "sagclientId": 1,
        "flag": 0,
        "createdOn": obj.createdOn,
        "lastUpdatedOn": obj.lastUpdatedOn,
        "hsnsmryTmphsnsmryid": parseInt(obj.hsnsmryTmphsnsmryid),
        "hsnsmrySessionid": obj.hsnsmrySessionid
      }
      newItems.push(newObj);
    }

    if (valFlag == true) {
      this.commonService.getDataThrowPostMethod("saveHSN/GSTR1/HSN", newItems).subscribe(
        response => {
          if (response['data'] == true && response['httpStatus'] == 200) {
            this.goBack();
            success(response['message']);
          } else {
            alerts(response['message'])
          }

        }, error => {
          console.log(error);
          console.error('Error while saving HSN Details');
        });
    } else {
      alerts("Please Fill the Details Correctly!!");
    }

  }

  updateHsnListData() {
    let rowArray = this.gridDynamicObj.getGridData();

    let valFlag = true;
    for (let obj of rowArray) {
      if (obj.catId == "" || obj.msrmntId == "" || obj.hsnsmryTotlval == "" || obj.hsnsmryQty == "" || obj.hsnsmryTaxval == ""
        || obj.catId == null || obj.msrmntId == null || obj.hsnsmryTotlval == null || obj.hsnsmryQty == null
        || obj.hsnsmryTaxval == null || obj.hsnsmryClientHsnCode == null ||
        obj.hsnsmryClientHsnCode == "") {
        valFlag = false;
        alerts("Please fill the Required Details first !!");
        return
      }
      let hsnCode = obj.hsnsmryClientHsnCode.length
      let hsnitem = obj.hsnsmryClientHsnDesc.length
      if (hsnCode == 4 || hsnCode == 6 || hsnCode == 8) {
        valFlag = true;
      } else {
        valFlag = false;
        alerts("HSN/SAC code must be 4, 6, 8 Digits only!!");
        return
      }

      if (hsnitem < 31) {
        valFlag = true;
      } else {
        valFlag = false;
        alerts("Item length should not be more than 30!!");
        return
      }
    }

    let saveDataList = rowArray;
    let newItems = [];
    for (let obj of saveDataList) {
      let newObj = {
        "hsnsmryId": obj.hsnsmryId ? obj.hsnsmryId : null,
        "hsnsmrySrno": obj.hsnsmrySrno,
        mclientId: obj.mclientId,
        gstnC: { gstnId: parseInt(obj.gstnCid) },
        formType: { formtypeId: obj.formtypeId ? obj.formtypeId : 1 },
        month: { monthId: obj.monthId },
        year: { yearId: obj.yearId },
        mstCat: { "catId": parseInt(obj.catId) },
        mstHsnItem: obj.hsnitemId ? { "hsnitemId": parseInt(obj.hsnitemId) } : null,
        mstMsrmnt: { "msrmntId": parseInt(obj.msrmntId) },
        "hsnsmryQty": parseFloat(obj.hsnsmryQty),
        "hsnsmryTaxval": parseFloat(obj.hsnsmryTaxval),
        "hsnsmryIamt": parseFloat(obj.hsnsmryIamt),
        "hsnsmrySamt": parseFloat(obj.hsnsmrySamt),
        "hsnsmryCamt": parseFloat(obj.hsnsmryCamt),
        "hsnsmryCsamt": parseFloat(obj.hsnsmryCsamt),
        "hsnsmryTotltax": parseFloat(obj.hsnsmryTotltax),
        "hsnsmryTotlval": parseFloat(obj.hsnsmryTotlval),
        "hsnsmryUploadyn": obj.hsnsmryUploadyn,
        "hsnsmryUploaddt": obj.hsnsmryUploaddt,
        "hsnsmryApprovalyn": obj.hsnsmryApprovalyn,
        "hsnsmryApprovaldt": obj.hsnsmryApprovaldt,
        "hsnsmryClientHsnCode": obj.hsnsmryClientHsnCode,
        "hsnsmryClientHsnDesc": obj.hsnsmryClientHsnDesc,
        "sagclientId": 1,
        "flag": 0,
        "createdOn": obj.createdOn,
        "lastUpdatedOn": obj.lastUpdatedOn,
        "hsnsmryTmphsnsmryid": parseInt(obj.hsnsmryTmphsnsmryid),
        "hsnsmrySessionid": obj.hsnsmrySessionid
      }
      newItems.push(newObj);
    }

    if (valFlag == true) {
      this.commonService.getDataThrowPostMethod("updateHSN/GSTR1/HSN", newItems).subscribe(
        response => {
          if (response['data'] == true && response['httpStatus'] == 200) {
            this.goBack();
            success(response['message']);
          } else {
            alerts(response['message'])
          }

        }, error => {
          console.log(error);
          console.error('Error while updating HSN Details');
        });
    } else {
      alerts("Please Fill the Details first");
    }

  }

  getClientList(data) {
    let self = this;

    let Catarr = [
      { "key": null, "val": "--Select--" },
      { "key": 1, "val": "G" },
      { "key": 2, "val": "S" }
    ];

    let category = new SagSelectBox(Catarr, function (ele, prm) {
      ele.onchange = function () {
        self.getSelectedHsnSacGrid(ele.value);
        HSN.setOption(self.selectedhsnCodeGrid);
        desc.setOption(self.selectedDescriptionGrid);

      }
    })
    let HSN = new SagAutoCompleteBox(self.selectedhsnCode, function (ele, prm) {
      ele.onchange = function () {
        for (let obj of self.hsnCodeAndItem) {
          if (obj.hsnCode == ele.value) {
            self.gridDynamicObj.updateCell(prm.rowIndex, "hsnsmryClientHsnDesc", obj.description)
            self.gridDynamicObj.updateCell(prm.rowIndex, "hsnitemId", obj.hsnItemId)
            break;
          }
        }
      }
    })
    let desc = new SagAutoCompleteBox(self.selectedDescription, function (ele, prm) {
      ele.onchange = function () {
        for (let obj of self.hsnCodeAndItem) {
          if (obj.description == ele.value) {
            self.gridDynamicObj.updateCell(prm.rowIndex, "hsnsmryClientHsnCode", obj.hsnCode)
            self.gridDynamicObj.updateCell(prm.rowIndex, "hsnitemId", obj.hsnItemId)
            break;
          }
        }
      }
    })
    let UQC = new SagSelectBox(this.uqcList, function (ele, prm) {
      ele.onchange = function () {
      }
    })
    let quantity = new SagInputText({ "type": "number" }, function (ele, params) {
      ele.onchange = function () {
      }
    }); //hsnsmryTaxval hsnsmryIamt hsnsmryCamt hsnsmrySamt hsnsmryCsamt hsnsmryTotltax hsnsmryTotlval
    let taxVal = new SagInputText({ "type": "currency" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["hsnsmryTaxval"] = Number(ele.value);
        // params["hsnsmryTotltax"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        // if (params["hsnsmryTotltax"] < 0) {
        //   params["hsnsmryTotltax"] = 0;
        // }
        params["hsnsmryTotlval"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotlval"] < 0) {
          params["hsnsmryTotlval"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
      }
    });
    let igst = new SagInputText({ "type": "currency" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["hsnsmryIamt"] = Number(ele.value);
        params["hsnsmryTotltax"] = Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotltax"] < 0) {
          params["hsnsmryTotltax"] = 0;
        }
        params["hsnsmryTotlval"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotlval"] < 0) {
          params["hsnsmryTotlval"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
      }
    });
    let cgst = new SagInputText({ "type": "currency" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["hsnsmryCamt"] = Number(ele.value);
        params["hsnsmryTotltax"] = Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotltax"] < 0) {
          params["hsnsmryTotltax"] = 0;
        }
        params["hsnsmryTotlval"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotlval"] < 0) {
          params["hsnsmryTotlval"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
      }
    });
    let sgst = new SagInputText({ "type": "currency" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["hsnsmrySamt"] = Number(ele.value);
        params["hsnsmryTotltax"] = Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotltax"] < 0) {
          params["hsnsmryTotltax"] = 0;
        }
        params["hsnsmryTotlval"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotlval"] < 0) {
          params["hsnsmryTotlval"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
      }
    });
    let cess = new SagInputText({ "type": "currency" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["hsnsmryCsamt"] = Number(ele.value);
        params["hsnsmryTotltax"] = Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotltax"] < 0) {
          params["hsnsmryTotltax"] = 0;
        }
        params["hsnsmryTotlval"] = params["hsnsmryTaxval"] + Number(params["hsnsmryIamt"]) + Number(params["hsnsmryCamt"]) + Number(params["hsnsmrySamt"]) + Number(params["hsnsmryCsamt"]);
        if (params["hsnsmryTotlval"] < 0) {
          params["hsnsmryTotlval"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
      }
    });
    // let ttlTax = new SagInputText({ "type": "currency" }, function (ele, params) {
    //   ele.onchange = function () {
    //   }
    // });
    // let ttlVal = new SagInputText({ "type": "currency" }, function (ele, params) {
    //   ele.onchange = function () {
    //   }
    // });
    let component = {
      "category": category,
      "HSN": HSN,
      "desc": desc,
      "UQC": UQC,
      "quantity": quantity,
      "taxVal": taxVal,
      "igst": igst,
      "cgst": cgst,
      "sgst": sgst,
      "cess": cess,
      // "ttlTax": ttlTax,
      // "ttlVal": ttlVal,
    }

    this.gridData = {
      columnDef: this.colData,
      rowDef: data,
      components: component,
      gridExportService: this.gridExportService,
      disableAllSearch: true,
      callBack: {
        "onRowClick": function () {
          self.onRowSelectFn();
        },
        "onRowDbleClick": function () {
          // self.dblClickModify();
        }
      }

    };

    let sourceDiv = document.getElementById("hsn_add_grid");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);

  }

  onRowSelectFn() {
    this.deleteRowIndex = this.gridDynamicObj.getSelectedRowIndex();

  }

  ngOnInit() {
    this.getUQC();
    let selectedClient = this.shareService.getData("selectedClient");
    this.clientStateName = selectedClient.stateName;
  }

  goBack() {
    this.location.back();
  }


}
