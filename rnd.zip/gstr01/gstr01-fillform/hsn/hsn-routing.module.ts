import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HsnComponent } from './hsn.component';
import { HsnAddComponent } from './hsn-add/hsn-add.component';

const routes: Routes = [
  {
    path: "",
    component: HsnComponent
  },
  {
    path: "amv",
    component: HsnAddComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HsnRoutingModule { }
