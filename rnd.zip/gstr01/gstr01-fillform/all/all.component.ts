import { Component, OnInit } from '@angular/core';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Subscription } from 'rxjs';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { AnxCommonServiceService } from './../../../anx-one/anx-common-service.service';
import { lookup } from 'dns';
import { Router, ActivatedRoute } from '@angular/router';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { DatePipe } from '@angular/common';
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';

declare var SagGridMP;
declare var _;
declare var $;
declare function success(m);
declare function alerts(m);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-all',
  templateUrl: './all.component.html',
  styleUrls: ['./all.component.scss']
})
export class AllComponent implements OnInit {
  gridData: any;
  gridDynamicObj: any;
  location: ComponentLocation;
  //selectedDropDownDetails: any;

  importInputData: {};
  importlocation: ComponentLocation = {
    moduleId: 'importModule',
    selector: 'app-import'
  };
  exportlocation: ComponentLocation = {
    moduleId: 'exportModule',
    selector: 'app-export'
  };

  hideCommonDropDown : boolean = false;
  dropdownCofigJson = {
    selectedData: {
      formName: 'gstr1',
    },
    showHideDropdown: {
      month: false,
      showGetClientBtn: false,
      year: true,
      clientList: true,
      gstnList: true
    },
    enableDisableDropdown: {
      month: true,
      year: true,
      clientList: true,
      gstnList: true
    },
  };



  columnsArr_summary: any = [{ header: "S.No.", field: "sno", "editable": false, width: "50px", "align": "center", "ng-dblclick": "dblClickSection()" }, { header: "Section", field: "sectionName", filter: true, width: "270px", "editable": false, "text-align": "left", search: true, "ng-dblclick": "dblClickSection()" }, { header: "Total No Of Record", field: "invoiceCount", filter: true, width: "150px", "editable": false, search: true, "align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()" }, { header: "Total Taxable Value", field: "totalTaxable", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total IGST", field: "igstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total CGST", field: "cgstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total SGST", field: "sgstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total CESS", field: "cessAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total Invoice Value", field: "total", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }];

  columnsArr_de: any = [{ header: "S.No.", field: "sno", "editable": false, width: "50px", "align": "center", "ng-dblclick": "dblClickSection()" }, { header: "Section", field: "sectionName", filter: true, width: "270px", "editable": false, "text-align": "left", search: true, "ng-dblclick": "dblClickSection()" }, { header: "Total No Of Record", field: "invoiceCount", filter: true, width: "150px", "editable": false, search: true, "align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()" }, { header: "Total Taxable Value", field: "totalTaxable", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total IGST", field: "igstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total CGST", field: "cgstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total SGST", field: "sgstAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total CESS", field: "cessAmtTotal", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }, { header: "Total Invoice Value", field: "total", filter: true, width: "150px", "editable": false, search: true, "text-align": "right", "total": true, "total-text": "", "ng-dblclick": "dblClickSection()", "columnType": "numeric" }];

  rowData_reconsiliation: any = [{ header: "<input type=\"checkbox\" ng-click=\"selectAllCheckbox1($event)\">", field: "checkbox", "editable": false, width: "50px", "text-align": "center", elementType: [] }, { header: "S.No.", field: "sno", width: "50px", "editable": false, "align": "center", }, { header: "HSN/SAC Code", field: "hsnSc", filter: true, width: "150px", "editable": false, "align": "center", search: true, }, { header: "Description", field: "descr", filter: true, width: "150px", "editable": false, "align": "center", search: true, }, { header: "UQC", field: "uqc", filter: true, width: "70px", "editable": false, "align": "center", search: true, }, { header: "Quantity", field: "qty", filter: true, width: "120px", "editable": false, "align": "right", search: true, }, { header: "Taxable Value", field: "txval", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }, { header: "IGST", field: "iamt", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }, { header: "SGST", field: "samt", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }, { header: "CGST", field: "camt", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }, { header: "CESS", field: "csamt", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }, { header: "Total Value", field: "totlval", filter: true, width: "120px", "editable": false, "align": "right", search: true, "columnType": "numeric" }];

  rowData_compare_gstr_grid: any = [{ "colType": "checkBox", width: "50px", field: "checkBox", "text-align": "center", }, { header: "S.No.", field: "sno1", width: "50px", "editable": false, "text-align": "center", "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Name", field: "Name", filter: true, width: "290px", "text-align": "left", "editable": false, search: true, "sort": true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "GST No.", field: "GstNo", filter: true, width: "130px", "editable": false, "text-align": "center", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Section", field: "Section", filter: true, width: "190px", "editable": false, "text-align": "left", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "New Added In", field: "period", filter: true, width: "130px", "text-align": "center", "editable": false, search: true, "ng-click": "selectRow()", "ng-dblclick": "modifyOnDBlClick()" }, { header: "Original Invoice No.", field: "OrignalInvoiceNo", filter: true, width: "170px", "text-align": "center", "editable": false, search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Original Invoice Date", field: "OrignalInvoiceDate", filter: true, width: "200px", "editable": false, "text-align": "center", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Note Type", field: "noteType", filter: true, width: "150px", "editable": false, "align": "center", search: true, "ng-click": "selectRow()" }, { header: "Note No.", field: "NoteNo", filter: true, width: "150px", "editable": false, "align": "center", search: true, "ng-click": "selectRow()" }, { header: "Note Date", field: "NoteDate", filter: true, width: "120px", "editable": false, "align": "center", search: true, "ng-click": "selectRow()" }, { header: "Revised Invoice No.", field: "RevisedInvoiceNo", filter: true, width: "170px", "text-align": "center", "editable": false, search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Revised Invoice Date", field: "RevisedInvoiceDate", filter: true, width: "190px", "editable": false, "text-align": "center", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Shipping No", field: "invSbnum", filter: true, width: "160px", "editable": false, "text-align": "left", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Shipping Date", field: "invSbdt", filter: true, width: "160px", "editable": false, "text-align": "center", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Port No", field: "invSbpcode", filter: true, width: "160px", "editable": false, "text-align": "center", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }, { header: "Taxable Value", field: "TaxableValue", filter: true, width: "130px", "editable": false, "text-align": "right", search: true, "total": true, "total-text": "", "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "IGST", field: "Igst", filter: true, width: "130px", "text-align": "right", "editable": true, "total": true, "total-text": "", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "CGST", field: "Cgst", filter: true, width: "130px", "text-align": "right", "editable": true, "total": true, "total-text": "", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "SGST", field: "Sgst", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "CESS", field: "Cess", filter: true, width: "130px", "text-align": "right", "editable": false, "total": true, "total-text": "", search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "Total Tax", field: "TotelTax", filter: true, width: "130px", "text-align": "right", "editable": false, search: true, "total": true, "total-text": "", "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "Invoice Value", field: "InvoiceValue", filter: true, width: "130px", "text-align": "right", "editable": false, search: true, "total": true, "total-text": "", "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()", "columnType": "numeric" }, { header: "Uploaded By", field: "uploadBy", filter: true, width: "150px", "text-align": "center", "editable": false, search: true, "ng-click": "selectRow()", "ng-dblclick": "dblClickModify()" }];

  rowData_efile_grid: any = [{ header: "S.No.", field: "sno", width: "50px", "editable": false, search: true, "align": "center", "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Section", field: "sectionName", filter: true, width: "180px", "editable": false, "align": "", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Total Invoice", field: "totalInvoice", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Uploaded", field: "invoiceUploaded", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Deleted", field: "deletedInvoice", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Modified", field: "modifiedInvoice", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "To Be Uploaded", field: "invoiceTobeUploaded", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()" }, { header: "Balance", field: "balanceInvoice", filter: true, width: "125px", "editable": false, "align": "right", search: true, "ng-click": "selectRow()", "ng-dblclick": "addInvoiceInfo()", "columnType": "numeric" }];

  rowData_efile_grid_error: any = [{ header: "S.No.", field: "sno", "editable": false, width: "50px", "align": "center", "ng-click": "selectRow()" }, { header: "Section", field: "section", "align": "center", filter: true, width: "150px", "editable": false, search: true, "ng-click": "selectRow()", "sort": true }, { header: "Invoice No./Note No.", field: "invNo", filter: true, width: "150px", "align": "center", "editable": false, search: true, "ng-click": "selectRow()" }, { header: "GST No.", field: "ctin", filter: true, width: "150px", "align": "center", "editable": false, search: true, "ng-click": "selectRow()" }, { header: "Place Of Supply", field: "pos", filter: true, width: "150px", "editable": false, search: true, "ng-click": "selectRow()" }, { header: "Error", field: "errMsg", filter: true, width: "1000px", "editable": false, search: true, "ng-click": "selectRow()" }];

  rowData_efileSaveInvOnPortalLogInfo: any = [{ header: "Sno", field: "sno", width: "50px", "editable": false, "text-align": "center", search: true, }
    , { header: "Request Type", field: "rqst_type", filter: true, width: "150px", "editable": true, "text-align": "center", search: true, }, { header: "Request Date Time", field: "rqst_dttm", filter: true, width: "150px", "text-align": "center", "editable": true, search: true, }, { header: "Request Data", field: "rqst_data", filter: true, width: "150px", "text-align": "center", "editable": true, search: true, }, { header: "Response Date Time", field: "res_dttm", filter: true, width: "150px", "editable": true, "align": "center", search: true, }, { header: "Response Data", field: "res_data", filter: true, width: "150px", "text-align": "center", "editable": true, search: true, }, { header: "Txn ID", field: "txn_id", filter: true, width: "150px", "editable": true, "text-align": "center", search: true, }, { header: "Response Status", field: "res_status", filter: true, width: "150px", "editable": false, "text-align": "center", search: true, }];


  monthsArray: any = ["July", "August", "September", "October", "November", "December", "January", "February", "March", "Jul-Sep", "Oct-Dec", "Jan-Mar", "apr_sep", "oct_mar", "apr_mar"];
  sectionArray: any = ["all", "b2b", "b2ba", "b2cl", "b2cla", "cdnr", "cdnra", "cdnur", "cdnura", "exp", "expa", "b2cs", "b2csa", "exemp", "at", "ata", "atadj", "atadja", "hsn", "docs"];

  option: string;
  newData: string[];
  amendData: string[];
  requestData: {
    'yearId': any; 'monthId': any; 'gstnCid': any; 'formTypeName': string; //this.this.selectedDropDownDetails.formType
    'mClientId': any; 'invNoList': any[]; 'newAddedSectionName': string[]; 'option': any;
  };
  sub: Subscription;
  selectedMonthName: any;
  constructor(private ShareService: ShareService, private gridExportService: GridExportService,
    private fillformService: Gstr01FillformService, private router: Router, private activeRouter: ActivatedRoute, private eventEmitter: EventEmitterService, private commonServiceService: AnxCommonServiceService, private shareService: ShareService, private datePipe: DatePipe) {
    this.ShareService.newEvent();
    this.sub = this.ShareService.selectedDropDown.subscribe(selectedData => {
      this.selectedData = selectedData;
      console.log('SELECTED ::: ' + this.selectedData);
      this.__getAllSummaryDetails();
      this.getClientCurrentStatus();
    });
    this.ShareService.newEvent();
  }
  selectedData: any;

  loadImportModule(formId: String, template: String, form: String) {
    let obj = {
      formType: form,
      monthId: this.selectedData.month.monthId,
      period: this.selectedData.period.periodName,
      returnType: this.selectedData.returnType.rtnCode,
      selectedClient: this.selectedData.selectedClient,
      yearId: this.selectedData.year.yearId,
      yearName: this.selectedData.year.yearName,
    }
    this.location = this.importlocation;
    this.importInputData = { 'importInputData': { 'selectedData': obj, 'id': formId, 'template': template, 'form': form } };
    this.eventEmitter.loadImportForm();
  }

  loadExportModule(formId: String, template: String, form: String) {
    this.location = this.exportlocation;
    this.importInputData = { 'importInputData': {'id': formId, 'template': template, 'form': form } };
    this.eventEmitter.loadExportForm();
  }

  getDecimalFormat() {
    var labelList = $("#exampleModalCenter").find('label');
    let decimalFormat = {};
    let self = this;
    labelList.each(function (id, label) {
      var deciamlField = $(label).html();
      var decimalvalue = $(label).next().find('select').val();
      decimalFormat[deciamlField] = decimalvalue;
      self.decimalData[deciamlField] = decimalvalue;

    });
    return decimalFormat;
  }

  saveConfigurationFormat() {
    let data = this.getDecimalFormat();
    console.log("datadatadatadata", data);
    this.importInputData = { 'importInputData': { 'decimalFormat': data } };
    setTimeout(() => {
      $("#exampleModalCenter").modal('hide');
    }, 100);

  }
  openAddPopup(){
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
		}else{
      $("#exampleModalCenterr").modal("show");
    }
    //data-target="#exampleModalCenterr"
  }
  decimalFormatList: any;
  decimalFields: any;
  loadConfigurationForm() {
    this.decimalFormatList = this.shareService.getData("decimalFormatList");
    this.decimalFields = this.shareService.getData("decimalFields");
  }

  onKeywordsChange = (data: string) => {
    console.log(data);
    if (data == "refresh") {
      this.__getAllSummaryDetails();
    } else {
      this.decimalFormatList = data["list"];
      this.decimalFields = data["format"];
      this.selectAllDrop = this.decimalFields["Apply To All"];
    }
  }

  selectAllDrop: any;
  decimalData: any = {};
  selectDrp() {
    var value = this.selectAllDrop;
    if (value == 3) {
      $('.all_sel_box').find('select').val(2);
    } else {
      $('.all_sel_box').find('select').val(value);
    }
  }

  todayDate: any;
  clientCurrentStatus: any;
  returnDropDown: any;
  rtnStatus: any;
  ngOnInit() {
    if (!this.selectedData)
      this.fillformService.exit();
    console.log(this.selectedData);
    // this.getClientCurrentStatus();
    this.todayDate = this.datePipe.transform(new Date(), "dd/MM/yyyy");
    console.log("status of Client", this.selectedOptions)
    this.getAllSectionList();
  }

  // get All section list
  allSectionList: any;
  commonDropReq = {
    "reqList": ["sec"]
  }
  getAllSectionList() {
    this.shareService.getCommonDropdownList(this.commonDropReq, "GSTR1").subscribe(res => {
      if (res["httpStatus"] == 200) {
        this.allSectionList = res["data"]["sec"];
      }
    });
  }

  Modify(){
    let row = this.gridDynamicObj.getSeletedRowData();
    if(!row){
      alerts("Select Row to Modify");
    }else{
      row["invId"] = row.Id;
      this.shareService.setData("selectedInvoice", row);
      this.selectedSectionCode = row.SectionCode;
      this.goToSelectedSec();
    }
  }
  selectedSectionCode: string = null;
  goToSelectedSec() {
    if (this.selectedSectionCode == "nil") {
      this.selectedSectionCode = "exemp"
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode]);
    } else if (this.selectedSectionCode == "txpd") {
      this.selectedSectionCode = "atadj"
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode]);
    } else if (this.selectedSectionCode == "txpda") {
      this.selectedSectionCode = "atadja"
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode]);
    } else if (this.selectedSectionCode == "doc_Issue") {
      this.selectedSectionCode = "docs"
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode]);
    } else if (
      this.selectedSectionCode == "b2cs" ||
      this.selectedSectionCode == "b2csa" ||
      this.selectedSectionCode == "at" ||
      this.selectedSectionCode == "ata"
    ) {
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode]);
    } else {
      this.router.navigate(["gst/return/GSTR1/fillform/" + this.selectedSectionCode + "/amv"]);
    }
  }

  // For Get Client Current Status
  getClientCurrentStatus() {
    let requestData = {
      'yearId': parseInt(this.selectedData.year.yearId),
      'formType': 'GSTR1',
      'gstnCId': parseInt(this.selectedData.selectedClient.gstnCid),
      'mClientId': parseInt(this.selectedData.selectedClient.mClientId),
      'monthId': parseInt(this.selectedData.month.monthId),
    };
    this.commonServiceService.__getClientCurrentReturnStatus(requestData)
      .subscribe((data) => {
        if (data['currentStatus'].length != 0) {
          this.clientCurrentStatus = data['currentStatus'];
          this.selectedOptions = this.clientCurrentStatus[0]['rtnStatusCode']
          // this.rtnStatus = this.fillformSerivce.getSelectedValue(this.clientCurrentStatus, 'rtnstatusName', this.selectedData.selectedClient.returnStatus)['rtnstatusId'];
        } else {
          this.selectedOptions = 'NF'
        }
        this.returnDropDown = data['dropDown'];
      });
  }
  commonDropDownDataChange(data) {

  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  /**
   *  Object Initilizations...
   */
  selectedInnerTab = 'tab1';
  responseData: any = [];

  /**
   *  Get All Summary Details With Form Type
   */
  __getAllSummaryDetails() {
    this.selectedInnerTab = 'tab1';
    const self = this;
    const requestData = {  // reqData for Dummy purpose, change according requirements..
      'yearId': this.selectedData.year.yearId,
      'monthId': this.selectedData.month.monthId,
      'mClientId': this.selectedData.selectedClient.mClientId,
      'gstnCid': this.selectedData.selectedClient.gstnCid,
      'sectionName': 'all',//this.selectedData.section,
      'formType': 'GSTR1' //this.selectedData.formType
    };

    this.commonServiceService._getAllSummary(requestData).subscribe(
      (data) => {
        // tslint:disable-next-line: triple-equals
        if (data != null && data['httpStatus'] == 200) {
          console.log('Summary Data ----> ' + data);
          //this.getClientList(this.columnsArr,this.responseData);
          this.responseData = data['data'];
          this.gridData = {
            columnDef: this.columnsArr_summary,
            disableAllSearch: true,
            rowDef: this.responseData,
            gridExportService: this.gridExportService,
            sheatDetails: { sheatName: `GSTR1_All_summary_List`, title: `GSTR1_All_summary_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_All_Summary` },
            callBack: {
              'onRowClick': function () {
                self.onRowSelectFn();
              }, 'onRowDbleClick': function () {
                self.onRowDbleClick();
              }
            }
          };
          this.__generateGird(this.gridData, this.responseData);
        } else {
          alert(data['message']);
        }
      });
  }

  onRowDbleClick() {
    let data = this.gridDynamicObj.getSeletedRowData();
    if (data && data.sectionCode) {
      if (data.sectionCode == 'txpd') {
        this.router.navigate(['/gst/return/GSTR1/fillform/atadj']);
      } else if (data.sectionCode == 'txpda') {
        this.router.navigate(['/gst/return/GSTR1/fillform/atadja']);
      } else
        this.router.navigate(['/gst/return/GSTR1/fillform/' + data.sectionCode]);
    }
  }

  innerSubTab = 'subTab1';
  gstnInnerTab = 'gstnTab1';
  columnsArr_details: any = [{ "colType": "checkBox", width: "50px", field: "checkBox", "text-align": "center" }, { header: 'S.No.', field: 'sno', width: '100px', 'editable': false, 'text-align': 'center' },
  { header: 'Name', field: 'Name', filter: true, width: '290px', 'text-align': 'left', 'editable': false, search: true, 'sort': true, },
  { header: 'GST No.', field: 'GstNo', filter: true, width: '130px', 'editable': false, 'text-align': 'center', search: true },
  { header: 'Section', field: 'Section', filter: true, width: '190px', 'editable': false, 'text-align': 'left', search: true },
  { header: 'Original Invoice No.', field: 'OrignalInvoiceNo', filter: true, width: '170px', 'text-align': 'center', 'editable': false, search: true, },
  { header: 'Original Invoice Date', field: 'OrignalInvoiceDate', filter: true, width: '200px', 'editable': false, 'text-align': 'center', search: true, },
  { header: 'Note Type', field: 'noteType', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Note No', field: 'NoteNo', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Note Date', field: 'NoteDate', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Revised Invoice No.', field: 'RevisedInvoiceNo', filter: true, width: '170px', 'text-align': 'center', 'editable': false, search: true },
  { header: 'Revised Invoice Date', field: 'RevisedInvoiceDate', filter: true, width: '190px', 'editable': false, 'text-align': 'center', search: true },
  { header: 'Shipping No', field: 'invSbnum', filter: true, width: '150px', 'editable': false, 'align': 'center', search: true, },
  { header: 'Shipping Date', field: 'invSbdt', filter: true, width: '130px', 'text-align': 'right', 'editable': true, 'total': true, 'total-text': '', search: true },
  { header: 'Port No', field: 'invSbpcode', filter: true, width: '130px', 'text-align': 'right', 'editable': true, 'total': true, 'total-text': '', search: true },
  { header: 'Taxable Value', field: 'TaxableValue', filter: true, width: '130px', 'text-align': 'right', 'editable': false, 'total': true, 'total-text': '', search: true },
  { header: 'IGST', field: 'Igst', filter: true, width: '130px', 'text-align': 'right', 'editable': false, 'total': true, 'total-text': '', search: true },
  { header: 'CGST', field: 'Cgst', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'SGST', field: 'Sgst', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'CESS', field: 'Cess', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Total Tax', field: 'TotelTax', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Invoice Value', field: 'InvoiceValue', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Uploaded By', field: 'uploadBy', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Approved By', field: 'approvedBy', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Counter Party Status', field: 'cflag', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Return Filled By CP', field: 'cfs', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Action', field: 'action', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Earlier Period', field: 'eperiod', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'E-TIN ID', field: 'merchantId', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'flag', field: 'actionFlag', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' },
  { header: 'Dealer', field: 'delarType', filter: true, width: '130px', 'text-align': 'right', 'editable': false, search: true, 'total': true, 'total-text': '' }];

  /**
   *  Get Summary Details..
   */
  compData: any;
  __getDetails(type: any) {
    this.selectedInnerTab = 'tab2';
    this.compData = {
      sectionCode: 'ALL',
      formType: 'GSTR1',
    }

  }

  sectionList: any;
  showAll: any = false;


  resetInvoiceDetailsValue() {
    this.invoiceDetails = [
      { monthName: "April", monthId: 4, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "May", monthId: 5, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "June", monthId: 6, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "July", monthId: 7, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "August", monthId: 8, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "September", monthId: 9, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "October", monthId: 10, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "November", monthId: 11, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "December", monthId: 12, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "January	", monthId: 1, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "February", monthId: 2, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "March", monthId: 3, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      
      // { monthName: "", select: '', all: ''},
      
      { monthName: "Apr-Jun", monthId: 13, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "Jul-Sep", monthId: 14, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "Oct-Dec", monthId: 15, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      { monthName: "Jan-Mar", monthId: 16, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, },
      // { monthName: "", select: '', all: '', show: false},
      { monthName: "Apr-Sep", monthId: 17, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, show: false, },
      { monthName: "Oct-Mar", monthId: 18, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, show: false, },
      { monthName: "Apr-Mar", monthId: 19, select: false, all: 0, b2b: 0, b2ba: 0, b2bur: 0, imp_g: 0, imp_s: 0, b2cl: 0, b2cla: 0, cdnr: 0, cdnra: 0, cdnur: 0, cdnura: 0, exp: 0, expa: 0, b2cs: 0, b2csa: 0, nil: 0, at: 0, ata: 0, txpd: 0, txpda: 0, hsn: 0, doc: 0, show: false, }
    ]
  }

  invoiceDetails: any;

  /**
   *  get All Invoice Details...
   */
  __getAllinvoiceDetails() {
    this.selectedInnerTab = 'tab3';
    this.resetInvoiceDetailsValue();
    const selectedRow = this.selectedData['selectedClient'];
    console.log('data ::: ' + this.selectedData);
    const requestData = {  // reqData for Dummy purpose, change according requirements..
      'yearId': this.shareService.getData('year')['yearId'],
      //'monthId': this.shareService.getData('month')['monthId'],
      'gstnCid': this.shareService.getData('selectedClient').gstnCid,
      'formType': 'GSTR1', //this.this.selectedDropDownDetails.formType
      'mClientId': this.shareService.getData('selectedClient').mClientId
    };
    this.commonServiceService._getAllInvoiceDetails(requestData)
      .subscribe((data) => {
        if (data && data['httpStatus'] == 200) {
          this.genrateResp(data['data']);
        } else {
          alerts('Something went wrong..!');
        }
      });
  }
  genrateResp(data) {
    for (let index = 0; index < this.invoiceDetails.length; index++) {
      const section = this.invoiceDetails[index];
      for (let j = 0; j < data.length; j++) {
        const res = data[j];
        if (section.monthName.trim().toUpperCase() == res.monthName.trim().toUpperCase()) {
          section[res.secCode] = Number(res.rc);
        }
      }
    }
    $('#invoice_detail').modal('show');
  }

  /**
   *  Generate Grid Row..
   * @param GridData and ResponseData
   */
  __generateGird(gridData: any, responseData: any) {
    let self = this;
    const selectedRow = this.selectedData['selectedClient'];
    gridData["gridExportService"] = this.gridExportService;
    gridData["sheatDetails"] = { sheatName: `GSTR1_All_Detail_List`, title: `GSTR1_All_Detail_List`, fileName: `${this.shareService.getData("selectedClient").clientName}_${this.shareService.getData("selectedClient").gstNo}_All_Detail` };
    gridData['callBack'] = {
      'onRowClick': function () {
        self.onRowSelectFn();
      },
      'onRowDbleClick': function () {
        self.onRowDbleClick();
      }
    }
    const sourceDiv = document.getElementById('gstrone_fillform');
    this.gridDynamicObj = SagGridMP(sourceDiv, gridData, true, true);
    if (selectedRow) {
      for (let i = 0; i < responseData.length; i++) {
        const element = responseData[i];
        // tslint:disable-next-line: triple-equals
        if (element.mClientId == selectedRow.mClientId && element.gstnCid == selectedRow.gstnCid) {
          this.gridDynamicObj.setRowSelected(i);
          return;
        }
      }
    }

  }
  /**
   * Row Selected function..
   */
  selectedInvoice: any;
  onRowSelectFn() {
    this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
  }

  allselectChkBox: any = false;
  allMonthCheckBox: any = false;

  /**
   * For Month Checkbox Manage....
   * @param callFrom 
   */
  __isSelected(callFrom) {

    if (callFrom == 'all') {
      if (this.allselectChkBox == true) {
        this.allMonthCheckBox = true;
      } else {
        this.allMonthCheckBox = false;
      }
      for (let index = 0; index < this.invoiceDetails.length; index++) {
        const element = this.invoiceDetails[index];
        element.select = this.allMonthCheckBox;
      }
    } else {
      this.allselectChkBox = true;
      for (let index = 0; index < this.invoiceDetails.length; index++) {
        const element = this.invoiceDetails[index];
        if (!element.select) {
          this.allselectChkBox = false;
          break;
        }
      }
    }


  }
  isSelected = false;
  invoiceDetail2: any = [];
  /**
   *  Delete All invoice Details [ Month Wise Or Year Wise ] 
   */
  __deleteInvoiceDetails(showConfMsg) {
    if (showConfMsg) {
      let isSelected = false;
      for (let index = 0; index < this.invoiceDetails.length; index++) {
        const element = this.invoiceDetails[index];
        if (element.select) {
          element['all'] = (element.b2b + element.b2ba + element.b2cl + element.b2cla + element.cdnr + element.cdnra + element.cdnur + element.cdnura + element.exp + element.expa + element.b2cs + element.b2csa + element.at + element.ata + element.txpd + element.txpda + element.hsn + element.docs);
          this.invoiceDetail2.push(element);
        }
      }
      if (this.invoiceDetail2.length == 0) {
        return alerts("Select A Month");
      }
      var conf = confirm("Are you sure you want delete ?");
      if (conf == true) {
        this.deleteAndRefreshTable();
      }
    } else {
      if (this.invoiceDetail2.length > 0) {
        this.deleteAndRefreshTable();
      } else {
        success("Data deleted Successfully");
        this.__getAllinvoiceDetails();
      }
    }

  }


  private deleteAndRefreshTable() {
    const element = this.invoiceDetail2[this.invoiceDetail2.length - 1];
    if (element.select && element.all != 0) {
      let requestData = {
        'yearId': this.selectedData.year.yearId,
        'monthId': element.monthId,
        'gstnCId': this.selectedData.selectedClient.gstnCid,
        'formName': 'GSTR1',
        'mClientId': this.selectedData.selectedClient.mClientId,
        'secCode': 'ALL'
      };
      this.commonServiceService.__deleteInvoiceDetails(requestData)
        .subscribe((data) => {
          if (data && data['httpStatus'] == 200) {
            this.invoiceDetail2.pop();
            this.__deleteInvoiceDetails(false);
          }
        });
    } else {
      this.invoiceDetail2.pop();
      this.__deleteInvoiceDetails(false);
    }

  }
  deleteSelectedInvoice() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    this.selectedInnerTab == "tab1" ? this.summeryInvoiceDelete() : this.detailedInvoiceDelete();
  }

  private summeryInvoiceDelete() {
    let formName = 'GSTR1';
    let secCode = this.selectedInvoice.sectionCode;
    let mClientId = this.selectedData.selectedClient.mClientId;
    let gstnCId = this.selectedData.selectedClient.gstnCid;
    let monthId = this.selectedData.month.monthId;
    let yearId = this.selectedData.year.yearId;
    this.fillformService.getDataThrowGetMethod(`delete/${formName}/${secCode}?mClientId=${mClientId}&gstnCId=${gstnCId}&monthId=${monthId}&yearId=${yearId}`).subscribe(data => {
      if (data["httpStatus"] == 200) {
        success("Invoices Deleted Successfully");
        this.__getAllSummaryDetails();
      }
      else {
        alerts("Invoice Id could not be found!");
      }
    });
  }

  selectedOptions: any;
  private detailedInvoiceDelete() {
    var rowData = this.shareService.getData("selectedRow");
    console.log(rowData);
    var checkedInvoices = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    var invIds = [];
    let deletedIndex = [];
    if (checkedInvoices.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {
      checkedInvoices.forEach(element => { invIds.push(element.Id); deletedIndex.push(element.sag_G_Index); });
      this.fillformService.getDataThrowPostMethod(`GSTR1/all/deleteData`, invIds).subscribe(data => {
        if (data["httpStatus"] == 200) {
          success("Invoices Deleted Successfully");
          if (deletedIndex.length > 0) {
            this.gridDynamicObj.deleteMultipleRow(deletedIndex);
          }
        }
        else {
          alerts("Invoice Id could not be found!");
        }
      });
    }
  }
    else {
      alerts("Please Select at least one Invoice!!");
    }
  }

  /**
   *  Save Client Status...!
   */
  __saveClientStatus(status: any) {
    let requestData = {
      'clientName': this.selectedData.selectedClient.clientName,
      'month': this.selectedData.month.monthId,
      'gstnCid': this.selectedData.selectedClient.gstnCid,
      'formType': 'GSTR1', //this.selectedDropDownDetails.formType
      'mclientId': this.selectedData.selectedClient.mClientId,
      'rtnStatusCode': this.selectedOptions,//this.fillformSerivce.getSelectedValue(this.returnDropDown, "rtnstatusId", this.selectedOptions)['rtnStatusCode'],
      'rtnperiodId': this.selectedData.year.yearId,
      'rtnstatus': this.fillformService.getSelectedValue(this.returnDropDown, "rtnstatusCode", this.selectedOptions)['rtnstatusName'],
      'rtnstatusDate': this.todayDate
    };
    this.commonServiceService.__saveClientStatus(requestData)
      .subscribe((data) => {
        if (data && data['httpStatus'] == 200) {
          this.responseData = data['data'];
          console.log(this.invoiceDetails);
          this.responseData = data['data'];
          success("Data Successfully Saved..!");
        } else {
          alerts(data['message']);
        }
      });
  }
  gridOutput: any;
  detailComp($event) {
    this.gridOutput = $event;
    let gridData = this.gridOutput.gridData;
    let response = this.gridOutput.response;
    this.__generateGird(gridData, response);
  }

  openEfile() {
    this.ShareService.setData("formType", 'GSTR1')
    this.router.navigate(['/gst/return/GSTR1/fillform/efile']);
  }

}
