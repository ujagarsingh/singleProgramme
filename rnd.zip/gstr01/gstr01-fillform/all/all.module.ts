import { NgModule } from '@angular/core';
import { CommonModule, DatePipe} from '@angular/common';
import { AllRoutingModule } from './all-routing.module';
import { AllComponent } from './all.component';
import { GSTSharedModule } from '../../../../shared/shared.module'
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [
    AllComponent
  ],
  imports: [
  	LanguageModule,
    CommonModule,
    AllRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ],
  providers: [DatePipe]
})
export class AllModule { }
