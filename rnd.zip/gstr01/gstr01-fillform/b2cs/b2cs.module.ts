import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { B2csRoutingModule } from './b2cs-routing.module';
import { B2csComponent } from './b2cs.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { B2csAddComponent } from './b2cs-add/b2cs-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [B2csComponent, B2csAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,Gstr01FillformSharedModule,
    B2csRoutingModule,
    GSTSharedModule,
    CalendarModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class B2csModule { }
