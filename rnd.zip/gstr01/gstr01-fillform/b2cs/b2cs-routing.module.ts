import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2csComponent } from './b2cs.component';
import { B2csAddComponent } from './b2cs-add/b2cs-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2csComponent
  } ,
  {
    path : "amv",
    component : B2csAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2csRoutingModule { }
