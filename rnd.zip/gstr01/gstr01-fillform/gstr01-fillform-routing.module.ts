import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Gstr01FillformComponent } from './gstr01-fillform.component';

const routes: Routes = [
  {
    path: "",
    component: Gstr01FillformComponent,
    children : [
      {
        path : 'all',
        loadChildren: () => import('./all/all.module').then(mod => mod.AllModule)
      },
      {
        path: 'b2b',
        loadChildren: () => import('./b2b/b2b.module').then(mod => mod.B2bModule) 
      },
      {
        path: 'b2ba',
        loadChildren:() => import('./b2ba/b2ba.module').then(mod => mod.B2baModule)
      },
      {
        path: 'b2cl',
        loadChildren:() => import('./b2cl/b2cl.module').then(mod=> mod.B2clModule)
      },
      {
        path: 'b2cla',
        loadChildren:() => import('./b2cla/b2cla.module').then(mod=> mod.B2claModule)
      },
      {
        path: 'b2cs',
        loadChildren:() => import('./b2cs/b2cs.module').then(mod=> mod.B2csModule)
      },
      {
        path: 'b2csa',
        loadChildren:() => import('./b2csa/b2csa.module').then(mod=> mod.B2csaModule)
      },
      {
        path: 'cdnr',
        loadChildren:() => import('./cdnr/cdnr.module').then(mod=> mod.CdnrModule)
      },
      {
        path: 'cdnra',
        loadChildren:() => import('./cdnra/cdnra.module').then(mod=> mod.CdnraModule)
      },
      {
        path: 'cdnur',
        loadChildren:() => import('./cdnur/cdnur.module').then(mod=> mod.CdnurModule)
      },
      {
        path: 'cdnura',
        loadChildren:() => import('./cdnura/cdnura.module').then(mod=> mod.CdnuraModule)
      },
      
      {
        path: 'exp',
        loadChildren:() => import('./exp/exp.module').then(mod=> mod.ExpModule)
      },
      {
        path: 'expa',
        loadChildren:() => import('./expa/expa.module').then(mod=> mod.ExpaModule)
      },
      {
        path: 'b2cs',
        loadChildren:() => import('./b2cs/b2cs.module').then(mod=> mod.B2csModule)
      },
      {
        path: 'b2csa',
        loadChildren:() => import('./b2csa/b2csa.module').then(mod=> mod.B2csaModule)
      },
      {
        path: 'exemp',
        loadChildren:() => import('./exemp/exemp.module').then(mod=> mod.ExempModule)
      },
      {
        path: 'at',
        loadChildren:() => import('./at/at.module').then(mod=> mod.AtModule)
      },
      {
        path: 'ata',
        loadChildren:() => import('./ata/ata.module').then(mod=> mod.AtaModule)
      },
      {
        path: 'atadj',
        loadChildren:() => import('./atadj/atadj.module').then(mod=> mod.AtadjModule)
      },
      {
        path: 'atadja',
        loadChildren:() => import('./atadja/atadja.module').then(mod=> mod.AtadjaModule)
      },
      {
        path: 'hsn',
        loadChildren:() => import('./hsn/hsn.module').then(mod=> mod.HsnModule)
      },
      {
        path: 'docs',
        loadChildren:() => import('./docs/docs.module').then(mod=> mod.DocsModule)
      },
      {
        path: 'efile',
        loadChildren: () => import('../../efile/efile.module').then(mod => mod.EfileModule),
      }
    ]
    
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Gstr01FillformRoutingModule { }
