import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExpComponent } from './exp.component';
import { AmvComponent } from './amv/amv.component';

const routes: Routes = [
  {
    path : "",
    component : ExpComponent
  },
  {
    path: "amv",
    component: AmvComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExpRoutingModule { }
