import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExpRoutingModule } from './exp-routing.module';
import { ExpComponent } from './exp.component';

import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { AmvComponent } from './amv/amv.component';
import { SharedModule, CalendarModule, DropdownModule } from 'primeng/primeng';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [ExpComponent, AmvComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    SharedModule,
    ExpRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    CalendarModule, 
    DropdownModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class ExpModule { }
