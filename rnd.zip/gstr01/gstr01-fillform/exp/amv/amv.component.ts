import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from 'genmaster/src/master/services/validation.service';
import { RetrunService } from '../../../../retrun.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { Subscription } from 'rxjs';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { ConfigurationsService } from '../../../../configuration/configurations.service';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
declare const $;
declare var SagGridMP;

declare function success(m);
declare function alerts(m);

declare var SagGridMP;
declare var SagInputText;
declare var SagSelectBox;

@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-amv',
  templateUrl: './amv.component.html',
  styleUrls: ['./amv.component.scss']
})
export class AmvComponent implements OnInit {

  selectedDiff: any = null;
  commonFormGroup: FormGroup;
  singleTypeFormGroup: FormGroup;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [{ "key": "", "val": "-Select-" }];
  itemArr = [{ "key": "", "val": "-Select-" }];
  formType = "GSTR1";
  commonDropRes: any = {};
  commonDropReq = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category"], "docTypeParams": "R" };
  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };
  selectedClient: any;
  revChangeList: any;
  portCodeList: Array<Object>;
  singleMode: boolean = false;
  clientStateName: any;
  paymentData: Array<Object>;
  viewMode: boolean = false;
  selectedInvoice: any;
  hsnCodeAndItem: any;

  constructor(private eventEmitterService: EventEmitterService, private shareService: ShareService, private configurationService: ConfigurationsService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService,
    private router: Router,
    private locationB: Location, ) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.clientStateName = this.selectedClient.stateName;
    this.manageDateObject();
    this.revChangeList = [{ label: "Yes", value: 'Y' }, { label: "No", value: 'N' }];
  }

  get f() { return this.commonFormGroup.controls; }

  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;
  manageDateObject() {
    var obj = this.returnService.manageDateObjects(false);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }
  configuredData: any;
  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.getPortCode();
    this.commonFormGroup = this.fillformService.getFromGroup();

    this.overrideValidation();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    this.shareService.removeData("selectedInvoice");
    this.manageObservables();

  }

  getPaymentData() {
    this.fillformService.getDataThrowPostMethod("paymentData", {}).subscribe(response => {
      this.paymentData = response['data']
      console.log('Data', response)
      this.getCommonDropdownListOnLoad(this.commonDropReq, this.formType);
    })
  }

  overrideValidation() {
    // this.commonFormGroup.get("invSbnum").setValidators([Validators.required, ValidationService.shippingNoValidator]);
    // this.commonFormGroup.get("invNo").setValidators([Validators.required, ValidationService.invoiceNoValidator]);
    this.commonFormGroup.get("invSbdt").setValidators(null);
    this.commonFormGroup.get("invSbnum").setValidators([ValidationService.shippingNoValidator]);
    this.commonFormGroup.get("sp.spId").setValidators(null);
  }




  getPortCode() {
    this.fillformService.getPortCode().subscribe(res => {
      this.portCodeList = res['data'];
      this.getPaymentData();
    })
  }



  callFillDataAccordingSupplyTypeMethod = true;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitemApptaxrt"];
        delete data["data"]["txnInvitemData"];
        // data["data"]["pbcode"]["pbcodeId"] = data["data"]["pbcode"]["pbcodeId"]
        formGroup.patchValue(data["data"]);
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        if (this.selectedInvoice && this.selectedInvoice.amvType == 'view') {
          this.gridDynamicObj.disableAllRow();
          this.commonFormGroup.disable();
        } 
        this.callFillDataAccordingSupplyTypeMethod = false;
        // this.sellerChange();
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }


  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.splyTypeOvserver = this.commonFormGroup.get("splytype.splytypeId").valueChanges.subscribe(data => {
    });

    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else if (this.selectedInvoice && this.selectedInvoice.amvType == 'view') {
          this.gridDynamicObj.disableAllRow();
          this.commonFormGroup.disable();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });

    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });

  }

  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];

  enabledisableAllRowColumn() {
    if (this.supplyTypeCode) {
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.enableColumn("invitemIrt") : this.gridDynamicObj.disableColumn("invitemIrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.enableColumn("invitemIamt") : this.gridDynamicObj.disableColumn("invitemIamt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemCrt") : this.gridDynamicObj.enableColumn("invitemCrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemCamt") : this.gridDynamicObj.enableColumn("invitemCamt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemSrt") : this.gridDynamicObj.enableColumn("invitemSrt");
      this.supplyTypeCode == "INTER" ? this.gridDynamicObj.disableColumn("invitemSamt") : this.gridDynamicObj.enableColumn("invitemSamt");
      this.updateGrid();
    }
  }

  updateGrid() {
    if (this.callFillDataAccordingSupplyTypeMethod) {
      var arr = this.gridDynamicObj.getGridData();
      var invTotal = 0.0;
      var invTotalTax = 0.0;
      for (var i = 0; i < arr.length; i++) {
        let obj = arr[i];
        if (obj.invitemTaxamt && !isNaN(obj["invitemTaxamt"])) {
          obj.invitemApptaxrt = this.selectedDiff;
          this.fillformService.fillDataAccordingSupplyType(this.supplyTypeCode, obj, this.selectedInvoiceType, this.fillformService.roundOffBy);
          invTotal += parseFloat(!isNaN(obj["invitemTotlval"]) ? obj["invitemTotlval"] : 0);
          invTotalTax += (!isNaN(obj["invitemTotltax"]) ? obj["invitemTotltax"] : 0);
          this.gridDynamicObj.updateRow(i, obj);
        }
      }
      this.commonFormGroup.patchValue({
        invVal: invTotal,
        invTxval: invTotalTax
      })
    }
  }

  differentialChange() {
    var arr = this.gridDynamicObj.getGridData();
    for (let index = 0; index < arr.length; index++) {
      const obj = arr[index];
      this.fillformService.commonMethods(this, index, obj);
    }
  }

  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'sellerModule',
    selector: 'app-return-seller-form'
  };



  openSellerModal() {
    this.location = this.importlocation;
    $("#sellerModal").modal("show");
  }

  selectedInvoiceType = {
    invtypeCode: null
  }
  invoiceTypeChange() {
    var paymentId = this.commonFormGroup.get("gstpayment.gstpaymentId").value;
    var paymentCode;
    for (let obj of this.paymentData) {
      if (obj['gstpaymentId'] == paymentId) {
        paymentCode = obj['gstpaymentCode']
        this.selectedInvoiceType['invtypeCode'] = obj['gstpaymentCode']
      }
    }
    if (paymentCode == "WOPAY") {
      this.updateFieldsAccordingSEWOP();
    } else if (paymentCode == "WPAY") {
      this.gridDynamicObj.enableColumn("invitemIrt");
      this.gridDynamicObj.enableColumn("invitemIamt");
      this.gridDynamicObj.disableColumn("invitemCrt");
      this.gridDynamicObj.disableColumn("invitemCamt");
      this.gridDynamicObj.disableColumn("invitemSrt");
      this.gridDynamicObj.disableColumn("invitemSamt");
      this.gridDynamicObj.enableColumn("invitemCsrt");
      this.gridDynamicObj.enableColumn("invitemCsamt");
    } else {
      this.enabledisableAllRowColumn();
    }

    this.updateGrid();
  }


  updateFieldsAccordingSEWOP() {
    this.gridDynamicObj.disableColumn("invitemIrt");
    this.gridDynamicObj.disableColumn("invitemIamt");
    this.gridDynamicObj.disableColumn("invitemCrt");
    this.gridDynamicObj.disableColumn("invitemCamt");
    this.gridDynamicObj.disableColumn("invitemSrt");
    this.gridDynamicObj.disableColumn("invitemSamt");
    this.gridDynamicObj.disableColumn("invitemCsrt");
    this.gridDynamicObj.disableColumn("invitemCsamt");
    var arr = this.gridDynamicObj.getGridData();
    for (var i = 0; i < arr.length; i++) {
      let obj = arr[i];
      obj["invitemIrt"] = null;
      obj["invitemIamt"] = null;
      obj["invitemCrt"] = null;
      obj["invitemCamt"] = null;
      obj["invitemSrt"] = null;
      obj["invitemSamt"] = null;
      obj["invitemCsrt"] = null;
      obj["invitemCsamt"] = null;
      obj["invitemTotltax"] = null;
      this.gridDynamicObj.updateRow(i, obj);
    }
  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").clientid,
        this.shareService.getData("year")["yearId"], null).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alert("invoice No already exist In this financial Year");
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }
  supplyTypeCode: any = 'INTER';
  setDefaults() {
    for (const obj of this.commonDropRes.supplyType) {
      if (obj.supplyCode == "INTER") {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
        break;
      }
    }

  }

  saveEXP() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    var items = this.singleMode ? [this.amtFormGroupData] : this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      var obj = this.commonFormGroup.value;
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      this.fillformService.saveInvoice(obj, 'exp').subscribe(data => {
        if (data["httpStatus"] == 200) {
          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
          this.commonFormGroup.get("invSbnum").reset();
          this.commonFormGroup.get("invNo").reset();
          this.commonFormGroup.get("invId").reset();
          success(data['message'])
          this.closeSingleMode()
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }

  }

  hsnCodeList: any;
  hsnDesList: any;
  completeHsnList: any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.setGridDropdownOnLoad();
      })
  }

  /**
   * get common dropdown list
   */
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      if (data["data"]) {
        this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfExp");
        this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
          if (res["httpStatus"] == 200) {
            this.commonDropRes = res["data"];
            this.getHSNSummary();
            this.setDefaults()
            this.singleModeO();
          }
        });
      }
    });
  }

  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  popupData: {};

  singleModeO() {
    let obj = Object.assign({}, this.commonDropRes)
    obj.payment = this.paymentData
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }

  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue(
      {
        section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'exp')["secId"] },
        state: { stateId: this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', this.selectedClient.gstNo.substr(0, 2))["stateId"] },
        splytype: { splytypeId: this.fillformService.getSelectedValue(this.commonDropRes.supplyType, 'supplyCode', 'INTER')["supplyId"] }
      });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
    if (this.selectedInvoice)
      this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
    else
      this.addGrid(this.gridRowData);
    this.invoiceTypeChange();
    this.gridDynamicObj.disableAllRow();

  }
  addGrid(data) {

    var gridData = {
      columnDef: this.fillformService.getColumns("exp", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("gstrone_expAdd"), gridData, true, true);
  }

  addGridRow() {

  }
  deleteGridRow() {

  }

  ngOnDestroy() {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    if (this.splyTypeOvserver)
      this.splyTypeOvserver.unsubscribe();
    if (this.commonObserver)
      this.commonObserver.unsubscribe();
    if (this.rchargeObserver)
      this.rchargeObserver.unsubscribe();
  }

  goBack() {
    this.locationB.back();
  }

}
