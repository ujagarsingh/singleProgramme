import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CdnuraComponent } from './cdnura.component';
import { CdnuraAddComponent } from './cdnura-add/cdnura-add.component';

const routes: Routes = [
  {
    path : "",
    component : CdnuraComponent
  },{
    path : "amv",
    component : CdnuraAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CdnuraRoutingModule { }
