import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { B2bRoutingModule } from './b2b-routing.module';
import { B2bComponent } from './b2b.component';
import { B2bAddComponent } from './b2b-add/b2b-add.component';
import { FormsModule } from '@angular/forms';
import { SharedModule, CalendarModule } from 'primeng/primeng';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [B2bComponent, B2bAddComponent],
  imports: [
  	LanguageModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    CalendarModule,
    CommonModule,SharedModule,
    B2bRoutingModule,
    FormsModule,
    Gstr01FillformSharedModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ],
   
})
export class B2bModule { }
