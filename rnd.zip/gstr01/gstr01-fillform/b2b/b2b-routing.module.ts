import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2bComponent } from './b2b.component';
import { B2bAddComponent } from './b2b-add/b2b-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2bComponent
  },
  {
    path: 'amv',
    component: B2bAddComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2bRoutingModule { }
