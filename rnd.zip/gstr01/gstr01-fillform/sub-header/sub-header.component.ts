import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gstr-01-fillform-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.scss']
})
export class SubHeaderComponent implements OnInit {
  @Input() selectedSubTab : any;
  constructor( private router : Router ) { }

  ngOnInit() {
  }

  subTabClick(url : string ){
    this.router.navigate([url]);
  }
}
