import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CdnurComponent } from './cdnur.component';
import { CdnurAddComponent } from './cdnur-add/cdnur-add.component';

const routes: Routes = [
  {
    path : "",
    component : CdnurComponent
  },
  {
    path: "amv",
    component: CdnurAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CdnurRoutingModule { }
