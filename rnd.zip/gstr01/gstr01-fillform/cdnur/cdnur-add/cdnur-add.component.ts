import { Component, OnInit, OnDestroy } from '@angular/core';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Location } from '@angular/common';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
declare var SagGridMP;
declare var $;
declare function alerts(message)
declare function success(message)

@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-cdnur-add',
  templateUrl: './cdnur-add.component.html',
  styleUrls: ['./cdnur-add.component.scss']
})
export class CdnurAddComponent implements OnInit {

  hsnsacArr = [
    { "key": "", "val": "-Select-" },
  ];
  itemArr = [
    { "key": "", "val": "-Select-" },
  ];
  gridDynamicObj: any;
  formType: any = "GSTR1";
  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };
  selectedClient: any;
  clientStateName: any;
  commonFormGroup: FormGroup;
  
  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, HsnDesc: null,hsnitemId : null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];
  hsnCodeAndItem: any;

  constructor(private configurationService: ConfigurationsService, private eventEmitterService: EventEmitterService, public shareService: ShareService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.clientStateName = this.selectedClient.stateName;
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
  }

  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.manageDateObject();
    this.overrideValidation();
    this.manageObservables();
    this.getCommonDropdownListOnLoad({ "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category", 'noteType'], "docTypeParams": "R" }, this.formType);
  }

  dateChange(type) {
    if (this.commonFormGroup.get('invDt').value && this.commonFormGroup.get('invNtdt').value) {
      let invDt = (this.commonFormGroup.get('invDt').value).split('/');
      let ntdt = (this.commonFormGroup.get('invNtdt').value).split('/');
      let d1 = new Date(invDt[2], invDt[1], invDt[0]);
      let d2 = new Date(ntdt[2], ntdt[1], ntdt[0]);
      if (d1.getTime() > d2.getTime()) {
        alerts("Note Date should be Greater Then Invoice Date")
        this.commonFormGroup.get(type).patchValue(null);
      }
    }
  }

  overrideValidation() {
    this.commonFormGroup.controls['sp']['controls']['spId'].setValidators(null);
    this.commonFormGroup.controls['notetype']['controls']['notetypeId'].setValidators([Validators.required]);
    this.commonFormGroup.addControl("invNtnum", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invNtdt", new FormControl(null, Validators.required));
    // this.commonFormGroup.addControl("notetypeId", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invNtdt", new FormControl(null, Validators.required));
  }

  differentialChange() {
    var arr = this.gridDynamicObj.getGridData();
    for (let index = 0; index < arr.length; index++) {
      const obj = arr[index];
      this.fillformService.commonMethods(this, index, obj);
    }
  }

  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;
  manageDateObject() {
    var obj = this.returnService.manageDateObjects(false);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }

  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.splyTypeOvserver = this.commonFormGroup.get("splytype.splytypeId").valueChanges.subscribe(data => {
    });
    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });
    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });
  }

  addGrid(data) {
    var gridData = {
      columnDef: this.fillformService.getColumns("cdnur", this.configuredData),
      rowDef: data,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      components: this.fillformService.getGridComponent(this),
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("cdnur_add_grid"), gridData, true, true);
  }

  selectedInvoice: any;
  revChangePerList: any;
  invoiceTypeList: any = [];
  getInvTypeAndRevChrgsList() {
    this.fillformService.getInvTypeAndRevChrgsList().subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (data["data"] && data["data"]["invTypes"]) {
          let secId = this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'cdnur')["secId"]
          for (const obj of data["data"]["invTypes"]) {
            if (obj["sectionId"] == secId)
              this.invoiceTypeList.push(obj);
          }
        }
        if (data["data"] && data["data"]["revCharges"])
          this.revChangePerList = data["data"]["revCharges"];
      }
      if (this.selectedInvoice) {
        this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
        this.shareService.removeData("selectedInvoice");
      } else {
        this.addGrid(this.gridRowData);
        this.gridDynamicObj.disableAllRow();
      }
    });
  }

  hsnCodeList: any;
  hsnDesList : any;
  completeHsnList : any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.getInvTypeAndRevChrgsList();
      })
  }

  callFillDataAccordingSupplyTypeMethod = true;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (this.flag) {
          //data["data"]["invRefinvid"] = data["data"]["invId"];
          data["data"]["invId"] = null;
          this.flag = false;
        }
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitemApptaxrt"];
        delete data["data"]["txnInvitemData"];
        formGroup.setValue(data["data"]);
        formGroup.patchValue({
          section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'cdnur')["secId"] },
          year: { yearId: this.shareService.getData("year")["yearId"] },
          month: { monthId: this.shareService.getData("month")["monthId"] }
        })
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        this.callFillDataAccordingSupplyTypeMethod = false;
        this.sellerChange('pos');
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }


  selectedDiff: any;
  selectedInvoiceType: any
  invoiceTypeChange() {
    var data = this.invoiceTypeList[0];
    if (!data)
      data = this.returnService.getSelectedObject(this.invoiceTypeList, this.commonFormGroup.get("invtype.invtypeId").value, "invtypeId");
    this.selectedInvoiceType = data;
    if (!data)
      this.commonFormGroup.patchValue({ invtype: { invtypeId: data.invtypeId } });
    this.fillformService.invoiceTypeChange(this.commonFormGroup, this.selectedInvoiceType, this.gridDynamicObj, this.supplyTypeCode, this.selectedInvoice, this.selectedDiff, this.callFillDataAccordingSupplyTypeMethod);
  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == null) {
            alerts("Invoice does Not exist");
          }
        });
    }
  }

  saveCdnur() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    var items = this.singleMode ? [this.amtFormGroupData] : this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      var obj = this.commonFormGroup.getRawValue();
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      obj.invPrsyn = obj.invPrsyn ? 'Y' : 'N';
      this.fillformService.saveInvoice(obj, 'cdnur').subscribe(data => {
        if (data["httpStatus"] == 200) {
          success(data["message"]);
          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null, invNtdt: null, invNtnum: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }
  }

  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          this.getHSNSummary();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo == null && obj.stateId != this.selectedClient.stateId)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
        }
      });
  }

  commonDropRes: any = {};
  configuredData: any = {};
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      if (data["data"]) {
        this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfCdunr");
        this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
          if (res["httpStatus"] == 200) {
            this.commonDropRes = res["data"];
            this.setGridDropdownOnLoad();
          }
          this.getSellerList();
        });
      }
    });
  }

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue({
      section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'cdnur')["secId"] },
      splytype: { splytypeId: this.fillformService.getSelectedValue(this.commonDropRes.supplyType, 'supplyCode', 'INTER')["supplyId"] }
    });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
    // this.addGrid([this.gridRowData]);
    // this.gridDynamicObj.disableAllRow();
  }

  supplyTypeCode: any;
  sellerChange(type) {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("sp.spId").value, "spId");
    let fullState = this.commonFormGroup.get("state.stateId").value ? this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateId', this.commonFormGroup.get("state.stateId").value) :
      this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', data.gstnNo.substr(0, 2));
    for (const obj of this.commonDropRes.supplyType) {
       if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
      }
    }
    if (data){
      if(type == "seller"){
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: (data.stateId != null && data.stateId != 0) ? data.stateId : fullState.stateId } });
      }else{
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: fullState.stateId  } });
      }
    }

    this.onFormGroupChangeFireGridEvent();
    this.invoiceTypeChange();
  }

  stateChange() {
    var data = this.returnService.getSelectedObject(this.commonDropRes.state, this.commonFormGroup.get("state.stateId").value, "stateId")['stateCode'];
    for (const obj of this.commonDropRes.supplyType) {
      if (obj.supplyCode == "INTRA" && this.selectedClient.gstNo.substr(0, 2) === data) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
      } else if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != data) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
      }
    }
    this.invoiceTypeChange();
  }

  onFormGroupChangeFireGridEvent() {
    let arr = this.gridDynamicObj.getGridData();
    if (arr.length > 0) {
      for (let index = 0; index < arr.length; index++) {
        const obj = arr[index];
        this.fillformService.commonMethods(this, index, obj);
      }
    }
  }
  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'searchInvoiceModule',
    selector: 'app-search-invoice'
  };
  popupData: any;

  openSearchPopup() {
    this.location = this.importlocation;
    this.popupData = {
      'popupData': {
        'formName': "GSTR1", 'sectionCode': "cdnur", 'showYear': true, 'showMonth': true, 'showSeller': true,
        'showGstNo': true, 'sellerType': "Receiver", 'showInvNo': true, "crdrSecName": 'b2cl'
      }
    };
    this.eventEmitterService.loadSearchInvoicePopup();
  }
  flag = false;
  onKeywordsChange = (data) => {
    this.flag = true;
    this.manageSelectedInvoice(data, this.commonFormGroup);
    // this.selectedDiff = data.apptaxrt ? Number(data.apptaxrt) : null;
    // this.commonFormGroup.patchValue({
    //   spId: data.SpId,
    //   invRefinvid: data.Id,
    //   invNo: data.OrignalInvoiceNo,
    //   invDt: data.OrignalInvoiceDate,
    //   invVal: data.InvoiceValue,
    //   invTxval: data.TaxableValue,
    //   invtypeId: data.InvTypeCode?this.returnService.getSelectedObject(this.invoiceTypeList, data.InvTypeCode, "invtypeCode")['invtypeId']:null,
    //   stateId: data.stateName ? this.returnService.getSelectedObject(this.commonDropRes.state, data.stateName, "stateName")['stateId']:null 
    // });
    this.commonFormGroup.get("invNo").disable()
    this.commonFormGroup.get("invDt").disable()
    // this.getInvoiceItemList();
    // this.stateChange();
  }

  ntNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkNoteNo(this.commonFormGroup.get("invNtnum").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"]).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts(data["message"]);
            this.commonFormGroup.patchValue({ invNtnum: null })
          }
        });
    }
  }

  // getInvoiceItemList() {
  //   this.returnService.getInvoiceItemList(this.commonFormGroup.get("invRefinvid").value).subscribe(data => {
  //     if (data["httpStatus"] == 200) {
  //       console.log(data["data"]);
  //       for (var i = 0; i < data["data"].length; i++) {
  //         let obj = data["data"][i];
  //         obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
  //       }
  //       this.addGrid(data["data"]);
  //     } else
  //       this.addGrid([]);
  //     this.sellerChange('pos');
  //     this.invoiceTypeChange();
  //   });
  // }

  location1: ComponentLocation;
  importlocation1: ComponentLocation = {
    moduleId: 'sellerModule',
    selector: 'app-return-seller-form'
  };

  openSellerModal() {
    this.location1 = this.importlocation1;
    $("#sellerModal").modal("show");
  }

  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  singleMode: boolean = false;
  singleModeO() {
    let obj = Object.assign({}, this.commonDropRes)
    obj.invType = this.invoiceTypeList
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }

  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  ngOnDestroy(): void {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    if (this.splyTypeOvserver)
      this.splyTypeOvserver.unsubscribe();
    if (this.commonObserver)
      this.commonObserver.unsubscribe();
    if (this.rchargeObserver)
      this.rchargeObserver.unsubscribe();
  }
}
