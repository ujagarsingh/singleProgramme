import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CdnurRoutingModule } from './cdnur-routing.module';
import { CdnurComponent } from './cdnur.component';
import { CdnurAddComponent } from './cdnur-add/cdnur-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [CdnurComponent, CdnurAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    CalendarModule,
    CdnurRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    ReactiveComponentLoaderModule.forRoot(),
    SingleModeModule
  ]
})
export class CdnurModule { }
