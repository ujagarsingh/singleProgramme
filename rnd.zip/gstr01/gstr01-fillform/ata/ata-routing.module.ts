import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AtaComponent } from './ata.component';
import { AtaAddComponent } from './ata-add/ata-add.component';

const routes: Routes = [
  {
    path : "",
    component : AtaComponent
  },
  {
    path : "amv",
    component : AtaAddComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AtaRoutingModule { }
