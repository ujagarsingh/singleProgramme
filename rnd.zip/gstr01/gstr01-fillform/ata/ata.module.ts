import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AtaRoutingModule } from './ata-routing.module';
import { AtaComponent } from './ata.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { AtaAddComponent } from './ata-add/ata-add.component';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [AtaComponent, AtaAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,GSTSharedModule,
    AtaRoutingModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class AtaModule { }
