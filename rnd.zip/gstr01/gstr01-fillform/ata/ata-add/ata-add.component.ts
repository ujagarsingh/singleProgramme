import { Component, OnInit } from '@angular/core';
declare var SagGridMP;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-ata-add',
  templateUrl: './ata-add.component.html',
  styleUrls: ['./ata-add.component.scss']
})
export class AtaAddComponent implements OnInit {

  gridData: any;
  gridDynamicObj: any;
  gridSelectedRowData: any = {};

  rowData: any = [ {
    header        : "S.No.",
    field         : "sno",
    width         : "50px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

  }, {
    header        : "Category",
    field         : "category",
    filter        : true,
    width         : "70px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"
  }, {
    header        : "HSN/SAC",
    field         : "hsnSac",
    filter        : true,
    width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

  }, {
    header        : "Item",
    field         : "description",
    filter        : true,
    width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

  }, 
      {
       header        : "Quantity",
       field         : "quantity",
       filter        : true,
       width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

     },
     
     {
       header        : "UQC",
       field         : "uqc",
       filter        : true,
       width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

     },
     {
       header        : "Per Piece Rate",
       field         : "ppr",
       filter        : true,
       width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()"

     },
     
  {
    header        : "Taxable Value",
    field         : "taxableValue",
    filter        : true,
    width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()",
    "total"       : true,
    "total-text"  : ""

  }, {
       header        : "Rate",
       field         : "rate",
       filter        : true,
       width         : "100px",
       "text-align"  : "center",
       "editable"    : true,
       "total"       : false,


     },{
    header : "Differential(%)",
    field : "apptaxrt",
    width : "100px",
    "text-align" : "center",
    "editable" : true,
    "ng-click":"selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()",
    //display : ($scope.Config.differntOption)? "":"none"

  }, {
    header        : "IGST Rate",
    field         : "igstRate",
    filter        : true,
    width         : "130px",
    "editable"    : false,
    "text-align"  : "center",
    "ng-click"    : "selectRow()",
    "ng-dblclick" : "modifyOnDBlClick()",
    "display"     : "none",

  }, {
    header        : "IGST Amount",
    field : "igstAmount",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : "",
    
  }, {
    header : "CGST Rate",
    field : "cgstRate",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "display":"none"

  }, {
    header : "CGST Amount",
    field : "cgstAmount",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : ""
  }, {
    header : "SGST Rate",
    field : "sgstRate",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "display":"none"

  }, {
    header : "SGST Amount",
    field : "sgstAmount",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : ""

  }, {
    header : "Cess Rate",
    field : "cessRate",
    filter : true,
    width : "130px",
    "editable": false,
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()"

  }, {
    header : "Cess Amount",
    field : "cessAmount",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : ""

  }, {
    header : "Total Tax",
    field : "totalTax",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : ""

  },
  {
    header : "Total",
    field : "total",
    filter : true,
    width : "130px",
    "editable": false,
    "text-align" : "center",
    "ng-click":"selectRow()",
    "ng-dblclick":"modifyOnDBlClick()",
    "total" : true,
    "total-text" : ""
  },
   {
         header : "cessRateAmount",
      field : "cessRateAmount",
      "display":"none"
    }, 
    {
      header : "cessQty",
      field : "cessQty",
      "display":"none"
    }, {
      header : "cessCondition",
      field : "cessCondition",
      "display":"none"
    }, {
      header : "cessRateQty",
      field : "cessRateQty",
      "display":"none"
    }, {
      header : "cessPerQty",
      field : "cessPerQty",
      "display":"none"
    }, {
      header : "cessOn",
      field : "cessOn",
      "display":"none"
    }, {
      header : "cessQtyAmount",
      field : "cessQtyAmount",
      "display":"none"
    }, {
      header : "cessType",
      field : "cessType",
      "display":"none"
    }

  ];




  getClientList() {
    let response = [];

    this.gridData = {
      columnDef: this.rowData,
      rowDef: response,

    };

    let sourceDiv = document.getElementById("ata_add_grid");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);
    // });
  }

  constructor() { }

  ngOnInit() {
    this.getClientList();
  }

}
