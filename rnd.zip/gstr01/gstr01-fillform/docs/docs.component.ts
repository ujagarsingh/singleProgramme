import { Component, OnInit } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { CommonDropdownService } from '../../../../services/common-dropdown.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { ValidationService } from 'genmaster/src/master/services/validation.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as _ from "lodash";
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';

declare function success(m);
declare function alerts(m);

declare var SagGridMP;
declare var SagInputText;
declare var SagSelectBox;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-docs',
  templateUrl: './docs.component.html',
  styleUrls: ['./docs.component.scss']
})
export class DocsComponent implements OnInit {
  data_type: string = "single_mode";
  gridData: any;
  gridDynamicObj: any;
  location: ComponentLocation;
  importInputData: {};
  entryMode: boolean = false;
  natureType: any;
  selectedClient: any;
  sub: any;
  summeryTypeFlag: boolean = false;
  disablealert: boolean = true;
  updateButtonShow: boolean = false;

  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }

  dropdownCofigJson = {
    selectedData: {
      formName: 'anx1',
    },
    showHideDropdown: {
      month: true,
      showGetClientBtn: false,
      year: true,
      period: false,
      returnType: false,
      clientList: true,
      gstnList: true
    },
    enableDisableDropdown: {
      month: false,
      year: false,
      period: true,
      returnType: true,
    },
  };
  summerySingleType: boolean = false;
  summeryMultiType: boolean = true;
  detailDataList: any;
  responseData: any;
  gridDynamicObj2: any;
  summeryDisable: boolean = false;
  multiGstDocId: any;
  updateEntryModeButton: boolean = false;
  SummeryGstDocId: any;

  commonDropDownDataChange(data) {

  }

  rowDataDetail: any = [
    {
      header: "S.No.",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      search: true,
      "total": false,
    },
    {
      header: "Nature of Document",
      field: "docName",
      filter: true,
      width: "300px",
      "editable": false,
      search: true,
      "align": "left",
      "total": false,
    },
    {
      header: "S.No From",
      field: "gstrdocFromsno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "total": false,
    },
    {
      header: "S.No To",
      field: "gstrdocTosno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    },
    {
      header: "Total Number",
      field: "gstrdocTotlno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    },
    {
      header: "Cancelled",
      field: "gstrdocCancel",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    },
    {
      header: "Net Issued",
      field: "gstrdocNetissue",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    },
    {
      header: "Doc Id",
      field: "docId",
      filter: true,
      hidden: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    }
  ];

  rowDataSumery: any = [
    {
      header: "S.No.",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      search: true,
      "total": false,
    },
    {
      header: "Nature of Document",
      field: "docName",
      filter: true,
      width: "300px",
      "editable": false,
      search: true,
      "align": "left",
      "total": false,
    },
    {
      header: "S.No From",
      field: "gstrdocFromsno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "total": false,
      "component": "from"
    },
    {
      header: "S.No To",
      field: "gstrdocTosno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "component": "to"
    },
    {
      header: "Total Number",
      field: "gstrdocTotlno",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "component": "total"
    },
    {
      header: "Cancelled",
      field: "gstrdocCancel",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "component": "cancel"
    },
    {
      header: "Net Issued",
      field: "gstrdocNetissue",
      filter: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
      "component": "net"
    },
    {
      header: "Doc Id",
      field: "docId",
      filter: true,
      hidden: true,
      width: "130px",
      "editable": false,
      search: true,
      "align": "center",
    }
  ];



  getClientSingleList(data) {
    let response = data;
    let self = this;

    //response.push(...detailData);
    let from = new SagInputText({}, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["gstrdocFromsno"] = Number(ele.value);
        let to = Number(params["gstrdocTosno"]);
        let from = params["gstrdocFromsno"];
        if (to != 0 && from != 0) {
          if (from > to) {
            params["gstrdocTosno"] = from;
            to = from;
          }
          let total = to - from + 1;
          params["gstrdocTotlno"] = total;
          self.gridDynamicObj.updateRow(prl.rowIndex, params);
        }
      }
    });
    let to = new SagInputText({}, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["gstrdocTosno"] = Number(ele.value);
        let to = params["gstrdocTosno"];
        let from = Number(params["gstrdocFromsno"]);
        if (to != 0 && from != 0) {
          if (from > to) {
            params["gstrdocTosno"] = from;
            to = from;
          }
          let total = to - from + 1;
          params["gstrdocNetissue"] = total;
          params["gstrdocTotlno"] = total;
          params["gstrdocCancel"] = 0;
          self.gridDynamicObj.updateRow(prl.rowIndex, params);
        }
      }
    });
    let total = new SagInputText({ "type": "number" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["gstrdocTotlno"] = Number(ele.value);
        params["gstrdocNetissue"] = params["gstrdocTotlno"] - Number(params["gstrdocCancel"]);
        if (params["gstrdocNetissue"] < 0) {
          params["gstrdocNetissue"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
        console.log("TOTAL Grid", self.gridDynamicObj.getGridData());
      }
    });
    let cancel = new SagInputText({ "type": "number" }, function (ele, prl) {
      ele.onchange = function () {
        let params = prl.rowValue;
        params["gstrdocCancel"] = Number(ele.value);
        params["gstrdocNetissue"] = Number(params["gstrdocTotlno"]) - params["gstrdocCancel"];
        if (params["gstrdocNetissue"] < 0) {
          params["gstrdocNetissue"] = 0;
        }
        self.gridDynamicObj.updateRow(prl.rowIndex, params);
        console.log("CANCEL Grid", self.gridDynamicObj.getGridData());
      }
    });
    let net = new SagInputText({ "type": "number" }, function (ele, params) {
      ele.onchange = function () {

      }
    });
    let components = {
      "from": from,
      "to": to,
      "total": total,
      "cancel": cancel,
      "net": net
    };

    this.gridData = {
      columnDef: this.rowDataSumery,
      components: components,
      rowDef: response,
      gridExportService: this.gridExportService,
      callBack: {
        "onRowClick": function () {
          self.onSingleRowSelectFn();
        },
        "onRowDbleClick": function () {
          //self.dblClickModify();
        }
      }
    };

    let sourceDiv = document.getElementById("gstrone_fillform_docs_single");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);
    let selectedClient = this.shareService.getData("selectedClient");
    //[disabled]="!selectedClient || returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed'" [routerLink]="['../amv']"
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
      this.disableSaveBtn = true;
      this.gridDynamicObj.disableGrid();
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    } else {
      this.gridDynamicObj.enableGrid();
    }
  }
  disableSaveBtn: boolean = false;

  onSingleRowSelectFn() {
    var obj = this.gridDynamicObj.getSeletedRowData();
    this.SummeryGstDocId = obj.gstrdocId;
  }

  totalChange(ele, prl) {
    let self = this;
    let params = prl.rowValue;
    params["gstrdocTotlno"] = Number(ele.value);
    params["gstrdocNetissue"] = params["gstrdocTotlno"] - Number(params["gstrdocCancel"]);
    if (params["gstrdocNetissue"] < 0) {
      params["gstrdocNetissue"] = 0;
    }
    self.gridDynamicObj.updateRow(prl.rowIndex, params);
    console.log("TOTAL Grid", self.gridDynamicObj.getGridData());
  }


  getClientMultiList(data) {
    let self = this;
    let response = data;
    this.gridData = {
      columnDef: this.rowDataDetail,
      rowDef: response,
      gridExportService: this.gridExportService,
      callBack: {
        "onRowClick": function () {
          self.onMultiRowSelectFn();
        },
        "onRowDbleClick": function () {
          //self.dblClickModify();
        }
      }
    };

    let sourceDiv2 = document.getElementById("gstrone_fillform_docs_multi");
    this.gridDynamicObj2 = SagGridMP(sourceDiv2, this.gridData, true, true);
  }

  onMultiRowSelectFn() {
    var obj = this.gridDynamicObj2.getSeletedRowData();
    this.multiGstDocId = obj.gstrdocId;
    this.entryForm.patchValue(obj);
    this.updateEntryModeButton = true;
  }


  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }
  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }

  constructor(private eventEmitter: EventEmitterService,
    private commonService: Gstr01FillformService,
    private shareService: ShareService,
    private fb: FormBuilder,
    private gridExportService: GridExportService,
  ) {
    this.shareService.newEvent();
    this._getAllDataList();
  }

  /**
   * ***************************** Nature Grid *****************************************************
   * 
   */

  _getAllDataList() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");
    this.commonService.getDataThrowGetMethod(`getCommonInvoiceData?mclientId=${selectedClient.mClientId}&yearId=${selectedYear.yearId}&monthId=${selectedMonth.monthId}&gstnCid=${selectedClient.gstnCid}&sectionCode=docs`).subscribe(
      response => {
        if (response['data']) {
          this.responseData = response['data'];
          this.natureType = response['data']['masterDoc'];
          this.detailDataList = response['data']['txnDoc'];
          this.setSummeryData(this.detailDataList);
          this.setDetailData(this.detailDataList);
        } else {
          this.natureType = [];
          alerts('No data found.');
        }
      }
    );
  }

  setDetailData(data) {
    let detailData = [];
    var k = 0;
    for (var i = 0; i < data.length; i++) {
      if ((data[i]["gstrdocFromsno"] != undefined && data[i]["gstrdocFromsno"] != "")
        || (data[i]["gstrdocTosno"] != undefined && data[i]["gstrdocTosno"] != "")
        || (data[i]["gstrdocCancel"] != undefined && data[i]["gstrdocCancel"] != "")
        || (data[i]["gstrdocNetissue"] != undefined && data[i]["gstrdocNetissue"] != "")
        || (data[i]["gstrdocTotlno"] != undefined && data[i]["gstrdocTotlno"] != "")) {
        detailData[k] = data[i];
        for (var j = 0; j < this.natureType.length; j++) {
          if (this.natureType[j].docId == detailData[k].docId) {
            detailData[k].docName = this.natureType[j].docName;
          }
        }
        k++;
      }
    }
    this.getClientMultiList(detailData);
    this.summeryEnable();
  }
  /**
  * ************************** Adding detailDataList to natureType *****************************************************
  * @auther Piyush Kaushik
  */
  setSummeryData(data) {
    this.updateButtonShow = false;
    let SummeryData = data;
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");

    console.log("natureType----------", this.natureType)
    let nature = _.map(this.natureType, o => _.extend({
      "flag": "",
      "gstrdocFromsno": "",
      "formtypeId": "",
      "gstrdocId": "",
      "gstrdocTosno": "",
      "gstrdocCancel": "",
      "gstrdocNetissue": "",
      "gstrdocTotlno": "",
      "gstrdocType": "",
      "mclientId": selectedClient.mClientId,
      "monthId": selectedMonth.monthId,
      "sagclient_id": "",
      "yearId": selectedYear.yearId,
      "gstnCid": selectedClient.gstnCid
    }, o));

    console.log("nature----------", nature)
    nature.forEach((value, key) => {
      let index = _.findIndex(SummeryData, ['docId', value.docId]);
      if (index != -1) {
        nature[key] = SummeryData[index];
        this.updateButtonShow = true;
      }
    });
    console.log("after ForEach------", nature)
    this.getClientSingleList(nature);
  }



  /**
  * ************************** Entry Form *****************************************************
  * @auther Piyush Kaushik
  */

  entryForm: FormGroup = this.fb.group({
    docCode: [''],
    docId: [''],
    docName: [''],
    flag: [''],
    formtypeId: [''],
    gstnCid: [''],
    gstrdocCancel: ['', {
      validators: [Validators.required, ValidationService.onlydigitsValidator]
    }],
    gstrdocFromsno: ['', Validators.required],
    gstrdocId: [''],
    gstrdocNetissue: ['', {
      validators: [Validators.required, ValidationService.onlydigitsValidator]
    }],
    gstrdocTosno: ['', Validators.required],
    gstrdocTotlno: ['', {
      validators: [Validators.required, ValidationService.onlydigitsValidator]
    }],
    gstrdocType: [''],
    mclientId: [''],
    monthId: [''],
    sag_G_Index: [0],
    sagclient_id: [''],
    sno: [''],
    yearId: [''],

  });

  get f() { return this.entryForm.controls; }


  ngOnInit() {
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this._getAllDataList();
      this.entryForm.reset();
      this.updateEntryModeButton = false;
    });
    this.entryForm.valueChanges.subscribe(data => {
      console.log(data);
    })

  }


  ///////////////////validation Methods/////////////////////
  // checkAllBlankValidation(itemslist) {
  //   var checkAllBlankFlag = true;
  //   for (var i = 0; i < itemslist.length; i++) {
  //     var item = itemslist[i];
  //     if ((item["gstrdocFromsno"] == undefined || item["gstrdocFromsno"] == "")
  //       && (item["gstrdocTosno"] == undefined || item["gstrdocTosno"] == "")
  //       && (item["gstrdocCancel"] == undefined || item["gstrdocCancel"] == "")
  //       && (item["gstrdocNetissue"] == undefined || item["gstrdocNetissue"] == "")
  //       && (item["gstrdocTotlno"] == undefined || item["gstrdocTotlno"] == "")) {
  //       checkAllBlankFlag = true;
  //     } else {
  //       checkAllBlankFlag = false;
  //       break;
  //     }
  //   }
  //   return checkAllBlankFlag;
  // }

  checkEmptyValidation(itemslist) {
    var checkEmptyFlag = true;
    for (var i = 0; i < itemslist.length; i++) {
      var item = itemslist[i];
      if (!(item["gstrdocFromsno"] + "" == "")
        && (item["gstrdocTosno"] + "" == "")
        && (item["gstrdocCancel"] + "" == "")
        && (item["gstrdocNetissue"] + "" == "")
        && (item["gstrdocTotlno"] + "" == "")) {
        if ((item["gstrdocFromsno"] + "" == "")
          || (item["gstrdocTosno"] + "" == "")
          || (item["gstrdocCancel"] + "" == "")
          || (item["gstrdocNetissue"] + "" == "")
          || (item["gstrdocTotlno"] + "" == "")) {
          checkEmptyFlag = false;
          break;
        }
      }
    }
    return checkEmptyFlag;
  }
  ////////////////////////////////// Validation Methods end /////////////////////////


  ////////////////////////////////// Save and Update and Delete Methods /////////////////////////


  saveAdvanceTexData() {
    if (this.gridDynamicObj.getGridData().length >= 1) {

      var itemsList = this.gridDynamicObj.getGridData();
      var items = [];
      // if (this.checkAllBlankValidation(itemsList)) {

      //   alerts("Fill Data to Save");
      //   return;
      // }
      // else
      if (this.checkEmptyValidation(itemsList)) {
        for (var i = 0; i < itemsList.length; i++) {
          if (itemsList[i]["gstrdocFromsno"] != undefined && itemsList[i]["gstrdocFromsno"] != "")
            items.push(itemsList[i]);
        }

        let newItems = [];
        for (let obj of items) {
          let newObj = {
            gstrdocId: null,
            mclientId: obj.mclientId,
            gstnC: { gstnId: parseInt(obj.gstnCid) },
            formType: { formtypeId: 1 },
            mstDoc: { docId: obj.docId },
            month: { monthId: obj.monthId },
            year: { yearId: obj.yearId },
            gstrdocType: obj.gstrdocType,
            gstrdocFromsno: parseInt(obj.gstrdocFromsno),
            gstrdocTosno: parseInt(obj.gstrdocTosno),
            gstrdocTotlno: parseInt(obj.gstrdocTotlno),
            gstrdocCancel: parseInt(obj.gstrdocCancel),
            gstrdocNetissue: parseInt(obj.gstrdocNetissue),
            // gstrdocUploadyn: obj.gstrdocUploadyn,
            // gstrdocUploaddt: obj.gstrdocUploaddt,
            sagclientId: obj.sagclient_id,
            flag: obj.flag,
            // createdOn: obj.createdOn,
            // lastUpdatedOn: obj.lastUpdatedOn,
            // gstrdocTmpgstrdocid: obj.gstrdocTmpgstrdocid,
            // gstrdocSessionid: obj.gstrdocSessionid,
          }
          newItems.push(newObj);
        }

        this.commonService.getDataThrowPostMethod("saveDocs/docs", newItems).subscribe(
          response => {
            if (response['data'] == true && response['httpStatus'] == 200) {
              this._getAllDataList();
              success(response['message']);
            } else {
              alerts("Error while Saving Data.")
            }
          }, error => {
            console.log(error);
            console.error('Error while fetching Document Natures');

          });
      }
      else {

        alerts("Please Fill all Required Fields");
      }
    }
  }

  updateSummeryData() {
    if (this.gridDynamicObj.getGridData().length >= 1) {
      var itemslist = this.gridDynamicObj.getGridData();
      var items = [];
      if (this.checkEmptyValidation(itemslist)) {
        for (var i = 0; i < itemslist.length; i++) {
          if (itemslist[i]["gstrdocFromsno"] != undefined && itemslist[i]["gstrdocFromsno"] != "")
            items.push(itemslist[i]);
          else if (itemslist[i]["gstrdocid"] != undefined && itemslist[i]["gstrdocid"] != "" && itemslist[i]["gstrdocid"] != null)
            items.push(itemslist[i]);
        }

        let newItems = [];
        for (let obj of items) {
          let newObj = {
            gstrdocId: obj.gstrdocId ? obj.gstrdocId : null,
            mclientId: obj.mclientId,
            gstnC: { gstnId: parseInt(obj.gstnCid) },
            formType: { formtypeId: 1 },
            mstDoc: { docId: obj.docId },
            month: { monthId: obj.monthId },
            year: { yearId: obj.yearId },
            gstrdocType: obj.gstrdocType,
            gstrdocFromsno: parseInt(obj.gstrdocFromsno),
            gstrdocTosno: parseInt(obj.gstrdocTosno),
            gstrdocTotlno: parseInt(obj.gstrdocTotlno),
            gstrdocCancel: parseInt(obj.gstrdocCancel),
            gstrdocNetissue: parseInt(obj.gstrdocNetissue),
            // gstrdocUploadyn: obj.gstrdocUploadyn,
            // gstrdocUploaddt: obj.gstrdocUploaddt,
            sagclientId: obj.sagclient_id,
            flag: obj.flag,
            // createdOn: obj.createdOn,
            // lastUpdatedOn: obj.lastUpdatedOn,
            // gstrdocTmpgstrdocid: obj.gstrdocTmpgstrdocid,
            // gstrdocSessionid: obj.gstrdocSessionid,
          }
          newItems.push(newObj);
        }

        this.commonService.getDataThrowPostMethod("updateDocs/docs", newItems).subscribe(
          response => {
            if (response['data'] == true && response['httpStatus'] == 200) {
              this._getAllDataList();
              success(response['message']);
            } else {
              alerts("Error while updating Data.")
            }
          }, error => {
            console.log(error);
            console.error('Error while fetching Document Natures');

          });
      }
      else {
        alerts("Please Fill all Required details");
      }
    }
  }

  deleteSummeryRow() {
    let deleteArray = [];
    if (this.SummeryGstDocId < 0) {
      alerts("Please select the row you want to delete!!")
    } else {
      deleteArray.push(this.SummeryGstDocId)
      let conf = confirm("Do you really want to delete this?")
      if (conf == true) {
        this.commonService.getDataThrowPostMethod(`GSTR1/docs/deleteData`, deleteArray).subscribe(
          response => {
            if (response['data'] == true && response['httpStatus'] == 200) {
              this._getAllDataList();
              success(response['message']);
            } else {
              alerts(response['message']);
            }
            this.SummeryGstDocId = -1
          })
      }
    }
  }

  //////////////// ENTRY MODE SAVE DATA ///////////////////

  changeDoc() {
    let id = this.entryForm.get("docId").value;
    for (let i = 0; i < this.natureType.length; i++) {
      if (this.natureType[i].docId == id) {
        this.entryForm.value.docName = this.natureType[i].docName
        this.entryForm.value.docCode = this.natureType[i].docCode
        break;
      }
    }
  }

  calcToFromNum() {
    let to = Number(this.entryForm.get("gstrdocTosno").value);
    let from = Number(this.entryForm.get("gstrdocFromsno").value);
    if (to != 0 && from != 0) {
      if (from > to) {
        this.entryForm.get("gstrdocTosno").patchValue(from);
        to = from;
      }
      let total = to - from + 1;
      this.entryForm.patchValue({
        gstrdocTotlno: total
      });
      this.calcNum();
    }
  }

  calcNum() {
    let total = this.entryForm.get("gstrdocTotlno").value;
    let cancel = this.entryForm.get("gstrdocCancel").value;
    let net = total - cancel;
    if (net < 0) {
      net = 0;
    }
    this.entryForm.patchValue({
      gstrdocNetissue: net
    });
  }

  saveDocs() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    let selectedMonth = this.shareService.getData("month");

    this.entryForm.value.gstnCid = selectedClient.gstnCid
    this.entryForm.value.mclientId = selectedClient.mClientId;
    this.entryForm.value.sno = selectedClient.sno;
    this.entryForm.value.monthId = selectedMonth.monthId
    this.entryForm.value.yearId = selectedYear.yearId

    let saveDataList = [];
    saveDataList.push(this.entryForm.value)

    let newItems = [];
    for (let obj of saveDataList) {
      let newObj = {
        gstrdocId: null,
        mclientId: obj.mclientId,
        gstnC: { gstnId: parseInt(obj.gstnCid) },
        formType: { formtypeId: 1 },
        mstDoc: { docId: obj.docId },
        month: { monthId: obj.monthId },
        year: { yearId: obj.yearId },
        gstrdocType: obj.gstrdocType,
        gstrdocFromsno: parseInt(obj.gstrdocFromsno),
        gstrdocTosno: parseInt(obj.gstrdocTosno),
        gstrdocTotlno: parseInt(obj.gstrdocTotlno),
        gstrdocCancel: parseInt(obj.gstrdocCancel),
        gstrdocNetissue: parseInt(obj.gstrdocNetissue),
        // gstrdocUploadyn: obj.gstrdocUploadyn,
        // gstrdocUploaddt: obj.gstrdocUploaddt,
        sagclientId: obj.sagclient_id,
        flag: obj.flag,
        // createdOn: obj.createdOn,
        // lastUpdatedOn: obj.lastUpdatedOn,
        // gstrdocTmpgstrdocid: obj.gstrdocTmpgstrdocid,
        // gstrdocSessionid: obj.gstrdocSessionid,
      }
      newItems.push(newObj);
    }
    if (this.entryForm.valid) {
      this.commonService.getDataThrowPostMethod("saveDocs/docs", newItems).subscribe(
        response => {
          if (response['data'] == true && response['httpStatus'] == 200) {
            this.entryForm.reset();
            this._getAllDataList();
            success(response['message']);
          } else {
            alerts(response['message']);
          }
        }, error => {
          console.log(error);
          console.error('Error while fetching Document Natures');
        });
    } else {
      alerts("Please Fill the Details first");
    }

  }
  updateDocs() {

    let updateDataList = [];
    updateDataList.push(this.entryForm.value)
    let newItems = [];
    for (let obj of updateDataList) {
      let newObj = {
        gstrdocId: obj.gstrdocId,
        mclientId: obj.mclientId,
        gstnC: { gstnId: parseInt(obj.gstnCid) },
        formType: { formtypeId: 1 },
        mstDoc: { docId: obj.docId },
        month: { monthId: obj.monthId },
        year: { yearId: obj.yearId },
        gstrdocType: obj.gstrdocType,
        gstrdocFromsno: parseInt(obj.gstrdocFromsno),
        gstrdocTosno: parseInt(obj.gstrdocTosno),
        gstrdocTotlno: parseInt(obj.gstrdocTotlno),
        gstrdocCancel: parseInt(obj.gstrdocCancel),
        gstrdocNetissue: parseInt(obj.gstrdocNetissue),
        // gstrdocUploadyn: obj.gstrdocUploadyn,
        // gstrdocUploaddt: obj.gstrdocUploaddt,
        sagclientId: obj.sagclient_id,
        flag: obj.flag,
        // createdOn: obj.createdOn,
        // lastUpdatedOn: obj.lastUpdatedOn,
        // gstrdocTmpgstrdocid: obj.gstrdocTmpgstrdocid,
        // gstrdocSessionid: obj.gstrdocSessionid,
      }
      newItems.push(newObj);
    }
    if (this.entryForm.valid) {
      this.commonService.getDataThrowPostMethod("updateDocs/docs", newItems).subscribe(
        response => {
          if (response['data'] == true && response['httpStatus'] == 200) {
            this.entryForm.reset();
            this._getAllDataList();
            success(response['message']);
            this.updateEntryModeButton = false;
          } else {
            alerts(response['message']);
          }
        }, error => {
          console.log(error);
          console.error('Error while fetching Document Natures');
        });
    } else {
      alerts("Please Fill the Details first");
    }

  }
  /////////////////////// Entry Mode Inside ends////////////////////////


  /////////////////////// multi Mode Methods starts////////////////////////

  deleteMultiRow() {
    let deleteArray = [];
    if (this.multiGstDocId < 0) {
      alerts("Please select the row you want to delete!!")
    } else {
      deleteArray.push(this.multiGstDocId)
      this.commonService.getDataThrowPostMethod(`GSTR1/docs/deleteData`, deleteArray).subscribe(
        response => {
          if (response['data'] == true && response['httpStatus'] == 200) {
            this._getAllDataList();
            this.entryForm.reset();
            success(response['message']);
            this.updateEntryModeButton = false;
          }
          else {
            alerts(response['message']);
          }
          this.multiGstDocId = -1;
        })
    }
  }
  ////////////////////////////////// Save and Update and Delete Methods end /////////////////////////


  //////////////////// Fire on change event of the radio button /////////////////

  changeData(val: any) {
    this.data_type = val.target.value;
    if (this.data_type == "multi_mode") {
      this.summeryMultiType = false;
      this.summerySingleType = true;
    } else {
      this.summerySingleType = false;
      this.summeryMultiType = true;
    }
  }

  ///////////////////////// summery Enanle Disable ////////////////////////////

  summeryEnable() {
    this.summeryTypeFlag = false;
    let data = this.gridDynamicObj2.getGridData();
    var gridlength = data.length;
    if (gridlength > 1) {
      var itemlist = data;
      for (var k = 0; k < itemlist.length; k++) {
        for (var l = k + 1; l < itemlist.length; l++) {
          if (itemlist[l].docName == itemlist[k].docName) {
            this.summeryTypeFlag = true;
            break;
          }

        }

      }
    }
    if (this.summeryTypeFlag == true) {
      this.summeryDisable = true;
      if (this.disablealert == true) {
        alerts("You have multiple Record In Detail for Same Nature So Summery is Disable");
        this.disablealert = false;
        this.data_type = "multi_mode"
        if (this.data_type == "multi_mode") {
          this.summeryMultiType = false;
          this.summerySingleType = true;
        } else {
          this.summerySingleType = false;
          this.summeryMultiType = true;
        }
      }

    } else if (this.summeryTypeFlag == false) {
      this.summeryDisable = false;
      this.disablealert = true;
    }

  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
