import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DocsRoutingModule } from './docs-routing.module';
import { DocsComponent } from './docs.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [DocsComponent],
  imports: [
	LanguageModule,
    CommonModule,SharedModule,
    DocsRoutingModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot(),
    FormsModule,
    ReactiveFormsModule
  ]
})
export class DocsModule { }
