import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CdnraRoutingModule } from './cdnra-routing.module';
import { CdnraComponent } from './cdnra.component';
import { CdnraAddComponent } from './cdnra-add/cdnra-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { CalendarModule } from 'primeng/primeng';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { SingleModeModule } from 'src/gst/models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [CdnraComponent, CdnraAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    SingleModeModule,
    CalendarModule,
    CdnraRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class CdnraModule { }
