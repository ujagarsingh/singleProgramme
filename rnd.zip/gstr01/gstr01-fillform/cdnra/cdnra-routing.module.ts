import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CdnraComponent } from './cdnra.component';
import { CdnraAddComponent } from './cdnra-add/cdnra-add.component';

const routes: Routes = [
  {
    path : "",
    component : CdnraComponent
  },
  {
    path: "amv",
    component: CdnraAddComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CdnraRoutingModule { }
