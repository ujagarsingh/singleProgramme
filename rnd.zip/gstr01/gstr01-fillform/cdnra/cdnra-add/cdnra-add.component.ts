import { Component, OnInit } from '@angular/core';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { Subscription } from 'rxjs';
import { FormControl, Validators } from '@angular/forms';
declare var SagGridMP;
declare function alerts(message);
declare function success(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-cdnra-add',
  templateUrl: './cdnra-add.component.html',
  styleUrls: ['./cdnra-add.component.scss']
})
export class CdnraAddComponent implements OnInit {
  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'searchInvoiceModule',
    selector: 'app-search-invoice'
  };
  selectedDiff: any = null;
  commonFormGroup: any;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [
    { "key": "", "val": "-Select-" },
  ];
  itemArr = [
    { "key": "", "val": "-Select-" },
  ];
  formType = "GSTR1";
  commonDropRes: any = {};

  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };

  
  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, HsnDesc: null,hsnitemId : null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];

  selectedClient: any;
  revChangeList: any;

  gridData: any;
  gridSelectedRowData: any = {};
  hsnCodeAndItem: any;

  constructor(private configurationService: ConfigurationsService, private eventEmitterService: EventEmitterService, public shareService: ShareService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.revChangeList = [{ label: "Yes", value: 'Y' }, { label: "No", value: 'N' }];
    this.manageDateObject();
  }

  overrideValidation() {
    this.commonFormGroup.addControl("invNtnum", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invNtdt", new FormControl(null, Validators.required));
    this.commonFormGroup.controls['sp']['controls']['spId'].setValidators(null);
    this.commonFormGroup.controls['notetype']['controls']['notetypeId'].setValidators([Validators.required]);
    // this.commonFormGroup.addControl("notetypeId", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invNtdt", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invOrigntnum", new FormControl(null, Validators.required));
    this.commonFormGroup.addControl("invOrigntdt", new FormControl(null, Validators.required));
  }
  singleMode = false;

  dateChange(type) {
    // if (this.commonFormGroup.get('invDt').value && this.commonFormGroup.get('invNtdt').value) {
    //   let invDt = (this.commonFormGroup.get('invDt').value).split('/');
    //   let ntdt = (this.commonFormGroup.get('invNtdt').value).split('/');
    //   let d1 = new Date(invDt[2], invDt[1], invDt[0]);
    //   let d2 = new Date(ntdt[2], ntdt[1], ntdt[0]);
    //   if (d1.getTime() > d2.getTime()) {
    //     alerts("Note Date should be Greater Then Invoice Date")
    //     this.commonFormGroup.get(type).patchValue(null);
    //   }
    // }
  }

  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;

  manageDateObject() {
    var obj = this.returnService.manageDateObjects(true);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }

  popupData: any;

  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    if (!this.selectedInvoice)
      this.openSearchPopup();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.overrideValidation();
    this.getCommonDropdownListOnLoad(this.formType);
    this.manageObservables();

  }

  openSearchPopup() {
    this.location = this.importlocation;
    this.popupData = {
      'popupData': {
        'formName': "GSTR1",
        'sectionCode': "cdnr",
        'showYear': true,
        'showMonth': true,
        'showSeller': true,
        'showGstNo': true,
        'showInvoice': true,
        'sellerType': "Receiver",
        'showCrDr': true,
      }
    };
    this.eventEmitterService.loadSearchInvoicePopup();
  }
  flag = false;
  onKeywordsChange = (data) => {
    this.flag = true;
    if (data && data.invId)
      this.manageSelectedInvoice(data, this.commonFormGroup);
    // this.selectedDiff = data.apptaxrt ? Number(data.apptaxrt) : null;
    // this.commonFormGroup.patchValue({
    //   spId: data.SpId,
    //   invRefinvid: data.Id,
    //   invNo: data.OrignalInvoiceNo,
    //   invOriginvno: data.OrignalInvoiceNo,
    //   invOriginvdt: data.OrignalInvoiceDate,
    //   invDt: data.OrignalInvoiceDate,
    //   invVal: data.InvoiceValue,
    //   invTxval: data.TaxableValue,
    //   invtypeId: this.fillformService.getSelectedValue(this.invoiceTypeList, 'invtypeCode', data.invtypeCode)['invtypeId'],
    //   invOrigntdt: data.OriginalNoteDate,
    //   invOrigntnum: data.OriginalNoteNo,
    //   invNtdt: data.OriginalNoteDate,
    //   invNtnum: data.OriginalNoteNo,
    //   notetypeId: data.noteTypeId,
    // });
    this.commonFormGroup.get('invOriginvno').disable();
    this.commonFormGroup.get('invOriginvdt').disable();
    this.commonFormGroup.get('invOrigntdt').disable();
    this.commonFormGroup.get('invOrigntnum').disable();
    // this.getInvoiceItemList();
  }

  // getInvoiceItemList() {
  //   this.returnService.getInvoiceItemList(this.commonFormGroup.get("invRefinvid").value).subscribe(data => {
  //     if (data["httpStatus"] == 200) {
  //       for (var i = 0; i < data["data"].length; i++) {
  //         let obj = data["data"][i];
  //         obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
  //       }
  //       this.addGrid(data["data"]);
  //     } else
  //       this.addGrid([]);
  //     this.sellerChange();
  //     this.invoiceTypeChange();
  //   });
  // }



  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.splyTypeOvserver = this.commonFormGroup.get("splytype.splytypeId").valueChanges.subscribe(data => {
    });
    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else if (this.selectedInvoice && this.selectedInvoice.amvType == 'view') {
          this.gridDynamicObj.disableAllRow();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });
    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });
  }


  configuredData: any;
  getCommonDropdownListOnLoad(formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfCdnrAmend");
      var requstobj = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category", "noteType"], "docTypeParams": "R" };
      this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
        if (res["httpStatus"] == 200) {
          this.commonDropRes = res["data"];
          this.setGridDropdownOnLoad();
        }
        this.getSellerList();
      });
    });

  }
  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          this.getHSNSummary();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo != null)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
        }
      });
  }
  hsnCodeList: any;
  hsnDesList : any;
  completeHsnList : any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.getInvTypeAndRevChrgsList();
      })
  }

  callFillDataAccordingSupplyTypeMethod = true;
  selectedInvoice: any;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (this.flag) {
          data["data"]["invRefinvid"] = data["data"]["invId"];
          data["data"]["invId"] = null;
          this.flag = false;
        }
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitemApptaxrt"];
        data["data"]["montho"]["monthId"] = data["data"]["month"]["monthId"];
        data["data"]["yearo"]["yearId"] = data["data"]["year"]["yearId"];
        data["data"]["stateO"]["stateId"] = data["data"]["state"]["stateId"];
        data["data"]["invOriginvno"] = data["data"]["invNo"];
        data["data"]["invOriginvdt"] = data["data"]["invDt"];
        data["data"]["invOrigntdt"] = data["data"]["invNtdt"];
        data["data"]["invOrigntnum"] = data["data"]["invNtnum"];
        data["data"]["notetype"]["notetypeId"] = data["data"]["notetype"]["notetypeId"];
        delete data["data"]["txnInvitemData"];
        formGroup.patchValue(data["data"]);
        formGroup.patchValue({
          section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'cdnra')["secId"] },
          year: { yearId: this.shareService.getData("year")["yearId"] },
          month: { monthId: this.shareService.getData("month")["monthId"] }
        })
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        this.callFillDataAccordingSupplyTypeMethod = false;
        this.sellerChange('pos');
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }

  differentialChange() {
    this.onFormGroupChangeFireGridEvent();
  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts("invoice No already exist In this financial Year");
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }

  revChangePerList: any;
  invoiceTypeList: any = [];
  getInvTypeAndRevChrgsList() {
    this.fillformService.getInvTypeAndRevChrgsList().subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (data["data"] && data["data"]["invTypes"]) {
          for (const obj of data["data"]["invTypes"]) {
            if (obj["sectionId"] == this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2b')['secId'])
              this.invoiceTypeList.push(obj);
          }
        }
        if (data["data"] && data["data"]["revCharges"])
          this.revChangePerList = data["data"]["revCharges"];
      }
      if (this.selectedInvoice) {
        this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
        this.shareService.removeData("selectedInvoice");
        if (this.selectedInvoice.amvType == "view") {
          this.commonFormGroup.disable();
          this.gridDynamicObj.disableAllRow();
        }
      } else {
        this.addGrid(this.gridRowData);
        this.gridDynamicObj.disableAllRow();
      }
    });
  }

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue({
      section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'cdnra')["secId"] },
    });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
    // this.addGrid(this.gridRowData);
    // this.gridDynamicObj.disableAllRow();
  }

  addGrid(data) {
    var gridData = {
      columnDef: this.fillformService.getColumns("cdnra", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("cdnra_add_grid"), gridData, true, true);
  }

  enabledisableAllRowCell(index, gridObj) {
    let obj = gridObj.getRowData(index);
    obj["invitemTaxamt"] != null && !isNaN(obj["invitemTaxamt"]) && parseFloat(obj["invitemTaxamt"]) != 0 ? gridObj.enableCell(index, "rate") : gridObj.disableCell(index, "rate");
  }

  onFormGroupChangeFireGridEvent() {
    let arr = this.gridDynamicObj.getGridData();
    if (arr.length > 0) {
      for (let index = 0; index < arr.length; index++) {
        const obj = arr[index];
        this.fillformService.commonMethods(this, index, obj);
      }
    }
  }

  ntNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkNoteNo(this.commonFormGroup.get("invNtnum").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"]).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts(data["message"]);
            this.commonFormGroup.patchValue({ invNtnum: null })
          }
        });
    }
  }

  supplyTypeCode: any;
  sellerChange(type) {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("sp").value["spId"], "spId");
    let fullState = this.commonFormGroup.get("state").value["stateId"] ? this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateId', this.commonFormGroup.get("state").value["stateId"]) :
      this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', data.gstnNo.substr(0, 2));
    for (const obj of this.commonDropRes.supplyType) {
      if (obj.supplyCode == "INTRA" && this.selectedClient.gstNo.substr(0, 2) === fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: {splytypeId : obj.supplyId} })
      } else if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: {splytypeId : obj.supplyId} })
      }
    }
    if (data){
      if(type == "seller"){
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: (data.stateId != null && data.stateId != 0) ? data.stateId : fullState.stateId } });
      }else{
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: fullState.stateId  } });
      }
    }
    this.onFormGroupChangeFireGridEvent();
    this.invoiceTypeChange();
  }

  selectedInvoiceType: any = { invtypeCode: "R" };
  invoiceTypeChange() {
    var data = this.returnService.getSelectedObject(this.invoiceTypeList, this.commonFormGroup.get("invtype.invtypeId").value, "invtypeCode");
    if (!data)
      data = this.returnService.getSelectedObject(this.invoiceTypeList, this.commonFormGroup.get("invtype.invtypeId").value, "invtypeId");
    this.selectedInvoiceType = data ? data : this.selectedInvoiceType;
    this.commonFormGroup.patchValue({ invtype: { invtypeId: this.selectedInvoiceType ? this.selectedInvoiceType.invtypeId : null } });
    this.fillformService.invoiceTypeChange(this.commonFormGroup, this.selectedInvoiceType, this.gridDynamicObj, this.supplyTypeCode, this.selectedInvoice, this.selectedDiff, this.callFillDataAccordingSupplyTypeMethod);
  }


  saveCdnra() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    var items = this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      var obj = this.commonFormGroup.getRawValue();
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      obj.invPrsyn = obj.invPrsyn ? 'Y' : 'N';
      this.fillformService.saveInvoice(obj, 'cdnra').subscribe(data => {
        if (data["httpStatus"] == 200) {
          success(data["message"]);
          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null, invNtdt: null, invNtnum: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }
  }


  ngOnDestroy() {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    this.splyTypeOvserver.unsubscribe();
    this.commonObserver.unsubscribe();
    this.rchargeObserver.unsubscribe();
  }
}
