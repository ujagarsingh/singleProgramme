import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2csaComponent } from './b2csa.component';
import { B2csaAddComponent } from './b2csa-add/b2csa-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2csaComponent
  },{
    path : 'amv',
    component : B2csaAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2csaRoutingModule { }
