import { Component, OnInit, OnDestroy } from '@angular/core';
declare var SagGridMP;
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Gstr01FillformService } from '../gstr01-fillform.service';
import { Subscription } from 'rxjs';
declare function success(message);
declare function alerts(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2csa',
  templateUrl: './b2csa.component.html',
  styleUrls: ['./b2csa.component.scss']
})
export class B2csaComponent implements OnInit, OnDestroy {

  location: ComponentLocation;
  importInputData: {};

  remarkLocation: ComponentLocation = {
    moduleId: 'RemarkModule',
    selector: 'app-remark'
  }

  EntryModeLocation: ComponentLocation = {
    moduleId: 'entryModeModule',
    selector: 'app-entry-mode'
  }
  entryMode: boolean = false;

  loadRemarkModule() {
    this.location = this.remarkLocation;
    this.eventEmitter.loadImportForm();
  }

  data_type: string = "asPerReturn";
  gridData: any;
  gridDynamicObj: any;
  sourceDiv: any;

  selectedClient: any;
  sub: Subscription;
  constructor(private eventEmitter: EventEmitterService, public router: Router, public activeRoute: ActivatedRoute,
    private returnService: RetrunService, private fillformService: Gstr01FillformService, private shareService: ShareService) {
    shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.sub = this.shareService.selectedDropDown.subscribe(selectedData => {
      this.selectedClient = selectedData ? selectedData["selectedClient"] : null;
      this.changeData();
    });
  }

  ngOnInit() {
    this.changeData();
  }
  compareModelLocation: ComponentLocation = {
    moduleId: 'compareModule',
    selector: 'app-compare'
  }

  loadCompareModule() {
    this.location = this.compareModelLocation;
    this.eventEmitter.loadImportForm();
  }
  gridId: any = "gstrone_fillform_b2csa";
  asPerReturnSub: Subscription;
  invoiceSub: Subscription;
  findEntryModeOpen: boolean = false;
  popupData = { "popupData": { case: "amendment", formtype: "GSTR1", sectionCode: 'b2csa', show: true, gridObj: this.gridDynamicObj, AmendmentSectionCode: 'b2cs' } };
  changeData() {
    if (this.data_type === "invoiceWise") {
      this.popupData = { "popupData": { case: "amendment", formtype: "GSTR1", sectionCode: 'b2csa', show: false, gridObj: this.gridDynamicObj, AmendmentSectionCode: 'b2cs' } };
      this.findEntryModeOpen = false;
      let obj = {
        formType: 'GSTR1',
        yearId: this.shareService.getData("year")["yearId"],
        monthId: this.shareService.getData("month")["monthId"],
        mClientId: this.shareService.getData("selectedClient")["mClientId"],
        gstnCid: this.shareService.getData("selectedClient")["gstnCid"],
        sectionName: "b2cs"
      };

      this.invoiceSub = this.returnService._getAllInvoiceDetails(obj).subscribe(data => {
        if (data["httpStatus"] == 200) {
          this.gridDynamicObj = this.fillformService.commonDetailGrid(data["data"], this.gridId, this);
        }
      });
    } else {
      let obj = {
        "gstnCid": this.shareService.getData("selectedClient")["gstnCid"],
        "posId": "",
        "yearId": this.shareService.getData("year")["yearId"],
        "monthId": this.shareService.getData("month")["monthId"],
        "ayearId": this.shareService.getData("year")["yearId"],
        "amonthId": this.shareService.getData("month")["monthId"],
        "mclientId": this.shareService.getData("selectedClient")["mClientId"] + "",
        "section": "b2csa",
        "ammendedSection": "b2csa",
        "formType": "GSTR1"
      }
      this.asPerReturnSub = this.returnService.getAmendInvoice(obj).subscribe(data => {
        if (data["httpStatus"] == 200) {
          data['data'].forEach(element => { element.rate = Number(element.cgstRate) + Number(element.sgstRate) + Number(element.igstRate); });
          this.gridDynamicObj = this.fillformService.commonAmendmentAsPerReturnGrid(data["data"], this.gridId, this);
          if (this.findEntryModeOpen) {
            this.eventEmitter.loadEntryModePopup(this.gridDynamicObj);
          }
        }
      });

    }
  }

  //grid callbacks start
  onRowDbleClickDetail() {
    this.fillformService.modifyInvoice(this.gridDynamicObj, this.activeRoute, 'amv', 'modify')
  }
  onRowSelect() {
    this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
  }
  //grid callbacks end

  selectedInvoice: any;
  onAsPerReturnRowSelect() {
    if (this.findEntryModeOpen && this.data_type === "asPerReturn") {
      this.openEntryModePopup();
    } else {
      this.selectedInvoice = this.gridDynamicObj.getSeletedRowData();
    }
  }

  onKeywordsChange = (data) => {
    if (data == "back") {
      this.findEntryModeOpen = false;
      this.entryMode = false;
    }
    this.changeData();
  }

  openEntryModePopup() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    this.findEntryModeOpen = true;
    var selectedInvoice = this.gridDynamicObj.getSeletedRowData();
    if (selectedInvoice) {
      let res = { completeData: [], selectedData: this.getEmitableObject(selectedInvoice) };
      let completeData = this.gridDynamicObj.getGridData();
      for (let index = 0; index < completeData.length; index++) {
        const obj = completeData[index];
        if (obj.stateId == selectedInvoice.stateId) {
          res['completeData'].push(this.getEmitableObject(obj));
        }
      }
      this.shareService.setData("selectedInvoiceEntryMode", this.getEmitableObject(selectedInvoice));
      this.shareService.setData('entryModePosGridData', res);
    } else {
      this.shareService.removeData('entryModePosGridData');
      this.shareService.removeData("selectedInvoiceEntryMode");
    }
    this.popupData = { "popupData": { case: "amendment", formtype: "GSTR1", sectionCode: 'b2csa', show: true, gridObj: this.gridDynamicObj, AmendmentSectionCode: 'b2cs' } };
    this.location = this.EntryModeLocation;
    this.eventEmitter.loadEntryModePopup(this.gridDynamicObj);
  }

  getEmitableObject(obj) {
    return {
      invitemApptaxrt: Number(obj.apptaxrt),
      invitemTaxamt: Number(obj.TaxAmount),
      invitemIrt: Number(obj.igstRate),
      invitemIamt: parseFloat(obj.Iamt) == 0 ? null : obj.Iamt,
      invitemCrt: Number(obj.cgstRate),
      invitemCamt: parseFloat(obj.Camt) == 0 ? null : obj.Camt,
      invitemSrt: Number(obj.sgstRate),
      invitemSamt: parseFloat(obj.Samt) == 0 ? null : obj.Samt,
      invitemCsrt: parseFloat(obj.csrt) == 0 ? null : obj.csrt,
      invitemCsamt: parseFloat(obj.CSamt) == 0 ? null : obj.CSamt,
      rate: parseFloat(obj.igstRate || 0) + parseFloat(obj.cgstRate || 0) + parseFloat(obj.sgstRate || 0),
      invitemTotltax: parseFloat(Math.abs((Number(obj.invVal) - Number(obj.TaxAmount))).toFixed(this.fillformService.roundOffBy)),
      invitemTotlval: Number(obj.invVal),
      stateName: obj.stateName,
      stateId: obj.stateId,
      invId: obj.invId,
      orgstateName: obj.orgstateName,
      originalMonth: obj.monthid ? parseInt(obj.monthid) : obj.originalMonth,
      originalYear: obj.yearOid ? parseInt(obj.yearOid) : obj.originalYear,
      stateoId: obj.stateoId,
      invRefId: obj.itemRef,
      amdeId: obj.amdeId
    }
  }

  deleteSelectedInvoice() {
    let selectedClient = this.shareService.getData("selectedClient");
    if (selectedClient.returnStatus.toLowerCase() == 'filed' || selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    let checkedInvoices = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    let invIds = [];
    if (checkedInvoices.length > 0) {
      let conf = confirm("Are you sure you want to delete this?")
      if (conf == true) {
        checkedInvoices.forEach(element => { invIds.push(element.invId); });
        this.fillformService.getDataThrowPostMethod(`GSTR1/b2csa/deleteData`, invIds).subscribe(data => {
          if (data["httpStatus"] == 200) {
            success("Invoices Deleted Successfully");
            this.changeData();
          }
        });
      }
    } else {
      alerts("Please Select at least an Invoice to Delete");
    }
  }

  ngOnDestroy(): void {
    if (this.asPerReturnSub) this.asPerReturnSub.unsubscribe();
    if (this.invoiceSub) this.invoiceSub.unsubscribe();
    if (this.sub) this.sub.unsubscribe();
    this.shareService.removeData("selectedInvoiceEntryMode");
  }
}