import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { B2csaRoutingModule } from './b2csa-routing.module';
import { B2csaComponent } from './b2csa.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { B2csaAddComponent } from './b2csa-add/b2csa-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [B2csaComponent, B2csaAddComponent],
  imports: [
  	LanguageModule,
    CommonModule, SharedModule,
    B2csaRoutingModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class B2csaModule { }
