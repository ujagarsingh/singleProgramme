import { Component, OnInit } from '@angular/core';
declare var SagGridMP;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2csa-add',
  templateUrl: './b2csa-add.component.html',
  styleUrls: ['./b2csa-add.component.scss']
})
export class B2csaAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
