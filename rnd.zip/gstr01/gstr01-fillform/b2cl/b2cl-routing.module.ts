import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2clComponent } from './b2cl.component';
import { B2clAddComponent } from './b2cl-add/b2cl-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2clComponent
  },
  {
    path: "amv",
    component: B2clAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2clRoutingModule { }
