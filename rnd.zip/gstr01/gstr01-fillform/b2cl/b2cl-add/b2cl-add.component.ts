import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
declare const $;
declare var SagGridMP;
declare function alerts(message);
declare function success(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2cl-add',
  templateUrl: './b2cl-add.component.html',
  styleUrls: ['./b2cl-add.component.scss']
})
export class B2clAddComponent implements OnInit {


  selectedDiff: any = null;
  commonFormGroup: any;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [{ "key": "", "val": "-Select-" }];
  itemArr = [{ "key": "", "val": "-Select-" }];
  formType = "GSTR1";
  commonDropRes: any = {};
  commonDropReq = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category"], "docTypeParams": "R" };
  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };
  selectedClient: any;
  revChangeList: any;
  selectedInvoice: any;
  hsnCodeAndItem: any;
  constructor(private shareService: ShareService, private eventEmitterService: EventEmitterService, private configurationService: ConfigurationsService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.manageDateObject();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    this.revChangeList = [{ label: "Yes", value: 'Y' }, { label: "No", value: 'N' }];
  }

  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;
  manageDateObject() {
    var obj = this.returnService.manageDateObjects(false);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }

  configuredData: any;
  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.overrideValidation();
    this.getCommonDropdownListOnLoad(this.commonDropReq, this.formType);
    this.manageObservables();
  }

  hsnCodeList: any;
  hsnDesList : any;
  completeHsnList : any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.getInvTypeAndRevChrgsList();
      })
  }

  callFillDataAccordingSupplyTypeMethod = true;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitemApptaxrt"];
        delete data["data"]["txnInvitemData"];
        formGroup.setValue(data["data"]);
        formGroup.patchValue({
          section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2cl')["secId"] },
          year: { yearId: this.shareService.getData("year")["yearId"] },
          month: { monthId: this.shareService.getData("month")["monthId"] }
        })
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        this.callFillDataAccordingSupplyTypeMethod = false;
        this.sellerChange('pos');
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }


  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.splyTypeOvserver = this.commonFormGroup.get("splytype.splytypeId").valueChanges.subscribe(data => {
    });
    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else if (this.selectedInvoice && this.selectedInvoice.amvType == 'view') {
          this.gridDynamicObj.disableAllRow();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });
    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });
  }

  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];

  differentialChange() {
    var arr = this.gridDynamicObj.getGridData();
    for (let index = 0; index < arr.length; index++) {
      const obj = arr[index];
      this.fillformService.commonMethods(this, index, obj);
    }
  }

  overrideValidation() {
    this.commonFormGroup.controls['sp']['controls']['spId'].setValidators(null);
  }

  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'sellerModule',
    selector: 'app-return-seller-form'
  };

  openSellerModal() {
    this.location = this.importlocation;
    $("#sellerModal").modal("show");
  }

  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          this.getHSNSummary();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo == null && obj.stateId != this.selectedClient.stateId)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
        }
      });
  }

  selectedInvoiceType = {
    invtypeCode: null
  }
  invoiceTypeChange() {
    this.fillformService.invoiceTypeChange(this.commonFormGroup, this.selectedInvoiceType, this.gridDynamicObj, this.supplyTypeCode, this.selectedInvoice, this.selectedDiff, this.callFillDataAccordingSupplyTypeMethod);
  }

  onFormGroupChangeFireGridEvent() {
    let arr = this.gridDynamicObj.getGridData();
    if (arr.length > 0) {
      for (let index = 0; index < arr.length; index++) {
        const obj = arr[index];
        this.fillformService.commonMethods(this, index, obj);
      }
    }
  }

  supplyTypeCode: any;
  sellerChange(type) {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("sp").value['spId'], "spId");
    let fullState = this.commonFormGroup.get("state").value['stateId'] ? this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateId', this.commonFormGroup.get("state").value['stateId']) :
      this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', data.stateCode);
    for (const obj of this.commonDropRes.supplyType) {
       if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
      }
    }
    if (data){
      if(type == "seller"){
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: (data.stateId != null && data.stateId != 0) ? data.stateId : fullState.stateId } });
      }else{
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: fullState.stateId  } });
      }
    }
    this.onFormGroupChangeFireGridEvent();
    this.invoiceTypeChange();
  }

  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts(data["message"]);
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }

  revChangePerList: any;
  invoiceTypeList: any = [];
  getInvTypeAndRevChrgsList() {
    this.fillformService.getInvTypeAndRevChrgsList().subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (data["data"] && data["data"]["invTypes"]) {
          for (const obj of data["data"]["invTypes"]) {
            this.invoiceTypeList.push(obj);
          }
        }
        if (data["data"] && data["data"]["revCharges"])
          this.revChangePerList = data["data"]["revCharges"];
      }
      if (this.selectedInvoice) {
        if (this.selectedInvoice.amvType == "view") {
          this.commonFormGroup.disable();
        }
        this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
        this.shareService.removeData("selectedInvoice");
      } else {
        this.addGrid(this.gridRowData);
        this.gridDynamicObj.disableAllRow();
      }
    });
  }

  saveB2CL() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
      return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
    }
    var items = this.singleMode ? [this.amtFormGroupData] : this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      var obj = this.commonFormGroup.value;
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      if (this.commonFormGroup.get('invVal').value < 250000) {
        return alerts('Invoice Value Should be Greater then 250000');
      }
      this.fillformService.saveInvoice(obj, 'b2cl').subscribe(data => {
        if (data["httpStatus"] == 200) {
          success(data["message"]);
          this.singleMode = false;

          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }

  }

  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  popupData: any;
  popupDataSingle: {};

  singleModeO() {
    let obj = Object.assign({}, this.commonDropRes)
    obj.invType = this.invoiceTypeList;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }
  singleMode: boolean = false;
  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  /**
   * get common dropdown list
   */
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      if (data["data"]) {
        this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfB2cl");
        this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
          if (res["httpStatus"] == 200) {
            this.commonDropRes = res["data"];
            this.setGridDropdownOnLoad();
          }
          this.getSellerList();
        });
      }
    });
  }

  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue(
      { section: { sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2cl')["secId"] } ,
        splytype: { splytypeId: this.fillformService.getSelectedValue(this.commonDropRes.supplyType, 'supplyCode', 'INTER')["supplyId"] }
    });
    
      this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
  }

  addGrid(data) {

    var gridData = {
      columnDef: this.fillformService.getColumns("b2cl", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("gstrone_b2clAdd"), gridData, true, true);
  }

  ngOnDestroy() {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    if (this.splyTypeOvserver)
      this.splyTypeOvserver.unsubscribe();
    if (this.commonObserver)
      this.commonObserver.unsubscribe();
    if (this.rchargeObserver)
      this.rchargeObserver.unsubscribe();
  }

}
