import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { B2clRoutingModule } from './b2cl-routing.module';
import { B2clComponent } from './b2cl.component';
import { B2clAddComponent } from './b2cl-add/b2cl-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { SingleModeModule } from 'src/gst/models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [B2clComponent, B2clAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    B2clRoutingModule,
    SingleModeModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    CalendarModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class B2clModule { }
