import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExpaComponent } from './expa.component';
import { ExpaAddComponent } from './expa-add/expa-add.component';

const routes: Routes = [
  {
    path : "",
    component : ExpaComponent
  },
  {
    path : "amv",
    component : ExpaAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExpaRoutingModule { }
