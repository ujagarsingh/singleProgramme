import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExpaRoutingModule } from './expa-routing.module';
import { ExpaComponent } from './expa.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { SharedModule, CalendarModule, DropdownModule } from 'primeng/primeng';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { ExpaAddComponent } from './expa-add/expa-add.component';
import { SingleModeModule } from '../../../../models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [ExpaComponent, ExpaAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,
    ExpaRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    CalendarModule,
    DropdownModule,
    SingleModeModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class ExpaModule { }
