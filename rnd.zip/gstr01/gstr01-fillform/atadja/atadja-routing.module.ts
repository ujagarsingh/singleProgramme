import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AtadjaComponent } from './atadja.component';

const routes: Routes = [
  {
    path : "",
    component : AtadjaComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AtadjaRoutingModule { }
