import { Component, OnInit } from '@angular/core';

declare var SagGridMP;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-atadja-add',
  templateUrl: './atadja-add.component.html',
  styleUrls: ['./atadja-add.component.scss']
})
export class AtadjaAddComponent implements OnInit {
  gridData: any;
  gridDynamicObj: any;
  gridSelectedRowData: any = {};

  rowData: any = [];




  getClientList() {
    let response = [];

    this.gridData = {
      columnDef: this.rowData,
      rowDef: response,

    };

    let sourceDiv = document.getElementById("atadja_add_add");
    this.gridDynamicObj = SagGridMP(sourceDiv, this.gridData, true, true);
    // });
  }

  constructor() { }

  ngOnInit() {
    this.getClientList();
  }

}
