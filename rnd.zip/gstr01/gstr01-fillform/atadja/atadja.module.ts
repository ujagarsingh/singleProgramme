import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AtadjaRoutingModule } from './atadja-routing.module';
import { AtadjaComponent } from './atadja.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { AtadjaAddComponent } from './atadja-add/atadja-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [AtadjaComponent, AtadjaAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,
    AtadjaRoutingModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class AtadjaModule { }
