import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExempComponent } from './exemp.component';

const routes: Routes = [
  {
    path : "",
    component : ExempComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExempRoutingModule { }
