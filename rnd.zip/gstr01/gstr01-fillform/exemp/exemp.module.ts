import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExempRoutingModule } from './exemp-routing.module';
import { ExempComponent } from './exemp.component';
import { SharedModule } from 'genmaster/src/master/shared/shared.module';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [ExempComponent],
  imports: [
  	LanguageModule,
    CommonModule,SharedModule,
    ExempRoutingModule,SharedModule,
    GSTSharedModule,
    ReactiveComponentLoaderModule.forRoot()
  ]
})
export class ExempModule { }
