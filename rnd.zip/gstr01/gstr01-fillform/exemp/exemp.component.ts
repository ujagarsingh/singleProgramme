import { Component, OnInit } from '@angular/core';
import { ExempService } from './exemp.service';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Gstr01FillformService } from '../gstr01-fillform.service';
declare var SagGridMP;
declare function success(m);
declare function alerts(m);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  templateUrl: './exemp.component.html',
  styleUrls: ['./exemp.component.scss']
})
export class ExempComponent implements OnInit {
  data_type: string = "2";
  selectedType: string = 'summary';

  gridData: any;
  gridDynamicObj: any;

  exempForm: FormGroup;
  tableitems: FormArray;

  totalNilRtAmt: Number = 0;
  totalExmtAmt: Number = 0;
  totalNgsAmt: Number = 0;

  sub: Subscription;
  exempSub: Subscription;

  selectedClient: any;
  constructor(private service: ExempService, public fillformService: Gstr01FillformService, private router: Router, private activeRouter: ActivatedRoute, public location: Location, private shareService: ShareService, private formBuilder: FormBuilder) {
    shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
  }
  commonDropReq = { "reqList": ["supplyType"] };

  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.exempForm = this.formBuilder.group({
      items: this.formBuilder.array([this.createTableItem(1), this.createTableItem(1), this.createTableItem(2), this.createTableItem(2)])
    });

    this.exempSub = this.exempForm.get("items").valueChanges.subscribe(data => {
      let array = this.exempForm.value && this.exempForm.value["items"] ? this.exempForm.value["items"] : undefined;
      if (array) {
        this.totalNilRtAmt = Number(array[0].nilrtAmt) + Number(array[1].nilrtAmt) + Number(array[2].nilrtAmt) + Number(array[3].nilrtAmt);
        this.totalExmtAmt = Number(array[0].nilrtExptamt) + Number(array[1].nilrtExptamt) + Number(array[2].nilrtExptamt) + Number(array[3].nilrtExptamt);
        this.totalNgsAmt = Number(array[0].nilrtNgsupamt) + Number(array[1].nilrtNgsupamt) + Number(array[2].nilrtNgsupamt) + Number(array[3].nilrtNgsupamt);
      }
    });
    this.getCommonDropdownListOnLoad(this.commonDropReq, "GSTR1");
  }

  supplyTypeList: any;
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
      if (res["httpStatus"] == 200) {
        this.supplyTypeList = res["data"]["supplyType"];
        this.getExempData();
      }
    });
  }

  saveOrUpdate = "Save";
  getExempData() {
    if (this.selectedClient && this.shareService.getData("year") && this.shareService.getData("month")) {
      this.service.getExempData(this.selectedClient.mClientId, this.selectedClient.gstnCid,
        this.shareService.getData("month")["monthId"], this.shareService.getData("year")["yearId"], 'NIL').subscribe(data => {
          if (data["httpStatus"] === 200) {
            if (data["data"].length > 0) {
              this.saveOrUpdate = "Update";
              let array = data["data"]
              this.exempForm.patchValue({ items: array });
              this.totalNilRtAmt = Number(array[0].nilrtAmt) + Number(array[1].nilrtAmt) + Number(array[2].nilrtAmt) + Number(array[3].nilrtAmt);
              this.totalExmtAmt = Number(array[0].nilrtExptamt) + Number(array[1].nilrtExptamt) + Number(array[2].nilrtExptamt) + Number(array[3].nilrtExptamt);
              this.totalNgsAmt = Number(array[0].nilrtNgsupamt) + Number(array[1].nilrtNgsupamt) + Number(array[2].nilrtNgsupamt) + Number(array[3].nilrtNgsupamt);
            }
          }
        });
    }
  }

  createTableItem(index): FormGroup {
    return this.formBuilder.group({
      nilrtId: [null],
      mclientId: [this.selectedClient.mClientId],
      gstnC:{gstnId: parseInt(this.selectedClient.gstnCid)},
      invId: [null],
      splytype:{splytypeId: null},
      nilrtCamt: [0],
      nilrtAmt: [0],
      nilrtExptamt: [0],
      nilrtNgsupamt: [0],
      year: {yearId: this.shareService.getData("year")["yearId"]},
      month:{monthId: this.shareService.getData("month")["monthId"]},
      section:{sectionId: 9},
      formType:{formtypeId: 1},
      nilrtUploaddt: [null],
      nilrtApprovalyn: [null],
      nilrtApprovaldt: [null],
      sagclientId: [null],
      flag: [null],
      createdOn: [null],
      lastUpdatedOn: [null],
      nilrtTmpnilrtid: [null],
      nilrtSessionid: [null],
      nilrtType: [null]
    });
  }

  saveExemp() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
		}
    let arr = this.exempForm.value.items;
    arr.forEach((element, index) => {
      element.nilrtType = index == 0 || index == 2 ? "R" : "C";
      element.splytype['splytypeId'] = this.fillformService.getSelectedValue(this.supplyTypeList, "supplyCode", index + 1 > 2 ? "INTER" : "INTRA")["supplyId"];
    });
    this.service.saveExempData(arr, "GSTR1").subscribe(data => {
      if (data["httpStatus"] === 200) {
        success(data["message"]);
        this.ngOnInit();
      } else {
        alerts(data["message"]);
      }
    });
  }

  ngOnDestroy() {
    this.exempSub.unsubscribe();
  }
}
