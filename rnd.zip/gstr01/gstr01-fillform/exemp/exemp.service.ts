import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { masterCommonConstant } from 'genmaster/src/master/constant/masterCommonConstant';

@Injectable({
  providedIn: 'root'
})
export class ExempService {
  returnUrl : string;
  constructor(public http : HttpClient) {
    this.returnUrl = masterCommonConstant.gstReturnBaseUrl;
   }
  
  saveExempData(data, formType){
    return this.http.post(`${this.returnUrl}/${formType}/saveNillData`,data);
  }
  getExempData(mclientId,gstnCid,monthId,yearId,sectionCode){
    return this.http.get(`${this.returnUrl}/getCommonInvoiceData?mclientId=${mclientId}&gstnCid=${gstnCid}&monthId=${monthId}&yearId=${yearId}&sectionCode=${sectionCode}`);
  }
}
