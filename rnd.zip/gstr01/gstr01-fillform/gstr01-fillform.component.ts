import { Component, OnInit } from '@angular/core';
import { NavigationError, NavigationEnd, NavigationStart, Router, Event, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ShareService } from 'genmaster/src/master/services/share.service';
declare function alerts(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-gstr01-fillform',
  templateUrl: './gstr01-fillform.component.html',
  styleUrls: ['./gstr01-fillform.component.scss']
})
export class Gstr01FillformComponent implements OnInit {
  selectedSubTab: String;
  subscription: Subscription;

  dropdownCofigJson = {
    selectedData: {
      formName: 'gstr1',
    },
    showHideDropdown: {
      month: true,
      showGetClientBtn: false,
      year: true,
      period: false,
      returnType: false,
      clientList: true,
      gstnList: true
    },
    enableDisableDropdown: {
      month: false,
      year: false,
      period: true,
      returnType: true,
    },
  };
  commonDropDownDataChange(data) {
    
  }
  hideCommonDropDown : boolean = false;
  constructor(private router: Router, private active: ActivatedRoute,private shareService: ShareService) {
    this.subscription = this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        let selectedClient = this.shareService.getData("selectedClient");
        if(!selectedClient){
          return this.router.navigate(["/gst/return/GSTR1/client"]);
        }
        // if(selectedClient.returnStatus.toLowerCase() == "filed" || selectedClient.returnStatus.toLowerCase() == "completed"){
        //   alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
        // }
        this.hideCommonDropDown = event.urlAfterRedirects.endsWith("amv") || event.urlAfterRedirects.includes("efile")?true:false;
        if(event.urlAfterRedirects == "/gst/return/GSTR1/fillform"){
          this.selectedSubTab = 'subTab1';
          this.router.navigate(["all"], { relativeTo: this.active });
          return;
        }else if(event.urlAfterRedirects === "/gst/return/GSTR1/fillform/all"){
          this.selectedSubTab = "subTab1";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2b") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2b/amv")){
          this.selectedSubTab = "subTab2";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2ba") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2ba/amv")){
          this.selectedSubTab = "subTab3";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cl") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cl/amv") ){
          this.selectedSubTab = "subTab4";
          return;
        } else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cla") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cla/amv")){
          this.selectedSubTab = "subTab5";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnr")|| event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnr/amv")){
          this.selectedSubTab = "subTab6";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnra")|| event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnra/amv")){
          this.selectedSubTab = "subTab7";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnur") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnur/amv")){
          this.selectedSubTab = "subTab8";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnura") || event.urlAfterRedirects==("/gst/return/GSTR1/fillform/cdnura/amv")){
          this.selectedSubTab = "subTab9";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/exp") ||event.urlAfterRedirects==("/gst/return/GSTR1/fillform/exp/amv") ){
          this.selectedSubTab = "subTab10";
          return;
        }  else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/expa") ||event.urlAfterRedirects==("/gst/return/GSTR1/fillform/expa/amv") ){
          this.selectedSubTab = "subTab11";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cs") ||  event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2cs/amv")){
          this.selectedSubTab = "subTab12";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/b2csa")){
          this.selectedSubTab = "subTab13";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/exemp")){
          this.selectedSubTab = "subTab14";
          return;
        } else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/at")|| event.urlAfterRedirects==("/gst/return/GSTR1/fillform/at/amv")){
          this.selectedSubTab = "subTab15";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/ata")){
          this.selectedSubTab = "subTab16";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/atadj")){
          this.selectedSubTab = "subTab17";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/atadja")){
          this.selectedSubTab = "subTab18";
          return;
        } else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/hsn")){
          this.selectedSubTab = "subTab19";
          return;
        }else if(event.urlAfterRedirects==("/gst/return/GSTR1/fillform/docs")){
          this.selectedSubTab = "subTab20";
          return;
        } 
      } 
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
