import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { B2claRoutingModule } from './b2cla-routing.module';
import { B2claComponent } from './b2cla.component';
import { B2claAddComponent } from './b2cla-add/b2cla-add.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { CalendarModule } from 'primeng/primeng';
import { Gstr01FillformSharedModule } from '../gstr01-fillform-shared/gstr01-fillform-shared.module';
import { SingleModeModule } from 'src/gst/models/single-mode/single-mode.module';
import { LanguageModule } from 'src/master/shared/language.module';


@NgModule({
  declarations: [B2claComponent, B2claAddComponent],
  imports: [
  	LanguageModule,
    CommonModule,
    CalendarModule,
    SingleModeModule,
    B2claRoutingModule,
    GSTSharedModule,
    Gstr01FillformSharedModule,
    ReactiveComponentLoaderModule.forRoot()

  ]
})
export class B2claModule { }
