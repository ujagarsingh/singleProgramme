import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { B2claComponent } from './b2cla.component';
import { B2claAddComponent } from './b2cla-add/b2cla-add.component';

const routes: Routes = [
  {
    path : "",
    component : B2claComponent
  },
  {
    path: "amv",
    component: B2claAddComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class B2claRoutingModule { }
