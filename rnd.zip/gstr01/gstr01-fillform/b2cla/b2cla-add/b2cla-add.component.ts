import { Component, OnInit } from '@angular/core';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { RetrunService } from 'src/gst/return/retrun.service';
import { Gstr01FillformService } from '../../gstr01-fillform.service';
import { SellerService } from 'genmaster/src/master/return-seller/seller.service';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Subscription } from 'rxjs';
import { ConfigurationsService } from 'src/gst/return/configuration/configurations.service';
declare const $;
declare var SagGridMP;
declare function alerts(message);
declare function success(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-b2cla-add',
  templateUrl: './b2cla-add.component.html',
  styleUrls: ['./b2cla-add.component.scss']
})
export class B2claAddComponent implements OnInit {
  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'searchInvoiceModule',
    selector: 'app-search-invoice'
  };
  selectedDiff: any = null;
  commonFormGroup: any;
  gridDynamicObj: any;
  selectCategory: any;
  hsnsacArr = [
    { "key": "", "val": "-Select-" },
  ];
  itemArr = [
    { "key": "", "val": "-Select-" },
  ];
  formType = "GSTR1";
  commonDropRes: any = {};

  configJson: any = {
    "upload": "", "approved": "", "status": ""
  };

  gridRowData = [{
    "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
    "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
    "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
  }];

  selectedClient: any;
  revChangeList: any;

  gridData: any;
  gridSelectedRowData: any = {};
  selectedInvoice: any;
  hsnCodeAndItem: any;
  constructor(private configurationService: ConfigurationsService, private eventEmitterService: EventEmitterService, public shareService: ShareService, public returnService: RetrunService, public fillformService: Gstr01FillformService, private sellerService: SellerService) {
    this.shareService.newEvent();
    this.selectedClient = this.shareService.getData("selectedClient");
    this.manageDateObject();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    this.revChangeList = [{ label: "Yes", value: 'Y' }, { label: "No", value: 'N' }];
  }

  overrideValidation() {
    this.commonFormGroup.controls['sp']['controls']['spId'].setValidators(null);
  }

  sellerLocation: ComponentLocation = {
    moduleId: 'sellerModule',
    selector: 'app-return-seller-form'
  };
  openSellerModal() {
    this.location = this.sellerLocation;
    $("#sellerModal").modal("show");
  }


  minDateValue: Date;
  maxDateValue: Date;
  yearRange: any;
  defaultDate: Date;
  showMonthNavigator: boolean = false;
  showYearNavigator: boolean = false;
  manageDateObject() {
    var obj = this.returnService.manageDateObjects(true);
    this.defaultDate = obj.defaultDate;
    this.minDateValue = obj.minDateValue;
    this.maxDateValue = obj.maxDateValue;
    this.yearRange = obj.yearRange;
    this.showMonthNavigator = obj.showMonthNavigator;
    this.showYearNavigator = obj.showYearNavigator;
  }
  commonDropReq = { "reqList": ["sec", "state", "diffRate", "supplyType", "rate", "uqc", "category"], "docTypeParams": "R" };
  popupData: any;
  ngOnInit() {
    if (!this.selectedClient)
      this.fillformService.exit();
    this.selectedInvoice = this.shareService.getData("selectedInvoice");
    if (!this.selectedInvoice)
      this.openSearchPopup();
    this.commonFormGroup = this.fillformService.getFromGroup();
    this.overrideValidation();
    this.getCommonDropdownListOnLoad(this.commonDropReq, this.formType);
    this.manageObservables();

  }

  openSearchPopup() {
    this.location = this.importlocation;
    this.popupData = {
      'popupData': {
        'formName': "GSTR1",
        'sectionCode': "b2cl",
        'showYear': true,
        'showMonth': true,
        'showSeller': true,
        'showGstNo': true,
        'showInvoice': true,
        'sellerType': "Receiver",
        'showInvNo': true,
      }
    };
    this.eventEmitterService.loadSearchInvoicePopup();
  }

  flag = false;
  onKeywordsChange = (data) => {
    this.flag = true;
    this.manageSelectedInvoice(data, this.commonFormGroup);
    // this.selectedDiff = data.apptaxrt ? Number(data.apptaxrt) : null;
    // this.commonFormGroup.patchValue({
    //   spId: data.SpId,
    //   invRefinvid: data.Id,
    //   invNo: data.OrignalInvoiceNo,
    //   invOriginvno: data.OrignalInvoiceNo,
    //   invOriginvdt: data.OrignalInvoiceDate,
    //   invDt: data.OrignalInvoiceDate,
    //   invVal: data.InvoiceValue,
    //   invTxval: data.TaxableValue,
    //   invType: this.getSelectedObject(this.invoiceTypeList, "invtypeCode", data.Type)
    // });
    this.commonFormGroup.get("invNo").disable()
    this.commonFormGroup.get("invDt").disable()
    //this.getInvoiceItemList();
  }

  // getInvoiceItemList() {
  //   this.returnService.getInvoiceItemList(this.commonFormGroup.get("invRefinvid").value).subscribe(data => {
  //     if (data["httpStatus"] == 200) {
  //       console.log(data["data"]);
  //       for (var i = 0; i < data["data"].length; i++) {
  //         let obj = data["data"][i];
  //         obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
  //       }
  //       this.addGrid(data["data"]);
  //     } else
  //       this.addGrid([]);
  //     this.sellerChange();
  //     this.invoiceTypeChange();
  //   });
  // }

  getSelectedObject(arr, key, selectedData) {
    for (let index = 0; index < arr.length; index++) {
      const obj = arr[index];
      if (obj[key] == selectedData) {
        return obj;
      }
    }
  }

  splyTypeOvserver: Subscription;
  commonObserver: Subscription;
  rchargeObserver: Subscription;
  manageObservables() {
    this.commonObserver = this.commonFormGroup.valueChanges.subscribe(data => {
      if (this.gridDynamicObj) {
        if (this.commonFormGroup.status == "INVALID") {
          this.gridDynamicObj.disableAllRow();
        } else if (this.selectedInvoice && this.selectedInvoice.amvType == 'view') {
          this.gridDynamicObj.disableAllRow();
        } else {
          this.gridDynamicObj.enableAllRow();
        }
      }
    });
    this.rchargeObserver = this.commonFormGroup.get("invRchrgyn").valueChanges.subscribe(data => {
      data === "Y" ? this.commonFormGroup.get("invRchrg").enable() : this.commonFormGroup.get("invRchrg").disable();
    });
  }

  differentialChange() {
    this.onFormGroupChangeFireGridEvent();
  }

  onFormGroupChangeFireGridEvent() {
    let arr = this.gridDynamicObj.getGridData();
    if (arr.length > 0) {
      for (let index = 0; index < arr.length; index++) {
        const obj = arr[index];
        this.fillformService.commonMethods(this, index, obj);
      }
    }
  }

  configuredData: any;
  getCommonDropdownListOnLoad(requstobj: any, formType: any) {
    this.configurationService._getConfigurationsDetails("GSTR1").subscribe(data => {
      if (data["data"]) {
        this.configuredData = this.fillformService.getParticularAndSectionData(data["data"], "gstrconfB2clAmend");
        this.shareService.getCommonDropdownList(requstobj, formType).subscribe(res => {
          if (res["httpStatus"] == 200) {
            this.commonDropRes = res["data"];
            this.setGridDropdownOnLoad();
          }
          this.getSellerList();
        });
      }
    });
  }
  sellerList: any = [];
  getSellerList() {
    this.sellerService.getSupplierReceiver(this.shareService.getData("year")["yearId"],
      this.selectedClient.clientid, this.selectedClient.gstnCid, "R", false, null, null).subscribe(data => {
        if (data["sellers"]) {
          this.getHSNSummary();
          for (const obj of data["sellers"]) {
            if (obj.gstnNo == null && obj.stateId != this.selectedClient.stateId)
              this.sellerList.push(obj);
          }
          this.shareService.setData("sellerList", data["sellers"]);
        }
      });
  }

  revChangePerList: any;
  invoiceTypeList: any = [];
  getInvTypeAndRevChrgsList() {
    this.fillformService.getInvTypeAndRevChrgsList().subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (data["data"] && data["data"]["invTypes"]) {
          for (const obj of data["data"]["invTypes"]) {
            if (obj["sectionId"] == this.commonFormGroup.get("section.sectionId").value)
              this.invoiceTypeList.push(obj);
          }
        }
        if (data["data"] && data["data"]["revCharges"])
          this.revChangePerList = data["data"]["revCharges"];
      }
      if (this.selectedInvoice) {
        if (this.selectedInvoice.amvType == "view") {
          this.commonFormGroup.disable();
        }
        this.manageSelectedInvoice(this.selectedInvoice, this.commonFormGroup);
        this.shareService.removeData("selectedInvoice");
      } else {
        this.addGrid(this.gridRowData);
        this.gridDynamicObj.disableAllRow();
      }
    });
  }

  hsnCodeList: any;
  hsnDesList : any;
  completeHsnList : any;
  getHSNSummary() {
    let selectedClient = this.shareService.getData("selectedClient");
    let selectedYear = this.shareService.getData("year");
    this.fillformService.getDataThrowGetMethod(`getHSNSummary?clientID=${selectedClient.clientid}&yearId=${selectedYear.yearId}`).subscribe(
      (response: any) => {
        this.completeHsnList = response;
        this.hsnCodeList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "hsnCode", false);
        this.hsnDesList = this.fillformService.commonMethodForGridSelectBox(response, "hsnItemId", "description", false);
        this.getInvTypeAndRevChrgsList();
      })
  }
  callFillDataAccordingSupplyTypeMethod = true;
  manageSelectedInvoice(selectedInvoice, formGroup) {
    this.returnService.getInvoiceItemList(selectedInvoice.invId).subscribe(data => {
      if (data["httpStatus"] == 200) {
        if (this.flag) {
          data["data"]["invRefinvid"] = data["data"]["invId"];
          data["data"]["invId"] = null;
          this.flag = false;
        }
        this.gridRowData = data["data"]["txnInvitemData"];
        this.selectedDiff = data["data"]["txnInvitemData"][0]["invitemApptaxrt"];
        delete data["data"]["txnInvitemData"];
        data["data"]["montho"]["monthId"] = data["data"]["month"]["monthId"];
        data["data"]["yearo"]["yearId"] = data["data"]["year"]["yearId"];
        data["data"]["stateO"]["stateId"] = data["data"]["state"]["stateId"];
        data["data"]["invOriginvno"] = data["data"]["invNo"];
        data["data"]["invOriginvdt"] = data["data"]["invDt"];
        formGroup.patchValue(data["data"]);
        formGroup.patchValue({
          section: {sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2cla')["secId"]},
          year : {yearId: this.shareService.getData("year")["yearId"]},
          month: {monthId: this.shareService.getData("month")["monthId"]}
        })
        this.gridRowData.forEach(obj => {
          obj.rate = obj.invitemIrt != null ? obj.invitemIrt : obj.invitemCrt + obj.invitemSrt;
        });
        this.addGrid(this.gridRowData);
        this.callFillDataAccordingSupplyTypeMethod = false;
        this.sellerChange('pos');
        this.invoiceTypeChange();
        this.callFillDataAccordingSupplyTypeMethod = true;
      }
    });
  }
  categoryArr: any = [];
  uqcArr: any = [];
  rateArr: any = [];
  differentialArr: any = [];
  setGridDropdownOnLoad() {
    this.commonFormGroup.patchValue({
      section : {sectionId: this.fillformService.getSelectedValue(this.commonDropRes.sec, 'secCode', 'b2cla')["secId"]},
      splytype: { splytypeId: this.fillformService.getSelectedValue(this.commonDropRes.supplyType, 'supplyCode', 'INTER')["supplyId"] },
    });
    this.categoryArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.category, "catId", "catName", false);
    this.uqcArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.uqc, "uqcId", "uqcName", false);
    this.rateArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.rate, "rateTax", "rateTax", true);
    this.differentialArr = this.fillformService.commonMethodForGridSelectBox(this.commonDropRes.differential, "diffRate", "diffRate", true);
    // this.addGrid([this.gridRowData]);
    // this.gridDynamicObj.disableAllRow();
  }
  addGrid(data) {

    var gridData = {
      columnDef: this.fillformService.getColumns("b2b", this.configuredData),
      components: this.fillformService.getGridComponent(this),
      showTotal: true,
      disableAllSearch: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      rowDef: data
    };
    this.gridDynamicObj = SagGridMP(document.getElementById("gstrone_b2cla_Add"), gridData, true, true);
  }

  enabledisableAllRowCell(index, gridObj) {
    let obj = gridObj.getRowData(index);
    obj["invitemTaxamt"] != null && !isNaN(obj["invitemTaxamt"]) && parseFloat(obj["invitemTaxamt"]) != 0 ? gridObj.enableCell(index, "rate") : gridObj.disableCell(index, "rate");
  }




  supplyTypeCode: any;
  sellerChange(type) {
    let data = this.returnService.getSelectedObject(this.sellerList, this.commonFormGroup.get("sp").value['spId'], "spId");
    let fullState = this.commonFormGroup.get("state").value['stateId'] ? this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateId', this.commonFormGroup.get("state").value['stateId']) :
      this.fillformService.getSelectedValue(this.commonDropRes.state, 'stateCode', data.stateCode);
    for (const obj of this.commonDropRes.supplyType) {
       if (obj.supplyCode == "INTER" && this.selectedClient.gstNo.substr(0, 2) != fullState['stateCode']) {
        this.supplyTypeCode = obj.supplyCode;
        this.commonFormGroup.patchValue({ splytype: { splytypeId: obj.supplyId } })
      }
    }
    if (data){
      if(type == "seller"){
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: (data.stateId != null && data.stateId != 0) ? data.stateId : fullState.stateId } });
      }else{
        this.commonFormGroup.patchValue({ sp:{spId: data.spId}, gstn:{gstnId : data.gstnId} ,state:{stateId: fullState.stateId  } });
      }
    }
    this.onFormGroupChangeFireGridEvent();
    this.invoiceTypeChange();
  }

  invoiceTypeChange() {
    this.fillformService.invoiceTypeChange(this.commonFormGroup, this.selectedInvoiceType, this.gridDynamicObj, this.supplyTypeCode, this.selectedInvoice, this.selectedDiff, this.callFillDataAccordingSupplyTypeMethod);
  }
  selectedInvoiceType: any = { invtypeCode: 'R' };

  ///////////////////SINGLE MODE STARTS///////////////////////////////
  amtFormGroupData: any;
  popupDataSingle: {};

  singleModeO() {
    let obj = Object.assign({}, this.commonDropRes)
    obj.invType = this.invoiceTypeList;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: obj,
        show: true
      }
    }
    return this.popupData;
  }

  openSingleModePopup() {
    this.singleModeO()
    this.eventEmitterService.loadSingleModePopup();
  }
  singleMode: boolean = false;
  closeSingleMode() {
    this.singleMode = false;
    this.popupData = {
      popupData: {
        commonFormGroup: this.commonFormGroup,
        commonDropRes: this.commonDropRes,
        show: false
      }
    }
  }

  onKeywordsChangeSingle(data) {
    this.amtFormGroupData = data;
  }

  ///////////////////SINGLE MODE ENDS///////////////////////////////

  saveB2CLA() {
    if (this.selectedClient.returnStatus.toLowerCase() == 'filed' || this.selectedClient.returnStatus.toLowerCase() == 'completed') {
			return alerts("Client Return Status is Completed Or Filed..<br> You are not allowed to ADD or MODIFY invoices");
		}
    var items = this.singleMode ? [this.amtFormGroupData] : this.gridDynamicObj.getGridData();
    if (this.fillformService.validateGridData(items, this.selectedInvoiceType, this.supplyTypeCode)) {
      this.fillformService.removeUnwantedKeysFromGridData(items);
      var obj = this.commonFormGroup.getRawValue();
      if (this.selectedDiff)
        items.forEach(element => {
          element.invitemApptaxrt = this.selectedDiff;
        });
      obj["txnInvitemData"] = items;
      this.fillformService.saveInvoice(obj, 'b2cl').subscribe(data => {
        if (data["httpStatus"] == 200) {
          success(data["message"]);
          this.singleMode = false;

          this.commonFormGroup.patchValue({ invVal: 0, invTxval: 0, invNo: null });
          this.selectedDiff = null;
          this.addGrid([{
            "sno": null, "catId": null, "itemId": null, "item": null, "invitemQty": null, "msrmntId": null, "invitemRate": null, "invitemTaxamt": null,
            "rate": null, "invitemApptaxrt": null, "invitemIrt": null, "invitemIamt": null, "invitemCrt": null, "invitemCamt": null, "invitemSrt": null,
            "invitemSamt": null, "invitemCsrt": null, "invitemCsamt": null, "invitemTotltax": null, "invitemTotlval": null,
          }]);
        } else {
          alerts(data["details"]);
        }
      });
      console.log(obj);
    }
  }
  
  invNoChange() {
    if (this.commonFormGroup.get("invOriginvno").value != this.commonFormGroup.get("invNo").value) {
      this.fillformService.checkInvoiceNo(this.commonFormGroup.get("invNo").value, this.shareService.getData("selectedClient").mClientId,
        this.shareService.getData("year")["yearId"], this.commonFormGroup.get("invDt").value).subscribe(data => {
          if (data["httpStatus"] == 200 && data["data"] == false) {
            alerts(data["message"]);
            this.commonFormGroup.patchValue({ invNo: null })
          }
        });
    }
  }

  ngOnDestroy() {
    this.shareService.removeData('selectedInvoice');
    this.selectedInvoice = undefined;
    if (this.splyTypeOvserver)
      this.splyTypeOvserver.unsubscribe();
    if (this.commonObserver)
      this.commonObserver.unsubscribe();
    if (this.rchargeObserver)
      this.rchargeObserver.unsubscribe();
  }

}
