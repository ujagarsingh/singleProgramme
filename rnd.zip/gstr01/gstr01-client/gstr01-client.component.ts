import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Gstr01ClientService } from './gstr01-client.service';
import * as sagCommonGstConstant from '../../../gstCommonConstant';
import { ComponentLocation } from '@wishtack/reactive-component-loader';
import { ShareService } from 'genmaster/src/master/services/share.service';
import { EventEmitterService } from 'genmaster/src/master/services/event-emitter.service';
import { Gstr01CommonService } from '../gstr01-common.service';
import { PerviewService } from '../perview.service';
import { Subscription } from 'rxjs';
import { element } from 'protractor';
import { GridExportService } from 'genmaster/src/master/services/gridExport.service';
declare var SagGridMP;
declare var SagInputText;
declare const $;
declare function alerts(message);
declare function success(message);
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-gstr01-client',
  templateUrl: './gstr01-client.component.html',
  styleUrls: ['./gstr01-client.component.scss']
})
export class Gstr01ClientComponent implements OnInit {

  clientListGridObject: any;
  clientListColumn: any;
  selectedClientData: any;
  selectedLoginFor: any;
  dropdownCofigJson = {
    selectedData: { formName: 'gstr1' },
    showPeriod : ["All","Monthly","Quarterly"],
    showHideDropdown: { showGetClientBtn: false, month: true, year: true, period: true, returnType: false, clientList: false, gstnList: false },
    enableDisableDropdown: { month: false, year: false, period: false, returnType: false }
  }
  fillingStatus = [
    { statusName: 'Pending', checked: false },
    { statusName: 'Complete', checked: false },
    { statusName: 'Submit', checked: false },
    { statusName: 'Filed', checked: false },
    { statusName: 'Blank', checked: false }
  ]

  constructor(private clientService: Gstr01ClientService, private gstr01CommonService: Gstr01CommonService,
    private previewService: PerviewService, private shareService: ShareService,
    private eventEmitterService: EventEmitterService,private gridExportService: GridExportService) {
    this.clientListColumn = sagCommonGstConstant.sagGstCommonConstant.anxClientListColumn;
  }
  
  ngOnInit() {
  }

  checkBoxChange(type) {
    if (type == "all") {
      this.monthList.forEach(element => { element.checked = this.selectAllMonth });
    } else {
      this.selectAllMonth = true;
      this.monthList.forEach(element => {
        if (!element.checked)
          this.selectAllMonth = false;
      });
    }
  }

  selectAllFillingStatus: boolean = false;
  fillingStatusChange(type) {
    if (type == "all") {
      this.fillingStatus.forEach(element => { element.checked = this.selectAllFillingStatus });
    } else {
      this.selectAllFillingStatus = true;
      this.fillingStatus.forEach(element => {
        if (!element.checked)
          this.selectAllFillingStatus = false;
      });
    }
  }

  commonDropdownData: any;
  getReturnStatusFromPortal() {
    if (this.clientListGridObject.getCheckedDataParticularColumnWise().length > 0) {
      this.commonDropdownData = this.shareService.getData("commonDropdownData");
      this.selectedYear = this.shareService.getData("year")['yearId'];
      this.getMonthList();
      this.selectAllMonth = false;
      $("#returnStatusModal").modal("show");
    } else {
      alerts("Please Select A client");
    }
  }

  sub: Subscription;
  rtnEmit = new EventEmitter<any>();
  message: any;
  startDownloadingReturnStatus() {
    let fillingStatusIsValid = false;
    this.message = "";
    for (let index = 0; index < this.fillingStatus.length; index++) {
      const element = this.fillingStatus[index];
      if (element.checked) {
        fillingStatusIsValid = true;
        break;
      }
    }
    let checkedMonth = [];
    for (let index = 0; index < this.monthList.length; index++) {
      const element = this.monthList[index];
      if (element.checked) {
        checkedMonth.push(element);
      }
    }
    if (!fillingStatusIsValid) {
      return alerts("Please Select Status ..!");
    } else if (checkedMonth.length == 0) {
      return alerts("Please Select Month ..!");
    }

    this.checkedClient = this.clientListGridObject.getCheckedDataParticularColumnWise();
    this.checkedClient.forEach(element => {
      element.monthList = [...checkedMonth];
    });
    this.login(this.checkedClient);
  }

  checkedClient: any;
  private login(checkedClient) {
    $("#returnStatusModal").modal("hide");
    if (checkedClient.length > 0) {
      this.popupData = {
        formInfo: {
          selectedClient: checkedClient[checkedClient.length - 1],
          formName: 'GSTR1'
        }
      }
      this.location = this.importlocation;
      this.eventEmitterService.loadCaptchePopup();
    } else if(this.message!=""){
      success(this.message);
    }
  }


  selectAllMonth: boolean = false;
  selectedYear: any;
  monthList: any = [];
  getMonthList() {
    if (this.commonDropdownData && this.commonDropdownData.Years)
      for (var i = 0; i < this.commonDropdownData.Years.length; i++) {
        let obj = this.commonDropdownData.Years[i];
        if (obj.yearId == this.selectedYear) {
          var periodArr = obj.period;
          for (var j = 0; j < periodArr.length; j++) {
            let period = periodArr[j];
            if (period.periodName == this.shareService.getData("period")["periodName"]) {
              var rtTypeArr = period.returnType;
              for (var k = 0; k < rtTypeArr.length; k++) {
                let rtType = rtTypeArr[k];
                if (rtType.rtnCode == this.shareService.getData("returnType")["rtnCode"]) {
                  this.monthList = [];
                  rtType.months.forEach(element => {
                    if (element.monthId <= 19) {
                      let month = Object.assign(element, element);
                      month.checked = false;
                      this.monthList.push(month);
                    }
                  });
                }
              }
            }
          }
        }
      }
  }

  onRowSelectFn() {
    let selectedRow = this.clientListGridObject.getSeletedRowData();
    if (selectedRow) {
      sessionStorage.setItem("selectedClient", JSON.stringify(selectedRow));
      this.shareService.setData('selectedClient', selectedRow);
    }
  }

  
  getRtnPeriod(yearName, month) {
    month = month+"";
    if(month.length<2 && !month.startsWith(0)){
      month =  "0"+month;
    }
    let yearArr = yearName.split('-');
    if (month > 3 && month < 13) {
      return month + yearArr[0];
    } else if(month > 0 && month < 4){
      return  month + yearArr[1];
    }else if(month==13){
      return "06" + yearArr[0];
    }else if(month==14){
      return "09" + yearArr[0];
    }else if(month==15){
      return "12" + yearArr[0];
    }else if(month==16){
      return "03" + yearArr[1];
    }
  }

  loggedInChange = (data) => {
    if (data != "close") {
      if (this.selectedLoginFor == "preview") {
        this.startDowloadingPreview();
      } else if (this.selectedLoginFor == "returnStatus") {
        this.getStatusFormPortal();
      }
    } else {
      if (this.selectedLoginFor == "returnStatus") {
        this.checkedClient.pop();
        this.login(this.checkedClient);
      }
    }

  }

  getStatusFormPortal() {
    if (this.checkedClient.length > 0) {
      let element = this.checkedClient[this.checkedClient.length - 1];
      if (element.monthList.length > 0) {
        let requestObject = {
          returnPrd: this.getRtnPeriod(this.shareService.getData('year')['yearName'], element.monthList[element.monthList.length - 1]['monthId']),
          gstnNo: element["gstNo"],
          mClientId: element["mClientId"],
          yearId: this.selectedYear,
          gstnId: element["gstnCid"],
          monthId: element.monthList[element.monthList.length - 1]["monthId"]
        };
        this.gstr01CommonService.___getReturnStatusFromPortal(requestObject).subscribe(
          (res: any) => {
            if (res) {
              let resStatus = res.success ? "Downloaded Successfully" : "Error While Downloading";
              this.message = this.message + " <br>  Client : " + element.clientName + " <br> Month : " + element.monthList[element.monthList.length - 1]['month'] + " <br> Status : " + resStatus;
            }
            element.monthList.pop();
            this.getStatusFormPortal();
          });
      } else {
        this.checkedClient.pop();
        this.login(this.checkedClient);
      }
    }
  }


  startDowloadingPreview() {
    let month = this.shareService.getData('month')['monthId'];
    this.gstr01CommonService.getGstr1AllSummary({
      rtn_prd: this.getRtnPeriod(this.shareService.getData('year')["yearName"], month),
      rtn_typ: 'GSTR1'
    }).subscribe(data => {
      //if (data['gstr1FormDetails'] && data['gstr1FormDetails'].status == 1 && data['gstr1TurnOver'] && data['gstr1TurnOver'].status == 1) {
        this.shareService.setData("rtnPreiod",this.getRtnPeriod(this.shareService.getData('year')["yearName"], month));  
      this.previewService.getJSONAndGenratePdf(data);
      // } else {
      //   let error;
      //   if (data['gstr1FormDetails'] && data['gstr1FormDetails'].status == 0) {
      //     error = data['gstr1FormDetails'].error.message;
      //   } else if (data['gstr1TurnOver'] && data['gstr1TurnOver'].status == 0) {
      //     error = data['gstr1TurnOver'].error.message;
      //   }
      //   alerts(error)
      // }
    });
  }

  rowsData: any;
  commonDropDownDataChange(data) {
    const self = this;
    let turnOver = new SagInputText({ "type": "number" }, function(){
    })

    let component = {
      turnOver: turnOver
    }
    if (data.completeData) {
      this.rowsData = data['completeData'];
      const selectedRow = data['selectedClient'];
      let gridData = {
        columnDef: this.clientListColumn,
        rowDef: this.rowsData,
        components: component,
        callBack: {
          'onRowClick': function () {
            self.onRowSelectFn();
          }
        },
        gridExportService : this.gridExportService,
      };
      const sourceDiv = document.getElementById('gstr01ClientListGrid');
      this.clientListGridObject = SagGridMP(sourceDiv, gridData, true, true);
      if (selectedRow) {
        for (let i = 0; i < this.rowsData.length; i++) {
          const element = this.rowsData[i];
          if (element.mClientId === selectedRow.mClientId && element.gstnCid === selectedRow.gstnCid) {
            this.clientListGridObject.setRowSelected(i);
            return;
          }
        }
      }
    }
  }

  location: ComponentLocation;
  importlocation: ComponentLocation = {
    moduleId: 'gstnOnlineModule',
    selector: 'app-gstn-online-login'
  };

  popupData: any;
  openGstnPop() {
    let selectedClient = this.clientListGridObject.getSeletedRowData();
    if (selectedClient) {
      this.popupData = {
        formInfo: {
          selectedClient: selectedClient,
          formName: 'GSTR1'
        }
      }
      this.location = this.importlocation;
      this.eventEmitterService.loadCaptchePopup();
    } else {
      alerts("Select A Client")
    }
  }

  showModel: boolean = false;
  returnStatus: boolean = false;
  getClientList(id: string, row: any) {
    this.shareService.setData("formName","GSTR1");
    this.shareService.setData("module","Return");
    this.selectedClientData = this.shareService;
    this.returnStatus = true;
  }
  getDownloadPortal() {
    let selectedRow = this.clientListGridObject.getSeletedRowData();
    if (selectedRow) {
      this.downloadPortal = true;
    }else{
      alerts("Please Select the client first!")
    }
  }
  compareLocation: ComponentLocation = {
    moduleId: 'gstr1And3bCompareModule',
    selector: 'app-compare-with3b'
  };
  wtLazyCondition =false;
  compareWith3b(){
    this.wtLazyCondition = true;
    let selectedClient = this.clientListGridObject.getSeletedRowData();
    if (selectedClient) {
      let obj = {
        formName : 'GSTR1'
      }
      this.location = this.compareLocation;
      this.eventEmitterService.loadGstr1And3bComparePopup(obj);
    } else {
      alerts("Select A Client")
    }
  }

  talkBack($event) {
    this.returnStatus = $event;
  }

  downloadPortal: boolean = false;
  talkBackDownload($event) {
    this.downloadPortal = $event;
  }

  saveTurnOver(){
    let selectedData = this.clientListGridObject.getCheckedDataParticularColumnWise();
    if(selectedData && selectedData.length>0){
      let obj = {
        clientList : selectedData,
        monthId : this.shareService.getData("month")["monthId"],
        yearId : this.shareService.getData("year")["yearId"],
        formType: "GSTR1"
      }
      this.gstr01CommonService.saveCurrentStatusInDB(obj).subscribe((response:any)=>{
        if(response && response.status == 1){
          success("Data Update Successfully");
        }else{
          alerts("Error While Update Data");
        }
      });
    }else{
      alerts("Please Checked Client for Save Status");
    }
  }
}
