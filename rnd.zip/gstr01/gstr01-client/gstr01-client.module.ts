import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Gstr01ClientRoutingModule } from './gstr01-client-routing.module';
import { Gstr01ClientComponent } from './gstr01-client.component';
import { GSTSharedModule } from 'src/gst/shared/shared.module';
import {Gstr01ClientService} from './gstr01-client.service';

import { GstnOnlineLoginModule } from 'genmaster/src/master/gstn-online-login/gstn-online-login.module';
import { ReturnStatusComponent } from '../../common-component/return-status/return-status.component';
import { ReactiveComponentLoaderModule } from '@wishtack/reactive-component-loader';
import { DownloadPortalComponent } from '../../common-component/download-portal/download-portal.component';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ReturnSharedModule } from '../../return-shared/return-shared.module';
import { LanguageModule } from 'src/master/shared/language.module';

@NgModule({
  declarations: [Gstr01ClientComponent,
    ReturnStatusComponent,
   // DownloadPortalComponent
  ],
  imports: [
  	LanguageModule,
    ReturnSharedModule,
    GstnOnlineLoginModule,
    GSTSharedModule,
    CommonModule,
    Gstr01ClientRoutingModule,
    ProgressSpinnerModule,
    ReactiveComponentLoaderModule.forRoot()

  ],
  providers: [Gstr01ClientService]
})
export class Gstr01ClientModule { }
