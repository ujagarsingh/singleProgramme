import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Gstr01ClientComponent } from './gstr01-client.component';

const routes: Routes = [{
  path : "",
  component : Gstr01ClientComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Gstr01ClientRoutingModule { }
