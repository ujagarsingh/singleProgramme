import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as sagCommonGstConstant from '../../../gstCommonConstant';
import { ShareService } from 'node_modules/genmaster/src/master/services/share.service';

@Injectable({
  providedIn: 'root'
})
export class Gstr01ClientService {

  gstBaseUrl: String;

  constructor(private httpClient: HttpClient, private shareService: ShareService) {
    this.gstBaseUrl = sagCommonGstConstant.sagGstCommonConstant.gstReturnBaseUrl;
  }

  public getGSTR1ClientList(data: any) {
    return this.httpClient.post(`${this.gstBaseUrl}/clientInfo?yearId=${data.yearId}
&monthId=${data.monthId}&quarter=${data.quarter}&formType=${data.formType}&period=${data.period}`, null);
 }


}
