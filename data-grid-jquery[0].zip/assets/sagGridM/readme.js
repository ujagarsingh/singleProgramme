//Uses of sag grid 

/** columns :- this is array of object for column */
EX: [{
    header: "Name of column",
    field: "column_field",
    filter: true,
    width: "150px",
    "text-align": "center",
    search: true,
    sagGridResize: false, // hide resize icon in column 
    "word-wrap": true,
    "headerClass": "className",
    component: "componentName", // cellRenderView:"componentName",
    "columnType": "date", // numeric
    "attributes": {},
    "styles": {
        "width": "50px",
        "left": "100px",
        "background-color": "red"
    },
    style: "background-color : red", // change heder background-color
    buttonComponent: {
        visibility: false
    },
    checkboxSelection: true,
}];

var callBack = {

    "onCellClick": function(ele) {
        self.onCellSelectFn();
    },
    "onRowClick": function() {
        self.onRowSelectFn();
    },
    "onRowDbleClick": function() {
        self.dblClickModify();
    },
    "onCheckBoxClick": function(data) {

    },
    "onAllCheckBoxClick": function(data) {

    },
    "onButtonComponentClick": function(ele, obj) {},
    "rowCallBack": function(param) {
        
    },
    "cellCallBack": function(param) {
        
    }
}



let selectObj = new SagSelectBox(optArr, function(ele, params) {
    let params = {
        "rowIndex": sag_G_Index,
        "colKey": field,
        "rowValue": obj,
        "colValue": columns[j],
        "value": val,
    }
});

let checkBoxObj = new SagCheckBox(function(ele, params) {
    let params = {
        "rowIndex": sag_G_Index,
        "colKey": field,
        "rowValue": obj,
        "colValue": columns[j],
        "value": val,
    }
});

var components = {
    "componentName1": selectObj,
    "componentName2": checkBoxObj,
};

if (undefined != sourceDiv) {
    var gridData = {
        columnDef: columnsArray,
        rowDef: rowsArray,
        viewHeight: 912, //(Send grid height in numeric value according to px )

        frezzManager: { "checkBox": "left", "sno": "left", "othindName": "left", "groupName": "right", "clientCode": "left" },

        gridExportService: gridExportService,
        sheatDetails: { sheatName: "Client_ClientCreation_Client_List", title: "Client Creation Client List", fileName: "Client_ClientCreation_Client_List" },

        callBack: callBack,
        components: components,

        rowSelection: true,
        cellSelectionLtoR: true,


        wordBreak: true,


        //pagination work
        clientSidePaggingMP: true,
        "recordPerPage": 10,
        "totalRecordAllPage": 100,
        "recordStartIndex": 0,
        "recordEndIndex": 10,
        "onPageChange": function(pageNO, fromIndex, toIndex) {},

        disableAllSearch: true,
        footer_hide: false,
        totalNoOfRecord_hide: false,
        sml_expandGrid_hide: false,
        exportXlsxPage_hide: false,
        exportXlsxAllPage_hide: false,
        exportPDFLandscape_hide: false,
        exportPDFPortrait_hide: false,
        ariaHidden_hide: false,
        dragDropCol_hide: false,

        mutliColorInRow: [
            { "colorCode": "", "index": [] },
            { "colorCode": "", "index": [] }
        ], //only for backgroundColor color change

        conditionMerzemanager: {
            "conditionColumn": "columnKeyToMerge",
            "mrzeColumnList": ["fieldToMerge1", "firldToMerge2"]
        },


        //number sequence is given "rowsId" array like [2,3,4,5] not this number [2,4,7,11]
        //column key sequence is given field name "margeColumn" array like ['stateName', 'stateCode', 'countryName'] not this column key ['stateName', 'countryName','sno','stateShow']
        margeCellColumn: [{ "colKey": "stateName", "colIdGroup": [{ "rowsId": [3, 4, 5] }, { "rowsId": [6, 7, 8, 9] }] }, { "colKey": "stateCode", "colIdGroup": [{ "rowsId": [7, 8, 9] }, { "rowsId": [90, 91] }] }],
        margeCellRow: [{ "rowsId": 15, "margeColumn": ['stateName', 'stateCode', 'countryName'] }, { "rowsId": 18, "margeColumn": ['stateCode', 'countryName'] }],



        //Row Grouping
        rowGrouping: {
            "enable": true,
            "allowClick": false,
            "groupType": "custome",
            "groupBy": "fieldName",
            "expandRow": [],
            "StopExpandCollapse": [3]
        },

        cellComments: {
            "onSelect": function(obj) {
                console.log("success");
                let index = obj["index"];
                let col = obj["column"];
                let val = obj["value"];
                console.log("val--->" + val);

                var cmnt = prompt("Please Enter Comment", val);
                if (cmnt != null) {
                    val = cmnt;
                }
                self.gridDynamicObj.setComment(index, col, val);
            }
        }


    };
    $scope.gridDynamic = SagGridMP(sourceDiv, gridData, true, true);
}

/*
 *\\defalut tool tip
 * if row object contain toolTipMsg  object with colWise message value
 * EX:-  toolTipMsg = { "field":"message value to show"}
 * 
 * 
 *\\calling sagToolTip component 
 * "toolTip":new SagToolTip({},function(ele,param){
						
						let msg = param.rowValue.ttip;
						ele.title=msg;
					}),
 */


/**
 * Grid Event for access using return from grid object 
 */
/**
 * @Event list 
 * 1.) @setSelectedRowIndex event for set selected row index to grid data using @param index 
 * 2.) @getCurrentPageNo is static methode to send page no. it's create to prevent  methode not defined in old grid error.
 * 3.) @getSelectedRowIndex event return selected row of index @param index is not necessarry to give only for prevent error from old grid code. 
 * 4.) @setGridHight event is to set dynamic height of grid. give only for prevent error from old grid code. 
 * 5.) @setPageNumberSaveState event is dummy event. give only for prevent error from old grid code. 
 * 6.) @getSeletedRowData event send the selected row JSON object .
 * 7.) @setRowSelected event set selected row and heightlight this row @param var_index index fo row @param status not necesary.
 * 8.) @getCheckedDataParticularColumnWise This function for get data according to checked data @param paramKey not necessary
 * 9.) @getGridData This Method for Get All Grid Data Its return An Json Array
 * 10.) @defaultSearchEnable dummy method to prevent error from old grid 
 * 11.) @goAnyWherePage Method for going to any page pass page number. dummy method to prevent error from old grid 
 * 12.) @addRow This eventt For Insert last row @var_index not necessary @json JSON object of new row
 * 13.) @deleteLastRow This methode For delete last row
 * 14.) @setRowProperty This method for setRow Property rowJson like that format {"color":"red"} it will set tr attribute
 * 15.) @setColRowProperty This method for set cell Property. Json like that format {"color":"red"} it will set tr attribute
 * 16.) @setColProperty This method for set column Property rowJson like that format {"color":"red"} it will set tr attribute
 * 17.) @getRowData This Method For Getting Particular Row Data Need To pass index of a row and index is start with 0
 * 18.) @deleteRow This Method for delete particular row take argument is rowIndex
 * 19.) @updateRow This method for Update Row argument rowIndex and update Json with field name key
 * 20.) @disableColumn event for disable column from grid @param colKey field of column
 * 21.) @enableColumn event for enable column from grid @param colKey field of column
 * 22.) @disableCell event for disable cell from grid @param index row index @colKey field of column
 * 23.) @enableCell event for enable cell from grid @param index row index @colKey field of column
 * 24.) @focusCell set focus as a active element in html DOM  @param index row index @colKey field of column
 * 25.) @highlightColumn heighlight cell with given color in grid html DOM  @param index row index @colKey field of column @colorCode color code of color defalut is #ec8080
 * 26.) @checkRow for check grid row from outside @param Row_index_Arr is array of index
 * 27.) @disableGrid for disable grid
 * 28.) @enableGrid for enable grid
 * 29.) @getTotalOfAllRow event get total row in @return JSON object 
 * 30.) @updateTotalTD event for update total of all rows after change data  row in @return JSON object
 * 31.) @validate check every cell data is valid or not using given regex
 * 32.) @getError get all not valid cell data
 * 33.) @setComment on any cell by @param index row index and @param column field value 
 * 34.) @expandAll all expend all rows if row by grouping in given in grid
 * 35.) @collapseAll all collapse all rows if row by grouping in given in grid
 * 36.) @deleteMultipleRow This Method for delete multiple row take argument is rowIndex Array  
 * 37.) @updateCell This method for Update Cell argument rowIndex, column field and update value
 * 38.) @isValidate check every cell data is valid or not using given regex @return true if valide otherwise false 
 * 39.) @disableRow event for disable row from grid @param index row index
 * 40.) @enableRow event for disable row from grid @param index row index 
 * 41.) @disableAllRow event for disable all row from grid 
 * 42.) @enableAllRow event for enable all row from grid 
 * 43.) @addRowByIndex This eventt For Insert  row in  index @var_index insert index @json JSON object of new row 
 * 44.) @addColumn This eventt For add column  in grid  @json JSON object of new column
 * 45.) @deleteColumn This eventt For delete column  in grid  @field column key of deleted column
 * 46.) @getSeletedCellData This event for get selected cell data
 * 47.) @getColumnLength This eventt For get column length from grid
 * 48.) @getAllColumns This eventt For get all column array  from grid
 * 49.) @columnHeaderChange this event column header text chnage get index position.
 * 50.) @columnHeaderPositionChange This method for Update Header Position argument Index, get current index  get index position
 * 51.) @columnHeaderHide This eventt For get column field hide column in grid
 * 52.) @collapseByIndex This method for collapse row  by argument rowIndex
 * 53.) @expandByIndex This method for expand row  by argument rowIndex
 * 54.) @insertRow This method for Update Row argument rowIndex, Row Object  add New Row
 * 55.) @deleteCellValue This method for delete cell value  argument rowIndex, column key  add New Row
 /** */


// @deleteCellValue : example use

// ele.addEventListener('keydown', function (event) {
// 	const key = event.key;
// 	if (key === "Delete") {
// 		let rowId = ele.attributes['sag_g_index'].value;
// 		let field = ele.attributes['sag_g_key'].value;
// 		self.gridDynamicObj.deleteCellValue(rowId, field);
//     ele.contentEditable = true;
// 	}
// });


EXAMPLE: SagDynamicComp

// declare var SagDynamicComp;

SagDynamicComp.prototype.getObject = function (params) {
    //  For Checkbox
    if (params.rowValue.source == "Credit Register" || params.rowValue.source == "GSTR2") {
        return new SagCheckBox({}, function (ele, param) {
            
        });
    } else {
        return this;
    }
}

[{ header: "Select", field : "checkBox", filter: false, width: "70px", "editable": false, "text-align": "left", search: true, headerComponent: 'checkBoxHeader', cellRenderView: 'checkbox' }]

let componentObj = {
    "input": new SagDynamicComp({}, function () { }),
    "checkBoxHeader": new headerCheckBox({ Array: ["GSTR2A"] }, function () { }),
};
