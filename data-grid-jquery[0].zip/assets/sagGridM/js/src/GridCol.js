

function GridCol(sagGridObj) {
	this.sagGridObj = sagGridObj;
	this.colObj = {};
	this.cellHeight = this.sagGridObj.OneRowHeight;

}

GridCol.prototype.getColHtml = function (index) {

	let columns = this.sagGridObj.colData;
	let colHtml = {};
	let rowIndex = index;
	let obj = this.sagGridObj.rowData[rowIndex];
	let sag_G_Index = obj.sag_G_Index;


	let colHtmlCenter = GeneralEvent.createElementFromHTML('<div class="grid_row" sag_G_Index="' + sag_G_Index + '" grid_row_id="' + rowIndex + '"  > </div>');
	let colHtmlRight = GeneralEvent.createElementFromHTML('<div class="grid_row" sag_G_Index="' + sag_G_Index + '" grid_row_id="' + rowIndex + '"> </div>');
	let colHtmlLeft = GeneralEvent.createElementFromHTML('<div class="grid_row" sag_G_Index="' + sag_G_Index + '" grid_row_id="' + rowIndex + '" > </div>');

	let leftStyleL = 0;
	let leftStyleR = 0;
	let leftStyleC = 0;

	for (let j = 0; j < columns.length; j++) {

		let styleWidth = columns[j]["width"];  //this.styleWidth;
		let field = columns[j]["field"];

		if (this.sagGridObj.frezzManager.hasOwnProperty(field)) {
			let val = this.sagGridObj.frezzManager[field];
			if (val == 'left') {
				colHtmlLeft.appendChild(this.createCol(index, j, leftStyleL, "left"));
				if (!(columns[j].hasOwnProperty("hidden") && columns[j].hidden)) {
					leftStyleL += Number(styleWidth.replace("px", ""));
				}

			} else if (val == 'right') {
				colHtmlRight.appendChild(this.createCol(index, j, leftStyleR, "right"));
				if (!(columns[j].hasOwnProperty("hidden") && columns[j].hidden)) {
					leftStyleR += Number(styleWidth.replace("px", ""));
				}
			} else {
				colHtmlCenter.appendChild(this.createCol(index, j, leftStyleC, "center"));
				if (!(columns[j].hasOwnProperty("hidden") && columns[j].hidden)) {
					leftStyleC += Number(styleWidth.replace("px", ""));
				}
			}
		} else {
			colHtmlCenter.appendChild(this.createCol(index, j, leftStyleC, "center"));
			if (!(columns[j].hasOwnProperty("hidden") && columns[j].hidden)) {
				leftStyleC += Number(styleWidth.replace("px", ""));
			}
		}
	}

	colHtml["left"] = colHtmlLeft;
	colHtml["right"] = colHtmlRight;
	colHtml["center"] = colHtmlCenter;


	return colHtml;

}


GridCol.prototype.createCol = function (index, j, styleLeft, pos) {


	let self = this;
	let obj = this.sagGridObj.rowData[index];
	let columns = this.sagGridObj.colData;

	let sag_G_Index = obj.sag_G_Index;

	let field = columns[j]["field"];
	let styleHight = this.cellHeight;

	if (this.sagGridObj.wordBreak) {
		styleHight = this.sagGridObj.wordbreakConfig[index].height;
	}


	let visibility = '';

	if (this.sagGridObj.margeCellColumn != null) {
		let object = self.sagGridObj.cellMergeEvent.cellMergeRowColumn(field, sag_G_Index, styleHight, visibility);
		styleHight = object["Hight"];
		visibility = object["visibility1"];
	}
	if (this.sagGridObj.margeCellRow != null) {
		columns = self.sagGridObj.cellMergeEvent.cellMergeRow(sag_G_Index, columns);
	}


	let styleWidth = columns[j]["width"];  //this.styleWidth;
	let colHtml = '';

	if (columns[j].hasOwnProperty("visibility")) {
		visibility = columns[j]["visibility"];
	}

	//for row spanning
	let rowSpanSno = "";
	let isRowGrouped = false;
	if (this.sagGridObj.rowSpan) {

		if (this.sagGridObj.conditionMerzemanager.mrzeColumnList.includes(field)) {

			if (this.sagGridObj.rowObjSpanIndexWidth.hasOwnProperty(sag_G_Index)) {
				let rowSpanHightVal = this.sagGridObj.rowObjSpanIndexWidth[sag_G_Index]["height"];
				styleHight = styleHight * rowSpanHightVal;
				rowSpanSno = this.sagGridObj.rowObjSpanIndexWidth[sag_G_Index]["index"];
				isRowGrouped = true;
			} else {
				rowSpanSno = index + 1;
				visibility = "";
			}
		} else {
			rowSpanSno = index + 1;
		}

	}

	if (this.sagGridObj.multiRowSpan) {

		let merzeObj = this.sagGridObj.rowArraySpanIndexWidth.find((item) => item.mrzeColumnList.includes(field));

		if (merzeObj != undefined && merzeObj.mrzeColumnList.includes(field)) {

			if (Object.keys(merzeObj.rowObjSpanIndexWidth).length === 0) {
				rowSpanSno = index + 1;
			} else if (merzeObj.rowObjSpanIndexWidth.hasOwnProperty(sag_G_Index)) {
				let rowSpanHightVal = merzeObj.rowObjSpanIndexWidth[sag_G_Index]["height"];
				styleHight = styleHight * rowSpanHightVal;
				rowSpanSno = merzeObj.rowObjSpanIndexWidth[sag_G_Index]["index"];
				isRowGrouped = true;
			} else {
				rowSpanSno = index + 1;
				visibility = "hidden";
			}
		} else {
			rowSpanSno = index + 1;
		}

	}


	let colClass = columns[j]["sagColClass"];   //this.sagGridObj.colIdArray[pos][j];   //'col'+j;

	let textAlign = 'left';
	if (columns[j].hasOwnProperty("text-align")) {
		textAlign = columns[j]["text-align"];
	} else if (columns[j].hasOwnProperty("align")) {
		textAlign = columns[j]["align"];
	}

	let attributes = {};
	let colEvent = {};
	if (columns[j].hasOwnProperty("attributes")) {
		attributes = columns[j]["attributes"];
		colEvent = attributes;
	}

	attributes["sag_G_Index"] = sag_G_Index;
	attributes["sag_G_Key"] = field;
	attributes["index"] = index;
	attributes["tabindex"] = "-1";
	attributes["tabIndex_col"] = j;
	attributes["tabIndex_row"] = index;



	let fieldVal = ''

	if (field == 'id') {
		fieldVal = sag_G_Index;
	} else if (field == 'sno' && this.sagGridObj.rowSpan) {

		fieldVal = rowSpanSno;

	} else if (field == 'sno' && this.sagGridObj.multiRowSpan) {

		fieldVal = rowSpanSno;

	} else if (field == 'sno') {

		if (this.sagGridObj.clientSidePagging && this.sagGridObj.hasOwnProperty("recordStartIndex")) {
			fieldVal = index + this.sagGridObj.recordStartIndex + 1;
		} else {
			fieldVal = index + 1;
		}
		obj[field] = fieldVal;
	} else {

		if (!columns[j].hasOwnProperty("component")) {
			fieldVal = obj[field];
		} else {

			let val = obj[field];
			let conponentName = columns[j]["component"];

			attributes["component"] = conponentName;
			attributes["keyValue"] = val;

			let compObj = this.sagGridObj.components[conponentName];
			// let compObj = new component();
			let params = {
				"rowIndex": sag_G_Index,
				"colKey": field,
				"rowValue": obj,
				"colValue": columns[j],
				"value": val,
			};
			if (compObj.getObject != undefined) {
				compObj = compObj.getObject(params);
			}
			compObj.init(params);
			//fieldVal = compObj.getValue();
			fieldVal = compObj.getTextView();
		}


	}

	if (fieldVal == null || fieldVal == undefined) {
		fieldVal = " ";
	}

	//Row by Grouping
	/*if( j == 0 && sag_G_Index < 0){
		fieldVal = obj["RowGroupingText"];
	}*/


	/**
	 * Cell Render view work start
	 */
	if (columns[j].hasOwnProperty("cellRenderView")) {
		let conponentName = columns[j]["cellRenderView"];
		let compObj = this.sagGridObj.components[conponentName];
		//let compObj = new component();
		let params = {
			"rowIndex": sag_G_Index,
			"colKey": field,
			"rowValue": obj,
			"colValue": columns[j],
			"value": fieldVal,
			"sagGridObj": this.sagGridObj,
		};
		if (compObj.getObject != undefined) {
			compObj = compObj.getObject(params);
		}
		compObj.init(params);
		fieldVal = compObj.getGui();
		compObj.afterGuiAttached();


		compObj.onChangeValue(function (rowIndex, colKey, val) {
			if (self.sagGridObj.rowGrouping) {
				self.sagGridObj.originalRowData[rowIndex][colKey] = val;
			} else {
				self.sagGridObj.rowData[rowIndex][colKey] = val;
			}
		});
	}


	//for give button component in column 
	if (columns[j].hasOwnProperty("buttonComponent")) {
		let btnCmpObj = columns[j]["buttonComponent"];
		if (btnCmpObj.hasOwnProperty("visibility") && (btnCmpObj.visibility == true)) {
			fieldVal = '<div class="sml_btnComponent"><span>' + fieldVal + '</span><button type="button" style="display:block;" class="fa fa-ellipsis-h btnComponent btnCmpListnr"></button></div>';
		} else {
			fieldVal = '<div class="sml_btnComponent"><span>' + fieldVal + '</span><button type="button" style="display:none;" class="fa fa-ellipsis-h btnComponent btnCmpListnr"></button></div>';
		}
	}

	//for give checkbox selection in column 
	if (columns[j].hasOwnProperty("checkboxSelection") && columns[j]["checkboxSelection"] == true) {
		let chkaArr = this.sagGridObj.checkedObj[field];
		if (Array.isArray(chkaArr) && chkaArr.includes(sag_G_Index)) {
			fieldVal = `
					<div class="coll_chekbox">
						  <input type="checkbox" sag_G_index="${sag_G_Index}" tabIndex_col="${j}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener" checked>
						  <label>${fieldVal}</label>
					</div>
			`
		} else {
			fieldVal = `
					<div class="coll_chekbox">
						  <input type="checkbox" sag_G_index="${sag_G_Index}" tabIndex_col="${j}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener">
						  <label>${fieldVal}</label>
					</div>
			`
		}

		// <input type="checkbox" sag_G_index="' + sag_G_Index + '" tabIndex_col="' + j + '" sag_G_Key="' + field +'" class="customCheckBoxListener">' + fieldVal + '';
	}

	//for give help Icon in column 
	if (columns[j].hasOwnProperty("helpBy")) {
		// set current value in a variable
		parent_val = fieldVal;
	}

	//for give help Icon in column 
	if (columns[j].hasOwnProperty("helpIcon")) {
		// check parent_val has in >> tooltipObj**[this is globle object] 
		let helpVal = '';
		if (tooltipObj) {
			let _moduleKey = columns[j].helpObj;
			let _current_elem = [];
			const _module = tooltipObj.filter((item_module) => {
				if (item_module.module_key === _moduleKey) {
					return item_module
				}
			})
			_current_elem = _module[0].module_data.filter((item) => {
				if (item.item_id === parent_val) {
					return item
				}
			})
			// if yes than
			if (_current_elem.length > 0) {
				helpVal = `<i data-help-key=${parent_val} data-module-key=${_moduleKey} class="fa fa-question-circle custom-fa vj_helpIconBtn"></i>`;
			}
		}
		if (typeof fieldVal === 'string' || fieldVal instanceof String)
			fieldVal += helpVal;
		else {
			if (fieldVal.querySelector("span"))
				fieldVal.querySelector("span").insertAdjacentHTML("afterend", helpVal)
			else
				console.error("Element Span Not Found");
		}
	}

	let nodeObject = {};


	let styleObj = { "width": styleWidth, "left": styleLeft + "px", "height": styleHight + "px", "text-align": textAlign, "visibility": visibility };


	//also apply css from grid column if given
	if (columns[j].hasOwnProperty("styles")) {
		styleObj = Object.assign(styleObj, columns[j]["styles"]);
	}


	//change patucular  row  vise css tyle like color color
	if (this.sagGridObj.setRowPropertyObj.hasOwnProperty(sag_G_Index)) {
		styleObj = Object.assign(styleObj, this.sagGridObj.setRowPropertyObj[sag_G_Index]);
	}

	//change patucular column and row  css tyle like color color
	if (this.sagGridObj.setColRowPropertyObj.hasOwnProperty(sag_G_Index + "_" + field)) {
		styleObj = Object.assign(styleObj, this.sagGridObj.setColRowPropertyObj[sag_G_Index + "_" + field]);
	}

	//change patucular column css tyle like color color
	if (this.sagGridObj.setColPropertyObj.hasOwnProperty(field)) {
		styleObj = Object.assign(styleObj, this.sagGridObj.setColPropertyObj[field]);
	}

	if (columns[j].hasOwnProperty("hidden") && columns[j].hidden) {
		styleObj["padding"] = "0";
		styleObj["width"] = "0px";
	}


	if (columns[j]["colType"] == "checkBox") {
		let cls = Property.fontAwsmClass.unChecked;
		if (this.sagGridObj.checkedRowIdArray.indexOf(sag_G_Index) > -1) {
			cls = Property.fontAwsmClass.checked;
		}

		//colHtml = `<div index="${index}" class="grid_cell ${colClass}" sag_G_Index="${sag_G_Index}" sag_G_Key="${field}" style="width:${styleWidth}; height:${styleHight}px; left:${styleLeft}px; text-align:center;  "  > <span class=" fa ${cls} sag-checkBox  sag-CheckboxCls" > </span></div>`;


		nodeObject = {
			"nodeType": "div",
			"attributes": attributes,
			"classes": ["grid_cell", "gridNavigationEvent", "cellSelectionEvent", "cellEventListnr", colClass],
			"styles": styleObj,
			"childNode": [
				{
					"nodeType": "span",
					//"attributes":colEvent,
					"classes": ["far", cls, "sag-checkBox", "sag-CheckboxCls"],
				}
			]
		};

	} else {

		if (this.sagGridObj.rowGrouping && (this.sagGridObj.rowGroupObj.hasOwnProperty("groupBy") && (this.sagGridObj.rowGroupObj["groupBy"] == field))) {
			let padding = obj.RG_Level * 20 + 'px';
			styleObj["padding-left"] = padding;
			if ((obj.hasOwnProperty("RG_HasChild") && obj.RG_HasChild)) {

				if (this.sagGridObj.expandRow.includes(obj.RG_INDEX)) {
					fieldVal = '<i class="fa fa-minus-circle RG_clickListner"  RG_ExpandCls RG_INDEX="' + obj.RG_INDEX + '" row_index="' + index + '"  RG_Level="' + obj.RG_Level + '"  ></i>   ' + fieldVal;
				} else {
					fieldVal = '<i class="fa fa-plus-circle RG_clickListner"  RG_ExpandCls RG_INDEX="' + obj.RG_INDEX + '"  row_index="' + index + '"    RG_Level="' + obj.RG_Level + '"  ></i>   ' + fieldVal;
				}
			}
		}

		nodeObject = {
			"nodeType": "div",
			"attributes": attributes,
			"classes": ["grid_cell", "gridNavigationEvent", "cellSelectionEvent", "cellEventListnr", colClass],
			"styles": styleObj,
			"props": { "innerHTML": fieldVal },
		};

		//Editable work start
		if (columns[j].hasOwnProperty("editable")) {
			if (columns[j]["editable"] == true) {
				nodeObject.classes.push("sagCellEditable");
				nodeObject.attributes["editable"] = "input-type-text";
			}
		}


		//disable cell 
		let disableCellKey = sag_G_Index + "_" + field;
		if (this.sagGridObj.gridEventObj.disabledCell.hasOwnProperty(disableCellKey) && (this.sagGridObj.gridEventObj.disabledCell[disableCellKey] == true)) {
			nodeObject.classes.push("sml_disable");
		}

		//disable column 
		if (columns[j].hasOwnProperty("disable")) {
			if (columns[j]["disable"] == true) {
				if (!this.sagGridObj.gridEventObj.disabledCell.hasOwnProperty(disableCellKey)) {
					nodeObject.classes.push("sml_disable");
				}
			}
		}




	}
	//let colHtml = `<div index="${index}" class="grid_cell ${colClass}" style="width:${styleWidth}; left:${styleLeft}px"  >${fieldVal}</div> `;

	//if row is selected 
	if (this.sagGridObj.gridEventObj.selectedRowINdex != null && this.sagGridObj.gridEventObj.selectedRowINdex == sag_G_Index) {
		nodeObject.classes.push("sml_slectedRow");
	}

	//for row grouping 
	// if(this.sagGridObj.rowObjSpanIndexWidth.hasOwnProperty(sag_G_Index) && this.sagGridObj.conditionMerzemanager.mrzeColumnList.includes(field) ){  //with only selected cell  field
	if (isRowGrouped) {
		nodeObject.classes.push("cellGroupSelected");
	}

	//for show invalid column value 
	let boolValue = this.sagGridObj.validationObj.isErrorInRC(sag_G_Index, field);
	if (boolValue)
		nodeObject.classes.push("regexInvalid");

	//for cell comment 
	if (this.sagGridObj.cellCommentObj) {
		let key = sag_G_Index + "_" + field;
		if (this.sagGridObj.cellCommentObj.cellCommentObj.hasOwnProperty(key)) {
			nodeObject.classes.push("sml_comment_i");
		}
	}

	// for apply word-break property 
	if (this.sagGridObj.wordBreak) {
		styleObj["text-overflow"] = "unset";
		styleObj["white-space"] = "normal";
	}




	colHtml = this.createElement(nodeObject, "null");
	//colHtml  = GeneralEvent.createHtmlStrFromEle(colHtml); 

	//tooltip show if row object contain ttoltip 
	//tooltip show 
	try {
		if (obj.hasOwnProperty("toolTipMsg")) {
			let toolTipObj = obj["toolTipMsg"];
			if (toolTipObj.hasOwnProperty(field)) {
				let msg = toolTipObj[field];
				colHtml.setAttribute("data-toggle", "tooltip");
				colHtml.setAttribute("title", msg);

				(function () {
					$(".tooltip").remove();
				})();

			}
		}
	} catch (e) {

	}


	return colHtml;

}

GridCol.prototype.updateCol = function (rowIndex, colKey) {
	let self = this;
	let columns = this.sagGridObj.colData;
	let colIndex = _.findIndex(columns, { "field": colKey });
	let cell = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + rowIndex + '"][sag_g_key="' + colKey + '"]')[0];
	if (cell != undefined && colIndex > -1) {
		let left = cell.style.left;
		styleLeft = left.replace("px", "");
		let parentNode = cell.closest(".parent_main");
		let pos = parentNode.getAttribute("parent");
		let cellHtml = this.createCol(rowIndex, colIndex, styleLeft, pos);
		cell.innerHTML = '';
		cell.innerHTML = cellHtml.innerHTML;
		this.sagGridObj.sagGridEvent.addClickListner();
	}
	if (colIndex > -1) {
		/** CALL BACK EVENT AFTER CELL CREATE  */
		if (this.sagGridObj.isCellCallBack) {
			this.sagGridObj.rowCellEvent.afterCellEditCallback(rowIndex, colIndex, this.sagGridObj.callBack.cellCallBack);
		}
	}
}



//refresh column Data in grid 
GridCol.prototype.refreshCol = function (colKey) {

	let self = this;
	let gridAllCol = (this.sagGridObj.gridEle).querySelectorAll('div[sag_g_key="' + colKey + '"].grid_cell');
	for (let i = 0; i < gridAllCol.length; i++) {

		let fieldVal = 'YES';
		let prNode = gridAllCol[i];
		let sag_G_Index = parseInt(gridAllCol[i].getAttribute("sag_g_index"));
		let index = parseInt(gridAllCol[i].getAttribute("index"));
		let field = gridAllCol[i].getAttribute("sag_g_key");

		let colData = _.find(this.sagGridObj.colData, { 'field': field });
		let obj = this.sagGridObj.originalRowData[sag_G_Index];

		if (field == 'id') {
			fieldVal = sag_G_Index;
		} else if (field == 'sno') {
			fieldVal = index + 1;
		} else {

			if (!colData.hasOwnProperty("component")) {
				fieldVal = obj[field];
			} else {

				let val = obj[field];
				let conponentName = colData["component"];

				// attributes["component"] = conponentName;
				//attributes["keyValue"] = val;

				let compObj = this.sagGridObj.components[conponentName];
				// let compObj = new component();
				let params = {
					"rowIndex": sag_G_Index,
					"colKey": field,
					"rowValue": obj,
					"colValue": colData,
					"value": val,
					"ele": ele,
				};
				if (compObj.getObject != undefined) {
					compObj = compObj.getObject(params);
				}
				compObj.init(params);
				//fieldVal = compObj.getValue();
				fieldVal = compObj.getTextView();
			}

		}

		if (fieldVal == null || fieldVal == undefined) {
			fieldVal = " ";
		}

		/**
		 * Cell Render view work start
		 */
		if (colData.hasOwnProperty("cellRenderView")) {
			let conponentName = colData["cellRenderView"];
			let compObj = this.sagGridObj.components[conponentName];
			//let compObj = new component();
			let params = {
				"rowIndex": sag_G_Index,
				"colKey": field,
				"rowValue": obj,
				"colValue": colData,
				"value": fieldVal,
				"sagGridObj": this.sagGridObj,
			};
			if (compObj.getObject != undefined) {
				compObj = compObj.getObject(params);
			}
			compObj.init(params);
			fieldVal = compObj.getGui();
			compObj.afterGuiAttached();

			compObj.onChangeValue(function (rowIndex, colKey, val) {
				if (self.sagGridObj.rowGrouping) {
					self.sagGridObj.originalRowData[rowIndex][colKey] = val;
				} else {
					self.sagGridObj.rowData[rowIndex][colKey] = val;
				}
			});
		}

		prNode.innerHTML = "";
		prNode.append(fieldVal);

	}

}


GridCol.prototype.clickOngrid_cell = function () {

	$('div.grid_cell').ondblclick = function () { console.log("click success") };

}

GridCol.prototype.createElement = function (nodeObj, fieldVal) {

	let nodeType = nodeObj.nodeType;
	var element = document.createElement(nodeType);

	//set attributes
	if (nodeObj.hasOwnProperty("attributes")) {
		let attrObj = nodeObj.attributes;
		for (let key in attrObj) {
			let value = attrObj[key];
			element.setAttribute(key, value);
		}
	}

	//set property
	if (nodeObj.hasOwnProperty("props")) {
		let propObj = nodeObj.props;
		for (let key in propObj) {
			let value = propObj[key];
			if (key == "innerHTML") {
				if (value instanceof HTMLElement) {
					element.append(value);
				} else {
					element[key] = value;
				}
			} else {
				element[key] = value;
			}
		}

	}

	//add styles
	if (nodeObj.hasOwnProperty("styles")) {
		let styleArray = nodeObj.styles;
		for (let key in styleArray) {
			let value = styleArray[key];
			element.style[key] = value;

		}
	}

	//add class
	if (nodeObj.hasOwnProperty("classes")) {
		let classArray = nodeObj.classes;
		for (let i = 0; i < classArray.length; i++) {
			element.classList.add(classArray[i]);
		}
	}

	if (nodeObj.hasOwnProperty("childNode")) {
		let childNodeArray = nodeObj.childNode;
		for (let i = 0; i < childNodeArray.length; i++) {
			let childObj = childNodeArray[i];
			let eleDom = this.createChildElement(childObj);
			element.appendChild(eleDom);
		}
	}


	//add events
	if (nodeObj.hasOwnProperty("events")) {
		let eventObj = nodeObj.events;
		for (let key in eventObj) {
			let value = eventObj[key];
			//element.addEventListener(key,value);	
			this.sagGridObj.EventListner.push({ "ele": element, "k": key, "fn": value });
		}
	}

	if (nodeObj.hasOwnProperty("callBack")) {
		nodeObj.callBack(element, fieldVal);
	}

	return element;
}

GridCol.prototype.createChildElement = function (nodeObj) {

	let nodeType = nodeObj.nodeType;
	var element = document.createElement(nodeType);

	//set attributes
	if (nodeObj.hasOwnProperty("attributes")) {
		let attrObj = nodeObj.attributes;
		for (let key in attrObj) {
			let value = attrObj[key];
			element.setAttribute(key, value);
		}
	}

	//set property
	if (nodeObj.hasOwnProperty("props")) {
		let propObj = nodeObj.props;
		for (let key in propObj) {
			let value = propObj[key];
			if (key == "innerHTML") {
				if (value instanceof HTMLElement) {
					element.append(value);
				} else {
					element[key] = value;
				}
			} else {
				element[key] = value;
			}
		}
	}

	//add styles
	if (nodeObj.hasOwnProperty("styles")) {
		let styleArray = nodeObj.styles;
		for (let key in styleArray) {
			let value = styleArray[key];
			element.style[key] = value;
		}
	}

	//add class
	if (nodeObj.hasOwnProperty("classes")) {
		let classArray = nodeObj.classes;
		for (let i = 0; i < classArray.length; i++) {
			element.classList.add(classArray[i]);
		}
	}

	if (nodeObj.hasOwnProperty("childNode")) {
		let childNodeArray = nodeObj.childNode;
		for (let i = 0; i < childNodeArray.length; i++) {
			let childObj = childNodeArray[i];
			let eleDom = this.createChildElement(childObj);
			element.appendChild(eleDom);
		}
	}
	return element;
}


