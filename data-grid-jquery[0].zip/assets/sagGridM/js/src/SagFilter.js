function Filter(sagGridObj) {

    this.sagGridObj = sagGridObj;
    this.lastSearchEle = null;
    this.filterRecordStoreArray = [];
    this.filterInputTextSearch = [];
    this.filterInputTextValue = null;
    this.filterInputTextStoreArray = [];
    this.textValueStore = null;
    this.checkedTextArray = [];
    this.totalCheckBoxTextArray = null;

    this.fieldValueStore = null;
    this.gridRowIndexArray = [];
    this.index = 0;
    this.idIndex = 0;


}


Filter.prototype.paginate = function(array, page_size, page_number) {
    --page_number;
    return array.slice(page_number * page_size, (page_number + 1) * page_size);
}

Filter.prototype.createFilterPopUp = function(ele) {

    $('#filterScroll').empty();
    let self = this;
    this.idIndex = 0;
    this.sagGridObj.sagFilter = false;

    this.gridRowIndexArray = [];
    this.checkedTextArray = [];

    let field = ele.getAttribute("field");
    this.fieldValueStore = field;
    self.lastSearchEle = ele
    this.filterInputTextValue = null;

    let lastTextSearchingArray = undefined;

    let worker;
    if (typeof(Worker) !== "undefined") {
        if (typeof(worker) == "undefined") {
            GeneralEvent.startLoader();
            var worker_fn = function(e) {
                self.postMessage('web worker process start');
            };
            var blob = new Blob(["onmessage =" + worker_fn.toString()], { type: "text/javascript" });
            worker = new Worker(window.URL.createObjectURL(blob));
        }

        worker.onmessage = function(event) {

            if (typeof(worker) !== "undefined") {
                if (self.filterInputTextStoreArray.length > 0) {
                    let valueObject = _.findLast(self.filterInputTextStoreArray, function(n) {
                        return n.field == field;
                    });
                    if (valueObject != undefined) {
                        let inputTextValue = valueObject['textValue'];
                        if (new String(inputTextValue).valueOf() == new String(self.textValueStore).valueOf()) {
                            let fieldName = valueObject['field'];
                            if (field == fieldName) {
                                $('#myInput').val(inputTextValue);
                            } else {
                                $('#myInput').val("");
                            }
                            lastTextSearchingArray = "TEXT_SEARCH";
                        } else {
                            $('#myInput').val(self.textValueStore);
                            let lastIndex = _.findLastIndex(self.filterInputTextStoreArray, { 'textValue': inputTextValue });
                            self.filterInputTextStoreArray.splice(lastIndex, 1);
                        }
                    } else {
                        $('#myInput').val("");
                    }
                }

                let arrayPageWise = null;

                if (self.filterRecordStoreArray.length > 0 && self.filterInputTextValue == null) {

                    let lastObject = _.last(self.filterRecordStoreArray);
                    fieldValue = lastObject['field'];
                    if (fieldValue == field) {
                        arrayPageWise = lastObject['totalInputsCheckBox'];
                    } else {
                        arrayPageWise = lastObject['filterDataArray'];

                    }
                } else {

                    arrayPageWise = self.paginate(self.sagGridObj.originalRowData, 10000, 1);
                    //arrayPageWise = self.sagGridObj.originalRowData;

                }

                self.index = arrayPageWise.length;
                $((self.sagGridObj.gridEle).querySelector('#filterScroll')).append(self.createInnerPopUpRecord(arrayPageWise, field));
                //self.addFilterPopUpScroll();

                let checkboxNodeList = (self.sagGridObj.gridEle).querySelectorAll('.filterRow input[type="checkbox"]');
                for (let i = 0, len = checkboxNodeList.length; i < len; i++) {
                    let ele = checkboxNodeList[i];
                    $(ele).removeClass("filterRow");
                    ele.addEventListener("click", function() {
                        self.InnerPopUpCheckBox_ClickEvent(ele);
                    }, false);
                }
                self.InnerPopUpCheckBox_ClickEvent();
                GeneralEvent.stopLoader();
                worker.terminate();
                worker = undefined;
            }

        }

        worker.postMessage("start");
    } else {
        alert("Sorry! No Web Worker support.");
    }

}


Filter.prototype.addFilterPopUpScroll = function() {

    let thisObj = this;
    $((this.sagGridObj.gridEle).querySelectorAll("#filterScroll")).unbind("scroll");
    $((this.sagGridObj.gridEle).querySelectorAll("#filterScroll")).scroll(function(event) {
        let ele = this;
        let pos = $(ele).scrollTop();
        event.preventDefault();
        $((thisObj.sagGridObj.gridEle).querySelectorAll("#filterScroll")).animate({ scrollTop: pos }, 0, 'linear', function() {
            thisObj.eventOnScrollFilter(ele);
        });

    });


}


Filter.prototype.eventOnScrollFilter = function(ele, addFlag) {

    let self = this;
    let element = self.lastSearchEle;
    let field = element.getAttribute("field");
    if (self.sagGridObj.rowData.length > self.index && self.filterInputTextValue == null) {
        self.index++;

        if (self.index >= 0 && !(self.gridRowIndexArray.includes(self.index))) {

            let arrayPageWise = self.paginate(self.sagGridObj.originalRowData, 5, self.index);
            if (self.totalCheckBoxTextArray != null) {

                for (var i = 0, len = arrayPageWise.length; i < len; i++) {

                    if (!self.totalCheckBoxTextArray.includes(self.index)) {
                        self.totalCheckBoxTextArray.push(arrayPageWise[i]);
                    }
                    self.index++;
                }

            }


            self.getFilterRow(arrayPageWise, field);

            let checkboxNodeList = (self.sagGridObj.gridEle).querySelectorAll('.filterRow input[type="checkbox"]');
            for (let i = checkboxNodeList.length - 1, len = checkboxNodeList.length; i < len; i++) {
                let ele = checkboxNodeList[i];
                $(ele).removeClass("filterRow");
                ele.addEventListener("click", function() {
                    self.InnerPopUpCheckBox_ClickEvent(ele);
                }, false);
            }
            self.InnerPopUpCheckBox_ClickEvent();


            if (addFlag == undefined) {
                self.gridRowIndexArray.push(self.index);
            }
        }
    }

}

Filter.prototype.getFilterRow = function(dataArrayList, field) {

    let self = this;

    if (dataArrayList.length > 0) {

        let rowDataUniqueList = self.unique(dataArrayList, field);

        var strArrCheckedList = rowDataUniqueList.map(String);
        var checkedArray = strArrCheckedList;

        let uniqueArray = strArrCheckedList;

        let componentObj = null;

        let colDataArray = this.sagGridObj.colData;
        let colObj = _.find(colDataArray, { 'field': field });

        let componentType = false;
        if (colObj.hasOwnProperty("component")) {
            componentType = "component";
        } else if (colObj.hasOwnProperty("cellRenderView")) {
            componentType = "cellRenderView";
        } else {
            componentType = false;

        }

        if (componentType) {
            let conponentName = colObj[componentType];
            componentObj = this.sagGridObj.components[conponentName];
        }

        // let innerDivElement = document.createDocumentFragment();
        for (var i = 0, len = uniqueArray.length; i < len; i++) {


            self.idIndex++;
            if (!(self.gridRowIndexArray.includes(self.idIndex))) {

                self.gridRowIndexArray.push(self.idIndex);
            }

            this.popupListShow++;
            let textShow = null;
            let textValue = uniqueArray[i];

            let textText = textValue;

            if (componentObj) {
                textText = componentObj.getTextUsingVal(textValue);
                if (componentObj.isFilterValueShow) {
                    textShow = textText + "  [ " + textValue + " ]";
                } else {
                    textShow = textText;
                }
            } else {
                textShow = textText;
            }

            let filterRow = document.createElement('div');
            filterRow.className = 'filterRow';
            let checkBoxDiv = document.createElement('div');
            checkBoxDiv.className = 'checkbox';
            let inputFilter = document.createElement('input');
            inputFilter.className = 'filterRowInput filterRowInputClickEvent';
            inputFilter.type = 'checkbox';
            inputFilter.value = textValue;
            inputFilter.name = "filterInput[]";
            if (checkedArray.includes(textValue)) {
                inputFilter.checked = true;
                this.checkedTextArray.push(textValue);
            } else {
                inputFilter.checked = false;
            }
            inputFilter.id = "filterInputId_" + self.idIndex;
            let checkLabel = document.createElement('div');
            checkLabel.className = 'checkLabel';
            checkLabel.innerText = textShow;
            checkBoxDiv.appendChild(inputFilter);
            filterRow.appendChild(checkBoxDiv);
            filterRow.appendChild(checkLabel);

            $((self.sagGridObj.gridEle).querySelector('#filterScroll')).append(filterRow);

        }


    }
}


Filter.prototype.createInnerPopUpRecord = function(dataArrayList, field) {

    let self = this;

    let fieldValue = field;
    let checkedArray = null;
    if (dataArrayList.length > 0) {
        let rowDataUniqueList = self.unique(dataArrayList, field);

        var strArrCheckedList = rowDataUniqueList.map(String);
        checkedArray = strArrCheckedList;

        if (self.filterRecordStoreArray.length > 0 && self.filterInputTextValue == null) {
            let lastObject = _.last(this.filterRecordStoreArray);
            fieldValue = lastObject['field'];
            if (fieldValue == field) {
                this.totalCheckBoxTextArray = lastObject['totalInputsCheckBox'];
                checkedArray = lastObject['checked'];
            } else {

                this.totalCheckBoxTextArray = dataArrayList;
                checkedArray = strArrCheckedList;

            }
            rowDataUniqueList = self.unique(this.totalCheckBoxTextArray, field);
            strArrCheckedList = rowDataUniqueList.map(String);

        } else {
            this.totalCheckBoxTextArray = dataArrayList;
            checkedArray = strArrCheckedList;
        }


        let uniqueArray = strArrCheckedList;

        let componentObj = null;

        let colDataArray = this.sagGridObj.colData;
        let colObj = _.find(colDataArray, { 'field': field });

        let componentType = false;
        if (colObj.hasOwnProperty("component")) {
            componentType = "component";
        } else if (colObj.hasOwnProperty("cellRenderView")) {
            componentType = "cellRenderView";
        } else {
            componentType = false;

        }

        if (componentType) {
            let conponentName = colObj[componentType];
            componentObj = this.sagGridObj.components[conponentName];
        }

        let innerDivElement = document.createDocumentFragment();
        for (var i = 0, len = uniqueArray.length; i < len; i++) {

            self.gridRowIndexArray.push(i);
            self.idIndex++;
            this.popupListShow++;
            let textShow = null;
            let textValue = uniqueArray[i];

            let textText = textValue;

            if (componentObj) {
                textText = componentObj.getTextUsingVal(textValue);
                if (componentObj.isFilterValueShow) {
                    textShow = textText + "  [ " + textValue + " ]";
                } else {
                    textShow = textText;
                }
            } else {
                textShow = textText;
            }

            let filterRow = document.createElement('div');
            filterRow.className = 'filterRow';
            let checkBoxDiv = document.createElement('div');
            checkBoxDiv.className = 'checkbox';
            let inputFilter = document.createElement('input');
            inputFilter.className = 'filterRowInput filterRowInputClickEvent';
            inputFilter.type = 'checkbox';
            inputFilter.value = textValue;
            inputFilter.name = "filterInput[]";
            if (checkedArray.includes(textValue)) {
                inputFilter.checked = true;
                this.checkedTextArray.push(textValue);
            } else {
                inputFilter.checked = false;
            }
            inputFilter.id = "filterInputId_" + this.idIndex;
            let checkLabel = document.createElement('div');
            checkLabel.className = 'checkLabel';
            checkLabel.innerText = textShow;
            checkBoxDiv.appendChild(inputFilter);
            filterRow.appendChild(checkBoxDiv);
            filterRow.appendChild(checkLabel);
            innerDivElement.appendChild(filterRow);
        }

        return innerDivElement;
    }
}


Filter.prototype.OkButton_FilterClickEvent = function(ele) {

    let self = this;
    let filterDataArray = [];

    let selectedEle = this.lastSearchEle;
    let field = selectedEle.getAttribute("field");
    let rowDataUniqueList = null;
    let inputVal = (this.sagGridObj.gridEle).querySelector('#myInput').value;
    inputVal = inputVal.toUpperCase();

    rowDataUniqueList = self.unique(this.totalCheckBoxTextArray, field);
    var uniqueArray = rowDataUniqueList.map(String);

    let checkedArray = [];
    for (let a = 0, n = uniqueArray.length; a < n; a++) {
        let allDataValue = uniqueArray[a];

        if (this.checkedTextArray.includes(allDataValue)) {
            checkedArray.push(allDataValue);
            let obj = {};
            obj[field] = allDataValue;
            let arrayFilter = _.filter(this.totalCheckBoxTextArray, function(o) {
                if (String(obj[field]) == String(o[field])) {
                    return true;
                }
            });

            filterDataArray.push.apply(filterDataArray, arrayFilter);

        }
    }


    if ($((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput:checked')).length == $((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput')).length) {
        this.sagGridObj.sagFilter = false;
        if (self.filterInputTextValue != null) {

            this.textValueStore = self.filterInputTextValue;

            $((this.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
            if (selectedEle) {
                selectedEle.classList.add('sml_activeFilter');
            }
            this.filterInputTextStoreArray.push({ "field": field, "textValue": this.textValueStore, "filterDataArray": filterDataArray });

        }

        if (this.filterRecordStoreArray.length > 0) {
            let lastObject = _.last(this.filterRecordStoreArray);
            let fieldValue = lastObject['field'];
            if (fieldValue == field) {
                this.filterRecordStoreArray.pop();
                if (this.filterRecordStoreArray.length > 0) {
                    let lastObject = _.last(this.filterRecordStoreArray);
                    let fieldValue = lastObject['field'];
                    let lastSelectedElement = lastObject['selectedEle'];
                    $((this.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
                    lastSelectedElement.classList.add('sml_activeFilter');
                } else {
                    $((this.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
                }
            }
        }


    } else {
        this.sagGridObj.sagFilter = true;
        $((this.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
        if (selectedEle) {
            selectedEle.classList.add('sml_activeFilter');
        }
        if (this.filterRecordStoreArray.length == 0) {
            this.filterRecordStoreArray.push({ "field": field, "totalInputsCheckBox": this.totalCheckBoxTextArray, "checked": checkedArray, "selectedEle": selectedEle, "filterDataArray": filterDataArray });
        } else {
            let lastArrayObject = _.last(this.filterRecordStoreArray);
            let key = lastArrayObject['field'];
            if (key == field) {
                let lastObjectTotalInputsCheckBox = lastArrayObject['totalInputsCheckBox'];
                this.filterRecordStoreArray.pop();
                this.filterRecordStoreArray.push({ "field": field, "totalInputsCheckBox": lastObjectTotalInputsCheckBox, "checked": checkedArray, "selectedEle": selectedEle, "filterDataArray": filterDataArray });

            } else {

                this.filterRecordStoreArray.push({ "field": field, "totalInputsCheckBox": this.totalCheckBoxTextArray, "checked": checkedArray, "selectedEle": selectedEle, "filterDataArray": filterDataArray });
            }

        }

    }


    if (filterDataArray.length > 0) {
        if (self.filterRecordStoreArray.length == 0 && inputVal == "" && $((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput:checked')).length == $((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput')).length) {
            $((this.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
            $('#myInput').val("");
            this.filterInputTextStoreArray = [];
            this.sagGridObj.scrollObj.scrollToTop();
            this.sagGridObj.rowData = this.sagGridObj.originalRowData;
            this.sagGridObj.createGridBody();

        } else {
            this.filter = false;
            self.InnerPopUpCheckBox_ClickEvent();
            this.sagGridObj.scrollObj.scrollToTop();
            let afterSortArr = _.sortBy(filterDataArray, [function(o) { return o.sag_G_Index; }]);
            this.sagGridObj.rowData = afterSortArr;
            this.sagGridObj.createGridBody();
        }

    }

}


Filter.prototype.AllCheckBox_ClickEvent = function(ele) {

    this.checkedTextArray = [];

    var checkboxes = (this.sagGridObj.gridEle).querySelectorAll('input.filterRowInput[type=checkbox]');

    if (ele.checked) {
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type == 'checkbox') {
                checkboxes[i].checked = true;
                let val = checkboxes[i].value;
                this.checkedTextArray.push(val);
            }
        }

    } else {
        for (var i = 0; i < checkboxes.length; i++) {
       
            if (checkboxes[i].type == 'checkbox') {
                checkboxes[i].checked = false;
            }
        }

    }

    var empty = [].filter.call(checkboxes, function(el) {
        return !el.checked
    });

    if (checkboxes.length == empty.length) {
        $((this.sagGridObj.gridEle).querySelector('#btnFilterOkButton')).attr('disabled', 'disabled');
        $((this.sagGridObj.gridEle).querySelector('#allCheckboxBlue')).css('display', 'none');
        $((this.sagGridObj.gridEle).querySelector('#checkAll')).css('display', 'block');
        //return false;
    } else {
        $((this.sagGridObj.gridEle).querySelector('#btnFilterOkButton')).removeAttr('disabled');
    }

}


Filter.prototype.AllCheckBoxRemoveColorBlue_ClickEvent = function(ele) {

    this.checkedTextArray = [];
    $((this.sagGridObj.gridEle).querySelector('#allCheckboxBlue')).css('display', 'none');
    $((this.sagGridObj.gridEle).querySelector('#checkAll')).css('display', 'block');
    $((this.sagGridObj.gridEle).querySelector('.allCheckbox')).prop('checked', true);


    var checkboxes = (this.sagGridObj.gridEle).querySelectorAll('input.filterRowInput[type=checkbox]');


    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].type == 'checkbox') {
            checkboxes[i].checked = true;
            let val = checkboxes[i].value;
            this.checkedTextArray.push(val);
        }
    }

}


Filter.prototype.InnerPopUpCheckBox_ClickEvent = function(ele) {

    if (ele != undefined) {

        let value = ele["value"];

        if (!this.checkedTextArray.includes(value)) {
            this.checkedTextArray.push(value);
        } else {
            var index = this.checkedTextArray.indexOf(value);
            if (index != -1) {
                this.checkedTextArray.splice(index, 1);
            }
        }


    }


    if ($((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput:checked')).length == $((this.sagGridObj.gridEle).querySelectorAll('.filterRowInput')).length) {

        $((this.sagGridObj.gridEle).querySelector('.allCheckbox')).prop('checked', true);
        $((this.sagGridObj.gridEle).querySelector('#allCheckboxBlue')).css('display', 'none');
        $((this.sagGridObj.gridEle).querySelector('#checkAll')).css('display', 'block');


    } else {
        $((this.sagGridObj.gridEle).querySelector('.allCheckbox')).prop('checked', false);
        $((this.sagGridObj.gridEle).querySelector('#allCheckboxBlue')).css('display', 'block');
        $((this.sagGridObj.gridEle).querySelector('#checkAll')).css('display', 'none');

    }


    var textinputs = (this.sagGridObj.gridEle).querySelectorAll('input.filterRowInput[type=checkbox]');
    var empty = [].filter.call(textinputs, function(el) {
        return !el.checked
    });

    if (textinputs.length == empty.length) {
        $((this.sagGridObj.gridEle).querySelector('#btnFilterOkButton')).attr('disabled', 'disabled');
        $((this.sagGridObj.gridEle).querySelector('#allCheckboxBlue')).css('display', 'none');
        $((this.sagGridObj.gridEle).querySelector('#checkAll')).css('display', 'block');

    } else {
        $((this.sagGridObj.gridEle).querySelector('#btnFilterOkButton')).removeAttr('disabled');
    }


}


Filter.prototype.InputTextSearchPopUp_ClickEvent = function(ele) {

    let self = this;
    self.checkedTextArray = [];
    let selectedEle = this.lastSearchEle;
    let field = selectedEle.getAttribute("field");
    let nodeList = this.sagGridObj.originalRowData; //originalRowData;  //rowData	
    let inputVal = (this.sagGridObj.gridEle).querySelector('#myInput').value;
    inputVal = inputVal.toUpperCase();
    if (inputVal != '') {
        self.filterInputTextValue = inputVal;
        selectedEle.classList.add('sml_activeFilter');
        $((self.sagGridObj.gridEle).querySelector('#btnFilterOkButton')).removeAttr('disabled');


        // let allList  = self.paginate(nodeList,7000,1);//self.unique(nodeList, field);	
        let val = inputVal;
        let key = field;
        let arrayList = nodeList;
        let filteredAllList = null; // Array.from(nodeList);	
        self.filterInputTextSearch = nodeList; //Array.from(nodeList);	

        var e = document.getElementById("selectFilter");
        var selectedValue = e.options[e.selectedIndex].value;
        let worker;
        if (typeof(Worker) !== "undefined") {
            if (typeof(worker) == "undefined") {
                GeneralEvent.startLoader();
                var worker_fn = function(e) {
                    self.postMessage('web worker process start');
                };
                var blob = new Blob(["onmessage =" + worker_fn.toString()], { type: "text/javascript" });
                worker = new Worker(window.URL.createObjectURL(blob));

            }

            worker.onmessage = function(event) {
            
                if (typeof(worker) !== "undefined") {
                 


                    if (inputVal != "") {

                        switch (selectedValue) {

                            case "StartWith":

                                filteredAllList = arrayList.filter(function(item) {
                                    return (String(item[field]).toLowerCase()).startsWith(inputVal.toLowerCase());
                                });

                                break;
                            case "EndWith":
                                filteredAllList = arrayList.filter(function(item) {
                                    return (String(item[field]).toLowerCase()).endsWith(inputVal.toLowerCase());
                                });
                                break;
                            case "Contains":
                                filteredAllList = arrayList.filter(function(item) {
                                    return ((String(item[field]).toLowerCase()).indexOf(inputVal.toLowerCase()) > -1);
                                });

                                break;
                            case "Equals":
                                filteredAllList = arrayList.filter(function(item) {
                                    return ((String(item[field]).toLowerCase()) == (inputVal.toLowerCase()));
                                });
                                break;
                            case "NotEquals":
                                filteredAllList = arrayList.filter(function(item) {
                                    return ((String(item[field]).toLowerCase()) != (inputVal.toLowerCase()));
                                });

                                break;

                        }
                    
                        if (filteredAllList.length > 0) {
                            $('#filterScroll').empty();
                            $((self.sagGridObj.gridEle).querySelector('#filterScroll')).append(self.createInnerPopUpRecord(filteredAllList, field));
                            let checkboxNodeList = (self.sagGridObj.gridEle).querySelectorAll('.filterRow input[type="checkbox"]');
                            for (let i = 0, len = checkboxNodeList.length; i < len; i++) {
                                let ele = checkboxNodeList[i];
                                $(ele).removeClass("filterRow");
                                ele.addEventListener("click", function() {
                                    self.InnerPopUpCheckBox_ClickEvent(ele);
                                }, false);
                            }
                            self.InnerPopUpCheckBox_ClickEvent();

                        } else {
                            $('#myInput').val("");
                            self.filterInputTextValue = null;
                            $((self.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
                            alert("TEXT NOT MATCH");
                        }

                    }

                    GeneralEvent.stopLoader();
                    worker.terminate();
                    worker = undefined;

                }
            }
            worker.postMessage("start");
        }
    } else {
        self.filterInputTextValue = null;
        $((self.sagGridObj.gridEle).querySelectorAll(".sagGridFilter")).removeClass("sml_activeFilter");
    }
}


Filter.prototype.startWithStr = function(searchVal, fieldName) {

    let dataArray = this.filterInputTextSearch;
    let val = searchVal;
    let key = fieldName;

    let filtered = dataArray.filter(function(item) {
        return (String(item[key]).toLowerCase()).startsWith(val.toLowerCase());
    });

    return filtered;

}

Filter.prototype.endWithStr = function(searchVal, fieldName) {

    let dataArray = this.filterInputTextSearch;
    let val = searchVal;
    let key = fieldName;

    let filtered = dataArray.filter(function(item) {
        return (String(item[key]).toLowerCase()).endsWith(val.toLowerCase());
    });

    return filtered;

}

Filter.prototype.containStr = function(searchVal, fieldName) {

    let dataArray = this.filterInputTextSearch;
    let val = searchVal;
    let key = fieldName;

    let filtered = dataArray.filter(function(item) {
        return ((String(item[key]).toLowerCase()).indexOf(val.toLowerCase()) > -1);
    });
    return filtered;

}

Filter.prototype.equalStr = function(searchVal, fieldName) {

    let dataArray = this.filterInputTextSearch;
    let val = searchVal;
    let key = fieldName;

    let filtered = dataArray.filter(function(item) {
        return ((String(item[key]).toLowerCase()) == (val.toLowerCase()));
    });
    return filtered;

}

Filter.prototype.notEqualStr = function(searchVal, fieldName) {

    let dataArray = this.filterInputTextSearch;
    let val = searchVal;
    let key = fieldName;

    let filtered = dataArray.filter(function(item) {
        return ((String(item[key]).toLowerCase()) != (val.toLowerCase()));
    });
    return filtered;

}

Filter.prototype.unique = function(arr, prop) {
    return arr.map(function(e) { return e[prop]; }).filter(function(e, i, a) {
        return i === a.indexOf(e);
    });
}