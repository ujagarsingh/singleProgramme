/**
 * @Event list 
 *  1.) @setSelectedRowIndex event for set selected row index to grid data using @param index 
 *  2.) @getCurrentPageNo is static method to send page no. it's create to prevent  method not defined in old grid error.
 *  3.) @getSelectedRowIndex event return selected row of index @param index is not necessarry to give only for prevent error from old grid code. 
 *  4.) @setGridHight event is to set dynamic height of grid. give only for prevent error from old grid code. 
 *  5.) @setPageNumberSaveState event is dummy event. give only for prevent error from old grid code. 
 *  6.) @getSeletedRowData event send the selected row JSON object .
 *  7.) @setRowSelected event set selected row and heightlight this row @param var_index index fo row @param status not necesary.
 *  8.) @getCheckedDataParticularColumnWise This function for get data according to checked data @param paramKey not necessary
 *  9.) @getGridData This Method for Get All Grid Data Its return An Json Array
 * 10.) @defaultSearchEnable dummy method to prevent error from old grid 
 * 11.) @goAnyWherePage Method for going to any page pass page number. dummy method to prevent error from old grid 
 * 12.) @addRow This eventt For Insert last row @var_index not necessary @json JSON object of new row
 * 13.) @deleteLastRow This method For delete last row
 * 14.) @setRowProperty This method for setRow Property rowJson like that format {"color":"red"} it will set tr attribute
 * 15.) @setColRowProperty This method for set cell Property. Json like that format {"color":"red"} it will set tr attribute
 * 16.) @setColProperty This method for set column Property rowJson like that format {"color":"red"} it will set tr attribute
 * 17.) @getRowData This Method For Getting Particular Row Data Need To pass index of a row and index is start with 0
 * 18.) @deleteRow This Method for delete particular row take argument is rowIndex
 * 19.) @updateRow This method for Update Row argument rowIndex and update Json with field name key
 * 20.) @disableColumn event for disable column from grid @param colKey field of column
 * 21.) @enableColumn event for enable column from grid @param colKey field of column
 * 22.) @disableCell event for disable cell from grid @param index row index @colKey field of column
 * 23.) @enableCell event for enable cell from grid @param index row index @colKey field of column
 * 24.) @focusCell set focus as a active element in html DOM  @param index row index @colKey field of column
 * 25.) @highlightColumn heighlight cell with given color in grid html DOM  @param index row index @colKey field of column @colorCode color code of color defalut is #ec8080
 * 26.) @checkRow for check grid row from outside @param Row_index_Arr is array of index
 * 27.) @disableGrid for disable grid
 * 28.) @enableGrid for enable grid
 * 29.) @getTotalOfAllRow event get total row in @return JSON object 
 * 30.) @updateTotalTD event for update total of all rows after change data  row in @return JSON object
 * 31.) @validate check every cell data is valid or not using given regex
 * 32.) @getError get all not valid cell data
 * 33.) @setComment on any cell by @param index row index and @param column field value 
 * 34.) @expandAll all expend all rows if row by grouping in given in grid
 * 35.) @collapseAll all collapse all rows if row by grouping in given in grid
 * 36.) @deleteMultipleRow This Method for delete multiple row take argument is rowIndex Array  
 * 37.) @updateCell This method for Update Cell argument rowIndex, column field and update value
 * 38.) @isValidate check every cell data is valid or not using given regex @return true if valide otherwise false 
 * 39.) @disableRow event for disable row from grid @param index row index
 * 40.) @enableRow event for disable row from grid @param index row index 
 * 41.) @disableAllRow event for disable all row from grid 
 * 42.) @enableAllRow event for enable all row from grid 
 * 43.) @addRowByIndex This eventt For Insert  row in  index @var_index insert index @json JSON object of new row 
 * 44.) @addColumn This eventt For add column  in grid  @json JSON object of new column 
 * 45.) @deleteColumn This eventt For delete column  in grid  @field column key of deleted column
 * 46.) @getSeletedCellData This event for get selected cell data 
 * 47.) @getColumnLength This eventt For get column length from grid  
 * 48.) @getAllColumns This eventt For get all column array  from grid  
 * 49.) @columnHeaderChange this event column header text chnage get index position.
 * 50.) @columnHeaderPositionChange This method for Update Header Position argument Index, get current index  get index position
 * 51.) @columnHeaderHide This eventt For get column field hide column in grid 
 * 52.) @collapseByIndex This method for collapse row  by argument rowIndex
 * 53.) @expandByIndex This method for expand row  by argument rowIndex
 * 54.) @insertRow This method for Update Row argument rowIndex, Row Object  add New Row
 * 55.) @deleteCellValue This method for delete cell value  argument rowIndex, column key  add New Row
 * 56.) @getCheckedRowIndexArrBycol This methods is to get the checked array of specified column given by the @param col this col is column name
 * 57.) @hideColumn This method for hide column 
 * 58.) @showColumn This method for show column
 * 59.) @expandRowByIndexArray array rows expend rows if row by grouping in given in grid 
 /*
 /*



/**
 *Grid event which is call from out side of grid. to get any data  and call any functionality according to condition. 
 * @param sagGridObj
 * @returns
 */
function GridEvent(sagGridObj) {
    this.sagGridObj = sagGridObj;
    this.selectedRowINdex = null;
    this.disabledCell = {};
    this.disabledRow = [];
    this.selectedCellData = null;
}

/**
 * @setSelectedRowIndex event for set selected row index to grid data using @param index 
 *  */
GridEvent.prototype.setSelectedRowIndex = function(index) {
    this.selectedRowINdex = parseInt(index);
}

/**
 * @setSelectedCellIndex event for set selected cell index to grid data using @param index 
 *  */
GridEvent.prototype.setSelectedCellIndex = function(obj) {
        this.selectedCellData = obj;
    }
    /**
     * @getSeletedCellData This event for get selected cell data 
     */
GridEvent.prototype.getSeletedCellData = function() {
    if (this.selectedCellData != null && Object.keys(this.selectedCellData).length !== 0) {
        return this.selectedCellData;
    } else {
        console.error("No cell Selected");
        return null;
    }
}


/** 
 * @getCurrentPageNo is static method to send page no. it's create to prevent  method not defined in old grid error.
 */
GridEvent.prototype.getCurrentPageNo = function() {
    return 1;
}

/** 
 * @getSelectedRowIndex event return selected row of index @param index is not necessarry to give only for prevent error from old grid code. 
 */
GridEvent.prototype.getSelectedRowIndex = function() {
    let returnIndex = parseInt(this.selectedRowINdex);
    if (returnIndex == undefined || isNaN(returnIndex)) {
        returnIndex = -1;
    }
    return returnIndex;
}

/** 
 * @setGridHight event is to set dynamic height of grid. give only for prevent error from old grid code. 
 */
GridEvent.prototype.setGridHight = function(param) {
    /*

    	//set grid height
    	 var totalHeight = headerHeight = pageHeaderHeaight = pageHeaderHeaight =  bottomLineHeight  =  sagButtonLine  =  tableGridHeaderFirst =  tableGridHeaderSecond  = footerGridHeight = tableGridTotalHeight = calculateHeight = sagFieldSecHeight =  sagtabsSectionNav = sagtabsSection2Nav = null;
    	 totalHeight = $(window).outerHeight(true);
    	 var outerHeight = 0;
    	 headerHeight = $('.site-header').outerHeight();
    	 pageHeaderHeaight = $('.page-content-header').outerHeight();
    	 sagFieldSecHeight = $('.sagFieldSec').outerHeight();
    	 sagtabsSectionNav = $('.tabs-section-nav').outerHeight();
    	 sagtabsSection2Nav = $('.tabs-section-nav-2').outerHeight();
    	 bottomLineHeight = $('.bottomline').outerHeight();
    	 sagButtonLine = $('.sagbootom-Line').outerHeight();
    	 outerHeight = headerHeight + pageHeaderHeaight + sagFieldSecHeight + sagtabsSectionNav + bottomLineHeight + sagButtonLine + sagtabsSection2Nav;

    	// tableGridHeaderFirst = $('.drag-div').outerHeight();
    	// tableGridHeaderSecond = $('#gridHeader').outerHeight();
    	// footerGridHeight = $('.footerGrid').outerHeight();

    	// tableGridTotalHeight = tableGridHeaderFirst + tableGridHeaderSecond + footerGridHeight;

    	 calculateHeight = totalHeight - outerHeight ;
    	 let sourceDiv = this.sagGridObj.gridEle;
    	 $(sourceDiv).parents(".masterdiv").height(calculateHeight);
    	 
    	*/

}

/** 
 * @setPageNumberSaveState event is dummy event. give only for prevent error from old grid code. 
 */
GridEvent.prototype.setPageNumberSaveState = function(param) {
    console.warn("setPageNumberSaveState function is not working");
}


/** 
 * @getSeletedRowData event send the selected row JSON object . 
 */
GridEvent.prototype.getSeletedRowData = function() {
    if (this.selectedRowINdex != null && this.selectedRowINdex > -1) {
        var obj = this.sagGridObj.originalRowData[this.selectedRowINdex];
        return obj;
    } else {
        console.error("No Row Selected");
        return null;
    }
}


/** 
 * @setRowSelected event set selected row and heightlight this row @param var_index index fo row @param status not necesary  . 
 */
GridEvent.prototype.setRowSelected = function(var_index, status) {
    this.selectedRowINdex = var_index;
    this.sagGridObj.generalEvntObj.selectRowClrChange(this.selectedRowINdex);
    this.sagGridObj.scrollObj.scrollToIndex(var_index);
}

/**
 * @getCheckedDataParticularColumnWise This function for get data according to checked data @param paramKey not necessary
 * */
GridEvent.prototype.getCheckedDataParticularColumnWise = function(paramKey) {

    let self = this;
    let orgArray = self.sagGridObj.originalRowData;
    let dataArray = orgArray.filter(function(item) {
        let index = item["sag_G_Index"];
        if (self.sagGridObj.checkedRowIdArray.includes(index)) {
            return item;
        }
    });
    return dataArray;

}



/** @getGridData 
/* @getGridData This Method for Get All Grid Data Its return An Json Array and All Json key is equal of 
* that field which is define in column Json when set first time
* return Data 
* 
* Note : if Pagging apply then it will return page wise all data
* 		  in that case use  getAllPageData ()
*/
GridEvent.prototype.getGridData = function() {
    let self = this;
    let orgArray = self.sagGridObj.originalRowData;
    letObj = JSON.parse(JSON.stringify(orgArray));
    if (self.sagGridObj.rowGrouping) {
        letObj = _.filter(letObj, function(o) { return o.RG_P_REF_ID == "Super"; })
    }
    return letObj;
}

/**35
 * @defaultSearchEnable dummy method to prevent error from old grid 
 */
GridEvent.prototype.defaultSearchEnable = function(var_columnKey) {


}

/**
 * 53@goAnyWherePage Method for going to any page pass page number. dummy method to prevent error from old grid 
 **/

GridEvent.prototype.goAnyWherePage = function(pageNumber) {


}


/**8.@addRow This eventt For Insert last row @var_index not necessary @json JSON object of new row */
GridEvent.prototype.addRow = function(var_index, json) {

    let gridHeightEle = (this.sagGridObj.gridEle).querySelectorAll('.gridTHeight');
    let oldHeight = $(gridHeightEle).css("height");
    let newHeight = Number((oldHeight.split("px"))[0]) + this.sagGridObj.OneRowHeight;
    $(gridHeightEle).css("height", newHeight);

    let last_index = this.sagGridObj.originalRowData.length + 1;

    let var_rowJsonData = Object.assign({}, json);
    var_rowJsonData["sag_G_Index"] = last_index;

    //var_rowJsonData["groupName"] = last_index;
    this.sagGridObj.originalRowData.push(var_rowJsonData);

    //reset data 
    this.sagGridObj.resetGridData();

    //let scrollObj = new Scroll(this.sagGridObj);
    // this.sagGridObj.scrollObj.setRowLen(last_index);
    this.sagGridObj.scrollObj.addRowByIndex(last_index - 1);
    this.sagGridObj.scrollObj.resetScroll();
    this.sagGridObj.scrollObj.scrollToIndex(last_index - 1);

}

/**8.@addRowByIndex This eventt For Insert  row in  index @var_index insert index @json JSON object of new row */
GridEvent.prototype.addRowByIndex = function(var_index, json) {

    let var_rowJsonData = Object.assign({}, json);
    this.sagGridObj.originalRowData = GeneralEvent.insertInArray(this.sagGridObj.originalRowData, var_index, var_rowJsonData);
    //reset data 
    this.sagGridObj.resetGridData();
    this.sagGridObj.createGridBody();
}

/**8.@addColumn This eventt For add column  in grid  @json JSON object of new column */

GridEvent.prototype.addColumn = function(json) {
    var colkey = json.field;
    this.sagGridObj.originalRowData = this.sagGridObj.originalRowData.map(function(el) {
        var o = Object.assign({}, el);
        if (!o.hasOwnProperty(colkey)) {
            o[colkey] = "";
        }
        return o;
    })
    this.sagGridObj.originalColData.push(json);
    this.sagGridObj.resetGridBody();
}

/**8.@deleteColumn This eventt For delete column  in grid  @field column key of deleted column */
GridEvent.prototype.deleteColumn = function(field) {
    this.sagGridObj.originalRowData = this.sagGridObj.originalRowData.map(function(el) {
        delete el[field];
        return el;
    })
    this.sagGridObj.originalColData = _.filter(this.sagGridObj.originalColData, function(o) { return o.field != field; });
    this.sagGridObj.resetGridBody();

}


/**8. @deleteLastRow This method For delete last row  */
GridEvent.prototype.deleteLastRow = function() {

    let gridHeightEle = (this.sagGridObj.gridEle).querySelectorAll('.gridTHeight');
    let oldHeight = $(gridHeightEle).css("height");
    let newHeight = Number((oldHeight.split("px"))[0]) - this.sagGridObj.OneRowHeight;
    $(gridHeightEle).css("height", newHeight);

    let last_index = this.sagGridObj.originalRowData.length;

    this.sagGridObj.originalRowData.pop();

    this.sagGridObj.resetGridData();

    //let scrollObj = this.sagGridObj;  //new Scroll(this.sagGridObj);
    this.sagGridObj.scrollObj.resetScroll();
    this.sagGridObj.scrollObj.scrollToIndex(last_index);
    this.sagGridObj.scrollObj.deleteRowByIndex(last_index);
}


/**9. @setRowProperty This method for setRow Property rowJson like that format {"color":"red"} it will set tr attribute */
GridEvent.prototype.setRowProperty = function(var_rowIndex, var_rowJson) {
    this.sagGridObj.generalEvntObj.setRowStyleProperty(var_rowIndex, var_rowJson);
    this.sagGridObj.setRowPropertyObj[var_rowIndex] = var_rowJson;
}

/**10. @setColRowProperty This method for set cell Property. Json like that format {"color":"red"} it will set tr attribute */
GridEvent.prototype.setColRowProperty = function(var_rowIndex, var_colKey, var_rowJson) {
    this.sagGridObj.generalEvntObj.setColRowStyleProperty(var_rowIndex, var_colKey, var_rowJson);
    this.sagGridObj.setColRowPropertyObj[var_rowIndex + "_" + var_colKey] = var_rowJson;
}

/**11.@setColProperty This method for set column Property rowJson like that format {"color":"red"} it will set tr attribute */
GridEvent.prototype.setColProperty = function(var_colKey, var_rowJson) {
    this.sagGridObj.generalEvntObj.setColStyleProperty(var_colKey, var_rowJson);
    this.sagGridObj.setColPropertyObj[var_colKey] = var_rowJson;
}


/**3. @getRowData This Method For Getting Particular Row Data Need To pass index of a row and index is start with 0 **/
GridEvent.prototype.getRowData = function(var_rowIndex) {
    let rowJson = this.sagGridObj.originalRowData[var_rowIndex];
    return rowJson;
}


/**5. @deleteRow This Method for delete particular row take argument is rowIndex */
GridEvent.prototype.deleteRow = function(var_rowIndex) {
    if (var_rowIndex > -1) {
        this.sagGridObj.originalRowData.splice(var_rowIndex, 1);
        this.sagGridObj.resetGridData();
        this.sagGridObj.createGridBody();
    } else {
        console.error("Error to Delete row" + var_rowIndex);
    }

    /**let gridHeightEle = (this.sagGridObj.gridEle).querySelectorAll('.gridTHeight');
	let oldHeight = $(gridHeightEle).css("height");
	let newHeight = Number((oldHeight.split("px"))[0]) - this.sagGridObj.OneRowHeight;
	$(gridHeightEle).css("height",newHeight);
		
	let last_index = this.sagGridObj.originalRowData.length;

	this.sagGridObj.originalRowData.splice(var_rowIndex, 1);
	
	this.sagGridObj.resetGridData();

	 let scrollObj = this.sagGridObj;  //new Scroll(this.sagGridObj);
	 this.sagGridObj.scrollObj.resetScroll();
	// this.sagGridObj.scrollObj.scrollToIndex(last_index);
	 this.sagGridObj.scrollObj.deleteRowByIndex(var_rowIndex);
	 **/
}




/**6.@updateRow This method for Update Row argument rowIndex and update Json with field name key */
GridEvent.prototype.updateRow = function(var_rowIndex, var_updateJson) {
    //this.sagGridObj.originalRowData[var_rowIndex] = var_updateJson;
    for (var key in var_updateJson) {
        if (var_updateJson.hasOwnProperty(key)) {
            var val = var_updateJson[key];
            if (this.sagGridObj.rowGrouping) {
                this.sagGridObj.rowData[var_rowIndex][key] = val;
            } else {
                this.sagGridObj.originalRowData[var_rowIndex][key] = val;
            }
        }
    }
    this.sagGridObj.scrollObj.deleteRowByIndex(var_rowIndex);
    //this.sagGridObj.resetGridData();
    this.sagGridObj.scrollObj.addRowByIndex(var_rowIndex);
}


/** @disableColumn event for disable column from grid @param colKey field of column*/
GridEvent.prototype.disableColumn = function(colKey) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_key="' + colKey + '"]');
    let obj = _.find(this.sagGridObj.colData, {
        'field': colKey
    });
    obj["disable"] = true;
    $(allCol).addClass('sml_disable');
    let header = (this.sagGridObj.gridEle).querySelectorAll('[colfield="' + colKey + '"]');
    $(header).addClass('sml_disable');

}

/** @enableColumn event for enable column from grid @param colKey field of column*/
GridEvent.prototype.enableColumn = function(colKey) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_key="' + colKey + '"]');
    let obj = _.find(this.sagGridObj.colData, {
        'field': colKey
    });
    obj["disable"] = false;
    $(allCol).removeClass('sml_disable');
    let header = (this.sagGridObj.gridEle).querySelectorAll('[colfield="' + colKey + '"]');
    $(header).removeClass('sml_disable');
}

/** @disableRow event for disable row from grid @param index row index*/
GridEvent.prototype.disableRow = function(index) {
    let allRow = (this.sagGridObj.gridEle).querySelectorAll('[saggridrowid="' + index + '"]');
    this.disabledRow.push(index);
    $(allRow).addClass('sml_disable');
}

/** @enableRow event for disable row from grid @param index row index */
GridEvent.prototype.enableRow = function(index) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[saggridrowid="' + index + '"]');
    var rmInd = this.disabledRow.indexOf(index);
    if (rmInd !== -1) {
        this.disabledRow.splice(rmInd, 1);
        $(allCol).removeClass('sml_disable');
    }
}

/** @disableAllRow event for disable all row from grid */
GridEvent.prototype.disableAllRow = function() {
    let allRowHtml = (this.sagGridObj.gridEle).querySelectorAll('.mainDivTbodySecond');
    $(allRowHtml).addClass('sml_disable');
}

/** @enableAllRow event for enable all row from grid */
GridEvent.prototype.enableAllRow = function() {
    let allRowHtml = (this.sagGridObj.gridEle).querySelectorAll('.mainDivTbodySecond');
    $(allRowHtml).removeClass('sml_disable');
}


/** @enableCell event for enable cell from grid @param index row index @colKey field of column*/
GridEvent.prototype.enableCell = function(index, colKey) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + index + '"][sag_g_key="' + colKey + '"]');
    let key = index + "_" + colKey;
    this.disabledCell[key] = false;
    $(allCol).removeClass('sml_disable');
}

/** @disableCell event for disable cell from grid @param index row index @colKey field of column*/
GridEvent.prototype.disableCell = function(index, colKey) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + index + '"][sag_g_key="' + colKey + '"]');
    let key = index + "_" + colKey;
    this.disabledCell[key] = true;
    $(allCol).addClass('sml_disable');
}

/** @focusCell set focus as a active element in html DOM  @param index row index @colKey field of column*/
GridEvent.prototype.focusCell = function(index, colKey) {
    $((this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + index + '"][sag_g_key="' + colKey + '"]')).addClass("grid_cell_selected").focus();
}


/** @highlightColumn heighlight cell with given color in grid html DOM  @param index row index @colKey field of column @colorCode color code of color defalut is #ec8080*/
GridEvent.prototype.highlightColumn = function(var_rowIndex, var_colKey, colorCode) {
    if (colorCode == undefined) {
        colorCode = "#ec8080";
    }
    let borderVal = "2px solid " + colorCode;
    let styleJson = { "border": borderVal };
    this.setColRowProperty(var_rowIndex, var_colKey, styleJson);
}

/** @checkRow for check grid row from outside @param Row_index_Arr is array of index  */
GridEvent.prototype.checkRow = function(Row_index_Arr) {

    for (var i = 0; i < Row_index_Arr.length; i++) {
        let index = Row_index_Arr[i];
        let rowCheckbox = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + index + '"][sag_g_key="checkBox"]')[0];
        (rowCheckbox.getElementsByClassName('sag-CheckboxCls')[0]).click();
    }
}


/**@disableGrid for disable grid  */
GridEvent.prototype.disableGrid = function() {
    $(this.sagGridObj.gridEle).addClass('sml_disable');
}

/**@enableGrid for enable grid  */
GridEvent.prototype.enableGrid = function() {
    $(this.sagGridObj.gridEle).removeClass('sml_disable');
}

/**@getTotalOfAllRow event get total row in @return JSON object   */
GridEvent.prototype.getTotalOfAllRow = function() {
    return this.sagGridObj.totalFooterCol;
}


/**@updateTotalTD event for update total of all rows after change data  row in @return JSON object   */
GridEvent.prototype.updateTotalTD = function() {
    this.sagGridObj.sagGridEvent.showFooterSum();
}

/**
 * @validate check every cell data is valid or not using given regex  
 */
GridEvent.prototype.validate = function() {
    this.sagGridObj.validationObj.validate();
}

/**
 * @isValidate check every cell data is valid or not using given regex @return true if valide otherwise false 
 */
GridEvent.prototype.isValidate = function() {
    return this.sagGridObj.validationObj.isValidate();
}

/**
 * @getError get all not valid cell data   
 */
GridEvent.prototype.getError = function() {
    return this.sagGridObj.validationObj.getError();
}

/**
 * @setComment on any cell by @param index row index and @param column field value  
 * */
GridEvent.prototype.setComment = function(index, col, val) {
    if (this.sagGridObj.cellCommentObj) {
        this.sagGridObj.cellCommentObj.setComment(index, col, val);
    }
}

/** @expandAll all expend all rows if row by grouping in given in grid */
GridEvent.prototype.expandAll = function() {

    this.sagGridObj.rowData = _.orderBy(this.sagGridObj.RG_AllData, ['RG_INDEX'], ['asc']);
    //this.sagGridObj.resetGridData();
    this.sagGridObj.expandRow = _.flatMap(this.sagGridObj.RG_AllData, function(o) {
        return [o.RG_INDEX];
    });
    this.sagGridObj.rowData = this.sagGridObj.rowData.map(function(x, indx) {
        x["ROW_INDEX"] = indx;
        return x;
    });
    this.sagGridObj.createGridBody();
}

/** @expandRowByIndexArray array rows expend rows if row by grouping in given in grid */
GridEvent.prototype.expandRowByIndexArray = function(roWIndexArray) {

    let self = this;
    if (self.sagGridObj.expandRow.length > 0) {
        self.sagGridObj.expandRow.map(function(value, index) {
            rowIndex = roWIndexArray[index];
            let childArray = _.filter(self.sagGridObj.RG_AllData, {
                'RG_P_REF_ID': value,
            });
            self.sagGridObj.rowData.splice(rowIndex + 1, 0, ...childArray);
        });
    }
    self.sagGridObj.rowData = self.sagGridObj.rowData.map(function(x, indx) {
        x["ROW_INDEX"] = indx;
        return x;
    });
    let pre = self.sagGridObj.scrollObj.getScrollPos();
    self.sagGridObj.createGridBody();
    self.sagGridObj.scrollObj.setScrollPos(pre);

}

/** @collapseAll all collapse all rows if row by grouping in given in grid */
GridEvent.prototype.collapseAll = function() {
    //this.sagGridObj.resetGridData();
    this.sagGridObj.rowData = [];
    this.sagGridObj.rowData = RowGroup.getParentData(this.sagGridObj.RG_AllData);
    this.sagGridObj.rowData = this.sagGridObj.rowData.map(function(x, indx) {
        x["ROW_INDEX"] = indx;
        return x;
    });
    this.sagGridObj.expandRow = [];
    this.sagGridObj.createGridBody();
}

/**. @deleteMultipleRow This Method for delete multiple row take argument is rowIndex Array */
GridEvent.prototype.deleteMultipleRow = function(deletedIndexArr) {
    for (let i = 0; i < deletedIndexArr.length; i++) {
        let var_rowIndex = deletedIndexArr[i];
        if (var_rowIndex > -1) {
            this.sagGridObj.originalRowData = _.filter(this.sagGridObj.originalRowData, function(o) { return o.sag_G_Index != var_rowIndex; });
            if (this.sagGridObj.originalRowData.length == 0) {
                $((this.sagGridObj.gridEle).querySelectorAll(".sagRow")).remove();
                let gridHeightEle = (this.sagGridObj.gridEle).querySelectorAll('.gridTHeight');
                $(gridHeightEle).css("height", "0px");
            }
        } else {
            console.error("Error to Delete row" + var_rowIndex);
        }
    }
    this.sagGridObj.resetGridData();
    this.sagGridObj.createGridBody();
}


/**@updateCell This method for Update Cell argument rowIndex, column field and update value*/
GridEvent.prototype.updateCell = function(var_rowIndex, colKey, value) {
    if (this.sagGridObj.rowGrouping && this.sagGridObj.rowData.length >= var_rowIndex) {
        this.sagGridObj.rowData[var_rowIndex][colKey] = value;
        this.sagGridObj.GridColObj.updateCol(var_rowIndex, colKey);
    } else if (this.sagGridObj.rowData.length >= var_rowIndex) {
        this.sagGridObj.rowData[var_rowIndex][colKey] = value;
        this.sagGridObj.GridColObj.updateCol(var_rowIndex, colKey);
    } else {
        this.sagGridObj.originalRowData[var_rowIndex][colKey] = value;
    }

}

/**@deleteCellValue This method for delete cell value  argument rowIndex, column key  add New Row*/
GridEvent.prototype.deleteCellValue = function(var_rowIndex, colKey) {
    this.sagGridObj.rowData[var_rowIndex][colKey] = "";
    this.sagGridObj.GridColObj.updateCol(var_rowIndex, colKey);

}


/**@collapseByIndex This method for collapse row  by argument rowIndex*/
GridEvent.prototype.collapseByIndex = function(var_rowIndex) {
    //let obj = this.sagGridObj.RG_AllData[var_rowIndex];
    let obj = _.filter(this.sagGridObj.RG_AllData, { 'sag_G_Index': var_rowIndex, })[0];
    let lvl = obj.RG_Level;
    this.sagGridObj.sagGridEvent.onCollapse(var_rowIndex, var_rowIndex, lvl);
}


/**@expandByIndex This method for expand row  by argument rowIndex*/
GridEvent.prototype.expandByIndex = function(var_rowIndex) {
    let obj = _.filter(this.sagGridObj.RG_AllData, { 'sag_G_Index': var_rowIndex, })[0];
    let lvl = obj.RG_Level;
    this.sagGridObj.sagGridEvent.onExpand(var_rowIndex, var_rowIndex, lvl);
}



/** @getColumnLength This eventt For get column length from grid  */
GridEvent.prototype.getColumnLength = function() {
    let colLength = this.sagGridObj.originalColData.length;
    return colLength;
}


/**@getAllColumns This eventt For get all column array  from grid  */
GridEvent.prototype.getAllColumns = function() {
    return this.sagGridObj.originalColData;
}


/**@columnHeaderChange This method for Update Cell argument rowIndex, column field and update value*/
GridEvent.prototype.columnHeaderChange = function(colfield, headerText) {

    this.sagGridObj.originalColData = this.sagGridObj.originalColData.map(function(x, indx) {
        if (x["field"] == colfield) { x["header"] = headerText; };
        return x;
    });
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();

}

/**@columnHeaderPositionChange This method for Update Cell argument rowIndex, column field and update value*/
GridEvent.prototype.columnHeaderPositionChange = function(from, to) {

    let colData = this.sagGridObj.originalColData.splice(from, 1)[0]; // cut the element at index 'from'
    this.sagGridObj.originalColData.splice(to, 0, colData); // insert it at index 'to'
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();
}


/**@columnHeaderHide This method for Update Cell argument rowIndex, column field and update value*/
GridEvent.prototype.columnHeaderHide = function(colfield) {
    this.sagGridObj.originalColData = this.sagGridObj.originalColData.map(function(x, indx) {
        if (x["field"] == colfield) { x["hidden"] = true; };
        return x;
    });
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();
}

/**@hideColumn This method for hide column */
GridEvent.prototype.hideColumn = function(colfield) {
    this.sagGridObj.originalColData = this.sagGridObj.originalColData.map(function(x, indx) {
        if (x["field"] == colfield) { x["hidden"] = true; };
        return x;
    });
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();
}

/**@showColumn This method for show column*/
GridEvent.prototype.showColumn = function(colfield) {
    this.sagGridObj.originalColData = this.sagGridObj.originalColData.map(function(x, indx) {
        if (x["field"] == colfield) { x["hidden"] = false; };
        return x;
    });
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();
}

/**@insertRow This method for Update Row argument rowIndex, Row Object  add New Row*/
GridEvent.prototype.insertRow = function(index, item) {
    if (index > -1) {
        this.sagGridObj.originalRowData.splice(index, 0, item);
        this.sagGridObj.resetGridData();
        this.sagGridObj.createGridBody();
    } else {
        console.error("Error to insert row" + index);
    }
};

/** 
 * @method getCheckedRowIndexArrBycol
 * @param col
 * @description This methods is to get the checked array of specified column given by the parameter.
 */
GridEvent.prototype.getCheckedRowIndexArrBycol = function(col) {
    if (this.sagGridObj.checkedObj.hasOwnProperty(col)) {
        let checkedArr = this.sagGridObj.checkedObj[col];
        return checkedArr;
    } else {
        // console.error("Error while fetching Array", col);
        return []
    }
};


/**3. @getRowData This Method For Getting Particular Row Data Need To pass index of a row and index is start with 0 **/
GridEvent.prototype.getRowDataCollapse = function(ROW_INDEX) {
    let rowJson = this.sagGridObj.rowData[ROW_INDEX];
    return rowJson;
}

/**@updateCell This method for Update Cell argument rowIndex, column field and update value*/
GridEvent.prototype.updateCollapseCell = function(ROW_INDEX, RG_INDEX, colKey, value) {

    this.sagGridObj.rowData[ROW_INDEX][colKey] = value;
    this.sagGridObj.GridColObj.updateCol(ROW_INDEX, colKey);
    this.sagGridObj.originalRowData[RG_INDEX][colKey] = value;

}


/** @updateCellInnerHtml event for updateCellInnerHtml cell from grid @param index row index @colKey field of column and value InnerHTML update*/
GridEvent.prototype.updateCellInnerHtml = function (index, colKey, html) {
    let allCol = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + index + '"][sag_g_key="' + colKey + '"]');
    $(allCol).html(html);
}

GridEvent.prototype.checkDisableCell = function (index, colKey) {
    let checkCell = false;
    let cell = (this.sagGridObj.gridEle).querySelector('[sag_g_index="' + index + '"][sag_g_key="' + colKey + '"]');
    if (cell.classList.contains("sml_disable")) {
        return checkCell = true;
    }
    return checkCell;


} 

GridEvent.prototype.addColumnKeyOriginalRowData = function () {

    let self = this;

    this.sagGridObj.originalColData.map(function (x) {

        var colkey = x["field"];
        self.sagGridObj.originalRowData = self.sagGridObj.originalRowData.map(function (el) {
            var o = Object.assign({}, el);
            if (!o.hasOwnProperty(colkey)) {
                o[colkey] = "";
            }
            return o;
        })
    });

    //this.sagGridObj.resetGridBody();
}


/**@setGridColumnWidth This method for set GridColumn Width colFieldArray:{field:Name,width:150}  */
GridEvent.prototype.setGridColumnWidth = function (colFieldArray) {
    this.sagGridObj.originalColData = this.sagGridObj.originalColData.map(function (x, indx) {
        colFieldArray.find((col) => { if (x["field"] == col.field) { x["width"] = col.width + "px"; } });
        return x;
    });
    this.sagGridObj.createGridHeader();
    this.sagGridObj.resetGridBody();
}



//
////Old Grid method Implements
//
///***1.This Method for Set All Grid Column and Row ,Remove Present Row and Column*
// * Parameter -- 1.ColumnData(JSONArray) 
// * 				2.RowData(JSONArray)
// * return -- null**/
//GridEvent.prototype.setJsonArr = function (var_ColumnData, var_rowData){
//	
//}
//
//

//
//

//
///**4.This method for Highlight Perpouse pass Argument rowIndex and color/color code **/
//GridEvent.prototype.highlightRow = function(var_rowIndex,var_color){
//	
//	
//}
//

//
///**7.This Method For highlight Column */
//GridEvent.prototype.setColumnProperty = function(var_columnJsonArr){
//	
//}
//


//
///**10. search Data and highlight this function is not Complete */
//GridEvent.prototype.search = function(var_coldef, var_searchContain, var_propertyJson){
//	
//}
//
///**11.This Method for Grid Lines*/
//GridEvent.prototype.gridLines = function (var_propertyName){ 
//	
//}
//
///**12.This Method for selection we have 4 selection type - Grid,Cell,Row,Column,Header
// * Parameter -- selectionValue (String)
// * return null**/
//GridEvent.prototype.setSelection = function(var_selection){
//	
//}
//
//
///**13.This Method for SetGridWidth 
// *Parameter -- ValueOfWidth in px,%,vm(String Object) 
// *return null**/
//GridEvent.prototype.setGridWidth = function(var_gridWidth){
//
//}
//
///**14.This Method For GetColumn 
// * Parameter -- columnJsonData (JSONObject) 
// * return -- Array in String Form*/
//GridEvent.prototype.getColumnData = function(var_ColumnJson){
//	
//}
//
///**15.This Method For removeRowProperty 
// * Parameter -- rowIndexValue (int/String)
// * 				propertyName 
// * return -- null*/
//GridEvent.prototype.removeRowProperty = function(var_rowIndex, var_PropertyName){
//	
//}
//
///**16.This Method for SetGridHeight 
// *Parameter -- ValueOfWidth in px,%,vm(String Object) 
// *return null**/
//GridEvent.prototype.setGridHight = function(var_gridHeight){
//	
//}
//
///**17.Parameter --  {currentPage :1,totalPage :10,showRecord:100,nextEnable :true,previousEnable : true,nextOnclick : null,previousOnclick: null,range: 1-10,totalRecord:10,firstOnclick: null,lastOnclick:};
//*return null**/
//GridEvent.prototype.setServerPagingData = function(var_data){
//	
//}
//
///**18.Parameter --  {currentPage :1,totalPage :10,showRecord:100};
//*return null**/
//GridEvent.prototype.getServerPagingData = function(){
//	
//}
//
///**
// * 19
// * */
//GridEvent.prototype.setRowsEventProperty = function(var_rowIndex, var_propertyJson){
//	
//	
//}
//
///**
// * 20
// * */
//GridEvent.prototype.setRowData = function(rowsDataJson){
//	
//}
//
//GridEvent.prototype.setColumnFrezz = function(var_frezzColumn,var_frezzType){
//	
//}
//
// /** 22
// * @parm columnKey is column key which column key based groupping
// * @parm openCloseStatus its status for open and Close if status is null then its default true (mean close with +) and false  
// * */
//GridEvent.prototype.addRowGroupping = function(columnKey,openCloseStatus){
//	 
// }
//
///**23
// * 
// * */
//GridEvent.prototype.removeRowGroupping   = function(columnKey){
//	
//}
///**
// * 24
// * */
//GridEvent.prototype.grouppingStateChange = function(){
//	
//}
///**25
// *  Comming Soon
// * */
//GridEvent.prototype.getSeletedRowData = function(){
//
//}
//
///**26
// *  Comming Soon
// * */
//GridEvent.prototype.setGridEditable = function(var_status){
//	
//	
//}
//
///**27
// *  Comming Soon
// * */
//GridEvent.prototype.setColumnEditableProperty = function(var_columnKey, var_status){
//	
//	
//}
//
///**28
// *  Comming Soon
// * */
//GridEvent.prototype.setRowEditable = function(var_rowIndex , var_status){
//	
//	
//}
//
///**29
// *  Comming Soon
// * */
//GridEvent.prototype.deleteSeletedRowData = function(){
//	
//}
//
///**  Comming Soon
//* */
//GridEvent.prototype.getSelectedRowIndex = function(){
//	
//}
//
///**31
// *  Comming Soon
// * */
//GridEvent.prototype.updateTotal = function(){
//	
//}
//
///**32
// *  Comming Soon
// * */
//GridEvent.prototype.setRowSelected = function(var_index,status){
//	
//	
//}
//
///**33
// *  Comming Soon
// * */ 
//GridEvent.prototype.setPageNumberSaveState = function(selectedPage){
//	
//}
//
///**34
//*  Comming Soon
//* */
//GridEvent.prototype.insertRowAtPostion = function(var_index,dataJsonObj){
//	
//	
//}
//
//
//
///**36
// */
//GridEvent.prototype.resizeEnable = function(){
//	
//	
//}
//
///**37
// */
//GridEvent.prototype.mergeRowWhenSame= function(columnKey){
//	
//	
//}
//

///**39
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.fun_highlightRow=function(selectedIndex){
//	
//	
//}
//
///*******40
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.fun_removeHighlightRow=function(selectedIndex){
//	
//	
//}
//
///*******41
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.fun_highlightRowWithColorNm =function(selectedIndex, colorName){
//	
//}
//
///*** 
// * 42
// ****/
//GridEvent.prototype.setTdTextColor =function(selectedIndex, colorName){
//	
//	
//}
//
///*******43
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.fun_highlightRowBoder =function(selectedIndex, colorName){
//	
//}
//
///*******44
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.fun_removeColumnBorderColor =function(selectedIndex, colorName){
//	
//	
//	
//}
//
///*******45
// * this function  is used to highlight selected row**
// * ***********/
//GridEvent.prototype.conditionMerze = function(var_equalCondColumnKey , merzeColumnKeyArr){
//	
//}
//
///**46
// * */
//GridEvent.prototype.updateTotalContainer = function(var_rowdef) {
//	
//	
//}
//
///**47 A
// * This Method For Export the Data in Excel
// * Here self is this mean self and this is same Object
// * */
//GridEvent.prototype.exportGridDataInExcel = function(){
//	
//}
//
///**48 B
// * This Method For Export the Data in Excel
// * Here self is this mean self and this is same Object
// * */
//GridEvent.prototype.exportGridDataInExcelPageWise = function(){}
//
///**48 C
// * This Method For Export the Data in PDF landscape
// * Here self is this mean self and this is same Object
// * */
//GridEvent.prototype.exportGridDataInPDFLandscape = function(){}
//
///**48 D
// * This Method For Export the Data in Excel
// * Here self is this mean self and this is same Object
// * */
//GridEvent.prototype.exportGridDataInPDFPortrait = function(){}
//
///**
// * 49
// * */
//GridEvent.prototype.exportGridData = function(exportMode,typeOfExp,pageOrient){}
//
///**
// * 50
// * For Get Completed Data 
// * 
// * */
//GridEvent.prototype.getAllPageData = function(){}
//
///**
// * 50.1
// * For Get Completed Data 
// * 
// * */
//GridEvent.prototype.getAllPageData_new = function(){
//	
//}
//
//
///**
// *51 Add by girraj 
// **/
//GridEvent.prototype.rowHeightMange = function(){
//	
//}
//
///**
// * 51
// * @parm dataForColor is JSONArray like ( [{index:[1,2,3],colorCode:"#cccc"},{index:[4,5,6],colorCode:"#eeee"}] )
// * *//*
//GridEvent.prototype.mutliColorInRow = function(dataForColor){
//}*/
//
//
///**
// * 52 Method for go to last page 
// * */
//GridEvent.prototype.goLastPageInGrid = function(){}
//

//
///**
// * 54 For Get Cuurent Page
// * */
//GridEvent.prototype.getCurrentPageNo = function(){}
//
///**
// * 55 For Get Cuurent Page
// * */
//GridEvent.prototype.scrollLock = null;
//GridEvent.prototype.manageScroll = function(var_pram){}
//
//
///**
// * 56 For get Row Unique Id for Futhure USe  
// */
//GridEvent.prototype.getSelectedRowGridId = function (){}
//
///**
// * 57 This Method is Called For Selected Row Using Row id 
// * */
//GridEvent.prototype.setRowSelectedUsingRowId  = function(rowid){}
//
//
///**
// * 58 This Method is column add for hide column show hide   
// * */
//
//GridEvent.prototype.hideShowColum = function(){}
//
//
///**
// * 59 This Method is keydown for left, right, up and down   
// * */
//var currentColumn = 0;
//	
//GridEvent.prototype.fun_table = function(e) {}
//
///**
// * 60 This Method is select Data for allWise and PageWise  
// * */
//
//GridEvent.prototype.allPagewiseDataSelect = function(e,getHeaderTable){}
//
///**
// * This function is checked column grouping case is enabled or not if
// * enabled then its return true otherwise it will return false
// */
//GridEvent.prototype.checkColumnArrayForColumnGroupping = function (columnArrayJson){}
//
//
///**
// * get checkbox data from grid according to checkbox start
// */
//GridEvent.prototype.enableCheckboxPageWise = function(){}
//

///**
// * Disabled Enabled Key event
// * */
//GridEvent.prototype.enableKeyBoard = function(flag){}
//	
//