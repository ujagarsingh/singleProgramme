
function CellComment(sagGridObj){

    this.sagGridObj = sagGridObj;
    this.cellCommentObj = {};
    if(sagGridObj.cellComments.hasOwnProperty("onSelect")){
      this.onSelectFn = sagGridObj.cellComments.onSelect;
    }

    if(sagGridObj.cellComments.hasOwnProperty("data")){
        let CellCommentData = sagGridObj.cellComments.data;
        for(let i=0;i<CellCommentData.length;i++){
            let obj = CellCommentData[i];
            let key = obj["index"]+"_"+obj["column"];
            let val = obj["value"];
            this.cellCommentObj[key] = val;
        }
    }
}

CellComment.prototype.setComment = function(index,col,val){
    let self= this;
    let key = index+"_"+col;
    if(val == ""){
        delete this.cellCommentObj[key];
        $((self.sagGridObj.gridEle).querySelector(".grid_cell_selected")).removeClass("sml_comment_i");
    }else{
        $((self.sagGridObj.gridEle).querySelector(".grid_cell_selected")).addClass("sml_comment_i");
        this.cellCommentObj[key] = val;
    }
}

CellComment.prototype.onF3Press = function(index,col){
    let key = index+"_"+col;
    if(this.cellCommentObj.hasOwnProperty(key)){
        let val = this.cellCommentObj[key];
        if(this.onSelectFn){
            let obj = {"index":index,"column":col,"value":val};
            this.onSelectFn(obj);
        }
    }else{
        let val = "";
        if(this.onSelectFn){
            let obj = {"index":index,"column":col,"value":val};
            this.onSelectFn(obj);
        }
    }
}

/**
 * calling 
 *    rowSelection:true,
      cellSelectionLtoR:true,
      cellComments:{
          "onSelect":function(obj){
            console.log("success");
            let index = obj["index"];
            let col = obj["column"];
            let val = obj["value"];
            console.log("val--->"+val);

            var cmnt = prompt("Please enter Comment", val);
            if (cmnt != null) {
              val = cmnt;
            }
            self.gridDynamicObj.setComment(index,col,val);
          }
      }
 */


