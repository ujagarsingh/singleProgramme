function RowGroup(sagGridObj){
    this.sagGridObj = sagGridObj;
}

RowGroup.prototype.getGroupData = function(){
	  
	let data = this.sagGridObj.rowData;
	let grpArray = ["statusname","gstnDty"];
	let rowData = this.groupByMultiple(data, grpArray);

	
}

RowGroup.prototype.groupByMultiple = function(obj, values, context){
	  
	if (!values.length)
		return obj;
	var byFirst = _.groupBy(obj, values[0], context),
		rest = values.slice(1);
	for (var prop in byFirst) {
		byFirst[prop] = this.groupByMultiple(byFirst[prop], rest, context);
	}
	return byFirst;
}

RowGroup.prototype.addValToIndexArr = function(arr,obj){
	arr.splice(1, 0,obj);
	return arr;
}


RowGroup.CustomeGrouping = function(API_DATA){
	let dataArray = [];
	var S_index = 0;
	function recursiveFunction(DATA_ARRAY,parentRef,RG_level){ 
			_.forEach(DATA_ARRAY, function(model){ 
				let obj = model;
				obj["RG_INDEX"] = S_index; 
				obj["RG_Level"] = RG_level;
				let perIndex = S_index;
				S_index++;
				obj["RG_P_REF_ID"] = parentRef; 
				if( model.detail &&  model.detail.length > 0){ 
					obj["RG_HasChild"] = true;
					next_level = RG_level+1;
					recursiveFunction(model.detail,perIndex,next_level); 
				}else if (model.details && model.details.length > 0) { 
					obj["RG_HasChild"] = true;
					next_level = RG_level + 1;
					recursiveFunction(model.details, perIndex, next_level); 
				}else{
					obj["RG_HasChild"] = false;
				}			
				dataArray.push(obj);			
			}); 
		}; 		
	recursiveFunction(API_DATA,'Super',0); 
	return dataArray;
}

RowGroup.getParentData = function(dataArray){
	let perDataArr = _.filter(dataArray, { 'RG_P_REF_ID': 'Super'});
	return perDataArr;
}


/**
 * calling 
 * -------------->
 *  rowGrouping :{
            "enable":true,
            "groupType":"custome",
            "groupBy":"nature",
            "expandRow":[]
          }
 */



