function Property(){
	
	
}

Property.fontAwsmClass = {
			  "checked":"fa-check-square", 
			  "unChecked":"fa-square",
			  "expandPlus":"fa-plus-circle",
			  "collapseMinus":"fa-minus-circle"
			};

