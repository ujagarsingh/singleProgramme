function SagGridEvent(sagGridObj) {

    this.sagGridObj = sagGridObj;
    this.searchColObj = {};
    this.currentSortCol = null;

    this.filterObj = new Filter(sagGridObj);

    this.fromSearchInRGAllData = Array.from(sagGridObj.RG_AllData);
}

SagGridEvent.prototype.addClickListner = function () {

    this.addCheckBoxClick();
    this.addAllCheckBoxClick();

    this.customCheckbox();

    // this.addSagSelectClick();
    this.addFilterClick();
    this.recordFilterOK();
    this.allCheckBoxCheck();
    this.allCheckBoxColorChange();
    this.singleCheckBoxClick();
    this.searchPopUpFilterClick();
    this.addRowHoverEvent();
    this.cellClickListner();
    this.addCellKeyEvent();
    this.addCellEditing();
    this.helpIconClickListner();
    this.popHover();

    if (this.sagGridObj.rowGroupObj.allowClick != false) {
        this.addExpandCollapseClick();
    }

    //row Grouping click
    //this.expandRowGroup();

}

SagGridEvent.prototype.createRowSnapping = function () {

    /*let allColNode = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_key="section"]');
    for(let i=0;i<allColNode.length;i++){

        let colDiv = allColNode[0];
        let rowIndex = colDiv.getAttribute("index");
        let val = colDiv.innerText;
        let offSetHeight = colDiv.offsetHeight;
    	
        console.log(rowIndex);
    	
    }*/

}


SagGridEvent.prototype.searchFilter = function () {

    //.header_cell input[type="text"]

    let self = this;
    let searchNodeList = (this.sagGridObj.gridEle).querySelectorAll('.header_cell input[type="text"]');

    for (var i = 0, len = searchNodeList.length; i < len; i++) {
        let ele = searchNodeList[i];
        let field = ele.getAttribute("field");
        ele.addEventListener("keyup", function (event) {
            //enter button press
            self.searchColObj[field] = this.value;
            if (self.sagGridObj.rowGrouping) {
                self.applySearchAfterRG();
            } else {
                self.applySearch();
            }
            self.sagGridObj.generalEvntObj.onSearchFilter(event);
            /* if (event.keyCode === 13) {
                self.applySearch();
            }else{
                self.searchColObj[field] = this.value;
            }*/
        }, false);
    }
}

SagGridEvent.prototype.applySearchAfterRG = function () {

    let self = this;

    let filterdSerchColObj = {};

    for (let tempKey in self.searchColObj) {

        let serchVal = (self.searchColObj[tempKey]).trim();
        if (serchVal != "" && serchVal != null && serchVal != undefined) {
            self.sagGridObj.searchFilter = true;
            filterdSerchColObj[tempKey] = serchVal;

        } else {
            self.sagGridObj.searchFilter = false;
        }
    }

    let filteredArray = self.fromSearchInRGAllData.filter(function (item) {
        for (var key in filterdSerchColObj) {
            try {
                let dataVal = (item[key]).toString();
                let sVal = (filterdSerchColObj[key]).toString();

                //search if row grouping in enable then show parent also in search with child element
                if (self.sagGridObj.rowGrouping) {
                    if (((dataVal.toLowerCase()).indexOf(sVal.toLowerCase())) > -1) {
                        if (item.RG_HasChild == false) {
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    if (((dataVal.toLowerCase()).indexOf(sVal.toLowerCase())) < 0) {
                        return false;
                    }
                }
            } catch (err) {
                return false;
            }
        }
        return true;
    });

    let parentArr = [];

    function getParent(RG_P_REF_ID) {
        let obj = _.find(self.sagGridObj.originalRowData, { 'RG_INDEX': RG_P_REF_ID });
        if (obj.RG_P_REF_ID != 'Super') {
            getParent(obj.RG_P_REF_ID);
        }
        if (!parentArr.includes(obj.RG_INDEX)) {
            parentArr.push(obj.RG_INDEX);
            filteredArray.push(obj);
        }
    }

    if (self.sagGridObj.rowGrouping) {
        filteredArray = _.filter(filteredArray, { "RG_HasChild": false });
        let childArray = Array.from(filteredArray);
        childArray.forEach(function (a) {
            if (a.RG_P_REF_ID != 'Super') {
                getParent(a.RG_P_REF_ID);
            }
        });
        this.sagGridObj.expandRow = [];
        self.sagGridObj.RG_AllData = _.orderBy(filteredArray, ['RG_INDEX'], ['asc']);
        self.sagGridObj.rowData = RowGroup.getParentData(filteredArray);
    } else {
        self.sagGridObj.rowData = filteredArray;
    }
    //	self.sagGridObj.rowData = filteredArray;
    self.sagGridObj.createGridBody();
}

SagGridEvent.prototype.applySearch = function () {

    let self = this;

    let filterdSerchColObj = {};

    for (let tempKey in self.searchColObj) {

        let serchVal = (self.searchColObj[tempKey]).trim();
        if (serchVal != "" && serchVal != null && serchVal != undefined) {
            self.sagGridObj.searchFilter = true;
            filterdSerchColObj[tempKey] = serchVal;

        } else {
            self.sagGridObj.searchFilter = false;
        }
    }

    self.sagGridObj.rowData = self.sagGridObj.originalRowData.filter(function (item) {
        for (var key in filterdSerchColObj) {
            try {

                let dataVal = (item[key]).toString();
                let sVal = (filterdSerchColObj[key]).toString();

                if (((dataVal.toLowerCase()).indexOf(sVal.toLowerCase())) < 0) {
                    return false;
                }
            } catch (err) {
                return false;
            }
        }
        return true;
    });

    self.sagGridObj.createGridBody();
}

SagGridEvent.prototype.addSortListner = function () {

    let self = this;
    let sortNodeList = (this.sagGridObj.gridEle).querySelectorAll('.header_cell img[type="sortIcon"]');
    for (var i = 0, len = sortNodeList.length; i < len; i++) {
        let ele = sortNodeList[i];
        let field = ele.getAttribute("field");
        let sortType = 'text';

        if (ele.hasAttribute("columnType")) {
            sortType = ele.getAttribute("columnType");
        }

        if (sortType == 'date') {
            ele.addEventListener("click", function () {
                self.applySortOnDate(field);
            }, false);
        } else {
            ele.addEventListener("click", function () {
                self.applySort(field);
            }, false);
        }

    }
}



SagGridEvent.prototype.applySort = function (columnName) {

    let self = this;
    if (self.currentSortCol != columnName) {
        self.sagGridObj.rowData = _.sortBy(self.sagGridObj.rowData, columnName);
    } else {
        self.sagGridObj.rowData = (self.sagGridObj.rowData).reverse();
    }

    if (self.sagGridObj.rowSpan) {
        //for row span
        self.sagGridObj.inDomRowSpanIndex = [];
        self.sagGridObj.rowSpanObj = {};

        self.sagGridObj.rowObjSpanVal = null;
        self.sagGridObj.rowObjSpanIndex = null;
        self.sagGridObj.rowObjSpanIndexWidth = {};
        self.sagGridObj.snoIndex = 0;

        self.sagGridObj.rowData = self.sagGridObj.rowData.map(function (x, ind) {
            let index = x.sag_G_Index;
            //for row span 
            if (x[self.sagGridObj.rowSpanCol] == self.sagGridObj.rowObjSpanVal) {
                if (self.sagGridObj.rowObjSpanIndexWidth.hasOwnProperty(self.sagGridObj.rowObjSpanIndex)) {
                    self.sagGridObj.rowObjSpanIndexWidth[self.sagGridObj.rowObjSpanIndex] = { "height": self.sagGridObj.rowObjSpanIndexWidth[self.sagGridObj.rowObjSpanIndex]["height"] + 1 };
                } else {
                    self.sagGridObj.rowObjSpanIndexWidth[self.sagGridObj.rowObjSpanIndex] = { "height": 2 };
                }

                if (self.sagGridObj.rowObjSpanIndex != null) {
                    self.sagGridObj.rowObjSpanIndexWidth[self.sagGridObj.rowObjSpanIndex]["index"] = self.sagGridObj.snoIndex;
                }

            } else {
                self.sagGridObj.snoIndex = self.sagGridObj.snoIndex + 1;
                self.sagGridObj.rowObjSpanVal = x[self.sagGridObj.rowSpanCol];
                self.sagGridObj.rowObjSpanIndex = index;
            }
            return x;
        })
    }

    self.sagGridObj.createGridBody();
    self.currentSortCol = columnName;
}

SagGridEvent.prototype.applySortOnDate = function (columnName) {

    let self = this;
    if (self.currentSortCol != columnName) {
        self.sagGridObj.rowData = self.sagGridObj.rowData.sort(function (a, b) {

            let date1 = self.getDateObjFrStr(a[columnName]);
            let date2 = self.getDateObjFrStr(b[columnName]);

            if (date1 == "") return 1;
            if (date2 == "") return -1;
            if (date1 > date2) return 1;
            if (date1 < date2) return -1;
            return 0;
        });
    } else {
        self.sagGridObj.rowData = (self.sagGridObj.rowData).reverse();
    }

    self.sagGridObj.createGridBody();
    self.currentSortCol = columnName;
}


SagGridEvent.prototype.getDateObjFrStr = function (dateInString) {

    //check string is html element or not. ex-  input type
    let eleForCheckDom = "";
    let isDomObject = (function (getString) {
        eleForCheckDom = document.createElement('div');
        eleForCheckDom.innerHTML = getString;
        if (eleForCheckDom.firstElementChild) {
            if (eleForCheckDom.firstElementChild.nodeType == 1)
                return true;
        }
        return false;
    })(dateInString);
    if (isDomObject) {
        dateInString = eleForCheckDom.firstElementChild.value;
    }

    let dateType = 1;
    if (dateInString != null || dateInString != undefined) {
        dateInString = dateInString.trim();
    }
    if (dateInString == null || dateInString == "" || dateInString == undefined) {
        return "";
    } else {

        // str1 format should be dd/mm/yyyy. OR dd-mm-yyyy Separator can be anything e.g. / or -. It wont effect
        if (dateType == 1) {
            var dt = parseInt(dateInString.substring(0, 2));
            var mon = parseInt(dateInString.substring(3, 5));
            var yr = parseInt(dateInString.substring(6, 10));
        }
        //str1 format should be  yyyy/mm/dd. OR yyyy-mm-dd Separator can be anything e.g. / or -. It wont effect
        else if (dateType == 2) {
            var yr = parseInt(dateInString.substring(0, 4));
            var mon = parseInt(dateInString.substring(5, 7));
            var dt = parseInt(dateInString.substring(8, 10));
        }
        var dateObj = new Date(yr, mon - 1, dt);
        //check date is valid or not 
        if (dateObj.getTime() === dateObj.getTime()) {
            return dateObj;
        } else {
            return "";
        }
    }
}


SagGridEvent.prototype.addRowHoverEvent = function () {

    let self = this;
    let rowNodeList = (this.sagGridObj.gridEle).querySelectorAll('div.mouseOverOut');
    for (var i = 0, len = rowNodeList.length; i < len; i++) {
        let ele = rowNodeList[i];
        $(ele).removeClass("mouseOverOut");
        ele.addEventListener("mouseover", function (e) {
            self.sagGridObj.generalEvntObj.onRowHover(ele);
        }, false);

        ele.addEventListener("click", function (e) {
            self.sagGridObj.generalEvntObj.onRowClick(ele);
            //let cName = ele.getAttribute("component");
            //alert(cName);
        }, false);

        ele.addEventListener("dblclick", function (e) {
            self.sagGridObj.generalEvntObj.onRowDblclick(ele);
        }, false);

        ele.addEventListener("mouseout", function (e) {
            self.sagGridObj.generalEvntObj.outRowHover(ele);
        }, false);
    }
}

/**
 * Cell event for button componennt click 
 *
 */

SagGridEvent.prototype.cellClickListner = function () {

    let self = this;
    let rowNodeList = (this.sagGridObj.gridEle).querySelectorAll('.btnCmpListnr');
    for (var i = 0, len = rowNodeList.length; i < len; i++) {
        let ele = rowNodeList[i];
        $(ele).removeClass("btnCmpListnr");
        ele.addEventListener("click", function (e) {
            self.sagGridObj.generalEvntObj.onButtonComponentClick(ele);
        }, false);

    }
}

SagGridEvent.prototype.customCheckbox = function () {
    let self = this;
    let rowNodeList = (this.sagGridObj.gridEle).querySelectorAll('.customCheckBoxListener');
    for (var i = 0, len = rowNodeList.length; i < len; i++) {
        let ele = rowNodeList[i];
        $(ele).removeClass("customCheckBoxListener");
        ele.addEventListener("click", function (e) {
            e.stopPropagation();
            self.customCheckboxClick(ele);
        }, false);

    }
}

SagGridEvent.prototype.customCheckboxClick = function (ele) {
    let self = this;
    let colName = ele.attributes["sag_G_Key"].value;
    let index = parseInt(ele.attributes["sag_G_index"].value);
    let newObj;
    if (ele.checked == true) {
        if (!this.sagGridObj.checkedObj.hasOwnProperty(colName)) {
            newObj = {};
            newObj[colName] = [];
            newObj[colName].push(index);
            this.sagGridObj.checkedObj = Object.assign(this.sagGridObj.checkedObj, newObj)
        } else {
            this.sagGridObj.checkedObj[colName].push(index);
        }
    } else {
        if (!this.sagGridObj.checkedObj.hasOwnProperty(colName)) {
            newObj = {};
            newObj[colName] = [];
            newObj[colName].splice(index, 1);
            this.sagGridObj.checkedObj = Object.assign(this.sagGridObj.checkedObj, newObj)
        } else {
            this.sagGridObj.checkedObj[colName].splice(index, 1);
        }
    }
    if ($((this.sagGridObj.gridEle).querySelectorAll('input[sag_G_Key="' + colName + '"]:checked')).length == $((this.sagGridObj.gridEle).querySelectorAll('input[sag_G_Key="' + colName + '"]')).length) {
        $((this.sagGridObj.gridEle).querySelector('input[sag_col="' + colName + '"]')).prop('checked', true);
    } else {
        $((this.sagGridObj.gridEle).querySelector('input[sag_col="' + colName + '"]')).prop('checked', false);
    }
}

SagGridEvent.prototype.customHeaderCheckbox = function () {
    let self = this;
    let rowNodeList = (this.sagGridObj.gridEle).querySelectorAll('.customHeaderCheckboxListener');
    for (var i = 0, len = rowNodeList.length; i < len; i++) {
        let ele = rowNodeList[i];
        $(ele).removeClass("customHeaderCheckboxListener");
        ele.addEventListener("click", function (e) {
            e.stopPropagation();
            self.customHeaderCheckboxClick(ele);
        }, false);
    }
}

SagGridEvent.prototype.customHeaderCheckboxClick = function (ele) {
    let colKey = ele.attributes["sag_col"].value;
    if (ele.checked) {
        $('input[sag_G_Key="' + colKey + '"]').prop("checked", true);
        let checkedArray = this.sagGridObj.checkedObj[colKey];
        let allArr = this.sagGridObj.AllRowIndex;
        this.sagGridObj.checkedObj[colKey] = _.union(checkedArray, allArr);
    } else {
        $('input[sag_G_Key="' + colKey + '"]').prop("checked", false);
        this.sagGridObj.checkedObj[colKey] = [];
    }
}

SagGridEvent.prototype.addCheckBoxClick = function () {
    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('span.sag-checkBox');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("sag-checkBox");
        ele.addEventListener("click", function (e) {
            self.onCheckBoxClick(this);
        }, false);
    }

}


SagGridEvent.prototype.addAllCheckBoxClick = function () {
    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('span.sag-AllCheckBox');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("sag-AllCheckBox");
        ele.addEventListener("click", function (e) {
            self.onAllCheckBoxClick(this);
        }, false);
    }
}


SagGridEvent.prototype.onCheckBoxClick = function (ele) {

    let self = this;
    let checked;

    let sag_g_index = parseInt(ele.parentElement.getAttribute("sag_g_index"));
    let colKey = ele.parentElement.getAttribute("sag_g_key");
    let col_index = parseInt(ele.parentElement.getAttribute("tabindex_col"));


    if (ele.classList.contains(Property.fontAwsmClass.checked)) {
        $(ele).removeClass(Property.fontAwsmClass.checked);
        $(ele).addClass(Property.fontAwsmClass.unChecked);
        var index = self.sagGridObj.checkedRowIdArray.indexOf(sag_g_index);
        if (index > -1) {
            self.sagGridObj.checkedRowIdArray.splice(index, 1);
            checked = false;
        }

    } else {

        $(ele).removeClass(Property.fontAwsmClass.unChecked);
        $(ele).addClass(Property.fontAwsmClass.checked);
        var index = self.sagGridObj.checkedRowIdArray.indexOf(sag_g_index);
        if (index == -1) {
            self.sagGridObj.checkedRowIdArray.push(sag_g_index);
            checked = true;
        }
    }

    if (self.sagGridObj.checkedRowIdArray.length == self.sagGridObj.AllRowIndex.length) {
        $(".sag-AllCheckboxCls").removeClass(Property.fontAwsmClass.unChecked);
        $(".sag-AllCheckboxCls").addClass(Property.fontAwsmClass.checked);
    } else {
        $(".sag-AllCheckboxCls").removeClass(Property.fontAwsmClass.checked);
        $(".sag-AllCheckboxCls").addClass(Property.fontAwsmClass.unChecked);
    }

    let data = {
        "rowIndex": sag_g_index,
        "colKey": colKey,
        "rowValue": self.sagGridObj.rowData[sag_g_index],
        "colValue": self.sagGridObj.colData[col_index],
        "value": checked,
    }
    self.sagGridObj.generalEvntObj.onCheckBoxClick(data);

   

}


//onAllCheckBoxClick

SagGridEvent.prototype.onAllCheckBoxClick = function (ele) {

    let self = this;
    let allChecked;

    let worker;
    if (typeof (Worker) !== "undefined") {
        if (typeof (worker) == "undefined") {
            GeneralEvent.startLoader();
            var worker_fn = function (e) {
                self.postMessage('web worker process start');
            };

            var blob = new Blob(["onmessage =" + worker_fn.toString()], { type: "text/javascript" });

            worker = new Worker(window.URL.createObjectURL(blob));
        }

        worker.onmessage = function (event) {
    
            if (typeof (worker) !== "undefined") {

                if (ele.classList.contains(Property.fontAwsmClass.checked)) {
                    $(ele).removeClass(Property.fontAwsmClass.checked);
                    $(ele).addClass(Property.fontAwsmClass.unChecked);

                    $(".sag-CheckboxCls").removeClass(Property.fontAwsmClass.checked);
                    $(".sag-CheckboxCls").addClass(Property.fontAwsmClass.unChecked);

                    self.sagGridObj.checkedRowIdArray = [];
                    allChecked = false;

                } else {

                    $(ele).removeClass(Property.fontAwsmClass.unChecked);
                    $(ele).addClass(Property.fontAwsmClass.checked);

                    $(".sag-CheckboxCls").removeClass(Property.fontAwsmClass.unChecked);
                    $(".sag-CheckboxCls").addClass(Property.fontAwsmClass.checked);

                    let tempAllChecked = [];
                    self.sagGridObj.rowData.map(function (x, index) {
                        tempAllChecked.push(x["sag_G_Index"]);
                    });


                    self.sagGridObj.AllRowIndex = Array.from(tempAllChecked);
                    self.sagGridObj.checkedRowIdArray = Array.from(tempAllChecked);
                    allChecked = true;
                }

                let data = {};
                if (allChecked == true) {
                    data = {
                        "rowData": self.sagGridObj.rowData,
                        "colData": self.sagGridObj.colData,
                        "checked": true
                    };
                } else {
                    data = {
                        "rowData": self.sagGridObj.rowData,
                        "colData": self.sagGridObj.colData,
                        "checked": false
                    };
                }

                self.sagGridObj.generalEvntObj.onAllCheckBoxClick(data);

         

                GeneralEvent.stopLoader();
                worker.terminate();
                worker = undefined;
            }
        }
        worker.postMessage("start");
    }
}




/** not used now */
SagGridEvent.prototype.addSagSelectClick = function () {
    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('span.sag-selectBox');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("sag-selectBox");
        ele.addEventListener("click", function (e) {
            self.onClickSagComponent(this);
        }, false);
    }
}

SagGridEvent.prototype.onClickSagComponent = function (ele) {


    var x = ele.parentElement;
    let sag_g_key = x.getAttribute("sag_g_key");
    let obj = this.sagGridObj.columnElementObj[sag_g_key];
    var sel = document.createElement('select');
    let optionArr = obj.option;

    for (let i = 0; i < optionArr.length; i++) {
        var opt = document.createElement('option');
        opt.value = optionArr[i].val;
        opt.text = optionArr[i].text;
        sel.appendChild(opt);
    }

    sel.value = obj.val;
    x.appendChild(sel);
    ele.style.display = "none";
    $(sel).focus();

    $(sel).focusout(function (e) {
        e.stopPropagation();
        let val = sel.value;
        ele.innerHTML = val;
        sel.remove();
        ele.style.display = "block";
    });


}

//Grouping click function

//SagGridEvent.prototype.expandRowGroup = function(){
//	let self = this;
//	   let customGrouping =   this.sagGridObj.customGrouping;//new CustomGrouping(this.sagGridObj);
//    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('div.rowGrouping');
//    for (var i = 0, len = nodeList.length; i < len; i++) {
//        let ele = nodeList[i];
//        $(ele).removeClass("rowGrouping");
//        ele.addEventListener("click", function(e){ 
//        	customGrouping.expandGroup(ele);
//        }, false);
//    }
//   
//}



//* filter popup working start*//

SagGridEvent.prototype.singleCheckBoxClick = function () {

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.filterRowInputClickEvent');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("filterRowInputClickEvent");
        ele.addEventListener("click", function (e) {
            self.filterObj.onClickAllCheckBox(ele);
        }, false);
    }

}


SagGridEvent.prototype.searchPopUpFilterClick = function (el) {

    let self = this;
    let searchNodeList = (this.sagGridObj.gridEle).querySelectorAll('.popup-filetr-search');

    for (var i = 0, len = searchNodeList.length; i < len; i++) {
        let ele = searchNodeList[i];
        $(ele).removeClass("popup-filetr-search");
        ele.addEventListener("keyup", function (event) {
            // $('.filterRow').remove();
            var key = event.which || event.keyCode;
            if (key === 13) { // 
                self.filterObj.InputTextSearchPopUp_ClickEvent(ele);
            }
        });
    }
}


SagGridEvent.prototype.addFilterClick = function () {

    let self = this;

    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('span.filterDropdown');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("filterDropdown");
        ele.addEventListener("click", function (e) {
            //self.filterObj.onFilterClick(ele);
            self.filterObj.createFilterPopUp(ele);
        }, false);
    }
}


SagGridEvent.prototype.recordFilterOK = function (el) {

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('button.btnFilter');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("btnFilter");
        ele.addEventListener("click", function (e) {
            //self.filterObj.onFilterOkButtonClick(ele);
            self.filterObj.OkButton_FilterClickEvent(ele);
        }, false);
    }
}


SagGridEvent.prototype.allCheckBoxCheck = function (ele) {

    let self = this;
    var state = false;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('input.checked_all');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("checked_all");
        ele.addEventListener("click", function (e) {
            //self.filterObj.onClickAllCheckBox(ele,state);
            self.filterObj.AllCheckBox_ClickEvent(ele);
        }, false);
    }

}

SagGridEvent.prototype.allCheckBoxColorChange = function (ele) {

    let self = this;
    var state = false;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.removeCheckColor');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("removeCheckColor");
        ele.addEventListener("click", function (e) {
            self.filterObj.AllCheckBoxRemoveColorBlue_ClickEvent(ele);
        }, false);
    }

}


//* filter working end *//



/** cell Editing start **/

SagGridEvent.prototype.addCellEditing = function () {

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('div[component].cellEventListnr');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("cellEventListnr");
        ele.addEventListener("click", function (e) {

            if (ele.hasAttribute("component")) {
                let conponentName = ele.getAttribute("component");
                let field = ele.getAttribute("sag_g_key");
                let rowIndex = parseInt(ele.getAttribute("sag_g_index"));
                let obj = self.sagGridObj.originalRowData[rowIndex];

                let val = obj[field];
                let compObj = self.sagGridObj.components[conponentName];
                let colValue = compObj["param"]["colValue"];
                //let compObj = new component();
                let params = {
                    "rowIndex": rowIndex,
                    "colKey": field,
                    "rowValue": obj,
                    "colValue": colValue,
                    "value": val,
                    "ele": ele,
                };
                if (compObj.getObject != undefined) {
                    compObj = compObj.getObject(params);
                }
                compObj.init(params);
                let eleComp = compObj.getGui();
                ele.innerHTML = '';
                ele.append(eleComp);
                compObj.afterGuiAttached();

                if (compObj.isPopup()) {
                    eleComp.addEventListener('change', function () {
                        let val = compObj.getValue();
                        let text = compObj.getTextView();
                        self.sagGridObj.originalRowData[rowIndex][field] = val;
                        let colValue = compObj["param"]["colValue"];
                        if (colValue != undefined && colValue.hasOwnProperty("checkboxSelection") && colValue["checkboxSelection"] == true) {
                            // let chkaArr = self.sagGridObj.checkedObj[field];
                            if (Array.isArray(self.sagGridObj.checkedObj[field]) && self.sagGridObj.checkedObj[field].includes(rowIndex)) {
                                fieldVal = `
									<div class="coll_chekbox">
										<input type="checkbox" sag_G_index="${rowIndex}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener" checked>
										<label>${text}</label>
									</div>`
                            } else {
                                fieldVal = `
									<div class="coll_chekbox">
										<input type="checkbox" sag_G_index="${rowIndex}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener">
										<label>${text}</label>
									</div>`
                            }
                            ele.innerHTML = fieldVal;
                            self.customCheckbox();
                        } else {
                            ele.innerHTML = text;
                        }
                    });
                } else {
                    $(eleComp).focusout(function (e) {
                        e.stopPropagation();
                        let val = compObj.getValue();
                        let text = compObj.getTextView();
                        self.sagGridObj.originalRowData[rowIndex][field] = val;
                        let colValue = compObj["param"]["colValue"];
                        if (colValue != undefined && colValue.hasOwnProperty("checkboxSelection") && colValue["checkboxSelection"] == true) {
                            // let chkaArr = self.sagGridObj.checkedObj[field];
                            if (Array.isArray(self.sagGridObj.checkedObj[field]) && self.sagGridObj.checkedObj[field].includes(rowIndex)) {
                                fieldVal = `
									<div class="coll_chekbox">
										<input type="checkbox" sag_G_index="${rowIndex}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener" checked>
										<label>${text}</label>
									</div>`
                            } else {
                                fieldVal = `
									<div class="coll_chekbox">
										<input type="checkbox" sag_G_index="${rowIndex}" sag_G_Key="${field}" class="customCheckBox customCheckBoxListener">
										<label>${text}</label>
									</div>`
                            }
                            ele.innerHTML = fieldVal;
                            self.customCheckbox();
                        } else {
                            ele.innerHTML = text;
                        }
                    });
                }
            }
        }, false);
    }
}


SagGridEvent.prototype.onCellClick = function (ele) {

    let type = ele.getAttribute("editable");
    let compObj = new Components();
    let editObj = compObj.getComponent(type);
    let colName = ele.attributes["sag_G_Key"].value;
    let index = parseInt(ele.attributes["sag_G_index"].value);

    var param = { "value": ele.innerHTML };
    ele.innerHTML = '';

    editObj.init(param);
    let eleComp = editObj.getGui();
    ele.append(eleComp);
    editObj.afterGuiAttached();

    $(eleComp).click(function (e) {
        e.stopPropagation();
   
    });

    eleComp.addEventListener("keyup", function (event) {
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            event.preventDefault();
        }
    });

    $(eleComp).focusout(function (e) {
        e.stopPropagation();
        let val = editObj.getTextView();

        ele.innerHTML = val;
    });


}

/** cell Editing End **/



/** Export data work start **/

SagGridEvent.prototype.addExportClick = function () {

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.allPageExport');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("allPageExport");
        ele.addEventListener("click", function (e) {
            self.sagGridObj.gridExportObj.onClickButton(ele);
        }, false);
    }
}


/** keyboard Key Event  **/

SagGridEvent.prototype.addCellKeyEvent = function () {

    let navObj = new GridNavigation(this.sagGridObj);

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.cellSelectionEvent');
    if (nodeList.length > 0) {
        for (var i = 0, len = nodeList.length; i < len; i++) {
            let ele = nodeList[i];
            $(ele).removeClass("cellSelectionEvent");
            ele.addEventListener("click", function (e) {
                self.sagGridObj.generalEvntObj.onCellClick(ele);
            }, false);
        }
    }

}

SagGridEvent.prototype.onCellSelect = function (ele) {

}


/*SagGridEvent.prototype.onKeyDown  = function(e){
	
    let self = this;
	
    switch (e.keyCode) {
	
            case 38: // <Up>
                    let pElement = document.querySelectorAll('div.sml_slectedRow [sag_g_key]');  //sag_g_index  //cellEventListnr 
                    if(pElement.length > 0){
                    let preIndex = parseInt(pElement[0].getAttribute("index"))-1;
                    let pnEle = document.querySelectorAll('[index="'+preIndex+'"]');
                    if(pnEle.length > 0){
                    pnEle[0].click();
                    pnEle[0].scrollIntoView(false);
                    }
                }
                	
                break;				
            case 40: // <Down>
                let nelement = document.querySelectorAll('div.sml_slectedRow [sag_g_key]');  //sag_g_index  //cellEventListnr 
                if(nelement.length > 0){
                let nextIndex = parseInt(nelement[0].getAttribute("index"))+1;
                let npEle = document.querySelectorAll('[index="'+nextIndex+'"]');
                if(npEle.length > 0 ){
                npEle[0].click();
                npEle[0].scrollIntoView(false);
                }
                }
                break;
    	
    }
	
}*/


SagGridEvent.prototype.showFooterSum = function () {


    let self = this;

    if (self.sagGridObj.rowData.length > 0){

    //if(Object.keys(self.sagGridObj.totalFooterCol).length === 0){
    if (!(self.sagGridObj.showTotal) && (self.sagGridObj.searchFilter || self.sagGridObj.sagFilter)) {
        (self.sagGridObj.gridEle).querySelector("#totalFooter").style.display = "none";
    }

    for (var key in self.sagGridObj.totalFooterCol) {

        let sum = _.sumBy(self.sagGridObj.rowData, function (o) {
            let val = Number(o[key]);
            if (val) {
                return val;
            } else {
                return 0;
            }
        });

        sum = sum.toFixed(2)
        self.sagGridObj.totalFooterCol[key] = sum;
        let ele = (self.sagGridObj.gridEle).querySelector('div[sag_g_key="' + key + '"].totalField');
        if (ele) {
            ele.innerHTML = sum;
        }
    }
  }


    if ((self.sagGridObj.columnTotal) && !(self.sagGridObj.searchFilter || self.sagGridObj.sagFilter)) {

        for (var tKey in self.sagGridObj.columnTotal) {
            let sum = Number(self.sagGridObj.columnTotal[tKey]);
            sum = sum.toFixed(2)
            self.sagGridObj.totalFooterCol[tKey] = sum;
            let ele = (self.sagGridObj.gridEle).querySelector('div[sag_g_key="' + tKey + '"].totalField');
            if (ele) {
                ele.innerHTML = sum;
            }
        }

    }

}

SagGridEvent.prototype.headerComponent = function () {

    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('[headercomponent].headerComponent');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("headerComponent");
        let compName = ele.getAttribute("headerComponent");
        let compObj = this.sagGridObj.components[compName];
        compObj.afterGuiAttached(ele, this.sagGridObj);
    }
}

SagGridEvent.prototype.refreshCol = function (colKey) {

    let gridColObj = new GridCol(this.sagGridObj);
    gridColObj.refreshCol(colKey);

}

/* used for tabbing for chnage clr row and select row in space button click */
SagGridEvent.prototype.setRowSelectInTab = function (var_index) {
    this.sagGridObj.gridEventObj.selectedRowINdex = var_index;
    this.sagGridObj.generalEvntObj.selectRowClrChange(var_index);
}


/* Grid expand full screen */
SagGridEvent.prototype.GridExpandClick = function () {

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.addExpandClick');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("addExpandClick");
        ele.addEventListener("click", function (e) {
            self.GridExpand(ele);
        }, false);
    }
}

SagGridEvent.prototype.GridExpand = function () {

    let tableMain = (this.sagGridObj.gridEle).querySelector('#slm_tableMain');
    if (tableMain.classList.contains("smlFullPageScreen")) {
        tableMain.classList.remove("smlFullPageScreen");
    } else {
        tableMain.classList.add("smlFullPageScreen");
    }
}


//pagination work 
SagGridEvent.prototype.createPagination = function () {

    let self = this;
    let pagintnDiv = (this.sagGridObj.gridEle).querySelector('#sml_Pagination');

    let ulList = pagintnDiv.querySelector('ul');

    let allRecords = this.sagGridObj.totalRecordAllPage;
    let recordPerPage = this.sagGridObj.recordPerPage;
    let totalPage = Math.ceil(allRecords / recordPerPage);

    let currentPageNO = (Number(this.sagGridObj.recordStartIndex) / Number(this.sagGridObj.recordPerPage) + 1);


    for (let i = 0; i < totalPage; i++) {
        let pageNo = i + 1;
        let liHtml = '';
        if (currentPageNO == pageNo) {
            liHtml = '<li value=' + pageNo + ' class="active"><a href="javascript:void(0)">' + pageNo + '</a></li>';
        } else {
            liHtml = '<li value=' + pageNo + '><a href="javascript:void(0)">' + pageNo + '</a></li>';
        }
        var node = GeneralEvent.createElementFromHTML(liHtml);
        node.addEventListener("click", function () {
            self.onClickPage(this.value);
        });
        ulList.appendChild(node);
    }
    $(pagintnDiv).show();
}

SagGridEvent.prototype.onClickPage = function (pageNO) {

    if (this.sagGridObj.onPageChangeCallBack) {
        pageNO = Number(pageNO);
        let fromIndex = this.sagGridObj.recordPerPage * (pageNO - 1);
        let toIndex = this.sagGridObj.recordPerPage * pageNO;

        if (this.sagGridObj.totalRecordAllPage < toIndex) {
            toIndex = this.sagGridObj.totalRecordAllPage;
        }
        this.sagGridObj.onPageChangeCallBack(pageNO, fromIndex, toIndex);
    }

}

//Row Grouping work 


SagGridEvent.prototype.addExpandCollapseClick = function () {
    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('.RG_clickListner');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("RG_clickListner");
        ele.addEventListener("click", function (e) {
            self.onClickExpandCollapse(ele);
        }, false);
    }
}

SagGridEvent.prototype.onClickExpandCollapse = function (ele) {

    let self = this;
    let RG_INDEX = parseInt(ele.getAttribute("rg_index"));
    let RG_Level = parseInt(ele.getAttribute("rg_level"));
    let sag_g_index = parseInt(ele.getAttribute("row_index"));
    let parent_index = Number(ele.parentElement.getAttribute("sag_g_index"));

    if (this.sagGridObj.rowGroupObj.hasOwnProperty("StopExpandCollapse") && (this.sagGridObj.rowGroupObj.StopExpandCollapse.indexOf(parent_index) > -1)) {
        return true;
    }
    if (ele.classList.contains(Property.fontAwsmClass.expandPlus)) {
        $(ele).removeClass(Property.fontAwsmClass.expandPlus);
        $(ele).addClass(Property.fontAwsmClass.collapseMinus);
        self.onExpand(RG_INDEX, sag_g_index, RG_Level);
    } else {
        $(ele).removeClass(Property.fontAwsmClass.collapseMinus);
        $(ele).addClass(Property.fontAwsmClass.expandPlus);
        self.onCollapse(RG_INDEX, sag_g_index, RG_Level);
    }
    self.sagGridObj.generalEvntObj.onClickExpandCollapse(ele);
}


SagGridEvent.prototype.onExpand = function (index, rowIndex, rgLevel) {
    let childArray = _.filter(this.sagGridObj.RG_AllData, { 'RG_P_REF_ID': index, });
    this.sagGridObj.rowData.splice(rowIndex + 1, 0, ...childArray);

    this.sagGridObj.rowData = this.sagGridObj.rowData.map(function (x, indx) {
        x["ROW_INDEX"] = indx;
        return x;
    });

    this.sagGridObj.expandRow.push(index);
    let pre = this.sagGridObj.scrollObj.getScrollPos();
    //this.sagGridObj.resetGridData();
    this.sagGridObj.createGridBody();
    this.sagGridObj.scrollObj.setScrollPos(pre);

}


SagGridEvent.prototype.onCollapse = function (index, rowIndex, rgLevel) {
    let removeCount = 0;
    for (let i = rowIndex + 1; i < this.sagGridObj.rowData.length; i++) {
        let obj = this.sagGridObj.rowData[i];
        if (obj.RG_Level > rgLevel) {
            let t_ind = this.sagGridObj.expandRow.indexOf(obj.RG_INDEX);
            if (t_ind > -1) {
                this.sagGridObj.expandRow.splice(t_ind, 1);
            }
            removeCount++;
        } else {
            break;
        }
    }
    let t_ind = this.sagGridObj.expandRow.indexOf(index);
    if (t_ind > -1) {
        this.sagGridObj.expandRow.splice(t_ind, 1);
    }
    this.sagGridObj.rowData.splice(rowIndex + 1, removeCount);

    this.sagGridObj.rowData = this.sagGridObj.rowData.map(function (x, indx) {
        x["ROW_INDEX"] = indx;
        return x;
    });

    let pre = this.sagGridObj.scrollObj.getScrollPos();
    //this.sagGridObj.resetGridData();
    this.sagGridObj.createGridBody();
    this.sagGridObj.scrollObj.setScrollPos(pre);
}

// callback function implementation for helpIcon 
SagGridEvent.prototype.helpIconClickListner = function () {
    // instruction .....
    // just last 2 keys defaint in .ts file. 
    // helpBy:true      // for S No. key
    // helpIcon:true    // for Nature of Supplies
    // helpObj:"gsrt9"  // define Json Object Module Key;

    // according to GSTR9 tab 4 "Details of Adv / Inward / Outward Supplies(WPAY)"

    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('i.vj_helpIconBtn');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        $(ele).removeClass("vj_helpIconBtn");
        ele.addEventListener("click", function (e) {
            self.onHelpIconClick(this);
        }, false);
    }
}

// for helpIcon callback function body
SagGridEvent.prototype.onHelpIconClick = function (element) {

    const _elem_val = element.attributes["data-help-key"].value;
    const _moduleKey = element.attributes["data-module-key"].value;

    // console.log(tooltipObj); 
    // "tooltipObj" is all data global variable
    let _current_elem = [];
    const _module = tooltipObj.filter((item_module) => {
        if (item_module.module_key === _moduleKey) {
            return item_module
        }
    })
    const _elem_obj = _module[0].module_data;
    _current_elem = _elem_obj.filter((item) => {
        if (item.item_id === _elem_val) {
            return item
        }
    })

    if (_current_elem !== "") {
        // create ui of popup start
        let _curItem = _current_elem[0].items;

        let popupElem = document.createElement("DIV");
        popupElem.classList = "well custom-tooltip";
        let heading = document.createElement("H4");
        heading.innerHTML = _curItem['title'];
        popupElem.appendChild(heading);

        let listCon = document.createElement("OL");
        _curItem['list_items'].forEach((li_elem) => {
            let cur_li = document.createElement("LI");
            cur_li.innerText = li_elem;
            listCon.appendChild(cur_li);
        })

        popupElem.appendChild(listCon);
        // create ui of popup end

        // create remove function
        function removePopup(el) {
            const _list = el.target.classList;
            if (_list.contains('custom-tooltip') && _list.contains('well')) {
                el.target.remove();
            }
        }

        // get top left position
        function getElementCoords(elem) {
            var root = document.documentElement,
                body = document.body,
                sTop = window.pageYOffset || root.scrollTop || body.scrollTop,
                sLeft = window.pageXOffset || root.scrollLeft || body.scrollLeft,
                cTop = root.clientTop || body.clientTop || 0,
                cLeft = root.clientLeft || body.clientLeft || 0,
                rect = elem.getBoundingClientRect(),
                top = Math.round(rect.top + sTop - cTop),
                left = Math.round(rect.left + sLeft - cLeft);

            return {
                top: top,
                left: left
            };
        }

        // function  for check place of popup
        function checkRightPlace(popupElem, cordinates) {
            setTimeout(() => {
                const _elem_height = popupElem.offsetHeight;
                const _elem_width = popupElem.offsetWidth;
                const _win_height = window.innerHeight;
                const _win_width = window.innerWidth;
                // console.log(cordinates);
                if (_win_width > 768) {

                    if (cordinates.top + _elem_height > _win_height) {
                        popupElem.style.top = (_win_height - (_elem_height + 30)) + 'px';
                       
                    }

                    if (cordinates.left + _elem_width > _win_width) {
                        popupElem.style.left = (cordinates.left - (_elem_width + 10)) + 'px';
                        
                    }
                } else {
                    popupElem.style.top = ((_win_height - _elem_height) / 2) + 'px';
                    popupElem.style.left = ((_win_width - _elem_width) / 2) + 'px';
                }
            }, 10)

        }
        // apply dynamic positions.
        let _cordinates = getElementCoords(element);
        popupElem.style.top = _cordinates.top + 'px';
        popupElem.style.left = _cordinates.left + 22 + 'px';

        popupElem.addEventListener("click", function (e) {
            const _list = popupElem.classList;
            if (_list.contains('custom-tooltip') && _list.contains('well')) {
                removePopup(e);
            }
        }, false);

        //  element.parentElement.appendChild(popupElem); // append 
        document.body.appendChild(popupElem); // append 

        checkRightPlace(popupElem, _cordinates);
    }
}


SagGridEvent.prototype.popHover = function () {
    // let clicked = false;
    // let popUp;
    // let documentDiv = document.querySelectorAll("div:not(.sagGridPopHover), i:not(.fa.fa-question-circle.custom-fa)")
    let nodePopHover = document.querySelectorAll('.sagGridPopHover');
    let nodePopHoverTxt = document.querySelectorAll('.sagPophoverTxt');
    for (let i = 0; i < nodePopHoverTxt.length; i++) {
        nodePopHoverTxt[i];
    }

    // for (let c = 0; c < documentDiv.length; c++)
    // {
    //     documentDiv[c].addEventListener("click", function(e) {
    //         if(clicked)
    //         {
    //             clicked = false;
    //             if(popUp)
    //                 popUp.classList.remove("show");
    //         }
    //     });
    // }

    for (let i = 0; i < nodePopHover.length; i++) {
        let ele = nodePopHover[i];
        // ele.addEventListener("click", function (e) {
        //     // e.stopPropagation();
        //     // clicked = true;
        //     let popHoverTxt = document.querySelectorAll('.sagPophoverTxt');
        //     for (let i = 0; i < popHoverTxt.length; i++) {
        //         popHoverTxt[i].parentNode.classList.remove("show");
        //     }
        //     e.currentTarget.classList.add("show");
        // });
        ele.addEventListener("mouseover", function (e) {
            let popHoverTxt = document.querySelectorAll('.sagPophoverTxt');
            for (let i = 0; i < popHoverTxt.length; i++) {
                popHoverTxt[i].parentNode.classList.remove("show");
            }
            e.currentTarget.classList.add("show");
            // popUp = e.currentTarget;
        });
        ele.addEventListener("mouseleave", function (e) {
            // if(!clicked)
              e.currentTarget.classList.remove("show");
        });

    }
}



/**
SagGridEvent.prototype.addCellClick = function(){
    let self = this;
    let nodeList = (this.sagGridObj.gridEle).querySelectorAll('div.grid_cell');
    for (var i = 0, len = nodeList.length; i < len; i++) {
        let ele = nodeList[i];
        let field = ele.innerHTML;  //getAttribute("field");
        ele.addEventListener("dblclick", function(e){

            e.preventDefault();
            e.stopPropagation();
            self.onCellClick(this);

        }, false);
    }
}

SagGridEvent.prototype.onCellClick = function(ele){

    var text = document.createElement("input");
    text.setAttribute("type", "text");
    text.setAttribute("value",ele.innerHTML);
    ele.innerHTML = '';
    ele.append(text);

    $(text).dblclick(function(e){
        e.stopPropagation();
        console.log("input click");
    });
    $(text).focus();
    $(text).focusout(function(e){
        e.stopPropagation();
        let val = text.value;
        ele.appendChild(val);
    });

    console.log(ele);
}

**/