/**
 * Validation class for validate grid
 * @param {*} sagGridObj 
 */
function Validation(sagGridObj) {
    this.sagGridObj = sagGridObj;
    this.RegexObj = {};
    this.validErrorObjArr = [];
    this.validateCol = [];
    this.isShowErrorCol = true;

    for (let i = 0; i < this.sagGridObj.colData.length; i++) {
        let colObj = this.sagGridObj.colData[i];
        if (colObj.hasOwnProperty("valid") && colObj.hasOwnProperty("field")) {
            let colKey = colObj.field;
            let validaObj = colObj.valid;
            this.validateCol.push(colKey);
            this.RegexObj[colKey + "R"] = validaObj.regex;
            this.RegexObj[colKey + "E"] = validaObj.error;
        }
    }
}

Validation.prototype.validate = function () {

    if (this.validateCol.length > 0) {
        for (let i = 0; i < this.sagGridObj.originalRowData.length; i++) {
            let rowObj = this.sagGridObj.originalRowData[i];
            for (let j = 0; j < this.validateCol.length; j++) {
                let colKey = this.validateCol[j];
                if (rowObj.hasOwnProperty(colKey)) {
                    RCValue = rowObj[colKey];
                    let regex = this.RegexObj[colKey + "R"];
                    let errMsg = this.RegexObj[colKey + "E"];

                    var patt = new RegExp(regex);
                    var result = patt.test(RCValue);
                    if (!result) {
                        let errorObj = {};
                        errorObj["index"] = i;
                        errorObj["field"] = colKey;
                        errorObj["error"] = errMsg;
                        this.validErrorObjArr.push(errorObj);
                        if (this.isShowErrorCol) {
                            this.addInvalidCls(i, colKey);
                        }
                    } else {
                        let rmIndex = _.find(this.validErrorObjArr, { 'index': i, 'field': colKey });
                        if (rmIndex != undefined) {
                            this.validErrorObjArr.splice(rmIndex, 1);
                        }
                    }
                }
            }
        }
    }
}

Validation.prototype.isValidate = function () {

    if (this.validErrorObjArr.length > 0) {
        return false;
    } else {
        return true;
    }
}

Validation.prototype.isHeighlightColumn = function (val) {
    if (val == false) {
        this.isShowErrorCol = false;
    } else {
        this.isShowErrorCol = true;
    }
}

Validation.prototype.clear = function () {
    this.validErrorObjArr = [];
    let allCellEle = (this.sagGridObj.gridEle).querySelectorAll('.grid_cell');
    $(allCellEle).removeClass("regexInvalid");
}

Validation.prototype.addInvalidCls = function (var_rowIndex, var_colKey) {
    let allCellEle = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="' + var_rowIndex + '"][sag_g_key="' + var_colKey + '"]');
    $(allCellEle).addClass("regexInvalid");
}

Validation.prototype.getError = function () {
    return this.validErrorObjArr;
};

Validation.prototype.isErrorInRC = function (index, field) {
    let obj = _.find(this.validErrorObjArr, { 'index': index, 'field': field });
    if (obj != undefined) {
        return true;
    } else {
        return false;
    }
};

Validation.prototype.showError = function () {

}

/** Calling
 *  {
  header: "Name(Legal Name)",
  field: "gstnName",
  filter: true,
  width: "200px",
  "editable": false,
  "text-align": "left",
  search: true,
  //valid:{"regex":"^[0-9]*$","error":"Please enter only number"}
},
 *
 *
 */
