
function ContextMenu(sagGridObj){
    this.sagGridObj = sagGridObj;
}

ContextMenu.prototype.create = function(){
    
}


/**
 * calling 
 *   
 */


