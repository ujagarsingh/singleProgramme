self.addEventListener('message', function(e) {
	  let array  = e.data;
	  self.postMessage(array);

}, false);