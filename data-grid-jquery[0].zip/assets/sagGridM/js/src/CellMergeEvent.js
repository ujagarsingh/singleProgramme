function CellMergeEvent(sagGridObj) {
    this.sagGridObj = sagGridObj;
    this.lastMargeRowId = -1;
    this.lastColumnArray = null
}


CellMergeEvent.prototype.cellMergeRowColumn = function(field, sag_G_Index, styleHight, visibility) {
    let self = this;

    if (this.sagGridObj.sagFilter == false && this.sagGridObj.searchFilter == false) {

        self.sagGridObj.margeCellColumn.forEach((item) => {
            if (item.colKey === field) {
                let obj = self.sagGridObj.margeCellColumn.find(o => o.colKey === field);
                let arr = obj["colIdGroup"];
                arr.forEach((obj1) => {
                    let array1 = obj1["rowsId"];
                    if (array1[0] == sag_G_Index) {
                        let rowSpanHightVal = array1.length;
                        styleHight = styleHight * rowSpanHightVal;
                    } else if (array1.includes(sag_G_Index)) {
                        styleHight = '';
                        visibility = "hidden";
                    }
                });
            }
        });
    }
    return {
        Hight: styleHight,
        visibility1: visibility
    };
}



CellMergeEvent.prototype.cellMergeRow = function(rowindex, columns) {

    if (this.sagGridObj.sagFilter == false && this.sagGridObj.searchFilter == false) {
        let self = this;
        if (this.lastMargeRowId != rowindex) {
            let arr = self.sagGridObj.margeCellRow;

            let column = Array.from(columns);
            for (let obj of arr) {

                let rowId = obj['rowsId'];
                if (rowId == rowindex) {
                    self.lastMargeRowId = rowindex;
                    let lengthCount = 0;
                    let countIndex = 0;
                    let array = obj['margeColumn'];

                    let len = array.length;
                    let wdth = 0;
                    _.forEachRight(column, function(obj, index) {
                        let value = obj.field;
                        if (array.includes(value)) {
                            countIndex++;
                            let styleWidth = obj.width
                            if (!obj.hasOwnProperty("hidden")) {
                                wdth += Number(styleWidth.replace("px", ""));
                            }
                            let index = _.findIndex(column, {
                                'field': value
                            });
                            let getObj = column.find(o => o.field === value);
                            let newObject = JSON.parse(JSON.stringify(getObj));
                            //if (len == lengthCount) {
                            if (len == countIndex) {
                                newObject.width = wdth + 'px';
                                column[index] = newObject;
                            } else {
                                newObject.width = 0 + "px";
                                newObject.hidden = true;
                                newObject.visibility = 'hidden';
                                column[index] = newObject;
                            }
                            lengthCount++;

                        } else {
                            lengthCount++;
                        }
                    });
                    self.lastColumnArray = column;
                    return column;
                }
            }
        } else if (this.lastMargeRowId == rowindex) {
            return self.lastColumnArray;

        }
    }
    return columns;

}

/***set array Component.ts in this.gridData object

//number sequence is given "rowsId" array like [2,3,4,5] not this number [2,4,7,11]

//column key sequence is given field name "margeColumn" array like ['stateName', 'stateCode', 'countryName'] not this column key ['stateName', 'countryName','sno','stateShow']

    // margeCellColumn: [{ "colKey": "stateName", "colIdGroup": [{ "rowsId": [3, 4, 5] }, { "rowsId": [6, 7, 8, 9] }] }, { "colKey": "stateCode", "colIdGroup": [{ "rowsId": [7, 8, 9] }, { "rowsId": [90, 91] }] }],
    // margeCellRow: [{ "rowsId": 15, "margeColumn": ['stateName', 'stateCode', 'countryName'] }, { "rowsId": 18, "margeColumn": ['stateCode', 'countryName'] }],
    ****/