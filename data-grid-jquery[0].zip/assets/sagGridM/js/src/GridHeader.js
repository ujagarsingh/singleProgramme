	function GridHeader(sagGridObj) {

	    this.sagGridObj = sagGridObj;
	    this.colData = sagGridObj.colData;
	    this.colLen = sagGridObj.colLen;
		this.frezzManagerFlag = sagGridObj.frezzManagerFlag;
	    this.headerHtml = '';
	    this.searchHtml = '';
	    this.headerHtmlObj = {};

	    this.headerLeft = '';
	    this.headerRight = '';
	    this.headerCenter = '';

	    this.styleLeft = 0;

		//parent Header
		this.headerPopIcon = '';
	    this.header = '';
	    this.lastColumnGroup = '';
	    this.widthTotal = 0;
	    this.parentHeaderPos = '';

	    this.textValueC = '';
	    this.textValueR = '';
	    this.textValueL = '';

	    this.leftHeaderGrpColHtml = '';
	    this.rightHeaderGrpColHtml = '';
	    this.centerHeaderGrpColHtml = '';

	    this.pHeaderPosArray = [];

	}

	GridHeader.prototype.getHeaderHtml = function() {

	    let headerHtmlCenter = '';
	    let headerHtmlRight = '';
	    let headerHtmlLeft = '';

	    let searchHtmlLeft = '';
	    let searchHtmlRight = '';
	    let searchHtmlCenter = '';

	    let totalFooterLeft = '';
	    let totalFooterRight = '';
	    let totalFooterCenter = '';

	    let leftStyleL = 0;
	    let leftStyleR = 0;
		let leftStyleC = 0;

	    for (let i = 0; i < this.colLen; i++) {

	        let field = this.colData[i].field;
	        let styleWidth = this.colData[i].width;
	        if (this.sagGridObj.frezzManager.hasOwnProperty(field)) {
	            let val = this.sagGridObj.frezzManager[field];
	            if (val == 'left') {
	                if (!(this.colData[i].hasOwnProperty("hidden") && this.colData[i].hidden)) {

	                    this.createSuperParentHeader(i, leftStyleL, "left");
	                    headerHtmlLeft += this.createHeader(i, leftStyleL, "left");
	                    searchHtmlLeft += this.createHeaderSearch(i, leftStyleL);
	                    totalFooterLeft += this.createTotalFooter(i, leftStyleL, "left");

	                    leftStyleL += Number(styleWidth.replace("px", ""));
	                    this.sagGridObj.leftTableWidth = leftStyleL;
	                }
	            } else if (val == 'right') {

	                if (!(this.colData[i].hasOwnProperty("hidden") && this.colData[i].hidden)) {

	                    this.createSuperParentHeader(i, leftStyleR, "right");
	                    headerHtmlRight += this.createHeader(i, leftStyleR, "right");
	                    searchHtmlRight += this.createHeaderSearch(i, leftStyleR);

	                    totalFooterRight += this.createTotalFooter(i, leftStyleR, "right");

	                    leftStyleR += Number(styleWidth.replace("px", ""));
	                    this.sagGridObj.rightTableWidth = leftStyleR;
	                }
	            } else {

	                if (!(this.colData[i].hasOwnProperty("hidden") && this.colData[i].hidden)) {

	                    this.createSuperParentHeader(i, leftStyleC, "center");
	                    headerHtmlCenter += this.createHeader(i, leftStyleC, "center");
	                    searchHtmlCenter += this.createHeaderSearch(i, leftStyleC);

	                    totalFooterCenter += this.createTotalFooter(i, leftStyleC, "center");


	                    leftStyleC += Number(styleWidth.replace("px", ""));
	                    this.sagGridObj.centerTableWidth = leftStyleC;
	                }
	            }
	        } else {

	            if (!(this.colData[i].hasOwnProperty("hidden") && this.colData[i].hidden)) {

	                this.createSuperParentHeader(i, leftStyleC, "center");
	                headerHtmlCenter += this.createHeader(i, leftStyleC, "center");
	                searchHtmlCenter += this.createHeaderSearch(i, leftStyleC);

	                totalFooterCenter += this.createTotalFooter(i, leftStyleC, "center");

	                leftStyleC += Number(styleWidth.replace("px", ""));
	                this.sagGridObj.centerTableWidth = leftStyleC;
	            }
	        }

	    }

	    let searchHtmlLeftP = '';
	    let searchHtmlRightP = '';
	    let searchHtmlCenterP = '';
	    let leftHeaderGrpCol = '';
	    let rightHeaderGrpCol = '';
	    let centerHeaderGrpCol = '';

	    if (!this.sagGridObj.disableAllSearch) {

	        searchHtmlLeftP = '<div class="child_header">' +
	            '<div class="header_row">' + searchHtmlLeft + '</div>' +
	            '</div>';
	        searchHtmlRightP =
	            ' <div class="child_header">' +
	            '  <div class="header_row" >' + searchHtmlRight + '</div>';
	        searchHtmlCenterP =
	            '<div class="child_header">' +
	            ' <div class="header_row">' + searchHtmlCenter + '</div>' +
	            '</div>';

	    }

	    if (this.sagGridObj.columnGrouping) {
	        leftHeaderGrpCol = '<div class="child_header">' +
	            '<div class="header_row" >' + this.leftHeaderGrpColHtml + '</div>' +
	            '</div>';
	    }

	    let leftHeader = ' <div class="left-tbl-header superParent" parent="left" style ="width:' + this.sagGridObj.leftTableWidth + 'px"> ' +
	        '<div class="header_div" >' +
	        leftHeaderGrpCol +
	        '<div class="child_header">' +
	        '<div class="header_row" >' + headerHtmlLeft + '</div>' +
	        '</div>' +
	        searchHtmlLeftP +
	        '</div>' +
	        '</div>';


	    if (this.sagGridObj.columnGrouping) {
	        rightHeaderGrpCol = '<div class="child_header">' +
	            '<div class="header_row" >' + this.rightHeaderGrpColHtml + '</div>' +
	            '</div>';
	    }


	    let rightHeader = '<div class="right-tbl-header superParent" parent="right" style ="width:' + this.sagGridObj.rightTableWidth + 'px"> ' +
	        ' <div class="header_div">' +
	        rightHeaderGrpCol +
	        ' <div class="child_header">' +
	        ' <div class="header_row" >' + headerHtmlRight + '</div>' +
	        ' </div>' +
	        searchHtmlRightP +
	        ' </div>' +
	        ' </div>' +
	        ' </div>';

	    if (this.sagGridObj.columnGrouping) {
	        centerHeaderGrpCol = '<div class="child_header">' +
	            '<div class="header_row" >' + this.centerHeaderGrpColHtml + '</div>' +
	            '</div>';
	    }

	    let centerHeader = '<div class="center-tbl-header superParent" parent="center"  style ="width:' + this.sagGridObj.centerTableWidth + 'px"> ' +
	        '<div class="header_div" >' +
	        centerHeaderGrpCol +
	        '<div class="child_header">' +
	        '<div class="header_row" >' + headerHtmlCenter + '</div>' +
	        '</div>' +
	        searchHtmlCenterP +
	        ' </div>' +
	        ' </div>';

	    /** 
	     * Footer 
	     */

	    let leftFooter = '<div class="leftTotalFooter left-tbl-header" parent="left" style ="width:' + this.sagGridObj.leftTableWidth + 'px">' +
	        '<div class="header_div">' +
	        ' <div class="child_header">' +
	        ' <div class="header_row">' +
	        ' <div class="leftTotalRowFooter footer_cell"> ' + totalFooterLeft + '</div>' +
	        ' </div>' +
	        '</div>' +
	        '</div>' +
	        '</div>';

	    let centerFooter = '<div class="centerTotalFooter center-tbl-header" parent="center" style ="width:' + this.sagGridObj.centerTableWidth + 'px">' +
	        '<div class="header_div">' +
	        '<div class="child_header">' +
	        '<div class="header_row">  ' +
	        ' <div class="centerTotalRowFooter footer_cell" >' + totalFooterCenter + '</div>' +
	        '</div>  ' +
	        '</div>	  ' +
	        ' </div>' +
	        '</div>';

	    let rightFooter = '<div class="rightTotalFooter right-tbl-header" parent="right" style ="width:' + this.sagGridObj.rightTableWidth + 'px">' +
	        '<div class="header_div">' +
	        ' <div class="child_header">' +
	        ' <div class="header_row">' +
	        ' <div class="rightTotalRowFooter footer_cell" >' + totalFooterRight + '</div>' +
	        ' </div> ' +
	        ' </div>' +
	        '</div>' +
	        '</div>';

	    this.headerHtmlObj["center"] = centerHeader;
	    this.headerHtmlObj["left"] = leftHeader;
	    this.headerHtmlObj["right"] = rightHeader;

	    this.headerHtmlObj["centerFooter"] = centerFooter;
	    this.headerHtmlObj["leftFooter"] = leftFooter;
	    this.headerHtmlObj["rightFooter"] = rightFooter;

	    return this.headerHtmlObj;
	}



	GridHeader.prototype.createSuperParentHeader = function(i, styleLeft, pos) {

	    if (pos == "center") {

	        let eleHtml = this.createParentHeader(i, styleLeft, pos);
	        this.centerHeaderGrpColHtml += eleHtml;
	        let textCont = $(eleHtml).filter('div').text();
	        if (this.textValueC != '' && this.textValueC == textCont) {
	            let ele = $(this.centerHeaderGrpColHtml).filter("div");
	            ele.splice(ele.length - 2, 1);
	            let addHtml = '';
	            for (var j = 0; j < ele.length; j++) {
	                addHtml += ele[j].outerHTML;
	            }

	            this.centerHeaderGrpColHtml = addHtml;
	        }
	        this.textValueC = textCont;

	        return this.centerHeaderGrpColHtml;

	    } else if (pos == "left") {

	        let eleHtml = this.createParentHeader(i, styleLeft, pos);
	        this.leftHeaderGrpColHtml += eleHtml;
	        let textCont = $(eleHtml).filter('div').text();
	        if (this.textValueL != '' && this.textValueL == textCont) {
	            let ele = $(this.leftHeaderGrpColHtml).filter("div");
	            ele.splice(ele.length - 2, 1);
	            let addHtml = '';
	            for (var j = 0; j < ele.length; j++) {
	                addHtml += ele[j].outerHTML;
	            }

	            this.leftHeaderGrpColHtml = addHtml;
	        }
	        this.textValueL = textCont;

	        return this.leftHeaderGrpColHtml;

	    } else if (pos == "right") {

	        let eleHtml = this.createParentHeader(i, styleLeft, pos);
	        this.rightHeaderGrpColHtml += eleHtml;
	        let textCont = $(eleHtml).filter('div').text();
	        if (this.textValueR != '' && this.textValueR == textCont) {
	            let ele = $(this.rightHeaderGrpColHtml).filter("div");
	            ele.splice(ele.length - 2, 1);
	            let addHtml = '';
	            for (var j = 0; j < ele.length; j++) {
	                addHtml += ele[j].outerHTML;
	            }

	            this.rightHeaderGrpColHtml = addHtml;
	        }
	        this.textValueR = textCont;

	        return this.rightHeaderGrpColHtml;

	    }

	}



	GridHeader.prototype.createParentHeader = function(i, styleLeft, pos) {

	    let self = this;

	    let m = this.colData[i];

	    let width = Number(m.width.replace("px", ""));
	    if (self.lastColumnGroup === m.columnGroup && i > 0 && self.parentHeaderPos == pos) {

	        if (m.hasOwnProperty('columnGroup')) {
	            self.widthTotal += width;
	            if (this.pHeaderPosArray.length > 0 && self.parentHeaderPos == pos) {

	                this.pHeaderPosArray.find((o, i) => {
	                    if (o.pos === pos) {
	                        this.pHeaderPosArray[i] = { pos: pos, columnGroup: m.columnGroup, width: self.widthTotal };
	                        return true; // stop searching
	                    }
	                });
	            } else {
	                this.pHeaderPosArray.push({ pos: pos, columnGroup: m.columnGroup, width: self.widthTotal });
	            }
	            self.header.width(self.widthTotal)
	        }

	    } else {
	        if (this.pHeaderPosArray.length > 0 && self.parentHeaderPos !== pos) {
	            let obj = _.find(this.pHeaderPosArray, function(obj) { return obj.pos == pos })

	            if (obj != undefined && obj.columnGroup == m.columnGroup) {
	                self.widthTotal = obj.width + width;
	                styleLeft = 0;
	            } else {
	                self.widthTotal = width;
	                this.pHeaderPosArray.push({ pos: pos, columnGroup: m.columnGroup, width: self.widthTotal });
	            }
	        } else {
	            self.widthTotal = width;
	            if (m.columnGroup != undefined) {
	                this.pHeaderPosArray.push({ pos: pos, columnGroup: m.columnGroup, width: self.widthTotal });
	            }
			}
			
			let styleObject = '';
			if (m.hasOwnProperty("style")) {
				styleObject = m["style"];
			}
	        //self.widthTotal = width;
			self.header = $("<div class='header_cell' style='text-align:center; left:" + styleLeft + "px; " + styleObject+"' colGroup=" + m.columnGroup +"/>")
	            .html("<span class='sml_header_text'>" + (m.columnGroup || '') + "</span>")
				.width(self.widthTotal)
			
				

	    }
	    self.lastColumnGroup = m.columnGroup;
	    self.parentHeaderPos = pos;

	    return self.header[0].outerHTML;

	}



	GridHeader.prototype.createHeader = function(i, styleLeft, pos) {

	    var self = this;

	    let text = "";
	    let field = "";
	    let header = "";

		let sortIcon = '';
		let popHoverIcon = '';

	    let headerClass = '';

	    let colmnData = this.colData[i];
	    let colClass = 'col' + i;

	    if (colmnData.hasOwnProperty("headerClass")) {
	        headerClass = colmnData["headerClass"];
	    }
	    let styleObject = '';
	    if (colmnData.hasOwnProperty("style")) {
	        styleObject = colmnData["style"];
	    }


	    text = colmnData.header;
	    field = colmnData.field;

	    if (text == undefined) {
	        text = "";
	    }

	    let sag_colDragClass = "sag_colDrag";
	    let dragDropCol_hide = false;
	    if (colmnData.hasOwnProperty("dragDropCol_hide")) {
	        dragDropCol_hide = colmnData["dragDropCol_hide"];
	        if (dragDropCol_hide == true) {
	            sag_colDragClass = "";
	        }
	    }

	    if (colmnData.hasOwnProperty("sort")) {
	        if (colmnData.hasOwnProperty("columnType")) {
	            let colType = colmnData["columnType"];
	            sortIcon = '<img class="sortIcon" type="sortIcon"  field=' + field + ' columnType=' + colType + ' style="height: 25px;" src="assets/sagGridM/images/sort.png">';
	        } else {
	            sortIcon = ' <img class="sortIcon" type="sortIcon"  field=' + field + ' style="height: 25px;" src="assets/sagGridM/images/sort.png">';
	        }
	    }

	    //enable hide show 
	    if (this.sagGridObj.enableColHide) {
	        this.enableShowHideCol(colmnData, colClass, pos);
	    } else {
	        let ul = (this.sagGridObj.gridEle).querySelector('#showHideColmn');
	        ul.style.display = "none";
		}
		
	


	    if (colmnData.hasOwnProperty("colType")) {
	        if (colmnData.colType == "checkBox") {
	            let cls = Property.fontAwsmClass.unChecked;
	            header = '<span class= "far ' + cls + ' sag-AllCheckBox  sag-AllCheckboxCls" ></span>';

	            this.sagGridObj.colIdArray[pos].push(colClass);
	            let styleWidth = colmnData.width; // this.styleWidth*(i+1);  
	            let headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; justify-content: center; ' + styleObject + ' ">' + header + '</div>';
	            return headerHtml;
	        } else {
	            header = '<span class="' + sag_colDragClass + '">' + text + '</span>';

	            this.sagGridObj.colIdArray[pos].push(colClass);
	            let styleWidth = colmnData.width; // this.styleWidth*(i+1);  
	            let headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; justify-content: center; ' + styleObject + '">' + header + '</div>';
	            return headerHtml;
	        }
	    } else {
			if (field == 'sno' || colmnData.hasOwnProperty("popOver")) {
				if (field == 'sno'){
					header = '<span>' + text + '</span> <span class="float-right sagGridResize sml_snoClass"><i class="fas fa-arrows-alt-v"></i></span> ';
				} else{
					header = '<span>' + text + '</span> <span class="float-right sagGridPopHover">' +
												'<span class="sagPophoverTxt">' + colmnData.popOverText + '</span>' +
												'<i class="fa fa-question-circle custom-fa"></i>'+
												' </span>' +  
												'<span class="float-right sagGridResize sml_snoClass"><i class="fas fa-arrows-alt-v"></i></span> ';
				}
				
				this.sagGridObj.colIdArray[pos].push(colClass);
				// headerPopIcon = '<span>' + text + '</span>  ';
				let styleWidth = colmnData.width; // this.styleWidth*(i+1); 
				if (colmnData.hasOwnProperty("popOver")) {
					var headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; justify-content: center; ' + styleObject + '">' + header + '</div>';
				}else{
					var headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; justify-content: center; ' + styleObject + '">' + header + '</div>';
				}
				
	            return headerHtml;

	        } else if (field == 'checkbox') {
	            header = '<span>' + text + '</span>';

	            this.sagGridObj.colIdArray[pos].push(colClass);
	            let styleWidth = colmnData.width; // this.styleWidth*(i+1);  
	            let headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; justify-content: center; ' + styleObject + ' ">' + header + '</div>';
	            return headerHtml;

			}
			
			
			else {

	            let compValue = "";
	            if (colmnData.hasOwnProperty("headerComponent")) {

	                let conponentName = colmnData["headerComponent"];
	                let compObj = this.sagGridObj.components[conponentName];
	                //let compObj = new component();
	                let params = {
	                    "compName": conponentName,
	                    "compObj": compObj,
	                    "compColKey": field
	                };
	                compObj.init(params);
	                compValue = compObj.getGui();
	                compValue = compValue.outerHTML;
	            }
	            if (colmnData.hasOwnProperty("checkboxSelection") && colmnData.checkboxSelection == true) {
	                let col = colmnData.field
	                text = `<input type="checkbox" class="customHeaderCheckbox customHeaderCheckboxListener" sag_col="${col}">` + text;
	            }
	            let colFilter = '';
	            if (this.sagGridObj.rowSpan ? (this.sagGridObj.conditionMerzemanager.mrzeColumnList.includes(field)) : true) {
	                colFilter = '<span field=' + field + '  class="float-right sagGridFilter filterDropdown"><i class="fa fa-align-justify"></i></span>';
	            }

	            //remove filter when this is disable from grid configuration
	            if (colmnData.hasOwnProperty("filter") && (colmnData.filter == false)) {
	                colFilter = '';
	            }
	            let sagGridResize = '<span class="float-right sagGridResize"><i class="fas fa-arrows-alt-v"></i></span>';
	            //remove filter when this is disable from grid configuration
	            if (colmnData.hasOwnProperty("sagGridResize") && (colmnData.sagGridResize == false)) {
	                sagGridResize = '';
	            }


	            header = sortIcon + '' + compValue + '<span class="sml_header_text" >' + text + '</span> ' + colFilter + sagGridResize;
	            let colClass = 'col' + i;
	            this.sagGridObj.colIdArray[pos].push(colClass);
	            let styleWidth = colmnData.width; // this.styleWidth*(i+1);  

	            let headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' rowGroupDrag ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px; text-align:center; ' + styleObject + '">' + header + '</div>';
	            if (colmnData.hasOwnProperty("hidden") && colmnData.hidden) {
	                headerHtml = '<div class="header_cell ' + headerClass + ' ' + colClass + ' rowGroupDrag ' + sag_colDragClass + '" colId=' + colClass + ' colPos=' + pos + ' colfield=' + field + ' style="width:0px;  left:' + styleLeft + 'px; text-align:center; padding: 0; visibility: hidden; ' + styleObject + '">' + header + '</div>';
	            }
	            return headerHtml;
			}
			
		}


	}




	GridHeader.prototype.createHeaderSearch = function(i, styleLeft) {

	    field = this.colData[i].field;
	    let colClass = 'col' + i;
	    let styleWidth = this.colData[i].width
	    var obj = this.colData[i];
	    let el = document.createElement("div");
	    var para = document.createElement("div");
	    para.classList.add('header_cell');
	    para.classList.add(colClass);
	    para.setAttribute('colId', colClass);
	    para.style.width = styleWidth;
	    para.style.left = styleLeft + 'px';

	    if (this.colData[i].search == true && (this.sagGridObj.rowSpan ? (this.sagGridObj.conditionMerzemanager.mrzeColumnList.includes(field)) : true)) {
	        var searchInput = document.createElement("INPUT");
	        searchInput.setAttribute("type", "text");
	        searchInput.setAttribute("field", obj.field);
	        searchInput.setAttribute("placeholder", "Search");
	        para.appendChild(searchInput);
	    }

	    el.appendChild(para);
	    return el.innerHTML;
	}




	GridHeader.prototype.createHeaderFilterDiv = function() {

	    $((this.sagGridObj.gridEle).querySelectorAll("#PopupFiletrSearch")).empty();

	    var dropdownMenuDiv = document.createElement('div');
	    dropdownMenuDiv.className = 'dropdown-menu dropdoenMenu p-2';
	    var dropdownMenuDivInput = document.createElement('input');
	    dropdownMenuDivInput.className = 'form-control mb-1 popup-filetr-search';
	    dropdownMenuDivInput.id = 'myInput';
	    dropdownMenuDivInput.type = 'text';
	    dropdownMenuDivInput.placeholder = 'Searching..Press Enter';
	    var dropdownMenuDivSelect = document.createElement('select');
	    dropdownMenuDivSelect.className = 'form-control mb-1 selectFilter';
	    dropdownMenuDivSelect.id = 'selectFilter';
	    dropdownMenuDiv.appendChild(dropdownMenuDivSelect);
	    var option1 = document.createElement("option");
	    var option2 = document.createElement("option");
	    var option3 = document.createElement("option");
	    var option4 = document.createElement("option");
	    var option5 = document.createElement("option");
	    option1.text = 'StartWith';
	    option2.text = 'EndWith';
	    option3.text = 'Contains';
	    option4.text = 'Equals';
	    option5.text = 'NotEquals';
	    option1.value = 'StartWith';
	    option2.value = 'EndWith';
	    option3.value = 'Contains';
	    option4.value = 'Equals';
	    option5.value = 'NotEquals';
	    dropdownMenuDivSelect.appendChild(option1);
	    dropdownMenuDivSelect.appendChild(option2);
	    dropdownMenuDivSelect.appendChild(option3);
	    dropdownMenuDivSelect.appendChild(option4);
	    dropdownMenuDivSelect.appendChild(option5);
	    var divTabLList = document.createElement('div');
	    divTabLList.className = 'tabLList';
	    divTabLList.id = 'tabLList';
	    var scroll_div = document.createElement('div');
	    scroll_div.className = 'mainDivTbody';
	    scroll_div.id = 'filterScroll';
	    divTabLList.appendChild(scroll_div);
	    var blockDiv = document.createElement('div');
	    blockDiv.className = 'blockDiv d-flex';
	    var floatLeftDiv = document.createElement('div');
	    floatLeftDiv.className = 'col p-0';
	    var formCheckDiv = document.createElement('div');
	    formCheckDiv.className = 'form-check checkBlkDiv pl-0';
	    var formCheckInnerDiv = document.createElement('div');
	    formCheckInnerDiv.className = 'all-checkbox-checked removeCheckColor';
	    formCheckInnerDiv.id = 'allCheckboxBlue';
	    var formCheckInput = document.createElement('input');
	    formCheckInput.className = 'form-check-input allCheckbox checked_all';
	    formCheckInput.id = 'checkAll';
	    formCheckInput.name = 'checkme[]';
	    formCheckInput.value = 'option1';
	    formCheckInput.setAttribute("checked", 'true');
	    formCheckInput.type = 'checkbox';
	    var formCheckLable = document.createElement('label');
	    formCheckLable.className = 'form-check-label';
	    formCheckLable.setAttribute("for", 'exampleRadios1');
	    formCheckLable.innerHTML = 'ALL';
	    formCheckDiv.appendChild(formCheckInnerDiv);
	    formCheckDiv.appendChild(formCheckInput);
	    formCheckDiv.appendChild(formCheckLable);
	    floatLeftDiv.appendChild(formCheckDiv);
	    blockDiv.appendChild(floatLeftDiv);
	    var floatRightDiv = document.createElement('div');
	    floatRightDiv.className = 'pull-right';
	    var floatRightButtonOk = document.createElement('button');
	    floatRightButtonOk.className = 'btn btn-primary sagGridFilter btnFilter mr-1';
	    floatRightButtonOk.id = 'btnFilterOkButton';
	    floatRightButtonOk.innerHTML = 'OK';
	    floatRightDiv.appendChild(floatRightButtonOk);
	    var floatRightButtonCancel = document.createElement('button');
	    floatRightButtonCancel.className = 'btn btn-danger sagGridFilterCancel';
	    floatRightButtonCancel.innerHTML = 'Cancel';
	    floatRightDiv.appendChild(floatRightButtonCancel);
	    blockDiv.appendChild(floatRightDiv);
	    dropdownMenuDiv.appendChild(dropdownMenuDivInput);
	    dropdownMenuDiv.appendChild(dropdownMenuDivSelect);
	    dropdownMenuDiv.appendChild(divTabLList);
	    dropdownMenuDiv.appendChild(blockDiv);

	    $((this.sagGridObj.gridEle).querySelectorAll("#PopupFiletrSearch")).append(dropdownMenuDiv);

	}


	GridHeader.prototype.createTotalFooter = function(i, styleLeft, pos) {

	    let field = "";
	    let footer = "";

	    if (this.colData[i].hasOwnProperty("colType")) {
	        if (this.colData[i].colType == "checkBox") {
	            footer = ""; //`<span> Total C </span>`;
	        }
	    } else {
	        text = this.colData[i].header;
	        field = this.colData[i].field;
	        footer = ""; //`${text}`;               
	    }

	    let colClass = 'col' + i;
	    let styleWidth = this.colData[i].width;
	    let footerHtml = '<div class="totalField ' + colClass + '" sag_g_key=' + field + ' colId=' + colClass + ' colPos=' + pos + ' style="width:' + styleWidth + '; left:' + styleLeft + 'px" >' + footer + '</div>';
	    return footerHtml;
	}

	GridHeader.prototype.enableShowHideCol = function(colmnData, colClass, pos) {

	    let field = colmnData.header;

	    let self = this;
	    let ul = (self.sagGridObj.gridEle).querySelector('#showHideColUl');

	    let hideShowObj = self.sagGridObj.hideShowCol;


	    let li = document.createElement('li');
	    let aTag = document.createElement('a')
	    aTag.classList.add("small");
	    let checkbox = document.createElement('input');
	    checkbox.type = "checkbox";
	    checkbox.checked = true;
	    checkbox.setAttribute("colClass", colClass);
	    checkbox.setAttribute("colPos", pos);

	    checkbox.addEventListener("click", function() {
	        hideShowObj.hideShowFn(this, colmnData);
	    });

	    let textNode = document.createTextNode(field);

	    aTag.appendChild(checkbox);
	    aTag.appendChild(textNode);
	    li.appendChild(aTag);
	    ul.appendChild(li);

	}
