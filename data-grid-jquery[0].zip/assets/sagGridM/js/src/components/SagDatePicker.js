// function to act as a class
function SagDatePicker(optn,callBack) {
	this.optionArray = optn;
	this.callBackFn = callBack;
	this.isShow = true;
	this.param = {};
}

// gets called once before the renderer is used
SagDatePicker.prototype.init = function(params) {
    // create the cell
	this.eInput = document.createElement('input');
	this.eInput.value = params.value;
	this.eInput.oninput = function () {
		var regex = new RegExp(/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/);    // allow only date formate dd/mm/yyyy 12/04/2008 
		if (!regex.test(this.value.replace(/\s/g, ''))) {
			this.value = '';
		}
	}
	
	if(this.optionArray && this.optionArray.hasOwnProperty("isShow")){
		this.isShow = this.optionArray.isShow(params);
	}

	if(!this.isShow){
		this.eInput.disabled = true;
	}
	this.param = params;
};

// gets called once when grid ready to insert the element
SagDatePicker.prototype.getGui = function() {
	
	if(this.isShow){
		return this.eInput;
	}else{
		var x = document.createElement("SPAN");
		var t = document.createTextNode(this.eInput.value);
		x.appendChild(t);
		return x;
	}

};

// focus and select can be done after the gui is attached
SagDatePicker.prototype.afterGuiAttached = function() {
    //this.eInput.focus();
	let self = this;
	this.dateFormat;
	this.changeYear;
	this.changeMonth;
	this.minDate;
	this.maxDate;
	if (self.optionArray &&  self.optionArray.hasOwnProperty("dateFormat")) {
		this.dateFormat = self.optionArray.dateFormat;
	}
	if (self.optionArray &&  self.optionArray.hasOwnProperty("changeYear")) {
		this.changeYear = self.optionArray.changeYear;
	}
	if (self.optionArray &&  self.optionArray.hasOwnProperty("changeMonth")) {
		this.changeMonth = self.optionArray.changeMonth;
	}
	if (self.optionArray &&  self.optionArray.hasOwnProperty("minDate")) {
		this.minDate = self.optionArray.minDate;
	}
	if (self.optionArray &&  self.optionArray.hasOwnProperty("maxDate")) {
		this.maxDate = self.optionArray.maxDate;
	}
		
	if(this.isShow){

		var date = new Date();
		var currentYear = date.getFullYear();
		var currentMonth = date.getMonth() + 1;
		var currentDate = date.getDate();
		var defaultCurrentDate = currentDate + '/' + currentMonth + '/'+ currentYear;
		var maxYear = date.getFullYear() + 2;
		var startYear = date.getFullYear() - 137;
		var yearRange = startYear + ":" + maxYear;
		var startDate = currentDate + '/' + currentMonth + '/' + startYear;
		var birthYear = date.getFullYear() - 18;

		var json = {
			dateFormat:  this.dateFormat == undefined ? "dd/mm/yy" : this.dateFormat,
			changeYear:  this.changeYear == undefined ? true : this.changeYear,
			changeMonth: this.changeMonth == undefined ? true : this.changeMonth,
			minDate   :  this.minDate == undefined ? "01/07/2017" : this.minDate,
			maxDate   :  this.maxDate == undefined ? "31/12/2020" : this.maxDate,	//defaultCurrentDate,
			yearRange :  yearRange
		}

		
		var setDate = function(dateInString){
			self.eInput.value = dateInString;
			if(self.callBackFn){
				self.callBackFn(dateInString);
			}
		}
		
		$(self.eInput).datepicker({
			dateFormat : json.dateFormat,
			changeYear : json.changeYear,
			changeMonth : json.changeMonth,
			minDate : json.minDate,
			maxDate : json.maxDate,
			yearRange : json.yearRange,
			onSelect : function(date) {
				setDate(date);
				self.destroy();
			},
			onClose :function(date){
				self.destroy();
			}
		});
		//$("#datepickerPopup").show();
		$(self.eInput).datepicker('show');

		$(".hasDatepicker").each(function (index, element) {
			var context = $(this);
			context.on("blur", function (e) {
				// The setTimeout is the key here.
				setTimeout(function () {
					if (!context.is(':focus')) {
						$(context).datepicker("hide");
					}
				}, 250);
			});
		});
	}
	
};

// returns the new value after editing
SagDatePicker.prototype.getValue = function() {
    return this.eInput.value;
};

//returns the new value after editing
SagDatePicker.prototype.getText = function() {
    return this.eInput.value;
};

SagDatePicker.prototype.getTextUsingVal =function(val) {
	return val;
};

//returns the new value after editing
SagDatePicker.prototype.getTextView = function() {
    return this.eInput.value;
};


//any cleanup we need to be done here
SagDatePicker.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
	$(self.eInput).datepicker("destroy");
	let event = new Event('change');
	this.eInput.dispatchEvent(event);
};

// if true, then this editor will appear in a popup
SagDatePicker.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
		return true;
};

SagDatePicker.prototype.onChangeValue = function(callBack){

}

//all events 
SagDatePicker.prototype.preventDefaultEvent = function() {
  
	   
    $(this.eInput).click(function(event){ 
		e.stopPropagation();
	});
    
    this.eInput.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		    event.preventDefault();
		  }
		});
};