
//function to act as a class
function SagDynamicButton(obj, callBack) {

    this.obj = obj;
    this.callBackFn = callBack;
    this.param = {};
}

// gets called once before the renderer is used
SagDynamicButton.prototype.init = function (param) {
    let self = this;
    this.param = param;
   // this.eGui = document.createElement('span');
    this.input = document.createElement('BUTTON');

    if (param.value == undefined) {
        param.value = "";
    }

    this.input.innerHTML = param.value;

    if (this.obj.hasOwnProperty("name")) {
    this.input.innerHTML = this.obj.name;
    } else {
        this.input.innerHTML = "";

    }
    if (this.obj.hasOwnProperty("classes")) {
        for (let obj of this.obj["classes"]) {
            this.input.classList.add(obj);
        }
    }
    if (this.obj.hasOwnProperty("attr")) {
        let attr = this.obj['attr'];
        for (let key in attr) {
            this.input.setAttribute(key, attr[key])
        }
    }
    if (this.obj.hasOwnProperty("styles")) {
        let styles = this.obj['styles'];
        for (let key in styles) {
            this.input.style[key] = styles[key];
        }
    }

    
    // for (let obj in this.obj.styles) {
    //     this.input.setStyle(obj);
    // }

    // let btn = GeneralEvent.createElementFromHTML('<button type="button" class="btn btn-primary" style="height:3vh; line-height:3vh; width:100%;">...</button>');

    // if (this.obj.text) {
    //     this.input.appendChild(btn);
    // }

  // this.eGui.appendChild(this.input);
    // this.param = params;

};

//gets called once when grid ready to insert the element
SagDynamicButton.prototype.getGui = function () {
    // return this.selectList;
    return this.input;
};


SagDynamicButton.prototype.afterGuiAttached = function (ele, gridObj) {
    this.input.focus();
    if (this.callBackFn) {
        // let prm = JSON.parse(JSON.stringify(this.param));
        this.callBackFn(this.input, this.param);
    }
};

//returns the new value after editing
SagDynamicButton.prototype.getValue = function () {
    return this.input;
};

//returns the new value after editing
SagDynamicButton.prototype.getText = function () {
    return this.input;
};

//returns the new value after editing
SagDynamicButton.prototype.getTextView = function () {
    return this.input;
};

SagDynamicButton.prototype.getTextUsingVal = function (val) {
    return false;
};

// any cleanup we need to be done here
SagDynamicButton.prototype.destroy = function () {
    // but this example is simple, no cleanup, we could
    // even leave this method out as it's optional
};

// if true, then this editor will appear in a popup
SagDynamicButton.prototype.isPopup = function () {
    // and we could leave this method out also, false is the default
    return false;
};

SagDynamicButton.prototype.onChangeValue = function (callBack) {
    //callBack();
}

//all events 
SagDynamicButton.prototype.preventDefaultEvent = function () {


    // $(this.input).click(function (e) {
    //     e.stopPropagation();
    //     console.log("input click");
    // });

    this.input.addEventListener("keyup", function (event) {
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            // event.preventDefault();
        }
    });
};
