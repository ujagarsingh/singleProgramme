// function to act as a class
function SagAutoComplete(optn,callBack) {
	
	this.optionObj = optn;
	this.callBackFn = callBack;
	this.isShow = true;
}

// gets called once before the renderer is used
SagAutoComplete.prototype.init = function(params) {
    // create the cell
    this.eInput = document.createElement('input');
	this.eInput.value = params.value;
	if(this.optionObj && this.optionObj.hasOwnProperty("isShow")){
		this.isShow = this.optionObj.isShow(params);
	}

	if(!this.isShow){
		this.eInput.disabled = true;
	}

};

// gets called once when grid ready to insert the element
SagAutoComplete.prototype.getGui = function() {
	
	if(this.isShow){
		return this.eInput;
	}else{
		var x = document.createElement("SPAN");
		var t = document.createTextNode(this.eInput.value);
		x.appendChild(t);
		return x;
	}

};

// focus and select can be done after the gui is attached
SagAutoComplete.prototype.afterGuiAttached = function() {
    //this.eInput.focus();
	let self = this;
		
	if(this.isShow){
         $(function() {
            var availableTutorials  =  [
               "ActionScript",
               "Bootstrap",
               "C",
               "C++",
            ];
            $( self.eInput).autocomplete({
               source: availableTutorials
            });
         });
	}
	
};

// returns the new value after editing
SagAutoComplete.prototype.getValue = function() {
    return this.eInput.value;
};

//returns the new value after editing
SagAutoComplete.prototype.getText = function() {
    return this.eInput.value;
};

SagAutoComplete.prototype.getTextUsingVal =function(val) {
	return val;
};

//returns the new value after editing
SagAutoComplete.prototype.getTextView = function() {
    return this.eInput.value;
};


//any cleanup we need to be done here
SagAutoComplete.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
	//$(self.eInput).datepicker("destroy");
	//let event = new Event('change');
	//this.eInput.dispatchEvent(event);
};

// if true, then this editor will appear in a popup
SagAutoComplete.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
		return true;
};

SagAutoComplete.prototype.onChangeValue = function(callBack){

}

//all events 
SagAutoComplete.prototype.preventDefaultEvent = function() {
  
	   
    $(this.eInput).click(function(event){ 
		e.stopPropagation();
	});
    
    this.eInput.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		    event.preventDefault();
		  }
		});
};