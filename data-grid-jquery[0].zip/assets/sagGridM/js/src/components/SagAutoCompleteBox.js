// function to act as a class
function SagAutoCompleteBox(optn, callBack) {
    this.optionArray = optn;
    this.callBackFn = callBack;
    this.oninputValueL;
}

//gets called once before the renderer is used
SagAutoCompleteBox.prototype.setOption = function (optn) {
    this.optionArray = optn;
}

// gets called once before the renderer is used
SagAutoCompleteBox.prototype.init = function (param) {
    // create the cell

    let array = this.optionArray;
    this.param = param;
    this.oninputValueL = "";

    let self = this;
    
    this.selectedDiv = document.createElement("div");
    this.inputBox = document.createElement("input");
    this.inputBox.setAttribute('type', "text")
    // this.inputBox.multiple = true;
    this.inputBox.setAttribute('list', "objectList")
    this.inputBox.setAttribute('autocomplete', "off")

    this.selectList = document.createElement("datalist");
    this.selectList.id = "objectList";

    for (var i = 0; i < array.length; i++) {
        var option = document.createElement("option");
        // option.setAttribute('data-value', array[i].key);
        option.value = array[i]
        // option.text = array[i].val;
        // if (array[i].disabled) {
        //     option.disabled = array[i].disabled;
        // }
        this.selectList.appendChild(option);
    }
    if (param.value) {
        this.inputBox.value = param.value;
        // this.selectList.setAttribute('data-value', param.value);
    }

    this.inputBox.oninput = function () {
        if (isNaN(this.value)){
          return this.value = this.oninputValueL;
        }else if (this.value.length > 8)
            return this.value = this.oninputValueL;
        else {
            this.oninputValueL = this.value;
        return this.value;
        }
        
    };

    this.selectedDiv.appendChild(this.inputBox)
    this.selectedDiv.appendChild(this.selectList)
    this.preventDefaultEvent();

};

//gets called once before the renderer is used
SagAutoCompleteBox.prototype.setOption = function (optn) {
    this.optionArray = optn;
}

//gets called once before the renderer is used
SagAutoCompleteBox.prototype.createOption = function (array) {
    this.optionArray = array;
    let val = this.param.value;
    this.optionArray = array;
    $(this.selectList).find('option').remove();
    for (var i = 0; i < array.length; i++) {
        var option = document.createElement("option");
        option.value = array[i];
        // option.text = array[i];
        this.selectList.appendChild(option);
    }
    this.inputBox.value = val;
}

// gets called once when grid ready to insert the element
SagAutoCompleteBox.prototype.getGui = function () {

    if (this.selectList.value == "Filed") {
        var x = document.createElement("SPAN");
        var t = document.createTextNode(this.inputBox.value);
        return t;
    }

    return this.selectedDiv;
};


// focus and select can be done after the gui is attached
SagAutoCompleteBox.prototype.afterGuiAttached = function () {
    this.inputBox.focus();
    //this.selectList.click()
    this.callBackFn(this.inputBox, this.param);

};

// returns the new value after editing
SagAutoCompleteBox.prototype.getValue = function () {
    return this.inputBox.value;
};

//returns the new value after editing
SagAutoCompleteBox.prototype.getText = function () {
    let sel = this.selectList;
    let opt = sel.options[sel.selectedIndex < 0 ? 0 : sel.selectedIndex];
    if (opt != undefined) {
        return opt.text;
    } else {
        return "";
    }
};

SagAutoCompleteBox.prototype.getTextUsingVal = function (val) {
    //let found = this.optionArray.find(element => element.key == val);
    let found = _.find(this.optionArray, function (obj) { return obj.key == val })
    if (found) {
        return found.val;
    } else {
        return "";
    }
};

//returns the new value after editing
SagAutoCompleteBox.prototype.getTextView = function () {
    // let sel = this.selectList;
    // let opt = sel.options[sel.selectedIndex < 0 ? 0 : sel.selectedIndex];
    // if (opt != undefined) {
    //     return opt.text + '<span class="float-right"> <i class="fa fa-caret-down" aria-hidden="true"></i></span> ';
    // } else {
    //     return '<span class="float-right"> <i class="fa fa-caret-down" aria-hidden="true"></i></span> ';
    // }

    return this.inputBox.value;
};


//any cleanup we need to be done here
SagAutoCompleteBox.prototype.destroy = function () {
    // but this example is simple, no cleanup, we could
    // even leave this method out as it's optional
};

// if true, then this editor will appear in a pop up
SagAutoCompleteBox.prototype.isPopup = function () {
    // and we could leave this method out also, false is the default
    return false;
};

//create for change value in cellRenderView when component value chnage 
SagAutoCompleteBox.prototype.onChangeValue = function (callBack) {

}

//all events 
SagAutoCompleteBox.prototype.preventDefaultEvent = function () {

    let self = this;

    $(this.inputBox).click(function (e) {
        e.stopPropagation();
        //e.preventDefault();
    });

    this.selectList.addEventListener("keyup", function (event) {
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            event.preventDefault();
        }
    });
};

