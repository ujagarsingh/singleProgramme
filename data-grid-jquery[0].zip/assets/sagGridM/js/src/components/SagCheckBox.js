// function to act as a class
function SagCheckBox(optn, callBack) {

    this.optionArray = optn;

    this.callBackFn = callBack;
    this.isFilterValueShow = true;
    this.isDisable = false;
    this.applyChange = '';
    this.param = {};

    //num or bool
    this.returnType = 'num';
    if (this.optionArray) {
        if (this.optionArray.hasOwnProperty("returnType") && this.optionArray.returnType == "bool") {
            this.returnType = 'bool';
        }
    }
}

// gets called once before the renderer is used
SagCheckBox.prototype.init = function(params) {
    let self = this;
    this.params = params;
    this.param = params;
    this.eGui = document.createElement('span');

    this.input = document.createElement('input');
    this.input.type = 'checkbox';
    this.input.id = 'inputCheckBox';
    this.input.className = 'inputCheckBoxClass';
    this.input.setAttribute("rowIndex", this.params.rowIndex);
    this.input.setAttribute("colKey", this.params.colKey);
    this.input.setAttribute("colVal", this.params.value);

    if (this.optionArray) {
        if (this.optionArray.hasOwnProperty("isDisable")) {
            this.isDisable = this.optionArray.isDisable(params);
        }
    }


    if (params.value == true || params.value == 1) {
        this.input.checked = true;
    } else {
        this.input.checked = false;
    }

    this.input.onclick = function() {

        let val = 0;
        if (this.checked) {
            val = 1;
        }
        let rowId1 = this.offsetParent.getAttribute("index");
        //let parentElement = this.offsetParent.offsetParent.children[0].children[0].childNodes[0];

        // var element = (self.params.sagGridObj.gridEle).querySelectorAll("#row_" + rowId1 + " span.sag-CheckboxCls");


        // let spanEle = element[0];
        // console.log(spanEle);
        // if ((spanEle.classList.contains(Property.fontAwsmClass.checked) && !this.checked) || (spanEle.classList.contains(Property.fontAwsmClass.unChecked) && this.checked)) {

        //     self.params.sagGridObj.sagGridEvent.onCheckBoxClick(spanEle);

        // }



        let rowIndex = parseInt(this.getAttribute("rowindex"));
        let colKey = this.getAttribute("colkey");
        let returnVal = false;
        if (self.returnType == 'bool') {
            if (val == 1) {
                returnVal = true;
            }
        } else {
            returnVal = val;
        }
        self.applyChange(rowId1, colKey, returnVal);

   
        let headerComp = (self.params.sagGridObj.gridEle).querySelector('[compcolkey="' + colKey + '"]');
        if (headerComp) {
            let totalCheckBox = []; 
            let checkedArr = _.filter(self.params.sagGridObj.rowData, function(o) {
                if(o.hasOwnProperty(colKey))
                   totalCheckBox.push(o[colKey]);

                if (o[colKey] == val) {
                    return true;
                }
            });

            if (checkedArr.length == totalCheckBox.length) {
                //get header component
                if (val == 1) {
                    headerComp.checked = true;
                } else {
                    headerComp.checked = false;
                }
            } else {
                headerComp.checked = false;
            }

        }
        // } else {
        //     let rowId = this.offsetParent.getAttribute("index");
        //     var checkboxes = (self.params.sagGridObj.gridEle).querySelectorAll("#row_" + rowId + " input[type='checkbox']");

        //     if (checkboxes != null && checkboxes.length > 0) {
        //         let checkedResultCount = 0;
        //         if (this.parentElement.parentElement.getAttribute('tabindex_col') == checkboxes[0].offsetParent.getAttribute("tabindex_col")) {
        //             if (checkboxes[0].checked) {
        //                 for (let i = 1; i < checkboxes.length; i++) {
        //                     checkboxes[i].checked = true;
        //                     checkedResultCount++;
        //                 }
        //             } else {
        //                 for (let i = 1; i < checkboxes.length; i++) {
        //                     checkboxes[i].checked = false;
        //                 }

        //             }


        //             if (checkboxes.length - 1 == checkedResultCount) {
        //                 checkboxes[0].checked = true;
        //             } else {
        //                 checkboxes[0].checked = false;
        //             }
        //         } else {

        //             for (let i = 1; i < checkboxes.length; i++) {
        //                 if (checkboxes[i].checked == true) {
        //                     checkedResultCount++;
        //                 }
        //             }
        //             if (checkboxes.length - 1 == checkedResultCount) {
        //                 checkboxes[0].checked = true;
        //             } else {
        //                 checkboxes[0].checked = false;
        //             }
        //         }
        //     }
        // }
    }


    if (this.isDisable) {
        this.input.disabled = true;
    }
    this.eGui.appendChild(this.input);

};

// returns the new value for show 
SagCheckBox.prototype.getValue = function() {
    return this.input.value;
};


//returns the new value for show 
SagCheckBox.prototype.getText = function() {
    if (this.input.checked) {
        return true;
    } else {
        return false;
    }
};

SagCheckBox.prototype.getTextUsingVal = function(val) {
    if (val == 1 || val == true) {
        return true;
    } else {
        return false;
    }

};

SagCheckBox.prototype.onChangeValue = function(callBack) {
    this.applyChange = callBack;
}


//returns the new value for show 
SagCheckBox.prototype.getTextView = function() {
    return this.input.value;
};


//gets called once when grid ready to insert the element
SagCheckBox.prototype.getGui = function() {
    // return this.selectList;
    return this.eGui;
};

SagCheckBox.prototype.afterGuiAttached = function() {
    if (this.callBackFn) {
        this.callBackFn(this.input, this.params);
    }
};

SagCheckBox.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
    return false;
};

/**
 * calling
 *  "checkbox": new SagCheckBox({}, function (ele,obj) {
          console.log(ele);
          
      })
 */