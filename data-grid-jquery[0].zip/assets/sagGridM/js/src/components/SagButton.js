
//function to act as a class
function SagButton(obj,callBack) {
	
	this.obj = obj;
	this.callBackFn = callBack;
	this.param = {};
}

// gets called once before the renderer is used
SagButton.prototype.init = function(params) {
	 let self = this;
	 this.eGui = document.createElement('span');
	 this.input = document.createElement('button');
	 
	 let btn = GeneralEvent.createElementFromHTML('<button type="button" class="btn btn-primary" style="height:3vh; line-height:3vh; width:100%;">...</button>');
	 
	 if(this.obj.text){
		 this.input.appendChild(btn);
	 }
	 
	 this.eGui.appendChild(this.input);
	 this.param =params; 

};

//gets called once when grid ready to insert the element
SagButton.prototype.getGui = function() {
   // return this.selectList;
	return this.eGui ;
};


SagButton.prototype.afterGuiAttached = function(ele,gridObj) {
	 this.input.focus();
	 this.callBackFn(this.input,this.param);
};

//returns the new value after editing
SagButton.prototype.getValue = function() {
    return this.input.value;
};

//returns the new value after editing
SagButton.prototype.getText = function() {
    return this.input.value;
};

//returns the new value after editing
SagButton.prototype.getTextView = function() {
    return this.input.value;
};

SagButton.prototype.getTextUsingVal =function(val) {
	return val;
};

// any cleanup we need to be done here
SagButton.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
};

// if true, then this editor will appear in a popup
SagButton.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
    return false;
};

SagButton.prototype.onChangeValue = function(callBack){
		//callBack();
}

//all events 
SagButton.prototype.preventDefaultEvent = function() {
  
	   
    $(this.input).click(function(e){ 
		e.stopPropagation();
		
	});
    
    this.input.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		   // event.preventDefault();
		  }
		});
};
