 function SagDynamicComp(optn, callBack) {
     this.optionObj = optn;
     this.callBackFn = callBack;
     this.param = {};
     this.applyChange = '';
 }

 // SagDynamicComp.prototype.getObject = function (param) {

 //   if (param.rowValue.sag_G_Index == 2) {
 //     return new SagCheckBox({}, function () {})
 //   } else if (param.rowValue.sag_G_Index == 4) {
 //     return new SagInputText({}, function () {})
 //   } else {
 //     return this;
 //   }
 // }

 SagDynamicComp.prototype.init = function(params) {

     let self = this;
     this.params = params;
     this.param = params;

     self.callBackFn(this.params.rowIndex, this.params.colKey, this.params.value);
 }


 SagDynamicComp.prototype.getGui = function() {
     return this.params.value;
 };

 SagDynamicComp.prototype.afterGuiAttached = function() {
     // if (this.callBackFn) {
     //   this.callBackFn(this.input, this.params);
     // }

 };

 SagDynamicComp.prototype.onChangeValue = function(callBack) {
     this.callBackFn();
 }

 SagDynamicComp.prototype.getTextView = function() {
     return this.params.value;
 };

 SagDynamicComp.prototype.getText = function () {
    return this.params.value;
 };

 SagDynamicComp.prototype.isPopup = function() {
     return false;
 };