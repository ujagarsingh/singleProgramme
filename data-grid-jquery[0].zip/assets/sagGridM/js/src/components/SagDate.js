// function to act as a class
function SagDate(optn,callBack) {
	
	this.optionObj = optn;
	this.callBackFn = callBack;
	this.isShow = true;
}


//gets called for change option 
SagDate.prototype.setOption = function(optn) {
	this.optionObj = optn;
}


// gets called once before the renderer is used
SagDate.prototype.init = function(params) {
    // create the cell
    this.eInput = document.createElement('input');
	this.eInput.value = params.value;
	if(this.optionObj && this.optionObj.hasOwnProperty("isShow")){
		this.isShow = this.optionObj.isShow(params);
	}

	if(!this.isShow){
		this.eInput.disabled = true;
	}

};

// gets called once when grid ready to insert the element
SagDate.prototype.getGui = function() {
	
	if(this.isShow){
		return this.eInput;
	}else{
		var x = document.createElement("SPAN");
		var t = document.createTextNode(this.eInput.value);
		x.appendChild(t);
		return x;
	}

};

// focus and select can be done after the gui is attached
SagDate.prototype.afterGuiAttached = function() {
    //this.eInput.focus();
	let self = this;
		
	if(this.isShow){

		var date = new Date();
		var currentYear = date.getFullYear();
		var currentMonth = date.getMonth() + 1;
		var currentDate = date.getDate();
		var defaultCurrentDate = currentDate + '/' + currentMonth + '/'+ currentYear;
		var maxYear = date.getFullYear() + 2;
		var startYear = date.getFullYear() - 137;
		var yearRange = startYear + ":" + maxYear;
		var startDate = currentDate + '/' + currentMonth + '/' + startYear;
		var birthYear = date.getFullYear() - 18;

		var json = {
			dateFormat : "dd/mm/yy",
			changeYear : true,
			changeMonth : true,
			minDate : "01/07/2017",
			maxDate :  "31/12/2020",       	//defaultCurrentDate,
			yearRange : yearRange
		}

		
		var setDate = function(dateInString){
			self.eInput.value = dateInString;
			if(self.callBackFn){
				self.callBackFn(dateInString);
			}
		}
		
		$(self.eInput).datepicker({
			dateFormat : json.dateFormat,
			changeYear : json.changeYear,
			changeMonth : json.changeMonth,
			minDate : json.minDate,
			maxDate : json.maxDate,
			yearRange : json.yearRange,
			onSelect : function(date) {
				setDate(date);
				self.destroy();
			},
			onClose :function(date){
				self.destroy();
			}
		});
		//$("#datepickerPopup").show();
		$(self.eInput).datepicker('show');
	}
	
};

// returns the new value after editing
SagDate.prototype.getValue = function() {
    return this.eInput.value;
};

//returns the new value after editing
SagDate.prototype.getText = function() {
    return this.eInput.value;
};

SagDate.prototype.getTextUsingVal =function(val) {
	return val;
};

//returns the new value after editing
SagDate.prototype.getTextView = function() {
    return this.eInput.value;
};


//any cleanup we need to be done here
SagDate.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
	$(self.eInput).datepicker("destroy");
	let event = new Event('change');
	this.eInput.dispatchEvent(event);
};

// if true, then this editor will appear in a popup
SagDate.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
		return true;
};

SagDate.prototype.onChangeValue = function(callBack){

}

//all events 
SagDate.prototype.preventDefaultEvent = function() {
  
	   
    $(this.eInput).click(function(event){ 
		e.stopPropagation();
	});
    
    this.eInput.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		    event.preventDefault();
		  }
		});
};