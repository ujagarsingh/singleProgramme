
// function to act as a class
function SagToolTip(optn,callBack) {
	
	this.optionArray = optn;
	this.callBackFn = callBack;
	this.param = {};
}

// gets called once before the renderer is used
SagToolTip.prototype.init = function(params) {
    // create the cell
    this.eInput = document.createElement('div');
    this.eInput.style.height= "inherit";
    this.eInput.setAttribute("data-toggle", "tooltip"); 
    this.eInput.textContent = params.value;
	this.param =params; 
};

// gets called once when grid ready to insert the element
SagToolTip.prototype.getGui = function() {
    return this.eInput;
};

// focus and select can be done after the gui is attached
SagToolTip.prototype.afterGuiAttached = function() {
    //this.eInput.focus();
    if(this.callBackFn){
    	this.callBackFn(this.eInput,this.param);
    }
};

// returns the new value after editing
SagToolTip.prototype.getValue = function() {
    return this.eInput.textContent;
};

//returns the new value after editing
SagToolTip.prototype.getText = function() {
    return this.eInput.textContent;
};

//returns the new value after editing
SagToolTip.prototype.getTextView = function() {
    return this.eInput.textContent;
};

SagToolTip.prototype.getTextUsingVal =function(val) {
	return val;
};

// any cleanup we need to be done here
SagToolTip.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
};

// if true, then this editor will appear in a popup
SagToolTip.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
    return false;
};

SagToolTip.prototype.onChangeValue = function(callBack){
		//callBack();
}

//all events 
SagToolTip.prototype.preventDefaultEvent = function() {
  

    //not necessary for span
   /**   $(this.eInput).click(function(e){ 
		e.stopPropagation();
	
	});
    
    this.eInput.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		   // event.preventDefault();
		  }
        });
   */
};

/*
 *\\defalut tool tip
 * if row object contain toolTipMsg  object with colWise message value
 * EX:-  toolTipMsg = { "field":"message value to show"}
 * 
 * 
 *\\calling sagToolTip component 
 * "toolTip":new SagToolTip({},function(ele,param){
						
						let msg = param.rowValue.ttip;
						ele.title=msg;
					}),
 */
