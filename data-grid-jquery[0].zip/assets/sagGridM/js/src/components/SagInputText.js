
// function to act as a class
function SagInputText(optn,callBack) {
	
	this.optionObj = optn;
	
	this.callBackFn = callBack;
	this.param = {};
	this.applyChange = '';
	this.lastNumberValue = '';
}

// gets called once before the renderer is used
SagInputText.prototype.init = function(params) {
    // create the cell
	this.eInput = document.createElement('input');
	
	
	if(params.value == undefined){
    	params.value = "";
	}
	
    this.eInput.value = params.value;
    
    if(this.optionObj && this.optionObj.hasOwnProperty("type")){
    	if(this.optionObj.type == "currency"){
    		this.eInput.oninput= function(){this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');};
		 }else if(this.optionObj.type == "number"){
			 this.eInput.oninput= function(){this.value = this.value.replace(/[^0-9]/g, '');};
		} else if (this.optionObj.type == "float") {
			this.eInput.oninput = function () {
				var regex = new RegExp(/^[-?,1-9][0-9\,]*([.][0-9]{0,2}|)$/);    // allow only float [0-9] 
				if (!regex.test(this.value.replace(/\s/g, ''))) {
					if(this.value != "")
					   this.value = this.lastNumberValue ? this.lastNumberValue:"";
				}else{
					this.lastNumberValue = this.value;
				}
			};
		}
	}

		// example : = {type: "number", classes: ['btn', 'btn-primary']}
	if (this.optionObj.hasOwnProperty("classes")) {
		for (let val of this.optionObj["classes"]) {
			this.eInput.classList.add(val);
		}
	}

// example : = {type: "number", attribute: {'key' : 'val' , 'key' : 'val'}}
	if (this.optionObj.hasOwnProperty("attribute")) {
		let attr = this.optionObj['attribute'];
		for (let key in attr) {
			this.eInput.setAttribute(key, attr[key]);
		}
	}

    
	this.param =params; 
	//self.applyChange(params.rowIndex, params.colKey, params.value);
	this.preventDefaultEvent();
};

// gets called once when grid ready to insert the element
SagInputText.prototype.getGui = function() {
    return this.eInput;
};

// focus and select can be done after the gui is attached
SagInputText.prototype.afterGuiAttached = function() {
    this.eInput.focus();
    if(this.callBackFn){
	//	let prm = //JSON.parse(JSON.stringify(this.param));
		this.callBackFn(this.eInput, this.param);
    }
};

// returns the new value after editing
SagInputText.prototype.getValue = function() {
    return this.eInput.value;
};

//returns the new value after editing
SagInputText.prototype.getText = function() {
    return this.eInput.value;
};

//returns the new value after editing
SagInputText.prototype.getTextView = function() {
    return this.eInput.value;
};

SagInputText.prototype.getTextUsingVal =function(val) {
	return val;
};

// any cleanup we need to be done here
SagInputText.prototype.destroy = function() {
    // but this example is simple, no cleanup, we could
// even leave this method out as it's optional
};

// if true, then this editor will appear in a popup
SagInputText.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
    return false;
};

SagInputText.prototype.onChangeValue = function(callBack){
	this.applyChange = callBack;
}

//all events 
SagInputText.prototype.preventDefaultEvent = function() {
  
	   
    $(this.eInput).click(function(e){ 
		e.stopPropagation();

	});
    
    this.eInput.addEventListener("keyup", function(event) {
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		   // event.preventDefault();
		  }
		});
};