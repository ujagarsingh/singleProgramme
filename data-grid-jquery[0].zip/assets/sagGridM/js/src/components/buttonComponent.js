
// function to act as a class
function ButtonComponent(optn,callBack){
	this.btnCmpObj = optn;
	this.callBackFn = callBack;
    this.param = {};
}

// gets called once before the renderer is used
ButtonComponent.prototype.init = function(params) {

    this.param = params;
    let buttonValue;
    let iconClass = "";
    let fieldVal = params.value;
    this.eGui = document.createElement('span');
    this.cellText = "";

    if(this.btnCmpObj.hasOwnProperty("cellValue")){
        fieldVal = this.btnCmpObj.cellValue;
    }

    if (this.btnCmpObj.hasOwnProperty("buttonValue")) {
      buttonValue = this.btnCmpObj.buttonValue;
    } else {
      buttonValue = "";
      iconClass = "fa fa-ellipsis-h";
 
    }
    if (fieldVal == null || fieldVal == undefined){
      fieldVal = "";
    }
  
    if(this.btnCmpObj.hasOwnProperty("visibility") && (this.btnCmpObj.visibility == true)){
      this.cellText = '<div class="sml_btnComponent_"><span>' + fieldVal + '</span><button id ="btnComponent_'+params.rowIndex+'" type="button" style="display:inline-block;" class="' + iconClass+' btnComponent btnCmpListnr">' + buttonValue+'</button></div>';
    }else{
      this.cellText = '<div class="sml_btnComponent_"><span>' + fieldVal + '</span><button id ="btnComponent_' + params.rowIndex +'" type="button" style="display:none;" class="' + iconClass +' btnComponent btnCmpListnr">' + buttonValue +'</button></div>';
    }
    let cellText = GeneralEvent.createElementFromHTML(this.cellText);
    this.eGui.appendChild(cellText);
    //this.preventDefaultEvent();

  let buttonEle = this.eGui.childNodes[0].lastElementChild;

  if (this.btnCmpObj.hasOwnProperty("styles")) {
    let styles = this.btnCmpObj['styles'];
    for (let key in styles) {
      buttonEle.style[key] = styles[key];
    }
  }
  if (this.btnCmpObj.hasOwnProperty("attribute")) {
    let attr = this.btnCmpObj['attribute'];
    for (let key in attr) {
      buttonEle.setAttribute(key, attr[key])
    }
  }

  if (this.btnCmpObj.hasOwnProperty("classes")) {
    for (let obj of this.btnCmpObj["classes"]) {
      buttonEle.classList.add(obj);
    }
  }
   
};


// returns the new value for show 
ButtonComponent.prototype.getValue = function() {
    return this.param.value;
};


//returns the new value for show 
ButtonComponent.prototype.getText = function() {
    return this.eGui;
};

ButtonComponent.prototype.getTextUsingVal =function(val) {
	return this.param.value;
};

ButtonComponent.prototype.onChangeValue = function(callBack){
	this.applyChange = callBack;
};


//returns the new value for show 
ButtonComponent.prototype.getTextView = function() {
    return this.cellText;
};

//gets called once when grid ready to insert the element
ButtonComponent.prototype.getGui = function() {
   // return this.selectList;
	return this.eGui;
};

ButtonComponent.prototype.afterGuiAttached = function() {
    let self = this;
    let ele = this.eGui.childNodes[0].lastElementChild;
	 if(this.callBackFn){
     this.callBackFn(ele,self.param);
	 }
};

ButtonComponent.prototype.isPopup = function() {
    // and we could leave this method out also, false is the default
    return false;
};

ButtonComponent.prototype.preventDefaultEvent = function() {
   let self = this;
    $(self.eGui).click(function(e){ 
      
        e.stopPropagation();
        if(self.callBackFn){
            self.callBackFn(self.eGui,self.param);
         }
    });
};
