function RowCellEvent(sagGridObj){

  this.sagGridObj = sagGridObj;
  this.rowCallBack = undefined;
  this.cellCallBack = undefined;
  this.rowIndex = null;
}

RowCellEvent.prototype.setIndex = function(index){
  this.rowIndex = index;
}

RowCellEvent.prototype.afterRowCallback = function(fn){

	let rowIndex = this.rowIndex;
    let obj = this.sagGridObj.rowData[rowIndex];
    let rowEle = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowIndex+'"]')[0];
    let params = {
        "rowIndex":rowIndex,
        "value":obj,
        "ele":rowEle
    };
    fn(params);

}

RowCellEvent.prototype.afterCellCallback = function(fn){

  let rowIndex = this.rowIndex;
  let obj = this.sagGridObj.rowData[rowIndex];

  let columns = this.sagGridObj.colData;
  for(let j=0;j<columns.length;j++){
      let field = columns[j]["field"];
      let val = obj[field];
      let cell = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowIndex+'"][sag_g_key="'+field+'"]')[0];
      //if(cell != undefined && colIndex > -1){
      let params = {
          "rowIndex":rowIndex,
          "colKey":field,
          "rowValue":obj,
          "colValue":columns[j],
          "value":val,
          "ele":cell
      };
      fn(params);
}

}

RowCellEvent.prototype.afterCellEditCallback = function(rowIndex,colIndex,fn){

    let obj = GeneralEvent.deepJsonCopy(this.sagGridObj.rowData[rowIndex]);
    let colObj = GeneralEvent.deepJsonCopy(this.sagGridObj.colData[colIndex]);
    let field = colObj["field"];
    let val = obj[field];
    let cell = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowIndex+'"][sag_g_key="'+field+'"]')[0];
    let params = {
        "rowIndex":rowIndex,
        "colKey":field,
        "rowValue":obj,
        "colValue":colObj,
        "value":val,
        "ele":cell
    };
    fn(params);
}




/**
* Calling 
* 
* 
*    callBack: {
      "onRowClick": function () {
        self.onRowSelectFn();
      },
      "onRowDbleClick": function () {
        self.dblClickModify();
      },
      "rowCallBack":function(param){
        
      },
      "cellCallBack":function(param){
        
      }
    }
* 
* 
*/