//class for start grid 
//class SagGrid{
function SagGridMP(sourceDiv, gridData, compile, scope) {
    // detect container height
    var totalHeight = headerHeight = pageHeaderHeaight = pageHeaderHeaight = bottomLineHeight = sagButtonLine = tableGridHeaderFirst = tableGridHeaderSecond = footerGridHeight = tableGridTotalHeight = calculateHeight = sagFieldSecHeight = sagtabsSectionNav = sagtabsSection2Nav = null;
    totalHeight = $(window).outerHeight(true);
    var outerHeight = 0;
    headerHeight = $('.site-header').outerHeight();
    pageHeaderHeaight = $('.page-content-header').outerHeight();
    sagFieldSecHeight = $('.sagFieldSec').outerHeight();
    sagtabsSectionNav = $('.tabs-section-nav').outerHeight();
    sagtabsSection2Nav = $('.tabs-section-nav-2').outerHeight();
    bottomLineHeight = $('.bottomline').outerHeight();
    sagButtonLine = $('.sagbootom-Line').outerHeight();
    outerHeight = headerHeight + pageHeaderHeaight + sagFieldSecHeight + sagtabsSectionNav + bottomLineHeight + sagButtonLine + sagtabsSection2Nav;

    calculateHeight = totalHeight - outerHeight;
    // $(sourceDiv).parents(".masterdiv").height(calculateHeight); 
    // end detect container height

    //generating grid
    let obj = new SagGridM(sourceDiv, gridData, true, true);
    //setTimeout(function(){
    obj.getSagGrid(function (res) {
        //stopLoader();
        //GridNavigation();
    });
    //},0);

    return obj.gridEventObj;
    //end generating grid	 
}

/** with loader and time delay */
function tblPlaceholder(sourceDiv) {
    let _dummyTbl = `<div class="timz"><div class="abmk"><!--<div class="bkmk header-top"></div><div class="bkmk header-left"></div><div class="bkmk header-right"></div><div class="bkmk header-bottom"></div>
		<div class="bkmk subheader-left"></div><div class="bkmk subheader-right"></div><div class="bkmk subheader-bottom"></div>--><div class="mkbx mk-0"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-1"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-2"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-3"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-4"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-5"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-6"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-7"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-8"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-9"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-10"><div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div><div class="mkbx mk-11"> <div class="bkmk ctop"></div><div class="bkmk cfef"></div>
		<div class="bkmk csls"></div><div class="bkmk cfee"></div><div class="bkmk ctle"></div><div class="bkmk ctee"></div></div></div><div class="bg"></div><div class="loader"></div><div class="loding">Loding</div>
		</div>`;
    sourceDiv.innerHTML = _dummyTbl;
};

function SagGridMPT(sourceDiv, gridData, compile, scope) {
    // function calling for table placeholder 
    tblPlaceholder(sourceDiv);
    // detect container height
    var totalHeight = headerHeight = pageHeaderHeaight = pageHeaderHeaight = bottomLineHeight = sagButtonLine = tableGridHeaderFirst = tableGridHeaderSecond = footerGridHeight = tableGridTotalHeight = calculateHeight = sagFieldSecHeight = sagtabsSectionNav = sagtabsSection2Nav = null;
    totalHeight = $(window).outerHeight(true);
    var outerHeight = 0;
    headerHeight = $('.site-header').outerHeight();
    pageHeaderHeaight = $('.page-content-header').outerHeight();
    sagFieldSecHeight = $('.sagFieldSec').outerHeight();
    sagtabsSectionNav = $('.tabs-section-nav').outerHeight();
    sagtabsSection2Nav = $('.tabs-section-nav-2').outerHeight();
    bottomLineHeight = $('.bottomline').outerHeight();
    sagButtonLine = $('.sagbootom-Line').outerHeight();
    outerHeight = headerHeight + pageHeaderHeaight + sagFieldSecHeight + sagtabsSectionNav + bottomLineHeight + sagButtonLine + sagtabsSection2Nav;

    calculateHeight = totalHeight - outerHeight;
    // $(sourceDiv).parents(".masterdiv").height(calculateHeight); 
    // end detect container height

    //generating grid
    let obj = new SagGridM(sourceDiv, gridData, true, true);
    setTimeout(function () {
        obj.getSagGrid(function (res) {
            //stopLoader();
            //GridNavigation();
        });
        //alert(0);
    }, 200);


    return obj.gridEventObj;
    //end generating grid	 
}

// creating grid
function SagGridM(sourceDiv, gridData, compile, scope) {

    //start loader
    // GeneralEvent.startLoader();

    this.sanitizeHTML = false;
    this.sourceDivId = null;
    this.gridRowObj;
    this.viewHeight = null;
    this.gridHeight = 0;

    this.compile = compile;
    this.scope = scope;
    this.sagFilter = false;
    this.searchFilter = false;
    this.columnGrouping = { enable: false };
    this.columndef = []; 
    this.lastRowHeadArr = [];

    if (gridData.hasOwnProperty("viewHeight")) {
        this.viewHeight = gridData.viewHeight;
    }

    if (gridData.hasOwnProperty("sanitizeHTML")) {
        this.sanitizeHTML = gridData.sanitizeHTML;
    }

    this.rowDef = Array.from(gridData.rowDef);

    this.showTotal = false;
    this.columnTotal = null;
    if (gridData.hasOwnProperty("showTotal")) {
        this.showTotal = gridData.showTotal;

        if (gridData.hasOwnProperty("columnTotal")) {
            this.columnTotal = gridData.columnTotal;
        }
    }

    let self = this;

    //for determine in freezing  And TotalColumn 
    this.totalFooterCol = {};
    this.columnGrouping = false;

    //column word-wrap and word-break;
    this.wordWrapCol = {};

    this.wordBreak = false;
    this.wordbreakConfig = {};
    if (gridData.hasOwnProperty("wordBreak")) {
        this.wordBreak = gridData.wordBreak;
    }

    this.oneWordWidth = 7;
    if (gridData.hasOwnProperty("oneWordWidth")) {
        this.oneWordWidth = gridData.oneWordWidth;
    }

    if (gridData.hasOwnProperty("exectColumn")) {
        this.oneWordWidth = gridData.exectColumn;
    }

    this.columnChildrenFlag = false;
    this.ExportColumnArray = [];
    this.columnChildrenFlag = gridData.hasOwnProperty("exectColumn");
    if (this.columnChildrenFlag){
        this.ExportColumnArray = JSON.parse(JSON.stringify(gridData.exectColumn));
    }

    if (!this.columnGrouping["enable"] && this.checkColumnArrayForColumnGroupping(gridData.columnDef)) {
        this.columnGrouping.enable = true;
        this.getFieldColumn(gridData.columnDef);
        this.columndef = this.lastRowHeadArr;
    }else{
        this.columndef = gridData.columnDef;
    }

    this.originalColData = this.columndef.map(function (x, index) {
        x["sagColClass"] = "col" + index;
        //Save entry for total
        if (x.hasOwnProperty("field")) {
            if (x.columnType == 'numeric') {
                self.totalFooterCol[x.field] = 0;
            }
        }

        //check if word-wrap is enable or disable 
        if (x.hasOwnProperty("word-wrap") && x["word-wrap"] == true) {
            self.wordWrapCol[x.field] = 8;
        } else if (!x.hasOwnProperty("width")) {
            //check if width not exist apply 50px default width 
            x["width"] = '50px';
        }

        //check if column grouping exist //columnGroup
        if (x.hasOwnProperty("columnGroup")) {
            self.columnGrouping = true;
        }


        //check if any column total then showTotal set to true
        if (x.hasOwnProperty("total")) {
            self.showTotal = true;
        }


        //hide column in grid  
        if (x.hasOwnProperty("display") && (x.display == "none")) {
            x["hidden"] = true;
        }

        return x;
    });
  

    //for row Grouping
    this.rowGrouping = false;
    this.rowGroupObj = {};
    this.RG_AllData = [];
    this.expandRow = [];

    if (gridData.hasOwnProperty("rowGrouping")) {
        this.rowGroupObj = gridData["rowGrouping"];
        if (this.rowGroupObj.hasOwnProperty("enable") && this.rowGroupObj.enable) {
            this.rowGrouping = true;
            this.RG_AllData = RowGroup.CustomeGrouping(gridData.rowDef);
            gridData.rowDef = _.orderBy(this.RG_AllData, ['RG_INDEX'], ['asc']); //RowGroup.getParentData(this.RG_AllData);
            //check for parent row which is opened or not 
            if (this.rowGroupObj.hasOwnProperty("expandRow") && this.rowGroupObj.expandRow.length > 0) {
                this.expandRow = this.rowGroupObj.expandRow;
            }
        }
    }

    //for row span
    this.rowSpan = false;
    this.inDomRowSpanIndex = [];
    this.rowSpanObj = {};
    this.conditionMerzemanager = {};

    //for multi row span mergze array
    this.multiRowSpan = false;
    this.rowArraySpanIndexWidth = [];
    if (gridData.hasOwnProperty("conditionMerzemanager")) {
        if (Array.isArray(gridData.conditionMerzemanager)) {
            this.multiRowSpan = true;
            let MerzeArray = gridData.conditionMerzemanager;
            for (let i = 0; i < MerzeArray.length; i++) {
                let rowSpanCol = MerzeArray[i].conditionColumn;
                let snoIndex = 0;
                let rowObjSpanVal = null;
                let rowObjSpanIndex = null;
                let rowObjSpanIndexWidth = {};

                gridData.rowDef.map(function (el, index) {
                    if (el[rowSpanCol] == rowObjSpanVal) {
                        if (rowObjSpanIndexWidth.hasOwnProperty(rowObjSpanIndex)) {
                            rowObjSpanIndexWidth[rowObjSpanIndex] = { "height": rowObjSpanIndexWidth[rowObjSpanIndex]["height"] + 1 };
                        } else {
                            rowObjSpanIndexWidth[rowObjSpanIndex] = { "height": 2 };
                        }

                        if (rowObjSpanIndex != null) {
                            rowObjSpanIndexWidth[rowObjSpanIndex]["index"] = snoIndex;
                        }

                    } else {
                        snoIndex = snoIndex + 1;
                        rowObjSpanVal = el[rowSpanCol];
                        rowObjSpanIndex = index;
                    }

                });

                let rowSpanObj = { "conditionColumn": MerzeArray[i].conditionColumn, "rowObjSpanIndexWidth": rowObjSpanIndexWidth, "mrzeColumnList": MerzeArray[i].mrzeColumnList };
                this.rowArraySpanIndexWidth.push(rowSpanObj);
                rowSpanObj = {};
            }
  
        } else {
            this.rowSpan = true;
            this.conditionMerzemanager = gridData.conditionMerzemanager;
        }
    }
    this.rowObjSpanVal = null;
    this.rowObjSpanIndex = null;
    this.rowObjSpanIndexWidth = {};
    this.snoIndex = 0;
    this.rowSpanCol = null;
    if (self.rowSpan) {
        this.rowSpanCol = self.conditionMerzemanager["conditionColumn"];
    }

    let tempAllChecked = [];

    let ele = GeneralEvent.createElementFromHTML('<div id="mp_wordBreakId" class="mp_wordBreak"> </div>');
    document.body.appendChild(ele);
    let word_wrapEle = document.getElementById("mp_wordBreakId");
    let trans_y = 0;
    this.originalRowData = gridData.rowDef.map(function (x, index) {

        x["sag_G_Index"] = index;

        tempAllChecked.push(index);

        //for row span 
        if (self.rowSpan) {
            if (x[self.rowSpanCol] == self.rowObjSpanVal) {
                if (self.rowObjSpanIndexWidth.hasOwnProperty(self.rowObjSpanIndex)) {
                    self.rowObjSpanIndexWidth[self.rowObjSpanIndex] = { "height": self.rowObjSpanIndexWidth[self.rowObjSpanIndex]["height"] + 1 };
                } else {
                    self.rowObjSpanIndexWidth[self.rowObjSpanIndex] = { "height": 2 };
                }

                if (self.rowObjSpanIndex != null) {
                    self.rowObjSpanIndexWidth[self.rowObjSpanIndex]["index"] = self.snoIndex;
                }

            } else {
                self.snoIndex = self.snoIndex + 1;
                self.rowObjSpanVal = x[self.rowSpanCol];
                self.rowObjSpanIndex = index;
            }
        }


        // for word-wrap
        Object.keys(self.wordWrapCol).forEach(function (key) {
            let value = self.wordWrapCol[key];
            let strLen = x[key] ? (x[key]).length : 1;
            self.wordWrapCol[key] = strLen > value ? strLen : value;
        });

        if (self.wordBreak) {
            let indexheight = 20;
            self.wordbreakConfig[index] = { "height": 20, "trans_y": trans_y };
            self.originalColData.map(function (colObj) {
                if (colObj.field && x[colObj.field]) {
                    height = self.wordbreakConfig[index].height;
                    word_wrapEle.style.width = colObj.width;
                    word_wrapEle.innerHTML = x[colObj.field];
                    let newHeight = $(word_wrapEle).height();
                    if (newHeight > indexheight) {
                        indexheight = newHeight;
                    }
                }

            });
            self.wordbreakConfig[index]["height"] = indexheight;
            self.wordbreakConfig[index]["trans_y"] = trans_y;
            self.gridHeight = self.gridHeight + indexheight;
            trans_y = trans_y + indexheight;
        }
        return x;
    });

    //document.removeChild(word_wrapEle);
    $(word_wrapEle).remove();


    //assign width in column after word-wrap true
    // for word-wrap
    this.originalColData.map(function (x) {
        if (self.wordWrapCol.hasOwnProperty(x["field"])) {
            x["width"] = (((self.wordWrapCol[x.field]) * self.oneWordWidth) + 50) + 'px';
        }
    });


    this.AllRowIndex = Array.from(tempAllChecked);


    // this.originalColData = gridData.columnDef;


    if (this.rowGrouping) {
        this.rowData = RowGroup.getParentData(this.originalRowData);
        this.rowData = this.rowData.map(function (x, indx) {
            x["ROW_INDEX"] = indx;
            return x;
        });
    } else {
        this.rowData = this.originalRowData;
    }
    //this.rowData =   this.originalRowData.splice(1,20);

    this.colData = this.originalColData; //gridData.columnDef;


    this.rowLen = this.rowData.length;
    this.colLen = this.colData.length;
    this.gridEle = sourceDiv;
    this.tableBody = null;
    this.tableBodyLeft = null;
    this.tableBodyRight = null;
    this.tableBodyCenter = null;

    this.OneRowHeight = 20;
    this.totalRowShow = 0;

    this.leftTableWidth = 0;
    this.rightTableWidth = 0;
    this.centerTableWidth = 0;
    this.gridHeight = 0;


    //help for drag and drop column
    this.colIdArray = { "left": [], "right": [], "center": [] };

    //row index contain which row is in grid div
    this.gridRowIndexArray = [];

    //this use for contain all checked data index 
    this.checkedRowIdArray = [];

    //used to create column element after click in column
    this.columnElementObj = {};

    //event Array
    this.EventListner = [];

    //frezzeManager 
    this.frezzManagerFlag = false;
    this.frezzManager = {};

    //used for custome checkbox enable perticular column vise
    this.checkedObj = {};


    /**FOR MOBILE **/
    this.isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    /** FREEZ ONLY 50% OF EXSINTING AVALABLE WIDTH **/
    this.freezableWidth = sourceDiv.offsetWidth / 2;
    this.freezedWidth = 0;

    if (!this.isMobile && gridData.hasOwnProperty("frezzManager")) {

        //change freegManager according to also header heading 

        let obj = gridData.frezzManager;
        for (var key in obj) {

            for (let cd = 0; cd < this.colData.length; cd++) {
                let cdObj = this.colData[cd];
                if (cdObj["header"] == key || cdObj["field"] == key) {
                    this.freezedWidth += Number(cdObj.width.split('px')[0]);
                    if (this.freezedWidth < this.freezableWidth) {
                        this.frezzManager[key] = obj[key];
                    }
                }
            }
        }
        //if all key direct in field
        //this.frezzManager = gridData.frezzManager;
        this.frezzManagerFlag = true;
    }

    //CallBack methods 
    this.callBack = {};
    if (gridData.hasOwnProperty("callBack")) {
        this.callBack = gridData.callBack;
    }


    //Export
    this.gridExportObj = new GridExport(this);
    if (gridData.hasOwnProperty("gridExportService")) {
        this.ExcelExportService = gridData.gridExportService;
    }
    if (gridData.hasOwnProperty("sheatDetails")) {
        this.sheatDetails = gridData.sheatDetails;
    }

    if (gridData.hasOwnProperty("sheatDetailsfun")) {
        this.sheatDetailsfun = gridData.sheatDetailsfun;
    }

    if (gridData.hasOwnProperty("clientDetail")) {
        this.clientDetail = gridData.clientDetail;
    }

    this.components = {};
    if (gridData.hasOwnProperty("components")) {
        this.components = gridData.components;
    }

    this.enableColHide = false;
    if (gridData.hasOwnProperty("enableColHide")) {
        this.enableColHide = gridData.enableColHide;
    }

    this.disableAllSearch = false;
    if (gridData.hasOwnProperty("disableAllSearch")) {
        this.disableAllSearch = gridData.disableAllSearch;
    }

    this.rowSelection = false;
    if (gridData.hasOwnProperty("rowSelection")) {
        this.rowSelection = gridData.rowSelection;
    }

    /*
        When user enter key press then default cell select up to down within a column 
        but after set cellSelectionLtoR = true. cell must be select left to right within a row 
    */
    this.onEnterLtoR_cellSelection = false;
    if (gridData.hasOwnProperty("cellSelectionLtoR")) {
        this.onEnterLtoR_cellSelection = gridData.cellSelectionLtoR;
    }

    //Apply property in single row like color 
    this.setRowPropertyObj = {};

    //Apply color property in multiple row 
    //syntex [{"colorCode":"","index":[]},{"colorCode":"","index":[]}]
    this.mutliColorInRow = [];
    if (gridData.hasOwnProperty("mutliColorInRow")) {
        this.mutliColorInRow = gridData.mutliColorInRow;
        for (let mClr = 0; mClr < this.mutliColorInRow.length; mClr++) {
            let clrCode = this.mutliColorInRow[mClr].colorCode;
            let indexArr = this.mutliColorInRow[mClr].index;
            for (let rI = 0; rI < indexArr.length; rI++) {
                let rIndex = indexArr[rI];
                this.setRowPropertyObj[rIndex] = { "backgroundColor": clrCode };
            }
        }

    }

    //Apply property in single column by row like color 
    this.setColRowPropertyObj = {};

    //Apply color property in multiple column by  row 
    //syntex [{"colorCode":"","colKey":"","index":[]},{ "style": { "color":"#7ff734"}, "colKey":"earning", "index": 4 }]
    this.mutliColorInColRow = [];
    if (gridData.hasOwnProperty("mutliColorInColRow")) {
        this.mutliColorInColRow = gridData.mutliColorInColRow;
        for (let mClr = 0; mClr < this.mutliColorInColRow.length; mClr++) {
            let clrCode = this.mutliColorInColRow[mClr].colorCode;
            let rIndex = this.mutliColorInColRow[mClr].index;
            let colKey = this.mutliColorInColRow[mClr].colKey;
            let objKey = rIndex + "_" + colKey;

            if (this.mutliColorInColRow[mClr].hasOwnProperty("style")) {
                let styleObj = this.mutliColorInColRow[mClr]["style"];
                this.setColRowPropertyObj[objKey] = styleObj;
            } else {
                this.setColRowPropertyObj[objKey] = { "backgroundColor": clrCode };
            }
        }
    }

    //Apply property columnby like color 
    this.setColPropertyObj = {};

    //Apply color property in multiple column by  row 
    //syntex [{"colorCode":"","index":[]},{"colorCode":"","index":[]}]
    this.mutliColorInCol = [];
    if (gridData.hasOwnProperty("mutliColorInCol")) {
        this.mutliColorInCol = gridData.mutliColorInCol;
        for (let mClr = 0; mClr < this.mutliColorInCol.length; mClr++) {
            let clrCode = this.mutliColorInCol[mClr].colorCode;
            let colKey = this.mutliColorInCol[mClr].colKey;
            this.setColPropertyObj[colKey] = { "backgroundColor": clrCode };
        }
    }

    //for pagination 
    this.clientSidePagging = false;
    this.recordPerPage = 100;
    this.recordStartIndex = 0;
    this.recordEndIndex = 100;
    this.totalPage = 1;
    this.onPageChangeCallBack = null;

    this.totalRecordAllPage = this.originalRowData.length;
    if (gridData.hasOwnProperty("clientSidePaggingMP")) {
        this.clientSidePagging = gridData.clientSidePaggingMP;
        if (this.clientSidePagging && gridData.hasOwnProperty("recordPerPage")) {
            this.recordPerPage = gridData.recordPerPage;
            let allRecords = this.originalRowData.length;
            let recordPerPage = this.recordPerPage;
            this.totalPage = Math.ceil(allRecords / recordPerPage);

            if (gridData.hasOwnProperty("totalRecordAllPage")) {
                this.totalRecordAllPage = gridData.totalRecordAllPage;
            }

            if (gridData.hasOwnProperty("recordStartIndex")) {
                this.recordStartIndex = gridData.recordStartIndex;
            }

            if (gridData.hasOwnProperty("recordEndIndex")) {
                this.recordEndIndex = gridData.recordEndIndex;
            }

            if (gridData.hasOwnProperty("onPageChange")) {
                this.onPageChangeCallBack = gridData.onPageChange;
            }

        }
    }

    //marge cell column wise
    this.margeCellColumn = null;
    if (gridData.hasOwnProperty("margeCellColumn")) {
        this.margeCellColumn = gridData.margeCellColumn;
    }
    //marge cell row wise
    this.margeCellRow = null;
    if (gridData.hasOwnProperty("margeCellRow")) {
        this.margeCellRow = gridData.margeCellRow;
    }



    //check grid elements key 
    self.checkElements_hasOwnProperty(gridData);

    //object 
    this.scrollObj = new Scroll(this);
    this.generalEvntObj = new GeneralEvent(this);
    this.gridEventObj = new GridEvent(this);
    this.bottomScrollObj = new BottomScroll(this);
    this.hideShowCol = new HideShowCol(this);
    this.sagGridEvent = new SagGridEvent(this);
    this.GridColObj = new GridCol(this);
    // this.rowGroupObj = new RowGroup(this);
    this.validationObj = new Validation(this);
    this.cellCommentObj = undefined;
    this.cellcomment = {};
    if (gridData.hasOwnProperty("cellComments")) {
        this.cellComments = gridData.cellComments;
        this.cellCommentObj = new CellComment(this);
    }

    /** Custome Context menu show in grid cell right click */
    this.contextMenu = new ContextMenu(this);

    /** Row And Cell event just like callBack after create row and cell */
    this.rowCellEvent = new RowCellEvent(this);

    //    this.cellMergeEvent = new CellMergeEvent(this);

    this.isRowCallBack = false;
    if (this.callBack.hasOwnProperty("rowCallBack")) {
        this.isRowCallBack = true;
        this.rowCellEvent.rowCallBack = this.callBack.rowCallBack;
    }

    this.isCellCallBack = false;
    if (this.callBack.hasOwnProperty("cellCallBack")) {
        this.isCellCallBack = true;
        this.rowCellEvent.cellCallBack = this.callBack.cellCallBack;
    }

}
// end creating grid


SagGridM.prototype.resetGridData = function () {

    let self = this;
    let tempAllChecked = [];
    this.originalRowData = this.originalRowData.map(function (x, index) {
        x["sag_G_Index"] = index;
        tempAllChecked.push(index);
        return x;
    });

    this.AllRowIndex = Array.from(tempAllChecked);
    if (this.rowGrouping) {
        this.rowData = RowGroup.getParentData(this.originalRowData);
        this.rowData = this.rowData.map(function (x, indx) {
            x["ROW_INDEX"] = indx;
            return x;
        });
    } else {
        this.rowData = this.originalRowData;
    }
    this.rowLen = this.rowData.length;

    //refresh total row
    let totalNoOfReocord = (this.gridEle).querySelectorAll('#totalNoOfRecord')[0];
    totalNoOfReocord.textContent = 'No. of Records: ' + this.originalRowData.length;

    this.scrollObj = new Scroll(this);
    this.generalEvntObj = new GeneralEvent(this);
    //this.gridEventObj = new GridEvent(this);
    this.bottomScrollObj = new BottomScroll(this);
    this.hideShowCol = new HideShowCol(this);
    this.sagGridEvent = new SagGridEvent(this);
    this.sagGridEvent.showFooterSum();
    this.validationObj = new Validation(this);
}

SagGridM.prototype.resetGridBody = function () {
    let self = this;
    this.originalColData = this.originalColData.map(function (x, index) {
        x["sagColClass"] = "col" + index;
        //Save entry for total
        if (x.hasOwnProperty("field")) {
            if (x.columnType == 'numeric') {
                self.totalFooterCol[x.field] = 0;
            }
        }
        //check if width not exist apply 50px default width 
        if (!x.hasOwnProperty("width")) {
            x["width"] = '50px';
        }
        //check if column grouping exist //columnGroup
        if (x.hasOwnProperty("columnGroup")) {
            self.columnGrouping = true;
        }
        //check if any column total then showTotal set to true
        if (x.hasOwnProperty("total")) {
            self.showTotal = true;
        }
        //hide column in grid  
        if (x.hasOwnProperty("display") && (x.display == "none")) {
            x["hidden"] = true;
        }
        return x;
    });
    this.colData = this.originalColData;
    this.colLen = this.colData.length;
    this.getSagGrid(function () {

    });
}


SagGridM.prototype.getSagGrid = function (callBack) {


    //set length again in when grid data change in search 
    this.rowLen = this.rowData.length;
    var self = this;

    this.gridRowObj = new GridRow(this);

    this.gridHtml = '<div class="main">' +
        '<div class="sag_grid">' +

        //<!--Header Drag Div  start -->
        '<div class="drag-div rowGroupDrop"  style="display:none;"></div>' +
        //<!--Header Drag Div End-->


        '  <div id="slm_tableMain" class="table_main">' +
        ' <div class="sml_headBody">  ' +
        '	<div class="sml_innerHeadBody">' +
        //<!-- Header start -->
        '   <div id="gridHeader" class="header_Blk">' +

        '     </div>' +
        //<!-- Header End -->  

        //<!--main Tbody table Start -->	
        ' <div id="verScroll" class="mainDivTbody" >' +

        '  <div class="mainDivTbodySecond gridTHeight" style = "height:' + this.gridHeight + 'px">' +

        //<!--main parent div left table -->
        ' <div id="leftGrid" class="parent_main left-tbl gridTHeight"  parent="left" style = "height:' + this.gridHeight + 'px; width:' + this.leftTableWidth + 'px">   ' +
        '   <div id="sag_grid_table_mainL"  class="sag_grid_table_main" >' +
        '   <div class="first_grid_tbody">' +
        '   <div class="table_body gridTHeight" style = "height:' + this.gridHeight + 'px">' +

        '  </div>' +
        '  </div>' +
        '    </div>' +
        '  </div>' +
        // <!--main parent div end left table-->  

        //<!--main parent div start center table-->
        '  <div id="centerGrid"  class="parent_main center-tbl gridTHeight" parent="center" style = "height:' + this.gridHeight + 'px;  width:${this.centerTableWidth}px"">  ' +
        '  <div id="sag_grid_table_mainC" class="sag_grid_table_main" >' +
        '    <div class="first_grid_tbody">' +
        '   <div class="table_body gridTHeight"  style = "height:' + this.gridHeight + 'px">' +

        '    </div>' +
        ' </div>' +
        '  </div>' +
        '  </div>' +
        // <!--main parent div end center table -->

        // <!--main parent div start right table-->
        '  <div id="rightGrid" class="parent_main right-tbl gridTHeight" parent="right" style = "height:' + this.gridHeight + 'px; width:' + this.rightTableWidth + 'px">' +
        '  <div id="sag_grid_table_mainR"  class="sag_grid_table_main" >' +
        '        <div class="first_grid_tbody">' +
        '            <div class="table_body gridTHeight" style = "height:' + this.gridHeight + 'px">' +

        '            </div>' +
        '         </div>' +
        '      </div>' +
        '   </div>' +
        // <!--main parent div end right table-->

        '   </div>' +

        '   </div>' +
        '  </div> ' +

        '<div id="totalFooter" class="totalFooter"></div>' +
        '  </div>' +


        //<!-- start Footer -->     

        '  <div  class="footerGrid">' +

        '  <div id="footer_hide" >' +


        '	<div id="BottomScrollBar" class="scrollBar">' +

        '<div id="secondLeftScroll" parent="left" class="gridLeftScroll">' +
        '	<div  class="secondLeftScroll"></div>' +
        '	</div>' +

        '	<div  id="secondCenterScroll" class="gridCenterScroll">' +
        '	<div  parent="center"  class="secondCenterScroll"></div>' +
        '</div>' +

        '	<div id="secondRightScroll" parent="right" class="gridRightScroll">' +
        '	<div class="secondRightScroll"></div>' +
        '	</div>' +


        '</div>' +

        '<div class="paginationBlk" > ' +

        '<nav  role="navigation" id=sml_Pagination style="display:none;" >' +
        '	<ul class="cd-pagination animated-buttons custom-icons pull-left">' +

        '</ul>' +
        '</nav>' +


        '	<span id="totalNoOfRecord" class="sml_totalRecord pull-left"> No. of Records </span>' +

        '	<div class="float-right" style="display: flex; flex-direction: row;">' +

        '		 <div id="showHideColmn" class="button-group dropup multiDropDown" style="margin-right: 5px">' +
        '		    <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-arrow-up" aria-hidden="true"></i> <span>Columns</span></button>' +
        '			<ul id="showHideColUl" class="dropdown-menu">' +

        '			</ul>	' +
        '		  </div>' +

        '		  <div class="btn-group btn-group-toggle pull-right" data-toggle="buttons">' +

        '			  <label id="exportBtnPage" class="btn btn-outline-primary btn-sm mr-1 allPageExport" export-type="exportBtnPage">' +
        '			    <i title="All Page Export" class="far fa-file-excel" aria-hidden="true"></i>' +
        '			  </label>' +
        '			   <label id="exportBtnAll" class="btn btn-outline-primary btn-sm mr-1 allPageExport" export-type="exportBtnAll">' +
        '			    <i title="All Page Export" class="far fa-file-excel" aria-hidden="true"></i>' +
        '			  </label>' +
        '			  <label id="exportBtnForPDFLandscape" class="btn btn-outline-primary btn-sm mr-1 allPageExport" export-type="exportBtnForPDFLandscape">' +
        '			   <i title="PDF Portrait" class="far fa-file-pdf" aria-hidden="true" style="color:red"></i>' +
        '			  </label>' +
        '			  <label id="exportBtnForPDFPortrait"  class="btn btn-outline-primary btn-sm mr-1 allPageExport" export-type="exportBtnForPDFPortrait">' +
        '			   <i title="PDF Landscape" class="far fa-file-pdf" aria-hidden="true" style="transform: rotate(90deg);color:red"></i>' +
        '			  </label>' +


        '			  <label id="ariaHidden" class="btn btn-outline-primary btn-sm mr-1">' +
        '			   <i class="fa fa-eye-slash" aria-hidden="true"></i>' +
        '			  </label>' +
        '			  <label id="sml_expandGrid" class="btn btn-outline-primary btn-sm addExpandClick">' +
        '			   <i class="fa fa-expand" aria-hidden="true"></i>' +
        '			  </label>' +


        '			</div>' +
        '		</div>  ' +
        '	</div>   ' +
        '</div>   ' +

        // <!-- End Footer -->                 
        //<!--main Tbody table END -->	
        '</div>' +
        '</div>' +
        '</div>' +
        '<div id="PopupFiletrSearch"></div>' +

        '</div>';



    let dom = GeneralEvent.createElementFromHTML(this.gridHtml);


    //self.gridEle = document.getElementById(self.sourceDivId);
    self.gridEle.innerHTML = '';
    self.gridEle.appendChild(dom);

    self.createGridHeader();
    self.createGridBody();

    /** Manage scroll in POPUP if DOM is not present */
    setTimeout(function () { self.bottomScrollObj.ceateScroll(); }, 0);

    /**Because compile only row for grid using addGridRowDom function 
                	
                     if(self.compile != null && self.scope != null){
                         self.compile(self.gridEle)(self.scope);    
                    }
                  **/

    callBack(true);
    //return this.gridHtml;  

    /**FOR MOBILE **/
    if (this.isMobile) {
        let centerWidth = (this.gridEle).querySelectorAll("div.center-tbl-header.superParent")[0].scrollWidth;
        (this.gridEle).querySelectorAll(".sml_innerHeadBody")[0].style.width = centerWidth + "px";
    }


}

//REmoved
SagGridM.prototype.createColElement = function () {
    for (let i = 0; i < this.colData.length; i++) {
        let obj = this.colData[i];
        if (obj.hasOwnProperty("element")) {
            this.columnElementObj[obj.field] = obj.element;
        }
    }
}



SagGridM.prototype.addGridRowDom = function (gridRowHtmlTest) {

    if (gridRowHtmlTest.center != '') {
        let center = gridRowHtmlTest.center;
        //if(this.compile != null && this.scope != null)
        //center = this.compile(GeneralEvent.createElementFromHTML(center))(this.scope);
        $((this.gridEle).querySelectorAll('#centerGrid .sag_grid_table_main .table_body')).append(center); //querySelectorAll('#leftGrid .sag_grid_table_main .table_body');
    }

    if (gridRowHtmlTest.right != '') {
        let right = gridRowHtmlTest.right;
        //if(this.compile != null && this.scope != null)
        //right = this.compile(GeneralEvent.createElementFromHTML(right))(this.scope);
        $((this.gridEle).querySelectorAll('#rightGrid .sag_grid_table_main .table_body')).append(right); //.querySelectorAll('#rightGrid .sag_grid_table_main .table_body')
    }

    if (gridRowHtmlTest.left != '') {
        let left = gridRowHtmlTest.left;
        //if(this.compile != null && this.scope != null)
        //left =  this.compile(GeneralEvent.createElementFromHTML(gridRowHtmlTest.left))(this.scope);
        $((this.gridEle).querySelectorAll('#leftGrid .sag_grid_table_main .table_body')).append(left); //(this.sagGridObj.gridEle).querySelectorAll('#leftGrid .sag_grid_table_main .table_body')
    }

    let sagGridEvent = new SagGridEvent(this);
    sagGridEvent.addClickListner();


    /** CALL BACK EVENT AFTER CELL CREATE  */
    if (this.isCellCallBack) {
        this.rowCellEvent.afterCellCallback(this.callBack.cellCallBack);
    }
    /** CALL BACK EVENT AFTER ROW CREATE  */
    if (this.isRowCallBack) {
        this.rowCellEvent.afterRowCallback(this.callBack.rowCallBack);
    }


    //  sagGridEvent.createRowSnapping();

}


SagGridM.prototype.createGridHeader = function () {

    $((this.gridEle).querySelectorAll("#gridHeader")).empty();

    let HeaderEle = (this.gridEle).querySelectorAll('#gridHeader')[0];
    let gridHeaderObj = new GridHeader(this);
    let gridHeaderHtml = gridHeaderObj.getHeaderHtml();
    gridHeaderObj.createHeaderFilterDiv();



    let htmlText = '' + gridHeaderHtml.left + gridHeaderHtml.center + gridHeaderHtml.right + '';
    // let dom = GeneralEvent.createElementFromHTML(htmlText); 
    HeaderEle.innerHTML = htmlText;
    // HeaderEle.appendChild(dom);

    let totalFooterEle = (this.gridEle).querySelectorAll('#totalFooter')[0];
    let totalFooterText = '' + gridHeaderHtml.leftFooter + gridHeaderHtml.centerFooter + gridHeaderHtml.rightFooter + '';
    totalFooterEle.innerHTML = totalFooterText;

    let totalNoOfReocord = (this.gridEle).querySelectorAll('#totalNoOfRecord')[0];
    if (this.clientSidePagging) {
        totalNoOfReocord.textContent = 'No. of Records: ' + this.totalRecordAllPage;
    } else {
        totalNoOfReocord.textContent = 'No. of Records: ' + this.originalRowData.length;
    }


    //seraching Event 
    let sagGridEvent = new SagGridEvent(this);
    sagGridEvent.searchFilter();
    sagGridEvent.addSortListner();
    sagGridEvent.addCheckBoxClick();
    sagGridEvent.addExportClick();
    sagGridEvent.addCellKeyEvent();
    sagGridEvent.headerComponent();
    sagGridEvent.GridExpandClick();
    sagGridEvent.customHeaderCheckbox();

    if (this.clientSidePagging) {
        sagGridEvent.createPagination();
    }



    let self = this;

    $(document).ready(function () {

        $((self.gridEle).querySelectorAll(".sagGridFilterCancel")).click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            $((self.gridEle).querySelectorAll("#filterScroll")).empty();
            $((self.gridEle).querySelectorAll(".dropdoenMenu")).toggle();
        });

        $((self.gridEle).querySelectorAll(".sagGridFilter")).click(function (event) {
            event.preventDefault();
            event.stopPropagation();

            $((self.gridEle).querySelectorAll(".dropdoenMenu")).toggle();

            var x = $(this).offset();

            var divWidth = $((self.gridEle).querySelectorAll(".dropdoenMenu")).outerWidth();
            var leftWidth = x.left;
            var totalWidth = screen.width;
            var leftDivWidth = divWidth + leftWidth;
            var topPos = x.top + 18;

            if (totalWidth < leftDivWidth) {
                let leftShift = leftDivWidth - totalWidth;
                leftWidth = leftWidth - leftShift;
            }

            var leftPadding = $($((self.gridEle).querySelectorAll(".dropdoenMenu")).closest(".modal-fullscreen")).css('padding-left');
            var topPadding = $($((self.gridEle).querySelectorAll(".dropdoenMenu")).closest(".modal-fullscreen")).css('top');

            if (leftPadding != undefined) {
                leftWidth = leftWidth - parseInt(leftPadding, 10);

            }
            if (topPadding != undefined) {
                topPos = topPos - parseInt(topPadding, 10);
            }

            $((self.gridEle).querySelectorAll(".dropdoenMenu"))[0].style.top = topPos + 'px';
            $((self.gridEle).querySelectorAll(".dropdoenMenu"))[0].style.left = leftWidth + 'px';


        });

    });

}

SagGridM.prototype.createGridBody = function () {

    let self = this;
    this.scrollObj.scrollToTop();


    let ele = GeneralEvent.createElementFromHTML('<div id="mp_wordBreakId" class="mp_wordBreak"> </div>');
    document.body.appendChild(ele);
    let word_wrapEle = document.getElementById("mp_wordBreakId");
    let trans_y = 0;

    if (self.wordBreak) {
        this.gridHeight = 0;
    }

    if (this.rowData.length > 0) {
        let ifAllChecked = true;
        this.rowData.map(function (x, index) {
            //check for al chekBox is checked or not 
            let indexKey = x["sag_G_Index"];
            if (!self.checkedRowIdArray.includes(indexKey)) {
                ifAllChecked = false;
            }


            if (self.wordBreak) {
                let indexheight = 20;
                self.wordbreakConfig[index] = { "height": 20, "trans_y": trans_y };
                self.originalColData.map(function (colObj) {
                    if (colObj.field && x[colObj.field]) {
                        height = self.wordbreakConfig[index].height;
                        word_wrapEle.style.width = colObj.width;
                        word_wrapEle.innerHTML = x[colObj.field];
                        let newHeight = $(word_wrapEle).height();
                        if (newHeight > indexheight) {
                            indexheight = newHeight;
                        }
                    }

                });
                self.wordbreakConfig[index]["height"] = indexheight;
                self.wordbreakConfig[index]["trans_y"] = trans_y;
                self.gridHeight = self.gridHeight + indexheight;
                trans_y = trans_y + indexheight;
            }

        });

        //document.removeChild(word_wrapEle);
        $(word_wrapEle).remove();

        if (!self.wordBreak) {
            this.gridHeight = this.rowData.length * this.OneRowHeight;
        }

        let verScrollGrid = (this.gridEle).querySelectorAll('#verScroll')[0];

        $((this.gridEle).querySelectorAll(".sagRow")).remove();
        this.gridRowIndexArray = [];
        this.inDomRowSpanIndex = [];

        let gridHeightEle = (this.gridEle).querySelectorAll('.gridTHeight');
        $(gridHeightEle).css("height", this.gridHeight);
        // gridHeightEle.style.height = this.gridHeight+"px";

        let gridleftEle = (this.gridEle).querySelector('#leftGrid');
        gridleftEle.style.width = this.leftTableWidth + "px";

        let gridCenterEle = (this.gridEle).querySelector('#centerGrid');
        gridCenterEle.style.width = this.centerTableWidth + "px";

        let gridRightEle = (this.gridEle).querySelector('#rightGrid');
        gridRightEle.style.width = this.rightTableWidth + "px";

        if (ifAllChecked) {
            $((self.gridEle).querySelectorAll(".sag-AllCheckboxCls")).removeClass(Property.fontAwsmClass.unChecked);
            $((self.gridEle).querySelectorAll(".sag-AllCheckboxCls")).addClass(Property.fontAwsmClass.checked);
        } else {
            $((self.gridEle).querySelectorAll(".sag-AllCheckboxCls")).removeClass(Property.fontAwsmClass.checked);
            $((self.gridEle).querySelectorAll(".sag-AllCheckboxCls")).addClass(Property.fontAwsmClass.unChecked);
        }
        this.setEventAfterGridLoad();
    }

    //elements hidden in grid
    self.hiddenGridElements();
    this.bottomScrollObj.manageScroll();

    let sagGridEvent = new SagGridEvent(this);
    sagGridEvent.showFooterSum();

    //self.rowGroupObj.getGroupData();

}


SagGridM.prototype.setEventAfterGridLoad = function () {

    var self = this;

    self.tableBodyLeft = (self.gridEle).querySelectorAll('#leftGrid .sag_grid_table_main .table_body');
    self.tableBodyRight = (self.gridEle).querySelectorAll('#rightGrid .sag_grid_table_main .table_body');
    self.tableBodyCenter = (self.gridEle).querySelectorAll('#centerGrid .sag_grid_table_main .table_body');
    self.tableBody = (self.gridEle).querySelectorAll('#verScroll .mainDivTbodySecond');

    //dragging
    let dragObj = new Dragging(self);
    dragObj.dragDropCol();

    //Row Grouping Drag
    let rowGrpObj = new RowDragging(self);
    rowGrpObj.dragForGroup();

    //Resize
    let resizeObj = new Resize(self);
    resizeObj.onResize();


    //scrolling 
    let scrollObj = new Scroll(self);

    let viewHeight = 0;
    if (self.viewHeight != null) {
        viewHeight = self.viewHeight;
    } else {
        viewHeight = $((self.gridEle).querySelectorAll('#verScroll')).height();
    }

    let totalRowInView = Math.round(viewHeight / this.OneRowHeight);
    if (totalRowInView == 0) {
        totalRowInView = 22;
    }
    let startRowLength = totalRowInView + 10;
    this.totalRowShow = startRowLength;

    if (this.rowData.length < startRowLength) {
        startRowLength = this.rowData.length;
    }


    this.gridRowIndexArray = [];

    //if row Grouping add all grouped row in starting
    // if (self.rowSpan) {
    //     for (let rwGrpI in self.rowObjSpanIndexWidth) {
    //         if (this.rowObjSpanIndexWidth.hasOwnProperty(rwGrpI)) {
    //             scrollObj.addRowByIndex(rwGrpI);
    //         }
    //     }
    // }

    for (let i = 0; i < startRowLength; i++) {
        scrollObj.addRow();
    }


    scrollObj.addGridScroll();

    // stop loder
    // GeneralEvent.stopLoader();

}


SagGridM.prototype.returnRowData = function (orgArray) {
    //remove extra added key from array 
    let rowData = orgArray.map(function (x, index) {
        //delete x.sag_G_Index;
        return x;
    });
    return rowData;
}


SagGridM.prototype.checkElements_hasOwnProperty = function (gridData) {

    var self = this;

    this.footer_hide = false;
    if (gridData.hasOwnProperty("footer_hide")) {
        self.footer_hide = gridData.footer_hide;
    }

    this.totalNoOfRecord_hide = false;
    if (gridData.hasOwnProperty("totalNoOfRecord_hide")) {
        self.totalNoOfRecord_hide = gridData.totalNoOfRecord_hide;
    }

    this.sml_expandGrid_hide = false;
    if (gridData.hasOwnProperty("sml_expandGrid_hide")) {
        self.sml_expandGrid_hide = gridData.sml_expandGrid_hide;
    }

    this.exportXlsxPage_hide = false;
    if (gridData.hasOwnProperty("exportXlsxPage_hide")) {
        self.exportXlsxPage_hide = gridData.exportXlsxPage_hide;
    }

    this.exportXlsxAllPage_hide = false;
    if (gridData.hasOwnProperty("exportXlsxAllPage_hide")) {
        self.exportXlsxAllPage_hide = gridData.exportXlsxAllPage_hide;
    }

    this.exportPDFLandscape_hide = false;
    if (gridData.hasOwnProperty("exportPDFLandscape_hide")) {
        self.exportPDFLandscape_hide = gridData.exportPDFLandscape_hide;
    }

    this.exportPDFPortrait_hide = false;
    if (gridData.hasOwnProperty("exportPDFPortrait_hide")) {
        self.exportPDFPortrait_hide = gridData.exportPDFPortrait_hide;
    }

    this.ariaHidden_hide = false;
    if (gridData.hasOwnProperty("ariaHidden_hide")) {
        self.ariaHidden_hide = gridData.ariaHidden_hide;
    }
    
    this.totalFooter_hide = false;
    if (gridData.hasOwnProperty("totalFooter_hide")) {
        self.totalFooter_hide = gridData.totalFooter_hide;
    }
    
}

SagGridM.prototype.hiddenGridElements = function () {

    var self = this;
    //footer hide in grid 
    if (self.footer_hide == true) {
        let ul = (self.gridEle).querySelector('#footer_hide');
        ul.style.display = "none";
    }

    //totalNoOfRecord hide in grid 
    if (self.totalNoOfRecord_hide == true) {
        let ul = (self.gridEle).querySelector('#totalNoOfRecord');
        ul.style.display = "none";
    }

    //sml_expandGrid hide in grid
    if (self.sml_expandGrid_hide == true) {
        let ul = (self.gridEle).querySelector('#sml_expandGrid');
        ul.style.display = "none";
    }

    //exportBtnPage hide in grid
    if (self.exportXlsxPage_hide == true) {
        let ul = (self.gridEle).querySelector('#exportBtnPage');
        ul.style.display = "none";
    }

    //exportBtnAll hide in grid
    if (self.exportXlsxAllPage_hide == true) {
        let ul = (self.gridEle).querySelector('#exportBtnAll');
        ul.style.display = "none";
    }

    //exportBtnForPDFLandscape hide in grid
    if (self.exportPDFLandscape_hide == true) {
        let ul = (self.gridEle).querySelector('#exportBtnForPDFLandscape');
        ul.style.display = "none";
    }

    //exportBtnForPDFPortrait hide in grid
    if (self.exportPDFPortrait_hide == true) {
        let ul = (self.gridEle).querySelector('#exportBtnForPDFPortrait');
        ul.style.display = "none";
    }

    //ariaHidden hide in grid
    if (self.ariaHidden_hide == true) {
        let ul = (self.gridEle).querySelector('#ariaHidden');
        ul.style.display = "none";
    }

     //totalFooter hide in grid
     if (self.totalFooter_hide == true) {
        let ul = (self.gridEle).querySelector('#totalFooter');
        ul.style.display = "none";
    }


}



/***
 * elements hidden keys declear
key : --->>

footer_hide
totalNoOfRecord_hide
sml_expandGrid_hide
exportXlsxPage_hide
exportXlsxAllPage_hide
exportPDFLandscape_hide
exportPDFPortrait_hide
ariaHidden_hide


//dragDropCol hide Dragging event

dragDropCol_hide

***/

/**
 * disableAllSearch:true
 */


/**
 * This function is checked column grouping case is enabled or not if
 * enabled then its return true otherwise it will return false
 */
SagGridM.prototype.checkColumnArrayForColumnGroupping = function (columnArrayJson) {

    for (var i = 0; i < columnArrayJson.length; i++) {
        if ("children" in columnArrayJson[i])
            return true;
        else
            continue;
    }
    return false;
}

SagGridM.prototype.getFieldColumn = function (columnArr) {

    if (columnArr && columnArr.length > 0) {

        for (var i = 0; i < columnArr.length; i++) {

            if ("children" in columnArr[i])
                this.getFieldColumn(columnArr[i]["children"]);
            else
                this.lastRowHeadArr.push(columnArr[i]);

        }

    }

}






