	 function GeneralEvent(sagGridObj){
		    this.sagGridObj = sagGridObj;
			this.callBackJson = this.sagGridObj.callBack;
			
			GeneralEvent.removeToolTip();
		}

	GeneralEvent.deepJsonCopy = function(json) {
				let newJson =  JSON.parse(JSON.stringify(json));
				return newJson;
		}

	GeneralEvent.insertInArray = (arr, index, newItem) => [
		...arr.slice(0, index),
		newItem,
		...arr.slice(index)
	];
		  
	
    GeneralEvent.createElementFromHTML = function(htmlString) {
        var div = document.createElement('div');
        div.innerHTML = htmlString.trim();
        // Change this to div.childNodes to support multiple top-level nodes
        return div.firstChild; 
    }
    
    GeneralEvent.createHtmlStrFromEle = function(ele) {
        var wrap = document.createElement('div');
        wrap.appendChild(ele.cloneNode(true));
        return wrap.innerHTML;
	}

	//GeneralEvent.startLoader();
	GeneralEvent.startLoader = function() {
	  $('#saggstloader').css("display", "block");
   }
   
   //GeneralEvent.stopLoader();
   GeneralEvent.stopLoader = function() {
		$('#saggstloader').css("display", "none");
   }
	
	GeneralEvent.removeToolTip = function() {
		$(function () {
			$('body').tooltip({
				selector: '[data-toggle="tooltip"]'
			}).click(function () {
				$('[data-toggle="tooltip"]').tooltip("hide");
			});
		});
		
    }
    
    
    GeneralEvent.prototype.onRowHover = function(ele) {
    	
    	//let rowId = $(ele).attr("sag_g_index");
    	// $((this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowId+'"]')).addClass("sml_hoverRow");
    	
    	
	    //compile this row for event 
	   /* if($(ele).attr("isCompiled") != "true"){
	    	this.sagGridObj.compile(ele)(this.sagGridObj.scope);
	    	$(ele).attr("isCompiled","true");
	    }*/
	    
    }
    
    GeneralEvent.prototype.outRowHover = function(ele){
    	//let rowId = $(ele).attr("sag_g_index");
    	//$((this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowId+'"]')).removeClass("sml_hoverRow");
	   
	}

	GeneralEvent.prototype.onCellClick = function(ele) {
	
		let rowId = $(ele).attr("sag_g_index");
		let cellIndex = $(ele).attr("tabIndex_col");
		let field = $(ele).attr("sag_G_Key");
		let cellValue = ele.innerText;
		let obj = {"rowIndex" : rowId,"field" : field,"cellIndex":cellIndex,"cellValue":cellValue};
		this.sagGridObj.gridEventObj.setSelectedCellIndex(obj);

		if(this.callBackJson.hasOwnProperty("onCellClick")){
			this.callBackJson.onCellClick(ele);
		} 

	}
    
    
    GeneralEvent.prototype.onRowClick = function(ele) {
    	let rowId = $(ele).attr("sag_g_index");
    	this.sagGridObj.gridEventObj.setSelectedRowIndex(rowId);
    	this.selectRowClrChange(rowId);
    
    	 if(this.callBackJson.hasOwnProperty("onRowClick")){
    		 this.callBackJson.onRowClick();
         } 	
    }
    
    
    GeneralEvent.prototype.onRowDblclick = function(ele) {
 
    	 if(this.callBackJson.hasOwnProperty("onRowDbleClick")){
    		 this.callBackJson.onRowDbleClick();
         } 	
      }
    
    
    GeneralEvent.prototype.onCheckBoxClick = function(data) {
    	 
   	 if(this.callBackJson.hasOwnProperty("onCheckBoxClick")){
   		 this.callBackJson.onCheckBoxClick(data);
        } 	
     }
    
    GeneralEvent.prototype.onAllCheckBoxClick = function(data) {
   	 
      	 if(this.callBackJson.hasOwnProperty("onAllCheckBoxClick")){
      		 this.callBackJson.onAllCheckBoxClick(data);
           } 	
	}

	GeneralEvent.prototype.onClickExpandCollapse = function (ele) {

		if (this.callBackJson.hasOwnProperty("onClickExpandCollapse")) {
			this.callBackJson.onClickExpandCollapse(ele);
		}
	}

GeneralEvent.prototype.onSearchFilter = function (ele) {

	if (this.callBackJson.hasOwnProperty("onSearchFilter")) {
		this.callBackJson.onSearchFilter(ele);
	}
}
	
	/**
	 * pass cell button component callback return 
	 */
	GeneralEvent.prototype.onButtonComponentClick = function(ele) {
		if(this.callBackJson.hasOwnProperty("onButtonComponentClick")){
			let cellEle = ele.parentElement.parentElement;
			let index = Number(cellEle.getAttribute("sag_g_index"));
			let colKey = cellEle.getAttribute("sag_g_key");
			let data = this.sagGridObj.originalRowData[index];
			let colVal = data[colKey];
				let obj = {
						"rowIndex":index,
						"colKey":colKey,
						"rowValue":data,
						"value":colVal,
				};
			this.callBackJson.onButtonComponentClick(ele,obj);
		} 	
     }

	/**
	 * call when row selection true for key event up and down 
	 */
	GeneralEvent.prototype.rowSelectionOnKeyDownUp = function(var_index){
		this.sagGridObj.gridEventObj.selectedRowINdex = var_index;
		this.selectRowClrChange(var_index);
		if(this.callBackJson.hasOwnProperty("onRowClick")){
			this.callBackJson.onRowClick();
		} 	
		//this.sagGridObj.scrollObj.scrollToIndex(var_index);
	}
    
  
    //onRowDblclick
    GeneralEvent.prototype.selectRowClrChange = function(rowIndex) {
    	let allCellElePre = $((this.sagGridObj.gridEle).querySelectorAll('div[sag_g_index]'));
    	allCellElePre.removeClass("sml_slectedRow");   //.css("background-color", ''); grid_cell
    	allCellElePre.removeClass("sml_hoverRow");
    	
    	let allCellEleNew = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+rowIndex+'"]');
	    $(allCellEleNew).addClass("sml_slectedRow"); //.css("background-color", '#9f9e9d');   //d8d8d8
	    //this.sagGridObj.scrollObj.scrollToIndex(rowIndex);
	    	 //allCellEleNew[0].scrollIntoView();

    }
    
    
    /** This method for setRow Property rowJson like that format {"color":"red"}; it will set tr attribute */
    GeneralEvent.prototype.setRowStyleProperty = function(var_rowIndex,var_rowJson) {
  
       let allCellEleNew = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+var_rowIndex+'"]');
       var var_keys = Object.keys(var_rowJson);
   	   for (var i = 0; i < allCellEleNew.length; i++) {
	    	  var item = allCellEleNew[i];
	    	  for(let j=0;j<var_keys.length;j++){
	    		  item.style[var_keys[j]] = var_rowJson[var_keys[j]];
	    	  }
	    	}
    }
	
	
	/** This method for set column by Row Property rowJson like that format {"color":"red"}; it will set tr attribute */
    GeneralEvent.prototype.setColRowStyleProperty = function(var_rowIndex,var_colKey,var_rowJson) {
  
		//let allCellEleNew = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+var_rowIndex+'", sag_g_key="'+var_colKey+'"]');
		let allCellEleNew = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_index="'+var_rowIndex+'"][sag_g_key="'+var_colKey+'"]');
		var var_keys = Object.keys(var_rowJson);
		   for (var i = 0; i < allCellEleNew.length; i++) {
			   var item = allCellEleNew[i];
			   for(let j=0;j<var_keys.length;j++){
				   item.style[var_keys[j]] = var_rowJson[var_keys[j]];
			   }
			 }
	 }

	 /** This method for set column by Row Property rowJson like that format {"color":"red"}; it will set tr attribute */
	 GeneralEvent.prototype.setColStyleProperty = function(var_colKey,var_rowJson) {
  
		let allCellEleNew = (this.sagGridObj.gridEle).querySelectorAll('[sag_g_key="'+var_colKey+'"]');
		var var_keys = Object.keys(var_rowJson);
		   for (var i = 0; i < allCellEleNew.length; i++) {
			   var item = allCellEleNew[i];
			   for(let j=0;j<var_keys.length;j++){
				   item.style[var_keys[j]] = var_rowJson[var_keys[j]];
			   }
			 }
	 }

	
    
    
    
    
  
    
    
    
	
	

	    
