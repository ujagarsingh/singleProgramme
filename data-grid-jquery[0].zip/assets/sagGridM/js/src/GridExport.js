function GridExport(sagGridObj){

	this.sagGridObj = sagGridObj;
}
var REST_SERVICE_URI = "/genius_gst/";
var exptype = null;
var param = null;
var gridExportName = "";

GridExport.prototype.onClickButton = function(ele){
	
	let exportType = ele.getAttribute("export-type");
	
	if(exportType == "exportBtnPage"){
			
		/**47 A
		 * This Method For Export the Data in Excel
		 * Here self is this mean self and this is same Object
		 * */
		this.exportGridData("allPage","xlsx","");
	
	}else if(exportType == "exportBtnAll"){
		/**48 B
		 * This Method For Export the Data in Excel
		 * Here self is this mean self and this is same Object
		 * */
		this.exportGridData("pageWise","xlsx","");
	
	}else if(exportType == "exportBtnForPDFPortrait"){


		/**48 C
		 * This Method For Export the Data in PDF landscape
		 * Here self is this mean self and this is same Object
		 * */
			this.exportGridData("allPage","pdf","landscape");
	
	}else if(exportType == "exportBtnForPDFLandscape"){
		
		/**48 D
		 * This Method For Export the Data in Excel
		 * Here self is this mean self and this is same Object
		 * */
			this.exportGridData("allPage","pdf","portrait");
		
	}
		
}


GridExport.prototype.exportGridData = function (exportMode, typeOfExp, pageOrient) {

	let self = this.sagGridObj;
	let thisObj = this;
	thisObj.var_gridUkey = 0;

	let checkedArray = [];

	let rowData = Array.from(self.rowData);
	let gridRowData = Array.from(self.rowData);
	let colData = Array.from(self.originalColData);
	let sanitizeKey = self.sanitizeHTML;

	this.addGridColumnModal_(thisObj.var_gridUkey);
	openPopup(thisObj.var_gridUkey, "open");
	//colData.shift();
	var copyColumnDef = JSON.parse(JSON.stringify(colData));
	var btn = $("#gridColumnModal_" + thisObj.var_gridUkey).find("button");
	var tbody = $("#gridColumnModal_" + thisObj.var_gridUkey).find("tbody")[0];
	var AllCheckBox = $("#gridColumnModal_" + thisObj.var_gridUkey).find(
		"#gcCheckbox")[0];
	AllCheckBox.checked = true;
	var checkBoxArr = [];
	var last = null;
	init();
	function init() {
		tbody.innerHTML = "";
		var trArray = [];
		for (var i = 0; i < copyColumnDef.length; i++) {
			var tr = document.createElement("tr");
			trArray.push(tr);
			setEventsOnTr(tr, trArray);
			var td = document.createElement("td");
			td.innerHTML = "<span class=\"checkbox\"><input type=\"checkbox\" class=\"gcCheckboxCheckedInput\" "
				+ "id=\"gcCheckbox" + i + "\" >"
				+ "<label for=\"gcCheckbox" + i + "\"\"></label></span>";
			var td1 = document.createElement("td");
			var Coldata = copyColumnDef[i];
			var checkBox = $(td).find("input")[0];
			if (copyColumnDef[i].hasOwnProperty("select"))
				checkBox.checked = copyColumnDef[i].select;
			else {
				copyColumnDef[i].select = true;
				checkBox.checked = true;
			}

			td1.innerHTML = Coldata.header;
			tr.appendChild(td);
			tr.appendChild(td1);
			tr.setAttribute("index", i);
			if (last && last == i)
				tr.className = "active";

			checkBoxArr.push(checkBox);
			setEvents(i, checkBox);
			tbody.appendChild(tr);
		}

		//$(".tableHeadFixed").tableHeadFixer();
		$(".tableHeadFixed").parent().addClass('tableHeadFixerMain');
		var done = function () {

			openPopup(thisObj.var_gridUkey, "close");

			var filterColumn = [];
			for (var k = 0; k < copyColumnDef.length; k++) {
				if (copyColumnDef[k].select) {
					var div = document.createElement("div");
					div.innerHTML = copyColumnDef[k].header;
					copyColumnDef[k].header = div.innerText;
					filterColumn.push(copyColumnDef[k]);
				}
			}

			for (let c = 0; c < colData.length; c++) {

				let colmn = colData[c];

				let componentType = false;
				if (colmn.hasOwnProperty("component")) {
					componentType = "component";
				} else if (colmn.hasOwnProperty("cellRenderView")) {
					componentType = "cellRenderView";
				} else {
					componentType = false;
				}

				if (componentType) {
					let field = colmn.field
					gridRowData = [];
					gridRowData = rowData.map(function (x, index) {

						let val = x[field];
						let conponentName = colData[c][componentType];

						let compObj = self.components[conponentName];
						// let compObj = new component();
						let params = {
							"rowIndex": index,
							"colKey": field,
							"rowValue": x,
							"colValue": colData[c],
							"value": val,
						};
						compObj.init(params);
						// fieldVal = compObj.getValue();
						fieldVal = compObj.getText();
						x[field] = fieldVal;
						return x;
					});

				}

			}

			let mergeObj = {};
			// assign key of sanitize
			mergeObj["senetize"] = sanitizeKey;

			if (self.columnChildrenFlag) {
				mergeObj["columns"] = self.ExportColumnArray;
			} else
				mergeObj["columns"] = filterColumn;
				
			if (exportMode != null) {
				if (exportMode == "pageWise")
					mergeObj["rows"] = gridRowData;
				else
					mergeObj["rows"] = gridRowData;
			} else
				mergeObj["rows"] = gridRowData;



			
			// added by ujagar for export time senetize data (remove html tags)
			function senetizeJson(jData, pinPoint){
				function senetizeStr(str){
					const _str = str.replace(/<\/?[^>]+>/gi, '');
					return _str; 
				}

				function generatedData(item){
					for (const [key, value] of Object.entries(item)) {
						// console.log(`${key}: ${value}`);
						let _pinPoint = item[pinPoint];
						if(_pinPoint){
							item[pinPoint] = senetizeJson(_pinPoint, pinPoint);
						} else if(value && value.length > 0){
							item[key] = senetizeStr(value);
						} 
					}
					return item;
				}
				const _rows = jData.map((item)=>{
					const _item = generatedData(item);
					return _item;
				});
			return _rows;
			}

			let clonedObj = Object.assign(mergeObj);
			let newObj = {};
			newObj['columns'] = clonedObj.columns;
			if(clonedObj.senetize){
				newObj['rows'] = senetizeJson(clonedObj.rows, 'detail');
			} else {
				newObj['rows'] = clonedObj.rows;
			}
			// added by ujagar for export time senetize data (remove html tags)
			

			
			if (self.ExcelExportService != null) {
				if (self.sheatDetailsfun) {
					newObj["sheatDetails"] = self.sheatDetailsfun();
				} else if (self.sheatDetails) {
					newObj["sheatDetails"] = self.sheatDetails;
				}
				if (self.clientDetail){
					newObj["clientDetail"] = self.clientDetail;
				}
				/* typeOfExp,pageOrient */
				if (typeOfExp == "xlsx") {
					self.ExcelExportService.gridDataExport(newObj, "xlsx");
						// .then(function (response) {
						// 	console.log("File Export Successfully");
						// }, function (errorMgs) {
						// 	console.log("Error occued for Export Data..!");
						// });
				} else {
					newObj["orientation"] = pageOrient;
					self.ExcelExportService.gridDataExport(newObj, "pdf");

				}

			} else {
				if (typeOfExp == "pdf"){
					newObj["orientation"] = pageOrient;	
				}
				gridExportName = self.gridEle['id'];
				gridDataExport(newObj, typeOfExp);
				//alert("ExportService Is Null ...!");
			}
		}

		btn[3].onclick = done;
		btn[4].onclick = function () {
			openPopup(thisObj.var_gridUkey, "close");
		};

		btn[0].onclick = function () {
			openPopup(thisObj.var_gridUkey, "close");
		};
		// up
		btn[1].onclick = function () {
			var selectedTr = $(tbody).find("tr.active")[0];
			if (selectedTr) {
				var index = parseInt(selectedTr.getAttribute("index"));
				if (index != 0) {
					var temp = copyColumnDef[index - 1];
					copyColumnDef[index - 1] = copyColumnDef[index];
					copyColumnDef[index] = temp;
					last = index - 1;
					checkBoxArr = [];
					init();
				} else
					alert("Already In Top..!");
			} else {
				alert("Please Select Row first..!");
			}
		};
		// down
		btn[2].onclick = function () {
			var selectedTr = $(tbody).find("tr.active")[0];
			if (selectedTr) {
				var index = parseInt(selectedTr.getAttribute("index"));
				if (index != copyColumnDef.length - 1) {
					var temp = copyColumnDef[index + 1];
					copyColumnDef[index + 1] = copyColumnDef[index];
					copyColumnDef[index] = temp;
					last = index + 1;
					checkBoxArr = [];
					init();
				} else
					alert("Already In Buttom..!");
			} else {
				alert("Please Select Row first..!");
			}
		};

		AllCheckBox.onclick = function () {
			if (AllCheckBox.checked == false) {
				$((self.gridEle).querySelector('#btnFilterSaveButton')).attr('disabled', 'disabled');
				checkedArray = [];
			}
			else {
				$((self.gridEle).querySelector('#btnFilterSaveButton')).removeAttr('disabled');
			}
			for (var i = 0; i < checkBoxArr.length; i++) {
				checkBoxArr[i].checked = AllCheckBox.checked;
				copyColumnDef[i].select = AllCheckBox.checked;
				checkedArray.push(i);
			}
		}

	}// Close init

	function openPopup(gridKey, operation) {
		//var popup = $((self.gridEle).querySelector('#gridColumnModal_' + gridKey)); // $("#gridColumnModal_" + gridKey);
		if (operation == "open")
		$('#gridColumnModal_' + gridKey).modal('show')
		else
		$('#gridColumnModal_' + gridKey).modal('hide')
	}
	function setEvents(index, checkBox) {

		checkBox.onclick = function () {

			if ($((self.gridEle).querySelectorAll('.gcCheckboxCheckedInput:checked')).length == 0) {
				$((self.gridEle).querySelector('#btnFilterSaveButton')).attr('disabled', 'disabled');
			}
			else {
				if ($((self.gridEle).querySelector('#btnFilterSaveButton')).is(':disabled')) {
					$((self.gridEle).querySelector('#btnFilterSaveButton')).removeAttr('disabled');
				}
			}
			copyColumnDef[index].select = checkBox.checked;
			var all = true;
			for (var i = 0; i < checkBoxArr.length; i++) {
				if (!checkBoxArr[i].checked) {
					all = false;
					break;
				}
			}
			AllCheckBox.checked = all;
		};
	}
	function setEventsOnTr(tr, trList) {
		tr.onclick = function () {
			for (var j = 0; j < trList.length; j++) {
				trList[j].className = "";
			}
			tr.className = "active";
		};
	}
}


GridExport.prototype.addGridColumnModal_ = function (uniqueId) {

	let self = this.sagGridObj;

	var addGridColumn = "<div class='modal modal-small fade in gridColumnModal_0' id='gridColumnModal_"
		+ uniqueId
		+ "' role='dialog' style='z-index: 1055;'><div class='modal-dialog modal-sm_ modal-sm-2x modal-dialog-centered'><div class='modal-content'>"
		+ "<div class='modal-header respectHeader'><h4 class='modal-title'>Grid Column</h4><button type='button' class='btn btn-default close' data-dismiss='modal'>&times;</button></div>"
		+ "<div class='modal-body' style='overflow:hidden'><div class='table-responsive gridColumnTbl height60vh mt-0'><table class='table table-bordered staticHeadTbl tableHeadFixed'>"
		+ "<thead><tr><th class='p-1'><span class='custom-control custom-checkbox'><input class='custom-control-input' type='checkbox' id='gcCheckbox' /><label class='custom-control-label' for='gcCheckbox'>Select All</label></span></th><th class='p-1'><span class='mr-5'>Column Name</span><span class='topBottomIcons form-inline- ml-auto'><button class='btn btn-primary btn-sm'><i class='fa fa-arrow-up'></i></button> <button class='btn btn-primary btn-sm'><i class='fa fa-arrow-down'></i></button></span></th></tr></thead>"
		+ "<tbody><tr><td><span class='custom-control custom-checkbox'><input class='custom-control-input' type='checkbox' id='gcCheckbox1' /><label class='custom-control-label' for='gcCheckbox1'></label></span></td><td>Txn_Count</td></tr></tbody>"
		+ "</table></div></div>"
		+ "<div class='modal-footer fixed-footer'>"
		+ "<button id='btnFilterSaveButton' class='btn btn-primary'><i class='fa fa-floppy-o'></i><span>Save</span></button> <button class='btn btn-danger' data-dismiss='modal'><i class='fa fa-times-circle'></i><span>Cancel</span></button></div>"
		+ "</div></div></div>";

		$((self.gridEle).querySelector('.main')).append(addGridColumn);
}



function gridDataExport(dataObj, type) {
	
	exptype = type;
	if (!type)
		type = "xlsx";//As per Default
	var url = REST_SERVICE_URI + "gird/export/" + type;
	param = { data: dataObj }
	return new Promise(function (resolve, reject) { 
		var req = new XMLHttpRequest();
		req.open('post', url); 
		req.setRequestHeader('Content-Type', 'application/json');
		req.onload = function () {
			if (req.status == 200) {
				var data = JSON.parse(req.response);
				if (data.hasOwnProperty("success")) {
					var key = data.key;
					downloadExportFile(key, type).then(
						function (response) {
							success("file Download Successfully");
							resolve(response.data);
						},
						function (error) {
							alerts("Error Occuered ..!");
							reject(Error(error));
						}
					);
				}
				
			} else {		
				console.error('Error while sending data');
				alerts("Error Occuered ..!");
				reject(Error(req.statusText));
			}
		}; 
		req.send(JSON.stringify(param));
})
}

function downloadExportFile(key, type) {

	let url = REST_SERVICE_URI + "gird/downloadExcel?key=" + key;
	return new Promise(function (resolve, reject) {
		var req = new XMLHttpRequest();
		req.open('GET', url);
		req.setRequestHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		req.responseType = "arraybuffer";
		req.onload = function () {
			if (req.status == 200) {
				var data = req.response;

				var defaultFileName = "export" + ((exptype == "pdf") ? ".pdf" : ".xlsx");
				if (gridExportName != "") {
					defaultFileName = gridExportName + ((exptype == "pdf") ? ".pdf" : ".xlsx");
				}
				exptype = null;
				// var disposition = req.headers('Content-Disposition');

				// if (disposition) {
				// 	var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
				// 	if (match[1])
				// 		defaultFileName = match[1];
				// }
				defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
	
				downloadFile(data, defaultFileName);
				resolve(defaultFileName);
						
			} else {
				console.error('Error while sending data');
				alerts("Error Occuered ..!");
				reject(Error(req.statusText));
			}
		};
		req.send();
	});

}


var downloadFile = (function () {
	var a = document.createElement("a");
	document.body.appendChild(a);
	//a.style = "display: none" // not supported in IE
	$(a).addClass('hidden');

	return function (data, fileName) {
		blob = new Blob([data], { type: "octet/stream" }),
			url = window.URL.createObjectURL(blob);
		a.href = url;
		if (param && param.data && param.data.orientation) {
			fileName = fileName.substring(0, fileName.lastIndexOf('.')) + "_" + param.data.orientation + ".pdf";
		}
		if (fileName.indexOf('.') == -1) {
			fileName = fileName + ".xlsx";
		}
		a.download = fileName;
		//changes according to IE-11
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf("MSIE ");
		if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))  // If Internet Explorer, return version number
		{
			window.navigator.msSaveBlob(blob, fileName);
		} else // If another browser, return 0
		{
			a.click();
		}

		window.URL.revokeObjectURL(url);
	};
}());






















