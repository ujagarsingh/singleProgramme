import { accVoucherEntryConstants } from '../_constants';

export function accVoucherEntry(state = {}, action) {
  switch (action.type) {
    case accVoucherEntryConstants.VOUCHER_ENTRY_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accVoucherEntryConstants.VOUCHER_ENTRY_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accVoucherEntryConstants.VOUCHER_ENTRY_FAILURE:
      return {
        error: action.error
      };


    case accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accVoucherEntryConstants.CREATE_VOUCHER_ENTRY_FAILURE:
      return {
        error: action.error
      };



    case accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accVoucherEntryConstants.UPDATE_VOUCHER_ENTRY_FAILURE:
      return {
        error: action.error
      };


    case accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accVoucherEntryConstants.DELETE_VOUCHER_ENTRY_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}