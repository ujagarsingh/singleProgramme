import { defaultSliderConstants } from '../_constants';

export function defaultSlider(state = {}, action) {
  switch (action.type) {
    case defaultSliderConstants.SLIDER_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case defaultSliderConstants.SLIDER_SUCCESS:
      return {
        item: action.response
      };
    case defaultSliderConstants.SLIDER_FAILURE:
      return {
        error: action.error
      };

 

    default:
      return state
  }
}