import { sessionYearsConstants } from '../_constants';
import { sessionYearsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const sessionYearsAction = {
    getSessionYears
};

function getSessionYears() { 
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        sessionYearsService.getSessionYears()
            .then(
                response => {
                    dispatch(success(response.data.ses_year_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: sessionYearsConstants.SESSION_YEAR_REQUEST } }
    function success(response) { return { type: sessionYearsConstants.SESSION_YEAR_SUCCESS, response } }
    function failure(error) { return { type: sessionYearsConstants.SESSION_YEAR_FAILURE, error } }
}
