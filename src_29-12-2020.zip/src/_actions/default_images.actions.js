import { defaultImagesConstants } from '../_constants';
import { defaultImagesService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const defaultImagesActions = {
    getDefaultImages
};

function getDefaultImages() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        defaultImagesService.getDefaultImages()
            .then(
                response => {
                    dispatch(success(response.data.images_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: defaultImagesConstants.IMAGES_REQUEST } }
    function success(response) { return { type: defaultImagesConstants.IMAGES_SUCCESS, response } }
    function failure(error) { return { type: defaultImagesConstants.IMAGES_FAILURE, error } }
}
 