import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
// import axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
// import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { professionalAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const GET_PROFESSIONAL = `http://schools.rajpsp.com/api/professional/read_one.php`;
// const READ_ALL_STAFF_IDS = `http://schools.rajpsp.com/api/professional/read_all_staff_ids.php`;

class ProfessionalProfile extends Component {
  state = {
    current_id: '',
    prev_id: '',
    next_id: '',
    is_prev: false,
    is_next: false,
    all_staffs_ids: [],
    proff: '',
    user_category: '',
    group_id: '',
    school_id: '',
    user_category: '',
    session_year_id: '',
    formIsHalfFilledOut: false,
  }
  isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }

  componentDidMount() {
    if (isEmptyObj(this.props.professional)) {
      this.props.getProfessional();
    }
    this.checkFlag();
  }

  checkFlag() {
    setTimeout(() => {
      const _all_prof = this.props.professional;
      if (_all_prof) {
        this.checkAuthentication();
      } else {
        this.checkFlag()
      }
    }, 100);
  }


  checkAuthentication() {
    loadProgressBar();
    const { match } = this.props;
    const current_id = match.params.id;

    this.setState({
      current_id: current_id,
    }, () => {
      this.getProffRecords();
      this.getAllStaffIdsHandler()
    })

    // axios.post(VALIDATE_URL, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     // sessionStorage.setItem("user", getRes.data);
    //     console.log(getRes);
    //     if (getRes.data) {
    //       this.setState({
    //         user: getRes.data,
    //         group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
    //         school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
    //         user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
    //         session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
    //         current_id: current_id
    //       }, () => {
    //         this.getProffRecords();
    //         this.getAllStaffIdsHandler()
    //       })
    //     }
    //   }).catch((error) => {
    //     this.props.history.push('/login.jsp');
    //   })
  }

  setStaffItsHandler() {
    debugger
    const _current_id = this.state.current_id;
    const _staff_ids = this.state.all_staffs_ids;
    let _prev_id = '';
    let _next_id = '';
    let _is_prev = false;
    let _is_next = false;
    let _chnage_state = false;
    for (let i = 0; i < _staff_ids.length; i++) {

      if (_current_id === _staff_ids[i].s_id && (i >= 0 && i < _staff_ids.length)) {

        if (i === 0) {
          _prev_id = _staff_ids[_staff_ids.length - 1].s_id;
        } else {
          _prev_id = _staff_ids[i - 1].s_id;
        }

        if (i === _staff_ids.length - 1) {
          _next_id = _staff_ids[0].s_id;
        } else {
          _next_id = _staff_ids[i + 1].s_id;
        }


        _chnage_state = true;
        if (i == 0) {
          _is_prev = true;
        } else if (i == _staff_ids.length - 1) {
          _is_next = true;
        }
        break;
      }
    }

    if (_chnage_state) {
      this.setState({
        prev_id: _prev_id,
        next_id: _next_id,
        is_prev: _is_prev,
        is_next: _is_next
      })
    }
  }
  getPrevStaffRecord(e, _id) {
    e.preventDefault();
    this.setState({
      current_id: _id
    }, () => {
      this.getProffRecords();
      this.setStaffItsHandler();
      this.changeUrlHandler();
    })
  }
  changeUrlHandler() {
    this.props.history.push(`/professional_profile.jsp/${this.state.current_id}`);
  }

  getAllStaffIdsHandler() {
    const _professional = this.props.professional;
    const school_id = this.props.user.school_id;
    let all_Ids = [];
    _professional.map((item) => {
      if (item.school_id === school_id) {
        all_Ids = [...all_Ids, { s_id: item.id, emp_name: item.emp_name }]
      }
    })

    this.setState({
      all_staffs_ids: all_Ids
    }, () => {
      this.setStaffItsHandler()
    })


    // axios.post(READ_ALL_STAFF_IDS, obj)
    //   .then(res => {
    //     const resData = res.data;
    //     // console.log(resData);
    //     this.setState({
    //       all_staffs_ids: resData,
    //       errorMessages: resData.message
    //     }, () => {
    //       this.setStaffItsHandler()
    //     });
    //   }).catch((error) => {
    //     // error
    //   });
  }
  getProffRecords() {
    const staff_id = this.state.current_id;
    const _professional = this.props.professional;

    const _proff = _professional.filter((item, index) => {
      if (item.id === staff_id) {
        return item
      }
    })

    this.setState({
      proff: _proff[0]
    });

    // axios.get(GET_PROFESSIONAL + '?id=' + staff_id)
    //   .then(res => {
    //     const getRes = res.data;
    //     if (getRes.message !== undefined) {
    //       Alert.error(getRes.message, {
    //         position: 'bottom-right',
    //         effect: 'jelly',
    //         timeout: 5000, offset: 40
    //       });
    //     }
    //     this.setState({
    //       proff: getRes,
    //       errorMessages: res.data.message
    //     });
    //     //console.log(proff);
    //   }).catch((error) => {
    //     // error
    //   })
  }

  render() {
    const { proff, prev_id, next_id, is_prev, is_next, formIsHalfFilledOut } = this.state;
    const { user, professional } = this.props;
    // console.log(this.state)
    return (
      <div className="page-content">
        <Helmet>
          <title>Professional Profile</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <div className="page-bar d-flex">
          <div className="page-title">Professional Profile</div>
        </div>
        {user && professional &&
          <div className="card card-box sfpage-cover">
            <div className="card-body sfpage-body">
              <div className="table-scrollable">
                <div className="col-md-12">
                  {/* BEGIN PROFILE SIDEBAR */}
                  <div className="profile-sidebar">
                    <div className="card mb-4 card-topline-aqua">
                      <div className="card-body p-0">
                        <div className="row">
                          <div className="profile-userpic">
                            {!this.isEmpty(proff.profile_image) ?
                              < img src={`${process.env.PUBLIC_URL}` + proff.profile_image} className="img-responsive" alt={proff.emp_name} />
                              : (proff.gender === 'Male' ?
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_male.jpg`} className="img-responsive" alt="" />
                                :
                                <img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/prof_female.jpg`} className="img-responsive" alt="" />)
                            }
                          </div>
                        </div>
                        <div className="profile-usertitle">
                          <div className="profile-usertitle-name"> {proff.emp_name} </div>
                          <div className="profile-usertitle-job"> {proff.emp_crnt_designation} </div>
                        </div>
                        <ul className="list-group list-group-unbordered">
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">Class Teacher</b> <span className="pull-right">{proff.class_teacher}</span>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">DOJ</b> <span className="pull-right">{proff.appoint_date}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="card mb-4">
                      <div className="card-body p-0">

                        <ul className="list-group list-group-unbordered">

                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">DOB </b>
                            <div className=" pull-right">{proff.dob}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">Gender </b>
                            <div className=" pull-right">{proff.gender}</div>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">Father's Name</b><span className="pull-right">{proff.emp_f_name}</span>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">Caste</b><span className="pull-right">{proff.caste}</span>
                          </li>
                          <li className="list-group-item d-flex justify-content-between">
                            <b className="font-bold text-muted">Mobile</b>
                            <div className=" pull-right">{proff.emp_mob}</div>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="card mb-4">
                      <div className="card-head card-topline-aqua">
                        <header className="p-2">Address</header>
                      </div>
                      <div className="card-body p-0">
                        <div className="row text-center m-t-10">
                          <div className="col-md-12">
                            <p>{proff.address}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* END BEGIN PROFILE SIDEBAR */}
                  {/* BEGIN PROFILE CONTENT */}
                  <div className="profile-content">
                    <div className="card">
                      <div className="card-topline-aqua">
                        <header />
                      </div>
                      <div className="card-body">
                        <div id="biography">
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Education</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.pacific_ability}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Educational qualification</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.edu_qulifi}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Is the teacher RTET / REET / CTET qualified</b>?</h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.is_rtet_qlifid}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Employee (Type</b>)</h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.emp_type}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Class Teacher</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.class_teacher}</li>
                          </ul>
                          {/* <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Relieve Date</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.relieve_date}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Relieve Status</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.relieve_status}</li>
                          </ul>
                          <hr /> */}
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Show in Home page</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{(proff.show_home === '1') ? 'Yes' : 'No'}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Medium</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.medium}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Secondary Roll No</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.sec_roll_no}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Secondary Year</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.sec_year}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Employee Current Subject</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.emp_cur_sub}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Aadhar No</b>.</h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.aadhar_no}</li>
                          </ul>
                          <hr />
                          <h6 className="font-bold text-muted"><b className="font-bold text-muted">Responsibility</b></h6>
                          <ul className="ml-4 pl-4">
                            <li>{proff.responsibility}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* END PROFILE CONTENT */}
                </div>
              </div>
            </div>
            <div className="card-footer d-flex p-2">
              {(this.props.user.user_category === '1' || this.props.user.user_category === '2') ?
                <>
                  <button type="button"
                    onClick={event => this.getPrevStaffRecord(event, prev_id)}
                    disabled={is_prev}
                    className="btn btn-primary text-white">
                    <i className="fa fa-angle-left"></i>
                  </button>
                  <button type="button"
                    onClick={event => this.getPrevStaffRecord(event, next_id)}
                    disabled={is_next}
                    className="btn btn-primary ml-3 text-white">
                    <i className="fa fa-angle-right"></i>
                  </button>

                  <NavLink className="btn btn-primary mr-2 ml-auto"
                    to={`/edit_professional.jsp/${proff.id}`}>
                    Edit</NavLink>
                  <NavLink to="/all_professionals.jsp" className="btn btn-danger">Back</NavLink>
                </>
                :
                <NavLink to="/dashboard.jsp" className="btn btn-danger">Back</NavLink>
              }
            </div>
          </div>
        }
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: professional } = state.professional;
  return { user, professional };
}

const actionCreators = {
  getProfessional: professionalAction.getProfessional,
}

export default connect(mapStateToProps, actionCreators)(withRouter(ProfessionalProfile));