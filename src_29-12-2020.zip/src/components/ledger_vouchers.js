import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction, accManagerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
class LedgerVouchers extends Component {

	state = {
		formIsHalfFilledOut: false,
		showDetails: false
	}

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
			this.props.getAccLedgerEntry();
		}

		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}

		if (isEmptyObj(this.props.accGroup)) {
			this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		// this.checkFlag();
		this.getLedgerSummaryofMonthHandler();
	}

	getLedgerSummaryofMonthHandler() {
		const { match } = this.props;
		const _ldr_id = match.params.l_id;
		const _month_id = match.params.m_id;
		const _accManager = this.props.accManager;
		const _accLedgerEntry = this.props.accLedgerEntry;
		this.props.getLedgerSummaryofMonthHandler({
			"acc_manager": _accManager,
			"ledger_id": _ldr_id, "month_id": _month_id, "accLedgerEntry": _accLedgerEntry
		})
	}
	/*
	blnc_type: "Cr"
	child_data: (2) [{…}, {…}]
	cl_blnc: 68
	g_name: "Exam Fee /..."
	gt_cr: 0
	gt_dr: 68
	*/
	manageDetailHandler() {
		this.setState({
			showDetails: !this.state.showDetails
		})
	}
	render() {
		const { ldr_summary, ledger_name } = this.props;
		const { showDetails } = this.state;
		// console.log(this.props);
		return (
			<div className="page-content">
				<Helmet>
					<title>Group Summary</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Group Summary</div>
					<div className="form-inline ml-auto filter-panel">
						<span className="filter-closer">
							<button type="button" className="btn btn-danger filter-toggler-c">
								<i className="fa fa-times"></i>
							</button>
						</span>
						<div className="filter-con pt-1">
							<button className="btn btn-primary btn-sm"
								onClick={() => { this.manageDetailHandler() }}>
								{(showDetails) ? "Hide Detail" : "Show Detail"}
							</button>
						</div>
					</div>
				</div>
				{ldr_summary &&
					<div className="card card-box sfpage-cover">
						<div className="card-body p-1 sfpage-body">
							<div className="acc-page page-ledger-vouchers">
								<div className="acc-page-head  container-fluid">
									<div className="sec-title">
										<div className="title-zone"><span className="text-secondary">Ledger :</span> {ledger_name}</div>
										<div className="info-zone">
											<div className="fy-detail"><strong>1-Apr-2020 to 1-Jul-2020</strong></div>
										</div>
									</div>
								</div>
								<div className="acc-page-body container-fluid">
									<div className="table-scrollable">
										<table className="table table-striped table-bordered table-hover table-sm m-0">
											<thead>
												<tr className="lv-body-head">
													<th className="vch-date">Date</th>
													<th width={300} className="vch-name">Particulars</th>
													<th width={100}></th>
													<th width={100}></th>
													<th className="vch-type">Vch Type</th>
													<th className="vch-no">Vch No.</th>
													<th className="dr-amount">Debit</th>
													<th className="cr-amount">Credit</th>
												</tr>
											</thead>
											<tbody className="lv-body-area">
												{ldr_summary.child.map((sitem, inx) => {
													return (
														<React.Fragment key={inx}>
															<tr className="lv-detail-zone" >
																<td className="vch-date">{sitem.g_date}</td>
																<td className="vch-name">
																	<NavLink to={`/accounting_vouchers.jsp/${sitem.g_id}`} className="link-without-color">
																		{sitem.g_name}
																	</NavLink>
																</td>
																<td></td>
																<td></td>
																<td className="vch-type">{sitem.g_type}</td>
																<td className="vch-no">{sitem.g_id}</td>
																<td className="dr-amount">{(sitem.gdr_amo === 0) ? '' : sitem.gdr_amo}</td>
																<td className="cr-amount">{(sitem.gcr_amo === 0) ? '' : sitem.gcr_amo}</td>
															</tr>
															{(showDetails) && sitem['child_data'].map((item, index) => {
																return (
																	<tr className="lv-detail-zone" key={index} data-id={item.ldr_ref_id}>
																		<td className="vch-date"></td>
																		<td className="vch-name">{item.ldr_name}</td>
																		<td className="dr-amount">{item.dr_amo}.00</td>
																		<td className="cr-amount">{item.cr_amo}.00</td>
																		<td className="vch-type"></td>
																		<td className="vch-no"></td>
																		<td></td>
																		<td></td>
																	</tr>
																)
															})
															}
														</ React.Fragment>
													)
												})}
											</tbody>
										</table>
									</div>
								</div>
								<div className="acc-page-footer container-fluid">
									<div className="sec-foot">
										<div className="cl-blnc-zone">
											<div className="title-zone">Opening Balance : </div>
											<div className="amount-zone">
												<div className="dr-total">0,00,001.00</div>
												<div className="cr-total"></div>
											</div>
										</div>
										<div className="cl-blnc-zone">
											<div className="title-zone">Current Total : </div>
											<div className="amount-zone">
												<div className="dr-total">{ldr_summary.tdr}</div>
												<div className="cr-total">{ldr_summary.tcr}</div>
											</div>
										</div>
										<div className="cl-blnc-zone">
											<div className="title-zone">Closing Balance : </div>
											<div className="amount-zone">
												<div className="dr-total">{(ldr_summary.blnc_type == "Dr") ? ldr_summary.cl_blnc : ""}</div>
												<div className="cr-total">{(ldr_summary.blnc_type == "Cr") ? ldr_summary.cl_blnc : ""}</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				}
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	const { item: accManager } = state.accManager;
	const { ledger_summary_of_month: ldr_summary } = state.accManager.item;
	const { ledger_name } = state.accManager.item.ledger_fy_report;
	return {
		user, students, accLedger, accGroup, accLedgerEntry,
		ldr_summary, accManager, ledger_name,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
	getLedgerSummaryofMonthHandler: accManagerActions.getLedgerSummaryofMonthHandler,
	getVoucherEntryHandler: accManagerActions.getVoucherEntryHandler,

}

export default connect(mapStateToProps, actionCreators)(withRouter(LedgerVouchers));