import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { schoolsAction, frontGalleryActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// const CREATE_GALLERY = `http://schools.rajpsp.com/api/galleries/gallery/create.php`;

class AddGallery extends Component {
  state = ({
    medium: "",
    title: "",
    description: "",
    isActive: true,
    formIsHalfFilledOut: false,
  })
  changeHandler = (event, fieldName, isCheckbox) => {
    if (fieldName === 'school') {
      const _inx = event.target.value;
      const _sch_id = (!isEmpty(_inx)) ? this.props.schools[_inx].id : '';
      const _medium = (!isEmpty(_inx)) ? this.props.schools[_inx].sch_medium : [];
      sessionStorage.setItem("school_id", _sch_id);
      // this.filterClassesOnSchool(_sch_id, this.props.user.group_id);
      this.setState({
        school_id: _sch_id,
        medium_arr: _medium,
        medium: (_medium.length === 1 ? _medium[0] : ''),
        selected_school_index: _inx,
        selected_class_inx: ''
      })
    } else if (fieldName === 'medium') {
      const _medium = event.target.value;
      sessionStorage.setItem("medium", _medium);
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value
      });
    } else {
      this.setState({
        [fieldName]: isCheckbox ? event.target.checked : event.target.value,
        formIsHalfFilledOut: true
      })
    }
  };
  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
  }
  confirmBoxSubmit = (event) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to submit this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.submitHandler();
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  submitHandler = e => {
    let default_obj = '';
    if (this.props.user.user_category === "1") {
      default_obj = { school_id: this.state.school_id }
    }
    const form_obj = {
      medium: this.state.medium,
      title: this.state.title,
      description: this.state.description,
      active: (this.state.isActive) ? "1" : "0" // this.state.active
    }
    const obj = { ...form_obj, ...default_obj }
    // console.log(JSON.stringify(obj));
    this.props.createFrontGallery(obj);

    // axios.post(CREATE_GALLERY, obj)
    //   .then(res => {
    //     const getRes = res.data;
    //     Alert.success(getRes.message, {
    //       position: 'bottom-right',
    //       effect: 'jelly',
    //       timeout: 5000, offset: 40
    //     });
    //     this.setState({
    //       medium: '',
    //       title: '',
    //       description: '',
    //       isActive: true,
    //       formIsHalfFilledOut: false
    //     })
    //   }).catch((error) => {
    //     //this.setState({ errorMessages: error });
    //   })
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.frontGallery) {
      this.setState({
        medium: '',
        title: '',
        description: '',
        isActive: true,
        formIsHalfFilledOut: false
      })
    }
  }
  render() {
    const { isActive, selected_school_index, formIsHalfFilledOut, title, description } = this.state;
    const { user, schools, frontGallery } = this.props;
    return (
      <div className="page-child">
        <Helmet>
          <title>Add Gallery</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        <form className="card card-form" onSubmit={event => this.confirmBoxSubmit(event)}>
          <div className="card-header">
            Add Gallery
          </div>
          <div className="card-body">
            {user && schools && frontGallery &&
              <div className="row">
                {(user.user_category === "1") &&
                  <div className="col-sm-2">
                    <div className="form-group mr-2 mt-1">
                      <label className="control-label mr-2">Schools :</label>
                      <select className="form-control form-control-sm"
                        required
                        ref='school'
                        value={selected_school_index}
                        onChange={event => this.changeHandler(event, 'school')}>
                        <option value="">Select ...</option>
                        {schools.map((item, index) => {
                          return (
                            <option key={index} value={index}>{item.sch_name}, {item.sch_medium}</option>
                          )
                        })}
                      </select>
                    </div>
                  </div>
                }
                <div className="col-sm-4">
                  <div className="form-group">
                    <label className="control-label">Gallery Title
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="title" placeholder="Gallery Title"
                        className="form-control form-control-sm"
                        required
                        value={title}
                        onChange={event => this.changeHandler(event, 'title')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label className="control-label">About Gallery
                        <span className="required"> * </span>
                    </label>
                    <div className="form-input">
                      <input type="text" name="description" placeholder="About This Galary"
                        className="form-control form-control-sm"
                        required
                        value={description}
                        onChange={event => this.changeHandler(event, 'description')} />
                    </div>
                  </div>
                </div>
                <div className="col-sm-2">
                  <div className="form-group">
                    <label className="control-label">Is Active
                      </label>
                    <div className="form-input">
                      <div className="custom-control custom-checkbox">
                        <input type="checkbox" className="custom-control-input" id="customCheck2"
                          onChange={event => this.changeHandler(event, 'isActive', true)}
                          checked={isActive} />
                        <label className="custom-control-label" htmlFor="customCheck2">
                          {isActive ? 'Yes' : 'No'}
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
          <div className="card-footer text-right">
            <button type="submit"
              className="btn btn-secondary mr-2">Submit</button>
            <button onClick={event => this.props.toggeleCreate(event)} className="btn btn-warning">
              Cancel
            </button>
          </div>
        </form>
      </div>
    )
  }
}

function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: frontGallery } = state.frontGallery;
  const { item: schools } = state.schools;
  return { user, schools, frontGallery };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  createFrontGallery: frontGalleryActions.createFrontGallery,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AddGallery));
