import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { conveyanceAction, schoolsAction } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import AddTranspoartRoot from './add_transpoart_root';
import EditTranspoartRoot from './edit_transpoart_root';

import CommonFilters from '../utility/Filter/filter-schools';

// const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
// const READ_URL = `http://schools.rajpsp.com/api/conveyance/read.php`;  
// const DELETE_URL = `http://schools.rajpsp.com/api/conveyance/delete.php`;

class AllTranspoartRoot extends Component {
  state = {
    conveyance: [],
    createItem: false,
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.conveyance)) {
      this.props.getConveyance();
    }
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_conveyance = this.props.conveyance;
      if (_all_conveyance && _filter) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _conveyance = this.props.conveyance;
    if (!isEmpty(_conveyance)) {
      const _sch_conveyance = _conveyance.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_conveyance: _sch_conveyance,
      })
    }
  }


  // filterByClsHandler = () => {
  //   const _fltr_school = this.props.filteredSchoolData;
  //   const _fltr_class = this.props.filteredClassesData;
  //   const _all_student = this.props.students;
  //   if (_all_student) {
  //     const _school_student = _all_student.filter((item) => {
  //       if (!isEmpty(_fltr_class.slct_cls_name)) {
  //         if (item.school_id === _fltr_school.slct_school_id &&
  //           item.stu_class === _fltr_class.slct_cls_name) {
  //           return item
  //         }
  //       } else {
  //         if (item.school_id === _fltr_school.slct_school_id) {
  //           return item
  //         }
  //       }
  //     })
  //     this.setState({
  //       display_student: _school_student
  //     })
  //   }
  // }

  // checkAuthentication(obj) {
  //   loadProgressBar();
  //   axios.post(VALIDATE_URL, obj)
  //     .then(res => {
  //       const getRes = res.data;
  //       // sessionStorage.setItem("user", getRes.data);
  //       console.log(getRes);
  //       if (getRes.data) {
  //         this.setState({
  //           user: getRes.data,
  //           group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
  //           school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
  //           user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
  //           session_year_id: (getRes.data.session_year_id) ? getRes.data.session_year_id : "",
  //         }, () => {
  //           this.getConvencesHandler();
  //         })
  //       }
  //     }).catch((error) => {
  //       this.props.history.push('/login.jsp');
  //     })
  // }

  // getConvencesHandler() {
  //   loadProgressBar();
  //   axios.get(READ_URL)
  //     .then(res => {
  //       const conveyance = res.data;
  //       this.setState({
  //         conveyance: conveyance,
  //         errorMessages: res.data.message
  //       });
  //       //console.log(this.state.conveyance);
  //     }).catch((error) => {
  //       // error
  //     })
  // };
  confirmBoxDelete = (event, id) => {
    event.preventDefault();
    confirmAlert({
      title: 'stay one moment!',
      message: 'Are you sure do you want to delete this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            this.props.deleteConveyance({ id: id });
          }
        },
        {
          label: 'No',
        }
      ]
    });
  };

  // deleteHandlar = (event, id) => {
  //   event.preventDefault();
  //   const _id = id;

  //   axios.post(DELETE_URL + '?id=' + _id)
  //     .then(res => {
  //       const getRes = res.data;
  //       //console.log(getRes)
  //       Alert.success(getRes.message, {
  //         position: 'bottom-right',
  //         effect: 'jelly',
  //         timeout: 5000, offset: 40
  //       });
  //       const _conveyance = this.state.conveyance.filter((item, index) => {
  //         return item.id !== _id
  //       })
  //       this.setState({
  //         display_conveyance: _conveyance
  //       })
  //     }).catch((error) => {
  //       //this.setState({ errorMessages: error });
  //     })
  // }

  componentWillReceiveProps(nextProps) {
    if (nextProps.conveyance) {
      this.setState({
        stoppage_name: '',
        stoppage_amo: ''
      });
      setTimeout(() => {
        this.filterBySchoolHandler()
      }, 100);
    }
  }
  updateHandlar = (obj) => {
    console.log(JSON.stringify(obj));
    this.props.updateConveyance(obj);
  }
  toggeleCreate = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      createItem: !this.state.createItem
    })
  }
  openEdit = (event, id) => {
    event.preventDefault();
    const _selected_item = this.props.conveyance.filter((item) => {
      if (item.id === id) {
        return item
      }
    })

    this.setState({
      // editItem: !this.state.editItem,
      editItem: true,
      createItem: false,
      selected_item: _selected_item[0]
    })
  }
  closeEdit = (event) => {
    event.preventDefault();
    this.setState({
      editItem: false,
      selected_item: ''
    })
  }
  render() {
    const { formIsHalfFilledOut, display_conveyance, createItem, editItem, selected_item } = this.state;
    const { user, schools, conveyance } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>Transport Root</title>
        </Helmet>
        <Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />
        {user && schools && conveyance &&
          <>
            <div className="page-bar d-flex">
              <div className="page-title">All Transpoart Root</div>
              <div className="form-inline ml-auto filter-panel">
                <span className="filter-closer">
                  <button type="button" className="btn btn-danger filter-toggler-c">
                    <i className="fa fa-times"></i>
                  </button>
                </span>
                <div className="filter-con">
                  <CommonFilters
                    showSchoolFilter={true}
                    showMediumFilter={false}
                    // showClassFilter={true}
                    filterBySchoolHandler={this.filterBySchoolHandler}
                  // filterByClsHandler={this.filterByClsHandler}
                  />
                  {/* <div className="form-group mt-1">
                <NavLink to="/add_transpoart_root.jsp" className="btn btn-primary btn-sm">
                  Add New <i className="fa fa-plus" />
                </NavLink>
              </div> */}
                </div>
              </div>
            </div>
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                {createItem ? <AddTranspoartRoot
                  toggeleCreate={this.toggeleCreate} />
                  : null}
                {editItem ?
                  <>
                    <EditTranspoartRoot
                      selected_item={selected_item}
                      schools={schools}
                      user={user}
                      updateHandlar={this.updateHandlar}
                      openEdit={this.openEdit}
                      closeEdit={this.closeEdit}
                    />
                    <div className="backdrop edit-mode"></div>
                  </>
                  : null}

                <div className="table-scrollable">
                  <table className="table table-striped table-bordered table-hover table-sm">
                    <thead>
                      <tr>
                        <th />
                        <th> School </th>
                        <th> Root Aria </th>
                        <th> Amount</th>
                        <th> Action </th>
                      </tr>
                    </thead>
                    {display_conveyance &&
                      <tbody>
                        {display_conveyance.map((item, index) => {
                          return (
                            <tr key={index}>
                              <td>{index + 1 + '.'}</td>
                              <td>{item.school_name}, {item.school_medium}</td>
                              <td>{item.stoppage_name}</td>
                              <td>{item.stoppage_amo}/-</td>
                              <td className="d-flex">
                                {/* <NavLink to={`edit_transpoart_root.jsp/${item.id}`} className="btn btn-primary btn-sm mr-1">
                              Edit
                          </NavLink> */}
                                <button className="btn btn-primary btn-sm mr-1"
                                  value={item.id}
                                  type="button"
                                  onClick={event => this.openEdit(event, item.id)}>Edit</button>
                                <button className="btn btn-danger btn-sm"
                                  onClick={event => this.confirmBoxDelete(event, item.id)}>
                                  Del
                          </button>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    }
                  </table>
                </div>
              </div>
              <div className="card-footer">
                {createItem ?
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-danger btn-sm ">
                    Cancel
            </button>
                  :
                  <button onClick={event => this.toggeleCreate(event)}
                    className="btn btn-primary btn-sm">
                    Add New
            </button>
                }
              </div>
            </div>
          </>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const { item: conveyance } = state.conveyance;
  const { item: schools } = state.schools;
  const filteredSchoolData = state.filteredSchoolData;
  return {
    user, conveyance, schools, filteredSchoolData
  };
}

const actionCreators = {
  getConveyance: conveyanceAction.getConveyance,
  deleteConveyance: conveyanceAction.delete,
  updateConveyance: conveyanceAction.update,
  getSchools: schoolsAction.getSchools,
}

export default connect(mapStateToProps, actionCreators)(withRouter(AllTranspoartRoot));