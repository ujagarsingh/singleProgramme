import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Picky } from 'react-picky';
import axios from 'axios';
import DatePicker from 'react-date-picker';
import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';


const VALIDATE_URL = `http://schools.rajpsp.com/api/login/validate_token.php`;
const READ_SDUL_NOTE = `http://schools.rajpsp.com/api/exam_sdul_notes/read.php`;
const READ_SCHOOLS = `http://schools.rajpsp.com/api/school/read.php`;
const READ_SUBJECTS = `http://schools.rajpsp.com/api/subject/read_classwise_subjectsof_school.php`;
const READ_EXAM_CATE = `http://schools.rajpsp.com/api/exam_category/read.php`;
const CREATE_SEDUL = `http://schools.rajpsp.com/api/exam_sdul/create.php`;

class TestPaper extends Component {
	state = {
		selected_school_index: "",
		showResult: false
	}
	isEmpty(val) {
		return (val === undefined || val == null || val.length <= 0) ? true : false;
	}
	componentDidMount() {
		const token = sessionStorage.getItem('jwt');
		const obj = { "jwt": token };
		this.checkAuthentication(obj);
	}
	checkAuthentication(obj) {
		loadProgressBar();
		axios.post(VALIDATE_URL, obj)
			.then(res => {
				const getRes = res.data;
				// sessionStorage.setItem("user", getRes.data);
				console.log(getRes);
				if (getRes.data) {
					this.setState({
						user: getRes.data,
						group_id: (getRes.data.group_id) ? getRes.data.group_id : "",
						school_id: (getRes.data.school_id) ? getRes.data.school_id : "",
						user_category: (getRes.data.user_category) ? getRes.data.user_category : "",
						session_year: (getRes.data.session_year) ? getRes.data.session_year : "",
					}, () => {
						// this.getSchoolHandler();
						// this.getExamsCategories();
						// this.getSheduleNotes();
					})
				}
			}).catch((error) => {
				this.props.history.push('/login.jsp');
			})
	}

	getSchoolHandler() {
		loadProgressBar();
		const obj = {
			group_id: this.state.group_id
		}
		axios.post(READ_SCHOOLS, obj)
			.then(res => {
				const getRes = res.data;
				this.setState({
					schools_arr: getRes,
					errorMessages: getRes.message
				});
				// console.log(this.state);
			}).catch((error) => {
				// error
			})
	}

	showInstruction(event) {
		event.preventDefault();

	}
	nextStep(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: true,
			step_third: false
		};
		this.props.nextStep(obj);
	}
	prevStep(event) {
		event.preventDefault();
		const obj = {
			step_first: true,
			step_second: false,
			step_third: false
		};
		this.props.prevStep(obj);
	}
	startTest(event) {
		event.preventDefault();
		const obj = {
			step_first: false,
			step_second: false,
			step_third: true
		};
		this.props.startTest(obj);
	}
	submitTest(event) {
		event.preventDefault();
		this.setState({
			showResult: !this.state.showResult
		})
	}

	render() {
		const { selected_school_index, schools_arr, user, medium_arr, medium, showResult,
			step_first, step_second, step_third, formIsHalfFilledOut } = this.state;
		console.log(this.state);
		return (

			<div>
				<div className="paper-headr-sec d-flex mb-3 justify-content-between">
					<div className="institute-title">JyotiSSS</div>
					<div className="exam-tmer d-flex">
						<div className="timer d-flex">
							<label className="mr-2">Time Left :</label>
							<div className="showWatch">01 : 25 : 02</div>
						</div>
						<div className="timer-btn ml-2">
							<button className="btn btn-outline-primary btn-sm">Pause</button>
						</div>
					</div>
					<div className="action-full">
						<button className="btn btn-outline-primary btn-sm">Full Screen</button>
					</div>
				</div>
				<div className="card-paper d-flex">
					{!showResult ?
						<>
							<div className="card left-test-panel border-primary">
								<div className="card-header"><strong className="mr-2">Test :</strong>Test Title Here...</div>
								<div className="card-body  p-0">
									<div className="d-flex question-info p-2 mb-1">
										<h5 className="card-title ml-2 m-0">Question 1</h5>
										<div className="ml-auto d-flex">
											<div className="question-time d-flex p-2">
												<label className="label-header">
													Time :</label>
												<div className="show-time">
													25:10</div>
											</div>
											<div className="obtain-marks d-flex  p-2">
												<label className="label-header">
													Marks:</label>
												<div className="get-marks text-success"> +20</div>
												<div className="loss-marks text-danger"> -10</div>
											</div>
										</div>
									</div>
									<div className="p-3">
										<div className="question-text">What Is the full name of CORONA-19?</div>
										<div className="form-group answer-options">
											<div className="custom-control custom-radio">
												<input type="radio" id="ansRadio1" name="ansRadio" className="custom-control-input" />
												<label className="custom-control-label" htmlFor="ansRadio1">Answer Option One</label>
											</div>
											<div className="custom-control custom-radio">
												<input type="radio" id="ansRadio2" name="ansRadio" className="custom-control-input" />
												<label className="custom-control-label" htmlFor="ansRadio2">Answer Option Two</label>
											</div>
											<div className="custom-control custom-radio">
												<input type="radio" id="ansRadio3" name="ansRadio" className="custom-control-input" />
												<label className="custom-control-label" htmlFor="ansRadio3">Answer Option Three</label>
											</div>
											<div className="custom-control custom-radio">
												<input type="radio" id="ansRadio4" name="ansRadio" className="custom-control-input" />
												<label className="custom-control-label" htmlFor="ansRadio4">Answer Option Four</label>
											</div>
											<div className="custom-control custom-radio">
												<input type="radio" id="ansRadio4" name="ansRadio" className="custom-control-input" />
												<label className="custom-control-label" htmlFor="ansRadio4">Answer Option Five</label>
											</div>
										</div>
									</div>
								</div>
								<div className="card-footer">
									<div className="d-flex">
										<button className="btn btn-primary btn-sm">Review Later &amp; Next</button>
										<button className="btn btn-outline-danger btn-sm ml-2">Reset</button>
										<button className="btn btn-success btn-sm ml-auto">Save &amp; Next</button>
									</div>
								</div>
							</div>
							<div className="paper-info right-test-panel">
								<div className="inst-panel bg-primary">
									<div className="student-data d-flex justify-content-center">
										<img classname="rounded-circle" src="https://i.imgur.com/stD0Q19.jpg" />
										<div className="user_name">Ujagar Singh Meena</div>
									</div>
								</div>
								<div className="answered-panel">
									<div className="title-test">Test Title Here...</div>
									<div className="list-queation">
										<button type="button" className="btn btn-answered">1</button>
										<button type="button" className="btn btn-active">2</button>
										<button type="button" className="btn btn-review-later">3</button>
										<button type="button" className="btn btn-ans-rev-leter">4</button>
										<button type="button" className="btn btn-not-answered ">5</button>
										<button type="button" className="btn btn-not-visited">6</button>
										<button type="button" className="btn btn-not-visited">7</button>
										<button type="button" className="btn btn-not-visited">8</button>
										<button type="button" className="btn btn-not-visited">9</button>
										<button type="button" className="btn btn-not-visited">10</button>
										<button type="button" className="btn btn-not-visited">11</button>
										<button type="button" className="btn btn-not-visited">12</button>
										<button type="button" className="btn btn-not-visited">13</button>
										<button type="button" className="btn btn-not-visited">14</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
										<button type="button" className="btn btn-not-visited">15</button>
									</div>
								</div>
								<div className="inst-info-panel">
									<ul className="epaper-instructions">
										<li className="q-answered"><span className="box bg-success">10</span>Answered</li>
										<li className="q-not-answered"><span className="box bg-red">5</span>Not Answered</li>
										<li className="q-review-without-ans"><span className="box bg-yellow">1</span>Review Later</li>
										<li className="q-not-visited"><span className="box bg-white">1</span>Not Visited</li>
										<li className="q-review-with-ans w-100"><span className="box bg-yellow">5</span>Answered &amp; Review Later
          </li>
									</ul>
									<button
										type="button"
										className="btn btn-default btn-block"
										onClick={event => this.prevStep(event)}
									>Review instruction</button>
								</div>
								<div className="button-group">
									<button
										type="button"
										className="btn btn-primary btn-lg btn-block"
										onClick={event => this.submitTest(event)}
									>Submit Test</button>
								</div>
							</div>
						</>
						:
						<div className="modal result-modal d-block">
							<div className="modal-dialog">
								<div className="modal-content">
									<div className="modal-header bg-light">
										<div className="d-flex flex-column">
											<h4 className="modal-title text-primary">Test Summary</h4>
											<h6>Your answer have been saved successfully please take few moments to review this summary.</h6>
										</div>
										<button type="button" className="btn btn-danger" 
										onClick={event => this.submitTest(event)}>×</button>
									</div>
									<div className="modal-body">
										<ul className="list-group">
											<li className="list-group-item d-flex justify-content-between align-items-center">
												No.of questions
            <span className="badge badge-primary badge-pill">14</span>
											</li>
											<li className="list-group-item d-flex justify-content-between align-items-center">
												Answered
            <span className="badge badge-primary badge-pill">2</span>
											</li>
											<li className="list-group-item d-flex justify-content-between align-items-center">
												Not Answered
            <span className="badge badge-primary badge-pill">3</span>
											</li>
											<li className="list-group-item d-flex justify-content-between align-items-center">
												Marked for review
            <span className="badge badge-primary badge-pill">0</span>
											</li>
											<li className="list-group-item d-flex justify-content-between align-items-center">
												Marked &amp; Answered
            <span className="badge badge-primary badge-pill">0</span>
											</li>
											<li className="list-group-item d-flex justify-content-between align-items-center">
												Not visited
            <span className="badge badge-primary badge-pill">11</span>
											</li>
										</ul>
									</div>
									<div className="modal-footer bg-light">
										<NavLink to="/test_result.jsp" 
										className="btn btn-success btn-sm">Continue</NavLink>
									</div>
								</div>
							</div>
						</div>

					}
				</div>
			</div>
		)
	}
}
export default withRouter(TestPaper);