import React, { Component } from 'react';
import { Prompt, withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
//import { loadProgressBar } from 'axios-progress-bar';
//import Alert from 'react-s-alert';
//import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
//import { HOST_URL } from '../includes/api-config';

class EditArticle extends Component {
  render() {
    return (
      <div className="page-content">
        <Helmet>
          <title>Edit Article</title>
        </Helmet><Prompt when={formIsHalfFilledOut} message="Are you sure? Change Page!! If 'Yes' Your 'field DATA' will be lost..." />

        <div className="page-bar d-flex">
              <div className="page-title">Edit Article</div>
            </div>
        <div className="row">
          <div className="col-md-12 col-sm-12">
            <div className="card card-box sfpage-cover">
              <div className="card-body sfpage-body">
                <form action="#" id="form_sample_1" className="form-horizontal">
                  <div className="form-body">
                    <div className="form-group row">
                      <label className="control-label col-md-3">Article Title
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-5">
                        <input type="text" name="firstname" placeholder className="form-control form-control-sm" />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label className="control-label col-md-3">Article Content
                      <span className="required"> * </span>
                      </label>
                      <div className="col-md-5">
                        <textarea name="address" placeholder="address" className="form-control-textarea form-control" rows={5} defaultValue={""} />
                      </div>
                    </div>
                    <div className="form-actions  text-right">
                      <div className="row">
                        <div className="offset-md-3 col-md-9">
                          <button type="submit" className="btn btn-primary mr-2">Submit</button>
                         <NavLink to="#" className="btn btn-danger">Cancel</NavLink>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(EditArticle);