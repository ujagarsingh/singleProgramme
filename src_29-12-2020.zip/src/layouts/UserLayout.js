import React, { Component } from "react";
import { withRouter } from 'react-router';
class UserLayout extends Component {
  render() {
    //const { children, ...rest } = this.props;
    const { children } = this.props;
    return (
      <div className="wrapper-100">
        {children}
      </div >
    )
  }
}

export default withRouter(UserLayout);
