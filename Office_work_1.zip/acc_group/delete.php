<?php
/*
http://localhost/reactjs-php/api/acc_group/delete.php
*/

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
 
// include database and object file
include_once '../database.php';
include_once '../objects/acc_group.php';

// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccGroup($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
 		// echo"<pre>";print_r($decoded);echo"</pre>";die();
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      
      $Item->id = isset($data->id) ? $data->id : "";

      if ($Item->delete()) {
		  // echo"<pre>";print_r($data);echo"</pre>";die();
          http_response_code(200); 
          echo json_encode(array(
              "message" => "Access granted.",
              "item_id" => $Item->id
          ));

      }
		/* get data end */
		
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}

?>