<?php
// http://localhost/schooloffice/api/acc_entry_book/read.php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// include database and object files
include_once '../database.php';
include_once '../objects/acc_entry_book.php';
 
// required to decode jwt
include_once '../core.php';
include_once '../libs/php-jwt-master/src/BeforeValidException.php';
include_once '../libs/php-jwt-master/src/ExpiredException.php'; 
include_once '../libs/php-jwt-master/src/SignatureInvalidException.php';
include_once '../libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;

$database = new Database();
$db = $database->getConnection();
 
$Item = new AccEntryBook($db);

// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));

// set ID property of Item to be edited
$jwt=isset($data->jwt) ? $data->jwt : "";


if($jwt){
	try {
		$decoded = JWT::decode($jwt, $key, array('HS256'));
 
		$Item->group_id = isset($decoded->data->group_id) ? $decoded->data->group_id : "";
		$Item->school_id = isset($decoded->data->school_id) ? $decoded->data->school_id : "";
		$Item->user_category = isset($decoded->data->user_category) ? $decoded->data->user_category : "";
		$Item->session_year_id = isset($decoded->data->session_year_id) ? $decoded->data->session_year_id : "";
		$Item->user_id = isset($decoded->data->id) ? $decoded->data->id : "";
		
		/* get Data start */
      // query products
      $stmt = $Item->read();
      $num = $stmt->rowCount();
	  $entry_book_arr = array();

      // check if more than 0 record found
      if ($num > 0) {
         while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
            extract($row);
         
			$entry_book_info = array();
			
			$entry_book_info['id'] = $Item->id;
			$entry_book_info['details_id'] = $row['details_id'];
			$entry_book_info['ledger_id'] = $row['ledger_id'];
			$entry_book_info['ledger_name'] = $row['ledger_name'];
			$entry_book_info['school_id'] = $row['school_id'];
			$entry_book_info['school_name'] = $row['school_name'];
			$entry_book_info['person_id'] = $row['person_id'];
			$entry_book_info['ledger_type'] = $row['ledger_type'];
			$entry_book_info['amount'] = $row['amount'];
			$entry_book_info['tr_type'] = $row['tr_type'];
			$entry_book_info['session_year_id'] = $row['session_year_id'];
			$entry_book_info['server_date_time'] = $row['server_date_time'];
 
            $entry_book_arr[] = $entry_book_info;
         
         }
         // echo json_encode($entry_book_arr); 
      }
		/* get data end */
		
		http_response_code(200); 
		echo json_encode(array(
			"message" => "Access granted.",
			"res_arr" => $entry_book_arr
		));
	}

	catch (Exception $e){
		http_response_code(401);
		echo json_encode(array(
			"message" => "Access denied.",
			"error" => $e->getMessage()
		));
	}
}
else{
	http_response_code(401);
	echo json_encode(array("message" => "Access denied.!!!!"));
}

?>