-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 04:59 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_entry_details`
--

CREATE TABLE `acc_entry_details` (
  `id` int(11) NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `amount` int(15) DEFAULT NULL COMMENT 'cr/dr amount',
  `description` varchar(150) DEFAULT NULL COMMENT 'Naretion',
  `session_year_id` varchar(3) DEFAULT NULL COMMENT 'current session id	',
  `entry_month` int(2) DEFAULT NULL COMMENT 'month of entry',
  `transaction_date` date DEFAULT NULL,
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_entry_details`
--

INSERT INTO `acc_entry_details` (`id`, `school_id`, `amount`, `description`, `session_year_id`, `entry_month`, `transaction_date`, `server_date_time`) VALUES
(4, 4, NULL, 'test', '1', NULL, '2019-08-14', '2019-08-14 03:14:34'),
(6, 4, NULL, 'News Paper payment of jan to dec', '1', NULL, '2019-08-14', '2019-08-14 03:16:40'),
(7, 4, NULL, 'hello', '1', NULL, '2019-08-21', '2019-08-14 03:19:51'),
(8, 4, NULL, 'test ', '1', NULL, '2019-08-15', '2019-08-14 03:29:24'),
(9, 4, 1000, 'test', '1', NULL, '2019-08-14', '2019-08-14 03:31:11'),
(10, 4, NULL, 'this', '1', NULL, '2019-08-14', '2019-08-14 03:33:04'),
(11, 4, NULL, 'thest', '1', NULL, '2019-08-14', '2019-08-14 03:35:05'),
(18, 4, 0, 'today test', '', NULL, '2019-10-03', '2019-10-03 17:55:09'),
(19, 4, NULL, '', '1', NULL, '2019-10-22', '2019-10-22 16:52:32'),
(38, 4, NULL, 'hello test', '1', NULL, '2020-09-12', '2020-09-12 13:35:49'),
(39, 4, 345345, 'today test', '1', NULL, '2020-09-12', '2020-09-12 13:50:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_entry_details`
--
ALTER TABLE `acc_entry_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sch_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_entry_details`
--
ALTER TABLE `acc_entry_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_entry_details`
--
ALTER TABLE `acc_entry_details`
  ADD CONSTRAINT `acc_entry_details_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school_info` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
