import { accEntryBookConstants } from '../_constants';

export function accEntryBook(state = {}, action) {
  switch (action.type) {
    case accEntryBookConstants.ENTRY_BOOK_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accEntryBookConstants.ENTRY_BOOK_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accEntryBookConstants.ENTRY_BOOK_FAILURE:
      return {
        error: action.error
      };


    case accEntryBookConstants.CREATE_ENTRY_BOOK_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryBookConstants.CREATE_ENTRY_BOOK_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accEntryBookConstants.CREATE_ENTRY_BOOK_FAILURE:
      return {
        error: action.error
      };



    case accEntryBookConstants.UPDATE_ENTRY_BOOK_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryBookConstants.UPDATE_ENTRY_BOOK_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accEntryBookConstants.UPDATE_ENTRY_BOOK_FAILURE:
      return {
        error: action.error
      };


    case accEntryBookConstants.DELETE_ENTRY_BOOK_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryBookConstants.DELETE_ENTRY_BOOK_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accEntryBookConstants.DELETE_ENTRY_BOOK_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}