import { accEntryDetailsConstants } from '../_constants';

export function accEntryDetails(state = {}, action) {
  switch (action.type) {
    case accEntryDetailsConstants.ENTRY_DETAILS_REQUEST:
      return {
        loading: true,
        //items : action.users
      };
    case accEntryDetailsConstants.ENTRY_DETAILS_SUCCESS:
      return {
        item: action.response,
        loading: false,
      };
    case accEntryDetailsConstants.ENTRY_DETAILS_FAILURE:
      return {
        error: action.error
      };


    case accEntryDetailsConstants.CREATE_ENTRY_DETAILS_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryDetailsConstants.CREATE_ENTRY_DETAILS_SUCCESS:
      const new_arr = [action.response, ...state.item];
      return {
        item: new_arr,
        loading: false,
      };
    case accEntryDetailsConstants.CREATE_ENTRY_DETAILS_FAILURE:
      return {
        error: action.error
      };



    case accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_SUCCESS:
      const updated_arr = state.item.map((item) => {
        if (item.id === action.response.id) {
          item = action.response;
        }
        return item;
      })
      return {
        item: updated_arr,
        loading: false,
      };
    case accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_FAILURE:
      return {
        error: action.error
      };


    case accEntryDetailsConstants.DELETE_ENTRY_DETAILS_REQUEST:
      return {
        ...state,
        loading: true,
        //items : action.users
      };
    case accEntryDetailsConstants.DELETE_ENTRY_DETAILS_SUCCESS:
      const rest_arr = state.item.filter((item) => {
        if (action.response !== item.id) {
          return item
        }
      });
      return {
        item: rest_arr,
        loading: false,
      };
    case accEntryDetailsConstants.DELETE_ENTRY_DETAILS_FAILURE:
      return {
        error: action.error
      };



    default:
      return state
  }
}