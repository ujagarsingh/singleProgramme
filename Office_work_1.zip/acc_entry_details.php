<?php
class AccEntryDetails{
 
    // database connection and table name
    private $conn;
    private $table_name = "acc_entry_details";
    private $table_school = "school_info";
	
    // object properties
    public $id;
	public $school_id;
    public $amount;
    public $description;
    public $session_year_id;
	public $transaction_date;
    public $server_date_time;
    public $last_id;
    
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
// read Classes
function read(){
 
    // select all query
    $query = "SELECT I.*, S.sch_name FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        ";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
 
    return $stmt;
}

// create product
function create(){
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                school_id = :school_id,
                amount = :amount,
                entry_month = :entry_month,
                description = :description,
                transaction_date = :transaction_date,
                session_year_id = :session_year_id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
    
    // sanitize
    $this->school_id = $this->school_id;
    $this->amount = $this->amount;
    $this->entry_month = $this->entry_month;
    $this->description = $this->description;
    $this->transaction_date = $this->transaction_date;
    $this->session_year_id = $this->session_year_id;

    // bind values
    $stmt->bindParam(":school_id", $this->school_id);
    $stmt->bindParam(":amount", $this->amount);
    $stmt->bindParam(":entry_month", $this->entry_month);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":transaction_date", $this->transaction_date);
    $stmt->bindParam(":session_year_id", $this->session_year_id);

    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute query
    if($stmt->execute()){
        $this->last_id = $this->conn->lastInsertId();

        // Create ledger_details
        $this->createEntryBook();

        return true;
    }
 
    return false;
     
}

// create EntryBook records.
function createEntryBook(){
 // $this->last_id;
 // $this->ledger_details;
    
	$query = "INSERT INTO 
		" . $this->table_name . " 
			(details_id, ledger_id, person_id, ledger_type, amount, tr_type) VALUES "; //Prequery
			
	$qPart = array_fill(0, count($entry_book), "(?, ?, ?, ?, ?, ?)");
	$query .=  implode(",",$qPart);
	$query .= "ON DUPLICATE KEY UPDATE
				sub_name = VALUES(sub_name),
				sub_lavel = VALUES(sub_lavel)";
	
	$stmt = $this->conn->prepare($query);

	$i = 1;
	foreach($entry_book as $item) { 
    //bind the values one by one
		$stmt -> bindParam($i++, $this->last_id);
		$stmt -> bindParam($i++, $item->ledger_id);
		$stmt -> bindParam($i++, $item->person_id);
		$stmt -> bindParam($i++, $item->ledger_type);
		$stmt -> bindParam($i++, $item->amount);
		$stmt -> bindParam($i++, $item->tr_type);
    }
    
	if($stmt->execute()){
        // update ledger current balance
        $this->updateLedgerCurrentBalance();
		return true;
	}
 
	return false;
}

// update Ledger's current balance in one query
function updateLedgerCurrentBalance(){
    // $this->ledger_details;
    $update_ledger_details = Array();

    $i = 1;
	foreach($entry_book as $item) { 

        $query = "SELECT * FROM " . $this->table_name . "
            WHERE
                  id = ?
            LIMIT
                  0,1";

        // prepare query statement
        $stmt = $this->conn->prepare( $query );
        // bind id of product to be updated
        $stmt->bindParam(1, $item->ledger_id);
        // execute query
        $stmt->execute();
        $num = $stmt->rowCount();

        if ($num > 0) {
            $res = array();
            while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
                extract($row);
                $res['type'] = $row['crnt_balance_type'];
                $res['amo'] = $row['crnt_balance'];

                // if old_type == new_type like "CR" == "CR"
                if($res['type'] == $item->tr_type){ 
                    // add amount


                } else {
                    
                }
            }
        }

        // $stmt -> bindParam($i++, $this->last_id);
		// $stmt -> bindParam($i++, $item->ledger_id);
		// $stmt -> bindParam($i++, $item->person_id);
		// $stmt -> bindParam($i++, $item->ledger_type);
		// $stmt -> bindParam($i++, $item->amount);
        // $stmt -> bindParam($i++, $item->tr_type);
        
        // update query for ledger
        //--------------------------------------------------

        // Update Group Current Balance 
        $this->updateGroupCurrentBalance();

    }

}

// update Group's current balance in one query
function updateGroupCurrentBalance(){

}
 
// used when filling up the update product form
function readOne(){
 
    // query to read single record
     
    $query = "SELECT I.*, S.sch_name FROM " . $this->table_name . " AS I
        LEFT JOIN " . $this->table_school . " AS S
        ON I.school_id = S.id
        WHERE
                I.id = ?
            LIMIT
                0,1";

	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->id);
    // execute query
    $stmt->execute();
 
    return $stmt;
  
 
}

  
// update the product
function update(){
	
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
				school_id = :school_id,
                amount = :amount,
                description = :description,
                transaction_date = :transaction_date,
                session_year_id = :session_year_id
				
            WHERE
                id = :id";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
	
    // sanitize
    $this->id 				= $this->id;
	$this->school_id = $this->school_id;
    $this->amount = $this->amount;
    $this->description = $this->description;
    $this->transaction_date = $this->transaction_date;
    $this->session_year_id = $this->session_year_id;
    
    // bind values
	$stmt->bindParam(":id", $this->id);
	$stmt->bindParam(":school_id", $this->school_id);
    $stmt->bindParam(":amount", $this->amount);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":transaction_date", $this->transaction_date);
    $stmt->bindParam(":session_year_id", $this->session_year_id);
    
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute the query
    if($stmt->execute()){
        return true;  
    }
 
    return false;
}

// delete the product
function delete(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->id=htmlspecialchars(strip_tags($this->id));
 
    // bind id of record to delete
    $stmt->bindParam(':id', $this->id);
 
    // echo"<pre>";print_r($stmt);echo"</pre>";die();
    // execute query
    if($stmt->execute()){
        return true;
    }
    return false;
}


}



 