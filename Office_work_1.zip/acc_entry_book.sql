-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 04:59 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_entry_book`
--

CREATE TABLE `acc_entry_book` (
  `id` int(11) NOT NULL,
  `details_id` int(11) DEFAULT NULL COMMENT 'acc entry details id',
  `ledger_id` int(5) DEFAULT NULL,
  `person_id` int(5) DEFAULT NULL COMMENT 'student or staff id',
  `ledger_type` varchar(1) DEFAULT NULL COMMENT 'student = S, Employee = E, Other = O, Capital & Owner = C',
  `amount` int(15) DEFAULT NULL COMMENT 'cr/dr amount',
  `tr_type` varchar(5) NOT NULL COMMENT 'Transaction type',
  `server_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_entry_book`
--

INSERT INTO `acc_entry_book` (`id`, `details_id`, `ledger_id`, `person_id`, `ledger_type`, `amount`, `tr_type`, `server_date_time`) VALUES
(4, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:14:34'),
(6, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:16:40'),
(7, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:19:51'),
(8, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:29:24'),
(9, 4, 0, 0, NULL, 1000, '', '2019-08-14 03:31:11'),
(10, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:33:04'),
(11, 4, 0, 0, NULL, NULL, '', '2019-08-14 03:35:05'),
(18, 4, 4, 0, NULL, 0, '', '2019-10-03 17:55:09'),
(19, 4, 0, 0, NULL, NULL, '', '2019-10-22 16:52:32'),
(38, 4, NULL, 0, NULL, NULL, '', '2020-09-12 13:35:49'),
(39, 4, NULL, 0, NULL, 345345, '', '2020-09-12 13:50:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_entry_book`
--
ALTER TABLE `acc_entry_book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sch_id` (`details_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_entry_book`
--
ALTER TABLE `acc_entry_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `acc_entry_book`
--
ALTER TABLE `acc_entry_book`
  ADD CONSTRAINT `acc_entry_book_ibfk_1` FOREIGN KEY (`details_id`) REFERENCES `acc_entry_details` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
