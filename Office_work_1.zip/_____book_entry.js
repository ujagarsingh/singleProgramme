{
    "school_id" : "4",
    "amount" : "5000",
    "description" : "this is the test naretion.",
    "session_year_id" : "1",
    "entry_month" : "4",
    "transaction_date" : "10-04-2020",
    "ledger_details" : [
        {
            "ledger_id" : "5",
            "person_id" : "2015",
            "ledger_type" : "S",
            "amount" : "1250",
            "tr_type" : "CR",
        },
        {
            "ledger_id" : "5",
            "person_id" : "2015",
            "ledger_type" : "S",
            "amount" : "1250",
            "tr_type" : "CR",
        },
        {
            "ledger_id" : "5",
            "person_id" : "2015",
            "ledger_type" : "S",
            "amount" : "1250",
            "tr_type" : "CR",
        },
    ]
}