import { accEntryDetailsConstants } from '../_constants';
import { accEntryDetails } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const accEntryDetailsActions = {
    getAccEntryDetails,
    createAccEntryDetails,
    update,
    delete : _delete
};

function getAccEntryDetails() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryDetails.getAccEntryDetails()
            .then(
                response => {
                    dispatch(success(response.data.inc_exp_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryDetailsConstants.ENTRY_DETAILS_REQUEST } }
    function success(response) { return { type: accEntryDetailsConstants.ENTRY_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: accEntryDetailsConstants.ENTRY_DETAILS_FAILURE, error } }
}
 

function createAccEntryDetails(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryDetails.createAccEntryDetails(obj)
            .then(
                response => {
                    dispatch(success(response.data.new_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            ); 
    };

    function request() { return { type: accEntryDetailsConstants.CREATE_ENTRY_DETAILS_REQUEST } }
    function success(response) { return { type: accEntryDetailsConstants.CREATE_ENTRY_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: accEntryDetailsConstants.CREATE_ENTRY_DETAILS_FAILURE, error } }
}
 
function update(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryDetails.update(obj)
            .then(
                response => {
                    dispatch(success(response.data.updated_item),toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_REQUEST } }
    function success(response) { return { type: accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: accEntryDetailsConstants.UPDATE_ENTRY_DETAILS_FAILURE, error } }
}
 
function _delete(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        accEntryDetails.delete(obj)
            .then(
                response => {
                    dispatch(success(response.data.item_id),
                    toastr.success(response.data.message));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: accEntryDetailsConstants.DELETE_ENTRY_DETAILS_REQUEST } }
    function success(response) { return { type: accEntryDetailsConstants.DELETE_ENTRY_DETAILS_SUCCESS, response } }
    function failure(error) { return { type: accEntryDetailsConstants.DELETE_ENTRY_DETAILS_FAILURE, error } }
}
