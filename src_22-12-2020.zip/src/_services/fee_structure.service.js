// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const feeStructureService = {
    getFeeStructure,
    create,
    update,
    delete : _delete
};

function getFeeStructure() {
    loadProgressBar();
    const url = USER_URL + 'fee_amount/read_classWise_cat_fee.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_amount/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_amount/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function _delete(obj) {
    loadProgressBar(obj);
    const url = USER_URL + 'fee_amount/delete.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
