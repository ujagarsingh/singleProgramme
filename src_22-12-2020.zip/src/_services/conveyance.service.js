// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const conveyanceService = {
    getConveyance,
    create,
    update,
    delete : _delete 
};

function getConveyance() {
    loadProgressBar();
    const url = USER_URL + 'conveyance/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'conveyance/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar(); 
    const url = USER_URL + 'conveyance/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function _delete(obj) {
    loadProgressBar();
    const url = USER_URL + 'conveyance/delete.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}
