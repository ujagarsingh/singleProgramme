// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const classesService = {
    getClasses,
    create,
    update
};

function getClasses() {
    loadProgressBar();
    const url = USER_URL + 'classes/read.php';
    return Axios.post(url, authHeader()).then()
}

function create(obj) {
    loadProgressBar();
    const url = USER_URL + 'classes/create.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

function update(obj) {
    loadProgressBar();
    const url = USER_URL + 'classes/update.php';
    return Axios.post(url, {...authHeader(), ...obj}).then()
}

