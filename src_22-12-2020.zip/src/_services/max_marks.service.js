// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const maxMarksService = {
    getMaxMarks
};

function getMaxMarks() {
    loadProgressBar();
    const url = USER_URL + 'exam/read_max_marks.php';
    return Axios.post(url, authHeader()).then()
}
