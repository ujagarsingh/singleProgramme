// import config from 'config';
import { authHeader } from '../_helpers';
import Axios from 'axios';
import { loadProgressBar } from 'axios-progress-bar';
import USER_URL from '../_helpers/api-url';

export const categoryWithFeeService = {
    getCategoryWithFee
};

function getCategoryWithFee() {
    loadProgressBar();
    const url = USER_URL + 'fee_amount/read_class_fee.php';
    return Axios.post(url, authHeader()).then()
}
