import { categoryWithFeeConstants } from '../_constants';
import { categoryWithFeeService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const categoryWithFeeAction = {
    getCategoryWithFee
};

function getCategoryWithFee() {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        categoryWithFeeService.getCategoryWithFee()
            .then(
                response => {
                    dispatch(success(response.data.fee_amo_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };
    function request() { return { type: categoryWithFeeConstants.CATEGORY_WITH_FEE_REQUEST } }
    function success(response) { return { type: categoryWithFeeConstants.CATEGORY_WITH_FEE_SUCCESS, response } }
    function failure(error) { return { type: categoryWithFeeConstants.CATEGORY_WITH_FEE_FAILURE, error } }
}
 