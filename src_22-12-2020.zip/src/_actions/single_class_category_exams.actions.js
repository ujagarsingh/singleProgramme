import { singleClassCategoryExamsConstants } from '../_constants';
import { singleClassCategoryExamsService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const singleClassCategoryExamsAction = {
    getSingleCCE
};

function getSingleCCE(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        singleClassCategoryExamsService.getSingleCCE(obj)
            .then(
                response => {
                    dispatch(success(response.data.single_cce_info));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: singleClassCategoryExamsConstants.SINGLE_CCE_REQUEST } }
    function success(response) { return { type: singleClassCategoryExamsConstants.SINGLE_CCE_SUCCESS, response } }
    function failure(error) { return { type: singleClassCategoryExamsConstants.SINGLE_CCE_FAILURE, error } }
}
 