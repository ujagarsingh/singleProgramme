import { marksOfaClassConstants } from '../_constants';
import { marksOfaClassService } from '../_services';
import { toastr } from 'react-redux-toastr'; // import { history } from '../_helpers';

export const marksOfaClassAction = {
    getMarksOfaClass
};

function getMarksOfaClass(obj) {
    return dispatch => {
        // dispatch(request({ mobile }));
        dispatch(request());

        marksOfaClassService.getMarksOfaClass(obj)
            .then(
                response => {
                    dispatch(success(response.data.Class_arr));
                },
                error => {
                    dispatch(failure(error.toString()), toastr.error(error.toString()));
                }
            );
    };

    function request() { return { type: marksOfaClassConstants.MARKS_OF_ACLASS_REQUEST } }
    function success(response) { return { type: marksOfaClassConstants.MARKS_OF_ACLASS_SUCCESS, response } }
    function failure(error) { return { type: marksOfaClassConstants.MARKS_OF_ACLASS_FAILURE, error } }
}
 