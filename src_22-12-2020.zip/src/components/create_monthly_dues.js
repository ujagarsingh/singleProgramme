import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import DatePicker from 'react-date-picker';
// import { loadProgressBar } from 'axios-progress-bar';
import Alert from 'react-s-alert';
import { confirmAlert } from 'react-confirm-alert';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import {
	schoolsAction, classesAction, feeWithCategoryAction, accLedgerActions,
	accVoucherEntryActions, conveyanceAction, studentsAction
} from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';

class CreateMonthlyDues extends Component {
	state = {
		fee_months_arr: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
		selected_month: '',
		schools: [],
		fee_header: [],
		stu_ids: [],
		selected_student: [],
		due_date: new Date(),
		display_student: [],
		update_student: [],
	}

	changeHandler = (event, fieldName, isCheckbox) => {
		this.setState({
			[fieldName]: isCheckbox ? event.target.checked : event.target.value
		});
		if (fieldName === 'selected_month') {
			const _select_month = !isEmpty(event.target.value) ? (parseInt(event.target.value) + 1) : '';
			this.setState({
				selected_month: _select_month,
			}, () => {
				const _students = this.state.display_student;
				this.getFeeStructureofSelectedMonth(_students);
			})
		}
	};
	getFeeStructureofSelectedMonth(display_student) {
		debugger;
		const _students = display_student;
		const _slct_month = this.state.selected_month;
		const _month = this.state.fee_months_arr[_slct_month - 1];
		const _feeCategory = this.props.feeWithCategory;

		let _header = [];
		let _ids = [];
		const c_student = _students.map((s_item, index) => {
			const _c_fee = _feeCategory.filter((f_item) => {
				const collect_tiem = f_item.collect_time;
				if (collect_tiem !== null && (s_item.class_id === f_item.class_id) && (collect_tiem.includes(_month))) {
					if (!_header.includes(f_item.cat_name)) {
						_header = [..._header, f_item.cat_name];
					}
					return f_item;
				} else {
					return false
				}
			})

			if (!_ids.includes(s_item.se_id)) {
				_ids = [..._ids, s_item.se_id];
			}
			let crnt_dues = 0;
			let fee_strc = _c_fee.filter((item) => {
				if (!isEmpty(item.fee_amount)) {
					crnt_dues += Number(item.fee_amount);
					return item = {
						id: item.id,
						cat_name: item.cat_name,
						effected_ledger: item.ledger_id,
						under_group: item.under_group,
						group_type: item.group_type,
						fee_amount: item.fee_amount
					}
				}
				return false;
			})

			s_item = { ...s_item, "fee_class": fee_strc, "crnt_dues": crnt_dues };
			return s_item;
		})

		this.setState({
			display_student: c_student,
			fee_header: _header,
			stu_ids: _ids,
		})

	}
	startDateHandler = (getDate) => {
		this.setState({ due_date: getDate });
		// this.to.openCalendar();
	};

	checkHandler = (event, fieldName, value) => {
		// debugger;
		let _display_student = null;
		let _current_select = JSON.parse(value).admission_number;
		if (fieldName === 'select_this') {
			_display_student = this.state.display_student.map((checked_student) => {
				if (_current_select === checked_student.admission_number) {
					checked_student['is_checked'] = !checked_student.checked;
					return checked_student;
				}
				return checked_student;
			})
			// this.setState({
			// 	update_student: _display_student
			// }, () => { this.generateFeeDueObjectHandler() });

		} else if (fieldName === 'select_all') {
			_display_student = this.state.display_student.map((checked_student) => {
				checked_student['is_checked'] = (event.target.checked) ? true : false;
				return checked_student;
			})
			// this.setState({
			// 	update_student: _display_student
			// }, () => { this.generateFeeDueObjectHandler() });

		}
		let _update_student = _display_student.filter((checked_student) => {
			return checked_student['is_checked'] === true
		})
		this.setState({
			display_student: _display_student,
			update_student: _update_student
		}, () => { this.generateFeeDueObjectHandler() });
	};

	generateFeeDueObjectHandler() {
		// debugger;
		const _updated_student = this.state.update_student;
		// const _acc_ledger = this.props.accLedger;

		const std_obj = _updated_student.map((item) => {
			item = {
				// group_id: item.group_id,
				// medium: item.medium,
				// admission_number: item.admission_number,
				// gender: item.gender,
				// roll_number: item.roll_number,
				// software_class: item.software_class,
				// student_image: item.student_image,
				// convence_area: item.convence_area,
				// message_mob: item.message_mob,
				// convence_months: item.convence_months,
				// convence_discount: item.convence_discount,
				// dob: item.dob,
				// caste: item.caste,
				// dis_continue: item.dis_continue,
				// is_checked: item.is_checked,
				// s_id: item.s_id,
				// mother_name: item.mother_name,
				se_id: item.se_id,
				school_id: item.school_id,
				class_id: item.class_id,
				session_year_id: item.session_year_id,
				student_name: item.student_name,
				father_name: item.father_name,
				stu_class: item.stu_class,
				free_seat: item.free_seat,
				rte_stationary: item.rte_stationary,
				is_rte_student: item.is_rte_student,
				fee_class: item.fee_class,
				crnt_dues: item.crnt_dues,
			}
			return item;
		})

		const _due_obj = {
			action: 'journal_due_entry',
			due_entry_obj: std_obj,
			transaction_date: this.state.due_date,
			entry_month: this.state.selected_month,
		}
		// console.log(_due_obj);

		// debugger
		this.setState({
			dueDetailsEntryObj: _due_obj
		});

	}

	componentDidMount() {
		if (isEmptyObj(this.props.schools)) {
			this.props.getSchools();
		}
		if (isEmptyObj(this.props.classes)) {
			this.props.getClasses();
		}
		if (isEmptyObj(this.props.conveyance)) {
			this.props.getConveyance();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		if (isEmptyObj(this.props.feeWithCategory)) {
			this.props.getFeeWithCategory();
		}
		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}
		if (isEmptyObj(this.props.accVoucherEntry)) {
			this.props.getAccVoucherEntry();
		}
		this.checkFlag();
	}


	checkFlag() {
		setTimeout(() => {
			const _filter = this.props.filteredSchoolData;
			const _all_student = this.props.students;
			const _feeWithCategory = this.props.feeWithCategory;
			if (_all_student && _filter && _feeWithCategory) {
				this.filterBySchoolHandler();
			} else {
				this.checkFlag()
			}
		}, 100);
	}

	filterBySchoolHandler = () => {
		const _filter = this.props.filteredSchoolData;
		const _all_student = this.props.students;
		if (!isEmpty(_all_student)) {
			const _school_student = _all_student.filter((item) => {
				if (_filter.slct_school_id) {
					if (item.school_id === _filter.slct_school_id) {
						return item
					}
				} else {
					return item
				}
				return false
			})
			this.setState({
				display_student: _school_student,
			}, () => this.filterByClsHandler())
		}
	}

	filterByClsHandler = () => {
		const _fltr_school = this.props.filteredSchoolData;
		const _fltr_class = this.props.filteredClassesData;
		const _all_student = this.props.students;
		if (!isEmpty(_all_student)) {
			const _school_student = _all_student.filter((item) => {
				if (!isEmpty(_fltr_class.slct_cls_name)) {
					if (item.school_id === _fltr_school.slct_school_id &&
						item.stu_class === _fltr_class.slct_cls_name) {
						return item
					}
				} else {
					if (item.school_id === _fltr_school.slct_school_id) {
						return item
					}
				}
				return false
			})

			this.getFeeStructureofSelectedMonth(_school_student);
		}
	}


	confirmBoxSubmit = (event) => {
		event.preventDefault();
		confirmAlert({
			title: 'stay one moment!',
			message: 'Are you sure do you want to Update these.',
			buttons: [
				{
					label: 'Yes',
					onClick: () => {
						this.updateHandler();
					}
				},
				{
					label: 'No',
				}
			]
		});
	};
	updateHandler = () => {
		const _obj = this.state.dueDetailsEntryObj;

		if (!isEmptyObj(_obj)) {
			// console.log(JSON.stringify(_obj));
			this.props.createAccVoucherEntry(_obj);
		} else {
			Alert.error('Please Select Students, Date and Month of fee !!', {
				position: 'bottom-right',
				effect: 'jelly',
				timeout: 5000, offset: 40
			});
		}
	}


	currentMonthFeeHandler(item) {
		const _fee_header = this.state.fee_header;
		if (item.fee_class) {
			const _newDom = _fee_header.map((f_item, f_inx) => {
				return (<td className="text-right" key={f_inx}>
					{
						//	(item.free_seat == '0') ?
						this.getValueHandler(f_item, item.fee_class)
						//		: null
					}
				</td>);
			})
			return _newDom;
		}
	}
	getValueHandler(val, arr) {
		const _item = arr.filter((item) => {
			if (item.cat_name === val) {
				return item
			}
			return false
		})
		const _amo = (_item.length > 0) ? _item[0].fee_amount : null;
		return _amo;
	}


	render() {
		const { display_student, due_date, fee_months_arr, selected_month, fee_header } = this.state;
		const { user, classes, schools, conveyance, students, feeWithCategory, accLedger } = this.props;
		// console.log(this.state);
		return (
			<div className="page-content">
				<Helmet>
					<title>All Student</title>
				</Helmet>
				{user && classes && schools && conveyance && students && feeWithCategory && accLedger &&
					<>
						<div className="page-bar d-flex">
							<div className="page-title">All Student</div>
							<div className="form-inline ml-auto filter-panel">
								<span className="filter-closer">
									<button type="button" className="btn btn-danger filter-toggler-c">
										<i className="fa fa-times"></i>
									</button>
								</span>
								<div className="filter-con">
									<CommonFilters
										showSchoolFilter={true}
										showMediumFilter={false}
										showClassFilter={true}
										filterBySchoolHandler={this.filterBySchoolHandler}
										filterByClsHandler={this.filterByClsHandler}
									/>
									<div className="form-group mr-2 mt-1">
										<label className="control-label mr-2">Month : </label>
										<select
											// disabled={!isEmpty(filteredClassesData.slct_cls_id) ? false : true}
											value={selected_month - 1}
											className="form-control form-control-sm " name="selected_month"
											onChange={event => this.changeHandler(event, 'selected_month')}>
											<option value="">Select...</option>
											{fee_months_arr.map((opt, index) => {
												return (<option key={index} value={index}>{opt}</option>)
											})}
										</select>
									</div>
								</div>
							</div>
						</div>

						<div className="card card-box sfpage-cover">
							<div className="card-body p-1 sfpage-body">
								<div className="form-inline">
									<div className="form-group ml-auto mb-2">
										<label className="control-label mr-2">Select Date
                        <span className="required"> * </span>
										</label>
										<div className="form-input">
											<DatePicker
												onChange={this.startDateHandler}
												value={due_date}
												showLeadingZeroes={true}
												minDate={new Date()}
											/>
										</div>
									</div>
								</div>
								{display_student &&
									<div className="table-scrollable">
										<table className="table-responsive table table-striped table-bordered table-hover table-sm m-0">
											<thead>
												<tr>
													<th />
													<th>
														<div className="custom-control custom-checkbox">
															<input type="checkbox"
																disabled={(!isEmpty(selected_month)) ? false : true}
																id="select_all" className="custom-control-input"
																onChange={event => this.checkHandler(event, 'select_all', true)} />
															<label className="custom-control-label" htmlFor="select_all">&nbsp;</label>
														</div>
													</th>
													<th />
													<th>Enr. No.</th>
													<th>Student & Father's Name</th>
													<th>Class</th>
													{fee_header.map((item, f_inx) => {
														return (
															<th key={f_inx}>{item}</th>
														)
													})}
													<th>Monthly Dues</th>
												</tr>
											</thead>
											{display_student.length > 0 ?
												<tbody>
													{display_student.map((item, index) => {
														return (
															<tr className={(item.free_seat === '0') ? 'odd gradeX' : 'odd gradeX table-warning'} key={index}>
																<td>{index + 1}.</td>
																<td>
																	<div className="custom-control custom-control-inline custom-checkbox">
																		<input type="checkbox"
																			disabled={(!isEmpty(selected_month)) ? false : true}
																			checked={item.is_checked}
																			id={`check_` + index} name="customRadio" className="custom-control-input"
																			onChange={event => this.checkHandler(event, `select_this`, JSON.stringify(item))} />
																		<label className="custom-control-label" htmlFor={`check_` + index}>&nbsp;</label>
																	</div>
																</td>
																<td className="profile-pic">
																	<NavLink className="" to={`edit_student.jsp/${item.s_id}`}>
																		{!isEmpty(item.student_image) ?
																			< img src={`${process.env.PUBLIC_URL}` + item.student_image} alt={item.student_name} />
																			: (item.gender === 'Boy' ?
																				<img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_boy.jpg`} />
																				:
																				<img alt="SmartPSP" src={`${process.env.PUBLIC_URL}/assets/images/student_girl.jpg`} />)
																		}
																	</NavLink>
																</td>
																<td>{item.admission_number}</td>
																<td><NavLink className="" to={`student_profile.jsp/${item.s_id}`}>
																	{item.student_name}
																</NavLink>
																	<br /> S/o  {item.father_name}</td>
																<td>{item.stu_class}
																</td>

																{this.currentMonthFeeHandler(item)}

																<td className="text-right">{item.crnt_dues}</td>
															</tr>
														)
													})}

												</tbody>
												: null}
										</table>
									</div>
								}
							</div>
							<div className="card-footer text-right">
								<button type="button"
									onClick={event => this.confirmBoxSubmit(event)}
									className="btn btn-primary btn-sm mr-2">Update</button>
							</div>
						</div>
					</>}
			</div>
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: schools } = state.schools;
	const { item: classes } = state.classes;
	const { item: conveyance } = state.conveyance;
	const { item: feeWithCategory } = state.feeWithCategory;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accVoucherEntry } = state.accVoucherEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	return {
		user, classes, schools, conveyance, students, feeWithCategory, accLedger,
		accVoucherEntry, filteredSchoolData, filteredClassesData
	};

}

const actionCreators = {
	getSchools: schoolsAction.getSchools,
	getClasses: classesAction.getClasses,
	getConveyance: conveyanceAction.getConveyance,
	getStudents: studentsAction.getStudents,
	getFeeWithCategory: feeWithCategoryAction.getFeeWithCategory,
	getAccVoucherEntry: accVoucherEntryActions.getAccVoucherEntry,
	createAccVoucherEntry: accVoucherEntryActions.createAccVoucherEntry,
	getAccLedger: accLedgerActions.getAccLedger,
}

export default connect(mapStateToProps, actionCreators)(withRouter(CreateMonthlyDues));