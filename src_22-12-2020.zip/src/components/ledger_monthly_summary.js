import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction, accManagerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

// import CommonFilters from '../utility/Filter/filter-schools';


class LedgerMonthlySummary extends Component {

	state = {
		months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
		formIsHalfFilledOut: false,
	}

	componentDidMount() {
		if (isEmptyObj(this.props.accLedgerEntry)) {
			this.props.getAccLedgerEntry();
		}

		if (isEmptyObj(this.props.accLedger)) {
			this.props.getAccLedger();
		}

		if (isEmptyObj(this.props.accGroup)) {
			this.props.getAccGroup();
		}
		if (isEmptyObj(this.props.students)) {
			this.props.getStudents();
		}
		// this.checkFlag();
		this.ledgerSummaryofFinancialYearHandler();
	}

	ledgerSummaryofFinancialYearHandler() {
		const { match } = this.props;
		const _id = match.params.id;
		const accManager = this.props.accManager;
		this.props.getLedgerSummaryofFinancialYearHandler({ "acc_manager": accManager, "ledger_id": _id });
		this.setState({
			ldr_id: _id
		})
	}

	render() {
		const { ldr_id, months } = this.state;
		const { data_obj, filteredSchoolData, ledger_name, g_total } = this.props;
		console.log(this.props);
		return (
			<div className="page-content">
				<Helmet>
					<title>Group Summary</title>
				</Helmet>
				<div className="page-bar d-flex">
					<div className="page-title"> Group Summary</div>
				</div>
				{data_obj &&
					<div className="card card-box sfpage-cover">
						<div className="card-body p-1 sfpage-body">
							<div className="acc-page page-ledger-monthly-summary">
								<div className="acc-page-head  container-fluid">
									<div className="sec-title">
										<div className="title-zone">Particulars</div>
										<div className="info-zone">
											<table className="table table-bordered table-sm">
												<thead>
													<tr>
														<th colSpan="3">
															<div className="group-name">{ledger_name}</div>
															<div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
															<div className="fy-detail">1-Apr-2020 to 1-Jul-2020</div>
														</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td colSpan="2">
															<div className="blnc-title">Transactions</div>
														</td>
														<td rowSpan="2">
															<div className="blnc-cl-info">Closing<br />Balance</div>
														</td>
													</tr>
													<tr>
														<td>
															<div className="dr-title">Debit</div>
														</td>
														<td>
															<div className="cr-title">Credit</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
								<div className="acc-page-body container-fluid">
									<div className="lms-detail-zone">
										{data_obj.map((item, index) => {
											return (
												(item.cl_blnc != 0) ? (
													<NavLink to={`/ledger_vouchers.jsp/${ldr_id}/${item.month_id}`} className="link-without-color" key={index}>
														<div className="lms-detail-head" key={index}>
															<div className="head-name">{months[item.month_id - 1]}</div>
															<div className="head-amount">
																<div className="dr-amount">{(item.dr_amo === 0) ? '' : item.dr_amo}</div>
																<div className="cr-amount">{(item.cr_amo === 0) ? '' : item.cr_amo}</div>
																<div className="cl-balance">
																	{(item.lcl_blnc === 0) ? '' : item.lcl_blnc + " " + item.lcl_type}
																</div>
															</div>
														</div>
													</NavLink>
												) : (
														<div className="link-without-color" key={index}>
															<div className="lms-detail-head" key={index}>
																<div className="head-name">{months[item.month_id - 1]}</div>
																<div className="head-amount">
																	<div className="dr-amount">{(item.cr_amo === 0) ? '' : item.cr_amo}</div>
																	<div className="cr-amount">{(item.dr_amo === 0) ? '' : item.dr_amo}</div>
																	<div className="cl-balance">
																		{(item.lcl_blnc === 0) ? '' : item.lcl_blnc + " " + item.lcl_type}

																	</div>
																</div>
															</div>
														</div>
													)
											)
										})}
									</div>
								</div>
								<div className="acc-page-footer container-fluid">
									<div className="sec-foot">
										<div className="title-zone">Ground Total</div>
										<div className="amount-zone">
									<div className="dr-total">{g_total.total_dr}</div>
											<div className="cr-total">{g_total.total_cr}</div>
											<div className="cl-blnc-total">{g_total.closing_amo} {g_total.closing_type} </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				}
			</div >
		)
	}
}
function mapStateToProps(state) {
	const { item: user } = state.authentication;
	const { item: students } = state.students;
	const { item: accLedger } = state.accLedger;
	const { item: accGroup } = state.accGroup;
	const { item: accLedgerEntry } = state.accLedgerEntry;
	const filteredSchoolData = state.filteredSchoolData;
	const filteredClassesData = state.filteredClassesData;
	const { item: accManager } = state.accManager;
	const { data_obj, g_total, ledger_name } = state.accManager.item.ledger_fy_report;
	return {
		user, students, accLedger, accGroup, accLedgerEntry,
		accManager, data_obj, ledger_name, g_total,
		filteredSchoolData, filteredClassesData
	};
}

const actionCreators = {
	getStudents: studentsAction.getStudents,
	getAccLedger: accLedgerActions.getAccLedger,
	getAccGroup: accGroupActions.getAccGroup,
	getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
	getLedgerSummaryofFinancialYearHandler: accManagerActions.getLedgerSummaryofFinancialYearHandler,

}

export default connect(mapStateToProps, actionCreators)(withRouter(LedgerMonthlySummary));