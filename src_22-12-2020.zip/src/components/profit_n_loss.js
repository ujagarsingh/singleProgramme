import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { accLedgerActions, accGroupActions, accLedgerEntryActions, studentsAction, 
  schoolsAction, classesAction, accManagerActions } from '../_actions';
import { isEmptyObj, isEmpty } from '../utility/utilities';

import CommonFilters from '../utility/Filter/filter-schools';
import { Helmet } from "react-helmet";

class ProfitAndLoss extends Component {

  state = {
    formIsHalfFilledOut: false,
  }

  componentDidMount() {
    if (isEmptyObj(this.props.schools)) {
      this.props.getSchools();
    }
    if (isEmptyObj(this.props.classes)) {
      this.props.getClasses();
    }
    if (isEmptyObj(this.props.accLedgerEntry)) {
      this.props.getAccLedgerEntry();
    }
    if (isEmptyObj(this.props.accLedger)) {
      this.props.getAccLedger();
    }
    if (isEmptyObj(this.props.accGroup)) {
      this.props.getAccGroup();
    }
    if (isEmptyObj(this.props.students)) {
      this.props.getStudents();
    }
    this.checkFlag();
  }


  checkFlag() {
    setTimeout(() => {
      const _filter = this.props.filteredSchoolData;
      const _all_student = this.props.students;
      const _accGroup = this.props.accGroup;
      const _accLedgerEntry = this.props.accLedgerEntry;
      if (_all_student && _filter && _accGroup && _accLedgerEntry) {
        this.filterBySchoolHandler();
      } else {
        this.checkFlag()
      }
    }, 100);
  }

  filterBySchoolHandler = () => {
    const _filter = this.props.filteredSchoolData;
    const _all_student = this.props.students;
    if (!isEmpty(_all_student)) {
      const _school_student = _all_student.filter((item) => {
        if (_filter.slct_school_id) {
          if (item.school_id === _filter.slct_school_id) {
            return item
          }
        } else {
          return item
        }
      })
      this.setState({
        display_student: _school_student,
      }, () => this.filterByClsHandler())
    }
  }

  filterByClsHandler = () => {
    const _fltr_school = this.props.filteredSchoolData;
    const _fltr_class = this.props.filteredClassesData;
    const _all_student = this.props.students;
    const _all_groups = this.props.accGroup;
    const _all_ledger = this.props.accLedger;
    const _all_accLedgerEntry = this.props.accLedgerEntry;
    if (_all_student) {
      const _school_student = _all_student.filter((item) => {
        if (!isEmpty(_fltr_class.slct_cls_name)) {
          if (item.school_id === _fltr_school.slct_school_id &&
            item.stu_class === _fltr_class.slct_cls_name) {
            return item
          }
        } else {
          if (item.school_id === _fltr_school.slct_school_id) {
            return item
          }
        }
      })
      if(_school_student.length > 0){
        this.setState({
          display_student: _school_student
        },() => 
        //this.getFinalDataHandler() 
        this.props.getACCManager({
          acc_group : _all_groups,
          acc_ledgers : _all_ledger,
          acc_entries : _all_accLedgerEntry,
          students : _all_student,
        })
        )
      } 
    }
  }

getGroupwiseDetail = (group_title, group_id) => {
    const _blanceData = this.props.accManager.group_balance;
    const _crnt_grp = _blanceData.filter((item) => {
      if (item.id === group_id) {
        return item
      }
    });
    // debugger;
    const pnl_grp = _crnt_grp[0].sub_group.filter((item) => {if(item.group_name == group_title){return item}})[0];
    const g_total = pnl_grp.cl_blnc;

    let parent_row =
                    // <NavLink to={`group_summary.jsp/${'2'}/${_crnt_grp[0].id}`} className="link-without-color">
                      <div className="bs-detail-head">
                        <div className="head-name">{group_title}</div>
                        <div className="head-amount">{(g_total === 0) ? '' : g_total}</div>
                      </div>
                    // </NavLink>
                    ;
    let child_rows = pnl_grp.sub_group.map((item, index) => {
      const sub_total = item.cl_blnc;
      return (
        <NavLink key={index} to={`ledger_monthly_summary.jsp/${item.ldr_ref_id}`} className="link-without-color">
          <div className="bs-detail-sub-head" >
            <div className="sub-head-name">{item.ledger_name}</div>
            <div className="sub-head-amount">{(sub_total === 0) ? '' : sub_total}</div>
          </div>
        </NavLink>
      )
    });
    
    const abc = <div className="bs-detail-zone">{parent_row} {child_rows}</div>;
    return abc;
  }

  getExcessIncomeExpenditureDetail = (group_title, group_id, type_zone) => {
    const _blanceData = this.props.accManager.group_balance;
    const _crnt_grp = _blanceData.filter((item) => {
      if (item.id === group_id) {
        return item
      }
    });
    const _amo_type = _crnt_grp[0].blnc_type;
    const _blnc_amo = _crnt_grp[0].cl_blnc;
    if (_amo_type  === type_zone){
    const abc = <div className="pl-detail-zone">
                  <div className="pl-detail-head">
                    <div className="head-name">{group_title}</div>
                    <div className="head-amount">{_blnc_amo}</div>
                  </div>
                  <div className="pl-detail-sub-head"></div>
                </div>;
      return abc;
    } else {
      return null
    }
  }

  getTotalValuesHandler = (group_id) => {
    const _blanceData = this.props.accManager.group_balance;
    const _crnt_grp = _blanceData.filter((item) => {
      if (item.id === group_id) {
        return item
      }
    });
    const total_amount = _crnt_grp[0].total_blnc;

    return total_amount
  }
  
  render() {
    const { user, filteredSchoolData, accManager } = this.props;
    return (
      <div className="page-content">
        <Helmet>
          <title>Profit and Loss</title>
        </Helmet>
        {user && 
        <div className="page-bar d-flex">
          <div className="page-title">Profit and Loss</div>
        </div>
        }
        {accManager && 
        <div className="card card-box sfpage-cover">
          <div className="card-body p-1 sfpage-body">
            <div className="acc-page acc-midline page-profit-n-loss">
              <div className="acc-page-head  container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="sec-title">
                      <div className="title-zone">Particulars</div>
                      <div className="info-zone">
                        <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                        <div className="fy-detail">1-Apr-2020 to 1-Sep-2020</div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="sec-title">
                      <div className="title-zone">Particulars</div>
                      <div className="info-zone">
                        <div className="org-name">{filteredSchoolData.slct_school.sch_name}</div>
                        <div className="fy-detail">1-Apr-2020 to 1-Sep-2020</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="acc-page-body container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    {this.getGroupwiseDetail('Indirect Expenses', "1001")}
                    {this.getExcessIncomeExpenditureDetail('Excess of income over expenditure (P&L)', "1001", "DR")}
                  </div>
                  <div className="col-sm-6">
                    <div className="pl-detail-zone">
                      {this.getGroupwiseDetail('Indirect Income', "1001")}
                      {this.getExcessIncomeExpenditureDetail('Excess of income over expenditure (P&L)', "1001", "CR")}
                    </div>
                  </div>
                </div>
              </div>
              <div className="acc-page-footer container-fluid">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="sec-foot">
                      <div className="title-zone">Total</div>
                      <div className="amount-zone">{this.getTotalValuesHandler("1001")}</div>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="sec-foot">
                      <div className="title-zone">Total</div>
                      <div className="amount-zone">{this.getTotalValuesHandler("1001")}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        }
      </div>
    )
  }
}
function mapStateToProps(state) {
  const { item: user } = state.authentication;
  const filteredSchoolData = state.filteredSchoolData;
  const filteredClassesData = state.filteredClassesData;
  const { item: schools } = state.schools;
  const { item: students } = state.students;
  const { item: accLedger } = state.accLedger;
  const { item: accGroup } = state.accGroup;
  const { item: accLedgerEntry } = state.accLedgerEntry;
  const { item: accManager } = state.accManager;
  return {
    user, students, accLedger, accGroup, accLedgerEntry, schools, accManager,
    filteredSchoolData, filteredClassesData
  };
}

const actionCreators = {
  getSchools: schoolsAction.getSchools,
  getClasses: classesAction.getClasses,
  getStudents: studentsAction.getStudents,
  getAccLedger: accLedgerActions.getAccLedger,
  getAccGroup: accGroupActions.getAccGroup,
  getAccLedgerEntry: accLedgerEntryActions.getAccLedgerEntry,
  getACCManager: accManagerActions.getACCManager,

}

export default connect(mapStateToProps, actionCreators)(withRouter(ProfitAndLoss));
