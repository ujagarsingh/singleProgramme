<?php
class Products{
 
    // database connection and table name
    private $conn;
    private $table_name = "product_detail";
	private $table_name1 = "product_images";
 
    // object properties
    public $user_id;
    public $product_id;
    public $product_name;
	public $product_description;
	//public $product_image = array();
	public $product_image;
	public $product_img_id;
	public $product_img_path;
	public $product_img_type;
	public $last_id;
	public $product_image_name;
	public $image_ext;
	// locahost
	public $target_folder = "/reactjs-php/demo-app/public";
	// online
	//public $target_folder = "demo/reactjs-php";
	public $target_path = "uploads/products";
	
	
	
	// constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	public function generateName($type)	{
		//preg_match('/^data:image\/(\w+);base64,/', $this->product_image_name, $type);
		//$type = strtolower($type[1]); // jpg, png, gif
		//$type = strtolower($this->image_ext);
			
		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789_";
		$name = "";
		for($i=0; $i<12; $i++){
			$name .= $chars[rand(0,strlen($chars) - 1)];
		}
		return $name.'.'.$type;
	}
	
// read products
function read(){
	$query = "SELECT p.*, p1.* 
			FROM " . $this->table_name . " p 
		LEFT JOIN 
			" . $this->table_name1 . " p1 
			ON p.product_id = p1.product_id
		WHERE 
			p1.product_img_type = 'main'";
	/*$query = "SELECT
        php_users.*, p.*, p1.*
    FROM php_users
	LEFT JOIN		    
		" . $this->table_name . " p ON php_users.user_id = p.user_id
	LEFT JOIN		
		" . $this->table_name1 . " p1 ON p.user_id = p1.product_id 
	ORDER BY 
		p.user_id, p.product_id";*/
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
 
    // execute query
    $stmt->execute();
	return $stmt;
}

// read products of single User
function read_products(){

	$query = "SELECT 
		p.*, p1.*
    FROM " . $this->table_name . " p
	LEFT JOIN		
		 " . $this->table_name1 . " p1 ON p.product_id = p1.product_id 
	WHERE
		p.user_id = ? AND p1.product_img_type = 'main'
	ORDER BY 
		p.product_id DESC";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->user_id);
  
    // execute query
    $stmt->execute();
	return $stmt;
}

// create product detail
function createProduct(){
	//$fileName = $this->generateName();
	// query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
				user_id=:user_id, 
                product_id=:product_id, 
				product_name=:product_name,
				product_description=:product_description";
	// prepare query
    $stmt = $this->conn->prepare($query);
	
	// sanitize
	$this->user_id=htmlspecialchars(strip_tags($this->user_id));
    $this->product_id=htmlspecialchars(strip_tags($this->product_id));
    $this->product_name=htmlspecialchars(strip_tags($this->product_name)); 
    $this->product_description=htmlspecialchars(strip_tags($this->product_description));
	
	
	// bind values
    $stmt->bindParam(":user_id", $this->user_id);
	$stmt->bindParam(":product_id", $this->product_id);
    $stmt->bindParam(":product_name", $this->product_name);
    $stmt->bindParam(":product_description", $this->product_description); 
  
    // execute query
    if($stmt->execute()){
		$this->last_id = $this->conn->lastInsertId();
		return true;
    }
 
    return false;
}

// create product images
function createProductImg(){
	//$fileName = $this->generateName();
 
	// query to insert record
    $query = "INSERT INTO
                " . $this->table_name1 . "
            SET
				product_id=:product_id,
				product_img_path=:product_img_path,
				product_img_type=:product_img_type";
	// prepare query
    $stmt = $this->conn->prepare($query);
	
	// sanitize
	$this->product_id=$this->last_id;
	$this->product_img_path=htmlspecialchars(strip_tags('/'.$this->target_path.'/'.$this->user_id.'_'.$this->last_id.'/'. 
	$this->product_image_name));
    $this->product_img_type=htmlspecialchars(strip_tags($this->product_img_type));
 	
	// bind values
    $stmt->bindParam(":product_id", $this->product_id);
	$stmt->bindParam(":product_img_path", $this->product_img_path);
	$stmt->bindParam(":product_img_type", $this->product_img_type);
    


    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}

// used when filling up the update product form
function readOne(){
 
    // query to read single record
    $query = "SELECT
                p.*, p1.*
            FROM
                " . $this->table_name . " p
			LEFT JOIN		
				product_images p1 ON p.product_id = p1.product_id 
            WHERE
                p.product_id = ?";
	
	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->product_id);
	 
 
    // execute query
    $stmt->execute();
	return $stmt;
	 
}

// used when filling up the update product form
function read_1($product_id){

		
    // query to read single record
    $query = "SELECT
                p.*
            FROM
                " . $this->table_name1 . " p
            WHERE
                p.product_id = $product_id";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
 
    // execute query
    $stmt->execute();
	return $stmt;
}

// will upload image file to server
function uploadPhoto(){
$data = $this->product_image;

if (preg_match('/^data:image\/(\w+);base64,/', $data, $type)) {
    $data = substr($data, strpos($data, ',') + 1);
    $type = strtolower($type[1]); // jpg, png, gif
 
    $data = base64_decode($data);
	
	if ($data === false) {
        throw new \Exception('base64_decode failed');
    }
} else {
    throw new \Exception('did not match data URI with image data');
}
$folder_path = "{$_SERVER['DOCUMENT_ROOT']}/{$this->target_folder}/{$this->target_path}/{$this->user_id}_{$this->last_id}";
/*echo"<pre>";
print_r($folder_path);
echo"<br/>";
print_r($this->product_img_path);
echo"</pre>";
die();*/
if (!file_exists($folder_path)) {
	mkdir($folder_path, 0777, true);
}else{
	null;
}

file_put_contents("{$_SERVER['DOCUMENT_ROOT']}/{$this->target_folder}/{$this->product_img_path}", $data);

}

// update the product
function update(){
//$fileName = $this->generateName();
	// query to insert record
	$query = "UPDATE
                " . $this->table_name . "
            SET
				user_id=:user_id, 
                product_id=:product_id, 
				product_name=:product_name,
				product_description=:product_description
			WHERE
                product_id = :product_id";
	// prepare query
    $stmt = $this->conn->prepare($query);
	
	// sanitize
	$this->user_id=htmlspecialchars(strip_tags($this->user_id));
    $this->product_id=htmlspecialchars(strip_tags($this->product_id));
    $this->product_name=htmlspecialchars(strip_tags($this->product_name)); 
    $this->product_description=htmlspecialchars(strip_tags($this->product_description));
	
	// bind values
    $stmt->bindParam(":user_id", $this->user_id);
	$stmt->bindParam(":product_id", $this->product_id);
    $stmt->bindParam(":product_name", $this->product_name);
    $stmt->bindParam(":product_description", $this->product_description); 
	
    // execute query
    if($stmt->execute()){
		$this->last_id = $this->product_id;
		return true;
    }
 
    return false;
}
 
// delete the product
function delete(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE product_id = :product_id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->product_id=htmlspecialchars(strip_tags($this->product_id));
 
    // bind id of record to delete
    $stmt->bindParam(':product_id', $this->product_id);
	
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}

// delete the product
function delete_img_data(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name1 . " WHERE product_img_id = :product_img_id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->product_img_id=htmlspecialchars(strip_tags($this->product_img_id));
 
    // bind id of record to delete
    $stmt->bindParam(':product_img_id', $this->product_img_id);
	
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}

// delete the product
function delete_img_folder(){
 
	$temp_folderName = $_SERVER['DOCUMENT_ROOT'] . $this->target_folder.'/'.$this->target_path.'/'.$this->user_id.'_'.$this->product_id;
	
	if (! is_dir($temp_folderName)) {
        //throw new InvalidArgumentException("$temp_folderName must be a directory");
		return false;
    }
    if (substr($temp_folderName, strlen($temp_folderName) - 1, 1) != '/') {
        $temp_folderName .= '/';
    }
    $files = glob($temp_folderName . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            self::deleteDir($file);
        } else {
            unlink($file);
        }
    }
    if(rmdir($temp_folderName)){
		//return true;
	}
    
}

// used when filling up the update product form
function deleteImage(){
 
    // query to read single record
    $query = "SELECT
                p.*
            FROM
                " . $this->table_name1 . " p
            WHERE
                p.product_img_id = ?
            LIMIT
                0,1";
	
	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->product_img_id);
 
    // execute query
    $stmt->execute();
 
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
	
    // set values to object properties
	$imagename = explode ("/", $row['product_img_path']);
	$this->fileName = $imagename[count($imagename) - 1];;  
	
	// set temporary file name
	$temp_filename = $_SERVER['DOCUMENT_ROOT'] . $this->target_folder.'/'.$this->target_path.'/'.$this->user_id.'_'.$this->product_id.'/'.$this->fileName;
	
	if(file_exists($temp_filename)){
		if(!unlink($temp_filename))
		  {
			return "[" .$this->fileName. "] Error Image deleting";
		  }
		else
		  {
			return "[" .$this->fileName. "] Image Deleted";
		  }
	}else
		{
			return "[" .$this->fileName. "] Images not exist";
		}
}

}
?>
