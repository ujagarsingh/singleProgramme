<?php
class Users{
 
    // database connection and table name
    private $conn;
    private $table_name = "php_users";
 
    // object properties
	public $user_id;
	public $user_name;
	public $user_email;
	public $user_password;
	public $user_gender;
	public $user_marital_status;
	public $user_language;
	public $user_dob;
	public $user_about;
	public $user_img_path;
	public $user_image;
	// localhost
	public $target_folder = "reactjs-php/demo-app/public";
	// online
	//public $target_folder = "demo/reactjs-php";
	public $target_path = "uploads/users";
	
    
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	public function generateName(){
		preg_match('/^data:image\/(\w+);base64,/', $this->user_image, $type);
		$type = strtolower($type[1]); // jpg, png, gif
		
		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789_";
		$name = "";
		for($i=0; $i<12; $i++){
			$name .= $chars[rand(0,strlen($chars) - 1)];
		}
 		return $name.'.'.$type;
	}
// read products
function read(){
 
    // select all query
    $query = "SELECT * FROM " . $this->table_name . "";
 
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
 
    return $stmt;
}

	

// create product
function create(){
	//$fileName = $this->generateName();
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
				user_id =:user_id,
				user_name =:user_name,
				user_email =:user_email,
				user_password = :user_password";
	
    // prepare query
	$stmt = $this->conn->prepare($query);

    // sanitize
	$this->user_id 				= $this->user_id;
	$this->user_name 			= $this->user_name;
	$this->user_email 			= $this->user_email;
	$this->user_password 		= $this->user_password;
 

    // bind values
	$stmt->bindParam(":user_id", $this->user_id);
	$stmt->bindParam(":user_name", $this->user_name);
	$stmt->bindParam(":user_email", $this->user_email);
	$stmt->bindParam(":user_password", $this->user_password);
 
 // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}

// used when filling up the update product form
function readOne(){
 
    // query to read single record
    $query = "SELECT *
            FROM
                " . $this->table_name . "
            WHERE
                user_id = ?
            LIMIT
                0,1";
	 
	// prepare query statement
    $stmt = $this->conn->prepare( $query );
	
    // bind id of product to be updated
    $stmt->bindParam(1, $this->user_id);
 
    // execute query
    $stmt->execute();
 
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
	

    // set values to object properties
	$this->user_id 				= $row['user_id'];
	$this->user_name 			= $row['user_name'];
	$this->user_email 			= $row['user_email'];
	$this->user_password 		= $row['user_password'];
	$this->user_gender 			= $row['user_gender'];
	$this->user_marital_status 	= $row['user_marital_status'];
	$this->user_language 		= $row['user_language'];
	$this->user_dob 			= $row['user_dob'];
	$this->user_about 			= $row['user_about'];
	$this->user_img_path 		= $row['user_img_path'];
 
}


// update the product
function update(){
	$fileName = $this->generateName();
 
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
				user_name =:user_name,
				user_email =:user_email,
				user_password = :user_password,
				user_gender = :user_gender,
				user_marital_status = :user_marital_status,
				user_language = :user_language,
				user_dob = :user_dob,
				user_about = :user_about,
				user_img_path = :user_img_path
				
            WHERE
                user_id = :user_id";
	
    // prepare query statement
    $stmt = $this->conn->prepare($query);
	
    // sanitize
    $this->user_id 				= $this->user_id;
	$this->user_name 			= $this->user_name;
	$this->user_email 			= $this->user_email;
	$this->user_password 		= $this->user_password;
	$this->user_gender 			= $this->user_gender;
	$this->user_marital_status 	= $this->user_marital_status;
	$this->user_language 		= $this->user_language;
	$this->user_dob 			= $this->user_dob;
	$this->user_about 			= $this->user_about;
	$this->user_img_path 		= '/'.$this->target_path.'/'.$fileName;
 
    // bind values
	$stmt->bindParam(":user_id", $this->user_id);
	$stmt->bindParam(":user_name", $this->user_name);
	$stmt->bindParam(":user_email", $this->user_email);
	$stmt->bindParam(":user_password", $this->user_password);
	$stmt->bindParam(":user_gender", $this->user_gender);
	$stmt->bindParam(":user_marital_status", $this->user_marital_status);
	$stmt->bindParam(":user_language", $this->user_language);
	$stmt->bindParam(":user_dob", $this->user_dob);
	$stmt->bindParam(":user_about", $this->user_about);
	$stmt->bindParam(":user_img_path", $this->user_img_path);
  
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}

// delete the product
function delete(){
 
    // delete query
    $query = "DELETE FROM " . $this->table_name . " WHERE user_id = :user_id";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->user_id=htmlspecialchars(strip_tags($this->user_id));
 
    // bind user_id of record to delete
    $stmt->bindParam(':user_id', $this->user_id);
 
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
  
// will upload image file to server
function uploadPhoto(){
$data = $this->user_image;

//$fileName = $this->generateName();

if (preg_match('/^data:image\/(\w+);base64,/', $data, $type)) {
    $data = substr($data, strpos($data, ',') + 1);
    $type = strtolower($type[1]); // jpg, png, gif
 
    $data = base64_decode($data);
	
	if ($data === false) {
        throw new \Exception('base64_decode failed');
    }
} else {
    throw new \Exception('did not match data URI with image data');
}

file_put_contents("{$_SERVER['DOCUMENT_ROOT']}/{$this->target_folder}/{$this->user_img_path}", $data);
}

}



 