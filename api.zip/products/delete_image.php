<?php
/*
http://localhost/reactjs-php/api/products/delete_image.php
{ 
   "userId": 4,
   "productId": 102,
   "productImgId": 341
}
*/

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
 
// include database and object file
include_once '../database.php';
include_once '../objects/products.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare Item object
$Item = new Products($db);
 
// get Item id
$data = json_decode(file_get_contents("php://input"));
 
// set Item id to be deleted
$Item->user_id = $data->userId;
$Item->product_id = $data->productId;
$Item->product_img_id = $data->productImgId;

// delete the Item
if($message = $Item->deleteImage()){
	if($Item->delete_img_data()){
	echo '{';
	    echo '"message": "'.$message.'"';
    echo '}';
	}
}
 
// if unable to delete the Item
else{
    echo '{';
        echo '"message": "'.$message.'"';
    echo '}';
	
	//echo $Item->delete_img_data();
}
//echo $Item->delete_img_data();
?>