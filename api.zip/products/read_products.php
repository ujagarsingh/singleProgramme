<?php
// http://localhost/reactjs-php/api/products/read_products.php?user_id=1
// http://localhost/reactjs-php/api/products/read_one.php?product_id=1
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
 
// include database and object files
include_once '../database.php';
include_once '../objects/products.php';

// instantiate database and ui_app object
$database = new Database();
$db = $database->getConnection();
 
// initialize object
$Products = new Products($db);

// set ID property of product to be edited
$Products->user_id = isset($_GET['user_id']) ? $_GET['user_id'] : die();
 
// query products
$stmt = $Products->read_products();
$num = $stmt->rowCount();


// check if more than 0 record found
if ($num > 0) {
   $products_arr = array();
   while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
      extract($row);
 
		$product_item = array();
	    $product_item['productId'] = $row['product_id']; 
		$product_item['productName'] = $row['product_name']; 
		$product_item['productDiscription'] = $row['product_description']; 
		
		  $product_img = array(	
			   "imageurl" => $row['product_img_path'],
			   "type" => $row['product_img_type']
			);
	   
	   // for single product images end
	   
	   $product_item['mainImage'] =  $product_img;
		 
      $products_arr[] = $product_item;
	  
   }
   echo json_encode($products_arr);
}
	
 
else{
    echo json_encode(
        array("message" => "No products found.")
    );
}
?>