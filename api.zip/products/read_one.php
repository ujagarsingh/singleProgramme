<?php
// http://localhost/reactjs-php/api/products/read_one.php?product_id=1
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
// include database and object files
include_once '../database.php';
include_once '../objects/products.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare product object
$Products = new Products($db);
 
// set ID property of product to be edited
$Products->product_id = isset($_GET['product_id']) ? $_GET['product_id'] : die();

// read the details of product to be edited
//$Products->readOne();
$stmt = $Products->readOne();
$num = $stmt->rowCount();
 
if ($num > 0) {
	//$products_arr = array();
   $product_item = array();
   while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
      extract($row);
		$products_img[] = array(
			'productImgId' => $row['product_img_id'],
			'imageurl' => $row['product_img_path'],
			'type' => $row['product_img_type']
		);
		$product_item['productId'] = $row['product_id']; 
		$product_item['productName'] = $row['product_name']; 
		$product_item['productDescription'] = $row['product_description']; 
		if($row['product_img_id']){
			$product_item['productImages'] = $products_img;
		}
		
		
	 // $products_arr = $product_item;
   }
   echo json_encode($product_item);
}
	
 
else{
    echo json_encode(
        array("message" => "No products found.")
    );
}

?>