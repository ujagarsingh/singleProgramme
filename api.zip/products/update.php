<?php
/*
http://localhost/reactjs-php/api/products/update.php

{ 
	"userId": "4",
	"productId": "30",
	"productName": "Har fun maula",
	"productDescription": "Description detail here...",
	"productImages": [
		{
			"imageurl": "/products/product1.jpg",
			"type": "main"
		},
		{
			"imageurl": "/products/product2.jpg",
			"type": "extra"
		}
	]
}

*/
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../database.php';
include_once '../objects/products.php';
 
$database = new Database();
$db = $database->getConnection();
 
$Item = new Products($db);
 
// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));
 
// set ID property of Item to be edited
$Item->product_id = $data->productId;
 
// set Item property values
$Item->user_id = $data->userId;
$Item->product_name = $data->productName;
$Item->product_description = $data->productDescription;
$Item->product_image = $data->productImages;


// delete the image
/*$imageNameLenth = strlen($Item->app_image);
if($imageNameLenth > 100){
	echo $Item->deleteImage();
}*/
// update the Item
if($Item->product_name != ''){
	$message_obj = array();
	if($Item->update()){
		// create the Item images
		foreach ($Item->product_image as $key => $object) {
			$Item->product_image = $object->imageurl;
			$Item->product_img_type = $object->type;	
			$data = $Item->product_image;

		if (preg_match('/^data:image\/(\w+);base64,/', $data, $type)) {
			$data = substr($data, strpos($data, ',') + 1);
			$type = strtolower($type[1]); // jpg, png, gif
			if($Item->product_image_name = $Item->generateName($type)){
 
 				if($Item->createProductImg()){
					$message_obj[] = "Image $Item->product_image_name was created.";
				}
				// if unable to create the Item, tell the user
				else{
					$message_obj[] = "Image $Item->product_image_name was Not created."; 
				}
			}
		}else{
			$message_obj[] = "Image Formate Not Base64"; 
		}
			// try to upload the submitted file
			// uploadPhoto() method will return an error message, if any.
			echo  $Item->uploadPhoto();
		}
		echo '{';
			echo '"message" : "';  
			foreach ($message_obj as $key => $object) {
				echo ($key + 1). ". ";
				echo $object;
				echo ',  <br/>';
			}
			echo 'and Item Detail was created.';
			echo '"';  
		echo '}';
	}
	 
	// if unable to update the Item, tell the user
	else{
		echo '{';
			echo '"message" : "';  
			foreach ($message_obj as $key => $object) {
				echo ($key + 1). ". ";
				echo $object;
				echo ',  <br/>';
			}
			echo 'and Unable to update Item Detail.';
			echo '"';  
		echo '}';
	}
 } else {
	echo '{';
		echo '"message": "Something is wrong in Detail!!!."';
	echo '}';
 }
/*$imageNameLenth = strlen($Item->app_image);
if($imageNameLenth > 100){
	echo $Item->uploadPhoto();
}*/
?>