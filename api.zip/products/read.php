<?php
// http://localhost/reactjs-php/api/products/read.php
// http://localhost/reactjs-php/api/products/read_products.php?user_id=1
// http://localhost/reactjs-php/api/products/read_one.php?product_id=1
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
 
// include database and object files
include_once '../database.php';
include_once '../objects/products.php';
 
// instantiate database and ui_app object
$database = new Database();
$db = $database->getConnection();
 
// initialize object
$Products = new Products($db);
 
// query products
$stmt = $Products->read();
$num = $stmt->rowCount();


// check if more than 0 record found
if ($num > 0) {
   $products_arr = array();
   while ($row = $stmt -> fetch(PDO:: FETCH_ASSOC)) {
      extract($row);
		$product_item = array();
	    $product_item['product_id'] = $row['product_id']; 
		$product_item['product_name'] = $row['product_name']; 
		$product_item['product_description'] = $row['product_description']; 
		$product_item['product_img_path'] = $row['product_img_path']; 
		 
		/* 
		 // for single product images start
		 $stmt_1 = $Products->read_1($row['product_id']);
		 $products_img_arr = array();
		 while ($row = $stmt_1 -> fetch(PDO:: FETCH_ASSOC)) {
		  extract($row);
		  $product_img = array(	
			"product_img_id" => $product_img_id,
			"product_img_path" => $product_img_path,
			"product_img_type" => $product_img_type
			);
		  $products_img_arr[] = $product_img;
	   }
	   
	   // for single product images end
	   
	   $product_item['product_img'] =  $products_img_arr;
		*/ 
      $products_arr[] = $product_item;
	  
   }
   echo json_encode($products_arr);
}
	
 
else{
    echo json_encode(
        array("message" => "No products found.")
    );
}
?>