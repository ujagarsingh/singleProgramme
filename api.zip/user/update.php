<?php
/*
http://localhost/reactjs-php/api/user/update.php
{"userData":{ 
        "userId": 3,
        "userName": "Neeraj Meena",
        "userEmail": "kiran@gmail.com",
        "userPassword": "ujagar@1",
        "userGender": "male",
        "maritalStatus": "married",
        "languages": "hindi,english",
        "dob": "1977-07-04",
        "aboutUser": "I am a learner in elementary programming.",
        "userImage": "/author/imagename.jpg"
}}
*/
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../database.php';
include_once '../objects/users.php';
 
$database = new Database();
$db = $database->getConnection();
 
$User = new Users($db);
 
// get id of Item to be edited
$data = json_decode(file_get_contents("php://input"));
 
// set ID property of Item to be edited
 
// set Item property values 
$User->user_id 				= $data->userData->userId;
$User->user_name 			= $data->userData->userName;
$User->user_email			= $data->userData->userEmail;
$User->user_password 		= $data->userData->userPassword;
$User->user_gender 			= $data->userData->userGender;
$User->user_marital_status	= $data->userData->maritalStatus;
$User->user_language 		= $data->userData->languages;
$User->user_dob 			= $data->userData->dob;
$User->user_about 			= $data->userData->aboutUser;
$User->user_image 			= $data->userData->userImage;

// delete the image
/*$imageNameLenth = strlen($Item->app_image);
if($imageNameLenth > 100){
	echo $Item->deleteImage();
}*/
// update the Item
if($User->update()){
    echo '{';
        echo '"message": "Item was updated."';
    echo '}';
	
	echo  $User->uploadPhoto();
}
 
// if unable to update the Item, tell the user
else{
    echo '{';
        echo '"message": "Unable to update Item."';
    echo '}';
}
/*
$imageNameLenth = strlen($Item->app_image);
if($imageNameLenth > 100){
	echo $Item->uploadPhoto();
}*/
?>