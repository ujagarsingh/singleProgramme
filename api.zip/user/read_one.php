<?php
// http://localhost/reactjs-php/api/user/read_one.php?user_id=1
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
// include database and object files
include_once '../database.php';
include_once '../objects/users.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare product object
$User = new Users($db);

// set ID property of product to be edited
$User->user_id = isset($_GET['user_id']) ? $_GET['user_id'] : die();

// read the details of product to be edited
$User->readOne();
 
// create array
$User_data=array(
	"user_id" 				=> $User->user_id,
	"user_name" 			=> $User->user_name,
	"user_email" 			=> $User->user_email,
	"user_password" 		=> $User->user_password,
	"user_gender" 			=> $User->user_gender,
	"user_marital_status" 	=> $User->user_marital_status,
	"user_language" 		=> $User->user_language,
	"user_dob" 				=> $User->user_dob,
	"user_about" 			=> $User->user_about,
	"user_img_path" 		=> $User->user_img_path
);

// make it json format

print_r(json_encode($User_data));

?>