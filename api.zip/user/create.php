<?php
/* http://localhost/reactjs-php/api/user/create.php
{"userData":{ 
"userName": "Kiran Meena",
"userEmail": "kiran@gmail.com",
"password": "ujagar@1"
}}
*/
// required headers

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// get database connection
include_once '../database.php';
include_once '../objects/users.php';

$table_name = "php_users";

$database = new Database();
$db       = $database->getConnection();

$User = new Users($db);

// get posted data
$data = json_decode(file_get_contents("php://input"));

$User->user_name     = $data->userData->userName;
$User->user_email    = $data->userData->userEmail;
$User->user_password = $data->userData->password;

$query = "
SELECT * FROM " . $table_name . "
WHERE user_email = :user_email";

$statement = $db->prepare($query);

$statement->bindParam(":user_email", $User->user_email);

if ($statement->execute()) {
    
    $result = $statement->fetchAll();
    $num    = $statement->rowCount();
    
    if ($num > 0) {
        
        echo '{';
        echo '"error": "Email is Allready Exit.."';
        echo '}';
        
    } else {
        
        // create the Item
        if ($User->user_name != "") {
            
            if ($User->create()) {
                echo '{';
                echo '"message": "Item was created."';
                echo '}';
                
                //echo  $User->uploadPhoto();
            }
            
            // if unable to create the Item, tell the user
            else {
                echo '{';
                echo '"error": "Unable to create Item."';
                echo '}';
            }
            
        } else {
            echo '{';
            echo '"message": "Something is wrong!!!."';
            echo '}';
        }
    }
}
?>