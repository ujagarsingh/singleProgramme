<?php
/*
http://localhost/reactjs-php/api/user/delete.php
{ 
   "user_id": 3
}
*/

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
 
// include database and object file
include_once '../database.php';
include_once '../objects/users.php';
 
$database = new Database();
$db = $database->getConnection();
 
 
// prepare User object
$User = new Users($db);
 
// get User id
$data = json_decode(file_get_contents("php://input"));
 
// set User id to be deleted
$User->user_id = $data->user_id;

// delete the image
//echo $User->deleteImage();

// delete the User
if($User->delete()){
	echo '{';
		echo '"message": "Item was deleted."';
    echo '}';
}
 
// if unable to delete the Item
else{
    echo '{';
        echo '"message": "Unable to delete object."';
    echo '}';
}
?>