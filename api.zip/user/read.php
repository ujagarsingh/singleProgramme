<?php
// http://localhost/reactjs-php/api/user/read.php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
 
// include database and object files
include_once '../database.php';
include_once '../objects/users.php';
 
// instantiate database and ui_app object
$database = new Database();
$db = $database->getConnection();
 
// initialize object
$Users = new Users($db);
 
// query products
$stmt = $Users->read();
$num = $stmt->rowCount();

// check if more than 0 record found
if($num>0){
 
    // products array
    $Users=array();
	
    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
	// $row = $stmt->fetch(PDO::FETCH_ASSOC);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // extract row
        // this will make $row['name'] to
        // just $name only
        
		extract($row);
		/*
		echo "<pre>";
		print_r($row);
		echo "</pre>";
		die;
		*/
		
        $User=array(
            "user_id" => $user_id,
			"user_name" => $user_name,
			"user_email" => $user_email,
			"user_password" => $user_password,
			"user_gender" => $user_gender,
			"user_marital_status" => $user_marital_status,
			"user_language" => $user_language,
			"user_dob" => $user_dob,
			"user_about" =>  $user_about,
			"user_img_path" => $user_img_path
        );
  
    	$Users[] = $User;
		 
    }
	
	echo json_encode($Users);
}
 
else{
    echo json_encode(
        array("message" => "No products found.")
    );
}
?>