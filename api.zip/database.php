<?php
class Database{
 
// specify your own database credentials 

//$path = $_SERVER['HTTP_HOST'];


//if ($path == 'localhost') {
	private $host = "localhost";
    private $db_name = "reactjs-php";
    private $username = "root";
    private $password = "";
    public  $conn;

//} else {
/*	private $host = "148.72.232.172:3306";
	private $db_name = "ujagar_react";
	private $username = "react_ujagar";
	private $password = "ujagar@123";
	public $conn;
*/
//}
 
    // get the database connection
    public function getConnection(){
 
        $this->conn = null;
 
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
 
        return $this->conn;
    }
}
?>