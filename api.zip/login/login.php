<?php
/*
http://localhost/reactjs-php/api/login/login.php
{ 
"error": "",
"isLogedIn": false,
"user_email": "kiran@gmail.com",
"user_password": "ujagar@1"
}
*/
//login.php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// include database and object files
include_once '../database.php';
$table_name = "php_users";
$database = new Database();
$db       = $database->getConnection();

session_start();

$_SESSION["user_id"]    = '';
$_SESSION["user_name"]  = '';
$_SESSION["user_email"] = '';

$form_data = json_decode(file_get_contents("php://input"));


$validation_error = '';
if (empty($form_data->user_email)) {
    
    $error[] = 'Email is Required';
    
} else {
    
    if (!filter_var($form_data->user_email, FILTER_VALIDATE_EMAIL)) {
        
        $error[] = 'Invalid Email Format';
        
    } else {

		$data[':user_email'] = $form_data->user_email;
            
    }
}

if (empty($form_data->user_password)) {
    
    $error[] = 'Password is Required';
    
}

if (empty($error)) {
    
 $query = "
 SELECT * FROM " . $table_name . "
 WHERE user_email = :user_email";
    
    $statement = $db->prepare($query);
    
    if ($statement->execute($data)) {
        
        $result = $statement->fetchAll();
        $num    = $statement->rowCount();
        
        if ($num > 0) {
            foreach ($result as $row) {
                
                
                //if(true)
                if ($form_data->user_password === $row["user_password"]) {
                    
                    $_SESSION["user_id"]    = $row["user_id"];
                    $_SESSION["user_name"]  = $row["user_name"];
                    $_SESSION["user_email"] = $row["user_email"];
                    
                } else {
                    $validation_error = 'Wrong Password';
                }
            }
        } else {
            $validation_error = 'Wrong Email';
        }
    }
} else {
    $validation_error = implode(", ", $error);
}

if ($validation_error == '') {
    $output = array(
        'is_login' => "true",
        'error' => $validation_error,
        'user_id' => $_SESSION["user_id"],
        'user_name' => $_SESSION["user_name"],
        'user_email' => $_SESSION["user_email"]
    );
    echo json_encode($output);
} else {
    echo '{';
    echo '"error": "' . $validation_error . '"';
    echo '}';
}

?>
