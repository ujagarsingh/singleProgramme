<?php

//logout.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

session_start();

unset($_SESSION["user_id"]);
unset($_SESSION["user_name"]);
unset($_SESSION["user_email"]);




if (!isset($_SESSION)) {

	echo '{';
		echo '"is_login": "Success"';
	echo '}';
	
} else {
	
	echo '{';
		echo '"is_login": "Un Success"';
	echo '}';

}
session_destroy();
?>