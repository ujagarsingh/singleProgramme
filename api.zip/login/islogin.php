<?php

//http://localhost/reactjs-php/api/login/islogin.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

session_start();

if (array_key_exists('user_id',$_SESSION) && !empty($_SESSION['user_id'])) {
	
		$output = array(
		 'is_login' 	=> true,
		 'user_id' 		=> $_SESSION["user_id"],
		 'user_name'	=> $_SESSION["user_name"],
		 'user_email' 	=> $_SESSION["user_email"]
		);

		echo json_encode($output);
	
} else {

		 
		
	echo '{';
		echo '"is_login": "false"';
	echo '}';
}

session_destroy();
//session_destroy();

?>