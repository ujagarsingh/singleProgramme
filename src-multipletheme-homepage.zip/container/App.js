// Packages
import React, { Component } from 'react';
import '../App.css';
import { connect } from 'react-redux';

// Components
// import Addtodo from '../components/layout_1/addtodo';
import Components from '../components/addtodoindex';
import Todoitem from '../components/todoitem';

// Action Creators
import { addTodo, editTodo, deleteTodo } from '../actionCreator/todo-action-creator';


class App extends Component{
  
  render(){
    const { todos, addTodo, deleteTodo, editTodo } = this.props;
    const type = 'Component2'; // example variable - will change from user input
    const Addtodo = Components[type];
    return (
      <div className="App_">
        <Addtodo addTodo={addTodo} />
        <ol>
            {
              todos.map((item, index)=>{
                return(
                  <Todoitem 
                    key={index}
                    item={item}
                    index={index}
                    deleteTodo={deleteTodo}
                    editTodo={editTodo}
                  />
                )
              })              
            }
        </ol>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    todos : state.todos
  }
}
 
export default connect(mapStateToProps, { addTodo, deleteTodo, editTodo })(App);
