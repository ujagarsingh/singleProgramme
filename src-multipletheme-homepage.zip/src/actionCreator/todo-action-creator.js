import {ADD_TODO, DELETE_TODO, EDIT_TODO} from '../actionTypes/todo-action-type'

const addTodo = ({ text })=>{
    return {
      type : ADD_TODO,
      payload : {
        text : text,
        completed : false
      }
    }
  };

const deleteTodo = (index)=>{
    return {
      type : DELETE_TODO,
      payload : index
    }
  };

const editTodo = ({text, index})=>{
    return {
      type : EDIT_TODO,
      payload : {
        text : text,
        index : index
      }
    }
  }

  export {addTodo, deleteTodo, editTodo}