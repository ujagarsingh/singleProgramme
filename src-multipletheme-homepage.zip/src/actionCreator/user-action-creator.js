export const getPost = () =>{
    return (dispatch) =>{
        axios.get('url')
        .then((response)=>{
            dispatch({
                type: "GET_POSTS",
                payload : response.data
            })
        }).catch((err)=>{
            // err
        })
    }
}