import { createStore, combineReducers, applyMiddleware } from 'redux';
import logger from 'redux-logger';

import todosReducer from './todoReducer';
import userReducer from './userReducer';

// create a store with combineReducers
const store = combineReducers({
    todos : todosReducer, 
    userInfo : userReducer
})

// create a store with middleware
const createStoreWithMiddleware = applyMiddleware(logger)(createStore)

export default createStoreWithMiddleware(
    store, 
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    );