import {ADD_TODO, DELETE_TODO, EDIT_TODO} from '../actionTypes/todo-action-type'

const todosReducer = (state = [], action) => {
    switch(action.type){
        case ADD_TODO : 
            return [
                ...state,
                action.payload
            ]
        case DELETE_TODO :
            return [
                ...state.slice(0, action.payload),
                ...state.slice(action.payload + 1)
            ]
        case EDIT_TODO :
            const inx = action.payload.index;
            return [
                ...state.slice(0, inx),
                {...state[inx], text : action.payload.text},
                ...state.slice(inx + 1)
            ]
        default :
            return state;
    }
}

export default todosReducer;