import React from 'react';
import todosReducer from '../store/todoReducer';

class Addtodo extends React.Component{
    constructor(){
        super();
        this.state = {
            isEditing : false
        };
    };

    toggleEditing = () => {
        this.setState({
            isEditing : !this.state.isEditing
        });
    };

    addItemToState = (e) => {
        e.preventDefault();
        this.props.addTodo({
          text : this.refs.addtodo.value
        })
        this.refs.addtodo.value = '';
    };
    
    editItemToState = (e) => {
        e.preventDefault();
        this.props.editTodo({
          text : this.refs.edittodo.value, 
          index : this.props.index
        })
        this.refs.edittodo.value = '';
        this.toggleEditing();
    };

    renderItem = () => {
        const {index, deleteTodo, item} = this.props;
        return (
            <div>
                <p>{item.text}</p>
                <p>
                    <button style={{marginRight:"20px"}} type="button" onClick={() => deleteTodo(index)}>Delete</button>
                    <button type="button" onClick={this.toggleEditing}>Edit</button>
                </p>
            </div>
        )
    }
    renderForm = () => {
        const {item} = this.props;
        return (
            <form onSubmit={this.editItemToState}>
                <input type="text" ref="edittodo" defaultValue={item.text} />
                <button type="submit">Edit Toto</button>
            </form>
        )
    }
    render(){
        return(
            <li>
                {
                    this.state.isEditing ? this.renderForm() : this.renderItem()
                }
            </li>
        )
    }
}

export default Addtodo;

