
const dbdata = [
{
"exam_date": "2020-10-15",
"class_subject" : [
    {
      "id": "33",
      "class_name": "PP.4+",
      "class_name_portal": "PP.4+",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "273",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "274",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "275",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "276",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "277",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "278",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "279",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "280",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "35",
                "used": false,
                "inning": ""
              },
              {
                "id": "281",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "15",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "282",
            "sub_name": "Environment Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "283",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "284",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "285",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "46",
      "class_name": "PP.5+",
      "class_name_portal": "PP.5+",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "302",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "303",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "304",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "305",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "306",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "307",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "308",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "309",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "35",
                "used": false,
                "inning": ""
              },
              {
                "id": "310",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "15",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "311",
            "sub_name": "Environment Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "312",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "313",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "314",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "47",
      "class_name": "First",
      "class_name_portal": "First",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "341",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "342",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "343",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "344",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "345",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "346",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "347",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "348",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "35",
                "used": false,
                "inning": ""
              },
              {
                "id": "349",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "15",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "350",
            "sub_name": "Environment Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "351",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "352",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "353",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "42",
      "class_name": "Second",
      "class_name_portal": "Second",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "289",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "290",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "291",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "292",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "293",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              },
              {
                "id": "294",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "295",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "296",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "35",
                "used": false,
                "inning": ""
              },
              {
                "id": "297",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "15",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "298",
            "sub_name": "Environment Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "299",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "300",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "301",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "5",
      "class_name": "Third",
      "class_name_portal": "Third",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "483",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "484",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "485",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "486",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "487",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "488",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "489",
            "sub_name": "Environment",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "490",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "491",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "492",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "493",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "494",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "495",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "496",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "497",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "45",
      "class_name": "Fourth",
      "class_name_portal": "Fourth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "438",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "439",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "440",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "441",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "442",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "443",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "444",
            "sub_name": "Environment",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "445",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "40",
                "used": false,
                "inning": ""
              },
              {
                "id": "446",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "60",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "447",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "448",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "449",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "450",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "451",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "452",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "35",
      "class_name": "Fifth",
      "class_name_portal": "Fifth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "423",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "424",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "425",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "426",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "427",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "428",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "429",
            "sub_name": "Environment",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "430",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "431",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "432",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "433",
                "sub_name": "Oral",
                "sub_lavel": "11",
                "max_marks": "20",
                "used": false,
                "inning": ""
              },
              {
                "id": "434",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "435",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "436",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "437",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "26",
      "class_name": "Sixth",
      "class_name_portal": "Sixth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "498",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "499",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "500",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "501",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "502",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "503",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "504",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "505",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "506",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "507",
            "sub_name": "Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "508",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "509",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "510",
            "sub_name": "Social Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "511",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "512",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "513",
            "sub_name": "Sanskrit",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "514",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "515",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "516",
            "sub_name": "Computer",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "517",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "518",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "519",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "520",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "521",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "48",
      "class_name": "Seventh",
      "class_name_portal": "Seventh",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "546",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "547",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "548",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "549",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "550",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "551",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "552",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "553",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "554",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "555",
            "sub_name": "Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "556",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "557",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "558",
            "sub_name": "Social Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "559",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "560",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "561",
            "sub_name": "Sanskrit",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "562",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": "30",
                "used": false,
                "inning": ""
              },
              {
                "id": "563",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "70",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "564",
            "sub_name": "Computer",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "565",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "566",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "567",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "568",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "569",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "49",
      "class_name": "Eighth",
      "class_name_portal": "Eigth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "594",
            "sub_name": "Hindi",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "595",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "596",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "597",
            "sub_name": "English",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "598",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "599",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "600",
            "sub_name": "Math",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "601",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "602",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "603",
            "sub_name": "Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "604",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "605",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "606",
            "sub_name": "Social Science",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "607",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "608",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "609",
            "sub_name": "Sanskrit",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "610",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "611",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": "80",
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "612",
            "sub_name": "Computer",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "613",
                "sub_name": "Activity Based Eval.",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "614",
                "sub_name": "Written",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "615",
            "sub_name": "Work Exp.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "616",
            "sub_name": "Art Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "617",
            "sub_name": "Health Edu.",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          }
        ]
    },
    {
      "id": "50",
      "class_name": "Ninth",
      "class_name_portal": "Ninth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "642",
            "sub_name": "Hindi",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "643",
            "sub_name": "English",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "644",
            "sub_name": "Sanskrit",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "645",
            "sub_name": "Science",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "646",
            "sub_name": "Social Science",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "647",
            "sub_name": "Math",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "678",
            "sub_name": "Rajasthan study",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "679",
            "sub_name": "Health Edu.",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "680",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "681",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "682",
            "sub_name": "Foundation of IT",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "683",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "684",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "685",
            "sub_name": "SUPW",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "686",
                "sub_name": "Mandatory Trend",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "687",
                "sub_name": "Alternative Trend",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "688",
                "sub_name": "Camp",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "689",
            "sub_name": "Art Edu.",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "690",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "691",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "692",
                "sub_name": "Presentation Work",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          }
        ]
    },
    {
      "id": "30",
      "class_name": "Tenth",
      "class_name_portal": "Tenth",
      "innings": [
        
      ],
      "subject_arr":  [
          {
            "id": "666",
            "sub_name": "Hindi",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "667",
            "sub_name": "English",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "668",
            "sub_name": "Sanskrit",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "669",
            "sub_name": "Science",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "670",
            "sub_name": "Social Science",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "671",
            "sub_name": "Math",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "710",
            "sub_name": "Rajasthan study",
            "sub_lavel": "1",
            "max_marks": 0,
            "used": false,
            "inning": ""
          },
          {
            "id": "711",
            "sub_name": "Health Edu.",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "712",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "713",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "714",
            "sub_name": "Foundation of IT",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "715",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "716",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "717",
            "sub_name": "SUPW",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "718",
                "sub_name": "Mandatory Trend",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "719",
                "sub_name": "Alternative Trend",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "720",
                "sub_name": "Camp",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          },
          {
            "id": "721",
            "sub_name": "Art Edu.",
            "sub_lavel": "2",
            "max_marks": 0,
            "used": false,
            "inning": "",
            "child": [
              {
                "id": "722",
                "sub_name": "Theoretical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "723",
                "sub_name": "Practical",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              },
              {
                "id": "724",
                "sub_name": "Presentation Work",
                "sub_lavel": "11",
                "max_marks": 0,
                "used": false,
                "inning": ""
              }
            ]
          }
        ]
    }
  ]
}]
export default dbdata;