import React from 'react'
import dbdata from './data'
class Addtodo extends React.Component{
    state = {
        classes:[
            {class_name:'First'},
            {class_name:'Second'},
            {class_name:'Third'},
            {class_name:'Forth'},
            {class_name:'Fifth'},
            // {class_name:'Sixth'},
            // {class_name:'Seventh'},
            // {class_name:'Eighth'},
            // {class_name:'Nine'}
        ],
        innings:[
            {inning_name:'First'},
            {inning_name:'Second'}
        ],
        updated_subjects : [
            
        ], 
        old_subjects:[
        { exam_date : '2020-10-15',
         class_subject :   [
                    {
                        class_name:'Fist',
                        subject_arr:[
                            {
                                sub_name:'Hindi',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'English',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Math',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Health Edu.',
                                sub_lavel:'1',
                                child:[]
                            },
                            {
                                sub_name:'GK',
                                sub_lavel:'1',
                                child:[]
                            }
                        ]
                    },
                    {
                        class_name:'Second',
                        subject_arr:[
                            {
                                sub_name:'Hindi',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'English',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Math',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Health Edu.',
                                sub_lavel:'1',
                                child:[]
                            },
                            {
                                sub_name:'GK',
                                sub_lavel:'1',
                                child:[]
                            }
                        ]
                    },
                    {
                        class_name:'Third',
                        subject_arr:[
                            {
                                sub_name:'Hindi',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'English',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Math',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Health Edu.',
                                sub_lavel:'1',
                                child:[]
                            },
                            {
                                sub_name:'GK',
                                sub_lavel:'1',
                                child:[]
                            }
                        ]
                    },
                    {
                        class_name:'Forth',
                        subject_arr:[
                            {
                                sub_name:'Hindi',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'English',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Math',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Environment',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Health Edu.',
                                sub_lavel:'1',
                                child:[]
                            },
                            {
                                sub_name:'GK',
                                sub_lavel:'1',
                                child:[]
                            }
                        ]
                    },
                    {
                        class_name:'Fifth',
                        subject_arr:[
                            {
                                sub_name:'Hindi',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'English',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Math',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Environment',
                                sub_lavel:'2',
                                child:[
                                    {sub_child_name:'oral'},
                                    {sub_child_name:'written'}
                                ]
                            },
                            {
                                sub_name:'Health Edu.',
                                sub_lavel:'1',
                                child:[]
                            },
                            {
                                sub_name:'GK',
                                sub_lavel:'1',
                                child:[]
                            }
                        ]
                    }
                ] 
            }
        ]
    
    }
    addItemToState = (e) => {
        e.preventDefault();
        this.props.addTodo({
          text : this.refs.addtodo.value
        })
        this.refs.addtodo.value = ''
    };
    componentDidMount(){
        console.log(dbdata);
        const _exam_subject = dbdata;
        this.setState({
          subjects : _exam_subject,
          updated_subjects : _exam_subject
        }, ()=>{ this.getClassObj() })
        
    }
    getClassObj(){
        const _exam_subject = this.state.subjects;
        let _new_class_arr = [];
        _exam_subject[0]['class_subject'].forEach((item)=>{
            _new_class_arr = [..._new_class_arr, {'id' : item.id,  'class_name' : item.class_name}]
        })
        // console.log(_new_class_arr);
        this.setState({
            classes : _new_class_arr
        })
    }
    addNewRow(ev){
        ev.preventDefault();
        const _exam_subject = this.state.subjects;
        const _update = [...this.state.updated_subjects, _exam_subject[0]];

        this.setState({
            updated_subjects : _update 
        })
    }
    removeRow(ev, inx){
        ev.preventDefault();
        const _exam_subject = this.state.updated_subjects;
        const _update_exam = _exam_subject.filter((item, index)=>{
            if(index != inx){
                return item
            }
        })
        this.setState({
            updated_subjects : _update_exam 
        })
    }
    getSubjectSlection(_obj, inx){
        const _innings = this.state.innings;
        const  subjects = _obj.subject_arr;
        // console.log(subjects);
        // debugger
        // const  subjects = _obj.subject_arr.filter((item)=>{
        //     return item;
        // });
        return(
            <td key={inx}>
                <select className="form-control form-control-sm">
                   {subjects.map((item, index)=>{
                       // console.log(item);
                        return (
                                (item.child && item.child.length > 0 ) ? 
                                <optgroup key={index} label={item.sub_name}>
                                    { item.child.map((item_s, idx)=>{
                                        return <option key={idx}>{item_s.sub_name}</option>
                                    })}
                                </optgroup>
                                : 
                                <option key={index}>{item.sub_name}</option>
                            )
                    })} 
                </select>
                <select className="form-control form-control-sm">
                   {_innings.map((item, index)=>{
                        return (<option key={index}>{item.inning_name}</option>)
                    })} 
                </select>
            </td>
        )
    }

    render(){
        const { classes, updated_subjects } = this.state;
        // console.log(JSON.stringify(this.state));
        return(
            // <form onSubmit={this.addItemToState}>
            //     <input type="text" ref="addtodo" />
            //     <button type="submit">Add Toto</button>
            //     <p>Layout 1 Welcome</p>
            // </form>
            <div className="container">
			<form>
			  <div class="form-row align-items-center">
				<div class="col-auto">
				  <label class="sr-only" for="inlineFormInputGroup">Innings</label>
				  <div class="input-group mb-2">
					<div class="input-group-prepend">
					  <div class="input-group-text">@</div>
					</div>
					<input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Username">
				  </div>
				</div>
				<div class="col-auto">
				  <button type="submit" class="btn btn-primary mb-2">Add Inning</button>
				</div>
			  </div>
			</form>
            <table className="table table-sm table-bordered">
                <thead className="bg-light text-secondary">
                    <tr>
                        <th></th>
                        <th>Date</th>
                        {classes.map((item,index)=>{
                            return <th key={index}>{item.class_name}</th>
                        })}
                        <th>Action</th>
                    </tr>
                </thead>
                {updated_subjects.length > 0 ?
                <tbody>
                    {updated_subjects.map((item,index)=>{
                        return (
                            <tr key={index}>
                                <td>{index + 1}.</td>
                                <td><input type="date" className="form-control form-control-sm" /></td>
                                {item.class_subject.map((item_e, idex) => {
                                    return (this.getSubjectSlection(item_e, idex))
                                })}
                                <td className="d-flex">
                                    <button type="button" onClick={event => this.addNewRow(event)} className="btn btn-primary">+</button>
                                    <button type="button" onClick={event => this.removeRow(event, index)} className="btn btn-danger ml-1">-</button>
                                </td>
                            </tr>
                        )
                    })}
                </tbody>
                : null }
            </table>
            </div>
        )
    }
}

export default Addtodo;
