import React from 'react'

class Addtodo extends React.Component{
    addItemToState = (e) => {
        e.preventDefault();
        this.props.addTodo({
          text : this.refs.addtodo.value
        })
        this.refs.addtodo.value = ''
    };

    render(){
        return(
            <form onSubmit={this.addItemToState}>
                <p>Layuout 2 Welcome</p>
                <input type="text" ref="addtodo" />
                <button type="submit">Add Toto</button>
            </form>
        )
    }
}

export default Addtodo;